import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";

/**
 * POST /api/auth/reset-password
 *
 * Security: Rate limited (10/min), token validation, session invalidation,
 * audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(request, 10);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    const { token, newPassword } = await request.json();
    const ip = getRequestIP(request);

    if (!token || !newPassword) {
      return NextResponse.json({ error: { code: "validation_error", message: "توکن و رمز عبور جدید الزامی است." } }, { status: 422 });
    }
    if (newPassword.length < 8) {
      return NextResponse.json({ error: { code: "validation_error", message: "رمز عبور باید حداقل ۸ کاراکتر باشد." } }, { status: 422 });
    }

    const resetToken = await db.passwordResetToken.findUnique({ where: { token } });

    if (!resetToken) {
      auditLog("password_reset_invalid_token", { ip, details: { reason: "not_found" } });
      return NextResponse.json({ error: { code: "invalid_token", message: "توکن نامعتبر است." } }, { status: 400 });
    }
    if (resetToken.usedAt) {
      auditLog("password_reset_invalid_token", { userId: resetToken.userId, ip, details: { reason: "already_used" } });
      return NextResponse.json({ error: { code: "token_used", message: "این توکن قبلاً استفاده شده است." } }, { status: 400 });
    }
    if (resetToken.expiresAt < new Date()) {
      auditLog("password_reset_invalid_token", { userId: resetToken.userId, ip, details: { reason: "expired" } });
      return NextResponse.json({ error: { code: "token_expired", message: "توکن منقضی شده است." } }, { status: 400 });
    }

    const passwordHash = await bcrypt.hash(newPassword, 12);
    await db.user.update({ where: { id: resetToken.userId }, data: { passwordHash, failedLoginAttempts: 0, lockedUntil: null } });
    await db.passwordResetToken.update({ where: { id: resetToken.id }, data: { usedAt: new Date() } });
    await db.session.deleteMany({ where: { userId: resetToken.userId } });

    auditLog("password_reset_success", { userId: resetToken.userId, ip });

    return NextResponse.json({ message: "رمز عبور با موفقیت تغییر کرد. لطفاً دوباره وارد شوید." }, { status: 200 });
  } catch (error) {
    console.error("Reset password error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
