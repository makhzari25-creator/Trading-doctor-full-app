import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";
import { verify } from "jsonwebtoken";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { validateCsrfToken, csrfErrorResponse } from "@/lib/auth/csrf";

/**
 * JWT secret — required in production, fallback in development only.
 */
function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error("NEXTAUTH_SECRET environment variable is required in production.");
    }
    return "trading-doctor-dev-secret-change-in-production";
  }
  return secret;
}

async function getUserId(request: NextRequest): Promise<string | null> {
  const cookie = request.cookies.get("td-session");
  if (!cookie) return null;
  try {
    return (verify(cookie.value, getJwtSecret()) as { userId: string }).userId;
  } catch {
    return null;
  }
}

/**
 * GET /api/auth/profile — fetch profile
 * No CSRF needed (read-only).
 */
export async function GET(request: NextRequest) {
  const userId = await getUserId(request);
  if (!userId) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, name: true, role: true, image: true, emailVerified: true, createdAt: true },
  });

  if (!user) return NextResponse.json({ error: { code: "not_found", message: "کاربر یافت نشد." } }, { status: 404 });
  return NextResponse.json({ user }, { status: 200 });
}

/**
 * PUT /api/auth/profile — update name/image
 * CSRF protected, rate limited (10/min), audit logged.
 */
export async function PUT(request: NextRequest) {
  try {
    // CSRF validation
    if (!validateCsrfToken(request)) {
      auditLog("csrf_rejected", { ip: getRequestIP(request), details: { endpoint: "profile PUT" } });
      return csrfErrorResponse();
    }

    // Rate limiting
    const rl = rateLimit(request, 10);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    const userId = await getUserId(request);
    if (!userId) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

    const { name, image } = await request.json();
    const updated = await db.user.update({
      where: { id: userId },
      data: {
        ...(name !== undefined && { name: name?.trim() || null }),
        ...(image !== undefined && { image }),
      },
      select: { id: true, email: true, name: true, role: true, image: true, emailVerified: true },
    });

    auditLog("profile_updated", { userId, ip: getRequestIP(request), details: { updatedFields: [name !== undefined && "name", image !== undefined && "image"].filter(Boolean) } });

    return NextResponse.json({ user: updated }, { status: 200 });
  } catch (error) {
    console.error("Profile update error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}

/**
 * PATCH /api/auth/profile — change password
 * CSRF protected, rate limited (5/min), audit logged,
 * session invalidation on success.
 */
export async function PATCH(request: NextRequest) {
  try {
    // CSRF validation
    if (!validateCsrfToken(request)) {
      auditLog("csrf_rejected", { ip: getRequestIP(request), details: { endpoint: "profile PATCH" } });
      return csrfErrorResponse();
    }

    // Rate limiting (stricter for password change)
    const rl = rateLimit(request, 5);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    const userId = await getUserId(request);
    if (!userId) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

    const { currentPassword, newPassword } = await request.json();
    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: { code: "validation_error", message: "رمز فعلی و رمز جدید الزامی است." } }, { status: 422 });
    }
    if (newPassword.length < 8) {
      return NextResponse.json({ error: { code: "validation_error", message: "رمز جدید باید حداقل ۸ کاراکتر باشد." } }, { status: 422 });
    }

    const user = await db.user.findUnique({ where: { id: userId }, select: { passwordHash: true } });
    if (!user) return NextResponse.json({ error: { code: "not_found", message: "کاربر یافت نشد." } }, { status: 404 });

    if (!await bcrypt.compare(currentPassword, user.passwordHash)) {
      return NextResponse.json({ error: { code: "invalid_password", message: "رمز فعلی نادرست است." } }, { status: 401 });
    }

    await db.user.update({ where: { id: userId }, data: { passwordHash: await bcrypt.hash(newPassword, 12) } });

    // Invalidate all sessions (force re-login on all devices)
    await db.session.deleteMany({ where: { userId } });

    auditLog("password_change", { userId, ip: getRequestIP(request) });

    return NextResponse.json({ message: "رمز عبور با موفقیت تغییر کرد." }, { status: 200 });
  } catch (error) {
    console.error("Password change error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
