import { NextRequest, NextResponse } from "next/server";
import { verify } from "jsonwebtoken";

function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") throw new Error("NEXTAUTH_SECRET required in production.");
    return "trading-doctor-dev-secret-change-in-production";
  }
  return secret;
}

/**
 * GET /api/auth/session
 * Returns current user from JWT cookie.
 */
export async function GET(request: NextRequest) {
  try {
    const cookie = request.cookies.get("td-session");
    if (!cookie) return NextResponse.json({ user: null }, { status: 200 });

    const decoded = verify(cookie.value, getJwtSecret()) as { userId: string; email: string; role: string };
    return NextResponse.json({ user: { id: decoded.userId, email: decoded.email, role: decoded.role } }, { status: 200 });
  } catch {
    const response = NextResponse.json({ user: null }, { status: 200 });
    response.cookies.delete("td-session");
    return response;
  }
}
