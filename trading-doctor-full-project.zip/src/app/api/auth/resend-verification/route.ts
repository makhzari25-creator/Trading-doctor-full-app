import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { randomBytes } from "crypto";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { sendVerificationEmail } from "@/lib/auth/email";

/**
 * POST /api/auth/resend-verification
 *
 * Generates a new email verification token for the authenticated user.
 * Rate limited (3/min), invalidates old tokens, audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(request, 3);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    // Get user from JWT
    const cookie = request.cookies.get("td-session");
    if (!cookie) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

    const { verify } = await import("jsonwebtoken");
    const JWT_SECRET = process.env.NEXTAUTH_SECRET || "trading-doctor-dev-secret-change-in-production";
    let decoded: { userId: string };
    try { decoded = verify(cookie.value, JWT_SECRET) as { userId: string }; }
    catch { return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 }); }

    const user = await db.user.findUnique({ where: { id: decoded.userId }, select: { id: true, email: true, emailVerified: true } });
    if (!user) return NextResponse.json({ error: { code: "not_found", message: "کاربر یافت نشد." } }, { status: 404 });

    if (user.emailVerified) {
      return NextResponse.json({ message: "ایمیل شما قبلاً تأیید شده است." }, { status: 200 });
    }

    // Invalidate old tokens
    await db.verificationToken.deleteMany({ where: { userId: user.id } });

    // Generate new token
    const token = randomBytes(32).toString("hex");
    await db.verificationToken.create({
      data: { userId: user.id, token, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) },
    });

    auditLog("email_verified", { userId: user.id, ip: getRequestIP(request), details: { action: "resend" } });

    // Send verification email
    await sendVerificationEmail(user.email, token);

    return NextResponse.json(
      { message: "توکن تأیید جدید ارسال شد. لطفاً ایمیل خود را بررسی کنید.", ...(process.env.NODE_ENV === "production" ? {} : { verificationToken: token }) },
      { status: 200 }
    );
  } catch (error) {
    console.error("Resend verification error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
