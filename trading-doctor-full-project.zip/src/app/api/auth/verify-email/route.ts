import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";

/**
 * POST /api/auth/verify-email
 *
 * Security: Rate limited (10/min), token validation, audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(request, 10);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    const { token } = await request.json();
    const ip = getRequestIP(request);

    if (!token) {
      return NextResponse.json({ error: { code: "validation_error", message: "توکن الزامی است." } }, { status: 422 });
    }

    const vt = await db.verificationToken.findUnique({ where: { token } });

    if (!vt) {
      auditLog("email_verify_invalid_token", { ip, details: { reason: "not_found" } });
      return NextResponse.json({ error: { code: "invalid_token", message: "توکن نامعتبر است." } }, { status: 400 });
    }
    if (vt.expiresAt < new Date()) {
      await db.verificationToken.delete({ where: { id: vt.id } });
      auditLog("email_verify_invalid_token", { userId: vt.userId, ip, details: { reason: "expired" } });
      return NextResponse.json({ error: { code: "token_expired", message: "توکن منقضی شده است. لطفاً دوباره درخواست دهید." } }, { status: 400 });
    }

    await db.user.update({ where: { id: vt.userId }, data: { emailVerified: new Date() } });
    await db.verificationToken.delete({ where: { id: vt.id } });

    auditLog("email_verified", { userId: vt.userId, ip });

    return NextResponse.json({ message: "ایمیل شما با موفقیت تأیید شد." }, { status: 200 });
  } catch (error) {
    console.error("Email verification error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
