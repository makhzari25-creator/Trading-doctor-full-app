import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";
import { sign } from "jsonwebtoken";
import { randomBytes } from "crypto";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { setCsrfCookie } from "@/lib/auth/csrf";

/**
 * JWT secret — required in production, fallback in development only.
 */
function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error("NEXTAUTH_SECRET environment variable is required in production. Generate with: openssl rand -hex 32");
    }
    return "trading-doctor-dev-secret-change-in-production";
  }
  return secret;
}

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

/**
 * POST /api/auth/login
 *
 * Security: Rate limited (5/min), account lockout (5 attempts → 15min lock),
 * generic error messages (anti-enumeration), CSRF token issued on success,
 * audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    // --- Rate limiting (5 per minute per IP) ---
    const rl = rateLimit(request, 5);
    if (!rl.allowed) {
      auditLog("rate_limited", { ip: getRequestIP(request), details: { endpoint: "login" } });
      return rateLimitResponse(rl.resetTime);
    }

    const { email, password, rememberMe } = await request.json();
    const ip = getRequestIP(request);

    if (!email || !password) {
      return NextResponse.json({ error: { code: "validation_error", message: "ایمیل و رمز عبور الزامی است." } }, { status: 422 });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const JWT_SECRET = getJwtSecret();

    // Generic error (anti-enumeration)
    const GENERIC_ERROR = { error: { code: "invalid_credentials", message: "ایمیل یا رمز عبور نادرست است." } };

    const user = await db.user.findUnique({
      where: { email: normalizedEmail },
      select: { id: true, email: true, name: true, passwordHash: true, role: true, emailVerified: true, image: true, failedLoginAttempts: true, lockedUntil: true },
    });

    if (!user) {
      await db.loginEvent.create({ data: { email: normalizedEmail, ip, userAgent: request.headers.get("user-agent") || null, success: false, reason: "user_not_found" } });
      auditLog("login_failed", { email: normalizedEmail, ip, details: { reason: "user_not_found" } });
      return NextResponse.json(GENERIC_ERROR, { status: 401 });
    }

    // --- Account lockout check ---
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const remainingMs = user.lockedUntil.getTime() - Date.now();
      const remainingMin = Math.ceil(remainingMs / 60000);
      await db.loginEvent.create({ data: { userId: user.id, email: normalizedEmail, ip, userAgent: request.headers.get("user-agent") || null, success: false, reason: "account_locked" } });
      auditLog("login_locked", { userId: user.id, email: normalizedEmail, ip });
      return NextResponse.json(
        { error: { code: "account_locked", message: `حساب شما به دلیل تلاش‌های ناموفق متعدد قفل شده است. لطفاً ${remainingMin} دقیقه دیگر تلاش کنید.` } },
        { status: 423 }
      );
    }

    // --- Password verification ---
    const validPassword = await bcrypt.compare(password, user.passwordHash);
    if (!validPassword) {
      // Increment failed attempts
      const newFailedCount = user.failedLoginAttempts + 1;
      const shouldLock = newFailedCount >= MAX_FAILED_ATTEMPTS;

      await db.user.update({
        where: { id: user.id },
        data: {
          failedLoginAttempts: newFailedCount,
          ...(shouldLock ? { lockedUntil: new Date(Date.now() + LOCK_DURATION_MS) } : {}),
        },
      });

      await db.loginEvent.create({ data: { userId: user.id, email: normalizedEmail, ip, userAgent: request.headers.get("user-agent") || null, success: false, reason: shouldLock ? "account_locked" : "wrong_password" } });
      auditLog("login_failed", { userId: user.id, email: normalizedEmail, ip, details: { reason: "wrong_password", attempt: newFailedCount, locked: shouldLock } });

      if (shouldLock) {
        return NextResponse.json(
          { error: { code: "account_locked", message: "حساب شما به دلیل ۵ تلاش ناموفق به مدت ۱۵ دقیقه قفل شده است." } },
          { status: 423 }
        );
      }

      return NextResponse.json(GENERIC_ERROR, { status: 401 });
    }

    // --- Success: reset failed attempts ---
    if (user.failedLoginAttempts > 0 || user.lockedUntil) {
      await db.user.update({ where: { id: user.id }, data: { failedLoginAttempts: 0, lockedUntil: null } });
    }

    // --- Create session ---
    const expiresIn = rememberMe ? 30 * 24 * 60 * 60 : 24 * 60 * 60;
    const jwtToken = sign({ userId: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn });
    const sessionToken = randomBytes(32).toString("hex");

    await db.session.create({
      data: { userId: user.id, sessionToken, expires: new Date(Date.now() + expiresIn * 1000), ip, userAgent: request.headers.get("user-agent") || null },
    });

    await db.loginEvent.create({ data: { userId: user.id, email: normalizedEmail, ip, userAgent: request.headers.get("user-agent") || null, success: true, reason: "success" } });
    auditLog("login_success", { userId: user.id, email: normalizedEmail, ip });

    // --- Set cookies: session (httpOnly) + CSRF (readable by JS) ---
    const response = NextResponse.json(
      {
        user: { id: user.id, email: user.email, name: user.name, role: user.role, image: user.image, emailVerified: !!user.emailVerified },
        sessionToken,
      },
      { status: 200 }
    );

    // Session cookie (httpOnly, secure in production)
    response.cookies.set("td-session", jwtToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: expiresIn,
      path: "/",
    });

    // CSRF cookie (double-submit pattern — non-httpOnly so JS can read it)
    const csrfToken = randomBytes(32).toString("hex");
    response.cookies.set("td-csrf", csrfToken, {
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: expiresIn,
    });

    // Return CSRF token in response body so client can store it
    return NextResponse.json(
      {
        user: { id: user.id, email: user.email, name: user.name, role: user.role, image: user.image, emailVerified: !!user.emailVerified },
        sessionToken,
        csrfToken,
      },
      {
        status: 200,
        headers: response.headers,
      }
    );
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
