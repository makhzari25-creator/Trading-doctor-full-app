import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { verify } from "jsonwebtoken";

function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") throw new Error("NEXTAUTH_SECRET required in production.");
    return "trading-doctor-dev-secret-change-in-production";
  }
  return secret;
}

/**
 * POST /api/auth/logout
 * Clears session cookie, deletes DB session, audit logged.
 */
export async function POST(request: NextRequest) {
  const ip = getRequestIP(request);
  try {
    // Try to get userId for audit logging
    const cookie = request.cookies.get("td-session");
    if (cookie) {
      try {
        const decoded = verify(cookie.value, getJwtSecret()) as { userId: string };
        auditLog("logout", { userId: decoded.userId, ip });
      } catch { /* expired token — still log out */ }
    }

    const body = await request.json().catch(() => ({}));
    if (body.sessionToken) {
      await db.session.deleteMany({ where: { sessionToken: body.sessionToken } }).catch(() => {});
    }

    const response = NextResponse.json({ message: "خروج موفق بود." }, { status: 200 });
    response.cookies.delete("td-session");
    response.cookies.delete("td-csrf");
    return response;
  } catch {
    const response = NextResponse.json({ message: "خروج موفق بود." }, { status: 200 });
    response.cookies.delete("td-session");
    response.cookies.delete("td-csrf");
    return response;
  }
}
