import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verify } from "jsonwebtoken";

function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) { if (process.env.NODE_ENV === "production") throw new Error("NEXTAUTH_SECRET required."); return "trading-doctor-dev-secret-change-in-production"; }
  return secret;
}

/**
 * GET /api/auth/login-history — returns last 20 login events for current user
 */
export async function GET(request: NextRequest) {
  const cookie = request.cookies.get("td-session");
  if (!cookie) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

  let userId: string;
  try { userId = (verify(cookie.value, getJwtSecret()) as { userId: string }).userId; }
  catch { return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 }); }

  const events = await db.loginEvent.findMany({
    where: { userId },
    select: { id: true, ip: true, userAgent: true, success: true, reason: true, createdAt: true },
    orderBy: { createdAt: "desc" },
    take: 20,
  });

  return NextResponse.json({ events }, { status: 200 });
}
