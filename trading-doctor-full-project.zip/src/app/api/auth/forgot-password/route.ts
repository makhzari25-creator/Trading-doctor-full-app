import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { randomBytes } from "crypto";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { sendPasswordResetEmail } from "@/lib/auth/email";

/**
 * POST /api/auth/forgot-password
 *
 * Security: Rate limited (5/min), anti-enumeration (always returns same message),
 * audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(request, 5);
    if (!rl.allowed) {
      auditLog("rate_limited", { ip: getRequestIP(request), details: { endpoint: "forgot-password" } });
      return rateLimitResponse(rl.resetTime);
    }

    const { email } = await request.json();
    const ip = getRequestIP(request);

    if (!email) {
      return NextResponse.json({ error: { code: "validation_error", message: "ایمیل الزامی است." } }, { status: 422 });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Always return same message (anti-enumeration)
    const SUCCESS = { message: "اگر این ایمیل ثبت شده باشد، لینک بازنشانی ارسال شده است." };

    const user = await db.user.findUnique({ where: { email: normalizedEmail }, select: { id: true } });

    if (!user) {
      // Log but don't reveal
      auditLog("password_reset_requested", { email: normalizedEmail, ip, details: { userExists: false } });
      return NextResponse.json(SUCCESS, { status: 200 });
    }

    // Invalidate existing unused tokens
    await db.passwordResetToken.deleteMany({ where: { userId: user.id, usedAt: null } });

    // Generate new token
    const token = randomBytes(32).toString("hex");
    await db.passwordResetToken.create({
      data: { userId: user.id, token, expiresAt: new Date(Date.now() + 60 * 60 * 1000) },
    });

    // Send password reset email
    await sendPasswordResetEmail(normalizedEmail, token);

    auditLog("password_reset_requested", { userId: user.id, email: normalizedEmail, ip, details: { userExists: true } });

    return NextResponse.json(
      { ...SUCCESS, ...(process.env.NODE_ENV === "production" ? {} : { resetToken: token }) },
      { status: 200 }
    );
  } catch (error) {
    console.error("Forgot password error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
