import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { validateCsrfToken, csrfErrorResponse } from "@/lib/auth/csrf";
import { verify } from "jsonwebtoken";

function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") throw new Error("NEXTAUTH_SECRET required in production.");
    return "trading-doctor-dev-secret-change-in-production";
  }
  return secret;
}

/**
 * POST /api/auth/avatar
 *
 * Uploads avatar as base64 (SQLite-compatible — no file system needed).
 * Validates: CSRF, rate limited (5/min), max 500KB, image types only.
 */
export async function POST(request: NextRequest) {
  try {
    // CSRF validation
    if (!validateCsrfToken(request)) {
      auditLog("csrf_rejected", { ip: getRequestIP(request), details: { endpoint: "avatar" } });
      return csrfErrorResponse();
    }

    const rl = rateLimit(request, 5);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    // Get userId from JWT
    const cookie = request.cookies.get("td-session");
    if (!cookie) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

    let userId: string;
    try { userId = (verify(cookie.value, getJwtSecret()) as { userId: string }).userId; }
    catch { return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 }); }

    const body = await request.json();
    const { image } = body;

    if (!image || typeof image !== "string") {
      return NextResponse.json({ error: { code: "validation_error", message: "تصویر الزامی است." } }, { status: 422 });
    }

    // Validate it's a data URL with image type
    if (!image.startsWith("data:image/")) {
      return NextResponse.json({ error: { code: "validation_error", message: "فقط فرمت تصویر مجاز است." } }, { status: 422 });
    }

    // Validate size (base64 string length ≈ 1.37x actual size, max 500KB image)
    const MAX_SIZE = 500 * 1024 * 1.37;
    if (image.length > MAX_SIZE) {
      return NextResponse.json({ error: { code: "validation_error", message: "حجم تصویر نباید بیش از ۵۰۰ کیلوبایت باشد." } }, { status: 422 });
    }

    // Validate allowed types
    const allowedTypes = ["data:image/jpeg", "data:image/png", "data:image/webp", "data:image/gif"];
    if (!allowedTypes.some(t => image.startsWith(t))) {
      return NextResponse.json({ error: { code: "validation_error", message: "فرمت‌های مجاز: JPEG, PNG, WebP, GIF" } }, { status: 422 });
    }

    await db.user.update({ where: { id: userId }, data: { image } });
    auditLog("profile_updated", { userId, ip: getRequestIP(request), details: { field: "avatar" } });

    return NextResponse.json({ image, message: "تصویر پروفایل به‌روزرسانی شد." }, { status: 200 });
  } catch (error) {
    console.error("Avatar upload error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
