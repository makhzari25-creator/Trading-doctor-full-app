import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verify } from "jsonwebtoken";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { validateCsrfToken, csrfErrorResponse } from "@/lib/auth/csrf";

function getJwtSecret(): string {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) { if (process.env.NODE_ENV === "production") throw new Error("NEXTAUTH_SECRET required."); return "trading-doctor-dev-secret-change-in-production"; }
  return secret;
}

async function getUserId(request: NextRequest): Promise<string | null> {
  const cookie = request.cookies.get("td-session");
  if (!cookie) return null;
  try { return (verify(cookie.value, getJwtSecret()) as { userId: string }).userId; } catch { return null; }
}

/**
 * GET /api/auth/sessions — list active sessions for current user
 */
export async function GET(request: NextRequest) {
  const userId = await getUserId(request);
  if (!userId) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

  const sessions = await db.session.findMany({
    where: { userId, expires: { gt: new Date() } },
    select: { id: true, sessionToken: true, expires: true, createdAt: true, ip: true, userAgent: true },
    orderBy: { createdAt: "desc" },
  });

  // Get current session token from JWT to mark current
  const cookie = request.cookies.get("td-session");
  let currentSessionToken = "";
  if (cookie) {
    try { const decoded = verify(cookie.value, getJwtSecret()) as { userId: string }; 
      // Find the most recent session as "current"
      currentSessionToken = sessions[0]?.sessionToken || "";
    } catch {}
  }

  return NextResponse.json({ sessions: sessions.map(s => ({ ...s, isCurrent: s.sessionToken === currentSessionToken })) }, { status: 200 });
}

/**
 * DELETE /api/auth/sessions — revoke a specific session (by sessionToken in body)
 * or all sessions except current (if body.sessionToken === "all-others")
 */
export async function DELETE(request: NextRequest) {
  if (!validateCsrfToken(request)) { auditLog("csrf_rejected", { ip: getRequestIP(request), details: { endpoint: "sessions DELETE" } }); return csrfErrorResponse(); }

  const userId = await getUserId(request);
  if (!userId) return NextResponse.json({ error: { code: "unauthorized", message: "لطفاً وارد شوید." } }, { status: 401 });

  const body = await request.json();
  const { sessionToken } = body;

  if (sessionToken === "all-others") {
    // Revoke all sessions except the current one
    const cookie = request.cookies.get("td-session");
    let currentToken = "";
    if (cookie) { try { currentToken = (verify(cookie.value, getJwtSecret()) as { userId: string }).userId; } catch {} }
    // Find current session token
    const currentSession = await db.session.findFirst({ where: { userId }, orderBy: { createdAt: "desc" } });
    if (currentSession) {
      await db.session.deleteMany({ where: { userId, NOT: { sessionToken: currentSession.sessionToken } } });
    }
    return NextResponse.json({ message: "تمام جلسات دیگر بسته شدند." }, { status: 200 });
  }

  if (!sessionToken) return NextResponse.json({ error: { code: "validation_error", message: "توکن جلسه الزامی است." } }, { status: 422 });

  await db.session.deleteMany({ where: { userId, sessionToken } });
  auditLog("logout", { userId, ip: getRequestIP(request), details: { action: "revoke_session" } });

  return NextResponse.json({ message: "جلسه بسته شد." }, { status: 200 });
}
