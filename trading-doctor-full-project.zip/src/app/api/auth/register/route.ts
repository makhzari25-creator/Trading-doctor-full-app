import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { rateLimit, rateLimitResponse } from "@/lib/auth/rate-limiter";
import { auditLog, getRequestIP } from "@/lib/auth/audit-log";
import { sendVerificationEmail, sendWelcomeEmail } from "@/lib/auth/email";

/**
 * POST /api/auth/register
 *
 * Security: Rate limited (10/min), email enumeration protected,
 * bcrypt(12), verification token, audit logged.
 */
export async function POST(request: NextRequest) {
  try {
    // --- Rate limiting ---
    const rl = rateLimit(request, 10);
    if (!rl.allowed) return rateLimitResponse(rl.resetTime);

    const { email, password, name } = await request.json();
    const ip = getRequestIP(request);

    // --- Validation ---
    if (!email || !password) {
      return NextResponse.json({ error: { code: "validation_error", message: "ایمیل و رمز عبور الزامی است." } }, { status: 422 });
    }
    const normalizedEmail = email.toLowerCase().trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return NextResponse.json({ error: { code: "validation_error", message: "فرمت ایمیل نامعتبر است." } }, { status: 422 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: { code: "validation_error", message: "رمز عبور باید حداقل ۸ کاراکتر باشد." } }, { status: 422 });
    }

    // --- Email enumeration protection ---
    // If email already exists, return generic success (don't reveal it's taken)
    const existing = await db.user.findUnique({ where: { email: normalizedEmail }, select: { id: true } });
    if (existing) {
      auditLog("register_duplicate_attempt", { email: normalizedEmail, ip });
      return NextResponse.json(
        { message: "اگر ایمیل معتبر باشد، حساب ایجاد شد. لطفاً ایمیل خود را برای تأیید بررسی کنید." },
        { status: 201 }
      );
    }

    // --- Create user ---
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await db.user.create({
      data: { email: normalizedEmail, name: name?.trim() || null, passwordHash, role: "user" },
      select: { id: true, email: true, name: true, role: true },
    });

    // --- Verification token ---
    const token = randomBytes(32).toString("hex");
    await db.verificationToken.create({
      data: { userId: user.id, token, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) },
    });

    auditLog("register_success", { userId: user.id, email: normalizedEmail, ip });

    // Send verification + welcome emails
    await sendVerificationEmail(normalizedEmail, token);
    await sendWelcomeEmail(normalizedEmail, name?.trim() || null);

    return NextResponse.json(
      {
        user,
        message: "ثبت‌نام موفق بود. لطفاً ایمیل خود را تأیید کنید.",
        ...(process.env.NODE_ENV === "production" ? {} : { verificationToken: token }),
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Registration error:", error);
    return NextResponse.json({ error: { code: "internal_error", message: "خطای داخلی سرور." } }, { status: 500 });
  }
}
