"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface AuthUser {
  id: string; email: string; name: string | null; role: string; image: string | null; emailVerified: boolean;
}

interface AuthState {
  user: AuthUser | null; sessionToken: string | null; isAuthenticated: boolean; isLoading: boolean;
  setUser: (user: AuthUser | null) => void;
  setSession: (user: AuthUser, token: string) => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
}

export const useAuthStore = create<AuthState>()(persist((set) => ({
  user: null, sessionToken: null, isAuthenticated: false, isLoading: true,
  setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
  setSession: (user, token) => set({ user, sessionToken: token, isAuthenticated: true, isLoading: false }),
  logout: () => set({ user: null, sessionToken: null, isAuthenticated: false, isLoading: false }),
  setLoading: (loading) => set({ isLoading: loading }),
}), { name: "td-auth", partialize: (s) => ({ user: s.user, sessionToken: s.sessionToken, isAuthenticated: s.isAuthenticated }) }));
