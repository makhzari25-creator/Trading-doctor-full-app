/**
 * Trading Doctor — Email Service
 *
 * Production email service using Resend.
 * Sends: verification emails, password reset emails, welcome emails.
 *
 * In development (no RESEND_API_KEY): returns the verification/reset URL
 * directly in the API response so testing works without email.
 *
 * In production (RESEND_API_KEY set): sends real HTML emails.
 */

import { Resend } from "resend";

const apiKey = process.env.RESEND_API_KEY;
const FROM = process.env.EMAIL_FROM || "Trading Doctor <noreply@tradingdoctor.app>";
const APP_URL = process.env.APP_URL || "http://localhost:3000";

const resend = apiKey ? new Resend(apiKey) : null;

interface EmailParams {
  to: string;
  subject: string;
  html: string;
}

/**
 * Send an email. In development, logs to console instead.
 */
async function sendEmail({ to, subject, html }: EmailParams): Promise<boolean> {
  if (!resend) {
    // Development mode: log email instead of sending
    console.log("\n========== EMAIL (Dev Mode) ==========");
    console.log(`To: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Body: ${html.substring(0, 200)}...`);
    console.log("=======================================\n");
    return true;
  }

  try {
    const { error } = await resend.emails.send({
      from: FROM,
      to,
      subject,
      html,
    });

    if (error) {
      console.error("Email send error:", error);
      return false;
    }
    return true;
  } catch (error) {
    console.error("Email service error:", error);
    return false;
  }
}

/**
 * Send email verification email.
 */
export async function sendVerificationEmail(email: string, token: string): Promise<boolean> {
  const verifyUrl = `${APP_URL}/?view=verify-email&token=${token}`;

  const html = `
    <div dir="rtl" style="font-family: 'Vazirmatn', sans-serif; max-width: 480px; margin: 0 auto; padding: 24px; background: #0a0e1a; color: #f1f5f9;">
      <div style="text-align: center; margin-bottom: 32px;">
        <div style="width: 48px; height: 48px; background: #3b82f6; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold; color: white;">TD</div>
        <h1 style="font-size: 24px; margin-top: 16px;">Trading Doctor</h1>
      </div>
      <h2 style="font-size: 18px; color: #f1f5f9;">تأیید ایمیل</h2>
      <p style="color: #94a3b8; line-height: 1.6;">برای تکمیل ثبت‌نام، لطفاً ایمیل خود را تأیید کنید:</p>
      <a href="${verifyUrl}" style="display: inline-block; background: #f59e0b; color: #0a0e1a; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 16px 0;">تأیید ایمیل</a>
      <p style="color: #64748b; font-size: 12px; margin-top: 24px;">اگر شما این درخواست را انجام نداده‌اید، این ایمیل را نادیده بگیرید.</p>
      <hr style="border: none; border-top: 1px solid #1a2238; margin: 24px 0;" />
      <p style="color: #64748b; font-size: 11px;">© 2024 Trading Doctor. تمام حقوق محفوظ است.</p>
    </div>
  `;

  return sendEmail({ to: email, subject: "تأیید ایمیل — Trading Doctor", html });
}

/**
 * Send password reset email.
 */
export async function sendPasswordResetEmail(email: string, token: string): Promise<boolean> {
  const resetUrl = `${APP_URL}/?view=reset-password&token=${token}`;

  const html = `
    <div dir="rtl" style="font-family: 'Vazirmatn', sans-serif; max-width: 480px; margin: 0 auto; padding: 24px; background: #0a0e1a; color: #f1f5f9;">
      <div style="text-align: center; margin-bottom: 32px;">
        <div style="width: 48px; height: 48px; background: #3b82f6; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold; color: white;">TD</div>
        <h1 style="font-size: 24px; margin-top: 16px;">Trading Doctor</h1>
      </div>
      <h2 style="font-size: 18px; color: #f1f5f9;">بازنشانی رمز عبور</h2>
      <p style="color: #94a3b8; line-height: 1.6;">شما درخواست بازنشانی رمز عبور کرده‌اید. برای ادامه روی دکمه زیر کلیک کنید:</p>
      <a href="${resetUrl}" style="display: inline-block; background: #f59e0b; color: #0a0e1a; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 16px 0;">بازنشانی رمز عبور</a>
      <p style="color: #64748b; font-size: 12px; margin-top: 24px;">این لینک تا ۱ ساعت معتبر است. اگر شما این درخواست را انجام نداده‌اید، این ایمیل را نادیده بگیرید.</p>
      <hr style="border: none; border-top: 1px solid #1a2238; margin: 24px 0;" />
      <p style="color: #64748b; font-size: 11px;">© 2024 Trading Doctor. تمام حقوق محفوظ است.</p>
    </div>
  `;

  return sendEmail({ to: email, subject: "بازنشانی رمز عبور — Trading Doctor", html });
}

/**
 * Send welcome email (after successful registration).
 */
export async function sendWelcomeEmail(email: string, name: string | null): Promise<boolean> {
  const html = `
    <div dir="rtl" style="font-family: 'Vazirmatn', sans-serif; max-width: 480px; margin: 0 auto; padding: 24px; background: #0a0e1a; color: #f1f5f9;">
      <div style="text-align: center; margin-bottom: 32px;">
        <div style="width: 48px; height: 48px; background: #3b82f6; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold; color: white;">TD</div>
        <h1 style="font-size: 24px; margin-top: 16px;">Trading Doctor</h1>
      </div>
      <h2 style="font-size: 18px;">خوش آمدید${name ? `، ${name}` : ""}!</h2>
      <p style="color: #94a3b8; line-height: 1.6;">حساب شما با موفقیت ایجاد شد. اکنون می‌توانید فایل معاملات خود را آپلود کرده و تحلیل رفتاری دریافت کنید.</p>
      <a href="${APP_URL}" style="display: inline-block; background: #f59e0b; color: #0a0e1a; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 16px 0;">شروع تحلیل</a>
      <hr style="border: none; border-top: 1px solid #1a2238; margin: 24px 0;" />
      <p style="color: #64748b; font-size: 11px;">© 2024 Trading Doctor. تمام حقوق محفوظ است.</p>
    </div>
  `;

  return sendEmail({ to: email, subject: "خوش آمدید به Trading Doctor", html });
}
