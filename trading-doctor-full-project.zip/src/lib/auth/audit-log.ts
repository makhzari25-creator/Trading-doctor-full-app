/**
 * Trading Doctor — Audit Logger
 *
 * Structured logging for all auth events.
 * Logs to console (structured JSON) — in production, forward to log aggregation.
 */

export type AuthEventType =
  | "register_success"
  | "register_duplicate_attempt"
  | "login_success"
  | "login_failed"
  | "login_locked"
  | "logout"
  | "password_change"
  | "password_reset_requested"
  | "password_reset_success"
  | "password_reset_invalid_token"
  | "email_verified"
  | "email_verify_invalid_token"
  | "profile_updated"
  | "rate_limited"
  | "csrf_rejected";

export interface AuditLogEntry {
  timestamp: string;
  event: AuthEventType;
  userId?: string;
  email?: string;
  ip?: string;
  details?: Record<string, unknown>;
}

/**
 * Log an auth event. In development, logs to console.
 * In production, this would forward to Sentry/LogTail/etc.
 */
export function auditLog(
  event: AuthEventType,
  data: { userId?: string; email?: string; ip?: string; details?: Record<string, unknown> } = {}
): void {
  const entry: AuditLogEntry = {
    timestamp: new Date().toISOString(),
    event,
    ...data,
  };

  // Console logging (structured JSON)
  console.log("[AUDIT]", JSON.stringify(entry));

  // In production, forward to external logging service:
  // - Sentry (for security events)
  // - LogTail / Datadog (for audit trail)
  // - Database AuditLog table (for compliance)
}

/**
 * Extract IP from request for logging.
 */
export function getRequestIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  const realIP = request.headers.get("x-real-ip");
  if (realIP) return realIP.trim();
  return "unknown";
}
