/**
 * Trading Doctor — Rate Limiter
 *
 * In-memory IP-based rate limiter for auth endpoints.
 * Sliding window: tracks requests per IP within a 1-minute window.
 *
 * Limits:
 * - login, forgot-password: 5 requests per minute
 * - register, reset-password, verify-email: 10 requests per minute
 * - profile (PUT/PATCH): 10 requests per minute
 */

import { NextResponse } from "next/server";

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const store = new Map<string, RateLimitEntry>();
const WINDOW_MS = 60 * 1000; // 1 minute

// Cleanup expired entries every 5 minutes
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of store.entries()) {
      if (now > entry.resetTime) store.delete(key);
    }
  }, 5 * 60 * 1000);
}

/**
 * Check if a request should be rate limited.
 * @param request - The incoming request
 * @param limit - Max requests per minute
 * @param identifier - Additional identifier (e.g., email) for per-user limiting
 * @returns { allowed, remaining, resetTime }
 */
export function rateLimit(
  request: Request,
  limit: number = 5,
  identifier?: string
): { allowed: boolean; remaining: number; resetTime: number } {
  const ip = getClientIP(request);
  const key = identifier ? `${ip}:${identifier}` : ip;
  const now = Date.now();

  const entry = store.get(key);

  if (!entry || now > entry.resetTime) {
    store.set(key, { count: 1, resetTime: now + WINDOW_MS });
    return { allowed: true, remaining: limit - 1, resetTime: now + WINDOW_MS };
  }

  entry.count++;
  if (entry.count > limit) {
    return { allowed: false, remaining: 0, resetTime: entry.resetTime };
  }

  return { allowed: true, remaining: limit - entry.count, resetTime: entry.resetTime };
}

/**
 * Create a 429 Too Many Requests response.
 */
export function rateLimitResponse(resetTime: number): NextResponse {
  const retryAfter = Math.ceil((resetTime - Date.now()) / 1000);
  return NextResponse.json(
    {
      error: {
        code: "rate_limited",
        message: `تعداد درخواست‌ها بیش از حد مجاز است. لطفاً ${retryAfter} ثانیه دیگر تلاش کنید.`,
      },
    },
    {
      status: 429,
      headers: {
        "Retry-After": String(retryAfter),
        "X-RateLimit-Reset": String(Math.floor(resetTime / 1000)),
      },
    }
  );
}

function getClientIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  const realIP = request.headers.get("x-real-ip");
  if (realIP) return realIP.trim();
  return "unknown";
}
