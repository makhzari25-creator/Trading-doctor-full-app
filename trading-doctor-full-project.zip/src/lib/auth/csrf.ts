/**
 * Trading Doctor — CSRF Protection
 *
 * Double-submit cookie pattern:
 * 1. Server sets a CSRF token cookie (non-httpOnly, so JS can read it)
 * 2. Client sends the token in X-CSRF-Token header on state-changing requests
 * 3. Server validates that cookie token === header token
 *
 * This prevents CSRF attacks because an attacker can't read the cookie
 * (same-origin policy) to include it in their forged request's header.
 */

import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";

const CSRF_COOKIE_NAME = "td-csrf";
const CSRF_HEADER_NAME = "x-csrf-token";

/**
 * Generate a new CSRF token and set it as a cookie.
 * Call this on login success to issue a fresh CSRF token.
 */
export function setCsrfCookie(response: NextResponse): NextResponse {
  const token = randomBytes(32).toString("hex");
  response.cookies.set(CSRF_COOKIE_NAME, token, {
    httpOnly: false, // Must be readable by JavaScript
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 30 * 24 * 60 * 60, // 30 days (match session)
  });
  // Also return in response body so client can store it
  return NextResponse.json(
    { ...response.body, csrfToken: token },
    { status: response.status, headers: response.headers }
  );
}

/**
 * Validate CSRF token on state-changing requests.
 * Returns true if valid, false if missing/mismatched.
 */
export function validateCsrfToken(request: NextRequest): boolean {
  const cookieToken = request.cookies.get(CSRF_COOKIE_NAME)?.value;
  const headerToken = request.headers.get(CSRF_HEADER_NAME);

  if (!cookieToken || !headerToken) return false;
  if (cookieToken.length !== 64 || headerToken.length !== 64) return false;

  // Constant-time comparison to prevent timing attacks
  return timingSafeEqual(cookieToken, headerToken);
}

/**
 * Constant-time string comparison.
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

/**
 * Create a 403 Forbidden response for CSRF failures.
 */
export function csrfErrorResponse(): NextResponse {
  return NextResponse.json(
    {
      error: {
        code: "csrf_failed",
        message: "درخواست نامعتبر است. لطفاً صفحه را بازخوانی و دوباره تلاش کنید.",
      },
    },
    { status: 403 }
  );
}
