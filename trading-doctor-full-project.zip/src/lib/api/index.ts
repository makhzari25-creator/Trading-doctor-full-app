/**
 * Trading Doctor — API Functions
 *
 * Typed wrappers around the V23 REST API (proxied via BFF Route Handlers).
 * Each function corresponds to one V23 endpoint.
 *
 * Phase 5 §7, Phase 2 §5.1 (trades endpoint).
 */

export { ApiError } from "./client";

import { apiClient, apiUpload } from "./client";
import type {
  AnalysisReport,
  AnalysisSummary,
  AppConfig,
  HistoryResponse,
  TradesResponse,
  UploadResponse,
} from "../types";
import type { LLMProvider } from "../utils";

/* ============================================================================
   Health & Config
   ============================================================================ */

export async function getHealth(): Promise<{
  status: string;
  version: string;
  engine_ready: boolean;
  timestamp: string;
}> {
  return apiClient("/health");
}

export async function getConfig(): Promise<AppConfig> {
  return apiClient("/config");
}

/* ============================================================================
   Uploads
   ============================================================================ */

export async function uploadFile(file: File): Promise<UploadResponse> {
  return apiUpload<UploadResponse>("/uploads", file);
}

/* ============================================================================
   Analyses
   ============================================================================ */

export async function runAnalysis(
  uploadId: string,
  llmProvider: LLMProvider = "none"
): Promise<AnalysisSummary> {
  return apiClient<AnalysisSummary>("/analyses", {
    method: "POST",
    body: JSON.stringify({
      upload_id: uploadId,
      llm_provider: llmProvider,
    }),
  });
}

export async function getAnalysis(analysisId: string): Promise<AnalysisSummary> {
  return apiClient<AnalysisSummary>(`/analyses/${analysisId}`);
}

export async function getAnalysisReport(
  analysisId: string
): Promise<AnalysisReport> {
  return apiClient<AnalysisReport>(`/analyses/${analysisId}/report`);
}

/* ============================================================================
   Trades (NEW — Phase 2 §5.1)
   ============================================================================ */

export interface GetTradesParams {
  page?: number;
  pageSize?: number;
  side?: "long" | "short";
  outcome?: "win" | "loss";
}

export async function getTrades(
  analysisId: string,
  params: GetTradesParams = {}
): Promise<TradesResponse> {
  const searchParams = new URLSearchParams();
  if (params.page) searchParams.set("page", String(params.page));
  if (params.pageSize) searchParams.set("page_size", String(params.pageSize));
  if (params.side) searchParams.set("side", params.side);
  if (params.outcome) searchParams.set("outcome", params.outcome);

  const query = searchParams.toString();
  return apiClient<TradesResponse>(
    `/analyses/${analysisId}/trades${query ? `?${query}` : ""}`
  );
}

/* ============================================================================
   History
   ============================================================================ */

export async function getHistory(
  page = 1,
  pageSize = 20
): Promise<HistoryResponse> {
  return apiClient<HistoryResponse>(
    `/history?page=${page}&page_size=${pageSize}`
  );
}

/* ============================================================================
   Reports (download endpoints — return blobs, not JSON)
   ============================================================================ */

export async function downloadReportHtml(analysisId: string): Promise<string> {
  const response = await fetch(`/api/v1/analyses/${analysisId}/report.html`);
  if (!response.ok) throw new Error("تولید HTML ناموفق بود");
  return response.text();
}

export async function downloadReportPdf(analysisId: string): Promise<Blob> {
  const response = await fetch(`/api/v1/analyses/${analysisId}/report.pdf`);
  if (!response.ok) throw new Error("تولید PDF ناموفق بود");
  return response.blob();
}
