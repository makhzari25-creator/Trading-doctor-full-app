/**
 * Trading Doctor — Mock Data
 *
 * Faithfully represents V23 engine output for development without the backend.
 * Every field matches data_context.py structure exactly.
 * In production, replaced by real API calls via lib/api/.
 */

import type { AnalysisReport, HistoryItem, Trade } from "./types";

/* ============================================================================
   Mock Analysis Report
   ============================================================================ */

export const mockAnalysisReport: AnalysisReport = {
  meta: {
    report_title: "Trading Doctor — Behavioral Trading Report",
    generated_at: "۱۴۰۴/۰۴/۲۰ ۱۴:۳۰",
    engine_version: "Trading Doctor V23 — Phase 4",
    total_trades: 1245,
  },
  executive_summary: {
    summary_text:
      "تحلیل ۱۲۴۵ معامله‌ی شما نشان می‌دهد الگوی معامله‌ی انتقامی بزرگ‌ترین عامل ضرر است. با اصلاح این رفتار، потенциال سود شما تا ۶۰٪ بیشتر می‌شود.",
    overall_score: 67,
    primary_diagnosis: "معامله‌ی انتقامی پس از باخت‌های پیاپی",
    archetype: "Revenge Trader",
  },
  overall_score: {
    value: 67,
    label: "Overall Trading Score (Discipline Composite)",
    severity: 1,
  },
  diagnosis: {
    primary: "معامله‌ی انتقامی پس از باخت‌های پیاپی",
    secondary: "بیش‌معامله‌گری در روزهای پر",
    primary_detail:
      "پس از ۲ یا چند باخت متوالی، حجم معامله‌ی بعدی را به‌طور میانگین ۶۷٪ افزایش می‌دهید. این رفتار در ۱۲ مورد رخ داده و مجموعاً ۱٬۸۴۰ دلار ضرر ایجاد کرده است — معادل ۱۴۹٪ از سود خالص فعلی شما.",
    secondary_detail:
      "در روزهایی با بیش از ۵ معامله، وین‌ریت شما از ۵۲٪ به ۳۸٪ کاهش می‌یابد.",
  },
  trader_profile: {
    archetype: "Revenge Trader",
    dominant_pattern: "Revenge Trading",
    risk_appetite: "Medium-High",
    discipline_level: "Medium",
  },
  strengths: [
    "بهترین ساعت معاملاتی: ساعت ۱۴:۰۰ (میانگین سود +$۱۲/معامله).",
    "Profit Factor ۱.۳ — بالاتر از خط سربه‌سر استاندارد (۱.۰).",
    "انضباط در محدوده‌ی سالم قرار دارد (۶۷/۱۰۰).",
  ],
  weaknesses: [
    "معامله‌ی انتقامی: ۱۲ رویداد، ۱۸۴۰ دلار ضرر.",
    "بیش‌معامله‌گری: ۸ روز با بیش از ۵ معامله.",
    "ضعیف‌ترین ساعت معاملاتی: ۰۳:۰۰ (میانگین ضرر -$۸/معامله).",
  ],
  behavior_analysis: {
    scores: {
      revenge_score: 45,
      overtrading_score: 30,
      risk_taking_score: 25,
      patience_score: 80,
      discipline_score: 67,
    },
    context_rows: [
      {
        key: "revenge_score",
        label: "معامله‌ی انتقامی",
        score: 45,
        severity: "Critical",
        event_count: 12,
        dollars_lost: 1840,
        dollars_lost_fmt: "-$1,840",
        pct_of_total_profit: 149,
        insight:
          "پس از ۲+ باخت متوالی، حجم معامله‌ی بعدی را ۶۷٪ افزایش می‌دهید. این الگو ۱۲ بار رخ داده است.",
      },
      {
        key: "overtrading_score",
        label: "بیش‌معامله‌گری",
        score: 30,
        severity: "High",
        event_count: 8,
        dollars_lost: 420,
        dollars_lost_fmt: "-$420",
        pct_of_total_profit: 34,
        insight:
          "در ۸ روز با بیش از ۵ معامله، وین‌ریت از ۵۲٪ به ۳۸٪ کاهش یافته است.",
      },
      {
        key: "risk_taking_score",
        label: "ریسک‌پذیری در حجم",
        score: 25,
        severity: "Medium",
        event_count: 5,
        dollars_lost: 210,
        dollars_lost_fmt: "-$210",
        pct_of_total_profit: 17,
        insight:
          "۵ معامله با حجم بیش از ۱.۵ برابر میانگین داشته‌اید — نشانه‌ی مدیریت حجم ضعیف.",
      },
      {
        key: "patience_score",
        label: "صبر و فاصله‌ی زمانی",
        score: 80,
        severity: "Low",
        event_count: 3,
        dollars_lost: 45,
        dollars_lost_fmt: "-$45",
        pct_of_total_profit: 4,
        insight:
          "میانگین فاصله‌ی زمانی بین معاملات ۲۵ دقیقه است — در محدوده‌ی سالم.",
      },
      {
        key: "discipline_score",
        label: "انضباط کلی",
        score: 67,
        severity: "Medium",
        event_count: 0,
        dollars_lost: 0,
        dollars_lost_fmt: "$0",
        pct_of_total_profit: 0,
        insight: "امتیاز انضباط ترکیبی شما ۶۷ از ۱۰۰ است — در محدوده‌ی متوسط.",
      },
    ],
    detected_patterns: [
      "Revenge Trading after consecutive losses",
      "Overtrading on high-volume days",
      "Occasional oversized positions",
    ],
    what_if: {
      if_revenge_fixed: {
        current_profit: 1240,
        projected_profit: 3080,
        difference: 1840,
        improvement_pct: 149,
      },
    },
  },
  psychology: {
    dna: {
      archetype: "Revenge Trader",
      dominant_pattern: "Revenge Trading",
      risk_appetite: "Medium-High",
      discipline_level: "Medium",
    },
    narrative:
      "پروفایل رفتاری غالب شما «معامله‌گر انتقامی» است. این آرچیتایپ بر اساس مهم‌ترین شاهد رفتاری شناسایی‌شده در تاریخچه‌ی معاملاتی شما تعیین شده است (نه یک آستانه‌ی ثابت).\n\nمعامله‌گران انتقامی پس از یک باخت، تمایل به ورود سریع به معامله‌ی بعدی با حجم بزرگ‌تر دارند. این رفتار اغلب ناخودآگاه است و ریشه در تمایل به «جبران سریع ضرر» دارد — اما در عمل، حجم بزرگ‌تر در شرایط هیجانی باعث تصمیم‌های ضعیف‌تر و ضرر بیشتر می‌شود.\n\nخبر خوب: داده‌ی شما نشان می‌دهد در حالت عادی (بدون فشار باخت) وین‌ریت شما ۵۲٪ است — یعنی استراتژی شما سودده است. مشکل در مدیریت هیجان پس از باخت است، نه در خود استراتژی. با اصلاح این رفتار، potentiال سود شما تا ۶۰٪ افزایش می‌یابد.",
  },
  evidence: [
    {
      type: "revenge",
      label: "معامله‌ی انتقامی",
      description:
        "پس از ۲ یا چند باخت متوالی، حجم معامله‌ی بعدی را افزایش می‌دهید. این الگو ۱۲ بار رخ داده است.",
      severity: 3,
      frequency: 12,
      financial_impact: 1840,
      financial_impact_fmt: "-$1,840",
      priority_score: 92,
      confidence: 85,
    },
    {
      type: "overtrading",
      label: "بیش‌معامله‌گری",
      description:
        "در ۸ روز با بیش از ۵ معامله، عملکرد شما به‌طور قابل‌توجهی بدتر شده است.",
      severity: 2,
      frequency: 8,
      financial_impact: 420,
      financial_impact_fmt: "-$420",
      priority_score: 68,
      confidence: 72,
    },
    {
      type: "risk",
      label: "ریسک‌پذیری در حجم",
      description:
        "۵ معامله با حجم بیش از ۱.۵ برابر میانگین داشته‌اید — نشانه‌ی مدیریت حجم ضعیف.",
      severity: 1,
      frequency: 5,
      financial_impact: 210,
      financial_impact_fmt: "-$210",
      priority_score: 55,
      confidence: 65,
    },
    {
      type: "patience",
      label: "صبر و فاصله‌ی زمانی",
      description:
        "میانگین فاصله‌ی زمانی بین معاملات ۲۵ دقیقه است — در محدوده‌ی سالم.",
      severity: 0,
      frequency: 3,
      financial_impact: 45,
      financial_impact_fmt: "-$45",
      priority_score: 30,
      confidence: 80,
    },
    {
      type: "timing",
      label: "زمان‌بندی ضعیف",
      description: "در ساعت ۰۳:۰۰ به‌طور متوسط ضرر می‌کنید.",
      severity: 1,
      frequency: 15,
      financial_impact: 180,
      financial_impact_fmt: "-$180",
      priority_score: 48,
      confidence: 60,
    },
    {
      type: "streak",
      label: "رشته‌های باخت طولانی",
      description: "بیشترین رشته‌ی باخت شما ۵ معامله بوده است.",
      severity: 1,
      frequency: 2,
      financial_impact: 95,
      financial_impact_fmt: "-$95",
      priority_score: 42,
      confidence: 70,
    },
    {
      type: "consistency",
      label: "عدم ثبات در حجم",
      description: "واریانس حجم معاملات شما بالا است.",
      severity: 1,
      frequency: 20,
      financial_impact: 120,
      financial_impact_fmt: "-$120",
      priority_score: 38,
      confidence: 55,
    },
    {
      type: "emotional",
      label: "تصمیم هیجانی",
      description:
        "الگوی ورود سریع پس از باخت نشان‌دهنده‌ی تصمیم‌های هیجانی است.",
      severity: 2,
      frequency: 10,
      financial_impact: 350,
      financial_impact_fmt: "-$350",
      priority_score: 52,
      confidence: 68,
    },
  ],
  statistics: {
    total_trades: 1245,
    win_rate_pct: 52.3,
    max_win_streak: 7,
    max_loss_streak: 5,
  },
  performance: {
    net_profit: 1240,
    net_profit_fmt: "+$1,240",
    profit_factor: 1.3,
    avg_win: 24,
    avg_win_fmt: "+$24",
    avg_loss: -18,
    avg_loss_fmt: "-$18",
    reward_risk_ratio: 1.33,
  },
  risk: {
    max_drawdown: 890,
    max_drawdown_fmt: "-$890",
    risk_taking_score: 25,
    revenge_score: 45,
    what_if_no_revenge: {
      current_profit: 1240,
      projected_profit: 3080,
      difference: 1840,
      improvement_pct: 149,
    },
  },
  recommendations: [
    {
      priority: "P1",
      issue: "معامله‌ی انتقامی",
      action: "بعد از هر باخت، حداقل ۳۰ دقیقه استراحت کن و حجم بعدی را افزایش نده.",
      rationale:
        "این قانون به شما کمک می‌کند از تصمیم‌های هیجانی فاصله بگیرید. داده‌ی شما نشان می‌دهد ۱۲ رویداد انتقامی ۱۸۴۰ دلار ضرر ایجاد کرده — اصلاح این رفتار alone می‌تواند سود شما را ۱۴۹٪ افزایش دهد.",
    },
    {
      priority: "P2",
      issue: "بیش‌معامله‌گری",
      action: "برای خودت سقف روزانه‌ی تعداد معامله تعیین کن (مثلاً حداکثر ۵ معامله در روز).",
      rationale:
        "در روزهایی با بیش از ۵ معامله، وین‌ریت شما از ۵۲٪ به ۳۸٪ کاهش می‌یابد. سقف روزانه از خستگی تصمیم‌گیری جلوگیری می‌کند.",
    },
    {
      priority: "P3",
      issue: "ریسک‌پذیری در حجم",
      action: "برای هر معامله یک حداکثر حجم ثابت (٪ از سرمایه) تعیین کن و از آن عبور نکن.",
      rationale:
        "۵ معامله با حجم بزرگ‌تر از ۱.۵ برابر میانگین داشته‌اید. حجم ثابت از تصمیم‌های تکانشی جلوگیری می‌کند.",
    },
    {
      priority: "P4",
      issue: "زمان‌بندی",
      action: "در بازه‌ی ساعتی ضعیفت (۰۳:۰۰) یا معامله نکن یا استراتژی متفاوتی امتحان کن.",
      rationale: "در ساعت ۰۳:۰۰ به‌طور متوسط ۸ دلار ضرر می‌کنید.",
    },
    {
      priority: "P5",
      issue: "مدیریت رشته‌های باخت",
      action: "بعد از ۳ باخت پیاپی، معامله را برای بقیه‌ی روز متوقف کن.",
      rationale:
        "بیشترین رشته‌ی باخت شما ۵ معامله بوده — توقف زودتر از آن جلوی ضرر بیشتر را می‌گیرد.",
    },
  ],
  ai_coaching: {
    explainable_ai:
      "تحلیل ۱۲۴۵ معامله‌ی شما نشان می‌دهد استراتژی پایه‌ی شما سودده است (وین‌ریت ۵۲٪، Profit Factor ۱.۳)، اما اجرای شما در شرایط هیجانی ضعف دارد. بزرگ‌ترین فرصت بهبود، مدیریت رفتار پس از باخت است.\n\nوقتی پس از یک باخت، حس فوریت برای «جبران» پیدا می‌کنید، این دقیقاً لحظه‌ای است که باید از بازار فاصله بگیرید. مغز شما در حالت استرس، ارزیابی ریسک را کاهش می‌دهد و حجم را بزرگ‌تر از حد معمول انتخاب می‌کنید — ترکیبی که در ۱۲ مورد برای شما ۱۸۴۰ دلار هزینه داشته است.\n\nقانون ساده‌ی ۳۰ دقیقه استراحت پس از هر باخت، این چرخه را می‌شکند. نیازی به تغییر استراتژی نیست — فقط مکث کافی قبل از معامله‌ی بعدی.",
    reality_check:
      "هیچ ابزاری نمی‌تواند جایگزین انضباط شخصی شود. Trading Doctor می‌گوید چه رفتاری شما را ضرر می‌دهد، اما اصلاح آن به خود شما بستگی دارد. با یک تغییر کوچک شروع کنید: فقط قانون ۳۰ دقیقه استراحت را یک هفته امتحان کنید و دوباره تحلیل کنید. احتمالاً تفاوت را در اعداد خواهید دید.",
  },
  appendix: {
    performance_raw: {
      net_profit: 1240,
      gross_profit: 14880,
      gross_loss: 13640,
      profit_factor: 1.09,
      max_drawdown: 890,
      total_trades: 1245,
      winning_trades: 651,
      losing_trades: 594,
      win_rate: 52.3,
    },
    edge_map_raw: {
      best_hour: { hour: 14, avg_pnl: 12 },
      worst_hour: { hour: 3, avg_pnl: -8 },
      best_weekday: { day: "سه‌شنبه", total_pnl: 420 },
      worst_weekday: { day: "یکشنبه", total_pnl: -180 },
      best_strategy: { name: "Trend Follow", avg_pnl: 18, win_rate_pct: 58 },
      worst_strategy: { name: "Counter-trend", avg_pnl: -12, win_rate_pct: 35 },
      side_comparison: {
        long: { count: 780, win_rate: 54, avg_pnl: 3.2, total_pnl: 980 },
        short: { count: 465, win_rate: 48, avg_pnl: 1.1, total_pnl: 260 },
      },
    },
    data_quality_warnings: [
      "۳ ردیف تکراری شناسایی و حذف شد.",
      "۲ معامله با حجم صفر یافت شد.",
      "۵ تاریخ نامعتبر اصلاح شد.",
    ],
    generation_metadata: {
      generated_at: "۱۴۰۴/۰۴/۲۰ ۱۴:۳۰:۴۵",
      engine_version: "Trading Doctor V23 — Phase 4",
      total_trades: 1245,
    },
  },
};

/* ============================================================================
   Mock Trades (generated with realistic revenge-trading patterns)
   ============================================================================ */

function generateMockTrades(): Trade[] {
  const trades: Trade[] = [];
  const weekdays = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  let lossStreak = 0;
  let avgSize = 0.3;

  for (let i = 1; i <= 1245; i++) {
    const hour = Math.floor(Math.random() * 24);
    const isWinningHour = hour >= 8 && hour <= 17;
    const isRevengeTrade = lossStreak >= 2 && Math.random() < 0.4;
    const side: "Long" | "Short" = Math.random() > 0.4 ? "Long" : "Short";

    let size = 0.1 + Math.random() * 0.4;
    if (isRevengeTrade) {
      size = avgSize * (1.5 + Math.random() * 0.5);
    }

    const baseWinRate = isWinningHour ? 0.58 : 0.42;
    const adjustedWinRate = isRevengeTrade ? 0.3 : baseWinRate;
    const isWin = Math.random() < adjustedWinRate;

    const profit = isWin
      ? size * 80 + Math.random() * 20
      : -(size * 60 + Math.random() * 20);

    if (profit < 0) {
      lossStreak++;
    } else {
      lossStreak = 0;
    }

    avgSize = (avgSize * (i - 1) + size) / i;

    const day = new Date(2024, 0, 15);
    day.setHours(hour, Math.floor(Math.random() * 60));

    trades.push({
      id: i,
      open_time: day.toISOString().replace("T", " ").substring(0, 19),
      side,
      size: Math.round(size * 100) / 100,
      profit: Math.round(profit * 100) / 100,
      hour,
      weekday: weekdays[day.getDay()],
      date: day.toISOString().substring(0, 10),
    });
  }

  return trades;
}

export const mockTrades: Trade[] = generateMockTrades();

/* ============================================================================
   Mock History
   ============================================================================ */

export const mockHistory: HistoryItem[] = [
  {
    analysis_id: "analysis_001",
    upload_id: "upload_001",
    filename: "trades_jan.csv",
    created_at: "2025-01-15T14:30:00Z",
    total_trades: 1245,
    overall_score: 67,
    primary_diagnosis: "معامله‌ی انتقامی",
  },
  {
    analysis_id: "analysis_002",
    upload_id: "upload_002",
    filename: "trades_dec.csv",
    created_at: "2024-12-15T10:00:00Z",
    total_trades: 890,
    overall_score: 72,
    primary_diagnosis: "بیش‌معامله‌گری",
  },
  {
    analysis_id: "analysis_003",
    upload_id: "upload_003",
    filename: "trades_nov.csv",
    created_at: "2024-11-10T16:45:00Z",
    total_trades: 1100,
    overall_score: 54,
    primary_diagnosis: "ریسک‌پذیری در حجم",
  },
  {
    analysis_id: "analysis_004",
    upload_id: "upload_004",
    filename: "trades_oct.csv",
    created_at: "2024-10-05T09:15:00Z",
    total_trades: 760,
    overall_score: 78,
    primary_diagnosis: "انضباط خوب",
  },
  {
    analysis_id: "analysis_005",
    upload_id: "upload_005",
    filename: "trades_sep.csv",
    created_at: "2024-09-20T13:00:00Z",
    total_trades: 950,
    overall_score: 61,
    primary_diagnosis: "معامله‌ی انتقامی",
  },
];

/* ============================================================================
   Chart Data (derived from mock trades)
   ============================================================================ */

export const mockEquityCurve = (() => {
  let cumulative = 0;
  return mockTrades
    .filter((_, i) => i % 10 === 0)
    .map((t, i) => {
      cumulative += t.profit * 10;
      return { trade: i * 10 + 1, equity: Math.round(cumulative) };
    });
})();

export const mockDrawdown = (() => {
  let peak = 0;
  let cumulative = 0;
  return mockTrades
    .filter((_, i) => i % 10 === 0)
    .map((t, i) => {
      cumulative += t.profit * 10;
      peak = Math.max(peak, cumulative);
      return { trade: i * 10 + 1, drawdown: Math.min(0, cumulative - peak) };
    });
})();

export const mockPnLDistribution = (() => {
  const buckets: Record<string, number> = {};
  const range = [-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50];
  range.forEach((r) => {
    buckets[`${r}`] = 0;
  });
  mockTrades.forEach((t) => {
    const bucket = Math.floor(t.profit / 10) * 10;
    const key = `${Math.max(-50, Math.min(50, bucket))}`;
    buckets[key] = (buckets[key] || 0) + 1;
  });
  return Object.entries(buckets).map(([range, count]) => ({
    range: `${range} to ${parseInt(range) + 10}`,
    count,
    type: parseInt(range) >= 0 ? "win" : "loss",
  }));
})();

export const mockHourlyPnL = (() => {
  return Array.from({ length: 24 }, (_, h) => {
    const tradesInHour = mockTrades.filter((t) => t.hour === h);
    const totalPnL = tradesInHour.reduce((sum, t) => sum + t.profit, 0);
    return {
      hour: h,
      pnl: Math.round(totalPnL),
      count: tradesInHour.length,
    };
  });
})();
