/**
 * Trading Doctor — Type Definitions
 *
 * Mirrors V23 engine output (data_context.py) exactly.
 * These types are the single source of truth for all frontend code.
 * In production, validated at runtime by Zod schemas (lib/validations/).
 *
 * Phase 3 Design System §39, Phase 5 §6.
 */

/* ============================================================================
   Severity
   ============================================================================ */

export type Severity = "Low" | "Medium" | "High" | "Critical";

export type SeverityLevel = 0 | 1 | 2 | 3;

/* ============================================================================
   Analysis Report (GET /api/v1/analyses/{id}/report)
   ============================================================================ */

export interface Meta {
  report_title: string;
  generated_at: string;
  engine_version: string;
  total_trades: number;
}

export interface ExecutiveSummary {
  summary_text: string;
  overall_score: number;
  primary_diagnosis: string;
  archetype: string;
}

export interface OverallScore {
  value: number;
  label: string;
  severity: SeverityLevel;
}

export interface Diagnosis {
  primary: string;
  secondary?: string;
  primary_detail?: string;
  secondary_detail?: string;
}

export interface TraderProfile {
  archetype: string;
  dominant_pattern?: string;
  risk_appetite?: string;
  discipline_level?: string;
  [key: string]: string | undefined;
}

export interface ContextRow {
  key: string;
  label: string;
  score: number;
  severity: Severity;
  event_count: number;
  dollars_lost: number;
  dollars_lost_fmt: string;
  pct_of_total_profit: number;
  insight: string;
}

export interface WhatIfResult {
  current_profit: number;
  projected_profit: number;
  difference: number;
  improvement_pct: number;
}

export interface BehaviorAnalysis {
  scores: {
    revenge_score: number;
    overtrading_score: number;
    risk_taking_score: number;
    patience_score: number;
    discipline_score: number;
  };
  context_rows: ContextRow[];
  detected_patterns: string[];
  what_if: {
    if_revenge_fixed?: WhatIfResult;
    [key: string]: unknown;
  };
}

export interface Psychology {
  dna: TraderProfile;
  narrative: string;
}

export interface Evidence {
  type: string;
  label: string;
  description: string;
  severity: SeverityLevel;
  frequency: number;
  financial_impact: number;
  financial_impact_fmt: string;
  priority_score: number;
  confidence: number;
}

export interface Statistics {
  total_trades: number;
  win_rate_pct: number;
  max_win_streak: number;
  max_loss_streak: number;
}

export interface Performance {
  net_profit: number;
  net_profit_fmt: string;
  profit_factor: number;
  avg_win: number;
  avg_win_fmt: string;
  avg_loss: number;
  avg_loss_fmt: string;
  reward_risk_ratio: number;
}

export interface Risk {
  max_drawdown: number;
  max_drawdown_fmt: string;
  risk_taking_score: number;
  revenge_score: number;
  what_if_no_revenge: WhatIfResult;
}

export interface Recommendation {
  priority: string;
  issue: string;
  action: string;
  rationale?: string;
}

export interface AICoaching {
  explainable_ai: string;
  reality_check: string;
}

export interface EdgeMapEntry {
  hour?: number;
  day?: string;
  avg_pnl?: number;
  total_pnl?: number;
  win_rate_pct?: number;
  name?: string;
}

export interface SideComparison {
  count: number;
  win_rate: number;
  avg_pnl: number;
  total_pnl: number;
}

export interface EdgeMapRaw {
  best_hour?: EdgeMapEntry;
  worst_hour?: EdgeMapEntry;
  best_weekday?: EdgeMapEntry;
  worst_weekday?: EdgeMapEntry;
  best_strategy?: EdgeMapEntry;
  worst_strategy?: EdgeMapEntry;
  side_comparison?: {
    long: SideComparison;
    short: SideComparison;
  };
}

export interface Appendix {
  performance_raw: Record<string, number>;
  edge_map_raw: EdgeMapRaw;
  data_quality_warnings: string[];
  generation_metadata: {
    generated_at: string;
    engine_version: string;
    total_trades: number;
  };
}

export interface AnalysisReport {
  meta: Meta;
  executive_summary: ExecutiveSummary;
  overall_score: OverallScore;
  diagnosis: Diagnosis;
  trader_profile: TraderProfile;
  strengths: string[];
  weaknesses: string[];
  behavior_analysis: BehaviorAnalysis;
  psychology: Psychology;
  evidence: Evidence[];
  statistics: Statistics;
  performance: Performance;
  risk: Risk;
  recommendations: Recommendation[];
  ai_coaching: AICoaching;
  appendix: Appendix;
}

/* ============================================================================
   Analysis Summary (POST /api/v1/analyses, GET /api/v1/analyses/{id})
   ============================================================================ */

export interface AnalysisSummary {
  analysis_id: string;
  upload_id: string;
  filename: string;
  created_at: string;
  total_trades: number;
  overall_score: number;
  primary_diagnosis: string;
  data_quality_warning_count: number;
}

/* ============================================================================
   Upload (POST /api/v1/uploads)
   ============================================================================ */

export interface UploadResponse {
  upload_id: string;
  filename: string;
  size_bytes: number;
  uploaded_at: string;
}

/* ============================================================================
   Trades (GET /api/v1/analyses/{id}/trades — NEW, Phase 2 §5.1)
   ============================================================================ */

export interface Trade {
  id: number;
  open_time: string;
  side: "Long" | "Short";
  size: number;
  profit: number;
  hour: number;
  weekday: string;
  date: string;
}

export interface TradesResponse {
  trades: Trade[];
  total: number;
  page: number;
  page_size: number;
}

/* ============================================================================
   History (GET /api/v1/history)
   ============================================================================ */

export interface HistoryItem {
  analysis_id: string;
  upload_id: string;
  filename: string;
  created_at: string;
  total_trades: number;
  overall_score: number;
  primary_diagnosis: string;
}

export interface HistoryResponse {
  items: HistoryItem[];
  total: number;
  page: number;
  page_size: number;
}

/* ============================================================================
   Config (GET /api/v1/config)
   ============================================================================ */

export interface AppConfig {
  max_upload_size_bytes: number;
  allowed_file_types: string[];
  llm_providers: string[];
  auth_enabled: boolean;
  rate_limit_enabled: boolean;
  rate_limit_rpm: number;
}

/* ============================================================================
   API Error Envelope (standard across all V23 endpoints)
   ============================================================================ */

export interface ApiErrorEnvelope {
  error: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
}

/* ============================================================================
   View IDs (for client-side routing)
   ============================================================================ */

export type ViewId =
  | "landing"
  | "upload"
  | "dashboard"
  | "behavioral"
  | "diagnosis"
  | "coaching"
  | "trader-dna"
  | "edge-map"
  | "charts"
  | "trade-explorer"
  | "trends"
  | "report"
  | "history"
  | "settings"
  | "profile"
  | "security"
  | "login"
  | "register"
  | "forgot-password"
  | "reset-password"
  | "verify-email";
