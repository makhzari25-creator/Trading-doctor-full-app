/**
 * Trading Doctor — Prisma Client (Singleton)
 *
 * Reads DATABASE_URL from process.env (Prisma schema also reads it via env()).
 * Singleton pattern prevents exhausting DB connections during dev hot-reload.
 *
 * Provider is set to "postgresql" in prisma/schema.prisma — Supabase PostgreSQL
 * is the only supported database.
 *
 * If DATABASE_URL is missing or malformed, we log a clear warning at module-load
 * time so the developer can fix it. We do NOT throw, so the server stays alive
 * for health checks. Prisma itself will throw a clear error when a query runs.
 */

import { PrismaClient } from "@prisma/client";

function warnIfDatabaseUrlInvalid(): void {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.warn(
      "[db] DATABASE_URL is not set. Database queries will fail. " +
      "Set it in your .env file (local) or platform dashboard (production)."
    );
    return;
  }
  if (!url.startsWith("postgresql://") && !url.startsWith("postgres://")) {
    console.warn(
      `[db] DATABASE_URL does not look like a PostgreSQL URL (got: ${url.substring(0, 30)}...). ` +
      "Provider is set to postgresql in prisma/schema.prisma. " +
      "Database queries will fail until this is corrected."
    );
  }
}

warnIfDatabaseUrlInvalid();

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;
