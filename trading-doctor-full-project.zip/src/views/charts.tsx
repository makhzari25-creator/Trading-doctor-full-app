/**
 * Trading Doctor — نمودارها View
 * 4 Recharts visualizations: Equity Curve, Drawdown, P&L Distribution, Hourly P&L.
 * RTL-aware axes (XAxis reversed, YAxis orientation="right").
 */

"use client";

import {
  mockAnalysisReport,
  mockEquityCurve,
  mockDrawdown,
  mockPnLDistribution,
  mockHourlyPnL,
} from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { useAppStore } from "@/lib/store/app-store";
import { toPersianNumerals } from "@/lib/utils";
import { ChartLineUp, ArrowLeft } from "@phosphor-icons/react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ReferenceLine,
} from "recharts";

const tooltipStyle = {
  backgroundColor: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "8px",
  fontSize: "12px",
} as const;

const axisTick = { fill: "var(--muted-foreground)", fontSize: 11 } as const;
const smallTick = { fill: "var(--muted-foreground)", fontSize: 10 } as const;

export function ChartsView() {
  const navigate = useAppStore((s) => s.navigate);
  const r = mockAnalysisReport;
  const maxDD = Math.min(...mockDrawdown.map((d) => d.drawdown));

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">نمودارها</h1>
        <p className="text-sm text-muted-foreground">visual deep-dive عملکرد معاملات</p>
      </div>

      {/* Equity Curve */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-1">
          <ChartLineUp size={18} className="text-[var(--primary)]" />
          <h3 className="text-sm font-semibold">منحنی سرمایه</h3>
        </div>
        <p className="text-xs text-muted-foreground mb-3">رشد حساب در طول زمان</p>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={mockEquityCurve}>
            <defs>
              <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="trade" tick={axisTick} reversed />
            <YAxis tick={axisTick} orientation="right" />
            <Tooltip
              contentStyle={tooltipStyle}
              labelStyle={{ color: "var(--muted-foreground)" }}
            />
            <Area
              type="monotone"
              dataKey="equity"
              stroke="var(--chart-1)"
              strokeWidth={2}
              fill="url(#equityGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 سود خالص:{" "}
          <span className="td-mono font-bold text-foreground">
            {r.performance.net_profit_fmt}
          </span>{" "}
          در <span className="td-mono">{toPersianNumerals(r.statistics.total_trades)}</span> معامله
        </div>
      </Card>

      {/* Drawdown */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">دراودان (Drawdown)</h3>
        <p className="text-xs text-muted-foreground mb-3">افت سرمایه از اوج قبلی</p>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={mockDrawdown}>
            <defs>
              <linearGradient id="ddGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--profit-negative)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="var(--profit-negative)" stopOpacity={0.6} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="trade" tick={axisTick} reversed />
            <YAxis tick={axisTick} orientation="right" />
            <Tooltip contentStyle={tooltipStyle} />
            <ReferenceLine y={0} stroke="var(--border)" />
            <Area
              type="monotone"
              dataKey="drawdown"
              stroke="var(--profit-negative)"
              strokeWidth={2}
              fill="url(#ddGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 بزرگ‌ترین افت:{" "}
          <span
            className="td-mono font-bold"
            style={{ color: "var(--profit-negative)" }}
          >
            {toPersianNumerals(Math.abs(maxDD))}
          </span>
        </div>
      </Card>

      {/* P&L Distribution */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">توزیع سود/زیان</h3>
        <p className="text-xs text-muted-foreground mb-3">آیا سودهای شما بزرگ‌تر از ضررهاست؟</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={mockPnLDistribution}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="range" tick={smallTick} reversed />
            <YAxis tick={axisTick} orientation="right" />
            <Tooltip contentStyle={tooltipStyle} />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {mockPnLDistribution.map((entry, idx) => (
                <Cell
                  key={idx}
                  fill={
                    entry.type === "win"
                      ? "var(--profit-positive)"
                      : "var(--profit-negative)"
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 میانگین سود (
          <span className="td-mono" style={{ color: "var(--profit-positive)" }}>
            {r.performance.avg_win_fmt}
          </span>{" "}
          {r.performance.avg_win > Math.abs(r.performance.avg_loss)
            ? "بزرگ‌تر"
            : "کوچک‌تر"}{" "}
          از میانگین ضرر (
          <span className="td-mono" style={{ color: "var(--profit-negative)" }}>
            {r.performance.avg_loss_fmt}
          </span>
          )
        </div>
      </Card>

      {/* Hourly P&L */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">سود/زیان ساعتی</h3>
        <p className="text-xs text-muted-foreground mb-3">چه ساعتی بهترین/بدترین عملکرد را دارید؟</p>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={mockHourlyPnL}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="hour" tick={smallTick} reversed />
            <YAxis tick={axisTick} orientation="right" />
            <Tooltip contentStyle={tooltipStyle} />
            <ReferenceLine y={0} stroke="var(--border)" />
            <Bar dataKey="pnl" radius={[3, 3, 0, 0]}>
              {mockHourlyPnL.map((entry, idx) => (
                <Cell
                  key={idx}
                  fill={
                    entry.pnl >= 0
                      ? "var(--profit-positive)"
                      : "var(--profit-negative)"
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <button
        onClick={() => navigate("trade-explorer")}
        className="w-full py-3 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors flex items-center justify-center gap-2 td-press"
        aria-label="مشاهده‌ی معاملات خام"
      >
        مشاهده‌ی معاملات خام
        <ArrowLeft size={14} className="td-flip-rtl" />
      </button>
    </div>
  );
}
