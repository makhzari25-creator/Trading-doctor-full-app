/**
 * Trading Doctor — کاوش معاملات View
 * Aggregate stats, filter/sort, desktop table + mobile cards,
 * pagination, CSV export, and a detail drawer.
 */

"use client";

import { useMemo, useState, type ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { StatCard } from "@/components/td/stat-card";
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription,
} from "@/components/ui/drawer";
import { mockTrades } from "@/lib/mock-data";
import type { Trade } from "@/lib/types";
import { toPersianNumerals, formatCurrency } from "@/lib/utils";
import { Funnel, ArrowLeft, ArrowRight, DownloadSimple } from "@phosphor-icons/react";

const PAGE_SIZE = 20;
const PAGE_BTN = "p-2 rounded-lg border border-border disabled:opacity-40 hover:bg-accent transition-colors td-press";
type SideFilter = "all" | "Long" | "Short";
type OutcomeFilter = "all" | "win" | "loss";
type SortKey = "date" | "profit" | "size";

const sideColor = (t: Trade) =>
  t.side === "Long" ? "var(--profit-positive)" : "var(--profit-negative)";
const pnlColor = (v: number) =>
  v >= 0 ? "var(--profit-positive)" : "var(--profit-negative)";

function Chip({ active, onClick, children, label }: {
  active: boolean; onClick: () => void; children: ReactNode; label: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors td-press ${
        active
          ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
          : "bg-accent text-muted-foreground hover:bg-accent/70"
      }`}
    >
      {children}
    </button>
  );
}

export function TradeExplorerView() {
  const [side, setSide] = useState<SideFilter>("all");
  const [outcome, setOutcome] = useState<OutcomeFilter>("all");
  const [sort, setSort] = useState<SortKey>("date");
  const [page, setPage] = useState(1);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const list = mockTrades.filter((t) => {
      if (side !== "all" && t.side !== side) return false;
      if (outcome === "win" && t.profit <= 0) return false;
      if (outcome === "loss" && t.profit >= 0) return false;
      return true;
    });
    return [...list].sort((a, b) =>
      sort === "date" ? b.id - a.id : sort === "profit" ? b.profit - a.profit : b.size - a.size
    );
  }, [side, outcome, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const totalPnL = filtered.reduce((s, t) => s + t.profit, 0);
  const winCount = filtered.filter((t) => t.profit > 0).length;
  const winRate = filtered.length ? (winCount / filtered.length) * 100 : 0;
  const maxWin = filtered.length ? Math.max(...filtered.map((t) => t.profit)) : 0;
  const selectedTrade = selectedId ? mockTrades.find((t) => t.id === selectedId) ?? null : null;

  const exportCSV = () => {
    const rows = filtered
      .map((t) => `${t.id},${t.open_time},${t.side},${t.size},${t.profit},${t.hour},${t.weekday},${t.date}`)
      .join("\n");
    const blob = new Blob(["id,open_time,side,size,profit,hour,weekday,date\n" + rows], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trades_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const reset = (fn: () => void) => () => { fn(); setPage(1); };
  const openTrade = (id: number) => () => setSelectedId(id);

  return (
    <div className="space-y-4 fade-up">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold mb-1">کاوش معاملات</h1>
          <p className="text-sm text-muted-foreground">معاملات خام را نشانم بده</p>
        </div>
        <button
          onClick={exportCSV}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-xs font-medium hover:bg-accent transition-colors td-press"
          aria-label="خروجی CSV"
        >
          <DownloadSimple size={14} />
          <span className="hidden sm:inline">خروجی CSV</span>
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <StatCard label="تعداد معاملات" value={toPersianNumerals(filtered.length)} />
        <StatCard label="کل سود/زیان" value={formatCurrency(totalPnL)} trend={totalPnL >= 0 ? "up" : "down"} />
        <StatCard label="وین‌ریت" value={`${toPersianNumerals(winRate.toFixed(1))}٪`} />
        <StatCard label="بیشترین سود" value={formatCurrency(maxWin)} trend="up" />
      </div>

      <Card className="p-3">
        <div className="flex flex-wrap items-center gap-2">
          <Funnel size={14} className="text-muted-foreground" />
          <span className="text-xs text-muted-foreground">سمت:</span>
          {([["all", "همه"], ["Long", "Long"], ["Short", "Short"]] as const).map(([v, lbl]) => (
            <Chip key={v} label={`فقط ${lbl}`} active={side === v} onClick={reset(() => setSide(v))}>{lbl}</Chip>
          ))}
          <div className="w-px h-5 bg-border mx-1" />
          <span className="text-xs text-muted-foreground">نتیجه:</span>
          {([["all", "همه"], ["win", "سود"], ["loss", "زیان"]] as const).map(([v, lbl]) => (
            <Chip key={v} label={`فقط ${lbl}`} active={outcome === v} onClick={reset(() => setOutcome(v))}>{lbl}</Chip>
          ))}
          <div className="w-px h-5 bg-border mx-1" />
          <span className="text-xs text-muted-foreground">مرتب‌سازی:</span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="px-2 py-1.5 rounded-lg bg-accent text-xs border border-border"
            aria-label="مرتب‌سازی بر اساس"
          >
            <option value="date">تاریخ</option>
            <option value="profit">سود</option>
            <option value="size">حجم</option>
          </select>
        </div>
      </Card>

      <Card className="hidden md:block overflow-hidden">
        <div className="overflow-auto max-h-[60vh]">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-card z-10">
              <tr className="border-b border-border text-xs text-muted-foreground">
                {["#", "زمان باز کردن", "سمت", "حجم", "سود/زیان", "ساعت", "روز"].map((h) => (
                  <th key={h} className="text-start p-2 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pageItems.map((t) => (
                <tr
                  key={t.id}
                  className="border-b border-border/50 cursor-pointer hover:bg-accent/40 transition-colors"
                  onClick={openTrade(t.id)}
                >
                  <td className="p-2 td-mono text-xs text-muted-foreground">{toPersianNumerals(t.id)}</td>
                  <td className="p-2 td-mono text-xs">{t.open_time}</td>
                  <td className="p-2 text-xs" style={{ color: sideColor(t) }}>{t.side}</td>
                  <td className="p-2 td-mono text-xs">{toPersianNumerals(t.size.toFixed(2))}</td>
                  <td className="p-2 td-mono text-xs font-semibold" style={{ color: pnlColor(t.profit) }}>
                    {formatCurrency(t.profit)}
                  </td>
                  <td className="p-2 td-mono text-xs">{toPersianNumerals(t.hour)}:۰۰</td>
                  <td className="p-2 text-xs">{t.weekday}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="md:hidden space-y-2">
        {pageItems.map((t) => (
          <Card
            key={t.id}
            className="p-3 cursor-pointer td-card-hover td-press"
            onClick={openTrade(t.id)}
            role="button"
            tabIndex={0}
            aria-label={`معامله شماره ${t.id}`}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setSelectedId(t.id))}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground td-mono">#{toPersianNumerals(t.id)}</span>
              <span style={{ color: sideColor(t) }} className="text-xs">{t.side}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{t.open_time}</span>
              <span className="td-mono text-sm font-bold" style={{ color: pnlColor(t.profit) }}>
                {formatCurrency(t.profit)}
              </span>
            </div>
          </Card>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          صفحه‌ی {toPersianNumerals(safePage)} از {toPersianNumerals(totalPages)} · {toPersianNumerals(filtered.length)} معامله
        </span>
        <div className="flex items-center gap-2">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={safePage === 1} className={PAGE_BTN} aria-label="صفحه‌ی قبل">
            <ArrowRight size={14} className="td-flip-rtl" />
          </button>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={safePage === totalPages} className={PAGE_BTN} aria-label="صفحه‌ی بعد">
            <ArrowLeft size={14} className="td-flip-rtl" />
          </button>
        </div>
      </div>

      <Drawer open={selectedTrade !== null} onOpenChange={(o) => !o && setSelectedId(null)}>
        <DrawerContent>
          <DrawerHeader>
            <DrawerTitle>جزئیات معامله #{selectedTrade ? toPersianNumerals(selectedTrade.id) : ""}</DrawerTitle>
            <DrawerDescription>اطلاعات کامل معامله‌ی انتخاب‌شده</DrawerDescription>
          </DrawerHeader>
          {selectedTrade && (
            <div className="px-4 pb-6 space-y-2">
              {([
                ["زمان باز کردن", selectedTrade.open_time],
                ["سمت", selectedTrade.side],
                ["حجم", toPersianNumerals(selectedTrade.size.toFixed(2))],
                ["سود/زیان", formatCurrency(selectedTrade.profit), pnlColor(selectedTrade.profit)],
                ["ساعت", `${toPersianNumerals(selectedTrade.hour)}:۰۰`],
                ["روز هفته", selectedTrade.weekday],
                ["تاریخ", selectedTrade.date],
              ] as const).map(([label, value, color]) => (
                <div key={label} className="flex items-center justify-between p-3 rounded-lg bg-accent/40">
                  <span className="text-sm text-muted-foreground">{label}</span>
                  <span className="td-mono text-sm font-semibold" style={color ? { color } : undefined}>{value}</span>
                </div>
              ))}
            </div>
          )}
        </DrawerContent>
      </Drawer>
    </div>
  );
}
