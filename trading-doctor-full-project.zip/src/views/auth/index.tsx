"use client";
import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Eye, EyeSlash, ArrowLeft, Warning, CheckCircle, Mailbox, Camera, Shield, Clock, Monitor, SignOut, Trash } from "@phosphor-icons/react";
import { useAuthStore } from "@/lib/store/auth-store";
import { useAppStore } from "@/lib/store/app-store";
import { toast } from "sonner";

// Helper: get CSRF token from cookie
function getCsrfToken(): string {
  if (typeof document === "undefined") return "";
  const match = document.cookie.match(/td-csrf=([^;]+)/);
  return match ? match[1] : "";
}

// Helper: fetch with CSRF header
async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const csrfToken = getCsrfToken();
  return fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", "x-csrf-token": csrfToken, ...options.headers },
  });
}

export function LoginView() {
  const navigate = useAppStore((s) => s.navigate);
  const setSession = useAuthStore((s) => s.setSession);
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(""); setIsLoading(true);
    try {
      const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, rememberMe }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error?.message || "ورود ناموفق بود."); return; }
      setSession(data.user, data.sessionToken); toast.success("خوش آمدید!"); navigate("dashboard");
    } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button>
        <Card className="p-6 md:p-8 fade-up">
          <div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div>
          <h1 className="text-xl font-bold text-center mb-1">ورود به حساب</h1>
          <p className="text-sm text-muted-foreground text-center mb-6">وارد حساب Trading Doctor خود شوید</p>
          {error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email" dir="ltr" className="text-left" /></div>
            <div className="space-y-1.5"><Label htmlFor="password">رمز عبور</Label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required autoComplete="current-password" dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "پنهان کردن" : "نمایش"}>{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
            <div className="flex items-center justify-between text-sm"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="w-4 h-4 rounded border-border accent-[var(--primary)]" /><span className="text-muted-foreground">مرا به خاطر بسپار</span></label><button type="button" onClick={() => navigate("forgot-password")} className="text-[var(--primary)] hover:underline">رمز عبور را فراموش کرده‌اید؟</button></div>
            <Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? (<><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> در حال ورود...</>) : ("ورود")}</Button>
          </form>
          <div className="flex items-center gap-3 my-6"><div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">یا</span><div className="flex-1 h-px bg-border" /></div>
          <button type="button" disabled className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-border text-sm text-muted-foreground opacity-50 cursor-not-allowed">ادامه با گوگل (به‌زودی)</button>
          <p className="text-sm text-center text-muted-foreground mt-6">حساب ندارید؟ <button onClick={() => navigate("register")} className="text-[var(--primary)] hover:underline font-medium">ثبت‌نام کنید</button></p>
        </Card>
      </div>
    </div>
  );
}

export function RegisterView() {
  const navigate = useAppStore((s) => s.navigate);
  const setSession = useAuthStore((s) => s.setSession);
  const [name, setName] = useState(""); const [email, setEmail] = useState("");
  const [password, setPassword] = useState(""); const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); const [acceptTerms, setAcceptTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError("");
    if (password !== confirmPassword) { setError("رمز عبور و تکرار آن یکسان نیستند."); return; }
    if (!acceptTerms) { setError("پذیرش قوانین الزامی است."); return; }
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, name }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error?.message || "ثبت‌نام ناموفق بود."); return; }
      const loginRes = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, rememberMe: true }) });
      const loginData = await loginRes.json();
      if (loginRes.ok) { setSession(loginData.user, loginData.sessionToken); toast.success("ثبت‌نام موفق بود!"); navigate("dashboard"); }
      else { toast.success("ثبت‌نام موفق بود. وارد شوید."); navigate("login"); }
    } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button>
        <Card className="p-6 md:p-8 fade-up">
          <div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div>
          <h1 className="text-xl font-bold text-center mb-1">ساخت حساب جدید</h1>
          <p className="text-sm text-muted-foreground text-center mb-6">تحلیل رفتاری معاملات خود را شروع کنید</p>
          {error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="name">نام (اختیاری)</Label><Input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="نام شما" /></div>
            <div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" className="text-left" /></div>
            <div className="space-y-1.5"><Label htmlFor="password">رمز عبور</Label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" required dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="نمایش/پنهان">{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
            <div className="space-y-1.5"><Label htmlFor="confirmPassword">تکرار رمز عبور</Label><Input id="confirmPassword" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="تکرار رمز" required dir="ltr" className="text-left" /></div>
            <label className="flex items-start gap-2 cursor-pointer text-sm"><input type="checkbox" checked={acceptTerms} onChange={(e) => setAcceptTerms(e.target.checked)} className="w-4 h-4 rounded border-border accent-[var(--primary)] mt-0.5" /><span className="text-muted-foreground">قوانین و مقررات را می‌پذیرم</span></label>
            <Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? (<><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> در حال ثبت‌نام...</>) : ("ثبت‌نام")}</Button>
          </form>
          <p className="text-sm text-center text-muted-foreground mt-6">حساب دارید؟ <button onClick={() => navigate("login")} className="text-[var(--primary)] hover:underline font-medium">وارد شوید</button></p>
        </Card>
      </div>
    </div>
  );
}

export function ForgotPasswordView() {
  const navigate = useAppStore((s) => s.navigate);
  const [email, setEmail] = useState(""); const [isLoading, setIsLoading] = useState(false);
  const [sent, setSent] = useState(false); const [resetToken, setResetToken] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setIsLoading(true);
    try { const res = await fetch("/api/auth/forgot-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) }); const data = await res.json(); if (res.ok) { setSent(true); if (data.resetToken) setResetToken(data.resetToken); } } catch { setSent(true); } finally { setIsLoading(false); }
  };

  if (sent) return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><Mailbox size={32} className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">ایمیل ارسال شد</h1><p className="text-sm text-muted-foreground mb-4">اگر این ایمیل ثبت شده باشد، لینک بازنشانی ارسال شده است.</p>{resetToken && (<div className="bg-accent/30 rounded-lg p-3 mb-4 text-left"><p className="text-xs text-muted-foreground mb-1">توکن بازنشانی (حالت توسعه):</p><code className="text-xs td-mono break-all">{resetToken}</code><button onClick={() => navigate("reset-password")} className="block w-full mt-2 text-xs text-[var(--primary)] hover:underline">استفاده از توکن →</button></div>)}<button onClick={() => navigate("login")} className="text-sm text-[var(--primary)] hover:underline">بازگشت به ورود</button></Card></div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("login")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به ورود</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">بازنشانی رمز عبور</h1><p className="text-sm text-muted-foreground text-center mb-6">ایمیل خود را وارد کنید</p><form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" className="text-left" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال ارسال..." : "ارسال لینک بازنشانی"}</Button></form></Card></div></div>
  );
}

export function ResetPasswordView() {
  const navigate = useAppStore((s) => s.navigate);
  const [token, setToken] = useState(""); const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState(""); const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState(""); const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError("");
    if (newPassword !== confirmPassword) { setError("رمزها یکسان نیستند."); return; }
    if (newPassword.length < 8) { setError("رمز باید حداقل ۸ کاراکتر باشد."); return; }
    setIsLoading(true);
    try { const res = await fetch("/api/auth/reset-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, newPassword }) }); const data = await res.json(); if (!res.ok) { setError(data.error?.message || "بازنشانی ناموفق بود."); return; } setSuccess(true); toast.success("رمز عبور تغییر کرد."); } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  if (success) return (<div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><CheckCircle size={32} weight="fill" className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">رمز عبور تغییر کرد</h1><p className="text-sm text-muted-foreground mb-6">لطفاً با رمز جدید وارد شوید.</p><Button onClick={() => navigate("login")} className="bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90">ورود به حساب</Button></Card></div>);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("login")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به ورود</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">رمز عبور جدید</h1>{error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}<form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="token">توکن بازنشانی</Label><Input id="token" type="text" value={token} onChange={(e) => setToken(e.target.value)} placeholder="توکن" required dir="ltr" className="text-left text-sm" /></div><div className="space-y-1.5"><Label htmlFor="newPassword">رمز عبور جدید</Label><div className="relative"><Input id="newPassword" type={showPassword ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" required dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div><div className="space-y-1.5"><Label htmlFor="confirmPassword">تکرار رمز</Label><Input id="confirmPassword" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="تکرار" required dir="ltr" className="text-left" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال تغییر..." : "تغییر رمز عبور"}</Button></form></Card></div></div>
  );
}

export function VerifyEmailView() {
  const navigate = useAppStore((s) => s.navigate);
  const [token, setToken] = useState(""); const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(""); const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(""); setIsLoading(true);
    try { const res = await fetch("/api/auth/verify-email", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }) }); const data = await res.json(); if (!res.ok) { setError(data.error?.message || "تأیید ناموفق بود."); return; } setSuccess(true); } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  if (success) return (<div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><CheckCircle size={32} weight="fill" className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">ایمیل تأیید شد</h1><Button onClick={() => navigate("login")} className="bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90">ورود به حساب</Button></Card></div>);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">تأیید ایمیل</h1>{error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}<form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="token">توکن تأیید</Label><Input id="token" type="text" value={token} onChange={(e) => setToken(e.target.value)} placeholder="توکن" required dir="ltr" className="text-left text-sm" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال تأیید..." : "تأیید ایمیل"}</Button></form></Card></div></div>
  );
}

export function ProfileView() {
  const navigate = useAppStore((s) => s.navigate);
  const { user, logout, sessionToken, setUser } = useAuthStore();
  const [name, setName] = useState(user?.name || "");
  const [isSaving, setIsSaving] = useState(false);
  const [currentPassword, setCurrentPassword] = useState(""); const [newPassword, setNewPassword] = useState("");
  const [confirmNew, setConfirmNew] = useState(""); const [showPw, setShowPw] = useState(false); const [isChangingPw, setIsChangingPw] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (user) setName(user.name || ""); }, [user]);

  if (!user) { navigate("login"); return null; }

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const res = await authFetch("/api/auth/profile", { method: "PUT", body: JSON.stringify({ name }) });
      if (res.ok) { toast.success("پروفایل ذخیره شد"); setUser({ ...user, name }); }
      else toast.error("ذخیره ناموفق بود");
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsSaving(false); }
  };

  const handleChangePw = async () => {
    if (newPassword !== confirmNew) { toast.error("رمزهای جدید یکسان نیستند"); return; }
    if (newPassword.length < 8) { toast.error("رمز باید حداقل ۸ کاراکتر باشد"); return; }
    setIsChangingPw(true);
    try {
      const res = await authFetch("/api/auth/profile", { method: "PATCH", body: JSON.stringify({ currentPassword, newPassword }) });
      const data = await res.json();
      if (res.ok) { toast.success("رمز تغییر کرد. لطفاً دوباره وارد شوید."); logout(); navigate("login"); }
      else toast.error(data.error?.message || "ناموفق");
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsChangingPw(false); }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) { toast.error("حجم تصویر نباید بیش از ۵۰۰ کیلوبایت باشد"); return; }
    setIsUploadingAvatar(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const res = await authFetch("/api/auth/avatar", { method: "POST", body: JSON.stringify({ image: base64 }) });
        if (res.ok) { const data = await res.json(); setUser({ ...user, image: data.image }); toast.success("تصویر به‌روزرسانی شد"); }
        else { const d = await res.json(); toast.error(d.error?.message || "آپلود ناموفق بود"); }
        setIsUploadingAvatar(false);
      };
      reader.readAsDataURL(file);
    } catch { toast.error("خطا در آپلود"); setIsUploadingAvatar(false); }
  };

  const handleResendVerification = async () => {
    setIsResending(true);
    try {
      const res = await fetch("/api/auth/resend-verification", { method: "POST" });
      const data = await res.json();
      if (res.ok) toast.success(data.message);
      else toast.error(data.error?.message || "ارسال ناموفق بود");
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsResending(false); }
  };

  const handleLogout = async () => {
    try { await fetch("/api/auth/logout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionToken }) }); } catch {}
    logout(); navigate("landing"); toast.success("خروج موفق بود");
  };

  return (
    <div className="space-y-4 fade-up max-w-2xl">
      <div><h1 className="text-2xl font-bold mb-1">پروفایل</h1><p className="text-sm text-muted-foreground">مدیریت حساب کاربری</p></div>

      {/* Profile Info with Avatar */}
      <Card className="p-4">
        <div className="flex items-center gap-4 mb-6">
          <div className="relative">
            {user.image ? (
              <img src={user.image} alt="avatar" className="w-20 h-20 rounded-full object-cover" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-[var(--primary)]/10 flex items-center justify-center text-2xl font-bold text-[var(--primary)]">
                {user.name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
              </div>
            )}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingAvatar}
              className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[var(--primary)] text-white flex items-center justify-center hover:opacity-90 transition-opacity disabled:opacity-50"
              aria-label="تغییر عکس پروفایل"
            >
              {isUploadingAvatar ? <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Camera size={14} />}
            </button>
            <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={handleAvatarUpload} className="hidden" />
          </div>
          <div className="flex-1">
            <div className="font-medium">{user.name || "بدون نام"}</div>
            <div className="text-sm text-muted-foreground">{user.email}</div>
            {user.emailVerified ? (
              <div className="flex items-center gap-1 text-xs text-[var(--severity-low)] mt-1"><CheckCircle size={12} weight="fill" /> ایمیل تأیید شده</div>
            ) : (
              <div className="flex items-center gap-2 mt-1">
                <span className="flex items-center gap-1 text-xs text-[var(--severity-medium)]"><Warning size={12} weight="fill" /> تأیید نشده</span>
                <button onClick={handleResendVerification} disabled={isResending} className="text-xs text-[var(--primary)] hover:underline disabled:opacity-50">
                  {isResending ? "در حال ارسال..." : "ارسال مجدد"}
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-1.5 mb-4"><Label htmlFor="name">نام</Label><Input id="name" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1.5 mb-4"><Label>ایمیل</Label><Input value={user.email} disabled dir="ltr" className="text-left opacity-60" /></div>
        <div className="flex gap-2">
          <Button onClick={handleSave} disabled={isSaving} className="bg-[var(--primary)] text-white hover:opacity-90">{isSaving ? "در حال ذخیره..." : "ذخیره تغییرات"}</Button>
          <Button onClick={() => navigate("security")} variant="outline" className="border-[var(--primary)] text-[var(--primary)] hover:bg-[var(--primary)]/10">
            <Shield size={14} className="ml-1" /> امنیت حساب
          </Button>
        </div>
      </Card>

      {/* Password Change */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-4">تغییر رمز عبور</h3>
        <div className="space-y-3">
          <div className="space-y-1.5"><Label>رمز فعلی</Label><div className="relative"><Input type={showPw ? "text" : "password"} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="رمز فعلی" dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showPw ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
          <div className="space-y-1.5"><Label>رمز جدید</Label><Input type={showPw ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" dir="ltr" className="text-left" /></div>
          <div className="space-y-1.5"><Label>تکرار رمز جدید</Label><Input type={showPw ? "text" : "password"} value={confirmNew} onChange={(e) => setConfirmNew(e.target.value)} placeholder="تکرار" dir="ltr" className="text-left" /></div>
          <Button onClick={handleChangePw} disabled={isChangingPw || !currentPassword || !newPassword} variant="outline" className="border-[var(--primary)] text-[var(--primary)] hover:bg-[var(--primary)]/10">{isChangingPw ? "در حال تغییر..." : "تغییر رمز عبور"}</Button>
        </div>
      </Card>

      <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 py-3 rounded-lg border border-[var(--severity-critical)]/30 text-[var(--severity-critical)] text-sm font-medium hover:bg-[var(--severity-critical)]/10 transition-colors">
        <SignOut size={16} /> خروج از حساب
      </button>
    </div>
  );
}

export function SecurityView() {
  const navigate = useAppStore((s) => s.navigate);
  const { user } = useAuthStore();
  const [sessions, setSessions] = useState<Array<{ id: string; sessionToken: string; expires: string; createdAt: string; ip: string | null; userAgent: string | null; isCurrent: boolean }>>([]);
  const [loginEvents, setLoginEvents] = useState<Array<{ id: string; ip: string; userAgent: string | null; success: boolean; reason: string | null; createdAt: string }>>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("login"); return; }
    Promise.all([
      fetch("/api/auth/sessions").then(r => r.json()),
      fetch("/api/auth/login-history").then(r => r.json()),
    ]).then(([sessionsData, eventsData]) => {
      setSessions(sessionsData.sessions || []);
      setLoginEvents(eventsData.events || []);
      setIsLoading(false);
    }).catch(() => setIsLoading(false));
  }, [user, navigate]);

  if (!user) return null;

  const handleRevokeSession = async (sessionToken: string) => {
    try {
      const res = await authFetch("/api/auth/sessions", { method: "DELETE", body: JSON.stringify({ sessionToken }) });
      if (res.ok) { setSessions(sessions.filter(s => s.sessionToken !== sessionToken)); toast.success("جلسه بسته شد."); }
    } catch { toast.error("خطا در بستن جلسه"); }
  };

  const handleRevokeAllOthers = async () => {
    try {
      const res = await authFetch("/api/auth/sessions", { method: "DELETE", body: JSON.stringify({ sessionToken: "all-others" }) });
      if (res.ok) { setSessions(sessions.filter(s => s.isCurrent)); toast.success("تمام جلسات دیگر بسته شدند."); }
    } catch { toast.error("خطا"); }
  };

  const formatDateTime = (iso: string) => {
    try { return new Date(iso).toLocaleString("fa-IR", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
    catch { return iso; }
  };

  const parseUserAgent = (ua: string | null) => {
    if (!ua) return "نامشخص";
    if (ua.includes("Chrome")) return "Chrome";
    if (ua.includes("Firefox")) return "Firefox";
    if (ua.includes("Safari")) return "Safari";
    if (ua.includes("Edge")) return "Edge";
    return "مرورگر دیگر";
  };

  return (
    <div className="space-y-4 fade-up max-w-2xl">
      <div className="flex items-center gap-2">
        <button onClick={() => navigate("profile")} className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت</button>
      </div>
      <div><h1 className="text-2xl font-bold mb-1">امنیت حساب</h1><p className="text-sm text-muted-foreground">جلسات فعال، تاریخچه ورود و تنظیمات امنیتی</p></div>

      {/* Security Status */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Shield size={16} className="text-[var(--primary)]" /> وضعیت امنیتی</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>تأیید ایمیل</span>
            {user.emailVerified ? <span className="text-[var(--severity-low)] text-xs font-medium flex items-center gap-1"><CheckCircle size={12} /> تأیید شده</span> : <span className="text-[var(--severity-medium)] text-xs">تأیید نشده</span>}
          </div>
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>احراز هویت دو مرحله‌ای</span>
            <span className="text-xs text-muted-foreground px-1.5 py-0.5 rounded bg-accent">به‌زودی</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>رمز عبور</span>
            <span className="text-xs text-[var(--severity-low)] flex items-center gap-1"><CheckCircle size={12} /> تنظیم شده</span>
          </div>
        </div>
      </Card>

      {/* Active Sessions */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-2"><Monitor size={16} className="text-[var(--primary)]" /> جلسات فعال</h3>
          {sessions.length > 1 && <button onClick={handleRevokeAllOthers} className="text-xs text-[var(--severity-critical)] hover:underline">بستن همه‌ی جلسات دیگر</button>}
        </div>
        {isLoading ? (
          <div className="space-y-2">{[1, 2].map(i => <div key={i} className="h-12 rounded-lg bg-accent/30 skeleton-pulse" />)}</div>
        ) : sessions.length === 0 ? (
          <p className="text-sm text-muted-foreground">جلسه‌ای یافت نشد.</p>
        ) : (
          <div className="space-y-2">
            {sessions.map(s => (
              <div key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/30">
                <div className="flex items-center gap-3">
                  <Monitor size={18} className="text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">{parseUserAgent(s.userAgent)} {s.isCurrent && <span className="text-xs text-[var(--severity-low)] mr-1">(فعلی)</span>}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-2">
                      <span>{s.ip || "نامشخص"}</span>
                      <span>·</span>
                      <span>{formatDateTime(s.createdAt)}</span>
                    </div>
                  </div>
                </div>
                {!s.isCurrent && <button onClick={() => handleRevokeSession(s.sessionToken)} className="p-1.5 rounded hover:bg-[var(--severity-critical)]/10 text-[var(--severity-critical)]" aria-label="بستن جلسه"><Trash size={14} /></button>}
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Login History */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Clock size={16} className="text-[var(--primary)]" /> تاریخچه ورود</h3>
        {isLoading ? (
          <div className="space-y-2">{[1, 2, 3].map(i => <div key={i} className="h-10 rounded-lg bg-accent/30 skeleton-pulse" />)}</div>
        ) : loginEvents.length === 0 ? (
          <p className="text-sm text-muted-foreground">رویدادی ثبت نشده است.</p>
        ) : (
          <div className="space-y-1.5">
            {loginEvents.map(e => (
              <div key={e.id} className="flex items-center justify-between p-2 rounded-lg text-sm">
                <div className="flex items-center gap-2">
                  {e.success ? <CheckCircle size={14} className="text-[var(--severity-low)]" /> : <Warning size={14} className="text-[var(--severity-critical)]" />}
                  <span className="text-muted-foreground">{e.ip || "نامشخص"}</span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs">{parseUserAgent(e.userAgent)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${e.success ? "text-[var(--severity-low)]" : "text-[var(--severity-critical)]"}`}>{e.success ? "موفق" : "ناموفق"}</span>
                  <span className="text-xs text-muted-foreground">{formatDateTime(e.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
