/**
 * Trading Doctor — Upload View (Page 2 — Full Implementation)
 *
 * Entry flow: file selection → validation → LLM provider selection → analysis.
 * Includes the Analysis Progress flow as an in-view state transition.
 *
 * Phase 4 §5 (CSV Upload) + §6 (Analysis Progress).
 *
 * @phase Phase 1 build
 * @engine-dependency POST /api/v1/uploads, POST /api/v1/analyses
 */

"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Card } from "@/components/ui/card";
import {
  UploadSimple,
  Info,
  Play,
  X,
  CaretDown,
  Gear,
  Timer,
  Warning,
  Check,
} from "@phosphor-icons/react";
import { toast } from "sonner";
import { useAppStore } from "@/lib/store/app-store";
import type { ViewId } from "@/lib/types";
import {
  ALLOWED_FILE_TYPES,
  MAX_UPLOAD_SIZE_BYTES,
  toPersianNumerals,
} from "@/lib/utils";
import type { LLMProvider } from "@/lib/utils";
import { UploadDropzone } from "@/components/td/upload-dropzone";
import { FilePill } from "@/components/td/file-pill";
import { ProgressStepper, ANALYSIS_STAGES } from "@/components/td/progress-stepper";

/* ============================================================================
   Types
   ============================================================================ */

interface UploadViewProps {
  onViewChange: (view: ViewId) => void;
  onAnalysisComplete: (analysisId: string) => void;
}

type UploadPhase = "select" | "analyzing" | "error";

interface LLMOption {
  value: LLMProvider;
  label: string;
  tooltip: string;
}

/* ============================================================================
   Constants
   ============================================================================ */

const LLM_OPTIONS: LLMOption[] = [
  {
    value: "none",
    label: "بدون AI",
    tooltip: "سریع‌تر (زیر ۱۰ ثانیه)، توضیح الگوریتمی",
  },
  {
    value: "gemini",
    label: "Gemini",
    tooltip: "روایت غنی‌تر، تا ۲۰–۳۰ ثانیه تأخیر",
  },
  {
    value: "openai",
    label: "OpenAI",
    tooltip: "روایت غنی‌تر، تا ۲۰–۳۰ ثانیه تأخیر",
  },
  {
    value: "claude",
    label: "Claude",
    tooltip: "روایت غنی‌تر، تا ۲۰–۳۰ ثانیه تأخیر",
  },
];

const SUPPORTED_FORMATS = [
  { format: "CSV", desc: "خروجی استاندارد اکثر بروکرها (MT4, MT5, Binance, Bybit)" },
  { format: "XLSX/XLS", desc: "فایل اکسل" },
  { format: "HTM/HTML", desc: "گزارش HTML بروکر" },
  { format: "JSON", desc: "فرمت ساختاریافته" },
  { format: "LOG/TXT", desc: "فایل متنی لاگ" },
];

/* ============================================================================
   Component
   ============================================================================ */

export function UploadView({
  onViewChange: _onViewChange,
  onAnalysisComplete,
}: UploadViewProps) {
  const [phase, setPhase] = useState<UploadPhase>("select");
  const [file, setFile] = useState<File | null>(null);
  const [llmProvider, setLlmProvider] = useState<LLMProvider>("none");
  const [showFormats, setShowFormats] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Analyzing state
  const [elapsed, setElapsed] = useState(0);
  const [currentStage, setCurrentStage] = useState(0);
  const [allComplete, setAllComplete] = useState(false);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Smart time estimate based on LLM provider
  const timeEstimate =
    llmProvider === "none"
      ? "معمولاً کمتر از ۱۰ ثانیه طول می‌کشد"
      : "ممکن است تا ۲۰–۳۰ ثانیه طول بکشد";

  // Elapsed counter
  useEffect(() => {
    if (phase === "analyzing") {
      setElapsed(0);
      elapsedTimerRef.current = setInterval(() => {
        setElapsed((prev) => prev + 1);
      }, 1000);
    } else {
      if (elapsedTimerRef.current) {
        clearInterval(elapsedTimerRef.current);
        elapsedTimerRef.current = null;
      }
    }

    return () => {
      if (elapsedTimerRef.current) {
        clearInterval(elapsedTimerRef.current);
      }
    };
  }, [phase]);

  // Check for exceeded estimate
  const estimateSeconds = llmProvider === "none" ? 10 : 30;
  const exceededEstimate = elapsed > estimateSeconds + 5;

  const handleFileSelect = useCallback((selected: File) => {
    setFile(selected);
    setErrorMessage("");
  }, []);

  const handleError = useCallback((message: string) => {
    setErrorMessage(message);
    toast.error(message);
  }, []);

  const handleRemoveFile = () => {
    setFile(null);
    setErrorMessage("");
  };

  const handleAnalyze = () => {
    if (!file) return;

    setPhase("analyzing");
    setCurrentStage(0);
    setAllComplete(false);

    // In production, this calls:
    // 1. uploadFile(file) → upload_id
    // 2. runAnalysis(upload_id, llmProvider) → analysis_id
    //
    // V23's POST /analyses is synchronous — it blocks until done.
    // The 6 stages are conceptual (the API doesn't stream stage progress).
    // We show them with pulsing dots + honest elapsed counter.

    // Simulate analysis with conceptual stage progression
    // (stages are conceptual, not real — per Phase 2 §2.4 honesty note)
    const stageInterval = llmProvider === "none" ? 400 : 1500; // ms per stage

    for (let i = 0; i < ANALYSIS_STAGES.length; i++) {
      setTimeout(() => {
        if (phase === "error") return; // user cancelled
        setCurrentStage(i);
      }, stageInterval * i);
    }

    // Complete after all stages
    const totalDuration =
      stageInterval * ANALYSIS_STAGES.length + (llmProvider === "none" ? 800 : 2000);

    setTimeout(() => {
      setAllComplete(true);
      toast.success("تحلیل کامل شد");

      // Navigate to dashboard after showing success state
      setTimeout(() => {
        onAnalysisComplete("analysis-" + Date.now());
      }, 800);
    }, totalDuration);
  };

  const handleCancel = () => {
    setPhase("select");
    setCurrentStage(0);
    setAllComplete(false);
    setElapsed(0);
    toast.info("تحلیل لغو شد");
  };

  const formatElapsed = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${toPersianNumerals(mins)}:${toPersianNumerals(secs.toString().padStart(2, "0"))}`;
  };

  /* ========================================================================
     Render: Analysis Progress Phase
     ======================================================================== */
  if (phase === "analyzing") {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-2xl mx-auto fade-up">
        {/* Animated indicator */}
        <div className="mb-6">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              backgroundColor:
                "color-mix(in srgb, var(--primary) 15%, transparent)",
              border: "3px solid var(--primary)",
            }}
          >
            <Gear size={28} className="text-[var(--primary)] animate-spin" style={{ animationDuration: "3s" }} />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-xl font-bold mb-1 text-center">
          در حال تحلیل معاملات شما
        </h1>
        <p className="text-sm text-muted-foreground text-center mb-1">
          {file?.name} ·{" "}
          <span className="td-mono">{toPersianNumerals(1245)}</span> معامله
        </p>

        {/* Stage list */}
        <Card className="w-full p-5 mt-4">
          <ProgressStepper
            stages={ANALYSIS_STAGES}
            currentStage={currentStage}
            allComplete={allComplete}
            orientation="vertical"
          />
        </Card>

        {/* Progress bar */}
        <div className="w-full mt-4">
          <div className="h-2 rounded-full bg-accent overflow-hidden">
            <div
              className={`h-full rounded-full bg-[var(--primary)] ${
                allComplete ? "" : "animate-pulse"
              }`}
              style={{
                width: allComplete ? "100%" : "45%",
                transition: "width 0.4s ease",
              }}
            />
          </div>
        </div>

        {/* Time estimate + elapsed */}
        <div className="flex items-center gap-4 mt-4 text-sm">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Timer size={14} />
            <span>{timeEstimate}</span>
          </div>
          <span className="text-muted-foreground">·</span>
          <span className="td-mono text-muted-foreground">
            {formatElapsed(elapsed)} گذشته
          </span>
        </div>

        {/* Soft reassurance (if exceeded estimate) */}
        {exceededEstimate && !allComplete && (
          <p className="text-xs text-muted-foreground mt-2 text-center max-w-sm">
            کمی بیشتر از حد انتظار طول می‌کشد — هنوز در حال تحلیل است
          </p>
        )}

        {/* Cancel button */}
        {!allComplete && (
          <button
            onClick={handleCancel}
            className="mt-6 flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-[var(--severity-critical)] hover:border-[var(--severity-critical)] transition-colors"
          >
            <X size={14} />
            انصراف
          </button>
        )}

        {/* Success state (brief) */}
        {allComplete && (
          <div className="mt-6 flex items-center gap-2 text-[var(--severity-low)] font-medium fade-up">
            <Check size={20} weight="bold" />
            تحلیل کامل شد
          </div>
        )}
      </div>
    );
  }

  /* ========================================================================
     Render: File Selection Phase
     ======================================================================== */
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6 max-w-4xl mx-auto fade-up">
      {/* Left: Upload form (2/3 width on desktop) */}
      <div className="lg:col-span-2 space-y-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">آپلود فایل معاملات</h1>
          <p className="text-sm text-muted-foreground">
            هر فرمت خروجی بروکر را آپلود کنید
          </p>
        </div>

        {/* Dropzone (only shown when no file selected) */}
        {!file && (
          <UploadDropzone
            onFileSelect={handleFileSelect}
            onError={handleError}
            allowedExtensions={ALLOWED_FILE_TYPES}
            maxSizeBytes={MAX_UPLOAD_SIZE_BYTES}
          />
        )}

        {/* Inline error (from validation) */}
        {errorMessage && !file && (
          <div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm">
            <Warning
              size={16}
              weight="fill"
              className="text-[var(--severity-critical)] shrink-0 mt-0.5"
            />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* File Pill (after file selected) */}
        {file && (
          <FilePill
            filename={file.name}
            sizeBytes={file.size}
            onRemove={handleRemoveFile}
          />
        )}

        {/* LLM Provider Selector */}
        <div>
          <label className="text-xs text-muted-foreground mb-2 block">
            ارائه‌دهنده‌ی هوش مصنوعی
          </label>
          <div className="grid grid-cols-4 gap-2">
            {LLM_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setLlmProvider(opt.value)}
                title={opt.tooltip}
                className={`py-2 rounded-lg border text-xs font-medium transition-all ${
                  llmProvider === opt.value
                    ? "border-[var(--primary)] bg-[var(--primary)]/10 text-[var(--primary)]"
                    : "border-border text-muted-foreground hover:bg-accent"
                }`}
                aria-pressed={llmProvider === opt.value}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2 flex items-start gap-1">
            <Info size={12} className="mt-0.5 shrink-0" />
            هوش مصنوعی فقط روایت coaching را غنی‌تر می‌کند. امتیازها و تشخیص‌ها
            همیشه توسط موتور تعیین‌شده می‌شوند.
          </p>
        </div>

        {/* Analyze CTA */}
        <button
          onClick={handleAnalyze}
          disabled={!file}
          className="w-full py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] font-medium hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Play size={16} weight="fill" />
          شروع تحلیل
        </button>

        {/* Help: supported formats */}
        <button
          onClick={() => setShowFormats(!showFormats)}
          className="w-full flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          مشاهده فرمت‌های پشتیبانی‌شده
          <CaretDown
            size={12}
            className={`transition-transform ${showFormats ? "rotate-180" : ""}`}
          />
        </button>

        {showFormats && (
          <Card className="p-3 space-y-2 text-xs fade-up">
            {SUPPORTED_FORMATS.map((f, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="td-mono font-bold text-[var(--primary)] shrink-0 w-20">
                  {f.format}
                </span>
                <span className="text-muted-foreground">{f.desc}</span>
              </div>
            ))}
          </Card>
        )}
      </div>

      {/* Right: Explainer card (1/3 width on desktop, hidden on mobile) */}
      <div className="hidden lg:block">
        <Card className="p-5 sticky top-20">
          <h3 className="text-sm font-semibold mb-3">بعد از آپلود چه می‌شود؟</h3>
          <ol className="space-y-3">
            {[
              {
                step: "۱",
                title: "اعتبارسنجی داده",
                desc: "موتور فایل شما را بررسی و نرمال‌سازی می‌کند",
              },
              {
                step: "۲",
                title: "تحلیل رفتاری",
                desc: "۵ امتیاز رفتاری با تأثیر دلاری محاسبه می‌شود",
              },
              {
                step: "۳",
                title: "تشخیص و برنامه‌ی اقدام",
                desc: "مشکل اصلی + توصیه‌های اولویت‌بندی‌شده",
              },
              {
                step: "۴",
                title: "داشبورد",
                desc: "۴ پاسخ اصلی: وضعیت، نشتی، قوت، گام بعدی",
              },
            ].map((item, i) => (
              <li key={i} className="flex gap-3">
                <span className="shrink-0 w-6 h-6 rounded-full bg-[var(--primary)]/10 text-[var(--primary)] flex items-center justify-center text-xs font-bold td-mono">
                  {item.step}
                </span>
                <div>
                  <div className="text-sm font-medium">{item.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {item.desc}
                  </div>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-4 pt-4 border-t border-border">
            <div className="text-xs text-muted-foreground mb-1">
              نمونه‌ی فرمت CSV:
            </div>
            <div className="bg-accent/30 rounded p-2 td-mono text-[10px] text-muted-foreground leading-relaxed">
              Open Time,Side,Size,Profit
              <br />
              2024-01-15 14:30,Long,0.5,12.50
              <br />
              2024-01-15 15:00,Short,0.3,-8.20
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}


