/**
 * Verify that the required Prisma tables exist in Supabase.
 *
 * Connects via DIRECT_URL (session pooler, port 5432 — supports prepared statements)
 * and queries information_schema.tables.
 *
 * Usage:
 *   DATABASE_URL=... DIRECT_URL=... bun run scripts/verify-supabase-tables.ts
 */

import { PrismaClient } from "@prisma/client";

const REQUIRED_TABLES = [
  "User",
  "Account",
  "Session",
  "VerificationToken",
  "PasswordResetToken",
  "LoginEvent",
];

async function main() {
  const url = process.env.DIRECT_URL || process.env.DATABASE_URL;
  if (!url) {
    console.error("❌ DIRECT_URL (or DATABASE_URL) is not set.");
    process.exit(1);
  }
  console.log(`\n🔌 Connecting to: ${url.replace(/:[^:@]+@/, ":***@")}\n`);

  const prisma = new PrismaClient({
    log: ["error"],
  });

  try {
    // Test connection by running a raw query against information_schema
    const result = await prisma.$queryRaw<
      Array<{ table_name: string }>
    >`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
        AND table_type = 'BASE TABLE'
      ORDER BY table_name;
    `;

    const existingTables = result.map((r) => r.table_name);
    console.log(`📋 Tables found in 'public' schema (${existingTables.length}):`);
    for (const t of existingTables) {
      console.log(`   - ${t}`);
    }
    console.log("");

    console.log("✅ Verifying required tables:");
    let allExist = true;
    for (const required of REQUIRED_TABLES) {
      const exists = existingTables.includes(required);
      const mark = exists ? "✓" : "✗";
      console.log(`   ${mark} ${required}`);
      if (!exists) allExist = false;
    }

    console.log("");
    if (allExist) {
      console.log("🎉 All required tables exist in Supabase.");
      process.exit(0);
    } else {
      console.log("❌ Some required tables are missing.");
      process.exit(1);
    }
  } catch (error) {
    console.error("❌ Failed to query Supabase:");
    console.error(error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
