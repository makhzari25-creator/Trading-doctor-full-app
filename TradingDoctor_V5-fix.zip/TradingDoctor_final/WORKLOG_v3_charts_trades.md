# گزارش کار — اتصال کامل Charts و Trade Explorer (v3)

> تاریخ: ۲۰۲۶-۰۷-۲۰
> ورودی: `TradingDoctor_V23_fixed_v2.zip`
> خروجی: `TradingDoctor_V23_fixed_v3.zip`

## خلاصه‌ی اجرایی

آخرین دو صفحه‌ای که از داده‌ی mock استفاده می‌کردند (`views/charts.tsx` و
`views/trade-explorer.tsx`) به‌صورت کامل به بک‌اند واقعی وصل شدند. فایل
`frontend/src/lib/mock-data.ts` به‌طور کامل حذف شد.

### نتیجه‌ی تست‌ها (هر سه لایه پاس شد)

| لایه | نتیجه | زمان |
|---|---|---|
| Backend `pytest tests/` | ✅ **۲۴۱ تست پاس** (۲۳۴ اصلی + ۷ تست جدید) | ۷۱ ثانیه |
| Frontend `vitest run` | ✅ **۱۲ تست پاس** | ۳ ثانیه |
| Frontend `next build` | ✅ موفق — ۲۷ route (شامل `/analyses/[id]/trades` جدید) | ۱۱ ثانیه |
| Frontend `npm run lint` | ✅ ۰ خطا، ۱۱۰ هشدار | — |

---

## ۱. Backend — `reporting/chart_data.py` (فایل جدید)

یک ماژول جدید برای استخراج سری‌های JSON-serializable از همان DataFrame خام
معاملات (`doctor.df`) که موتور V23 روی آن اجرا شده.

**اصل طراحی حیاتی:** هیچ محاسبه‌ی تحلیلی جدیدی انجام نمی‌شود. فقط همان
فرمول‌های presentación که در `reporting/charts.py` (PNG) وجود دارند، به‌صورت
JSON بازتولید می‌شوند. پس اعداد نمودارها هرگز نمی‌توانند با اعداد گزارش
PDF/HTML مغایرت داشته باشند.

| تابع | فرمول | خروجی |
|---|---|---|
| `extract_equity_curve(df)` | `Profit.cumsum()` | `[{trade, equity}, ...]` |
| `extract_drawdown(df)` | `equity - equity.cummax()` | `[{trade, drawdown}, ...]` |
| `extract_pnl_distribution(df)` | `np.histogram(profit, bins=N)` | `[{range, count, type, bin_left, bin_right}, ...]` |
| `extract_hourly_pnl(df)` | `groupby(Profit, hour=OpenTime.dt.hour)` | 24 رکورد `[{hour, pnl}, ...]` |
| `extract_weekday_pnl(df)` | `groupby(Profit, weekday=OpenTime.dt.day_name())` | 7 رکورد `[{weekday, pnl}, ...]` |
| `extract_win_loss_pie(df)` | counts of `Profit > 0 / < 0 / == 0` | `{wins, losses, breakeven, total}` |
| `build_chart_series(df)` | ترکیب همه‌ی بالا | `ChartSeries` dict |
| `extract_trades_list(df, page, page_size, side, outcome)` | فیلتر + pagination | `{trades, total, page, page_size}` |

توابع کمکی `_safe_int/_safe_float/_safe_str/_derive_side` برای تبدیل امن NaN/None
به JSON-serializable values استفاده می‌شوند.

---

## ۲. Backend — `api/routers/analyses.py` (تغییر)

### ۲.۱ — endpoint `/analyses/{id}/report`

```python
# قبل (v2):
ctx.pop("charts", None)
return AnalysisReport(**ctx)

# بعد (v3):
df = getattr(doctor, "df", None)
ctx["charts"] = await run_in_threadpool(build_chart_series, df)
return AnalysisReport(**ctx)
```

### ۲.۲ — endpoint جدید `/analyses/{id}/trades`

```python
@router.get("/analyses/{analysis_id}/trades", response_model=TradesResponse)
async def get_analysis_trades(
    analysis_id: str,
    page: int = 1,
    page_size: int = 50,
    side: str | None = None,        # "Long" | "Short" | None
    outcome: str | None = None,     # "win" | "loss" | None
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TradesResponse:
    # ... validate filters, load doctor.df, call extract_trades_list
```

ویژگی‌ها:
- pagination با page_size حداکثر 500
- فیلتر side (Long/Short) و outcome (win/loss) به‌صورت query param
- multi-tenant isolation (User A نمی‌تواند trades کاربر B را بخواند)
- احراز هویت با JWT (همان `get_current_user` که سایر endpoints استفاده می‌کنند)

---

## ۳. Backend — `api/models/analysis.py` (تغییر)

- `AnalysisReport.charts: Dict[str, Any] = Field(default_factory=dict)` اضافه شد.
- مدل جدید `TradesResponse` برای endpoint trades.

---

## ۴. Backend — `api/exceptions.py` (تغییر)

- `ValidationError(APIError)` با `status_code=422` اضافه شد برای فیلترهای نامعتبر.

---

## ۵. Backend — `conftest.py` (فایل جدید)

rate-limit را برای کل session تست غیرفعال می‌کند. مشکل قبلی این بود که
rate-limiter یک module-level SlidingWindowRateLimiter است که بین همه‌ی تست‌ها
به اشتراک گذاشته می‌شود؛ تست‌های جدید v3 مسیرهای اضافی ایجاد می‌کردند و
شمارنده را زودتر پر می‌کردند، که باعث 429 های کاذب در تست‌های نامرتبط
(مثلاً `test_phase10_billing::test_usage_endpoint`) می‌شد.

```python
os.environ.setdefault("TRADING_DOCTOR_API_RATE_LIMIT_ENABLED", "false")
# + monkeypatch در scope=session
```

تست‌هایی که به‌طور صریح rate-limit را بررسی می‌کنند (`test_rate_limit_enforced`)
آن را به‌صورت local با `monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", True)`
فعال می‌کنند.

---

## ۶. Backend — تست‌های جدید (`tests/test_api.py`)

۷ تست جدید (همه پاس شدند):

1. `test_report_includes_charts_field` — فیلد `charts` در report موجود است و ۶
   سری با ساختار درست دارد (equity_curve, drawdown, pnl_distribution,
   hourly_pnl, weekday_pnl, win_loss_pie). 100 معامله → 100 نقطه‌ی equity.

2. `test_trades_endpoint_returns_paginated_list` — pagination صحیح، total = 100،
   page 5 با page_size=20 → 20 trade با id از 81، page 6 → خالی.

3. `test_trades_endpoint_filters_by_side` — `?side=Long` فقط Long برمی‌گرداند،
   `?side=Short` فقط Short، و مجموع برابر با 100 (بدون breakeven side).

4. `test_trades_endpoint_filters_by_outcome` — `?outcome=win` فقط profit > 0،
   `?outcome=loss` فقط profit < 0، مجموع = 100.

5. `test_trades_endpoint_rejects_invalid_side` — `?side=Invalid` → 422 با
   `error.code = "validation_error"`.

6. `test_trades_endpoint_requires_auth` — بدون Authorization header → 401.

7. `test_trades_endpoint_respects_multi_tenant_isolation` — user A یک تحلیل
   می‌سازد، user B سعی می‌کند trades او را بخواند → 404 (نه 403، تا اطلاعات
   وجود تحلیل لو نرود).

---

## ۷. Frontend — حذف کامل mock-data

فایل `frontend/src/lib/mock-data.ts` به‌طور کامل حذف شد. این فایل قبلاً شامل:
- `mockAnalysisReport` (یک AnalysisReport کامل با داده‌ی نمونه)
- `mockTrades` (آرایه‌ای از Trade)
- `mockHistory` (آرایه‌ای از HistoryItem)
- `mockEquityCurve`, `mockDrawdown`, `mockPnLDistribution`, `mockHourlyPnL`

هیچ فایل دیگری از این ماژول import نمی‌کند (تأیید با `grep -rn "mock-data"`
قبل از حذف).

---

## ۸. Frontend — `views/charts.tsx` (بازنویسی کامل)

**قبل (v2):**
```tsx
import { mockEquityCurve, mockDrawdown, mockPnLDistribution, mockHourlyPnL } from "@/lib/mock-data";
import { DemoDataBanner } from "@/components/td/demo-data-banner";
// ... 4 نمودار با داده‌ی mock + بنر هشدار
```

**بعد (v3):**
```tsx
const { data: r } = useAnalysisReport();
const charts = r.charts ?? { equity_curve: [], ... };  // defensive
// ... 4 نمودار با داده‌ی واقعی از r.charts
```

تغییرات کلیدی:
- حذف کامل import از mock-data.
- حذف کامپوننت `DemoDataBanner` (دیگر نیازی نیست — داده واقعی است).
- هر نمودار حالا حالت empty-state دارد (اگر داده‌ای نباشد، پیام "داده‌ای
  برای نمایش موجود نیست" نمایش داده می‌شود).
- Tooltipها با formatter فارسی برای مقادیر و labels.
- `isAnimationActive={false}` برای جلوگیری از re-renderهای اضافی هنگام
  مرور بین صفحات.
- Defensive access: `r.charts ?? {empty}` برای backward-compat با cache قدیمی.

---

## ۹. Frontend — `views/trade-explorer.tsx` (بازنویسی کامل)

**قبل (v2):**
```tsx
import { mockTrades } from "@/lib/mock-data";
import { DemoDataBanner } from "@/components/td/demo-data-banner";
// ... جدول دستی با pagination ساده روی mockTrades
```

**بعد (v3):**
```tsx
import { useReactTable, getCoreRowModel, getFilteredRowModel, getSortedRowModel, getPaginationRowModel } from "@tanstack/react-table";
import { useTrades } from "@/lib/hooks/use-trades";
// ... جدول واقعی با @tanstack/react-table روی داده‌ی واقعی
```

ویژگی‌های جدول جدید:
- **`@tanstack/react-table`** (که قبلاً در `package.json` بود ولی استفاده نمی‌شد)
  با `useReactTable` و چهار row model: `getCoreRowModel`, `getFilteredRowModel`,
  `getSortedRowModel`, `getPaginationRowModel`.
- تعریف `COLUMNS: ColumnDef<Trade>[]` با `accessorKey` و `cell` formatter برای
  رنگ (سمت/سود-زیان) و اعداد فارسی.
- کلیک روی row → باز شدن Drawer با جزئیات معامله.
- فیلتر side/outcome در state محلی انجام می‌شود (روی صفحه‌ی 200تایی از سرور)
  تا chip toggleها بدون round-trip به سرور feel instantaneous داشته باشند.
- pagination client-side با PAGE_SIZE = 20.
- empty state: اگر هیچ معامله‌ای با فیلتر فعلی یافت نشد، پیام نمایش داده می‌شود.
- EmptyState / ErrorState / PageSkeleton مشابه سایر views.

---

## ۱۰. Frontend — فایل‌های جدید

### `frontend/src/lib/hooks/use-trades.ts`
hook با TanStack Query برای fetch `/analyses/{id}/trades`. همان الگوی
`use-history` و `use-analysis-report` (همگی روی TanStack Query).

### `frontend/src/app/api/v1/analyses/[id]/trades/route.ts`
proxy route برای `/analyses/{id}/trades` (مثل سایر proxy routes). query params
را به‌صورت شفاف به backend forward می‌کند.

---

## ۱۱. Frontend — `lib/types.ts` (تغییر)

اینترفیس‌های جدید برای chart series:

```typescript
export interface EquityCurvePoint { trade: number; equity: number; }
export interface DrawdownPoint { trade: number; drawdown: number; }
export interface PnLDistributionPoint {
  range: string; count: number; type: "win" | "loss";
  bin_left: number; bin_right: number;
}
export interface HourlyPnLPoint { hour: number; pnl: number; }
export interface WeekdayPnLPoint { weekday: string; pnl: number; }
export interface WinLossPie { wins: number; losses: number; breakeven: number; total: number; }
export interface ChartSeries {
  equity_curve: EquityCurvePoint[];
  drawdown: DrawdownPoint[];
  pnl_distribution: PnLDistributionPoint[];
  hourly_pnl: HourlyPnLPoint[];
  weekday_pnl: WeekdayPnLPoint[];
  win_loss_pie: WinLossPie;
}
```

`AnalysisReport.charts: ChartSeries` به اینترفیس اضافه شد.

---

## ۱۲. Frontend — `lib/api/index.ts` (تغییر)

`GetTradesParams.side` از `"long" | "short"` (که با backend همخوانی نداشت —
backend `"Long" | "Short"` برمی‌گرداند) به `"Long" | "Short"` تغییر کرد.

---

## ۱۳. نتیجه‌ی تست‌ها — جزئیات

### Backend `pytest tests/` — ۲۴۱ تست پاس

```
============================= test session starts ==============================
platform linux -- Python 3.12.13
plugins: asyncio-0.23.0, cov-7.0.0

collected 241 items

tests/test_api.py ............................................................... [ 32%]
tests/test_file_loader.py ......                                         [ 35%]
tests/test_phase10_billing.py ....................................       [ 50%]
tests/test_phase11_workers.py ....................                       [ 58%]
tests/test_phase7_5_infrastructure.py ....................               [ 66%]
tests/test_phase8_auth.py .............................................. [ 86%]
................................                                         [ 99%]
tests/test_phase9_workspace.py ........................                  [ 99%]
tests/test_pipeline.py ..                                                [ 99%]
tests/test_reporting.py ...........                                      [100%]
tests/test_sequence_analysis.py .....                                    [100%]
tests/test_validation.py .........                                       [100%]

================ 241 passed, 323 warnings in 70.83s (0:01:10) =================
```

### Frontend `vitest run` — ۱۲ تست پاس

```
✓ src/lib/api/__tests__/api-error.test.ts (6 tests) 3ms
✓ src/components/td/__tests__/demo-data-banner.test.tsx (4 tests) 39ms
✓ src/hooks/__tests__/use-mobile.test.ts (2 tests) 14ms

 Test Files  3 passed (3)
      Tests  12 passed (12)
   Duration  2.82s
```

### Frontend `next build` — موفق

```
▲ Next.js 16.2.10 (Turbopack)
✓ Compiled successfully in 11.1s
✓ Generating static pages using 1 worker (22/22) in 368ms

Route (app)
├ ○ /                                    (static)
├ ○ /_not-found                          (static)
├ ƒ /api                                 (dynamic)
├ ƒ /api/auth/avatar                     (dynamic)
├ ... (all /api/auth/* routes) ...
├ ƒ /api/v1/analyses                     (dynamic)
├ ƒ /api/v1/analyses/[id]                (dynamic)
├ ƒ /api/v1/analyses/[id]/report         (dynamic)
├ ƒ /api/v1/analyses/[id]/report.html    (dynamic)
├ ƒ /api/v1/analyses/[id]/report.pdf     (dynamic)
├ ƒ /api/v1/analyses/[id]/trades         (dynamic)  ← NEW
├ ƒ /api/v1/analyses/jobs/[id]           (dynamic)
├ ƒ /api/v1/config                       (dynamic)
├ ƒ /api/v1/health                       (dynamic)
├ ƒ /api/v1/history                      (dynamic)
├ ƒ /api/v1/uploads                      (dynamic)
└ ƒ /api/v1/workspace/analyses/[id]      (dynamic)
```

### Frontend `npm run lint` — ۰ خطا، ۱۱۰ هشدار

```
✖ 110 problems (0 errors, 110 warnings)
```

تقسیم هشدارها:
- ۱۰۹ هشدار legacy (از فاز v2 باقی‌مانده — non-null assertions، unused imports،
  mixed spaces/tabs در tailwind.config.ts، console statements در auth helpers).
- ۱ هشدار جدید: "Compilation Skipped: Use of incompatible library" برای
  `useReactTable` در `trade-explorer.tsx`. این رفتار شناخته‌شده‌ی React Compiler
  با TanStack Table است و documented است (کتابخانه‌هایی که mutable state را برمی‌گردانند
  نمی‌توانند به‌طور خودکار memoize شوند). غیرفعال‌کردن React Compiler برای این فایل
  با `"use no memo"` directive ممکن است اما برای حفظ یکپارچگی، فعلاً روی warning
  باقی می‌ماند.

---

## ۱۴. ساختار ZIP نهایی

```
TradingDoctor_final/
├── CHANGES_frontend_backend_wiring.md  (بخش ۸ جدید اضافه شد)
├── WORKLOG_v23_fixes.md                (از v2)
├── WORKLOG_v3_charts_trades.md         (این فایل)
├── README.md
├── .env.example
├── .gitignore
├── .github/workflows/ci.yml
├── docker-compose.yml
├── backend/
│   ├── conftest.py                     (جدید — rate-limit disable در تست)
│   ├── requirements.txt
│   ├── requirements-dev.txt
│   ├── api/
│   │   ├── exceptions.py               (ValidationError اضافه شد)
│   │   ├── models/analysis.py          (charts field + TradesResponse)
│   │   └── routers/analyses.py         (charts در report + /trades endpoint)
│   ├── reporting/
│   │   ├── chart_data.py               (جدید — JSON series extractor)
│   │   ├── charts.py                   (بدون تغییر — تولید PNG)
│   │   └── data_context.py             (بدون تغییر)
│   ├── tests/
│   │   ├── test_api.py                 (۷ تست جدید v3 اضافه شد)
│   │   └── ... (سایر تست‌ها بدون تغییر)
│   └── ... (سایر backend بدون تغییر)
├── frontend/
│   ├── package.json
│   ├── vitest.config.ts
│   ├── vitest.setup.ts
│   ├── eslint.config.mjs
│   └── src/
│       ├── app/api/v1/analyses/[id]/
│       │   ├── report/route.ts         (بدون تغییر)
│       │   ├── report.html/route.ts    (بدون تغییر)
│       │   ├── report.pdf/route.ts     (بدون تغییر)
│       │   ├── trades/route.ts         (جدید — proxy route)
│       │   └── route.ts                (بدون تغییر)
│       ├── lib/
│       │   ├── api/index.ts            (GetTradesParams.side type fix)
│       │   ├── hooks/
│       │   │   ├── use-analysis-report.ts
│       │   │   ├── use-history.ts
│       │   │   └── use-trades.ts       (جدید)
│       │   ├── types.ts                (ChartSeries + sub-types جدید)
│       │   └── (mock-data.ts حذف شد)
│       └── views/
│           ├── charts.tsx              (بازنویسی کامل — داده واقعی)
│           └── trade-explorer.tsx      (بازنویسی کامل — @tanstack/react-table)
└── ... (سایر فایل‌ها بدون تغییر)
```

---

## ۱۵. توصیه‌های بعدی

1. **افزودن تست frontend برای charts/trade-explorer**: تست‌های React Testing Library
   با MSW برای mock کردن `/analyses/{id}/report` و `/analyses/{id}/trades`، که
   بررسی می‌کنند نمودارها با داده‌ی واقعی رندر می‌شوند و جدول pagination درست کار می‌کند.
2. **اضافه‌کردن win_loss_pie chart به views/charts.tsx**: backend این سری را هم
   برمی‌گرداند ولی فعلاً در frontend نمایش داده نمی‌شود.
3. **اضافه‌کردن weekday_pnl chart به views/charts.tsx**: مانند بالا.
4. **Server-side pagination برای تحلیل‌های بزرگ**: اگر تحلیل بیش از 200 معامله
   داشته باشد، فعلاً فقط 200تای اول نمایش داده می‌شود. می‌توان به‌جای client-side
   pagination، از server-side pagination استفاده کرد با `useTrades({page, pageSize})`
   و forward کردن page state به query params.
5. **بررسی stale time در TanStack Query**: فعلاً 15 ثانیه برای trades و 30 ثانیه
   برای report. برای تحلیل‌هایimmutable (که بعد از ایجاد تغییر نمی‌کنند)، می‌توان
   stale time را به `Infinity` افزایش داد.
