# -*- coding: utf-8 -*-
"""
llm/gemini.py
---------------
اتصال به Google Gemini API. برای فعال‌سازی، متغیر محیطی GEMINI_API_KEY
باید تنظیم شده باشد؛ در غیر این صورت CoachingEngine خودکار به fallback
هیوریستیک برمی‌گردد.

[AUDIT FIX - security] قبلاً کلید API مستقیماً در query-string آدرس
(`?key=...`) قرار می‌گرفت. اگر درخواست با خطا مواجه می‌شد،
`requests.Response.raise_for_status()` یک HTTPError پرتاب می‌کند که
پیام پیش‌فرضش شامل *کل URL* (از جمله کلید API) است؛ این Exception در
CoachingEngine لاگ می‌شد و عملاً کلید API را داخل فایل لاگ می‌نوشت.
حالا کلید API از طریق هدر `x-goog-api-key` ارسال می‌شود (نه URL) و علاوه
بر آن، هر خطای شبکه/HTTP قبل از هر جای دیگر این‌جا گرفته و به یک پیام
sanitize‌شده (بدون کلید) تبدیل می‌شود.
"""

import json

import config
from llm.provider import BaseLLMProvider
from utils.logger import get_logger

log = get_logger(__name__)

_GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


class GeminiProvider(BaseLLMProvider):
    name = "gemini"

    def __init__(self):
        if not config.GEMINI_API_KEY:
            raise RuntimeError(
                "GEMINI_API_KEY تنظیم نشده است. "
                "متغیر محیطی GEMINI_API_KEY را ست کنید یا از provider دیگری استفاده کنید."
            )
        self.api_key = config.GEMINI_API_KEY
        self.model = config.GEMINI_MODEL

    def chat(self, messages) -> str:
        import requests  # ایمپورت تنبل تا وابستگی فقط وقتی provider واقعاً استفاده می‌شود لازم باشد

        # Gemini پیام سیستم را جدا از "contents" می‌گیرد.
        system_parts = [m["content"] for m in messages if m.get("role") == "system"]
        user_parts = [m["content"] for m in messages if m.get("role") != "system"]

        url = _GEMINI_ENDPOINT.format(model=self.model)
        payload = {
            "contents": [{"parts": [{"text": "\n\n".join(user_parts)}]}],
        }
        if system_parts:
            payload["systemInstruction"] = {"parts": [{"text": "\n".join(system_parts)}]}

        try:
            response = requests.post(
                url,
                headers={"x-goog-api-key": self.api_key, "Content-Type": "application/json"},
                json=payload,
                timeout=config.LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
        except requests.exceptions.Timeout as e:
            log.warning("Gemini request timed out after %ss", config.LLM_TIMEOUT_SECONDS)
            raise RuntimeError("درخواست به Gemini timeout شد.") from e
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            log.warning("Gemini request failed with HTTP status %s", status)
            raise RuntimeError(f"Gemini با کد وضعیت {status} پاسخ داد.") from e
        except requests.exceptions.RequestException as e:
            log.warning("Gemini request failed: %s", type(e).__name__)
            raise RuntimeError("اتصال به Gemini برقرار نشد.") from e

        data = response.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"پاسخ غیرمنتظره از Gemini: {json.dumps(data)[:300]}") from e
