# -*- coding: utf-8 -*-
"""
llm/claude.py
---------------
اتصال به Anthropic Messages API. برای فعال‌سازی، متغیر محیطی
ANTHROPIC_API_KEY باید تنظیم شده باشد.
"""

import json

import config
from llm.provider import BaseLLMProvider
from utils.logger import get_logger

log = get_logger(__name__)


class ClaudeProvider(BaseLLMProvider):
    name = "claude"

    def __init__(self):
        if not config.ANTHROPIC_API_KEY:
            raise RuntimeError(
                "ANTHROPIC_API_KEY تنظیم نشده است. "
                "متغیر محیطی ANTHROPIC_API_KEY را ست کنید یا از provider دیگری استفاده کنید."
            )
        self.api_key = config.ANTHROPIC_API_KEY
        self.model = config.CLAUDE_MODEL

    def chat(self, messages) -> str:
        import requests

        # Anthropic پیام سیستم را جدا از "messages" می‌گیرد.
        system_parts = [m["content"] for m in messages if m.get("role") == "system"]
        chat_messages = [m for m in messages if m.get("role") != "system"]

        # [AUDIT FIX] یکدست‌سازی مدیریت خطای شبکه/HTTP با دو provider دیگر
        # (Step 5) + لاگ ساختاریافته بدون افشای هیچ داده‌ی حساس (Step 6).
        try:
            response = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "max_tokens": config.LLM_MAX_TOKENS,
                    "system": "\n".join(system_parts) if system_parts else None,
                    "messages": chat_messages,
                },
                timeout=config.LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
        except requests.exceptions.Timeout as e:
            log.warning("Claude request timed out after %ss", config.LLM_TIMEOUT_SECONDS)
            raise RuntimeError("درخواست به Claude timeout شد.") from e
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            log.warning("Claude request failed with HTTP status %s", status)
            raise RuntimeError(f"Claude با کد وضعیت {status} پاسخ داد.") from e
        except requests.exceptions.RequestException as e:
            log.warning("Claude request failed: %s", type(e).__name__)
            raise RuntimeError("اتصال به Claude برقرار نشد.") from e

        data = response.json()
        try:
            return "".join(
                block.get("text", "") for block in data.get("content", [])
                if block.get("type") == "text"
            )
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"پاسخ غیرمنتظره از Claude: {json.dumps(data)[:300]}") from e
