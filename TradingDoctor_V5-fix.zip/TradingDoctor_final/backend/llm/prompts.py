# -*- coding: utf-8 -*-
"""
llm/prompts.py
----------------
قالب‌های prompt استفاده‌شده توسط CoachingEngine. جدا نگه‌داشتن این متن‌ها
اینجا اجازه می‌دهد بدون دست‌زدن به منطق موتور، لحن/زبان/ساختار prompt را
تغییر دهیم یا برای provider مختلف نسخه‌های متفاوت بسازیم.
"""

from typing import List

COACHING_SYSTEM_PROMPT = (
    "تو یک مربی حرفه‌ای و همدل روانشناسی معاملاتی هستی. "
    "کاملاً ساده، واقعی و کاربردی توضیح بده."
)


def build_coaching_prompt(
    summary: str,
    primary: str,
    secondary: str,
    evidence_text: List[str],
) -> List[dict]:
    """پیام‌های system/user برای تولید توضیح coach-محور (explainable_ai)."""
    return [
        {"role": "system", "content": COACHING_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"""
خلاصه معاملات: {summary}
تشخیص اصلی: {primary}
تشخیص ثانویه: {secondary}
شواهد مهم: {evidence_text}
وظیفه:
- تحلیل رفتار تریدر
- نقاط قوت و ضعف
- علت اشتباهات
- ۲ تا ۳ پیشنهاد عملی واقعی
- لحن coach واقعی، نه ربات
""",
        },
    ]


# [Phase 6 — AI Coach workspace] پرامپت پرسش‌وپاسخ آزاد. محدودیت حیاتی:
# سیستم صراحتاً به مدل می‌گوید که هرگز عدد/امتیاز/تشخیص جدید تولید
# نکند — فقط همان نتایج از‌قبل‌محاسبه‌شده (که در context آمده) را توضیح
# دهد. این دقیقاً همان اصل معماری «AI هرگز موتور تحلیلی نمی‌شود» است که
# در سراسر این پروژه رعایت شده، حالا برای یک ویژگی پرسش‌وپاسخ آزاد هم
# صریحاً در سطح prompt تکرار می‌شود — نه فقط در کد.
FOLLOWUP_SYSTEM_PROMPT = (
    "تو یک مربی روانشناسی معاملاتی هستی که به سوالات پیگیری کاربر درباره‌ی "
    "تحلیل‌اش پاسخ می‌دهی. قوانین سخت‌گیرانه:\n"
    "۱) هرگز عدد، امتیاز، درصد یا تشخیص جدیدی که در «نتایج تحلیل» زیر نیامده "
    "است، اختراع نکن — فقط همان‌ها را توضیح بده یا بازتعریف کن.\n"
    "۲) اگر سوال نیاز به محاسبه‌ی جدید دارد که در داده‌ی داده‌شده نیست، صادقانه "
    "بگو این خارج از داده‌ی موجود است، حدس نزن.\n"
    "۳) لحن حمایتی و کاربردی، نه قضاوتی."
)


def build_followup_prompt(context_summary: str, question: str, chat_history: List[dict]) -> List[dict]:
    """
    context_summary: خلاصه‌ی متنی از نتایج از‌قبل‌محاسبه‌شده (تشخیص،
    امتیازها، شواهد کلیدی) — همان چیزی که کاربر در Dashboard/Diagnosis
    می‌بیند، نه محاسبه‌ی جدید.
    chat_history: پیام‌های قبلی این گفت‌وگو (برای حفظ context بین سوالات).
    """
    messages = [{"role": "system", "content": FOLLOWUP_SYSTEM_PROMPT + "\n\nنتایج تحلیل:\n" + context_summary}]
    messages.extend(chat_history)
    messages.append({"role": "user", "content": question})
    return messages
