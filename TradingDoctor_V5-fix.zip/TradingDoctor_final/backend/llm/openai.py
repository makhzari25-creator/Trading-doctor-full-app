# -*- coding: utf-8 -*-
"""
llm/openai.py
---------------
اتصال به OpenAI Chat Completions API. برای فعال‌سازی، متغیر محیطی
OPENAI_API_KEY باید تنظیم شده باشد.
"""

import json

import config
from llm.provider import BaseLLMProvider
from utils.logger import get_logger

log = get_logger(__name__)


class OpenAIProvider(BaseLLMProvider):
    name = "openai"

    def __init__(self):
        if not config.OPENAI_API_KEY:
            raise RuntimeError(
                "OPENAI_API_KEY تنظیم نشده است. "
                "متغیر محیطی OPENAI_API_KEY را ست کنید یا از provider دیگری استفاده کنید."
            )
        self.api_key = config.OPENAI_API_KEY
        self.model = config.OPENAI_MODEL

    def chat(self, messages) -> str:
        import requests

        # [AUDIT FIX] قبلاً requests.exceptions.* دستگیر نمی‌شد و مستقیماً
        # بالا می‌رفت. هرچند اینجا خطر افشای کلید API (مثل Gemini) وجود
        # ندارد چون کلید در هدر است نه URL، اما برای یکدستی مدیریت خطا در
        # همه‌ی providerها (Step 5) و لاگ ساختاریافته (Step 6) همان الگو
        # اعمال شد.
        try:
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "max_tokens": config.LLM_MAX_TOKENS,
                },
                timeout=config.LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
        except requests.exceptions.Timeout as e:
            log.warning("OpenAI request timed out after %ss", config.LLM_TIMEOUT_SECONDS)
            raise RuntimeError("درخواست به OpenAI timeout شد.") from e
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            log.warning("OpenAI request failed with HTTP status %s", status)
            raise RuntimeError(f"OpenAI با کد وضعیت {status} پاسخ داد.") from e
        except requests.exceptions.RequestException as e:
            log.warning("OpenAI request failed: %s", type(e).__name__)
            raise RuntimeError("اتصال به OpenAI برقرار نشد.") from e

        data = response.json()
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"پاسخ غیرمنتظره از OpenAI: {json.dumps(data)[:300]}") from e
