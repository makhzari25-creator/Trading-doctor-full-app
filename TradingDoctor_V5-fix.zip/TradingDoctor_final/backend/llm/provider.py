# -*- coding: utf-8 -*-
"""
llm/provider.py
------------------
واجهه‌ی مشترک برای همه‌ی LLM providerها + یک factory (get_llm) که بر اساس
نام، provider مناسب را می‌سازد. اگر provider پیدا نشود یا کلید API نداشته
باشد، خطای واضح می‌دهد تا CoachingEngine بتواند آن را بگیرد و به fallback
هوشمند برگردد (بدون کرش‌کردن کل برنامه).
"""

from abc import ABC, abstractmethod
from typing import List, Dict


class BaseLLMProvider(ABC):
    """کلاس پایه‌ی هر LLM provider (Gemini / OpenAI / Claude / ...)."""

    name: str = "base"

    @abstractmethod
    def chat(self, messages: List[Dict[str, str]]) -> str:
        """
        messages: لیستی از {"role": "system"|"user"|"assistant", "content": str}
        خروجی: متن پاسخ مدل.
        """
        raise NotImplementedError


def get_llm(provider_name: str) -> BaseLLMProvider:
    """
    Factory: بر اساس نام provider، نمونه‌ی مناسب را برمی‌گرداند.
    در صورت نبود کلید API یا وابستگی لازم، Exception با پیام روشن
    پرتاب می‌کند تا فراخوان (CoachingEngine) بتواند gracefully آن را
    بگیرد و به توضیح heuristic برگردد.
    """
    provider_name = (provider_name or "").strip().lower()

    if provider_name == "gemini":
        from llm.gemini import GeminiProvider
        return GeminiProvider()
    if provider_name == "openai":
        from llm.openai import OpenAIProvider
        return OpenAIProvider()
    if provider_name in ("claude", "anthropic"):
        from llm.claude import ClaudeProvider
        return ClaudeProvider()

    raise ValueError(f"LLM provider ناشناخته: '{provider_name}'")
