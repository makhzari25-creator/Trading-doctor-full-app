# -*- coding: utf-8 -*-
"""
ui/history.py
----------------
تاریخچه‌ی تحلیل‌ها — Phase 6 (UX & Web Experience).

محدوده‌ی صادقانه: این یک تاریخچه‌ی *محدود به session مرورگر فعلی* است،
نه یک پایگاه‌داده‌ی دائمی چندکاربره. هر تحلیل جدید در همان session
اضافه می‌شود؛ با بستن/رفرش کامل مرورگر یا ری‌استارت سرور، از بین
می‌رود — دقیقاً مثل بقیه‌ی state این اپ (st.session_state). اگر
تاریخچه‌ی دائمی و چندکاربره لازم باشد، زیرساخت واقعی همان
api/services/store.py (فاز ۳) است که از قبل روی دیسک/حافظه با محدودیت
اندازه کار می‌کند — این ماژول عمداً آن را دوباره پیاده‌سازی نمی‌کند،
فقط یک تجربه‌ی «تاریخچه در این نشست» برای کاربر Streamlit فراهم می‌کند.

هیچ منطق تحلیلی اینجا نیست — فقط ذخیره و بازیابی همان
doctor/result/coach که موتور از قبل تولید کرده.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

import streamlit as st

_HISTORY_KEY = "analysis_history"
_MAX_HISTORY_ITEMS = 20  # جلوگیری از رشد نامحدود حافظه‌ی session، مشابه فلسفه‌ی api/config.py::STORE_MAX_ANALYSES


def _ensure_history() -> List[Dict[str, Any]]:
    if _HISTORY_KEY not in st.session_state:
        st.session_state[_HISTORY_KEY] = []
    return st.session_state[_HISTORY_KEY]


def add_entry(filename: str, doctor: Any, result: Any, coach: Dict[str, Any],
              llm_provider: str = "gemini") -> str:
    """
    [Auto-save] هر تحلیل موفق باید بلافاصله اینجا ثبت شود — بدون نیاز به
    اقدام دستی کاربر. برمی‌گرداند: entry_id.
    """
    history = _ensure_history()
    entry_id = f"h{len(history)}_{int(datetime.now().timestamp())}"
    entry = {
        "id": entry_id,
        "filename": filename,
        "timestamp": datetime.now(),
        "discipline_score": result.behavior.scores.get("discipline_score", 0),
        "primary_diagnosis": coach.get("diagnosis", {}).get("primary", "نامشخص"),
        "total_trades": result.performance.get("total_trades", 0),
        "favorite": False,
        "doctor": doctor,
        "result": result,
        "coach": coach,
        "llm_provider": llm_provider,
    }
    history.insert(0, entry)  # جدیدترین در ابتدا
    if len(history) > _MAX_HISTORY_ITEMS:
        # [AUDIT FIX-pattern از api/services/store.py] حذف قدیمی‌ترین
        # آیتم‌های غیر-favorite برای جلوگیری از نشت حافظه در یک session
        # طولانی؛ آیتم‌های favorite حذف نمی‌شوند مگر کاربر خودش حذف کند.
        non_favorites = [e for e in history if not e["favorite"]]
        if non_favorites:
            history.remove(non_favorites[-1])
    return entry_id


def get_history() -> List[Dict[str, Any]]:
    return _ensure_history()


def toggle_favorite(entry_id: str) -> None:
    for entry in _ensure_history():
        if entry["id"] == entry_id:
            entry["favorite"] = not entry["favorite"]
            return


def delete_entry(entry_id: str) -> None:
    history = _ensure_history()
    st.session_state[_HISTORY_KEY] = [e for e in history if e["id"] != entry_id]


def load_entry(entry_id: str) -> bool:
    """بازیابی یک تحلیل قبلی به‌عنوان تحلیل فعال (result/coach/doctor/df)."""
    for entry in _ensure_history():
        if entry["id"] == entry_id:
            st.session_state["doctor"] = entry["doctor"]
            st.session_state["result"] = entry["result"]
            st.session_state["coach"] = entry["coach"]
            st.session_state["df"] = entry["doctor"].df
            st.session_state["llm_provider"] = entry.get("llm_provider", "gemini")
            # کش گزارش HTML/PDF (فاز ۲/۳) باید بی‌اعتبار شود چون تحلیل عوض شده
            st.session_state.pop("_html_cache_key", None)
            st.session_state.pop("_pdf_cache_key", None)
            # [Phase 6] گفت‌وگوی AI Coach هم باید برای تحلیل جدید از صفر
            # شروع شود — ادامه‌ی چت قبلی درباره‌ی یک تحلیل متفاوت گمراه‌کننده است.
            st.session_state.pop("coach_chat_history", None)
            st.session_state.pop("coach_followup_count", None)
            return True
    return False


def search_and_filter(
    query: str = "", favorites_only: bool = False,
    min_score: float = 0, max_score: float = 100,
    sort_by: str = "newest",
) -> List[Dict[str, Any]]:
    """
    جست‌وجو/فیلتر/مرتب‌سازی روی تاریخچه‌ی همین session — پیاده‌سازی واقعی
    "Global search" / "Advanced filters" / "Sorting" برای داده‌ای که واقعاً
    در این اپ وجود دارد (تاریخچه‌ی تحلیل)، نه یک جعبه‌ی جست‌وجوی نمایشی.
    """
    items = get_history()
    if query:
        q = query.strip().lower()
        items = [e for e in items if q in e["filename"].lower() or q in e["primary_diagnosis"].lower()]
    if favorites_only:
        items = [e for e in items if e["favorite"]]
    items = [e for e in items if min_score <= e["discipline_score"] <= max_score]

    if sort_by == "newest":
        items = sorted(items, key=lambda e: e["timestamp"], reverse=True)
    elif sort_by == "oldest":
        items = sorted(items, key=lambda e: e["timestamp"])
    elif sort_by == "score_desc":
        items = sorted(items, key=lambda e: e["discipline_score"], reverse=True)
    elif sort_by == "score_asc":
        items = sorted(items, key=lambda e: e["discipline_score"])
    return items
