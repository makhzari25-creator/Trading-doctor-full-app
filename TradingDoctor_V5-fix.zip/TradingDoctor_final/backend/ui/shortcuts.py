# -*- coding: utf-8 -*-
"""
ui/shortcuts.py
------------------
میان‌برهای صفحه‌کلید — Phase 6. با components.v1.html() پیاده‌سازی شده
(نه st.markdown) چون تأیید مستقیم شد که <script> تزریق‌شده از طریق
st.markdown(unsafe_allow_html=True) اصلاً اجرا نمی‌شود (innerHTML rules
استاندارد مرورگر) — این تفاوت با تست واقعی Playwright کشف شد، نه فرض.

نکته‌ی حیاتی صحّت: میان‌برها باید وقتی کاربر داخل یک input/textarea (مثلاً
جعبه‌ی جست‌وجوی تاریخچه یا چت AI Coach) در حال تایپ است، غیرفعال باشند —
در غیر این صورت تایپ‌کردن حرف "h" برای نوشتن یک کلمه، به‌طور ناخواسته
صفحه را عوض می‌کند. این یک باگ واقعی و شناخته‌شده در این کلاس ویژگی‌هاست،
نه یک احتیاط نظری.
"""

import streamlit.components.v1 as components

# مسیرهای واقعی صفحات — تأیید‌شده مستقیم از URL واقعی برنامه (نه حدس)،
# چون Streamlit مسیر هر صفحه را از روی نام نمایشی آن می‌سازد.
_SHORTCUTS = {
    "d": ("Dashboard", "داشبورد"),
    "c": ("Charts", "نمودارها"),
    "b": ("Behavioral_Analysis", "تحلیل رفتاری"),
    "g": ("Diagnosis", "تشخیص"),
    "a": ("Coaching", "Coaching"),
    "h": ("History", "تاریخچه"),
    "e": ("Downloads", "مرکز دانلود"),
}


def inject_keyboard_shortcuts() -> None:
    shortcuts_js_map = ", ".join(f'"{k}": "{v[0]}"' for k, v in _SHORTCUTS.items())
    help_lines = "".join(f"<div><b>{k}</b> — {v[1]}</div>" for k, v in _SHORTCUTS.items())

    components.html(f"""
    <script>
    (function() {{
        const doc = window.parent.document;
        if (doc.__td_shortcuts_installed) return;  // جلوگیری از نصب تکراری هنگام rerun
        doc.__td_shortcuts_installed = true;

        const routes = {{{shortcuts_js_map}}};

        function isTyping(el) {{
            if (!el) return false;
            const tag = (el.tagName || "").toLowerCase();
            return tag === "input" || tag === "textarea" || el.isContentEditable;
        }}

        function showHelp() {{
            let overlay = doc.getElementById("td-shortcuts-help");
            if (overlay) {{ overlay.remove(); return; }}
            overlay = doc.createElement("div");
            overlay.id = "td-shortcuts-help";
            overlay.style.cssText = "position:fixed;top:20px;right:20px;z-index:99999;" +
                "background:#181C22;color:#EDEFF2;border:1px solid #262B33;border-radius:10px;" +
                "padding:16px 20px;font-family:Inter,sans-serif;font-size:13px;box-shadow:0 4px 16px rgba(0,0,0,0.5);" +
                "direction:rtl;";
            overlay.innerHTML = "<b style='display:block;margin-bottom:8px;'>میان‌برهای صفحه‌کلید (? برای بستن)</b>" + `{help_lines}`;
            doc.body.appendChild(overlay);
        }}

        doc.addEventListener("keydown", function(e) {{
            if (isTyping(doc.activeElement)) return;
            if (e.metaKey || e.ctrlKey || e.altKey) return;

            if (e.key === "?") {{
                e.preventDefault();
                showHelp();
                return;
            }}
            const target = routes[e.key];
            if (target) {{
                e.preventDefault();
                // [AUDIT FIX] تنظیم مستقیم window.parent.location.href از
                // داخل iframe سندباکس‌شده‌ی components.html() توسط مرورگر
                // مسدود می‌شود (خطای واقعی مشاهده‌شده در تست:
                // "Unsafe attempt to initiate navigation ... sandboxed").
                // راه‌حل درست: پیدا کردن و کلیک برنامه‌ای روی لینک واقعی
                // sidebar که همان مسیر را دارد — این یک اقدام داخل سند
                // اصلی (نه iframe) است، نه یک تلاش ناوبری از iframe.
                const links = window.parent.document.querySelectorAll('[data-testid="stSidebarNavLink"]');
                for (const link of links) {{
                    if (link.href && link.href.endsWith("/" + target)) {{
                        link.click();
                        break;
                    }}
                }}
            }}
        }});
    }})();
    </script>
    """, height=0, width=0)
