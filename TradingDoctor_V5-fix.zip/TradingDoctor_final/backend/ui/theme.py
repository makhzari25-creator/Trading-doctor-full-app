# -*- coding: utf-8 -*-
"""
ui/theme.py
--------------
تزریق تم مشترک Trading Doctor V23 (Phase 5A Design System) — دقیقاً همان
توکن‌ها و مقادیر مستندشده در design/02_FOUNDATIONS.md و
design/03_COMPONENTS.md، بدون هیچ مقدار خام جدید اینجا.

این ماژول تنها راه تزریق تم است — هر صفحه (app.py و هر فایل زیر
pages/) دقیقاً همین یک تابع را در همان ابتدای اسکریپت صدا می‌زند:

    from ui.theme import inject_theme
    inject_theme()

چون Streamlit یک اپ چندصفحه‌ای را با اجرای مجدد کل اسکریپت هر صفحه پیاده
می‌کند (نه یک SPA با state مشترک)، تزریق باید در هر صفحه تکرار شود؛ این
یک تصمیم طراحی است، نه محدودیت — با این حال محتوای تزریق‌شده در همه‌جا
۱۰۰٪ یکسان است (یک منبع واحد، این فایل)، پس هیچ صفحه‌ای نمی‌تواند از تم
مشترک منحرف شود.

سلکتورهای هدف‌گیری ویجت‌های native با پروب واقعی DOM (Playwright روی
Streamlit 1.59.0) تأیید شده‌اند — نه حدس بر اساس مستندات یا الگوی
نام‌گذاری. جزئیات در design/05_COMPONENT_INVENTORY.md.
"""

import streamlit as st

_THEME_CSS = """
<style>
/* ============================================================
   design/02_FOUNDATIONS.md — Color System
   ============================================================ */
:root {
  /* Neutral — dark (default) */
  --td-bg-canvas: #0B0D10;
  --td-bg-surface: #12151A;
  --td-bg-surface-2: #181C22;
  --td-bg-surface-3: #20252D;
  --td-border: #262B33;
  --td-border-strong: #333A45;
  --td-text: #EDEFF2;
  --td-text-muted: #9AA3B0;
  --td-text-faint: #5B6472;

  /* Brand accent */
  --td-accent: #6F9BF0;
  --td-accent-hover: #8AAEF3;
  --td-accent-muted: rgba(111,155,240,0.14);

  /* Semantic — icon/border form */
  --td-positive: #35C795;
  --td-negative: #FF6B70;
  --td-warning: #E0B13D;
  --td-info: var(--td-accent);

  /* Semantic — solid fill (buttons, alert bars) */
  --td-positive-solid: #0F7A56;
  --td-negative-solid: #B3383C;
  --td-warning-solid: #7A5A15;

  /* Semantic — soft badge (background tint + text) */
  --td-positive-soft-bg: rgba(53,199,149,0.16);
  --td-positive-soft-text: #35C795;
  --td-negative-soft-bg: rgba(255,107,112,0.16);
  --td-negative-soft-text: #FF6B70;
  --td-warning-soft-bg: rgba(224,177,61,0.16);
  --td-warning-soft-text: #E0B13D;

  /* Severity ramp — High is the one genuinely new hue */
  --td-severity-high: #F0924A;
  --td-severity-high-solid: #B3611F;
  --td-severity-high-soft-bg: rgba(240,146,74,0.16);
  --td-severity-high-soft-text: #F0924A;

  /* Spacing (4px base) */
  --td-space-1: 4px; --td-space-2: 8px; --td-space-3: 12px;
  --td-space-4: 16px; --td-space-5: 24px; --td-space-6: 32px;
  --td-space-7: 48px; --td-space-8: 64px;

  /* Radius */
  --td-radius-sm: 6px; --td-radius-md: 10px; --td-radius-lg: 14px; --td-radius-full: 999px;

  /* Elevation — dark */
  --td-elevation-1: 0 1px 2px rgba(0,0,0,0.4);
  --td-elevation-2: 0 2px 8px rgba(0,0,0,0.5);
  --td-elevation-3: 0 4px 16px rgba(0,0,0,0.55);
  --td-elevation-4: 0 12px 32px rgba(0,0,0,0.6);

  /* Typography */
  --td-font-ui: "Inter", "Vazirmatn", -apple-system, "Segoe UI", sans-serif;
  --td-font-mono: "JetBrains Mono", ui-monospace, monospace;
}

@media (prefers-color-scheme: light) {
  :root {
    --td-bg-canvas: #F7F8FA;
    --td-bg-surface: #FFFFFF;
    --td-bg-surface-2: #F7F9FC;
    --td-bg-surface-3: #EEF1F5;
    --td-border: #E2E6ED;
    --td-border-strong: #C7CEDA;
    --td-text: #1E2430;
    --td-text-muted: #5B6472;
    --td-text-faint: #8B96A5;

    --td-accent: #3B6FD4;
    --td-accent-hover: #2F5FC4;
    --td-accent-muted: rgba(59,111,212,0.10);

    --td-positive: #00A67D;
    --td-negative: #E5484D;
    --td-warning: #B98900;

    --td-positive-solid: #00805F;
    --td-negative-solid: #C23238;
    --td-warning-solid: #8F6B00;

    --td-positive-soft-bg: rgba(0,166,125,0.14);
    --td-positive-soft-text: #00734F;
    --td-negative-soft-bg: rgba(229,72,77,0.14);
    --td-negative-soft-text: #E5484D;
    --td-warning-soft-bg: rgba(185,137,0,0.14);
    --td-warning-soft-text: #8A6800;

    --td-severity-high: #D9691E;
    --td-severity-high-solid: #B85A1A;
    --td-severity-high-soft-bg: rgba(217,105,30,0.14);
    --td-severity-high-soft-text: #A54E12;

    --td-elevation-1: 0 1px 2px rgba(20,24,32,0.06);
    --td-elevation-2: 0 2px 8px rgba(20,24,32,0.08);
    --td-elevation-3: 0 4px 16px rgba(20,24,32,0.10);
    --td-elevation-4: 0 12px 32px rgba(20,24,32,0.14);
  }
}

/* ============================================================
   Base — root app shell
   [AUDIT FIX — self-review, real regression found] The first pass used
   `[class*="st-"]` to apply the UI font broadly. Streamlit's own
   internal classes (`st-emotion-cache-...`) also match that wildcard,
   which caught its icon elements too — those render via a ligature
   font (Material Symbols Rounded) where the *text content* is literally
   a string like "keyboard_double_arrow_left" and the font is what turns
   it into an arrow glyph. Overriding that font broke every icon in the
   app (sidebar collapse arrow, expander chevrons, etc.) into showing
   raw ligature text. Confirmed via direct computed-style inspection
   before/after. Fixed by scoping the font rule to real content
   containers only, plus an explicit defensive restore for the icon
   element (verified selector: [data-testid="stIconMaterial"]) in case
   any other broad rule risks the same mistake later.
   ============================================================ */
body,
[data-testid="stMarkdownContainer"],
[data-testid="stMetricValue"], [data-testid="stMetricLabel"], [data-testid="stMetricDelta"],
[data-testid="stWidgetLabel"], [data-testid="stTextInputRootElement"],
[data-testid="stSelectbox"], [data-testid="stButton"], [data-testid="stBaseButton-primary"],
[data-testid="stBaseButton-secondary"], [data-testid="stTab"],
h1, h2, h3, h4, p {
  font-family: var(--td-font-ui);
}
[data-testid="stIconMaterial"] {
  font-family: "Material Symbols Rounded" !important;
}

[data-testid="stApp"],
[data-testid="stAppViewContainer"],
[data-testid="stMain"] {
  background-color: var(--td-bg-canvas) !important;
  color: var(--td-text) !important;
}
[data-testid="stMainBlockContainer"] { max-width: 1440px; }
[data-testid="stSidebar"], [data-testid="stSidebarContent"] {
  background-color: var(--td-bg-surface) !important;
  border-inline-end: 1px solid var(--td-border);
}
[data-testid="stSidebarNavLink"] {
  border-radius: var(--td-radius-sm) !important;
  color: var(--td-text-muted) !important;
  transition: background 150ms ease-out;
}
[data-testid="stSidebarNavLink"]:hover {
  background: var(--td-bg-surface-3) !important;
}
[data-testid="stSidebarNavLink"][aria-current="page"] {
  background: var(--td-accent-muted) !important;
  color: var(--td-accent) !important;
  border-inline-start: 2px solid var(--td-accent);
}
h1, h2, h3, [data-testid="stMarkdownContainer"] p { color: var(--td-text); }

/* ============================================================
   Phase 5B — shared section rhythm & hierarchy
   (design/01_DESIGN_RATIONALE.md Principle 8: one spacing scale,
   applied everywhere, replacing ad hoc st.divider()-only rhythm —
   design/00_UI_AUDIT.md finding #4/#8)
   ============================================================ */
[data-testid="stVerticalBlock"] > [data-testid="stElementContainer"]:has(h2),
[data-testid="stVerticalBlock"] > [data-testid="stElementContainer"]:has(h3) {
  margin-top: var(--td-space-6) !important;
}
/* [AUDIT FIX — self-review] st.subheader() renders as <h3>, not <h2> as
   first assumed — verified via direct DOM inspection (h2 count was 0 on
   every page checked, h3 count matched the number of st.subheader()
   calls exactly). The selector above already includes h3, this note
   documents why both levels are covered rather than just h2. */
h1 { font-size: 28px !important; font-weight: 700 !important; letter-spacing: -0.01em; }
h2 { font-size: 20px !important; font-weight: 600 !important; }
h3 { font-size: 16px !important; font-weight: 600 !important; color: var(--td-text-muted) !important; }
[data-testid="stMarkdownContainer"] p { font-size: 14px; line-height: 22px; color: var(--td-text); }

/* Page-link "next step" cards — hover affordance, consistency fix for
   design/00_UI_AUDIT.md's flat, unstyled nav links at page bottoms */
[data-testid="stPageLink"] {
  border: 1px solid var(--td-border);
  border-radius: var(--td-radius-md);
  padding: var(--td-space-3) var(--td-space-4) !important;
  transition: border-color 150ms ease-out, background 150ms ease-out;
}
[data-testid="stPageLink"]:hover {
  border-color: var(--td-accent);
  background: var(--td-accent-muted);
}

/* Table row hover (micro-interaction requested in Phase 5B) */
[data-testid="stDataFrame"] { transition: box-shadow 150ms ease-out; }
[data-testid="stDataFrame"]:hover { box-shadow: var(--td-elevation-2); }

/* Divider — visual weight reduced now that spacing carries most of the
   section rhythm (Principle 1: a gap communicates separation with less
   noise than a heavy line) */
[data-testid="stMarkdownContainer"] hr, hr {
  border-color: var(--td-border) !important;
  opacity: 0.6;
  margin-block: var(--td-space-5) !important;
}

:focus-visible {
  outline: 2px solid var(--td-accent) !important;
  outline-offset: 2px !important;
  border-radius: var(--td-radius-sm);
}

/* ============================================================
   design/03_COMPONENTS.md — Buttons
   (selectors verified via Playwright probe, Streamlit 1.59.0)
   ============================================================ */
[data-testid="stBaseButton-primary"] {
  background: var(--td-accent) !important;
  border-radius: var(--td-radius-md) !important;
  font-weight: 600 !important;
  transition: background 150ms ease-out, box-shadow 150ms ease-out;
}
[data-testid="stBaseButton-primary"]:hover {
  background: var(--td-accent-hover) !important;
  box-shadow: var(--td-elevation-1);
}
[data-testid="stBaseButton-secondary"] {
  border-radius: var(--td-radius-md) !important;
  border-color: var(--td-border-strong) !important;
  font-weight: 500 !important;
  transition: background 150ms ease-out;
}
[data-testid="stBaseButton-secondary"]:hover {
  background: var(--td-bg-surface-3) !important;
}

/* ============================================================
   Alerts — soft-bg + solid left accent bar, per component spec
   ============================================================ */
[data-testid="stAlertContainer"] {
  border-radius: var(--td-radius-md) !important;
  border-inline-start: 3px solid transparent;
}
[data-testid="stAlertContentError"] { color: var(--td-negative-soft-text) !important; }
[data-testid="stAlertContentError"] ~ * , [data-testid="stAlertContainer"]:has([data-testid="stAlertContentError"]) {
  background: var(--td-negative-soft-bg) !important;
  border-inline-start-color: var(--td-negative-solid) !important;
}
[data-testid="stAlertContentWarning"] { color: var(--td-warning-soft-text) !important; }
[data-testid="stAlertContainer"]:has([data-testid="stAlertContentWarning"]) {
  background: var(--td-warning-soft-bg) !important;
  border-inline-start-color: var(--td-warning-solid) !important;
}
[data-testid="stAlertContentInfo"] { color: var(--td-accent) !important; }
[data-testid="stAlertContainer"]:has([data-testid="stAlertContentInfo"]) {
  background: var(--td-accent-muted) !important;
  border-inline-start-color: var(--td-accent) !important;
}
[data-testid="stAlertContentSuccess"] { color: var(--td-positive-soft-text) !important; }
[data-testid="stAlertContainer"]:has([data-testid="stAlertContentSuccess"]) {
  background: var(--td-positive-soft-bg) !important;
  border-inline-start-color: var(--td-positive-solid) !important;
}

/* ============================================================
   Expander (Accordion), Tabs, Progress, DataFrame container
   ============================================================ */
[data-testid="stExpander"] {
  border-radius: var(--td-radius-md) !important;
  border-color: var(--td-border) !important;
}
[data-testid="stTabs"] [data-testid="stTab"][aria-selected="true"] {
  color: var(--td-text) !important;
  font-weight: 600 !important;
  border-bottom-color: var(--td-accent) !important;
}
[data-testid="stProgress"] [data-testid="stProgressBarTrack"] {
  background: var(--td-bg-surface-3) !important;
  border-radius: var(--td-radius-full) !important;
}
[data-testid="stDataFrame"] {
  border-radius: var(--td-radius-md) !important;
  border: 1px solid var(--td-border) !important;
  overflow: hidden;
}

/* ============================================================
   Custom components — see ui/components.py
   ============================================================ */
.td-card {
  background: var(--td-bg-surface-2);
  border: 1px solid var(--td-border);
  border-radius: var(--td-radius-md);
  padding: var(--td-space-5);
  box-shadow: var(--td-elevation-1);
}

.td-kpi .td-kpi-label {
  font-size: 13px; color: var(--td-text-muted);
  text-transform: uppercase; letter-spacing: 0.03em;
}
.td-kpi .td-kpi-value {
  font-family: var(--td-font-mono); font-size: 28px; font-weight: 700;
  color: var(--td-text); margin-block: var(--td-space-1);
}
.td-kpi .td-kpi-delta { font-size: 13px; font-weight: 600; }
.td-kpi .td-kpi-delta.positive { color: var(--td-positive); }
.td-kpi .td-kpi-delta.negative { color: var(--td-negative); }

.td-badge {
  display: inline-flex; align-items: center; gap: var(--td-space-1);
  padding: var(--td-space-1) var(--td-space-3);
  border-radius: var(--td-radius-full);
  font-size: 12px; font-weight: 600; letter-spacing: 0.02em;
  white-space: nowrap;
}
.td-badge-low { background: var(--td-positive-soft-bg); color: var(--td-positive-soft-text); }
.td-badge-medium { background: var(--td-warning-soft-bg); color: var(--td-warning-soft-text); }
.td-badge-high { background: var(--td-severity-high-soft-bg); color: var(--td-severity-high-soft-text); }
.td-badge-critical { background: var(--td-negative-soft-bg); color: var(--td-negative-soft-text); }
.td-badge-neutral { background: var(--td-bg-surface-3); color: var(--td-text-muted); }

.td-empty-state {
  text-align: center; padding-block: var(--td-space-7);
  color: var(--td-text-faint);
}
.td-empty-state .td-empty-icon { font-size: 40px; opacity: 0.6; margin-bottom: var(--td-space-3); }
.td-empty-state .td-empty-title {
  font-size: 16px; font-weight: 600; color: var(--td-text-muted); margin-bottom: var(--td-space-2);
}
.td-empty-state .td-empty-desc {
  font-size: 13px; max-width: 360px; margin-inline: auto;
}

.td-skeleton {
  border-radius: var(--td-radius-md);
  background: linear-gradient(90deg,
    var(--td-bg-surface-3) 25%, var(--td-bg-surface-2) 37%, var(--td-bg-surface-3) 63%);
  background-size: 400% 100%;
  animation: td-shimmer 1.5s linear infinite;
}
@keyframes td-shimmer {
  0% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
</style>
"""


def inject_theme() -> None:
    """
    تزریق CSS تم مشترک. باید در همان چند خط ابتدای هر صفحه (app.py و هر
    فایل pages/*.py) صدا زده شود — دقیقاً همان الگویی که
    design/05_COMPONENT_INVENTORY.md و design/01_DESIGN_RATIONALE.md
    توضیح می‌دهند.
    """
    st.markdown(_THEME_CSS, unsafe_allow_html=True)
