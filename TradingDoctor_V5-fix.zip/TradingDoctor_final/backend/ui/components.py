# -*- coding: utf-8 -*-
"""
ui/components.py
--------------------
کتابخانه‌ی کامپوننت‌های مشترک Phase 5A — پیاده‌سازی مستقیم
design/03_COMPONENTS.md. هر تابع اینجا فقط HTML/CSS تولید می‌کند (از
توکن‌های ui/theme.py استفاده می‌کند)؛ هیچ محاسبه‌ی تحلیلی انجام نمی‌دهد
و هیچ داده‌ای را تغییر نمی‌دهد — فقط داده‌ی از قبل آماده (severity،
label، value) را قالب‌بندی می‌کند، دقیقاً همان اصل معماری‌ای که
reporting/ و api/ از فاز‌های قبل رعایت می‌کنند.
"""

import html
from typing import Optional

import streamlit as st

_SEVERITY_CLASS = {
    "Low": "td-badge-low",
    "Medium": "td-badge-medium",
    "High": "td-badge-high",
    "Critical": "td-badge-critical",
}


def severity_badge(severity: str, extra_label: Optional[str] = None) -> None:
    """
    نشان رنگی شدت — پیاده‌سازی مستقیم design/03_COMPONENTS.md §Badges.
    severity باید یکی از مقادیر واقعی موتور تحلیلی باشد: Low/Medium/
    High/Critical (همان‌طور که ContextBlock.severity/Evidence.severity
    از قبل تولید می‌کنند) — این تابع هیچ severity جدیدی اختراع نمی‌کند.
    """
    css_class = _SEVERITY_CLASS.get(severity, "td-badge-neutral")
    label = html.escape(extra_label or severity)
    st.markdown(
        f'<span class="td-badge {css_class}" role="status">{label}</span>',
        unsafe_allow_html=True,
    )


def tag(label: str) -> None:
    """برچسب خنثی (غیر severity) — design/03_COMPONENTS.md §Badges & Tags."""
    st.markdown(
        f'<span class="td-badge td-badge-neutral">{html.escape(label)}</span>',
        unsafe_allow_html=True,
    )


def kpi_card(label: str, value: str, delta: Optional[str] = None,
             delta_positive: Optional[bool] = None) -> None:
    """
    کارت KPI — design/03_COMPONENTS.md §KPI Widgets. جایگزین ریسپانسیو و
    هم‌برند st.metric برای مواردی که نیاز به رنگ‌بندی معنایی سفارشی
    (severity/semantic) دارند، نه یک جایگزین همه‌جانبه‌ی st.metric —
    برای معیارهای ساده‌ی بدون بار معنایی خاص، st.metric بومی همچنان
    گزینه‌ی معتبر و ساده‌تر است.
    """
    delta_html = ""
    if delta:
        cls = "positive" if delta_positive else "negative" if delta_positive is False else ""
        delta_html = f'<div class="td-kpi-delta {cls}">{html.escape(delta)}</div>'
    st.markdown(
        f"""
        <div class="td-card td-kpi">
          <div class="td-kpi-label">{html.escape(label)}</div>
          <div class="td-kpi-value">{html.escape(value)}</div>
          {delta_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def empty_state(title: str, description: str = "", icon: str = "📭") -> None:
    """
    وضعیت خالی مشترک — design/03_COMPONENTS.md §Empty States. رفع مستقیم
    یافته‌ی #7 در design/00_UI_AUDIT.md (مدیریت موردی و ناهمسان حالت
    بدون‌داده در هر صفحه).
    """
    desc_html = f'<div class="td-empty-desc">{html.escape(description)}</div>' if description else ""
    st.markdown(
        f"""
        <div class="td-empty-state" role="status">
          <div class="td-empty-icon" aria-hidden="true">{icon}</div>
          <div class="td-empty-title">{html.escape(title)}</div>
          {desc_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def skeleton(height: str = "80px", count: int = 1) -> None:
    """
    اسکلتون بارگذاری — design/03_COMPONENTS.md §Loading States. عمداً
    CSS خالص است، نه st.skeleton بومی (که تنها از Streamlit 1.59.0
    موجود است — نسخه‌ی فعلی نصب‌شده، نه محدوده‌ی تضمین‌شده‌ی
    requirements.txt که >=1.30 است). جزئیات تصمیم در
    design/05_COMPONENT_INVENTORY.md.
    """
    blocks = "".join(
        f'<div class="td-skeleton" style="height:{height}; margin-bottom: var(--td-space-3);" '
        f'aria-hidden="true"></div>'
        for _ in range(count)
    )
    st.markdown(
        f'<div aria-busy="true" aria-live="polite">{blocks}</div>',
        unsafe_allow_html=True,
    )


def card_html(inner_html: str) -> None:
    """پوشش کارت خام برای ترکیب با محتوای دیگر — design/03_COMPONENTS.md §Cards."""
    st.markdown(f'<div class="td-card">{inner_html}</div>', unsafe_allow_html=True)
