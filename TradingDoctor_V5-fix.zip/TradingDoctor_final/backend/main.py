# -*- coding: utf-8 -*-
"""
main.py - نقطه ورود CLI Trading Doctor V23
"""
import sys
import argparse

from core.service import analyze_file
from engines.report_engine import ReportEngine
from reporting import generate_html_report, generate_pdf_report, ReportRenderError
from utils.file_loader import UnsupportedFileError
from utils.validation import DataValidationError
from utils.logger import get_logger

log = get_logger("cli")


def main():
    parser = argparse.ArgumentParser(description="Trading Doctor V23")
    parser.add_argument(
        "file_path",
        help="مسیر فایل معاملات (csv, xlsx, xls, htm, html, log, json, txt)",
    )
    parser.add_argument(
        "--llm", choices=["gemini", "openai", "claude", "none"], default="gemini",
        help="کدام provider LLM استفاده شود (یا 'none' برای fallback هیوریستیک)",
    )
    parser.add_argument(
        "--export-html", metavar="PATH", default=None,
        help="گزارش HTML کامل (Phase 2) را در این مسیر ذخیره کن",
    )
    parser.add_argument(
        "--export-pdf", metavar="PATH", default=None,
        help="گزارش PDF کامل (Phase 2) را در این مسیر ذخیره کن",
    )
    args = parser.parse_args()

    try:
        doctor, result, coach = analyze_file(args.file_path, llm_provider=args.llm)
        print(f"✅ فایل با {len(doctor.df)} معامله لود و تحلیل شد.")

        warnings = getattr(doctor, "data_quality_warnings", [])
        if warnings:
            print(f"⚠️  {len(warnings)} هشدار کیفیت داده:")
            for w in warnings:
                print(f"   - {w}")

        ReportEngine(result, coach).print_report()

        # [Phase 2] صادرات اختیاری گزارش HTML/PDF از همان pipeline
        # استفاده‌شده در Streamlit (pages/08_Report.py) — برای اسکریپت‌های
        # اتوماسیون/CI که نیاز به خروجی فایل دارند، بدون رابط کاربری.
        if args.export_html:
            try:
                html = generate_html_report(result, coach, doctor)
                with open(args.export_html, "w", encoding="utf-8") as f:
                    f.write(html)
                print(f"✅ گزارش HTML ذخیره شد: {args.export_html}")
            except ReportRenderError as e:
                log.error("HTML export failed: %s", e)
                print(f"❌ ساخت گزارش HTML با خطا مواجه شد: {e}")
                sys.exit(1)
            except OSError as e:
                # [AUDIT FIX — self-review regression found] این OSError
                # (مثلاً پوشه‌ی مقصد وجود ندارد) قبلاً توسط except
                # FileNotFoundError بیرونی (که برای «فایل ورودی پیدا نشد»
                # نوشته شده بود) اشتباهی گرفته می‌شد و پیام گمراه‌کننده‌ای
                # نشان می‌داد («فایل ورودی پیدا نشد») درحالی‌که مشکل واقعی
                # مسیر خروجی بود. حالا جداگانه و با پیام دقیق مدیریت می‌شود.
                log.error("Failed to write HTML export to '%s': %s", args.export_html, e)
                print(f"❌ نوشتن فایل HTML در مسیر «{args.export_html}» ممکن نشد: {e}")
                sys.exit(1)

        if args.export_pdf:
            try:
                pdf_bytes = generate_pdf_report(result, coach, doctor)
                with open(args.export_pdf, "wb") as f:
                    f.write(pdf_bytes)
                print(f"✅ گزارش PDF ذخیره شد: {args.export_pdf}")
            except ReportRenderError as e:
                log.error("PDF export failed: %s", e)
                print(f"❌ ساخت گزارش PDF با خطا مواجه شد: {e}")
                sys.exit(1)
            except OSError as e:
                log.error("Failed to write PDF export to '%s': %s", args.export_pdf, e)
                print(f"❌ نوشتن فایل PDF در مسیر «{args.export_pdf}» ممکن نشد: {e}")
                sys.exit(1)

    except FileNotFoundError:
        log.warning("File not found: %s", args.file_path)
        print(f"❌ فایل پیدا نشد: {args.file_path}")
        sys.exit(1)
    except UnsupportedFileError as e:
        log.warning("Unsupported file: %s", e)
        print(f"❌ فرمت یا محتوای فایل قابل‌پردازش نیست: {e}")
        sys.exit(1)
    except DataValidationError as e:
        log.warning("Data validation failed: %s", e)
        print(f"❌ داده‌ی فایل معتبر نیست: {e}")
        sys.exit(1)
    except Exception as e:
        # [AUDIT FIX] Step 5: هرگز traceback خام برای کاربر نهایی چاپ
        # نمی‌شود؛ جزئیات کامل با exc_info=True فقط در لاگ ثبت می‌شود.
        log.error("Unexpected error while analyzing '%s'", args.file_path, exc_info=True)
        print(f"❌ خطای غیرمنتظره: {type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
