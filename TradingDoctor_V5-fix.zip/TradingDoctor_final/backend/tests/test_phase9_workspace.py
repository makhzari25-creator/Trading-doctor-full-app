# -*- coding: utf-8 -*-
"""tests/test_phase9_workspace.py — Phase 9 persistent workspace tests.

Tests cover:
  - Repository pattern: uploads, analyses, favorites
  - Multi-tenant isolation (user A cannot see user B's data)
  - Storage abstraction (local FS path traversal protection)
  - Serialization round-trip (pickle + zlib)
  - Report cache (HTML + PDF cached after first render)
  - Workspace endpoints (summary, list with filter/sort, favorites lifecycle)
  - Soft-delete + restoration semantics
  - Engine immutability (workspace/ never imports engines/)
"""

from __future__ import annotations

import asyncio
import io
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import pandas as pd
import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Env setup (shared with test_phase8_auth.py + test_api.py)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _setup_test_env():
    os.environ["JWT_SECRET_KEY"] = "a" * 64
    os.environ["JWT_REFRESH_SECRET_KEY"] = "b" * 64
    os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ["TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY"] = "false"
    os.environ["EMAIL_BACKEND"] = "console"

    import importlib
    import db.base
    importlib.reload(db.base)
    import auth.config
    importlib.reload(auth.config)
    import auth.models
    importlib.reload(auth.models)
    import workspace.models
    import billing.models
    importlib.reload(billing.models)
    importlib.reload(workspace.models)
    yield


@pytest_asyncio.fixture
async def db_engine(_setup_test_env, tmp_path):
    import db.base
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file}")
    import auth.models  # noqa: F401
    import workspace.models  # noqa: F401
    import billing.models  # noqa: F401
    async with engine.begin() as conn:
        await conn.run_sync(db.base.Base.metadata.create_all)

    # Phase 10: seed billing plans.
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
    seed_factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with seed_factory() as session:
        from billing.services.plans import seed_plans
        await seed_plans(session)
        await session.commit()

    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncIterator[AsyncSession]:
    factory = async_sessionmaker(
        bind=db_engine, class_=AsyncSession,
        expire_on_commit=False, autoflush=False,
    )
    async with factory() as session:
        try:
            yield session
        finally:
            await session.close()


def _sample_csv_bytes(n=50, seed=1):
    import numpy as np
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=n, freq="90min"),
        "Profit": rng.normal(0, 20, n).round(2),
        "Size": abs(rng.normal(1, 0.3, n)).round(2),
    })
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


async def _create_user(db, email: str = "test@example.com"):
    """Helper: create + verify a user, return the User object."""
    from auth.services.users import create_user, verify_email
    user = await create_user(db=db, email=email, password="StrongPass123")
    user = await verify_email(db, user.id)
    await db.commit()
    return user


# ---------------------------------------------------------------------------
# Storage backend tests
# ---------------------------------------------------------------------------

class TestStorageBackend:
    @pytest.mark.asyncio
    async def test_local_backend_save_load_roundtrip(self, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.services.storage import LocalStorageBackend

        backend = LocalStorageBackend()
        await backend.save("user1/file.csv", b"hello world")
        data = await backend.load("user1/file.csv")
        assert data == b"hello world"

    @pytest.mark.asyncio
    async def test_local_backend_rejects_path_traversal(self, tmp_path, monkeypatch):
        """Path traversal must be rejected — security critical."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.services.storage import LocalStorageBackend

        backend = LocalStorageBackend()
        with pytest.raises(ValueError, match="escapes storage root"):
            await backend.save("../../etc/passwd", b"malicious")

    @pytest.mark.asyncio
    async def test_local_backend_rejects_absolute_paths(self, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.services.storage import LocalStorageBackend

        backend = LocalStorageBackend()
        with pytest.raises(ValueError, match="Absolute paths not allowed"):
            await backend.save("/etc/passwd", b"malicious")

    @pytest.mark.asyncio
    async def test_local_backend_delete(self, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.services.storage import LocalStorageBackend

        backend = LocalStorageBackend()
        await backend.save("file.txt", b"data")
        assert await backend.exists("file.txt") is True
        assert await backend.delete("file.txt") is True
        assert await backend.exists("file.txt") is False
        # Delete again returns False
        assert await backend.delete("file.txt") is False

    @pytest.mark.asyncio
    async def test_local_backend_load_missing_raises(self, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.services.storage import LocalStorageBackend

        backend = LocalStorageBackend()
        with pytest.raises(FileNotFoundError):
            await backend.load("nonexistent.csv")


# ---------------------------------------------------------------------------
# Serialization tests
# ---------------------------------------------------------------------------

class TestSerialization:
    def test_serialize_deserialize_roundtrip(self):
        """Pickle + zlib round-trip preserves the original object."""
        from workspace.services.serialization import (
            serialize_engine_outputs,
            deserialize_engine_outputs,
        )

        # Use plain Python objects (the engine's actual types are tested
        # implicitly via the full API tests in test_api.py).
        doctor = {"scores": [1, 2, 3], "df_summary": "100 rows"}
        result = {"behavior": "good", "scores": {"discipline": 75}}
        coach = {"diagnosis": "revenge_trading", "action_plan": ["step1", "step2"]}

        d_bytes, r_bytes, c_bytes = serialize_engine_outputs(doctor, result, coach)
        d_back, r_back, c_back = deserialize_engine_outputs(d_bytes, r_bytes, c_bytes)

        assert d_back == doctor
        assert r_back == result
        assert c_back == coach

    def test_serialized_bytes_are_compressed(self):
        """Compression should significantly reduce size for repetitive data."""
        from workspace.services.serialization import (
            serialize_engine_outputs,
            _pickle_zlib,
        )
        import pickle

        repetitive = {"data": ["same"] * 1000}
        raw = pickle.dumps(repetive := repetitive, protocol=4)
        compressed = _pickle_zlib(repetitive)
        # Compressed should be much smaller than raw
        assert len(compressed) < len(raw) / 2


# ---------------------------------------------------------------------------
# Upload repository tests
# ---------------------------------------------------------------------------

class TestUploadRepository:
    @pytest.mark.asyncio
    async def test_create_upload_persists_file_and_record(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload, get_upload_by_id

        user = await _create_user(db_session, "up@example.com")
        raw = _sample_csv_bytes()

        upload = await create_upload(
            db=db_session,
            user_id=user.id,
            filename="trades.csv",
            raw_bytes=raw,
        )
        await db_session.commit()

        assert upload.id is not None
        assert upload.filename == "trades.csv"
        assert upload.size_bytes == len(raw)
        assert upload.content_hash  # SHA-256
        assert upload.file_type == "csv"

        # Re-fetch
        fetched = await get_upload_by_id(db_session, user.id, upload.id)
        assert fetched.id == upload.id

    @pytest.mark.asyncio
    async def test_get_upload_isolates_by_user(self, db_session, tmp_path, monkeypatch):
        """User A cannot fetch User B's upload."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload, get_upload_by_id
        from api.exceptions import UploadNotFoundError

        user_a = await _create_user(db_session, "a@example.com")
        user_b = await _create_user(db_session, "b@example.com")

        upload_a = await create_upload(
            db=db_session, user_id=user_a.id,
            filename="a.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()

        # User B tries to fetch User A's upload → not found
        with pytest.raises(UploadNotFoundError):
            await get_upload_by_id(db_session, user_b.id, upload_a.id)

    @pytest.mark.asyncio
    async def test_list_uploads_pagination(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload, list_uploads

        user = await _create_user(db_session, "list@example.com")
        for i in range(5):
            await create_upload(
                db=db_session, user_id=user.id,
                filename=f"t{i}.csv", raw_bytes=_sample_csv_bytes(seed=i),
            )
        await db_session.commit()

        items, total = await list_uploads(db_session, user.id, page=1, page_size=3)
        assert total == 5
        assert len(items) == 3

        items2, total2 = await list_uploads(db_session, user.id, page=2, page_size=3)
        assert total2 == 5
        assert len(items2) == 2

    @pytest.mark.asyncio
    async def test_soft_delete_upload(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import (
            create_upload, soft_delete_upload, get_upload_by_id, count_user_uploads,
        )
        from api.exceptions import UploadNotFoundError

        user = await _create_user(db_session, "del@example.com")
        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="t.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        assert await count_user_uploads(db_session, user.id) == 1

        await soft_delete_upload(db_session, user.id, upload.id)
        await db_session.commit()

        # Now invisible
        with pytest.raises(UploadNotFoundError):
            await get_upload_by_id(db_session, user.id, upload.id)
        # Count excludes soft-deleted
        assert await count_user_uploads(db_session, user.id) == 0

    @pytest.mark.asyncio
    async def test_rename_upload(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload, rename_upload

        user = await _create_user(db_session, "rn@example.com")
        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="original.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()

        renamed = await rename_upload(db_session, user.id, upload.id, "My Custom Label")
        await db_session.commit()
        assert renamed.label == "My Custom Label"
        # Filename unchanged
        assert renamed.filename == "original.csv"

    @pytest.mark.asyncio
    async def test_total_user_upload_bytes(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import (
            create_upload, total_user_upload_bytes,
        )

        user = await _create_user(db_session, "quota@example.com")
        raw = _sample_csv_bytes()
        await create_upload(db=db_session, user_id=user.id, filename="a.csv", raw_bytes=raw)
        await create_upload(db=db_session, user_id=user.id, filename="b.csv", raw_bytes=raw)
        await db_session.commit()

        total = await total_user_upload_bytes(db_session, user.id)
        assert total == 2 * len(raw)


# ---------------------------------------------------------------------------
# Analysis repository tests
# ---------------------------------------------------------------------------

class TestAnalysisRepository:
    @pytest.mark.asyncio
    async def test_run_and_persist_analysis(self, db_session, tmp_path, monkeypatch):
        """End-to-end: upload → analyze → persist → retrieve."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, get_analysis_by_id, get_engine_outputs,
        )

        user = await _create_user(db_session, "ana@example.com")
        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="trades.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()

        # Run analysis
        analysis = await run_and_persist_analysis(
            db=db_session, user_id=user.id,
            upload_id=upload.id, llm_provider="none",
        )
        await db_session.commit()

        assert analysis.id is not None
        assert analysis.total_trades == 50
        assert analysis.overall_score >= 0
        assert analysis.engine_doctor_bytes  # non-empty
        assert analysis.engine_result_bytes
        assert analysis.engine_coach_bytes

        # Re-fetch
        fetched = await get_analysis_by_id(db_session, user.id, analysis.id)
        assert fetched.id == analysis.id

        # Load engine outputs back
        doctor, result, coach = await get_engine_outputs(db_session, user.id, analysis.id)
        assert doctor is not None
        assert result is not None
        assert coach is not None
        # The engine's BehaviorEngine has a df attribute
        assert hasattr(doctor, "df")
        assert len(doctor.df) == 50

    @pytest.mark.asyncio
    async def test_get_analysis_isolates_by_user(self, db_session, tmp_path, monkeypatch):
        """User B cannot fetch User A's analysis."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, get_analysis_by_id,
        )
        from api.exceptions import AnalysisNotFoundError

        user_a = await _create_user(db_session, "aa@example.com")
        user_b = await _create_user(db_session, "bb@example.com")

        upload_a = await create_upload(
            db=db_session, user_id=user_a.id,
            filename="a.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        analysis_a = await run_and_persist_analysis(
            db=db_session, user_id=user_a.id,
            upload_id=upload_a.id, llm_provider="none",
        )
        await db_session.commit()

        # User B cannot fetch
        with pytest.raises(AnalysisNotFoundError):
            await get_analysis_by_id(db_session, user_b.id, analysis_a.id)

    @pytest.mark.asyncio
    async def test_list_analyses_with_search(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, list_analyses,
        )

        user = await _create_user(db_session, "search@example.com")
        for name in ["alpha.csv", "beta.csv", "alpha_v2.csv"]:
            upload = await create_upload(
                db=db_session, user_id=user.id,
                filename=name, raw_bytes=_sample_csv_bytes(),
            )
            await db_session.commit()
            await run_and_persist_analysis(
                db=db_session, user_id=user.id,
                upload_id=upload.id, llm_provider="none",
            )
            await db_session.commit()

        # Search for "alpha"
        items, total = await list_analyses(db_session, user.id, search="alpha")
        assert total == 2  # alpha.csv + alpha_v2.csv

    @pytest.mark.asyncio
    async def test_list_analyses_sort_by_score(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, list_analyses,
        )

        user = await _create_user(db_session, "sort@example.com")
        # Different seeds → different scores
        for seed in [1, 2, 3, 4, 5]:
            upload = await create_upload(
                db=db_session, user_id=user.id,
                filename=f"t{seed}.csv", raw_bytes=_sample_csv_bytes(seed=seed),
            )
            await db_session.commit()
            await run_and_persist_analysis(
                db=db_session, user_id=user.id,
                upload_id=upload.id, llm_provider="none",
            )
            await db_session.commit()

        # Sort by score descending
        items, total = await list_analyses(
            db_session, user.id, sort_by="overall_score", sort_order="desc",
        )
        assert total == 5
        scores = [i.overall_score for i in items]
        assert scores == sorted(scores, reverse=True)

    @pytest.mark.asyncio
    async def test_list_analyses_filter_by_score_range(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, list_analyses,
        )

        user = await _create_user(db_session, "filter@example.com")
        for seed in [1, 2, 3, 4, 5]:
            upload = await create_upload(
                db=db_session, user_id=user.id,
                filename=f"t{seed}.csv", raw_bytes=_sample_csv_bytes(seed=seed),
            )
            await db_session.commit()
            await run_and_persist_analysis(
                db=db_session, user_id=user.id,
                upload_id=upload.id, llm_provider="none",
            )
            await db_session.commit()

        # Filter: score >= 0 (all should match)
        items, total = await list_analyses(db_session, user.id, min_score=0)
        assert total == 5

        # Filter: score > 200 (none should match — discipline is 0-100)
        items2, total2 = await list_analyses(db_session, user.id, min_score=200)
        assert total2 == 0


# ---------------------------------------------------------------------------
# Favorite repository tests
# ---------------------------------------------------------------------------

class TestFavoriteRepository:
    @pytest.mark.asyncio
    async def test_add_and_remove_favorite(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import run_and_persist_analysis
        from workspace.repositories.favorites import (
            add_favorite, remove_favorite, is_favorite, count_favorites,
        )

        user = await _create_user(db_session, "fav@example.com")
        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="t.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        analysis = await run_and_persist_analysis(
            db=db_session, user_id=user.id,
            upload_id=upload.id, llm_provider="none",
        )
        await db_session.commit()

        # Initially not favorited
        assert await is_favorite(db_session, user.id, analysis.id) is False
        assert await count_favorites(db_session, user.id) == 0

        # Add favorite
        await add_favorite(db_session, user.id, analysis.id, note="test")
        await db_session.commit()
        assert await is_favorite(db_session, user.id, analysis.id) is True
        assert await count_favorites(db_session, user.id) == 1

        # Adding again is idempotent (doesn't create duplicate)
        await add_favorite(db_session, user.id, analysis.id)
        await db_session.commit()
        assert await count_favorites(db_session, user.id) == 1

        # Remove
        await remove_favorite(db_session, user.id, analysis.id)
        await db_session.commit()
        assert await is_favorite(db_session, user.id, analysis.id) is False
        assert await count_favorites(db_session, user.id) == 0

    @pytest.mark.asyncio
    async def test_favorite_isolates_by_user(self, db_session, tmp_path, monkeypatch):
        """User B cannot favorite User A's analysis."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import run_and_persist_analysis
        from workspace.repositories.favorites import add_favorite
        from api.exceptions import AnalysisNotFoundError

        user_a = await _create_user(db_session, "fa@example.com")
        user_b = await _create_user(db_session, "fb@example.com")

        upload_a = await create_upload(
            db=db_session, user_id=user_a.id,
            filename="a.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        analysis_a = await run_and_persist_analysis(
            db=db_session, user_id=user_a.id,
            upload_id=upload_a.id, llm_provider="none",
        )
        await db_session.commit()

        # User B tries to favorite User A's analysis → not found
        with pytest.raises(AnalysisNotFoundError):
            await add_favorite(db_session, user_b.id, analysis_a.id)


# ---------------------------------------------------------------------------
# Report cache tests
# ---------------------------------------------------------------------------

class TestReportCache:
    @pytest.mark.asyncio
    async def test_cache_miss_then_hit(self, db_session, tmp_path, monkeypatch):
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, get_cached_report, save_cached_report,
        )

        user = await _create_user(db_session, "cache@example.com")
        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="t.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        analysis = await run_and_persist_analysis(
            db=db_session, user_id=user.id,
            upload_id=upload.id, llm_provider="none",
        )
        await db_session.commit()

        # Cache miss
        cached = await get_cached_report(db_session, user.id, analysis.id, "html")
        assert cached is None

        # Save to cache
        await save_cached_report(db_session, user.id, analysis.id, "html", b"<html>cached</html>")
        await db_session.commit()

        # Cache hit
        cached = await get_cached_report(db_session, user.id, analysis.id, "html")
        assert cached == b"<html>cached</html>"

    @pytest.mark.asyncio
    async def test_cache_isolates_by_user(self, db_session, tmp_path, monkeypatch):
        """User B cannot read User A's cached report."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "API_DATA_DIR", str(tmp_path))
        from workspace.repositories.uploads import create_upload
        from workspace.repositories.analyses import (
            run_and_persist_analysis, get_cached_report, save_cached_report,
        )
        from api.exceptions import AnalysisNotFoundError

        user_a = await _create_user(db_session, "ca@example.com")
        user_b = await _create_user(db_session, "cb@example.com")

        upload_a = await create_upload(
            db=db_session, user_id=user_a.id,
            filename="a.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()
        analysis_a = await run_and_persist_analysis(
            db=db_session, user_id=user_a.id,
            upload_id=upload_a.id, llm_provider="none",
        )
        await db_session.commit()
        await save_cached_report(db_session, user_a.id, analysis_a.id, "html", b"<html>A</html>")
        await db_session.commit()

        # User B tries to read → not found (because analysis belongs to A)
        with pytest.raises(AnalysisNotFoundError):
            await get_cached_report(db_session, user_b.id, analysis_a.id, "html")


# ---------------------------------------------------------------------------
# Engine immutability check (Phase 9 extension)
# ---------------------------------------------------------------------------

class TestEngineImmutability:
    def test_workspace_layer_does_not_import_engines(self):
        """The workspace/ layer must NOT import any frozen V23 engine module."""
        import inspect
        import workspace
        from workspace.repositories import analyses, favorites, uploads
        from workspace.routers import workspace as workspace_router
        from workspace.services import serialization, storage
        from workspace.models import Upload, Analysis, Favorite, AnalysisReportCache

        modules_to_check = [
            workspace, analyses, favorites, uploads, workspace_router,
            serialization, storage,
        ]
        for mod in modules_to_check:
            src = inspect.getsource(mod)
            assert "from engines" not in src, \
                f"{mod.__name__} must not import from engines/"
            assert "import engines" not in src, \
                f"{mod.__name__} must not import engines/"

    def test_only_engine_call_is_in_analyses_repository(self):
        """The ONLY call to the engine must be in workspace.repositories.analyses.

        This is the single integration point — the engine contract is preserved
        by keeping all engine calls in one place that's easy to audit.
        """
        import inspect
        from workspace.repositories import analyses
        src = inspect.getsource(analyses)

        # Count actual CALLS (lines with `analyze_dataframe(`), not mentions
        # in docstrings or comments.
        call_lines = [
            line for line in src.split("\n")
            if "analyze_dataframe(" in line
            and not line.strip().startswith("#")
            and not line.strip().startswith('"""')
            and "`" not in line  # exclude docstring backticks
        ]
        assert len(call_lines) == 1, \
            f"analyze_dataframe must be called exactly once in workspace.repositories.analyses; found {len(call_lines)}"
