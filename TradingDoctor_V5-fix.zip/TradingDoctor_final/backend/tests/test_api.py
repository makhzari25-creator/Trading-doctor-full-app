# -*- coding: utf-8 -*-
"""
tests/test_api.py
---------------------
Phase 3 → Phase 9 migration.

The original Phase 3 tests assumed:
  - No DB required (in-memory store)
  - No user auth (anonymous uploads)
  - API key auth (X-API-Key header)

Phase 9 changes:
  - DB REQUIRED (PostgreSQL or SQLite for tests)
  - User auth REQUIRED (JWT access token via Authorization: Bearer)
  - API key auth still works for service-to-service, but uploads/analyses
    require a real user (the upload must belong to someone)

This file is the Phase 9 version of the API tests. It:
  1) Sets up an in-memory SQLite DB + auth env (same as test_phase8_auth.py)
  2) Registers + verifies a test user via the API
  3) Runs the original full-flow test (upload → analyze → report → history)
     using the new auth flow
  4) Tests HTTP error codes (404, 413, 422, 429, 401) under the new auth
  5) Tests that the unified error envelope still works
  6) Tests rate limiting
  7) Tests multi-tenant isolation (user A cannot see user B's data)
  8) Tests that no business logic is duplicated in the API layer
"""

import io
import os
import sys
import uuid
from pathlib import Path
from typing import AsyncIterator

import pandas as pd
import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

# Ensure project root on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Test setup: env + DB (shared with test_phase8_auth.py)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _setup_test_env():
    """Set auth secrets + SQLite DB URL for the whole test session."""
    os.environ["JWT_SECRET_KEY"] = "a" * 64
    os.environ["JWT_REFRESH_SECRET_KEY"] = "b" * 64
    os.environ["JWT_ALGORITHM"] = "HS256"
    os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ["TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY"] = "false"
    os.environ["EMAIL_BACKEND"] = "console"

    import importlib
    import db.base
    importlib.reload(db.base)
    import auth.config
    importlib.reload(auth.config)
    import auth.models
    importlib.reload(auth.models)
    import workspace.models
    import billing.models
    importlib.reload(billing.models)
    importlib.reload(workspace.models)

    yield


@pytest_asyncio.fixture
async def db_engine(_setup_test_env, tmp_path):
    """Fresh SQLite DB per test."""
    import db.base
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file}")
    import auth.models  # noqa: F401
    import workspace.models  # noqa: F401
    import billing.models  # noqa: F401
    async with engine.begin() as conn:
        await conn.run_sync(db.base.Base.metadata.create_all)

    # Phase 10: seed billing plans so subscriptions can be auto-assigned.
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
    seed_factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with seed_factory() as session:
        from billing.services.plans import seed_plans
        await seed_plans(session)
        await session.commit()

    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def app_with_db(db_engine, monkeypatch):
    """FastAPI app wired to the test DB.

    Relies on db.base.get_db reading `async_session_factory` lazily at call
    time (see db/base.py). So we just monkeypatch the module-level factory
    + engine; no FastAPI dependency_overrides needed.
    """
    import db.base
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

    factory = async_sessionmaker(
        bind=db_engine, class_=AsyncSession,
        expire_on_commit=False, autoflush=False,
    )
    monkeypatch.setattr(db.base, "engine", db_engine)
    monkeypatch.setattr(db.base, "async_session_factory", factory)

    from api.main import app
    app.dependency_overrides.clear()
    app._test_db_factory = factory  # type: ignore[attr-defined]

    yield app

    app.dependency_overrides.clear()


def _register_and_verify(app, client, email: str, password: str = "StrongPass123") -> str:
    """Register + verify a user. Returns the user_id."""
    import asyncio
    factory = app._test_db_factory  # type: ignore[attr-defined]

    r = client.post("/api/v1/auth/register", json={
        "email": email, "password": password,
    })
    assert r.status_code == 201, r.text
    user_id = r.json()["user_id"]

    async def _verify():
        from auth.services.users import verify_email
        async with factory() as session:
            await verify_email(session, uuid.UUID(user_id))
            await session.commit()
    asyncio.run(_verify())

    return user_id


def _login(client, email: str, password: str = "StrongPass123") -> str:
    """Login + return access token."""
    r = client.post("/api/v1/auth/login", json={
        "email": email, "password": password,
    })
    assert r.status_code == 200, r.text
    return r.json()["tokens"]["access_token"]


# ---------------------------------------------------------------------------
# Sample data
# ---------------------------------------------------------------------------

def _sample_csv_bytes(n=100, seed=1, with_side=False):
    import numpy as np
    rng = np.random.default_rng(seed)
    data = {
        "Open Time": pd.date_range("2024-01-01", periods=n, freq="90min"),
        "Profit": rng.normal(0, 20, n).round(2),
        "Size": abs(rng.normal(1, 0.3, n)).round(2),
    }
    if with_side:
        # A genuine direction column (as some real broker exports provide,
        # e.g. MT4/MT5 "Type"), so the trades/side filter has real data to
        # filter on — this pipeline's standard 3-column format (Open Time/
        # Profit/Size, above) never has direction info at all.
        data["Type"] = rng.choice(["buy", "sell"], size=n)
    df = pd.DataFrame(data)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_health_check(app_with_db):
    with TestClient(app_with_db) as client:
        r = client.get("/api/v1/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert body["engine_ready"] is True


def test_config_endpoint_no_secrets_leaked(app_with_db):
    with TestClient(app_with_db) as client:
        r = client.get("/api/v1/config")
        assert r.status_code == 200
        body = r.json()
        assert "api_key" not in str(body).lower()
        assert "disk" not in str(body).lower()


def test_full_flow_upload_analyze_report_history(app_with_db):
    """Full request lifecycle: upload → analyze → JSON/HTML/PDF report → history."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "flow@example.com")
        token = _login(client, "flow@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        # Upload
        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        assert r.status_code == 201, r.text
        upload_id = r.json()["upload_id"]

        # Analyze
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        assert r.status_code == 201, r.text
        analysis_id = r.json()["analysis_id"]
        assert r.json()["total_trades"] == 100

        # Get summary
        r = client.get(f"/api/v1/analyses/{analysis_id}", headers=headers)
        assert r.status_code == 200

        # Get JSON report
        r = client.get(f"/api/v1/analyses/{analysis_id}/report", headers=headers)
        assert r.status_code == 200
        report = r.json()
        for key in ["meta", "executive_summary", "overall_score", "diagnosis", "trader_profile",
                    "strengths", "weaknesses", "behavior_analysis", "psychology", "evidence",
                    "statistics", "performance", "risk", "recommendations", "ai_coaching", "appendix"]:
            assert key in report, f"missing section: {key}"

        # Get HTML report
        r = client.get(f"/api/v1/analyses/{analysis_id}/report.html", headers=headers)
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/html")

        # Get PDF report
        r = client.get(f"/api/v1/analyses/{analysis_id}/report.pdf", headers=headers)
        assert r.status_code == 200
        assert r.content[:5] == b"%PDF-"

        # History
        r = client.get("/api/v1/history", headers=headers)
        assert r.status_code == 200
        assert r.json()["total"] == 1
        assert r.json()["items"][0]["analysis_id"] == analysis_id


def test_analysis_not_found_returns_404_unified_envelope(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "nf@example.com")
        token = _login(client, "nf@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        # Valid UUID format but doesn't exist
        r = client.get(f"/api/v1/analyses/{uuid.uuid4()}", headers=headers)
        assert r.status_code == 404
        assert "error" in r.json()
        assert r.json()["error"]["code"] == "analysis_not_found"


def test_upload_not_found_when_running_analysis(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "unf@example.com")
        token = _login(client, "unf@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/analyses",
                        json={"upload_id": str(uuid.uuid4()), "llm_provider": "none"},
                        headers=headers)
        assert r.status_code == 404
        assert r.json()["error"]["code"] == "upload_not_found"


def test_request_validation_error_uses_unified_envelope(app_with_db):
    """RequestValidationError must use the unified error envelope (not FastAPI default)."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "val@example.com")
        token = _login(client, "val@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/analyses",
                        json={"llm_provider": "not_a_real_provider"},
                        headers=headers)
        assert r.status_code == 422
        body = r.json()
        assert "error" in body
        assert body["error"]["code"] == "request_validation_error"
        assert "detail" not in body


def test_invalid_csv_content_returns_422(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "bad@example.com")
        token = _login(client, "bad@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        bad_csv = b"Name,City\nAlice,Paris\nBob,Berlin\n"
        r = client.post("/api/v1/uploads",
                        files={"file": ("bad.csv", bad_csv, "text/csv")},
                        headers=headers)
        assert r.status_code == 201
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        assert r.status_code == 422
        assert r.json()["error"]["code"] == "invalid_data"


def test_file_too_large_returns_413(app_with_db, monkeypatch):
    from api import config as api_config
    monkeypatch.setattr(api_config, "MAX_UPLOAD_SIZE_BYTES", 100)

    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "big@example.com")
        token = _login(client, "big@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        assert r.status_code == 413
        assert r.json()["error"]["code"] == "file_too_large"


def test_uploads_require_authentication(app_with_db):
    """Without a Bearer token, uploads must fail with 401."""
    with TestClient(app_with_db) as client:
        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")})
        assert r.status_code == 401


def test_health_endpoint_does_not_require_auth(app_with_db):
    """Health must always work without auth (liveness probe is public)."""
    with TestClient(app_with_db) as client:
        r = client.get("/api/v1/health")
        assert r.status_code == 200


def test_rate_limit_enforced(app_with_db, monkeypatch):
    from api import config as api_config
    from api import dependencies as api_deps
    # Explicitly enable rate limiting for THIS test (conftest disables it globally
    # to prevent cross-test interference).
    monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", True)
    monkeypatch.setattr(api_config, "RATE_LIMIT_REQUESTS_PER_MINUTE", 3)
    monkeypatch.setattr(api_deps, "_rate_limiter", api_deps._SlidingWindowRateLimiter(3))

    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "rl@example.com")
        token = _login(client, "rl@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        statuses = []
        for _ in range(5):
            r = client.post("/api/v1/uploads",
                            files={"file": ("t.csv", _sample_csv_bytes(), "text/csv")},
                            headers=headers)
            statuses.append(r.status_code)
        assert statuses[:3] == [201, 201, 201]
        assert 429 in statuses[3:]


def test_openapi_schema_has_no_leaked_internals(app_with_db):
    with TestClient(app_with_db) as client:
        import json
        spec_str = json.dumps(client.get("/openapi.json").json())
        for leak in ["API_DATA_DIR", "/home/", "/mnt/", "disk_path"]:
            assert leak not in spec_str, f"OpenAPI schema leaks internal detail: {leak!r}"


def test_no_business_logic_duplicated_in_api_layer():
    """Static check: no api/*.py file may import a frozen V23 engine class."""
    import pathlib
    forbidden = ["BehaviorEngine", "ScoreEngine", "EvidenceEngine",
                 "DiagnosisEngine", "PsychologyEngine"]
    api_dir = pathlib.Path(__file__).parent.parent / "api"
    for py_file in api_dir.rglob("*.py"):
        content = py_file.read_text(encoding="utf-8")
        for name in forbidden:
            assert name not in content, \
                f"{py_file} references engine class {name} directly — business logic leak"


def test_workspace_layer_does_not_import_engines():
    """Phase 9 extension: the workspace/ layer must NOT import engines/."""
    import inspect
    import workspace
    from workspace.repositories import analyses, favorites, uploads
    from workspace.routers import workspace as workspace_router
    from workspace.services import serialization, storage

    for mod in [workspace, analyses, favorites, uploads, workspace_router,
                serialization, storage]:
        src = inspect.getsource(mod)
        assert "from engines" not in src, f"{mod.__name__} must not import from engines/"
        assert "import engines" not in src, f"{mod.__name__} must not import engines/"


# ---------------------------------------------------------------------------
# Phase 9 multi-tenant isolation tests
# ---------------------------------------------------------------------------

def test_user_cannot_access_another_users_analysis(app_with_db):
    """User A's analysis must be invisible to User B."""
    with TestClient(app_with_db) as client:
        # User A
        _register_and_verify(app_with_db, client, "alice@example.com")
        token_a = _login(client, "alice@example.com")
        headers_a = {"Authorization": f"Bearer {token_a}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers_a)
        upload_id_a = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id_a, "llm_provider": "none"},
                        headers=headers_a)
        analysis_id_a = r.json()["analysis_id"]

        # User B
        _register_and_verify(app_with_db, client, "bob@example.com")
        token_b = _login(client, "bob@example.com")
        headers_b = {"Authorization": f"Bearer {token_b}"}

        # B tries to read A's analysis → 404 (not 403 — anti-enumeration)
        r = client.get(f"/api/v1/analyses/{analysis_id_a}", headers=headers_b)
        assert r.status_code == 404

        # B tries to read A's analysis report → 404
        r = client.get(f"/api/v1/analyses/{analysis_id_a}/report", headers=headers_b)
        assert r.status_code == 404

        # B tries to run analysis on A's upload → 404
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id_a, "llm_provider": "none"},
                        headers=headers_b)
        assert r.status_code == 404

        # B's history must NOT include A's analysis
        r = client.get("/api/v1/history", headers=headers_b)
        assert r.status_code == 200
        assert r.json()["total"] == 0


def test_user_cannot_use_expired_token(app_with_db, monkeypatch):
    """Tokens with negative expiry must be rejected."""
    import jwt as jwt_lib
    from auth import config as auth_config

    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "expire@example.com")

        # Set expiry to past
        monkeypatch.setattr(auth_config, "ACCESS_TOKEN_EXPIRE_SECONDS", -10)
        r = client.post("/api/v1/auth/login", json={
            "email": "expire@example.com", "password": "StrongPass123",
        })
        expired_token = r.json()["tokens"]["access_token"]

        # Reset expiry to valid
        monkeypatch.setattr(auth_config, "ACCESS_TOKEN_EXPIRE_SECONDS", 900)

        # Use expired token → 401
        r = client.get("/api/v1/me", headers={"Authorization": f"Bearer {expired_token}"})
        assert r.status_code == 401


def test_workspace_summary_endpoint(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "summary@example.com")
        token = _login(client, "summary@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        # Initially empty
        r = client.get("/api/v1/workspace/summary", headers=headers)
        assert r.status_code == 200
        body = r.json()
        assert body["total_uploads"] == 0
        assert body["total_analyses"] == 0
        assert body["total_favorites"] == 0

        # Upload + analyze
        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        # Summary reflects new state
        r = client.get("/api/v1/workspace/summary", headers=headers)
        assert r.status_code == 200
        body = r.json()
        assert body["total_uploads"] == 1
        assert body["total_analyses"] == 1
        assert body["average_score"] is not None


def test_workspace_analyses_list_with_filter(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "filter@example.com")
        token = _login(client, "filter@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        # Create 3 analyses
        for i in range(3):
            r = client.post("/api/v1/uploads",
                            files={"file": (f"t{i}.csv", _sample_csv_bytes(seed=i), "text/csv")},
                            headers=headers)
            upload_id = r.json()["upload_id"]
            client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)

        # List all
        r = client.get("/api/v1/workspace/analyses", headers=headers)
        assert r.status_code == 200
        assert r.json()["total"] == 3

        # Filter by min_score
        r = client.get("/api/v1/workspace/analyses?min_score=0", headers=headers)
        assert r.status_code == 200
        # All scores should be ≥ 0
        for item in r.json()["items"]:
            assert item["overall_score"] >= 0


def test_favorites_lifecycle(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "fav@example.com")
        token = _login(client, "fav@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        # Upload + analyze
        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        # Add to favorites
        r = client.post(f"/api/v1/workspace/analyses/{analysis_id}/favorite",
                        json={"note": "test note"}, headers=headers)
        assert r.status_code == 201

        # List favorites
        r = client.get("/api/v1/workspace/favorites", headers=headers)
        assert r.status_code == 200
        assert r.json()["total"] == 1
        assert r.json()["items"][0]["analysis_id"] == analysis_id

        # Check is_favorite flag in analyses list
        r = client.get("/api/v1/workspace/analyses", headers=headers)
        assert r.json()["items"][0]["is_favorite"] is True

        # Filter by only_favorites
        r = client.get("/api/v1/workspace/analyses?only_favorites=true", headers=headers)
        assert r.json()["total"] == 1

        # Remove from favorites
        r = client.delete(f"/api/v1/workspace/analyses/{analysis_id}/favorite",
                          headers=headers)
        assert r.status_code == 204

        r = client.get("/api/v1/workspace/favorites", headers=headers)
        assert r.json()["total"] == 0


def test_rename_analysis(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "rename@example.com")
        token = _login(client, "rename@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        r = client.patch(f"/api/v1/workspace/analyses/{analysis_id}",
                         json={"label": "My Best Analysis"}, headers=headers)
        assert r.status_code == 200
        assert r.json()["label"] == "My Best Analysis"


def test_soft_delete_analysis(app_with_db):
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "del@example.com")
        token = _login(client, "del@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        # Delete
        r = client.delete(f"/api/v1/workspace/analyses/{analysis_id}", headers=headers)
        assert r.status_code == 204

        # Now invisible via API
        r = client.get(f"/api/v1/analyses/{analysis_id}", headers=headers)
        assert r.status_code == 404

        # Not in history either
        r = client.get("/api/v1/history", headers=headers)
        assert r.json()["total"] == 0


def test_report_cache_works(app_with_db):
    """Second request for HTML report should be served from cache (faster)."""
    import time
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "cache@example.com")
        token = _login(client, "cache@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        # First request — cache miss, full render
        t1 = time.monotonic()
        r1 = client.get(f"/api/v1/analyses/{analysis_id}/report.html", headers=headers)
        first_time = time.monotonic() - t1
        assert r1.status_code == 200

        # Second request — cache hit, should be faster
        t2 = time.monotonic()
        r2 = client.get(f"/api/v1/analyses/{analysis_id}/report.html", headers=headers)
        second_time = time.monotonic() - t2
        assert r2.status_code == 200
        assert r1.content == r2.content  # same bytes
        # Cache hit should be at least as fast (usually much faster).
        # Don't assert strict less-than — CI noise can cause flakiness.


def test_unexpected_exception_never_leaks_traceback(app_with_db, monkeypatch):
    """Generic exceptions must be caught + sanitized — never leak traceback."""
    from api.main import app

    def _boom(*args, **kwargs):
        raise RuntimeError("simulated unexpected internal failure with sensitive path /etc/secrets")

    # Patch the ROUTER's reference to get_analysis_by_id (not the repository's).
    # The router imports the function at module-load time, so we patch the
    # router module's attribute.
    from api.routers import analyses as analyses_router
    monkeypatch.setattr(analyses_router, "get_analysis_by_id", _boom)

    with TestClient(app, raise_server_exceptions=False) as client:
        _register_and_verify(app_with_db, client, "boom@example.com")
        token = _login(client, "boom@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.get(f"/api/v1/analyses/{uuid.uuid4()}", headers=headers)
        assert r.status_code == 500
        body = r.json()
        assert body["error"]["code"] == "internal_error"
        assert "/etc/secrets" not in r.text
        assert "RuntimeError" not in r.text
        assert "Traceback" not in r.text


# ---------------------------------------------------------------------------
# v2 tests: charts field in report + /analyses/{id}/trades endpoint
# ---------------------------------------------------------------------------

def test_report_includes_charts_field(app_with_db):
    """[v2] GET /analyses/{id}/report must include a `charts` field with
    non-empty series for each chart type, sourced from the real DataFrame.
    """
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "charts@example.com")
        token = _login(client, "charts@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=100, seed=42), "text/csv")},
                        headers=headers)
        assert r.status_code == 201, r.text
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        assert r.status_code == 201
        analysis_id = r.json()["analysis_id"]

        r = client.get(f"/api/v1/analyses/{analysis_id}/report", headers=headers)
        assert r.status_code == 200
        report = r.json()
        assert "charts" in report, "report missing `charts` field (v2)"

        charts = report["charts"]
        # All 6 series should be present
        for key in ("equity_curve", "drawdown", "pnl_distribution",
                    "hourly_pnl", "weekday_pnl", "win_loss_pie"):
            assert key in charts, f"charts missing series: {key}"

        # Equity curve should have one entry per trade (100 trades → 100 entries).
        assert len(charts["equity_curve"]) == 100
        assert len(charts["drawdown"]) == 100

        # First equity = first Profit (cumsum starts at the first value).
        # We don't assert the exact value (depends on rng seed), but the type
        # and structure must be correct.
        first = charts["equity_curve"][0]
        assert set(first.keys()) == {"trade", "equity"}
        assert isinstance(first["trade"], int)
        assert isinstance(first["equity"], (int, float))

        # Hourly P&L must have exactly 24 entries (one per hour).
        assert len(charts["hourly_pnl"]) == 24

        # Weekday P&L must have exactly 7 entries.
        assert len(charts["weekday_pnl"]) == 7

        # win_loss_pie is a single dict with 4 keys.
        assert set(charts["win_loss_pie"].keys()) == {"wins", "losses", "breakeven", "total"}
        assert charts["win_loss_pie"]["total"] == 100


def test_trades_endpoint_returns_paginated_list(app_with_db):
    """[v2] GET /analyses/{id}/trades returns paginated raw trades list."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "trades@example.com")
        token = _login(client, "trades@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=100, seed=7), "text/csv")},
                        headers=headers)
        assert r.status_code == 201
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        assert r.status_code == 201
        analysis_id = r.json()["analysis_id"]

        # Page 1 with page_size=20 → 20 trades, total=100
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?page=1&page_size=20",
                       headers=headers)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["total"] == 100
        assert body["page"] == 1
        assert body["page_size"] == 20
        assert len(body["trades"]) == 20

        # Each trade must have all expected fields with correct types.
        t = body["trades"][0]
        assert set(t.keys()) == {"id", "open_time", "side", "size", "profit", "hour", "weekday", "date"}
        # This fixture has no Side/Type column (matches the pipeline's
        # standard 3-column format), so direction is genuinely unknown —
        # `side` must be None, not a fabricated guess, and the response
        # must say so via side_available=False.
        assert t["side"] is None
        assert body["side_available"] is False
        assert isinstance(t["hour"], int)
        assert isinstance(t["profit"], (int, float))
        assert isinstance(t["size"], (int, float))

        # Page 5 with page_size=20 → 20 trades (last page).
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?page=5&page_size=20",
                       headers=headers)
        assert r.status_code == 200
        body = r.json()
        assert len(body["trades"]) == 20
        assert body["trades"][0]["id"] == 81  # 1-indexed across filtered set

        # Page 6 should be empty (only 5 pages of 20).
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?page=6&page_size=20",
                       headers=headers)
        assert r.status_code == 200
        assert r.json()["trades"] == []


def test_trades_endpoint_filters_by_side(app_with_db):
    """[v2] GET /analyses/{id}/trades?side=Long filters by trade side."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "sidef@example.com")
        token = _login(client, "sidef@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=100, seed=11, with_side=True), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        # This fixture has a genuine "Type" (buy/sell) column, so side
        # filtering has real data to work with.
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?side=Long&page=1&page_size=100",
                       headers=headers)
        assert r.status_code == 200
        longs = r.json()
        assert longs["side_available"] is True
        assert longs["total"] > 0
        assert all(t["side"] == "Long" for t in longs["trades"])

        # side=Short should return only Short trades.
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?side=Short&page=1&page_size=100",
                       headers=headers)
        shorts = r.json()
        assert shorts["total"] > 0
        assert all(t["side"] == "Short" for t in shorts["trades"])


def test_trades_endpoint_side_unavailable_without_direction_column(app_with_db):
    """[v5 fix] When the upload has no Side/Type column (the pipeline's
    standard 3-column format), `side` must be None for every trade —
    never a fabricated guess — and side_available must be False so the
    frontend can hide the Long/Short filter instead of showing an
    always-empty result."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "sidenone@example.com")
        token = _login(client, "sidenone@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=50, seed=3), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?page=1&page_size=50", headers=headers)
        assert r.status_code == 200
        body = r.json()
        assert body["side_available"] is False
        assert all(t["side"] is None for t in body["trades"])

        # Filtering by side on a dataset with no direction data returns an
        # honest empty result — never a fabricated match.
        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?side=Long&page=1&page_size=50", headers=headers)
        assert r.status_code == 200
        assert r.json()["total"] == 0


def test_trades_endpoint_filters_by_outcome(app_with_db):
    """[v2] GET /analyses/{id}/trades?outcome=win|loss filters by P&L sign."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "outcomef@example.com")
        token = _login(client, "outcomef@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=100, seed=13), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]

        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?outcome=win&page=1&page_size=100",
                       headers=headers)
        assert r.status_code == 200
        wins = r.json()
        assert all(t["profit"] > 0 for t in wins["trades"])

        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?outcome=loss&page=1&page_size=100",
                       headers=headers)
        losses = r.json()
        assert all(t["profit"] < 0 for t in losses["trades"])

        # Wins + losses should equal total trades (rng.normal → ~0 breakeven).
        assert wins["total"] + losses["total"] == 100


def test_trades_endpoint_rejects_invalid_side(app_with_db):
    """[v2] GET /analyses/{id}/trades?side=invalid returns 422."""
    with TestClient(app_with_db) as client:
        _register_and_verify(app_with_db, client, "badf@example.com")
        token = _login(client, "badf@example.com")
        headers = {"Authorization": f"Bearer {token}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("trades.csv", _sample_csv_bytes(n=10, seed=99), "text/csv")},
                        headers=headers)
        upload_id = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id, "llm_provider": "none"},
                        headers=headers)
        analysis_id = r.json()["analysis_id"]

        r = client.get(f"/api/v1/analyses/{analysis_id}/trades?side=Invalid",
                       headers=headers)
        assert r.status_code == 422
        body = r.json()
        assert body["error"]["code"] == "validation_error"


def test_trades_endpoint_requires_auth(app_with_db):
    """[v2] /analyses/{id}/trades requires an Authorization header."""
    with TestClient(app_with_db) as client:
        r = client.get(f"/api/v1/analyses/{uuid.uuid4()}/trades")
        assert r.status_code == 401


def test_trades_endpoint_respects_multi_tenant_isolation(app_with_db):
    """[v2] User A cannot read user B's trades."""
    with TestClient(app_with_db) as client:
        # User A uploads + analyzes
        _register_and_verify(app_with_db, client, "a@example.com")
        token_a = _login(client, "a@example.com")
        headers_a = {"Authorization": f"Bearer {token_a}"}

        r = client.post("/api/v1/uploads",
                        files={"file": ("t.csv", _sample_csv_bytes(n=10, seed=1), "text/csv")},
                        headers=headers_a)
        upload_id_a = r.json()["upload_id"]
        r = client.post("/api/v1/analyses",
                        json={"upload_id": upload_id_a, "llm_provider": "none"},
                        headers=headers_a)
        analysis_id_a = r.json()["analysis_id"]

        # User B tries to read user A's trades
        _register_and_verify(app_with_db, client, "b@example.com")
        token_b = _login(client, "b@example.com")
        headers_b = {"Authorization": f"Bearer {token_b}"}

        r = client.get(f"/api/v1/analyses/{analysis_id_a}/trades",
                       headers=headers_b)
        assert r.status_code == 404
        assert r.json()["error"]["code"] == "analysis_not_found"
