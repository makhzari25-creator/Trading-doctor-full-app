# -*- coding: utf-8 -*-
"""
tests/test_file_loader.py
----------------------------
تست واحد برای سخت‌سازی‌های utils/file_loader.py (Step 4: empty file,
جداکننده‌ی اشتباه، JSON خراب).
"""

import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from utils.file_loader import load_any_file, UnsupportedFileError


def test_empty_csv_raises_clear_error():
    buf = io.BytesIO(b"")
    with pytest.raises(UnsupportedFileError):
        load_any_file(buf, filename="empty.csv")


def test_header_only_csv_raises():
    buf = io.BytesIO(b"Open Time,Profit,Size\n")
    with pytest.raises(UnsupportedFileError):
        load_any_file(buf, filename="header_only.csv")


def test_comma_separated_multi_column_csv_parses_correctly():
    """[AUDIT FIX رگرسیون] جداکننده‌ی صریح کاما باید همیشه قبل از
    auto-sniff امتحان شود تا داده‌ی چندستونی معمولی هرگز اشتباه پارس نشود."""
    content = b"Open Time,Profit,Size\n2024-01-01 10:00,10,1.0\n2024-01-01 11:00,-5,1.2\n"
    buf = io.BytesIO(content)
    df = load_any_file(buf, filename="trades.csv")
    assert list(df.columns) == ["Open Time", "Profit", "Size"]
    assert len(df) == 2


def test_semicolon_separated_csv_parses_correctly():
    content = b"Open Time;Profit;Size\n2024-01-01 10:00;10;1.0\n2024-01-01 11:00;-5;1.2\n"
    buf = io.BytesIO(content)
    df = load_any_file(buf, filename="trades_eu.csv")
    assert list(df.columns) == ["Open Time", "Profit", "Size"]
    assert len(df) == 2


def test_malformed_json_raises_clear_error():
    buf = io.BytesIO(b"{not valid json,,,")
    with pytest.raises(UnsupportedFileError):
        load_any_file(buf, filename="broken.json")


def test_unsupported_extension_falls_back_gracefully():
    # پسوند ناشناخته اما محتوای CSV معتبر -> باید با fallback خوانده شود
    content = b"Open Time,Profit,Size\n2024-01-01,10,1.0\n2024-01-02,-5,1.1\n"
    buf = io.BytesIO(content)
    df = load_any_file(buf, filename="trades.weirdext")
    assert len(df) == 2


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
