# -*- coding: utf-8 -*-
"""tests/test_phase8_auth.py — Phase 8 authentication tests.

Tests cover:
  - Password hashing (bcrypt): hash, verify, rehash on cost upgrade
  - Password policy enforcement
  - JWT access token: create, decode, expiry, invalid signature
  - Refresh token: issue, rotate, revoke, reuse detection
  - User service: create, get, verify email, change password, soft delete
  - Auth endpoints: register, login, refresh, logout, verify-email, password reset
  - Brute-force protection: lockout after N failures
  - Anti-enumeration: register/login/password-reset don't reveal user existence
  - Audit log: every event recorded
  - get_current_user dependency: rejects missing/expired/invalid tokens

Tests use an in-memory SQLite database (async) — no Postgres required.
This is acceptable for unit/integration testing because the auth code uses
only standard SQLAlchemy 2.0 APIs (no Postgres-specific SQL in service layer).

NOTE: SQLite does not enforce partial unique indexes (the uq_users_email_active
index that excludes soft-deleted users). Tests that depend on this constraint
must check the application-layer logic instead.
"""

from __future__ import annotations

import asyncio
import os
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import AsyncIterator

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

# Ensure project root on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Test setup: configure env BEFORE importing auth modules
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _setup_auth_env():
    """Set auth secrets + SQLite DB URL for the whole test session."""
    os.environ["JWT_SECRET_KEY"] = "a" * 64
    os.environ["JWT_REFRESH_SECRET_KEY"] = "b" * 64
    os.environ["JWT_ALGORITHM"] = "HS256"
    os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ["TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY"] = "false"  # easier for tests
    os.environ["EMAIL_BACKEND"] = "console"

    # Force reload of db.base + auth.config + auth.models so they pick up
    # the new env vars. Without reloading auth.models, the User/RefreshToken/etc.
    # classes remain bound to the OLD Base (before env var change), and
    # Base.metadata.create_all would create zero tables.
    import importlib
    import db.base
    importlib.reload(db.base)
    import auth.config
    importlib.reload(auth.config)
    import auth.models
    importlib.reload(auth.models)
    # Phase 9 + 10: workspace + billing tables also need reloading so their
    # ORM classes bind to the new Base.
    try:
        import workspace.models
        importlib.reload(workspace.models)
    except Exception:
        pass
    try:
        import billing.models
        importlib.reload(billing.models)
    except Exception:
        pass

    yield

    # Cleanup (restore defaults is not necessary for a test session)


# ---------------------------------------------------------------------------
# In-memory DB engine + session
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture
async def db_engine(_setup_auth_env, tmp_path):
    """Create a fresh file-based SQLite DB with all auth tables for each test.

    File-based (not :memory:) because each connection to :memory: creates a
    separate DB; we need a single shared DB across the test's connections.
    """
    import db.base
    db_file = tmp_path / "test.db"
    engine = create_async_engine(
        f"sqlite+aiosqlite:///{db_file}",
        # StaticPool keeps a single connection so the in-memory DB persists
        # across multiple sessions created by the same engine. For file-based
        # SQLite, this is not strictly necessary but improves performance.
    )

    # Create all tables (imports auth.models which registers them on Base.metadata)
    import auth.models  # noqa: F401 — register tables
    import workspace.models  # noqa: F401
    import billing.models  # noqa: F401
    async with engine.begin() as conn:
        # SQLAlchemy 2.0 async requires run_sync for DDL operations
        await conn.run_sync(db.base.Base.metadata.create_all)

    # Phase 10: seed billing plans so auth flows that touch billing (e.g.
    # auto-assign free plan on registration) work.
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
    seed_factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with seed_factory() as session:
        from billing.services.plans import seed_plans
        await seed_plans(session)
        await session.commit()

    yield engine

    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncIterator[AsyncSession]:
    """Yield an AsyncSession bound to the in-memory DB."""
    factory = async_sessionmaker(
        bind=db_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    async with factory() as session:
        try:
            yield session
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Password hashing tests
# ---------------------------------------------------------------------------

class TestPasswordHashing:
    def test_hash_returns_bcrypt_format(self):
        from auth.services.passwords import hash_password
        h = hash_password("test123abc")
        assert h.startswith("$2b$12$")  # bcrypt, 12 rounds
        assert len(h) == 60

    def test_hash_is_deterministic_in_algorithm_only(self):
        """Same password produces different hashes (different salts)."""
        from auth.services.passwords import hash_password
        h1 = hash_password("samepass123")
        h2 = hash_password("samepass123")
        assert h1 != h2  # different salt

    def test_verify_correct_password(self):
        from auth.services.passwords import hash_password, verify_password
        h = hash_password("correctpass123")
        assert verify_password("correctpass123", h) is True

    def test_verify_wrong_password(self):
        from auth.services.passwords import hash_password, verify_password
        h = hash_password("correctpass123")
        assert verify_password("wrongpass456", h) is False

    def test_verify_empty_password_returns_false(self):
        from auth.services.passwords import verify_password
        assert verify_password("", "$2b$12$" + "x" * 53) is False

    def test_verify_malformed_hash_returns_false(self):
        from auth.services.passwords import verify_password
        assert verify_password("anypass", "not-a-hash") is False

    def test_verify_and_maybe_rehash_returns_none_on_match(self):
        from auth.services.passwords import hash_password, verify_and_maybe_rehash
        h = hash_password("matchpass123")
        is_valid, new_hash = verify_and_maybe_rehash("matchpass123", h)
        assert is_valid is True
        # Hash already at current cost factor → no rehash needed
        assert new_hash is None

    def test_verify_and_maybe_rehash_upgrades_low_cost(self, monkeypatch):
        from auth.services import passwords
        from auth import config as auth_config
        # Hash with rounds=4 (below current PASSWORD_HASH_ROUNDS=12)
        import bcrypt
        low_hash = bcrypt.hashpw(b"lowcostpass1", bcrypt.gensalt(rounds=4)).decode()
        # Verify hash uses rounds=4
        assert low_hash.startswith("$2b$04$")

        is_valid, new_hash = passwords.verify_and_maybe_rehash("lowcostpass1", low_hash)
        assert is_valid is True
        assert new_hash is not None
        assert new_hash.startswith("$2b$12$")  # upgraded to current rounds


# ---------------------------------------------------------------------------
# Password policy tests
# ---------------------------------------------------------------------------

class TestPasswordPolicy:
    def test_too_short_rejected(self):
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy("short1")
        assert ok is False
        assert "at least" in msg.lower()

    def test_no_digit_rejected(self):
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy("allletters")
        assert ok is False
        assert "letter and one digit" in msg.lower()

    def test_no_letter_rejected(self):
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy("12345678")
        assert ok is False
        assert "letter and one digit" in msg.lower()

    def test_valid_password_accepted(self):
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy("validpass123")
        assert ok is True
        assert msg is None

    def test_passphrase_accepted(self):
        """Long passphrases are valid; no special-char requirement."""
        from auth.services.passwords import password_meets_policy
        ok, _ = password_meets_policy("this is a long passphrase with digits 12345")
        assert ok is True

    def test_too_long_rejected(self):
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy("a1" * 65)  # 130 chars
        assert ok is False
        assert "longer than" in msg.lower()


# ---------------------------------------------------------------------------
# JWT tests
# ---------------------------------------------------------------------------

class TestJWT:
    def test_create_and_decode_roundtrip(self):
        from auth.services.tokens import create_access_token, decode_access_token
        from auth.models import User, UserStatus
        user = User(
            id=uuid.uuid4(), email="test@example.com",
            password_hash="x", status=UserStatus.active,
            created_at=datetime.now(timezone.utc),
        )
        token, expires = create_access_token(user)
        claims = decode_access_token(token)
        assert claims["sub"] == str(user.id)
        assert claims["email"] == "test@example.com"
        assert claims["status"] == "active"
        assert claims["iss"] == "tradingdoctor"
        assert claims["aud"] == "tradingdoctor-users"
        assert claims["type"] == "access"
        assert "jti" in claims
        assert "exp" in claims
        assert "iat" in claims

    def test_decode_invalid_token_raises(self):
        from auth.services.tokens import decode_access_token
        import jwt
        with pytest.raises(jwt.InvalidTokenError):
            decode_access_token("not.a.valid.token")

    def test_decode_expired_token_raises(self, monkeypatch):
        from auth.services.tokens import create_access_token, decode_access_token
        from auth.models import User, UserStatus
        from auth import config as auth_config

        # Set expiry to 1 second in the past
        monkeypatch.setattr(auth_config, "ACCESS_TOKEN_EXPIRE_SECONDS", -1)
        user = User(
            id=uuid.uuid4(), email="test@example.com",
            password_hash="x", status=UserStatus.active,
            created_at=datetime.now(timezone.utc),
        )
        token, _ = create_access_token(user)

        # Reset to valid expiry before decode
        monkeypatch.setattr(auth_config, "ACCESS_TOKEN_EXPIRE_SECONDS", 900)
        import jwt
        with pytest.raises(jwt.ExpiredSignatureError):
            decode_access_token(token)

    def test_decode_token_wrong_secret_raises(self, monkeypatch):
        from auth.services.tokens import create_access_token, decode_access_token
        from auth.models import User, UserStatus
        from auth import config as auth_config
        user = User(
            id=uuid.uuid4(), email="test@example.com",
            password_hash="x", status=UserStatus.active,
            created_at=datetime.now(timezone.utc),
        )
        token, _ = create_access_token(user)

        # Now change the secret
        monkeypatch.setattr(auth_config, "JWT_SECRET_KEY", "c" * 64)
        import jwt
        with pytest.raises(jwt.InvalidSignatureError):
            decode_access_token(token)


# ---------------------------------------------------------------------------
# User service tests
# ---------------------------------------------------------------------------

class TestUserService:
    @pytest.mark.asyncio
    async def test_create_user_returns_pending_user(self, db_session):
        from auth.services.users import create_user
        from auth.models import UserStatus
        user = await create_user(
            db=db_session,
            email="newuser@example.com",
            password="StrongPass123",
            full_name="Test User",
        )
        assert user.id is not None
        assert user.email == "newuser@example.com"
        assert user.status == UserStatus.pending
        assert user.email_verified_at is None
        assert user.password_hash.startswith("$2b$12$")
        assert user.failed_login_attempts == 0

    @pytest.mark.asyncio
    async def test_create_user_lowercases_email(self, db_session):
        from auth.services.users import create_user
        user = await create_user(
            db=db_session,
            email="MixedCase@Example.COM",
            password="StrongPass123",
        )
        assert user.email == "mixedcase@example.com"

    @pytest.mark.asyncio
    async def test_create_user_duplicate_email_raises(self, db_session):
        from auth.services.users import create_user
        await create_user(db=db_session, email="dup@example.com", password="StrongPass123")
        with pytest.raises(ValueError, match="EMAIL_ALREADY_REGISTERED"):
            await create_user(db=db_session, email="dup@example.com", password="OtherPass456")

    @pytest.mark.asyncio
    async def test_get_user_by_email_returns_user(self, db_session):
        from auth.services.users import create_user, get_user_by_email
        await create_user(db=db_session, email="findme@example.com", password="StrongPass123")
        user = await get_user_by_email(db_session, "findme@example.com")
        assert user is not None
        assert user.email == "findme@example.com"

    @pytest.mark.asyncio
    async def test_get_user_by_email_returns_none_for_unknown(self, db_session):
        from auth.services.users import get_user_by_email
        user = await get_user_by_email(db_session, "nobody@example.com")
        assert user is None

    @pytest.mark.asyncio
    async def test_verify_email_sets_active_status(self, db_session):
        from auth.services.users import create_user, verify_email
        from auth.models import UserStatus
        user = await create_user(db=db_session, email="verify@example.com", password="StrongPass123")
        assert user.status == UserStatus.pending
        updated = await verify_email(db_session, user.id)
        assert updated.status == UserStatus.active
        assert updated.email_verified_at is not None

    @pytest.mark.asyncio
    async def test_change_password_rehashes_and_revokes_tokens(self, db_session):
        from auth.services.users import create_user, change_password
        from auth.services.tokens import issue_refresh_token, revoke_all_user_tokens
        user = await create_user(db=db_session, email="changepw@example.com", password="StrongPass123")
        old_hash = user.password_hash
        await issue_refresh_token(db_session, user)
        await change_password(db_session, user.id, "NewStrongPass456")
        new_hash = user.password_hash
        assert new_hash != old_hash
        # Verify new password works
        from auth.services.passwords import verify_password
        assert verify_password("NewStrongPass456", new_hash)

    @pytest.mark.asyncio
    async def test_authenticate_user_sync_with_valid_credentials(self, db_session):
        from auth.services.users import create_user, authenticate_user_sync
        user = await create_user(db=db_session, email="auth@example.com", password="StrongPass123")
        # Manually activate (authenticate requires status=active)
        from auth.services.users import verify_email
        user = await verify_email(db_session, user.id)
        is_valid, valid_user, new_hash = authenticate_user_sync(user, "StrongPass123")
        assert is_valid is True
        assert valid_user is not None
        assert valid_user.id == user.id

    @pytest.mark.asyncio
    async def test_authenticate_user_sync_wrong_password(self, db_session):
        from auth.services.users import create_user, verify_email, authenticate_user_sync
        user = await create_user(db=db_session, email="auth2@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)
        is_valid, valid_user, _ = authenticate_user_sync(user, "WrongPass456")
        assert is_valid is False
        assert valid_user is None

    @pytest.mark.asyncio
    async def test_authenticate_user_sync_pending_user_rejected(self, db_session):
        """A user with status=pending (email not verified) cannot authenticate."""
        from auth.services.users import create_user, authenticate_user_sync
        user = await create_user(db=db_session, email="pending@example.com", password="StrongPass123")
        # Don't verify email — user stays pending
        is_valid, valid_user, _ = authenticate_user_sync(user, "StrongPass123")
        assert is_valid is False
        assert valid_user is None

    @pytest.mark.asyncio
    async def test_authenticate_user_sync_none_user_runs_bcrypt(self, db_session):
        """Verifying against None user must still run bcrypt (timing attack defense)."""
        from auth.services.users import authenticate_user_sync
        is_valid, valid_user, _ = authenticate_user_sync(None, "anypass123")
        assert is_valid is False
        assert valid_user is None


# ---------------------------------------------------------------------------
# Refresh token tests
# ---------------------------------------------------------------------------

class TestRefreshTokens:
    @pytest.mark.asyncio
    async def test_issue_refresh_token_returns_plaintext_and_record(self, db_session):
        from auth.services.users import create_user
        from auth.services.tokens import issue_refresh_token
        user = await create_user(db=db_session, email="refresh@example.com", password="StrongPass123")
        plaintext, expires, record = await issue_refresh_token(db_session, user)
        assert len(plaintext) == 64  # 32 bytes hex
        assert record.token_hash != plaintext  # hash, not plaintext
        assert record.token_hash != ""
        assert record.expires_at > datetime.now(timezone.utc)
        assert record.revoked_at is None

    @pytest.mark.asyncio
    async def test_rotate_refresh_token_revokes_old_issues_new(self, db_session):
        from auth.services.users import create_user, verify_email
        from auth.services.tokens import issue_refresh_token, rotate_refresh_token
        from auth.models import RefreshToken
        from sqlalchemy import select
        user = await create_user(db=db_session, email="rotate@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)
        plaintext1, _, record1 = await issue_refresh_token(db_session, user)
        old_id = record1.id

        result = await rotate_refresh_token(db_session, plaintext1)
        assert result is not None
        new_user, plaintext2, _, record2 = result
        assert new_user.id == user.id
        assert plaintext2 != plaintext1
        assert record2.id != old_id

        # Old token should be revoked — commit + query fresh from DB
        await db_session.commit()
        stmt = select(RefreshToken).where(RefreshToken.id == old_id)
        old_record = (await db_session.execute(stmt)).scalar_one()
        assert old_record.revoked_at is not None
        assert old_record.revoked_reason == "rotated"
        assert old_record.replaced_by_id == record2.id

    @pytest.mark.asyncio
    async def test_rotate_revoked_token_triggers_reuse_detection(self, db_session):
        """Using an already-rotated token should return None (reuse detected)."""
        from auth.services.users import create_user, verify_email
        from auth.services.tokens import issue_refresh_token, rotate_refresh_token
        user = await create_user(db=db_session, email="reuse@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)
        plaintext1, _, _ = await issue_refresh_token(db_session, user)

        # First rotation: success
        result1 = await rotate_refresh_token(db_session, plaintext1)
        assert result1 is not None

        # Second use of the same (now-revoked) token: should fail (reuse)
        result2 = await rotate_refresh_token(db_session, plaintext1)
        assert result2 is None

    @pytest.mark.asyncio
    async def test_rotate_unknown_token_returns_none(self, db_session):
        from auth.services.tokens import rotate_refresh_token
        result = await rotate_refresh_token(db_session, "0" * 64)
        assert result is None

    @pytest.mark.asyncio
    async def test_revoke_refresh_token(self, db_session):
        from auth.services.users import create_user
        from auth.services.tokens import issue_refresh_token, revoke_refresh_token
        from auth.models import RefreshToken
        from sqlalchemy import select
        user = await create_user(db=db_session, email="revoke@example.com", password="StrongPass123")
        plaintext, _, record = await issue_refresh_token(db_session, user)
        record_id = record.id

        revoked = await revoke_refresh_token(db_session, plaintext, reason="logout")
        assert revoked is True
        await db_session.commit()
        stmt = select(RefreshToken).where(RefreshToken.id == record_id)
        refreshed = (await db_session.execute(stmt)).scalar_one()
        assert refreshed.revoked_at is not None
        assert refreshed.revoked_reason == "logout"

    @pytest.mark.asyncio
    async def test_revoke_unknown_token_returns_false(self, db_session):
        from auth.services.tokens import revoke_refresh_token
        revoked = await revoke_refresh_token(db_session, "0" * 64)
        assert revoked is False

    @pytest.mark.asyncio
    async def test_revoke_all_user_tokens(self, db_session):
        from auth.services.users import create_user
        from auth.services.tokens import issue_refresh_token, revoke_all_user_tokens
        user = await create_user(db=db_session, email="multi@example.com", password="StrongPass123")
        await issue_refresh_token(db_session, user)
        await issue_refresh_token(db_session, user)
        await issue_refresh_token(db_session, user)

        count = await revoke_all_user_tokens(db_session, user.id, reason="admin")
        assert count == 3


# ---------------------------------------------------------------------------
# Email verification token tests
# ---------------------------------------------------------------------------

class TestEmailVerificationTokens:
    @pytest.mark.asyncio
    async def test_create_email_verification_token(self, db_session):
        from auth.services.users import create_user, create_email_verification_token
        from auth.models import EmailVerificationType
        user = await create_user(db=db_session, email="ev@example.com", password="StrongPass123")
        token, expires = await create_email_verification_token(
            db_session, user, EmailVerificationType.email_verification,
        )
        assert len(token) == 64
        assert expires > datetime.now(timezone.utc)

    @pytest.mark.asyncio
    async def test_consume_valid_token_returns_user(self, db_session):
        from auth.services.users import (
            create_user, create_email_verification_token, consume_email_verification_token,
        )
        from auth.models import EmailVerificationType
        user = await create_user(db=db_session, email="consume@example.com", password="StrongPass123")
        token, _ = await create_email_verification_token(
            db_session, user, EmailVerificationType.email_verification,
        )
        result = await consume_email_verification_token(
            db_session, token, EmailVerificationType.email_verification,
        )
        assert result is not None
        assert result.id == user.id

    @pytest.mark.asyncio
    async def test_consume_token_twice_returns_none(self, db_session):
        """Token is single-use — second consumption must fail."""
        from auth.services.users import (
            create_user, create_email_verification_token, consume_email_verification_token,
        )
        from auth.models import EmailVerificationType
        user = await create_user(db=db_session, email="twice@example.com", password="StrongPass123")
        token, _ = await create_email_verification_token(
            db_session, user, EmailVerificationType.email_verification,
        )
        # First use: success
        result1 = await consume_email_verification_token(
            db_session, token, EmailVerificationType.email_verification,
        )
        assert result1 is not None
        # Second use: fail (reuse)
        result2 = await consume_email_verification_token(
            db_session, token, EmailVerificationType.email_verification,
        )
        assert result2 is None

    @pytest.mark.asyncio
    async def test_consume_unknown_token_returns_none(self, db_session):
        from auth.services.users import consume_email_verification_token
        from auth.models import EmailVerificationType
        result = await consume_email_verification_token(
            db_session, "0" * 64, EmailVerificationType.email_verification,
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_creating_new_token_revokes_old_ones(self, db_session):
        """Issuing a new verification token should invalidate prior tokens of same type."""
        from auth.services.users import (
            create_user, create_email_verification_token, consume_email_verification_token,
        )
        from auth.models import EmailVerificationType
        user = await create_user(db=db_session, email="revoked@example.com", password="StrongPass123")
        token1, _ = await create_email_verification_token(
            db_session, user, EmailVerificationType.email_verification,
        )
        token2, _ = await create_email_verification_token(
            db_session, user, EmailVerificationType.email_verification,
        )
        # token1 should now be consumed (revoked)
        result1 = await consume_email_verification_token(
            db_session, token1, EmailVerificationType.email_verification,
        )
        assert result1 is None
        # token2 should still work
        result2 = await consume_email_verification_token(
            db_session, token2, EmailVerificationType.email_verification,
        )
        assert result2 is not None


# ---------------------------------------------------------------------------
# Brute-force protection
# ---------------------------------------------------------------------------

class TestBruteForceProtection:
    @pytest.mark.asyncio
    async def test_failed_login_increments_counter(self, db_session):
        from auth.services.users import create_user, verify_email, update_login_failure
        user = await create_user(db=db_session, email="bf@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)

        attempts, locked = await update_login_failure(db_session, user.id)
        assert attempts == 1
        assert locked is None

        attempts, locked = await update_login_failure(db_session, user.id)
        assert attempts == 2

    @pytest.mark.asyncio
    async def test_account_locks_after_max_attempts(self, db_session, monkeypatch):
        from auth.services.users import create_user, verify_email, update_login_failure, is_account_locked
        from auth import config as auth_config

        # Lower threshold for test speed
        monkeypatch.setattr(auth_config, "MAX_FAILED_LOGIN_ATTEMPTS", 3)
        monkeypatch.setattr(auth_config, "ACCOUNT_LOCKOUT_MINUTES", 5)

        user = await create_user(db=db_session, email="lock@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)

        for i in range(3):
            await update_login_failure(db_session, user.id)

        is_locked = await is_account_locked(db_session, user.id)
        assert is_locked is True

    @pytest.mark.asyncio
    async def test_successful_login_resets_counter(self, db_session):
        from auth.services.users import (
            create_user, verify_email, update_login_failure, update_login_success,
        )
        user = await create_user(db=db_session, email="reset@example.com", password="StrongPass123")
        user = await verify_email(db_session, user.id)

        await update_login_failure(db_session, user.id)
        await update_login_failure(db_session, user.id)

        await update_login_success(db_session, user.id, ip_address="1.2.3.4")
        await db_session.refresh(user)
        assert user.failed_login_attempts == 0
        assert user.locked_until is None
        assert user.last_login_at is not None
        assert user.last_login_ip == "1.2.3.4"


# ---------------------------------------------------------------------------
# Audit log tests
# ---------------------------------------------------------------------------

class TestAuditLog:
    @pytest.mark.asyncio
    async def test_record_event_creates_row(self, db_session):
        from auth.services.audit import record_event
        from auth.models import AuditEventType
        user_id = uuid.uuid4()
        record = await record_event(
            db_session,
            AuditEventType.login,
            user_id=user_id,
            ip_address="1.2.3.4",
            user_agent="TestAgent/1.0",
            outcome="success",
            details={"reason": "test"},
        )
        assert record.id is not None
        assert record.user_id == user_id
        assert record.event_type == AuditEventType.login
        assert record.ip_address == "1.2.3.4"
        assert record.outcome == "success"
        assert "reason" in record.details  # JSON-encoded

    @pytest.mark.asyncio
    async def test_record_login_failure_includes_email(self, db_session):
        from auth.services.audit import record_login_failure
        from auth.models import AuditLog, AuditEventType
        await record_login_failure(db_session, "unknown@example.com", "1.2.3.4", "UA", reason="not_found")
        # Verify the row was created
        from sqlalchemy import select
        stmt = select(AuditLog).where(AuditLog.event_type == AuditEventType.login_failed)
        result = await db_session.execute(stmt)
        record = result.scalar_one()
        assert "email" in record.details
        assert "unknown@example.com" in record.details


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------

class TestAuthConfig:
    def test_validate_auth_config_returns_problems_when_secrets_missing(self, monkeypatch):
        from auth import config as auth_config
        monkeypatch.setattr(auth_config, "JWT_SECRET_KEY", "")
        monkeypatch.setattr(auth_config, "JWT_REFRESH_SECRET_KEY", "")
        problems = auth_config.validate_auth_config()
        assert len(problems) >= 2
        assert any("JWT_SECRET_KEY" in p for p in problems)
        assert any("JWT_REFRESH_SECRET_KEY" in p for p in problems)

    def test_validate_auth_config_detects_same_secret(self, monkeypatch):
        from auth import config as auth_config
        same = "x" * 64
        monkeypatch.setattr(auth_config, "JWT_SECRET_KEY", same)
        monkeypatch.setattr(auth_config, "JWT_REFRESH_SECRET_KEY", same)
        problems = auth_config.validate_auth_config()
        assert any("different" in p for p in problems)

    def test_validate_auth_config_passes_with_valid_config(self, _setup_auth_env):
        from auth import config as auth_config
        # Env is set by the fixture; should pass
        problems = auth_config.validate_auth_config()
        assert problems == []


# ---------------------------------------------------------------------------
# Auth exceptions
# ---------------------------------------------------------------------------

class TestAuthExceptions:
    def test_auth_error_defaults(self):
        from auth.exceptions import AuthError
        e = AuthError("test message")
        assert e.status_code == 401
        assert e.error_code == "auth_error"
        assert e.message == "test message"
        assert e.details == {}

    def test_account_locked_includes_lockout_time(self):
        from auth.exceptions import AccountLockedError
        from datetime import datetime, timezone, timedelta
        locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)
        e = AccountLockedError(locked_until=locked_until)
        assert e.status_code == 423
        assert e.error_code == "account_locked"
        assert "locked_until" in e.details

    def test_invalid_credentials_returns_401(self):
        from auth.exceptions import InvalidCredentialsError
        e = InvalidCredentialsError("bad pw")
        assert e.status_code == 401
        assert e.error_code == "invalid_credentials"

    def test_email_already_registered_returns_409(self):
        from auth.exceptions import EmailAlreadyRegisteredError
        e = EmailAlreadyRegisteredError("dup")
        assert e.status_code == 409


# ---------------------------------------------------------------------------
# Email template tests
# ---------------------------------------------------------------------------

class TestEmailTemplates:
    def test_render_email_verification_includes_url(self):
        from auth.templates.email_templates import render_email_verification
        html = render_email_verification("Test User", "https://example.com/verify?token=abc")
        assert "https://example.com/verify?token=abc" in html
        assert "Test User" in html
        assert "تأیید ایمیل" in html  # Persian title
        assert "dir=\"rtl\"" in html

    def test_render_password_reset_includes_url(self):
        from auth.templates.email_templates import render_password_reset
        html = render_password_reset("Test User", "https://example.com/reset?token=xyz")
        assert "https://example.com/reset?token=xyz" in html
        assert "بازنشانی رمز عبور" in html

    def test_render_welcome(self):
        from auth.templates.email_templates import render_welcome
        html = render_welcome("New User")
        assert "خوش آمدید" in html
        assert "New User" in html

    def test_template_escapes_user_input(self):
        """User name with HTML must be escaped (XSS prevention in email clients)."""
        from auth.templates.email_templates import render_email_verification
        html = render_email_verification("<script>alert(1)</script>", "https://example.com/verify")
        # The angle brackets must be HTML-escaped
        assert "<script>" not in html
        assert "&lt;script&gt;" in html


# ---------------------------------------------------------------------------
# Email backend tests
# ---------------------------------------------------------------------------

class TestEmailBackends:
    @pytest.mark.asyncio
    async def test_console_backend_always_succeeds(self, capsys):
        from auth.services.email import ConsoleEmailBackend
        backend = ConsoleEmailBackend()
        result = await backend.send(
            to_email="test@example.com",
            subject="Test Subject",
            html_body="<p>Hello</p>",
            text_body="Hello",
        )
        assert result is True
        captured = capsys.readouterr()
        assert "Test Subject" in captured.out
        assert "test@example.com" in captured.out

    @pytest.mark.asyncio
    async def test_send_email_verification_email_uses_console_backend(self, capsys):
        from auth.services.email import send_email_verification_email
        result = await send_email_verification_email("user@example.com", "abc123", "User Name")
        assert result is True
        captured = capsys.readouterr()
        assert "user@example.com" in captured.out
        # The token should appear in the verification URL
        assert "abc123" in captured.out


# ---------------------------------------------------------------------------
# Engine immutability check (extends Phase 7.5 test)
# ---------------------------------------------------------------------------

class TestEngineImmutability:
    def test_auth_layer_does_not_import_engines(self):
        """The auth/ layer must NOT import any frozen V23 engine module."""
        import inspect
        import auth
        import auth.config
        import auth.dependencies
        import auth.exceptions
        import auth.models
        import auth.schemas
        from auth.routers import login, me, password_reset, register, verify_email
        from auth.services import audit, email, passwords, tokens, users

        modules_to_check = [
            auth, auth.config, auth.dependencies, auth.exceptions,
            auth.models, auth.schemas,
            login, me, password_reset, register, verify_email,
            audit, email, passwords, tokens, users,
        ]
        for mod in modules_to_check:
            src = inspect.getsource(mod)
            assert "from engines" not in src, \
                f"{mod.__name__} must not import from engines/"
            assert "import engines" not in src, \
                f"{mod.__name__} must not import engines/"


# ---------------------------------------------------------------------------
# Integration: API endpoints (using FastAPI TestClient)
# ---------------------------------------------------------------------------

class TestAuthEndpoints:
    """End-to-end tests of the auth API endpoints.

    Uses an in-memory SQLite DB created fresh per test. Auth endpoints require
    a DB session — without one, they raise 500.
    """

    @pytest_asyncio.fixture
    async def app_with_db(self, _setup_auth_env, db_engine, monkeypatch):
        """Create a FastAPI app instance wired to the test DB.

        Relies on db.base.get_db reading `async_session_factory` lazily.
        """
        import db.base
        from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

        factory = async_sessionmaker(
            bind=db_engine, class_=AsyncSession,
            expire_on_commit=False, autoflush=False,
        )
        monkeypatch.setattr(db.base, "engine", db_engine)
        monkeypatch.setattr(db.base, "async_session_factory", factory)

        from api.main import app
        app.dependency_overrides.clear()
        app._test_db_factory = factory  # type: ignore[attr-defined]

        yield app

        app.dependency_overrides.clear()

    def _register_and_verify(self, app_with_db, client, email: str, password: str = "StrongPass123") -> str:
        """Helper: register a user, then mark email as verified in the DB.

        Returns the user_id.
        """
        import asyncio
        factory = app_with_db._test_db_factory  # type: ignore[attr-defined]

        r = client.post("/api/v1/auth/register", json={
            "email": email, "password": password,
        })
        assert r.status_code == 201, r.text
        user_id = r.json()["user_id"]

        # Mark email as verified directly in DB (skip email round-trip)
        async def _verify():
            from auth.services.users import verify_email
            async with factory() as session:
                await verify_email(session, uuid.UUID(user_id))
                await session.commit()
        asyncio.run(_verify())

        return user_id

    def test_health_endpoint_still_works_without_auth(self, app_with_db):
        """Existing /api/v1/health endpoint must still respond (no auth required)."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.get("/api/v1/health")
            assert r.status_code == 200
            assert r.json()["status"] == "ok"

    def test_register_endpoint_requires_email_and_password(self, app_with_db):
        """POST /api/v1/auth/register validates request body."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            # Missing required fields
            r = client.post("/api/v1/auth/register", json={})
            assert r.status_code == 422
            body = r.json()
            assert "error" in body
            assert body["error"]["code"] == "request_validation_error"

    def test_register_endpoint_creates_user(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post("/api/v1/auth/register", json={
                "email": "newuser@example.com",
                "password": "StrongPass123",
                "full_name": "New User",
            })
            assert r.status_code == 201, r.text
            body = r.json()
            assert body["email"] == "newuser@example.com"
            assert body["status"] == "pending"
            assert "user_id" in body

    def test_register_endpoint_rejects_duplicate_email(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            client.post("/api/v1/auth/register", json={
                "email": "dup@example.com", "password": "StrongPass123",
            })
            r = client.post("/api/v1/auth/register", json={
                "email": "dup@example.com", "password": "OtherPass456",
            })
            assert r.status_code == 409
            body = r.json()
            assert body["error"]["code"] == "email_already_registered"

    def test_register_rejects_weak_password(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post("/api/v1/auth/register", json={
                "email": "weak@example.com", "password": "short",
            })
            assert r.status_code == 422

    def test_login_with_valid_credentials(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "login@example.com")

            r = client.post("/api/v1/auth/login", json={
                "email": "login@example.com", "password": "StrongPass123",
            })
            assert r.status_code == 200, r.text
            body = r.json()
            assert "access_token" in body["tokens"]
            assert "refresh_token" in body["tokens"]
            assert body["tokens"]["token_type"] == "Bearer"
            assert body["user"]["email"] == "login@example.com"

    def test_login_with_wrong_password(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "wrongpw@example.com")
            r = client.post("/api/v1/auth/login", json={
                "email": "wrongpw@example.com", "password": "WrongPass456",
            })
            assert r.status_code == 401
            assert r.json()["error"]["code"] == "invalid_credentials"

    def test_login_with_unknown_email(self, app_with_db):
        """Anti-enumeration: same error as wrong password."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post("/api/v1/auth/login", json={
                "email": "nobody@example.com", "password": "AnyPass123",
            })
            assert r.status_code == 401
            assert r.json()["error"]["code"] == "invalid_credentials"

    def test_me_endpoint_requires_auth(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.get("/api/v1/me")
            assert r.status_code == 401
            assert r.json()["error"]["code"] == "invalid_token"

    def test_me_endpoint_with_valid_token(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "me@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "me@example.com", "password": "StrongPass123",
            })
            token = login_r.json()["tokens"]["access_token"]

            r = client.get("/api/v1/me", headers={"Authorization": f"Bearer {token}"})
            assert r.status_code == 200
            body = r.json()
            assert body["user"]["email"] == "me@example.com"

    def test_refresh_endpoint_issues_new_tokens(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "refresh@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "refresh@example.com", "password": "StrongPass123",
            })
            refresh_token = login_r.json()["tokens"]["refresh_token"]

            r = client.post("/api/v1/auth/refresh", json={"refresh_token": refresh_token})
            assert r.status_code == 200, r.text
            body = r.json()
            assert "access_token" in body
            assert body["refresh_token"] != refresh_token  # rotated

    def test_refresh_with_revoked_token_fails(self, app_with_db):
        """Refresh token rotation means the old token cannot be reused."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "rotate@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "rotate@example.com", "password": "StrongPass123",
            })
            old_refresh = login_r.json()["tokens"]["refresh_token"]

            # First refresh: success
            r1 = client.post("/api/v1/auth/refresh", json={"refresh_token": old_refresh})
            assert r1.status_code == 200

            # Second use of same token: must fail (reuse detection)
            r2 = client.post("/api/v1/auth/refresh", json={"refresh_token": old_refresh})
            assert r2.status_code == 401

    def test_logout_revokes_refresh_token(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "logout@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "logout@example.com", "password": "StrongPass123",
            })
            refresh_token = login_r.json()["tokens"]["refresh_token"]

            r = client.post("/api/v1/auth/logout", json={"refresh_token": refresh_token})
            assert r.status_code == 204

            # Refresh should now fail
            r2 = client.post("/api/v1/auth/refresh", json={"refresh_token": refresh_token})
            assert r2.status_code == 401

    def test_password_reset_request_anti_enumeration(self, app_with_db):
        """Reset request returns same response for known and unknown emails."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            # Known email (no need to verify for this test)
            client.post("/api/v1/auth/register", json={
                "email": "known@example.com", "password": "StrongPass123",
            })
            r1 = client.post("/api/v1/auth/password-reset/request", json={
                "email": "known@example.com",
            })
            # Unknown email
            r2 = client.post("/api/v1/auth/password-reset/request", json={
                "email": "unknown@example.com",
            })
            assert r1.status_code == 200
            assert r2.status_code == 200
            assert r1.json() == r2.json()  # identical response

    def test_password_reset_confirm_changes_password(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            # Register (no need to verify — password reset doesn't require active status)
            client.post("/api/v1/auth/register", json={
                "email": "reset@example.com", "password": "OldPass123",
            })

            # Request reset (console backend prints the token URL)
            from io import StringIO
            import sys
            old_stdout = sys.stdout
            sys.stdout = captured = StringIO()
            client.post("/api/v1/auth/password-reset/request", json={
                "email": "reset@example.com",
            })
            sys.stdout = old_stdout
            output = captured.getvalue()

            # Extract token from the printed URL
            import re
            match = re.search(r"token=([a-f0-9]{64})", output)
            assert match is not None, "Token not found in console output"
            token = match.group(1)

            # Confirm reset
            r = client.post("/api/v1/auth/password-reset/confirm", json={
                "token": token,
                "new_password": "NewStrongPass456",
            })
            assert r.status_code == 200, r.text

            # Verify email so login isn't blocked (password reset doesn't auto-verify)
            import asyncio
            factory = app_with_db._test_db_factory  # type: ignore[attr-defined]
            from auth.services.users import get_user_by_email
            async def _verify_after_reset():
                async with factory() as session:
                    user = await get_user_by_email(session, "reset@example.com")
                    from auth.services.users import verify_email
                    await verify_email(session, user.id)
                    await session.commit()
            asyncio.run(_verify_after_reset())

            # Old password should fail; new should work
            r_old = client.post("/api/v1/auth/login", json={
                "email": "reset@example.com", "password": "OldPass123",
            })
            assert r_old.status_code == 401

            r_new = client.post("/api/v1/auth/login", json={
                "email": "reset@example.com", "password": "NewStrongPass456",
            })
            assert r_new.status_code == 200

    def test_change_password_endpoint_requires_current_password(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "changepw@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "changepw@example.com", "password": "StrongPass123",
            })
            token = login_r.json()["tokens"]["access_token"]

            # Wrong current password
            r = client.post("/api/v1/me/password",
                headers={"Authorization": f"Bearer {token}"},
                json={"current_password": "WrongPass", "new_password": "NewPass123"},
            )
            assert r.status_code == 401

            # Correct current password
            r = client.post("/api/v1/me/password",
                headers={"Authorization": f"Bearer {token}"},
                json={"current_password": "StrongPass123", "new_password": "NewPass456"},
            )
            assert r.status_code == 204

    def test_delete_account_endpoint(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "delete@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "delete@example.com", "password": "StrongPass123",
            })
            token = login_r.json()["tokens"]["access_token"]

            r = client.delete("/api/v1/me", headers={"Authorization": f"Bearer {token}"})
            assert r.status_code == 204

            # Subsequent /me calls should fail (user is soft-deleted)
            r2 = client.get("/api/v1/me", headers={"Authorization": f"Bearer {token}"})
            assert r2.status_code == 401

    def test_get_my_activity_returns_audit_log(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "activity@example.com")
            login_r = client.post("/api/v1/auth/login", json={
                "email": "activity@example.com", "password": "StrongPass123",
            })
            token = login_r.json()["tokens"]["access_token"]

            r = client.get("/api/v1/me/activity", headers={"Authorization": f"Bearer {token}"})
            assert r.status_code == 200
            events = r.json()
            assert isinstance(events, list)
            assert len(events) >= 1  # at least the login event
            assert any(e["event_type"] == "login" for e in events)
