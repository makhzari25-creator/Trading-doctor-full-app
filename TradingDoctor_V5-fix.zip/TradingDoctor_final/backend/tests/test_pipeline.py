# -*- coding: utf-8 -*-
"""
tests/test_pipeline.py
-------------------------
تست دودی (smoke test) ساده برای اطمینان از اینکه کل خط لوله (Behavior →
Score → Evidence → Diagnosis → Psychology → Coaching → Report) بدون خطا
اجرا می‌شود، حتی وقتی هیچ LLM API key ای تنظیم نشده باشد.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from engines.behavior_engine import BehaviorEngine
from engines.score_engine import ScoreEngine
from engines.risk_engine import RiskEngine
from engines.coaching_engine import CoachingEngine
from engines.report_engine import ReportEngine


def _sample_df() -> pd.DataFrame:
    return pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=30, freq="6h"),
        "Profit": [10, -20, -30, 15, -5, 8, -40, 12, -10, 5] * 3,
        "Size": [1, 1.2, 1.5, 1, 1, 1.1, 2.0, 1, 1, 1] * 3,
    })


def test_full_pipeline_runs_without_llm():
    df = _sample_df()
    doctor = BehaviorEngine(df)
    result = ScoreEngine(doctor).run()

    assert result.performance["total_trades"] == 30
    assert "revenge_score" in result.context

    coach = CoachingEngine(doctor).generate(result)
    assert "trader_dna" in coach
    assert "diagnosis" in coach
    assert isinstance(coach["explainable_ai"], str)

    text_report = ReportEngine(result, coach).to_text()
    assert "SUMMARY" in text_report


def test_risk_engine_facade():
    df = _sample_df()
    risk = RiskEngine(df)
    report = risk.risk_report()
    assert "revenge_score" in report
    assert "position_sizing" in report


if __name__ == "__main__":
    test_full_pipeline_runs_without_llm()
    test_risk_engine_facade()
    print("OK - all smoke tests passed")
