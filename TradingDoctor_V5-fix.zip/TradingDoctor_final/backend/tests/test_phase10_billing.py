# -*- coding: utf-8 -*-
"""tests/test_phase10_billing.py — Phase 10 subscription & billing tests.

Tests cover:
  - Plan seeding (idempotent, all 3 tiers present)
  - Plan lookup (by tier, by id, list public)
  - Subscription lifecycle (auto-assign free, ensure_free_subscription)
  - Usage tracking (record_analysis_run, record_upload_bytes, aggregation)
  - Tier enforcement (check_analysis_allowed, check_upload_allowed, check_llm_call_allowed)
  - Feature flags (plan_allows_feature)
  - Billing endpoints (list plans, current plan, usage, checkout stub)
  - Webhook signature verification (rejects invalid signatures)
  - Webhook event dispatch (subscription created/updated/deleted, invoice paid)
  - Engine immutability (billing/ never imports engines/)
"""

from __future__ import annotations

import asyncio
import io
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import pandas as pd
import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Env setup (shared with prior phases)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _setup_test_env():
    os.environ["JWT_SECRET_KEY"] = "a" * 64
    os.environ["JWT_REFRESH_SECRET_KEY"] = "b" * 64
    os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ["TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY"] = "false"
    os.environ["EMAIL_BACKEND"] = "console"
    os.environ["AUTO_ASSIGN_FREE_PLAN"] = "true"
    # Stripe test keys (not real)
    os.environ["STRIPE_SECRET_KEY"] = "sk_test_" + "x" * 30
    os.environ["STRIPE_WEBHOOK_SECRET"] = "whsec_" + "x" * 30

    import importlib
    import db.base
    importlib.reload(db.base)
    import auth.config
    importlib.reload(auth.config)
    import auth.models
    importlib.reload(auth.models)
    import workspace.models
    importlib.reload(workspace.models)
    import billing.config
    importlib.reload(billing.config)
    import billing.models
    importlib.reload(billing.models)
    yield


@pytest_asyncio.fixture
async def db_engine(_setup_test_env, tmp_path):
    import db.base
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file}")
    import auth.models  # noqa: F401
    import workspace.models  # noqa: F401
    import billing.models  # noqa: F401
    async with engine.begin() as conn:
        await conn.run_sync(db.base.Base.metadata.create_all)

    # Seed billing plans.
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
    seed_factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with seed_factory() as session:
        from billing.services.plans import seed_plans
        await seed_plans(session)
        await session.commit()

    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncIterator[AsyncSession]:
    factory = async_sessionmaker(
        bind=db_engine, class_=AsyncSession,
        expire_on_commit=False, autoflush=False,
    )
    async with factory() as session:
        try:
            yield session
        finally:
            await session.close()


async def _create_user(db, email: str = "test@example.com"):
    """Helper: create + verify a user, return the User object."""
    from auth.services.users import create_user, verify_email
    user = await create_user(db=db, email=email, password="StrongPass123")
    user = await verify_email(db, user.id)
    await db.commit()
    return user


# ---------------------------------------------------------------------------
# Plan tests
# ---------------------------------------------------------------------------

class TestPlans:
    @pytest.mark.asyncio
    async def test_seed_plans_creates_three_tiers(self, db_session):
        from billing.services.plans import seed_plans, get_plan_by_tier
        from billing.models import PlanTier

        # seed_plans was already called by the fixture, so this should be 0
        count = await seed_plans(db_session)
        assert count == 0  # already seeded

        # Verify all three tiers exist
        free = await get_plan_by_tier(db_session, PlanTier.free)
        assert free is not None
        assert free.tier == PlanTier.free
        assert free.price_cents == 0

        pro = await get_plan_by_tier(db_session, PlanTier.pro)
        assert pro is not None
        assert pro.price_cents == 1900  # $19

        premium = await get_plan_by_tier(db_session, PlanTier.premium)
        assert premium is not None
        assert premium.price_cents == 4900  # $49

    @pytest.mark.asyncio
    async def test_seed_plans_is_idempotent(self, db_session):
        """Calling seed_plans twice doesn't create duplicates."""
        from billing.services.plans import seed_plans
        # Already seeded by fixture
        count1 = await seed_plans(db_session)
        count2 = await seed_plans(db_session)
        assert count1 == 0
        assert count2 == 0

    @pytest.mark.asyncio
    async def test_list_public_plans_sorted(self, db_session):
        from billing.services.plans import list_public_plans
        plans = await list_public_plans(db_session)
        assert len(plans) == 3
        # Sorted by sort_order: free (1), pro (2), premium (3)
        assert plans[0].tier.value == "free"
        assert plans[1].tier.value == "pro"
        assert plans[2].tier.value == "premium"

    @pytest.mark.asyncio
    async def test_plan_to_dict_serialization(self, db_session):
        from billing.services.plans import get_plan_by_tier, plan_to_dict
        from billing.models import PlanTier
        plan = await get_plan_by_tier(db_session, PlanTier.pro)
        d = plan_to_dict(plan)
        assert d["tier"] == "pro"
        assert d["price_cents"] == 1900
        assert "limits" in d
        assert "features" in d
        assert d["limits"]["max_analyses_per_month"] == 100


# ---------------------------------------------------------------------------
# Subscription tests
# ---------------------------------------------------------------------------

class TestSubscriptions:
    @pytest.mark.asyncio
    async def test_ensure_free_subscription_creates_one(self, db_session):
        from billing.services.subscriptions import (
            ensure_free_subscription, get_user_subscription,
        )
        user = await _create_user(db_session, "sub@example.com")

        sub = await ensure_free_subscription(db_session, user.id, user.email)
        await db_session.commit()
        assert sub.id is not None
        assert sub.status.value == "active"

        # Fetch it back
        fetched = await get_user_subscription(db_session, user.id)
        assert fetched is not None
        assert fetched.id == sub.id

    @pytest.mark.asyncio
    async def test_ensure_free_subscription_is_idempotent(self, db_session):
        """Calling twice returns the same subscription (no duplicate)."""
        from billing.services.subscriptions import ensure_free_subscription
        user = await _create_user(db_session, "idem@example.com")

        sub1 = await ensure_free_subscription(db_session, user.id, user.email)
        await db_session.commit()
        sub2 = await ensure_free_subscription(db_session, user.id, user.email)
        await db_session.commit()
        assert sub1.id == sub2.id

    @pytest.mark.asyncio
    async def test_get_user_plan_returns_plan(self, db_session):
        from billing.services.subscriptions import (
            ensure_free_subscription, get_user_plan,
        )
        user = await _create_user(db_session, "plan@example.com")
        await ensure_free_subscription(db_session, user.id, user.email)
        await db_session.commit()

        plan = await get_user_plan(db_session, user.id)
        assert plan is not None
        assert plan.tier.value == "free"

    @pytest.mark.asyncio
    async def test_get_user_plan_returns_none_without_subscription(self, db_session):
        from billing.services.subscriptions import get_user_plan
        user = await _create_user(db_session, "noplan@example.com")
        # Don't call ensure_free_subscription
        plan = await get_user_plan(db_session, user.id)
        assert plan is None

    @pytest.mark.asyncio
    async def test_upsert_subscription_from_stripe_creates_new(self, db_session):
        """Webhook-driven upsert creates a subscription for a new Stripe sub."""
        from billing.services.subscriptions import (
            upsert_subscription_from_stripe, get_subscription_by_stripe_id,
        )
        from billing.services.plans import get_plan_by_tier
        from billing.models import PlanTier
        user = await _create_user(db_session, "stripe@example.com")
        await db_session.commit()

        # Set a stripe_price_id on the pro plan so we can match it
        pro_plan = await get_plan_by_tier(db_session, PlanTier.pro)
        pro_plan.stripe_price_id = "price_test_pro_123"
        await db_session.commit()

        # Simulate a Stripe webhook creating a pro subscription
        sub = await upsert_subscription_from_stripe(
            db=db_session,
            stripe_subscription_id="sub_test_123",
            stripe_customer_id="cus_test_456",
            status="active",
            current_period_start=datetime.now(timezone.utc),
            current_period_end=datetime.now(timezone.utc),
            price_id="price_test_pro_123",
            user_id=user.id,
        )
        await db_session.commit()

        assert sub.stripe_subscription_id == "sub_test_123"
        assert sub.stripe_customer_id == "cus_test_456"
        assert sub.plan.tier == PlanTier.pro

        # Fetch by stripe_id
        fetched = await get_subscription_by_stripe_id(db_session, "sub_test_123")
        assert fetched is not None
        assert fetched.id == sub.id


# ---------------------------------------------------------------------------
# Usage tracking tests
# ---------------------------------------------------------------------------

class TestUsageTracking:
    @pytest.mark.asyncio
    async def test_record_analysis_run(self, db_session):
        from billing.services.usage import (
            record_analysis_run, get_monthly_usage, get_user_usage_summary,
        )
        from billing.models import UsageEventType
        user = await _create_user(db_session, "usage@example.com")

        analysis_id = uuid.uuid4()
        await record_analysis_run(db_session, user.id, analysis_id, llm_provider="none")
        await db_session.commit()

        count = await get_monthly_usage(db_session, user.id, UsageEventType.analysis_run)
        assert count == 1

        summary = await get_user_usage_summary(db_session, user.id)
        assert summary["analyses_run"] == 1
        assert summary["llm_calls"] == 0  # none provider → no LLM call

    @pytest.mark.asyncio
    async def test_record_analysis_run_with_llm(self, db_session):
        from billing.services.usage import (
            record_analysis_run, get_monthly_usage,
        )
        from billing.models import UsageEventType
        user = await _create_user(db_session, "llm@example.com")

        analysis_id = uuid.uuid4()
        await record_analysis_run(db_session, user.id, analysis_id, llm_provider="gemini")
        await db_session.commit()

        analyses = await get_monthly_usage(db_session, user.id, UsageEventType.analysis_run)
        llm_calls = await get_monthly_usage(db_session, user.id, UsageEventType.llm_call)
        assert analyses == 1
        assert llm_calls == 1

    @pytest.mark.asyncio
    async def test_record_upload_bytes(self, db_session):
        from billing.services.usage import (
            record_upload_bytes, get_monthly_usage,
        )
        from billing.models import UsageEventType
        user = await _create_user(db_session, "upusage@example.com")

        upload_id = uuid.uuid4()
        await record_upload_bytes(db_session, user.id, upload_id, 1024 * 1024)
        await db_session.commit()

        total_bytes = await get_monthly_usage(db_session, user.id, UsageEventType.upload_bytes)
        assert total_bytes == 1024 * 1024

    @pytest.mark.asyncio
    async def test_usage_aggregates_multiple_events(self, db_session):
        from billing.services.usage import (
            record_analysis_run, get_monthly_usage,
        )
        from billing.models import UsageEventType
        user = await _create_user(db_session, "agg@example.com")

        for i in range(5):
            await record_analysis_run(db_session, user.id, uuid.uuid4(), "none")
        await db_session.commit()

        count = await get_monthly_usage(db_session, user.id, UsageEventType.analysis_run)
        assert count == 5


# ---------------------------------------------------------------------------
# Tier enforcement tests
# ---------------------------------------------------------------------------

class TestTierEnforcement:
    @pytest.mark.asyncio
    async def test_check_analysis_allowed_under_limit(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_analysis_allowed
        from billing.models import PlanTier
        user = await _create_user(db_session, "allow@example.com")

        plan = await get_plan_by_tier(db_session, PlanTier.free)
        # Free plan allows 5 analyses/month; user has 0
        allowed, msg, current, maximum = await check_analysis_allowed(db_session, user.id, plan)
        assert allowed is True
        assert msg is None
        assert current == 0
        assert maximum == 5

    @pytest.mark.asyncio
    async def test_check_analysis_blocked_over_limit(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_analysis_allowed, record_analysis_run
        from billing.models import PlanTier
        user = await _create_user(db_session, "block@example.com")

        # Record 5 analyses (the free limit)
        for _ in range(5):
            await record_analysis_run(db_session, user.id, uuid.uuid4(), "none")
        await db_session.commit()

        plan = await get_plan_by_tier(db_session, PlanTier.free)
        allowed, msg, current, maximum = await check_analysis_allowed(db_session, user.id, plan)
        assert allowed is False
        assert msg is not None
        assert "تکمیل" in msg  # Persian: "completed"
        assert current == 5
        assert maximum == 5

    @pytest.mark.asyncio
    async def test_check_analysis_unlimited_for_premium(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_analysis_allowed, record_analysis_run
        from billing.models import PlanTier
        user = await _create_user(db_session, "unlim@example.com")

        # Record 100 analyses
        for _ in range(100):
            await record_analysis_run(db_session, user.id, uuid.uuid4(), "none")
        await db_session.commit()

        plan = await get_plan_by_tier(db_session, PlanTier.premium)
        allowed, msg, current, maximum = await check_analysis_allowed(db_session, user.id, plan)
        # Premium is unlimited
        assert allowed is True
        assert maximum == -1

    @pytest.mark.asyncio
    async def test_check_upload_allowed_per_file_size(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_upload_allowed
        from billing.models import PlanTier
        user = await _create_user(db_session, "upsize@example.com")

        plan = await get_plan_by_tier(db_session, PlanTier.free)
        # Free plan: max_upload_size_bytes = 5 MB
        allowed, msg = await check_upload_allowed(db_session, user.id, plan, 1 * 1024 * 1024)
        assert allowed is True

        allowed, msg = await check_upload_allowed(db_session, user.id, plan, 10 * 1024 * 1024)
        assert allowed is False
        assert "حجم" in msg  # Persian: "size"

    @pytest.mark.asyncio
    async def test_check_llm_call_blocked_for_free(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_llm_call_allowed
        from billing.models import PlanTier
        user = await _create_user(db_session, "nofree@example.com")

        plan = await get_plan_by_tier(db_session, PlanTier.free)
        allowed, msg = await check_llm_call_allowed(db_session, user.id, plan)
        assert allowed is False
        assert "پشتیبانی نمی‌کند" in msg  # Persian: "does not support"

    @pytest.mark.asyncio
    async def test_check_llm_call_allowed_for_pro(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import check_llm_call_allowed
        from billing.models import PlanTier
        user = await _create_user(db_session, "proai@example.com")

        plan = await get_plan_by_tier(db_session, PlanTier.pro)
        allowed, msg = await check_llm_call_allowed(db_session, user.id, plan)
        assert allowed is True
        assert msg is None


# ---------------------------------------------------------------------------
# Feature flag tests
# ---------------------------------------------------------------------------

class TestFeatureFlags:
    @pytest.mark.asyncio
    async def test_free_plan_features(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import plan_allows_feature
        from billing.models import PlanTier
        plan = await get_plan_by_tier(db_session, PlanTier.free)
        assert plan_allows_feature(plan, "pdf_export") is True
        assert plan_allows_feature(plan, "ai_coaching") is False
        assert plan_allows_feature(plan, "history_search") is False
        assert plan_allows_feature(plan, "favorites") is True
        assert plan_allows_feature(plan, "priority_support") is False

    @pytest.mark.asyncio
    async def test_pro_plan_features(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import plan_allows_feature
        from billing.models import PlanTier
        plan = await get_plan_by_tier(db_session, PlanTier.pro)
        assert plan_allows_feature(plan, "ai_coaching") is True
        assert plan_allows_feature(plan, "history_search") is True
        assert plan_allows_feature(plan, "priority_support") is False

    @pytest.mark.asyncio
    async def test_premium_plan_features(self, db_session):
        from billing.services.plans import get_plan_by_tier
        from billing.services.usage import plan_allows_feature
        from billing.models import PlanTier
        plan = await get_plan_by_tier(db_session, PlanTier.premium)
        assert plan_allows_feature(plan, "priority_support") is True


# ---------------------------------------------------------------------------
# Billing config validation
# ---------------------------------------------------------------------------

class TestBillingConfig:
    def test_validate_billing_config_passes_with_keys(self, _setup_test_env):
        from billing import config as billing_config
        # Env is set by fixture
        problems = billing_config.validate_billing_config()
        # In test mode with keys set, should have no problems
        assert problems == []

    def test_validate_billing_config_detects_missing_secret(self, monkeypatch):
        from billing import config as billing_config
        monkeypatch.setattr(billing_config, "STRIPE_SECRET_KEY", "")
        problems = billing_config.validate_billing_config()
        assert any("STRIPE_SECRET_KEY" in p for p in problems)

    def test_validate_billing_config_detects_missing_webhook_secret(self, monkeypatch):
        from billing import config as billing_config
        monkeypatch.setattr(billing_config, "STRIPE_WEBHOOK_SECRET", "")
        problems = billing_config.validate_billing_config()
        assert any("WEBHOOK" in p for p in problems)


# ---------------------------------------------------------------------------
# Webhook signature verification tests
# ---------------------------------------------------------------------------

class TestWebhookSecurity:
    def test_webhook_without_signature_returns_400(self, app_with_db):
        """A webhook without Stripe-Signature header must be rejected."""
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post(
                "/api/v1/billing/webhooks/stripe",
                content=b'{"type": "test"}',
                headers={"Content-Type": "application/json"},
            )
            assert r.status_code == 400
            body = r.json()
            assert body["error"]["code"] == "missing_signature"

    def test_webhook_with_malformed_signature_returns_400(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post(
                "/api/v1/billing/webhooks/stripe",
                content=b'{"type": "test"}',
                headers={
                    "Content-Type": "application/json",
                    "Stripe-Signature": "garbage",
                },
            )
            assert r.status_code == 400
            body = r.json()
            assert body["error"]["code"] in ("malformed_signature", "invalid_signature")

    def test_webhook_with_invalid_signature_returns_400(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.post(
                "/api/v1/billing/webhooks/stripe",
                content=b'{"type": "test"}',
                headers={
                    "Content-Type": "application/json",
                    "Stripe-Signature": "t=1234567890,v1=invalidsignature",
                },
            )
            assert r.status_code == 400
            assert r.json()["error"]["code"] == "invalid_signature"

    @pytest_asyncio.fixture
    async def app_with_db(self, db_engine, monkeypatch):
        """FastAPI app wired to test DB."""
        import db.base
        from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

        factory = async_sessionmaker(
            bind=db_engine, class_=AsyncSession,
            expire_on_commit=False, autoflush=False,
        )
        monkeypatch.setattr(db.base, "engine", db_engine)
        monkeypatch.setattr(db.base, "async_session_factory", factory)

        from api.main import app
        app.dependency_overrides.clear()
        app._test_db_factory = factory  # type: ignore[attr-defined]

        yield app

        app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Billing endpoint tests
# ---------------------------------------------------------------------------

class TestBillingEndpoints:
    @pytest_asyncio.fixture
    async def app_with_db(self, db_engine, monkeypatch):
        import db.base
        from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

        factory = async_sessionmaker(
            bind=db_engine, class_=AsyncSession,
            expire_on_commit=False, autoflush=False,
        )
        monkeypatch.setattr(db.base, "engine", db_engine)
        monkeypatch.setattr(db.base, "async_session_factory", factory)

        from api.main import app
        app.dependency_overrides.clear()
        app._test_db_factory = factory  # type: ignore[attr-defined]

        yield app

        app.dependency_overrides.clear()

    def _register_and_verify(self, app, client, email):
        import asyncio
        factory = app._test_db_factory  # type: ignore[attr-defined]
        r = client.post("/api/v1/auth/register", json={
            "email": email, "password": "StrongPass123",
        })
        assert r.status_code == 201, r.text
        user_id = r.json()["user_id"]

        async def _verify():
            from auth.services.users import verify_email
            async with factory() as session:
                await verify_email(session, uuid.UUID(user_id))
                await session.commit()
        asyncio.run(_verify())
        return user_id

    def _login(self, client, email):
        r = client.post("/api/v1/auth/login", json={
            "email": email, "password": "StrongPass123",
        })
        assert r.status_code == 200, r.text
        return r.json()["tokens"]["access_token"]

    def test_list_plans_endpoint(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "plans@example.com")
            token = self._login(client, "plans@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            r = client.get("/api/v1/billing/plans", headers=headers)
            assert r.status_code == 200
            body = r.json()
            assert len(body["plans"]) == 3
            tiers = [p["tier"] for p in body["plans"]]
            assert "free" in tiers
            assert "pro" in tiers
            assert "premium" in tiers

    def test_current_plan_endpoint(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "cur@example.com")
            token = self._login(client, "cur@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            r = client.get("/api/v1/billing/current-plan", headers=headers)
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["tier"] == "free"
            assert body["is_active"] is True

    def test_usage_endpoint(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "use@example.com")
            token = self._login(client, "use@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            r = client.get("/api/v1/billing/usage", headers=headers)
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["analyses_run"] == 0
            assert body["llm_calls"] == 0
            assert "plan_limits" in body
            assert body["plan_limits"]["max_analyses_per_month"] == 5

    def test_subscription_endpoint(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "sub2@example.com")
            token = self._login(client, "sub2@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            r = client.get("/api/v1/billing/subscription", headers=headers)
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["plan"]["tier"] == "free"
            assert body["status"] == "active"

    def test_checkout_rejects_free_tier(self, app_with_db):
        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            self._register_and_verify(app_with_db, client, "nocheck@example.com")
            token = self._login(client, "nocheck@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            # Trying to "checkout" the free tier is meaningless
            r = client.post("/api/v1/billing/checkout", headers=headers, json={
                "target_tier": "free",
                "success_url": "https://example.com/success",
                "cancel_url": "https://example.com/cancel",
            })
            # This is a bad *request* (nothing to check out for the free
            # tier), not an auth failure, so it correctly maps to 400 via
            # BillingError, not 401.
            assert r.status_code == 400
            assert r.json()["error"]["code"] == "billing_error"

    def test_billing_endpoints_require_auth(self, app_with_db, monkeypatch):
        """Billing endpoints must reject unauthenticated requests.

        NOTE: Rate limiter is shared across tests in the same session; we
        disable it here so the test doesn't get a spurious 429.
        """
        from api import config as api_config
        monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", False)

        from fastapi.testclient import TestClient
        with TestClient(app_with_db) as client:
            r = client.get("/api/v1/billing/plans")
            assert r.status_code == 401

            r = client.get("/api/v1/billing/current-plan")
            assert r.status_code == 401

            r = client.get("/api/v1/billing/usage")
            assert r.status_code == 401


# ---------------------------------------------------------------------------
# Auto-assign free plan on registration
# ---------------------------------------------------------------------------

class TestAutoAssignFreePlan:
    @pytest_asyncio.fixture
    async def app_with_db(self, db_engine, monkeypatch):
        import db.base
        from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

        factory = async_sessionmaker(
            bind=db_engine, class_=AsyncSession,
            expire_on_commit=False, autoflush=False,
        )
        monkeypatch.setattr(db.base, "engine", db_engine)
        monkeypatch.setattr(db.base, "async_session_factory", factory)

        from api.main import app
        app.dependency_overrides.clear()
        app._test_db_factory = factory  # type: ignore[attr-defined]

        yield app

        app.dependency_overrides.clear()

    def test_registration_auto_assigns_free_plan(self, app_with_db):
        """When AUTO_ASSIGN_FREE_PLAN=true, registration creates a free sub."""
        import asyncio
        from fastapi.testclient import TestClient
        factory = app_with_db._test_db_factory  # type: ignore[attr-defined]

        with TestClient(app_with_db) as client:
            r = client.post("/api/v1/auth/register", json={
                "email": "auto@example.com", "password": "StrongPass123",
            })
            assert r.status_code == 201
            user_id = r.json()["user_id"]

            # Verify the user has a free subscription
            async def _check():
                from billing.services.subscriptions import get_user_subscription
                async with factory() as session:
                    sub = await get_user_subscription(session, uuid.UUID(user_id))
                    return sub
            sub = asyncio.run(_check())
            assert sub is not None
            assert sub.plan.tier.value == "free"


# ---------------------------------------------------------------------------
# Engine immutability check
# ---------------------------------------------------------------------------

class TestEngineImmutability:
    def test_billing_layer_does_not_import_engines(self):
        """The billing/ layer must NOT import any frozen V23 engine module."""
        import inspect
        import billing
        from billing.routers import billing as billing_router, webhooks as webhooks_router
        from billing.services import (
            plans, stripe_provider, subscriptions, usage,
        )

        modules_to_check = [
            billing, billing_router, webhooks_router,
            plans, stripe_provider, subscriptions, usage,
        ]
        for mod in modules_to_check:
            src = inspect.getsource(mod)
            assert "from engines" not in src, \
                f"{mod.__name__} must not import from engines/"
            assert "import engines" not in src, \
                f"{mod.__name__} must not import engines/"
