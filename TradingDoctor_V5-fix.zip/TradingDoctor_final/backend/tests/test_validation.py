# -*- coding: utf-8 -*-
"""
tests/test_validation.py
---------------------------
تست واحد برای utils/validation.py (Step 4/13 از پروسه‌ی V23:
اعتبارسنجی ورودی + QA).
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import pytest

from utils.validation import validate_and_normalize, DataValidationError


def test_none_dataframe_raises():
    with pytest.raises(DataValidationError):
        validate_and_normalize(None)


def test_wrong_type_raises():
    with pytest.raises(DataValidationError):
        validate_and_normalize("not a dataframe")


def test_empty_dataframe_raises():
    with pytest.raises(DataValidationError):
        validate_and_normalize(pd.DataFrame())


def test_single_column_raises():
    with pytest.raises(DataValidationError):
        validate_and_normalize(pd.DataFrame({"OnlyOne": [1, 2, 3]}))


def test_unrecognizable_columns_raise_clear_error():
    df = pd.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    with pytest.raises(DataValidationError) as exc_info:
        validate_and_normalize(df)
    # پیام باید نام ستون‌های واقعی فایل را برای کاربر نشان دهد
    assert "A" in str(exc_info.value) and "B" in str(exc_info.value)


def test_good_dataframe_passes_with_no_warnings():
    df = pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=20, freq="h"),
        "Profit": [10, -5, 8, -3, 12, -7, 4, -2, 6, -9] * 2,
        "Size": [1.0, 1.1, 1.2, 1.0, 1.3, 1.0, 1.1, 1.2, 1.0, 1.1] * 2,
    })
    normalized, warnings = validate_and_normalize(df)
    assert len(normalized) == 20
    assert "Profit" in normalized.columns
    assert warnings == []


def test_duplicate_rows_generate_warning_but_do_not_raise():
    df = pd.DataFrame({
        "Open Time": ["2024-01-01 10:00"] * 10,
        "Profit": [10] * 10,
        "Size": [1.0] * 10,
    })
    normalized, warnings = validate_and_normalize(df)
    assert len(normalized) == 10  # هیچ ردیفی حذف نشده
    assert any("تکراری" in w for w in warnings)


def test_zero_size_generates_warning():
    df = pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=10, freq="h"),
        "Profit": [10, -5, 8, -3, 12, -7, 4, -2, 6, -9],
        "Size": [1.0, 0, 1.2, 1.0, 0, 1.0, 1.1, 1.2, 1.0, 1.1],
    })
    normalized, warnings = validate_and_normalize(df)
    assert any("حجم صفر یا منفی" in w for w in warnings)


def test_net_zero_profit_is_not_falsely_flagged_as_missing():
    """[FIX چک‌شده] ستونی که واقعاً Profit است ولی مجموعش صفر می‌شود
    (بردها و باخت‌ها دقیقاً خنثی) نباید به‌اشتباه 'شناسایی نشد' اعلام شود."""
    df = pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=4, freq="h"),
        "Profit": [10, -10, 5, -5],
        "Size": [1.0, 1.0, 1.0, 1.0],
    })
    assert df["Profit"].sum() == 0
    normalized, warnings = validate_and_normalize(df)
    assert not any("سود/زیان" in w for w in warnings)


if __name__ == "__main__":
    import sys as _sys
    raise SystemExit(pytest.main([__file__, "-v"]))
