# -*- coding: utf-8 -*-
"""
tests/test_reporting.py
--------------------------
تست‌های Phase 2 (ماژول گزارش‌گیری). این تست‌ها تضمین می‌کنند:
  1) هر ۱۵ بخش گزارش HTML واقعاً رندر می‌شود (نه فقط "کرش نمی‌کند").
  2) PDF یک فایل معتبر (magic bytes %PDF-) با تعداد صفحه‌ی معقول تولید می‌کند.
  3) هیچ‌کدام روی داده‌های حاشیه‌ای (خالی، تک‌معامله، بدون‌باخت، بدون‌برد،
     بدون ستون زمان) کرش نمی‌کنند.
  4) هیچ syntax نشتی‌یافته‌ی Jinja2 ({{ }} یا Undefined) در خروجی نیست.
  5) HTML و PDF از یک context یکسان تغذیه می‌شوند (همان اعداد کلیدی).
"""

import re

import pandas as pd
import pytest

from core.service import analyze_dataframe
from reporting import generate_html_report, generate_pdf_report, ReportRenderError
from reporting.data_context import build_report_context

REQUIRED_SECTION_IDS = [
    "sec-executive-summary", "sec-overall-score", "sec-diagnosis",
    "sec-trader-profile", "sec-strengths-weaknesses", "sec-behavior-analysis",
    "sec-psychology", "sec-evidence", "sec-statistics", "sec-performance",
    "sec-risk", "sec-charts", "sec-recommendations", "sec-ai-coaching", "sec-appendix",
]


def _sample_df(n=100, seed=1):
    import numpy as np
    rng = np.random.default_rng(seed)
    return pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=n, freq="90min"),
        "Profit": rng.normal(0, 20, n).round(2),
        "Size": abs(rng.normal(1, 0.3, n)).round(2),
    })


def test_html_report_contains_all_15_sections():
    doctor, result, coach = analyze_dataframe(_sample_df(), llm_provider="none")
    html = generate_html_report(result, coach, doctor)
    for section_id in REQUIRED_SECTION_IDS:
        assert f'id="{section_id}"' in html, f"missing section: {section_id}"


def test_html_report_has_no_leaked_template_syntax():
    doctor, result, coach = analyze_dataframe(_sample_df(), llm_provider="none")
    html = generate_html_report(result, coach, doctor)
    assert "{{" not in html and "}}" not in html
    assert "Undefined" not in html


def test_html_report_embeds_charts_as_base64():
    doctor, result, coach = analyze_dataframe(_sample_df(), llm_provider="none")
    html = generate_html_report(result, coach, doctor)
    # هر ۸ نمودار باید به‌صورت data URI base64 داخل HTML قرار گرفته باشند
    assert html.count("data:image/png;base64,") >= 8


def test_pdf_report_is_valid_pdf():
    doctor, result, coach = analyze_dataframe(_sample_df(), llm_provider="none")
    pdf_bytes = generate_pdf_report(result, coach, doctor)
    assert pdf_bytes[:5] == b"%PDF-"
    assert len(pdf_bytes) > 10_000  # یک PDF واقعی و نه یک فایل خالی/شکسته


@pytest.mark.parametrize("df_builder", [
    lambda: pd.DataFrame({"Profit": [10, -5, 3], "Size": [1.0, 1.0, 1.0]}),          # no time column
    lambda: pd.DataFrame({"Profit": [42], "Size": [1.0]}),                            # single trade
    lambda: pd.DataFrame({                                                            # all wins
        "Open Time": pd.date_range("2024-01-01", periods=10, freq="h"),
        "Profit": [5, 6, 7, 8, 9, 10, 11, 12, 13, 14], "Size": [1.0] * 10,
    }),
    lambda: pd.DataFrame({                                                            # all losses
        "Open Time": pd.date_range("2024-01-01", periods=8, freq="h"),
        "Profit": [-1, -2, -3, -4, -5, -6, -7, -8], "Size": [1.0] * 8,
    }),
    lambda: pd.DataFrame({                                                            # net-zero profit
        "Open Time": pd.date_range("2024-01-01", periods=4, freq="h"),
        "Profit": [10, -10, 5, -5], "Size": [1.0] * 4,
    }),
])
def test_html_and_pdf_survive_edge_case_datasets(df_builder):
    df = df_builder()
    doctor, result, coach = analyze_dataframe(df, llm_provider="none")
    html = generate_html_report(result, coach, doctor)
    pdf_bytes = generate_pdf_report(result, coach, doctor)
    assert "{{" not in html and "Undefined" not in html
    assert pdf_bytes[:5] == b"%PDF-"


def test_html_and_pdf_share_identical_headline_numbers():
    """
    HTML و PDF باید دقیقاً همان context مشترک را مصرف کنند — این تست
    مستقیماً بررسی می‌کند که هر دو از یک build_report_context() واحد
    تغذیه می‌شوند، نه اینکه هرکدام جدا داده استخراج کرده باشند.
    """
    doctor, result, coach = analyze_dataframe(_sample_df(seed=7), llm_provider="none")
    ctx1 = build_report_context(result, coach, doctor)
    ctx2 = build_report_context(result, coach, doctor)
    assert ctx1["overall_score"]["value"] == ctx2["overall_score"]["value"]
    assert ctx1["performance"]["net_profit"] == ctx2["performance"]["net_profit"]
    assert ctx1["diagnosis"]["primary"] == ctx2["diagnosis"]["primary"]

    html = generate_html_report(result, coach, doctor)
    pdf_bytes = generate_pdf_report(result, coach, doctor)
    # عدد امتیاز کلی باید در متن HTML قابل‌یافتن باشد (به‌صورت رشته)
    assert str(ctx1["overall_score"]["value"]) in html
    assert pdf_bytes[:5] == b"%PDF-"


def test_report_render_error_on_completely_invalid_input():
    """ورودی نامعتبر باید ReportRenderError بدهد، نه یک traceback خام."""
    with pytest.raises(Exception):
        generate_html_report(None, None, None)
