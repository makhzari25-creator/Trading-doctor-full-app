# -*- coding: utf-8 -*-
"""
tests/test_sequence_analysis.py
----------------------------------
تست واحد برای utils/sequence_analysis.py — تضمین می‌کند که پیاده‌سازی
برداری جدید (که جایگزین ۴ حلقه‌ی دستی تکراری در Engineها شد) دقیقاً همان
نتیجه‌ی عددی نسخه‌ی قدیمی حلقه‌محور را تولید می‌کند.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from utils.sequence_analysis import consecutive_streak, size_increased_mask, revenge_mask_from_df


def _old_loop_streak(mask):
    n = len(mask)
    streak = np.zeros(n, dtype=int)
    running = 0
    for i in range(n):
        if mask[i]:
            running += 1
        else:
            running = 0
        streak[i] = running
    return streak


def test_consecutive_streak_matches_old_loop_on_random_data():
    rng = np.random.default_rng(7)
    for _ in range(100):
        n = rng.integers(0, 60)
        mask = rng.random(n) < 0.5
        assert np.array_equal(_old_loop_streak(mask), consecutive_streak(mask))


def test_consecutive_streak_edge_cases():
    assert list(consecutive_streak(np.array([]))) == []
    assert list(consecutive_streak(np.array([True]))) == [1]
    assert list(consecutive_streak(np.array([False]))) == [0]
    assert list(consecutive_streak(np.array([True, True, False, True]))) == [1, 2, 0, 1]


def test_size_increased_mask_first_row_always_false():
    size = np.array([1.0, 2.0, 0.5, 3.0])
    mask = size_increased_mask(size)
    assert mask[0] == False
    assert mask[1] == True   # 2.0 > 1.0*1.05
    assert mask[2] == False  # 0.5 < 2.0*1.05
    assert mask[3] == True   # 3.0 > 0.5*1.05


def test_revenge_mask_from_df_empty():
    df = pd.DataFrame({"Profit": [], "Size": []})
    mask = revenge_mask_from_df(df)
    assert len(mask) == 0


def test_revenge_mask_from_df_detects_known_pattern():
    # دو باخت پشت‌سرهم + افزایش حجم در باخت دوم = revenge
    df = pd.DataFrame({
        "Profit": [10, -5, -8, 15],
        "Size": [1.0, 1.0, 1.5, 1.0],
    })
    mask = revenge_mask_from_df(df)
    assert list(mask) == [False, False, True, False]


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-v"]))
