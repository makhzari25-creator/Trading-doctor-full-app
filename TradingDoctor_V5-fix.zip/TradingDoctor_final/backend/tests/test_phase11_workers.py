# -*- coding: utf-8 -*-
"""tests/test_phase11_workers.py — Phase 11 worker + async job tests.

Tests cover:
  - AnalysisJob model + migration
  - Celery task module imports (without actually running Celery)
  - _use_celery() env var toggle
  - GET /analyses/jobs/{job_id} endpoint (auth + isolation + 404)
  - Sync mode still works (default — no Celery required)
  - Engine immutability (workers/ never imports engines/)
  - Cleanup task module imports
"""

from __future__ import annotations

import asyncio
import io
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import pandas as pd
import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Env setup (shared with prior phases)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _setup_test_env():
    os.environ["JWT_SECRET_KEY"] = "a" * 64
    os.environ["JWT_REFRESH_SECRET_KEY"] = "b" * 64
    os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///:memory:"
    os.environ["TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY"] = "false"
    os.environ["EMAIL_BACKEND"] = "console"
    os.environ["TRADING_DOCTOR_USE_CELERY"] = "false"  # sync mode for tests

    import importlib
    import db.base
    importlib.reload(db.base)
    import auth.config
    importlib.reload(auth.config)
    import auth.models
    importlib.reload(auth.models)
    import workspace.models
    importlib.reload(workspace.models)
    import billing.config
    importlib.reload(billing.config)
    import billing.models
    importlib.reload(billing.models)
    yield


@pytest_asyncio.fixture
async def db_engine(_setup_test_env, tmp_path):
    import db.base
    db_file = tmp_path / "test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_file}")
    import auth.models  # noqa: F401
    import workspace.models  # noqa: F401
    import billing.models  # noqa: F401
    async with engine.begin() as conn:
        await conn.run_sync(db.base.Base.metadata.create_all)

    # Seed billing plans.
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
    seed_factory = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)
    async with seed_factory() as session:
        from billing.services.plans import seed_plans
        await seed_plans(session)
        await session.commit()

    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def app_with_db(db_engine, monkeypatch):
    import db.base
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

    factory = async_sessionmaker(
        bind=db_engine, class_=AsyncSession,
        expire_on_commit=False, autoflush=False,
    )
    monkeypatch.setattr(db.base, "engine", db_engine)
    monkeypatch.setattr(db.base, "async_session_factory", factory)

    from api.main import app
    app.dependency_overrides.clear()
    app._test_db_factory = factory  # type: ignore[attr-defined]

    yield app

    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncIterator[AsyncSession]:
    """Async DB session for direct repository tests."""
    factory = async_sessionmaker(
        bind=db_engine, class_=AsyncSession,
        expire_on_commit=False, autoflush=False,
    )
    async with factory() as session:
        try:
            yield session
        finally:
            await session.close()


def _register_and_verify(app, client, email):
    import asyncio
    factory = app._test_db_factory  # type: ignore[attr-defined]
    r = client.post("/api/v1/auth/register", json={
        "email": email, "password": "StrongPass123",
    })
    assert r.status_code == 201, r.text
    user_id = r.json()["user_id"]

    async def _verify():
        from auth.services.users import verify_email
        async with factory() as session:
            await verify_email(session, uuid.UUID(user_id))
            await session.commit()
    asyncio.run(_verify())
    return user_id


def _login(client, email):
    r = client.post("/api/v1/auth/login", json={
        "email": email, "password": "StrongPass123",
    })
    assert r.status_code == 200, r.text
    return r.json()["tokens"]["access_token"]


def _sample_csv_bytes(n=50, seed=1):
    import numpy as np
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "Open Time": pd.date_range("2024-01-01", periods=n, freq="90min"),
        "Profit": rng.normal(0, 20, n).round(2),
        "Size": abs(rng.normal(1, 0.3, n)).round(2),
    })
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


# ---------------------------------------------------------------------------
# Worker module import tests
# ---------------------------------------------------------------------------

class TestWorkerModules:
    def test_celery_app_imports(self):
        """Celery app module must import cleanly (no Redis required at import)."""
        from workers.celery_app import app
        assert app is not None
        assert app.main == "tradingdoctor"

    def test_analysis_tasks_import(self):
        """Analysis task module must import cleanly."""
        from workers.tasks import analysis_tasks
        assert hasattr(analysis_tasks, "run_analysis_task")

    def test_email_tasks_import(self):
        """Email task module must import cleanly."""
        from workers.tasks import email_tasks
        assert hasattr(email_tasks, "send_email_verification_task")
        assert hasattr(email_tasks, "send_password_reset_task")
        assert hasattr(email_tasks, "send_welcome_email_task")
        assert hasattr(email_tasks, "send_invoice_email_task")

    def test_cleanup_tasks_import(self):
        """Cleanup task module must import cleanly."""
        from workers.tasks import cleanup_tasks
        assert hasattr(cleanup_tasks, "purge_old_soft_deletes")
        assert hasattr(cleanup_tasks, "purge_old_jobs")
        assert hasattr(cleanup_tasks, "cleanup_orphan_uploads")


# ---------------------------------------------------------------------------
# AnalysisJob model tests
# ---------------------------------------------------------------------------

class TestAnalysisJobModel:
    @pytest.mark.asyncio
    async def test_analysis_job_table_exists(self, db_engine):
        """The analysis_jobs table must be created by the model registration."""
        import db.base
        from workspace.models import AnalysisJob
        async with db_engine.begin() as conn:
            await conn.run_sync(db.base.Base.metadata.create_all)
        # If the table didn't exist, this query would fail
        async with db_engine.connect() as conn:
            from sqlalchemy import text
            result = await conn.execute(text("SELECT count(*) FROM analysis_jobs"))
            assert result.scalar() == 0

    @pytest.mark.asyncio
    async def test_create_analysis_job(self, db_session):
        """Can create an AnalysisJob row."""
        from auth.services.users import create_user, verify_email
        from workspace.repositories.uploads import create_upload
        from workspace.models import AnalysisJob
        from datetime import datetime, timezone

        user = await create_user(db_session, "job@example.com", "StrongPass123")
        user = await verify_email(db_session, user.id)
        await db_session.commit()

        upload = await create_upload(
            db=db_session, user_id=user.id,
            filename="t.csv", raw_bytes=_sample_csv_bytes(),
        )
        await db_session.commit()

        job = AnalysisJob(
            id=uuid.uuid4(),
            user_id=user.id,
            upload_id=upload.id,
            llm_provider="none",
            status="pending",
        )
        db_session.add(job)
        await db_session.commit()

        assert job.id is not None
        assert job.status == "pending"
        assert job.created_at is not None


# ---------------------------------------------------------------------------
# _use_celery toggle tests
# ---------------------------------------------------------------------------

class TestCeleryToggle:
    def test_use_celery_false_by_default(self, monkeypatch):
        """When TRADING_DOCTOR_USE_CELERY is unset, sync mode is used."""
        monkeypatch.delenv("TRADING_DOCTOR_USE_CELERY", raising=False)
        from api.routers.analyses import _use_celery
        assert _use_celery() is False

    def test_use_celery_true_when_enabled(self, monkeypatch):
        """When TRADING_DOCTOR_USE_CELERY=true, async mode is used."""
        monkeypatch.setenv("TRADING_DOCTOR_USE_CELERY", "true")
        from api.routers.analyses import _use_celery
        assert _use_celery() is True

    def test_use_celery_accepts_1_and_yes(self, monkeypatch):
        for val in ("1", "yes", "YES", "True"):
            monkeypatch.setenv("TRADING_DOCTOR_USE_CELERY", val)
            from api.routers.analyses import _use_celery
            assert _use_celery() is True, f"Failed for value={val!r}"

    def test_use_celery_rejects_other_values(self, monkeypatch):
        for val in ("false", "0", "no", "", "garbage"):
            monkeypatch.setenv("TRADING_DOCTOR_USE_CELERY", val)
            from api.routers.analyses import _use_celery
            assert _use_celery() is False, f"Failed for value={val!r}"


# ---------------------------------------------------------------------------
# Sync mode endpoint tests (default — no Celery)
# ---------------------------------------------------------------------------

class TestSyncMode:
    def test_sync_mode_returns_201_with_summary(self, app_with_db):
        """When Celery is disabled, POST /analyses returns 201 + AnalysisSummary."""
        from api.routers.analyses import _use_celery
        assert _use_celery() is False  # verify test env

        with TestClient(app_with_db) as client:
            _register_and_verify(app_with_db, client, "sync@example.com")
            token = _login(client, "sync@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            # Upload
            r = client.post("/api/v1/uploads",
                            files={"file": ("t.csv", _sample_csv_bytes(), "text/csv")},
                            headers=headers)
            upload_id = r.json()["upload_id"]

            # Analyze (sync)
            r = client.post("/api/v1/analyses",
                            json={"upload_id": upload_id, "llm_provider": "none"},
                            headers=headers)
            assert r.status_code == 201, r.text
            body = r.json()
            assert "analysis_id" in body
            assert "total_trades" in body
            assert "job_id" not in body  # sync mode doesn't return job_id


# ---------------------------------------------------------------------------
# Job status endpoint tests
# ---------------------------------------------------------------------------

class TestJobStatusEndpoint:
    def test_job_status_requires_auth(self, app_with_db, monkeypatch):
        """GET /analyses/jobs/{id} must require authentication."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", False)

        with TestClient(app_with_db) as client:
            r = client.get(f"/api/v1/analyses/jobs/{uuid.uuid4()}")
            assert r.status_code == 401

    def test_job_status_returns_404_for_unknown_job(self, app_with_db, monkeypatch):
        """A valid UUID that doesn't exist must return 404."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", False)

        with TestClient(app_with_db) as client:
            _register_and_verify(app_with_db, client, "job404@example.com")
            token = _login(client, "job404@example.com")
            headers = {"Authorization": f"Bearer {token}"}

            r = client.get(f"/api/v1/analyses/jobs/{uuid.uuid4()}", headers=headers)
            assert r.status_code == 404
            assert r.json()["error"]["code"] == "not_found"

    def test_job_status_isolates_by_user(self, app_with_db, monkeypatch):
        """User B cannot see User A's job."""
        from api import config as api_config
        monkeypatch.setattr(api_config, "RATE_LIMIT_ENABLED", False)

        with TestClient(app_with_db) as client:
            # User A
            _register_and_verify(app_with_db, client, "joba@example.com")
            token_a = _login(client, "joba@example.com")

            # User B
            _register_and_verify(app_with_db, client, "jobb@example.com")
            token_b = _login(client, "jobb@example.com")

            # Create a job as User A (via direct DB insert since Celery is off)
            import asyncio
            factory = app_with_db._test_db_factory  # type: ignore[attr-defined]

            async def _create_job():
                from auth.services.users import get_user_by_email
                from workspace.repositories.uploads import create_upload
                from workspace.models import AnalysisJob
                async with factory() as session:
                    user_a = await get_user_by_email(session, "joba@example.com")
                    upload = await create_upload(
                        db=session, user_id=user_a.id,
                        filename="t.csv", raw_bytes=_sample_csv_bytes(),
                    )
                    job = AnalysisJob(
                        id=uuid.uuid4(), user_id=user_a.id, upload_id=upload.id,
                        llm_provider="none", status="pending",
                    )
                    session.add(job)
                    await session.commit()
                    return str(job.id)

            job_id = asyncio.run(_create_job())

            # User B tries to fetch → 404
            r = client.get(
                f"/api/v1/analyses/jobs/{job_id}",
                headers={"Authorization": f"Bearer {token_b}"},
            )
            assert r.status_code == 404

            # User A can fetch
            r = client.get(
                f"/api/v1/analyses/jobs/{job_id}",
                headers={"Authorization": f"Bearer {token_a}"},
            )
            assert r.status_code == 200
            assert r.json()["status"] == "pending"


# ---------------------------------------------------------------------------
# Engine immutability check
# ---------------------------------------------------------------------------

class TestEngineImmutability:
    def test_workers_layer_does_not_import_engines(self):
        """The workers/ layer must NOT import any frozen V23 engine module."""
        import inspect
        from workers import celery_app
        from workers.tasks import analysis_tasks, email_tasks, cleanup_tasks

        modules_to_check = [celery_app, analysis_tasks, email_tasks, cleanup_tasks]
        for mod in modules_to_check:
            src = inspect.getsource(mod)
            assert "from engines" not in src, \
                f"{mod.__name__} must not import from engines/"
            assert "import engines" not in src, \
                f"{mod.__name__} must not import engines/"

    def test_workers_call_engine_only_via_repository(self):
        """The ONLY engine call must still be in workspace.repositories.analyses.

        Workers call run_and_persist_analysis (the repository function),
        NOT the engine directly. This preserves the engine contract.
        """
        import inspect
        from workers.tasks import analysis_tasks
        src = inspect.getsource(analysis_tasks)

        # The task imports run_and_persist_analysis from the repository.
        assert "run_and_persist_analysis" in src, \
            "analysis_tasks must use run_and_persist_analysis from the repository"
        # It must NOT import analyze_dataframe directly.
        call_lines = [
            line for line in src.split("\n")
            if "analyze_dataframe(" in line
            and not line.strip().startswith("#")
        ]
        assert len(call_lines) == 0, \
            "workers.tasks.analysis_tasks must NOT call analyze_dataframe directly"


# ---------------------------------------------------------------------------
# CI/CD + backup script existence
# ---------------------------------------------------------------------------

class TestCICDAssets:
    def test_github_actions_workflow_exists(self):
        workflow_path = Path(__file__).resolve().parent.parent.parent / ".github" / "workflows" / "ci.yml"
        assert workflow_path.exists(), "GitHub Actions workflow must exist"

    def test_backup_script_exists_and_is_executable(self):
        script_path = Path(__file__).resolve().parent.parent.parent / "scripts" / "backup.sh"
        assert script_path.exists(), "backup.sh must exist"
        assert os.access(script_path, os.X_OK), "backup.sh must be executable"

    def test_deployment_docs_exist(self):
        docs_path = Path(__file__).resolve().parent.parent.parent / "docs" / "backend" / "PHASE11_DEPLOYMENT.md"
        assert docs_path.exists(), "Phase 11 deployment docs must exist"

    def test_docker_compose_prod_includes_worker_and_beat(self):
        compose_path = Path(__file__).resolve().parent.parent.parent / "docker" / "docker-compose.prod.yml"
        content = compose_path.read_text()
        assert "worker:" in content, "docker-compose.prod.yml must include worker service"
        assert "beat:" in content, "docker-compose.prod.yml must include beat service"
        assert "TRADING_DOCTOR_USE_CELERY" in content, "worker must enable Celery"
