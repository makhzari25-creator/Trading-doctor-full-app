# -*- coding: utf-8 -*-
"""
reporting/pdf_report.py
---------------------------
رندرر PDF: از دقیقاً همان context مشترک (reporting/data_context.py) و
همان بایت‌های PNG نمودار (reporting/charts.py) که رندرر HTML استفاده
می‌کند، تغذیه می‌شود — پس محتوای HTML و PDF هرگز نمی‌توانند از هم
متفاوت باشند، حتی با اینکه لایه‌ی چیدمان (layout) کاملاً مستقل است.

چرا reportlab و نه تبدیل HTML→PDF؟
  reportlab یک کتابخانه‌ی خالص پایتون (pip-installable) است و به هیچ
  باینری سیستمی (مثل wkhtmltopdf) نیاز ندارد؛ در هر محیطی که
  `pip install -r requirements.txt` کار کند، تولید PDF هم کار می‌کند —
  ریسک شکست در production را حذف می‌کند.

[AUDIT FIX — self-review، یافته‌ی حیاتی] نسخه‌ی اول این فایل از فونت
پیش‌فرض reportlab (Helvetica) استفاده می‌کرد. Helvetica هیچ گلیف فارسی/
عربی ندارد و reportlab به‌صورت خودکار نه shaping حروف فارسی (اشکال
initial/medial/final) و نه bidi (راست‌به‌چپ) انجام نمی‌دهد. نتیجه: تمام
متن فارسی PDF به‌صورت مربع‌های خالی (tofu) درمی‌آمد — یک باگ اساسی که با
استخراج متن واقعی از PDF تولیدشده کشف و تأیید شد. اصلاح:
  1) فونت یونیکد Vazirmatn (Regular+Bold) در reportlab.pdfbase ثبت شد.
  2) هر رشته‌ی متنی قبل از ورود به Paragraph از arabic_reshaper (اشکال
     صحیح حروف) و python-bidi (ترتیب بصری راست‌به‌چپ) عبور می‌کند.
  3) هر کاراکتری (شامل ایموجی) که در cmap فونت ثبت‌شده وجود نداشته باشد
     پیش از reshape/bidi حذف می‌شود — این یک فیلتر عمومی و آینده‌نگر
     است، نه فقط یک لیست ایموجی هاردکدشده؛ هر محتوای پویای آینده (از
     موتور تحلیلی) که شامل کاراکتر پشتیبانی‌نشده باشد هم ایمن می‌ماند.

این ماژول هیچ محاسبه‌ی تحلیلی انجام نمی‌دهد؛ فقط همان داده‌ی از قبل
آماده‌شده را در قالب PDF چیدمان می‌کند.
"""

import io
import os
import re
from typing import Any, Dict, Optional

import arabic_reshaper
from bidi.algorithm import get_display

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    HRFlowable, Image, PageBreak, Paragraph, SimpleDocTemplate,
    Spacer, Table, TableStyle,
)

from engines.report_engine import FullResult
from reporting.charts import build_all_charts
from reporting.data_context import build_report_context
from reporting.html_report import ReportRenderError
from utils.logger import get_logger

log = get_logger(__name__)

_ACCENT = colors.HexColor("#3B6FD4")
_POSITIVE = colors.HexColor("#00A67D")
_NEGATIVE = colors.HexColor("#E5484D")
_TEXT_MUTED = colors.HexColor("#5B6472")
_CARD_BG = colors.HexColor("#F7F9FC")
_BORDER = colors.HexColor("#E2E6ED")

_FONTS_DIR = os.path.join(os.path.dirname(__file__), "fonts")
_FONT_NORMAL = "Vazirmatn"
_FONT_BOLD = "Vazirmatn-Bold"

_FONT_REGISTERED = False
_FONT_CMAP = set()


def _ensure_font_registered():
    """[AUDIT FIX] یک‌بار در طول عمر پردازش، فونت Vazirmatn را در
    reportlab ثبت می‌کند و مجموعه‌ی کدپوینت‌های پشتیبانی‌شده را برای
    فیلتر ایمن کاراکترها کش می‌کند."""
    global _FONT_REGISTERED, _FONT_CMAP
    if _FONT_REGISTERED:
        return
    pdfmetrics.registerFont(TTFont(_FONT_NORMAL, os.path.join(_FONTS_DIR, "Vazirmatn-Regular.ttf")))
    pdfmetrics.registerFont(TTFont(_FONT_BOLD, os.path.join(_FONTS_DIR, "Vazirmatn-Bold.ttf")))
    try:
        from fontTools.ttLib import TTFont as FTFont
        ft = FTFont(os.path.join(_FONTS_DIR, "Vazirmatn-Regular.ttf"))
        _FONT_CMAP = set(ft.getBestCmap().keys())
    except Exception:
        # اگر fontTools در دسترس نبود، فیلتر غیرفعال می‌شود (فقط ریسک
        # ظاهری چند کاراکتر خاص، نه یک شکست عملکردی) — گزارش همچنان
        # با متن فارسی صحیح تولید می‌شود.
        log.warning("fontTools unavailable; unsupported-glyph filtering disabled", exc_info=True)
        _FONT_CMAP = None
    _FONT_REGISTERED = True


# محدوده‌های Unicode که معمولاً به‌صورت جفت surrogate/emoji ظاهر می‌شوند
# و تقریباً هیچ‌وقت در فونت‌های متن استاندارد نیستند — برای سرعت به‌جای
# بررسی تک‌تک کاراکتر با cmap در حلقه‌های داغ، ابتدا این‌ها را regex حذف
# می‌کنیم؛ فیلتر cmap در ادامه هرچیز باقی‌مانده‌ی پشتیبانی‌نشده را هم می‌گیرد.
_EMOJI_RE = re.compile(
    "[" 
    "\U0001F300-\U0001FAFF"
    "\U00002600-\U000027BF"
    "\U0001F1E6-\U0001F1FF"
    "\U00002190-\U000021FF"
    "\U00002B00-\U00002BFF"
    "\uFE0F"
    "]+", flags=re.UNICODE,
)


def _rtl(text: Any) -> str:
    """
    آماده‌سازی متن فارسی/مختلط برای reportlab:
      ۱) حذف کاراکترهای پشتیبانی‌نشده توسط فونت (ایموجی و غیره)
      ۲) reshape حروف عربی/فارسی (اشکال initial/medial/final صحیح)
      ۳) بازچینش بصری راست‌به‌چپ (bidi)
    فقط باید روی قطعه‌های متن ساده (بدون تگ HTML-like reportlab مثل
    <b>) اعمال شود — نه روی کل رشته‌ی حاوی تگ، وگرنه bidi ترتیب تگ‌ها را
    هم به‌هم می‌ریزد و Paragraph قابل‌پارس نخواهد بود.
    """
    _ensure_font_registered()
    text = "" if text is None else str(text)
    text = _EMOJI_RE.sub("", text)
    if _FONT_CMAP is not None:
        text = "".join(ch for ch in text if ord(ch) in _FONT_CMAP or ch in ("\n", "\t"))
    try:
        reshaped = arabic_reshaper.reshape(text)
        return get_display(reshaped)
    except Exception:
        log.warning("RTL reshape/bidi failed for a text fragment; using raw text", exc_info=True)
        return text


def _b(text: Any) -> str:
    """کمکی: نسخه‌ی bold-wrapped یک قطعه‌ی متن *پس از* rtl-safe شدن."""
    return f"<b>{_rtl(text)}</b>"


def _styles():
    _ensure_font_registered()
    styles = getSampleStyleSheet()
    for name in list(styles.byName.keys()):
        styles[name].fontName = _FONT_NORMAL
    styles.add(ParagraphStyle(
        name="ReportTitle", fontSize=20, leading=26, alignment=TA_CENTER,
        textColor=colors.HexColor("#1E2430"), spaceAfter=4, fontName=_FONT_BOLD,
    ))
    styles.add(ParagraphStyle(
        name="ReportMeta", fontSize=9, leading=14, alignment=TA_CENTER,
        textColor=_TEXT_MUTED, spaceAfter=18, fontName=_FONT_NORMAL,
    ))
    styles.add(ParagraphStyle(
        name="SectionHeading", fontSize=14, leading=20, spaceBefore=16, spaceAfter=6,
        textColor=_ACCENT, fontName=_FONT_BOLD,
    ))
    styles.add(ParagraphStyle(
        name="SubHeading", fontSize=11, leading=16, spaceBefore=8, spaceAfter=4,
        textColor=_TEXT_MUTED, fontName=_FONT_BOLD,
    ))
    styles.add(ParagraphStyle(
        name="BodyMuted", fontSize=9, leading=15, textColor=_TEXT_MUTED, fontName=_FONT_NORMAL,
    ))
    styles.add(ParagraphStyle(
        name="BodyText2", fontSize=10, leading=17, textColor=colors.HexColor("#1E2430"), fontName=_FONT_NORMAL,
    ))
    styles.add(ParagraphStyle(
        name="MetricValue", fontSize=16, leading=20, alignment=TA_CENTER,
        fontName=_FONT_BOLD, textColor=colors.HexColor("#1E2430"),
    ))
    styles.add(ParagraphStyle(
        name="MetricLabel", fontSize=8, leading=13, alignment=TA_CENTER, textColor=_TEXT_MUTED, fontName=_FONT_NORMAL,
    ))
    styles.add(ParagraphStyle(
        name="ScoreHero", fontSize=44, leading=50, alignment=TA_CENTER, fontName=_FONT_BOLD,
    ))
    return styles


def _section_heading(text: str, styles) -> list:
    """
    [AUDIT FIX] قبلاً یک کاراکتر "■" برای نشانگر رنگی استفاده می‌شد که در
    فونت Vazirmatn موجود نیست (و ایموجی‌های ابتدای عنوان‌ها هم همین‌طور).
    حالا از یک خط رنگی برداری (HRFlowable — گرافیک، نه گلیف فونت) استفاده
    می‌شود که مستقل از پوشش فونت است، دقیقاً هم‌سو با استایل زیرخط رنگی
    عنوان‌ها در نسخه‌ی HTML (border-bottom آبی).
    """
    return [
        Paragraph(_rtl(text), styles["SectionHeading"]),
        HRFlowable(width="100%", thickness=1.4, color=_ACCENT, spaceAfter=10),
    ]


def _metric_table(items, styles, col_widths=None):
    """items: list of (value_str, label_str, color_or_None)"""
    cells = []
    for value, label, color in items:
        val_style = ParagraphStyle("mv", parent=styles["MetricValue"], textColor=color or colors.HexColor("#1E2430"))
        cells.append([Paragraph(_rtl(value), val_style), Paragraph(_rtl(label), styles["MetricLabel"])])
    row = [c[0] for c in cells]
    row2 = [c[1] for c in cells]
    n = len(items)
    widths = col_widths or [(17 * cm) / n] * n
    t = Table([row, row2], colWidths=widths)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), _CARD_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, _BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, _BORDER),
        ("TOPPADDING", (0, 0), (-1, 0), 10),
        ("BOTTOMPADDING", (0, 1), (-1, 1), 10),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _data_table(rows, styles, header=None, col_widths=None):
    data = []
    if header:
        data.append([Paragraph(_b(h), styles["BodyMuted"]) for h in header])
    for row in rows:
        data.append([Paragraph(_rtl(cell), styles["BodyText2"]) for cell in row])
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    style_cmds = [
        ("GRID", (0, 0), (-1, -1), 0.4, _BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        style_cmds.append(("BACKGROUND", (0, 0), (-1, 0), _CARD_BG))
    t.setStyle(TableStyle(style_cmds))
    return t


def _chart_image(png_bytes: bytes, max_width: float = 16 * cm) -> Image:
    img = Image(io.BytesIO(png_bytes))
    ratio = img.imageHeight / float(img.imageWidth)
    img.drawWidth = max_width
    img.drawHeight = max_width * ratio
    return img


def render_pdf_report(
    result: FullResult,
    coach: Dict[str, Any],
    doctor: Optional[Any] = None,
    report_title: str = "Trading Doctor — Behavioral Trading Report",
) -> bytes:
    """
    نقطه‌ی ورود عمومی PDF. برمی‌گرداند: bytes یک فایل PDF کامل.

    raises ReportRenderError: با پیام واضح، مشابه render_html_report.
    """
    try:
        ctx = build_report_context(result, coach, doctor, report_title=report_title)
    except Exception as e:
        log.error("Failed to build report context for PDF", exc_info=True)
        raise ReportRenderError(f"ساخت داده‌ی گزارش با خطا مواجه شد: {e}") from e

    df = getattr(doctor, "df", None) if doctor is not None else None
    try:
        charts_png = build_all_charts(df, ctx["behavior_analysis"]["scores"], ctx["trader_profile"])
    except Exception as e:
        log.error("Failed to generate charts for PDF", exc_info=True)
        raise ReportRenderError(f"تولید نمودارهای گزارش با خطا مواجه شد: {e}") from e

    try:
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf, pagesize=A4,
            topMargin=1.6 * cm, bottomMargin=1.6 * cm,
            leftMargin=1.6 * cm, rightMargin=1.6 * cm,
            title=ctx["meta"]["report_title"],
        )
        styles = _styles()
        story = []

        # --- Header ---
        story.append(Paragraph(_rtl(ctx["meta"]["report_title"]), styles["ReportTitle"]))
        story.append(Paragraph(
            f'{_rtl("تولید شده در:")} {ctx["meta"]["generated_at"]} &nbsp;&middot;&nbsp; '
            f'{_rtl("تعداد معاملات:")} {ctx["meta"]["total_trades"]} &nbsp;&middot;&nbsp; '
            f'{_rtl(ctx["meta"]["engine_version"])}',
            styles["ReportMeta"],
        ))

        # --- 1. Executive Summary ---
        story.extend(_section_heading("خلاصه اجرایی (Executive Summary)", styles))
        story.append(Paragraph(_rtl(ctx["executive_summary"]["summary_text"]), styles["BodyText2"]))
        story.append(Spacer(1, 8))
        story.append(_metric_table([
            (f'{ctx["executive_summary"]["overall_score"]}/100', "امتیاز کلی معاملاتی", _ACCENT),
            (ctx["executive_summary"]["archetype"], "نوع معامله‌گر", None),
            (ctx["executive_summary"]["primary_diagnosis"], "تشخیص اصلی", _NEGATIVE),
        ], styles))

        # --- 2. Overall Score ---
        story.extend(_section_heading("امتیاز کلی معاملاتی (Overall Trading Score)", styles))
        score_val = ctx["overall_score"]["value"]
        score_color = _POSITIVE if score_val >= 65 else (colors.HexColor("#B98900") if score_val >= 35 else _NEGATIVE)
        hero_style = ParagraphStyle("hero", parent=styles["ScoreHero"], textColor=score_color)
        story.append(Paragraph(f"{score_val}/100", hero_style))
        story.append(Paragraph(_rtl(ctx["overall_score"]["label"]), styles["ReportMeta"]))

        # --- 3. Diagnosis ---
        story.extend(_section_heading("تشخیص (Diagnosis)", styles))
        diag = ctx["diagnosis"]
        story.append(Paragraph(f'{_b("تشخیص اصلی:")} {_rtl(diag.get("primary", "N/A"))}', styles["BodyText2"]))
        if diag.get("primary_detail"):
            story.append(Paragraph(_rtl(diag["primary_detail"]), styles["BodyMuted"]))
        if diag.get("secondary"):
            story.append(Spacer(1, 4))
            story.append(Paragraph(f'{_b("تشخیص ثانویه:")} {_rtl(diag.get("secondary"))}', styles["BodyText2"]))
            if diag.get("secondary_detail"):
                story.append(Paragraph(_rtl(diag["secondary_detail"]), styles["BodyMuted"]))
        story.append(Paragraph(f'{_rtl("سطح اطمینان:")} {_b(diag.get("confidence_level", "N/A"))}', styles["BodyMuted"]))

        # --- 4. Trader Profile ---
        story.extend(_section_heading("پروفایل معامله‌گر (Trader Profile)", styles))
        story.append(Paragraph(_b(ctx["trader_profile"].get("archetype", "N/A")), styles["BodyText2"]))
        story.append(Spacer(1, 6))
        traits = [(v, k.replace("_", " ").title(), None) for k, v in ctx["trader_profile"].items() if k != "archetype"]
        if traits:
            story.append(_metric_table(traits[:3], styles))
            if len(traits) > 3:
                story.append(Spacer(1, 4))
                story.append(_metric_table(traits[3:6], styles))

        # --- 5. Strengths / Weaknesses ---
        story.extend(_section_heading("نقاط قوت و ضعف (Strengths & Weaknesses)", styles))
        story.append(Paragraph(_b("نقاط قوت"), styles["SubHeading"]))
        for s in ctx["strengths"]:
            story.append(Paragraph(f"{_rtl('•')} {_rtl(s)}", styles["BodyText2"]))
        story.append(Paragraph(_b("نقاط ضعف"), styles["SubHeading"]))
        for w in ctx["weaknesses"]:
            story.append(Paragraph(f"{_rtl('•')} {_rtl(w)}", styles["BodyText2"]))

        story.append(PageBreak())

        # --- 6. Behavior Analysis ---
        story.extend(_section_heading("تحلیل رفتاری (Behavior Analysis)", styles))
        rows = [
            (r["label"], r["score"], r["severity"], r["event_count"], r["dollars_lost_fmt"])
            for r in ctx["behavior_analysis"]["context_rows"]
        ]
        story.append(_data_table(
            rows, styles,
            header=["رفتار", "امتیاز", "شدت", "رخداد", "اثر مالی"],
            col_widths=[5 * cm, 2.2 * cm, 2.5 * cm, 2.3 * cm, 3 * cm],
        ))
        what_if = ctx["behavior_analysis"]["what_if"].get("if_revenge_fixed", {})
        if what_if:
            story.append(Spacer(1, 8))
            story.append(Paragraph(_b("شبیه‌سازی What-If (اگر Revenge اصلاح می‌شد)"), styles["SubHeading"]))
            story.append(_metric_table([
                (what_if.get("discipline_improvement", "N/A"), "بهبود انضباط", None),
                (what_if.get("expected_profit_increase", "N/A"), "تغییر سود مورد انتظار", None),
                (what_if.get("revenge_trades_adjusted", 0), "معاملات اصلاح‌شده", None),
            ], styles))

        # --- 7. Psychology ---
        story.extend(_section_heading("یافته‌های روان‌شناختی (Psychological Findings)", styles))
        story.append(Paragraph(_rtl(ctx["psychology"]["narrative"]), styles["BodyText2"]))
        story.append(Spacer(1, 6))
        story.append(_chart_image(charts_png["trader_dna_radar"], max_width=10 * cm))

        story.append(PageBreak())

        # --- 8. Evidence ---
        story.extend(_section_heading("شواهد کلیدی (Key Evidence)", styles))
        ev_rows = [
            (e["label"], e["priority_score"], e["frequency"], e["financial_impact_fmt"])
            for e in ctx["evidence"]
        ] or [("شاهد رفتاری قابل‌توجهی شناسایی نشد.", "", "", "")]
        story.append(_data_table(
            ev_rows, styles, header=["نوع", "اولویت", "تعداد", "اثر مالی"],
            col_widths=[6 * cm, 3 * cm, 3 * cm, 3 * cm],
        ))

        # --- 9. Trade Statistics ---
        story.extend(_section_heading("آمار معاملات (Trade Statistics)", styles))
        stats = ctx["statistics"]
        story.append(_metric_table([
            (stats["total_trades"], "تعداد کل معاملات", None),
            (f'{stats["win_rate_pct"]}%', "Win Rate", None),
            (stats["max_win_streak"], "رشته‌ی برد", _POSITIVE),
            (stats["max_loss_streak"], "رشته‌ی باخت", _NEGATIVE),
        ], styles))

        # --- 10. Performance Metrics ---
        story.extend(_section_heading("معیارهای عملکرد (Performance Metrics)", styles))
        perf = ctx["performance"]
        story.append(_metric_table([
            (perf["net_profit_fmt"], "سود خالص", _POSITIVE if perf["net_profit"] >= 0 else _NEGATIVE),
            (perf["profit_factor"], "Profit Factor", None),
            (perf["avg_win_fmt"], "میانگین برد", _POSITIVE),
            (perf["avg_loss_fmt"], "میانگین باخت", _NEGATIVE),
        ], styles))

        # --- 11. Risk Metrics ---
        story.extend(_section_heading("معیارهای ریسک (Risk Metrics)", styles))
        risk = ctx["risk"]
        story.append(_metric_table([
            (risk["max_drawdown_fmt"], "بیشترین Drawdown", _NEGATIVE),
            (f'{risk["risk_taking_score"]}/100', "ریسک‌پذیری حجم", None),
            (f'{risk["revenge_score"]}/100', "Revenge Trading", None),
        ], styles))

        story.append(PageBreak())

        # --- 12. Charts ---
        story.extend(_section_heading("نمودارها (Charts)", styles))
        story.append(Paragraph(_rtl("Equity Curve"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["equity_curve"]))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_rtl("Drawdown"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["drawdown"]))
        story.append(PageBreak())
        story.append(Paragraph(_rtl("Win/Loss Analysis"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["win_loss_pie"], max_width=9 * cm))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_rtl("Distribution Chart"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["pnl_distribution"]))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_rtl("سود/زیان بر اساس ساعت"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["hourly_pnl"]))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_rtl("سود/زیان بر اساس روز هفته"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["weekday_pnl"]))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_rtl("امتیازهای رفتاری"), styles["SubHeading"]))
        story.append(_chart_image(charts_png["behavior_scores"], max_width=13 * cm))

        story.append(PageBreak())

        # --- 13. Recommendations ---
        story.extend(_section_heading("پیشنهادها (Recommendations)", styles))
        rec_rows = [(item["priority"], item["issue"].replace("_", " ").title(), item["action"])
                    for item in ctx["recommendations"]] or [("", "—", "پیشنهاد خاصی ثبت نشده است.")]
        story.append(_data_table(
            rec_rows, styles, header=["اولویت", "موضوع", "اقدام پیشنهادی"],
            col_widths=[2 * cm, 4 * cm, 11 * cm],
        ))

        # --- 14. AI Coaching Summary ---
        story.extend(_section_heading("خلاصه‌ی Coaching هوش مصنوعی (AI Coaching)", styles))
        ai_text = ctx["ai_coaching"]["explainable_ai"].replace("\n", "<br/>")
        story.append(Paragraph(_rtl(ai_text), styles["BodyText2"]))
        if ctx["ai_coaching"]["reality_check"]:
            story.append(Spacer(1, 6))
            story.append(Paragraph(_rtl(ctx["ai_coaching"]["reality_check"]), styles["BodyMuted"]))

        story.append(PageBreak())

        # --- 15. Technical Appendix ---
        story.extend(_section_heading("پیوست فنی (Technical Appendix)", styles))
        if ctx["appendix"]["data_quality_warnings"]:
            story.append(Paragraph(_b("هشدارهای کیفیت داده"), styles["SubHeading"]))
            for w in ctx["appendix"]["data_quality_warnings"]:
                story.append(Paragraph(_rtl(w), styles["BodyMuted"]))
        story.append(Paragraph(_b("Performance (خام)"), styles["SubHeading"]))
        story.append(_data_table(
            [(k, v) for k, v in ctx["appendix"]["performance_raw"].items()], styles,
            col_widths=[6 * cm, 11 * cm],
        ))
        story.append(Spacer(1, 8))
        story.append(Paragraph(_b("Edge Map (خام)"), styles["SubHeading"]))
        edge_rows = [(k, str(v)) for k, v in ctx["appendix"]["edge_map_raw"].items()] or [("—", "داده‌ی کافی موجود نبود.")]
        story.append(_data_table(edge_rows, styles, col_widths=[6 * cm, 11 * cm]))
        story.append(Spacer(1, 10))
        story.append(Paragraph(
            _rtl(
                "توجه: این پیوست خلاصه‌ی آماری کامل است، نه فهرست معامله‌به‌معامله — "
                "برای جلوگیری از حجیم‌شدن غیرضروری گزارش در تاریخچه‌های بزرگ."
            ),
            styles["BodyMuted"],
        ))

        doc.build(story)
        pdf_bytes = buf.getvalue()
    except ReportRenderError:
        raise
    except Exception as e:
        log.error("PDF layout/build failed", exc_info=True)
        raise ReportRenderError(f"ساخت فایل PDF با خطا مواجه شد: {e}") from e

    log.info("PDF report rendered successfully (%d bytes)", len(pdf_bytes))
    return pdf_bytes
