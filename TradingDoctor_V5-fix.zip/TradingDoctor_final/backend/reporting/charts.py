# -*- coding: utf-8 -*-
"""
reporting/charts.py
----------------------
تولید نمودارهای استاتیک (PNG) با matplotlib — به‌اشتراک‌گذاشته‌شده بین
رندرر HTML (به‌صورت base64 داخل <img>) و رندرر PDF (به‌صورت reportlab
Image flowable). هر دو از دقیقاً همان بایت‌های PNG استفاده می‌کنند، پس
نمودارهای HTML و PDF هرگز نمی‌توانند از هم متفاوت باشند.

اصل طراحی حیاتی: تمام تبدیل‌های اینجا (cumsum برای Equity Curve،
cummax-cumsum برای Drawdown، groupby برای توزیع ساعتی/روزانه) دقیقاً
همان فرمول‌های presentational هستند که از قبل در pages/02_Charts.py
استفاده می‌شوند — هیچ محاسبه‌ی تحلیلی جدیدی معرفی نمی‌شود، فقط همان
اعداد به‌صورت تصویر استاتیک (برای گزارش قابل‌دانلود/چاپ) بازتولید
می‌شوند.

matplotlib با backend "Agg" (headless، بدون نیاز به display) استفاده
می‌شود تا در سرور Streamlit/CLI بدون کرش کار کند.
"""

import io
import threading
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")  # noqa: E402  — باید قبل از import pyplot باشد

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from utils.logger import get_logger

log = get_logger(__name__)

# [AUDIT FIX — Phase 2 self-review] matplotlib.pyplot از یک state machine
# سراسری (global figure registry) استفاده می‌کند که به‌صورت رسمی
# thread-safe نیست. در یک سرور Streamlit، چند session کاربر می‌توانند در
# thread های جداگانه‌ی همان پردازش اجرا شوند؛ اگر دو کاربر هم‌زمان گزارش
# بگیرند، تولید نمودار می‌تواند به‌طور نظری تداخل کند. تست تنیدگی دستی
# (۸ ترد هم‌زمان × ۵ دور) هیچ خطایی نشان نداد (به احتمال زیاد به لطف
# GIL در CPython)، اما تکیه بر این رفتار ضمنی برای production نادرست
# است. این قفل ساده و ارزان، امکان هرگونه race را کاملاً حذف می‌کند.
_MPL_LOCK = threading.Lock()

# پالت رنگ ثابت — برای هماهنگی بصری بین همه‌ی نمودارهای گزارش
_COLOR_POS = "#00A67D"
_COLOR_NEG = "#E5484D"
_COLOR_NEUTRAL = "#3B6FD4"
_COLOR_GRID = "#D8DEE9"
_FIG_DPI = 140

plt.rcParams.update({
    "font.size": 10,
    "axes.edgecolor": "#8B96A5",
    "axes.labelcolor": "#2E3440",
    "text.color": "#2E3440",
    "xtick.color": "#4C566A",
    "ytick.color": "#4C566A",
    "axes.grid": True,
    "grid.color": _COLOR_GRID,
    "grid.linewidth": 0.6,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})


def _fig_to_png_bytes(fig) -> bytes:
    buf = io.BytesIO()
    try:
        fig.savefig(buf, format="png", dpi=_FIG_DPI, bbox_inches="tight")
    finally:
        plt.close(fig)
    return buf.getvalue()


def _empty_chart(message: str) -> bytes:
    """وقتی داده‌ی کافی برای رسم نمودار نیست، به‌جای کرش یا نمودار خالی
    گیج‌کننده، یک تصویر واضح با پیام توضیحی تولید می‌شود."""
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.text(0.5, 0.5, message, ha="center", va="center", fontsize=11, color="#4C566A", wrap=True)
    ax.axis("off")
    return _fig_to_png_bytes(fig)


def equity_curve_chart(df: pd.DataFrame) -> bytes:
    """همان فرمول pages/02_Charts.py: Equity = cumsum(Profit)."""
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return _empty_chart("داده‌ی کافی برای Equity Curve موجود نیست.")
    equity = df["Profit"].cumsum()
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.plot(range(len(equity)), equity.values, color=_COLOR_NEUTRAL, linewidth=1.6)
    ax.fill_between(range(len(equity)), equity.values, 0, alpha=0.08, color=_COLOR_NEUTRAL)
    ax.axhline(0, color="#8B96A5", linewidth=0.8)
    ax.set_title("Equity Curve", fontsize=12, fontweight="bold")
    ax.set_xlabel("شماره معامله")
    ax.set_ylabel("سود تجمعی ($)")
    return _fig_to_png_bytes(fig)


def drawdown_chart(df: pd.DataFrame) -> bytes:
    """همان فرمول pages/02_Charts.py: Drawdown = Equity - cummax(Equity)."""
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return _empty_chart("داده‌ی کافی برای Drawdown موجود نیست.")
    equity = df["Profit"].cumsum()
    drawdown = equity - equity.cummax()
    fig, ax = plt.subplots(figsize=(9, 3))
    ax.fill_between(range(len(drawdown)), drawdown.values, 0, color=_COLOR_NEG, alpha=0.35)
    ax.plot(range(len(drawdown)), drawdown.values, color=_COLOR_NEG, linewidth=1.2)
    ax.set_title("Drawdown", fontsize=12, fontweight="bold")
    ax.set_xlabel("شماره معامله")
    ax.set_ylabel("افت سرمایه ($)")
    return _fig_to_png_bytes(fig)


def win_loss_pie_chart(df: pd.DataFrame) -> bytes:
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return _empty_chart("داده‌ی کافی برای توزیع برد/باخت موجود نیست.")
    wins = int((df["Profit"] > 0).sum())
    losses = int((df["Profit"] < 0).sum())
    breakeven = int((df["Profit"] == 0).sum())
    values = [v for v in (wins, losses, breakeven) if v > 0]
    labels = [l for l, v in zip(("برد", "باخت", "سربه‌سر"), (wins, losses, breakeven)) if v > 0]
    colors = [c for c, v in zip((_COLOR_POS, _COLOR_NEG, "#8B96A5"), (wins, losses, breakeven)) if v > 0]
    if not values:
        return _empty_chart("داده‌ی کافی برای توزیع برد/باخت موجود نیست.")
    fig, ax = plt.subplots(figsize=(4.5, 4.5))
    ax.pie(values, labels=labels, colors=colors, autopct="%1.1f%%", startangle=90,
           textprops={"fontsize": 10})
    ax.set_title("توزیع برد و باخت", fontsize=12, fontweight="bold")
    return _fig_to_png_bytes(fig)


def pnl_distribution_histogram(df: pd.DataFrame) -> bytes:
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return _empty_chart("داده‌ی کافی برای توزیع سود/زیان موجود نیست.")
    profit = df["Profit"].values
    fig, ax = plt.subplots(figsize=(9, 3.5))
    n_bins = min(40, max(10, len(profit) // 5))
    colors_per_bin = _COLOR_NEUTRAL
    counts, bins, patches = ax.hist(profit, bins=n_bins, color=colors_per_bin, alpha=0.85, edgecolor="white")
    for patch, left_edge in zip(patches, bins[:-1]):
        patch.set_facecolor(_COLOR_NEG if left_edge < 0 else _COLOR_POS)
    ax.axvline(0, color="#2E3440", linewidth=1)
    ax.set_title("توزیع سود/زیان هر معامله", fontsize=12, fontweight="bold")
    ax.set_xlabel("سود/زیان ($)")
    ax.set_ylabel("تعداد معاملات")
    return _fig_to_png_bytes(fig)


def hourly_pnl_bar_chart(df: pd.DataFrame) -> bytes:
    if df is None or len(df) == 0 or "hour" not in df.columns or df["Open Time"].isna().all():
        return _empty_chart("داده‌ی زمانی برای تحلیل ساعتی موجود نیست.")
    hourly = df.groupby("hour")["Profit"].sum()
    hourly = hourly.reindex(range(24), fill_value=0)
    fig, ax = plt.subplots(figsize=(9, 3.2))
    colors = [_COLOR_POS if v >= 0 else _COLOR_NEG for v in hourly.values]
    ax.bar(hourly.index, hourly.values, color=colors)
    ax.set_title("سود/زیان بر اساس ساعت روز", fontsize=12, fontweight="bold")
    ax.set_xlabel("ساعت")
    ax.set_ylabel("سود/زیان کل ($)")
    ax.set_xticks(range(0, 24, 2))
    return _fig_to_png_bytes(fig)


def weekday_pnl_bar_chart(df: pd.DataFrame) -> bytes:
    if df is None or len(df) == 0 or "Open Time" not in df.columns or df["Open Time"].isna().all():
        return _empty_chart("داده‌ی زمانی برای تحلیل روز هفته موجود نیست.")
    weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    weekday = pd.to_datetime(df["Open Time"], errors="coerce").dt.day_name()
    grouped = df.assign(_weekday=weekday).groupby("_weekday")["Profit"].sum()
    grouped = grouped.reindex(weekday_order, fill_value=0)
    fig, ax = plt.subplots(figsize=(9, 3.2))
    colors = [_COLOR_POS if v >= 0 else _COLOR_NEG for v in grouped.values]
    ax.bar(range(len(grouped)), grouped.values, color=colors)
    ax.set_xticks(range(len(grouped)))
    ax.set_xticklabels(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
    ax.set_title("سود/زیان بر اساس روز هفته", fontsize=12, fontweight="bold")
    ax.set_ylabel("سود/زیان کل ($)")
    return _fig_to_png_bytes(fig)


def behavior_scores_bar_chart(scores: Dict[str, float]) -> bytes:
    """نوار افقی برای ۵ امتیاز رفتاری — جایگزین ساده و چاپ‌پذیر gauge."""
    if not scores:
        return _empty_chart("امتیاز رفتاری‌ای برای نمایش موجود نیست.")
    labels = [k.replace("_score", "").replace("_", " ").title() for k in scores.keys()]
    values = list(scores.values())
    colors = []
    for k, v in scores.items():
        # discipline_score: بالاتر بهتر است؛ بقیه: پایین‌تر بهتر است.
        good_high = k == "discipline_score"
        v_eff = v if good_high else (100 - v)
        colors.append(_COLOR_POS if v_eff >= 65 else ("#E5A82E" if v_eff >= 35 else _COLOR_NEG))
    fig, ax = plt.subplots(figsize=(8, 0.55 * len(values) + 1))
    y_pos = np.arange(len(values))
    ax.barh(y_pos, values, color=colors)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels)
    ax.set_xlim(0, 100)
    ax.invert_yaxis()
    ax.set_title("امتیازهای رفتاری", fontsize=12, fontweight="bold")
    for i, v in enumerate(values):
        ax.text(min(v + 2, 96), i, f"{v}", va="center", fontsize=9)
    return _fig_to_png_bytes(fig)


def trader_dna_radar_chart(dna: Dict[str, str]) -> bytes:
    """نمودار رادار برای پروفایل کیفی (Low/Medium/High/Weak/Strong) —
    فقط بازنمایی بصری همان برچسب‌های از قبل تولیدشده توسط PsychologyEngine."""
    traits = {k: v for k, v in (dna or {}).items() if k != "archetype"}
    if not traits:
        return _empty_chart("پروفایل رفتاری (Trader DNA) موجود نیست.")
    value_map = {"Low": 25, "Medium": 55, "High": 85, "Strong": 80, "Weak": 30, "Unknown": 50}
    labels = [k.replace("_", " ").title() for k in traits.keys()]
    values = [value_map.get(v, 50) for v in traits.values()]

    n = len(labels)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False).tolist()
    values_closed = values + values[:1]
    angles_closed = angles + angles[:1]

    fig, ax = plt.subplots(figsize=(5.5, 5.5), subplot_kw={"projection": "polar"})
    ax.plot(angles_closed, values_closed, color=_COLOR_NEUTRAL, linewidth=1.8)
    ax.fill(angles_closed, values_closed, color=_COLOR_NEUTRAL, alpha=0.2)
    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylim(0, 100)
    ax.set_yticks([25, 55, 85])
    ax.set_yticklabels(["Low", "Medium", "High"], fontsize=7)
    ax.set_title("Trader DNA", fontsize=12, fontweight="bold", pad=20)
    return _fig_to_png_bytes(fig)


def build_all_charts(df: Optional[pd.DataFrame], behavior_scores: Dict[str, float],
                      trader_dna: Dict[str, str]) -> Dict[str, bytes]:
    """یک‌جا همه‌ی نمودارهای گزارش را می‌سازد — استفاده‌شده توسط هر دو رندرر
    HTML و PDF، تا نمودارها هرگز بین دو خروجی متفاوت نباشند.

    این تابع تنها نقطه‌ی ورود عمومی است که html_report.py و pdf_report.py
    صدا می‌زنند، به همین دلیل قفل thread-safety اینجا اعمال می‌شود (نه
    داخل هر تابع نمودار جداگانه) — کل دسته‌ی تولید نمودار برای یک گزارش
    به‌صورت atomic نسبت به سایر session های هم‌زمان اجرا می‌شود."""
    with _MPL_LOCK:
        charts = {
            "equity_curve": equity_curve_chart(df),
            "drawdown": drawdown_chart(df),
            "win_loss_pie": win_loss_pie_chart(df),
            "pnl_distribution": pnl_distribution_histogram(df),
            "hourly_pnl": hourly_pnl_bar_chart(df),
            "weekday_pnl": weekday_pnl_bar_chart(df),
            "behavior_scores": behavior_scores_bar_chart(behavior_scores),
            "trader_dna_radar": trader_dna_radar_chart(trader_dna),
        }
    log.info("Generated %d report charts", len(charts))
    return charts
