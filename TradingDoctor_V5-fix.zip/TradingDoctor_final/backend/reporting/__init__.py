# -*- coding: utf-8 -*-
"""
reporting/__init__.py
------------------------
API عمومی ماژول گزارش‌گیری. تنها نقطه‌ی ورودی که بقیه‌ی پروژه (Streamlit
pages، main.py CLI) باید با آن کار کند:

    from reporting import generate_html_report, generate_pdf_report, ReportRenderError

هر دو تابع از یک context مشترک (data_context.py) و نمودارهای مشترک
(charts.py) استفاده می‌کنند — محتوای HTML و PDF هرگز نمی‌توانند از هم
متفاوت باشند. هیچ‌کدام محاسبه‌ی تحلیلی جدیدی انجام نمی‌دهند؛ فقط
خروجی‌های از قبل آماده‌ی موتور تحلیلی (Phase 1) را قالب‌بندی می‌کنند.
"""

from reporting.html_report import ReportRenderError, render_html_report as generate_html_report
from reporting.pdf_report import render_pdf_report as generate_pdf_report

__all__ = ["generate_html_report", "generate_pdf_report", "ReportRenderError"]
