# -*- coding: utf-8 -*-
"""
reporting/html_report.py
----------------------------
رندرر HTML: قالب‌های Jinja2 (templates/report.html + partials) را با
context مشترک (reporting/data_context.py) و نمودارهای مشترک
(reporting/charts.py) پر می‌کند و یک رشته‌ی HTML *کاملاً مستقل*
(CSS inline، تصاویر به‌صورت base64) برمی‌گرداند — بدون هیچ وابستگی به
فایل خارجی، تا فایل دانلودشده همیشه به‌تنهایی درست نمایش داده شود.

این ماژول هیچ محاسبه‌ی تحلیلی انجام نمی‌دهد؛ فقط داده‌ی از قبل آماده‌شده
را قالب‌بندی می‌کند.
"""

import base64
from typing import Any, Dict, Optional

import pandas as pd
from jinja2 import Environment, FileSystemLoader, StrictUndefined, TemplateError

import config
from engines.report_engine import FullResult
from reporting.charts import build_all_charts
from reporting.data_context import build_report_context
from utils.logger import get_logger

log = get_logger(__name__)


class ReportRenderError(Exception):
    """خطای واضح وقتی رندر گزارش (HTML یا PDF) با شکست مواجه شود."""


def _get_jinja_env() -> Environment:
    """
    [نکته‌ی طراحی] StrictUndefined عمداً استفاده می‌شود: اگر context یک
    کلید مورد انتظار توسط قالب را نداشته باشد، رندر با خطای واضح متوقف
    می‌شود به‌جای اینکه بی‌صدا یک بخش از گزارش را خالی/ناقص نشان دهد —
    دقیقاً همان فلسفه‌ی «هرگز مشکل را بی‌صدا قورت نده» که در Phase 1 برای
    اعتبارسنجی داده استفاده شد.
    """
    env = Environment(
        loader=FileSystemLoader(config.TEMPLATES_DIR),
        undefined=StrictUndefined,
        autoescape=True,
        trim_blocks=True,
        lstrip_blocks=True,
    )
    return env


def _charts_to_base64(charts_png: Dict[str, bytes]) -> Dict[str, str]:
    return {name: base64.b64encode(png).decode("ascii") for name, png in charts_png.items()}


def render_html_report(
    result: FullResult,
    coach: Dict[str, Any],
    doctor: Optional[Any] = None,
    report_title: str = "Trading Doctor — Behavioral Trading Report",
) -> str:
    """
    نقطه‌ی ورود عمومی HTML. برمی‌گرداند: رشته‌ی HTML کامل و مستقل.

    raises ReportRenderError: اگر تولید context، نمودارها، یا رندر قالب
    با خطا مواجه شود — با پیام واضح، بدون traceback خام به کاربر نهایی.
    """
    try:
        report_context = build_report_context(result, coach, doctor, report_title=report_title)
    except Exception as e:
        log.error("Failed to build report context", exc_info=True)
        raise ReportRenderError(f"ساخت داده‌ی گزارش با خطا مواجه شد: {e}") from e

    df = getattr(doctor, "df", None) if doctor is not None else None
    behavior_scores = report_context["behavior_analysis"]["scores"]
    trader_dna = report_context["trader_profile"]

    try:
        charts_png = build_all_charts(df, behavior_scores, trader_dna)
        report_context["charts"] = _charts_to_base64(charts_png)
    except Exception as e:
        log.error("Failed to generate report charts", exc_info=True)
        raise ReportRenderError(f"تولید نمودارهای گزارش با خطا مواجه شد: {e}") from e

    try:
        env = _get_jinja_env()
        template = env.get_template("report.html")
        html = template.render(ctx=report_context)
    except TemplateError as e:
        log.error("Template rendering failed", exc_info=True)
        raise ReportRenderError(f"رندر قالب HTML با خطا مواجه شد: {e}") from e

    log.info("HTML report rendered successfully (%d bytes)", len(html))
    return html
