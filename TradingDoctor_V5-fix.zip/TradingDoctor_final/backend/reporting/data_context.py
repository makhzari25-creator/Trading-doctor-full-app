# -*- coding: utf-8 -*-
"""
reporting/data_context.py
----------------------------
لایه‌ی مشترک داده برای هر دو رندرر گزارش (HTML و PDF).

اصل طراحی حیاتی: **هیچ محاسبه‌ی تحلیلی جدیدی اینجا انجام نمی‌شود.** این
ماژول فقط خروجی‌های از قبل محاسبه‌شده‌ی موتور تحلیلی (`FullResult` از
`ScoreEngine.run()` و دیکشنری `coach` از `CoachingEngine.generate()`) را
می‌خواند و در یک ساختار دیکشنری واحد و مسطح (flat) برای مصرف مستقیم توسط
قالب‌های Jinja2 (HTML) و لایه‌ی reportlab (PDF) سازمان‌دهی می‌کند.

چرا یک context مشترک؟
  اگر HTML و PDF هرکدام جدا داده را از FullResult/coach استخراج می‌کردند،
  به‌مرور می‌توانستند به دو عدد متفاوت برای همان چیز برسند (مثلاً یکی
  net_profit را از performance می‌گیرد، دیگری اشتباهی از context
  می‌سازد). با ساختن این context یک‌بار در یک‌جا، هر دو رندرر دقیقاً از
  همان اعداد استفاده می‌کنند — تضمین سازگاری.

«نقاط قوت» و «نقاط ضعف» (Strengths/Weaknesses) در بخش ۵ این فایل، تنها
بازچینش (بازطبقه‌بندی نمایشی) برچسب‌های severity/priority است که از قبل
توسط ScoreEngine/EvidenceEngine محاسبه شده‌اند (مثلاً severity=="Low" →
نقطه‌ی قوت). هیچ آستانه یا فرمول تحلیلی جدیدی معرفی نمی‌شود.
"""

from dataclasses import asdict
from datetime import datetime
from typing import Any, Dict, List, Optional

from engines.report_engine import FullResult
from utils.logger import get_logger

log = get_logger(__name__)

REPORT_ENGINE_VERSION = "Trading Doctor V23 — Reporting Module Phase 2"


# ----------------------------------------------------------------------
# ابزارهای کمکی نمایشی (presentation-only — بدون منطق تحلیلی)
# ----------------------------------------------------------------------

def _fmt_money(value: Optional[float]) -> str:
    if value is None:
        return "N/A"
    sign = "+" if value > 0 else ""
    return f"{sign}${value:,.2f}"


def _fmt_pct(value: Optional[float]) -> str:
    if value is None:
        return "N/A"
    return f"{value:.1f}%"


def _severity_rank(severity: str) -> int:
    return {"Low": 0, "Medium": 1, "High": 2, "Critical": 3}.get(severity, 1)


def _build_strengths_weaknesses(context: Dict[str, Any], edge_map: Dict[str, Any],
                                 performance: Dict[str, Any]) -> Dict[str, List[str]]:
    """
    فقط بازچینش نمایشی خروجی‌های موجود:
      - هر ContextBlock با severity=="Low"  -> نقطه‌ی قوت
      - هر ContextBlock با severity در {"High","Critical"} -> نقطه‌ی ضعف
      - best_hour/best_weekday/best_strategy از edge_map (اگر موجود) -> نقطه‌ی قوت
      - worst_hour/worst_weekday/worst_strategy از edge_map (اگر موجود) -> نقطه‌ی ضعف
      - profit_factor >= 1 (خط سربه‌سر استاندارد صنعت) -> نقطه‌ی قوت، در غیر این صورت ضعف
        (این تنها آستانه‌ی صنعتی شناخته‌شده است که اضافه می‌شود، نه یک فرمول جدید تحلیلی)
    """
    strengths: List[str] = []
    weaknesses: List[str] = []

    label_map = {
        "revenge_score": "معامله‌ی انتقامی (Revenge Trading)",
        "overtrading_score": "بیش‌معامله‌گری (Overtrading)",
        "risk_taking_score": "ریسک‌پذیری در حجم معاملات",
        "patience_score": "صبر و فاصله‌ی زمانی بین معاملات",
        "discipline_score": "انضباط کلی",
    }

    for key, ctx in context.items():
        label = label_map.get(key, key)
        if ctx.severity == "Low":
            strengths.append(f"{label}: در محدوده‌ی سالم قرار دارد (شدت: Low).")
        elif ctx.severity in ("High", "Critical"):
            weaknesses.append(f"{label}: {ctx.insight}")

    best_hour = edge_map.get("best_hour")
    if best_hour:
        strengths.append(
            f"بهترین ساعت معاملاتی: ساعت {best_hour.get('hour')} "
            f"(میانگین سود {_fmt_money(best_hour.get('avg_pnl'))})."
        )
    worst_hour = edge_map.get("worst_hour")
    if worst_hour and worst_hour.get("avg_pnl", 0) < 0:
        weaknesses.append(
            f"ضعیف‌ترین ساعت معاملاتی: ساعت {worst_hour.get('hour')} "
            f"(میانگین سود {_fmt_money(worst_hour.get('avg_pnl'))})."
        )
    best_weekday = edge_map.get("best_weekday")
    if best_weekday:
        strengths.append(
            f"بهترین روز هفته: {best_weekday.get('day')} "
            f"(سود کل {_fmt_money(best_weekday.get('total_pnl'))})."
        )
    worst_weekday = edge_map.get("worst_weekday")
    if worst_weekday and worst_weekday.get("total_pnl", 0) < 0:
        weaknesses.append(
            f"ضعیف‌ترین روز هفته: {worst_weekday.get('day')} "
            f"(سود کل {_fmt_money(worst_weekday.get('total_pnl'))})."
        )
    best_strategy = edge_map.get("best_strategy")
    if best_strategy:
        strengths.append(
            f"بهترین استراتژی: {best_strategy.get('name')} "
            f"(Win Rate {best_strategy.get('win_rate_pct')}%)."
        )
    worst_strategy = edge_map.get("worst_strategy")
    if worst_strategy:
        weaknesses.append(f"ضعیف‌ترین استراتژی: {worst_strategy.get('name')}.")

    pf = performance.get("profit_factor")
    if pf is not None:
        if pf >= 1.0:
            strengths.append(f"Profit Factor {pf} — بالاتر یا برابر خط سربه‌سر استاندارد (1.0).")
        else:
            weaknesses.append(f"Profit Factor {pf} — پایین‌تر از خط سربه‌سر استاندارد (1.0).")

    if not strengths:
        strengths.append("با داده‌ی فعلی، نقطه‌ی قوت برجسته‌ای شناسایی نشد.")
    if not weaknesses:
        weaknesses.append("با داده‌ی فعلی، نقطه‌ی ضعف قابل‌توجهی شناسایی نشد.")

    return {"strengths": strengths, "weaknesses": weaknesses}


def build_report_context(
    result: FullResult,
    coach: Dict[str, Any],
    doctor: Any = None,
    report_title: str = "Trading Doctor — Behavioral Trading Report",
) -> Dict[str, Any]:
    """
    نقطه‌ی ورود واحد: هر دو رندرر (HTML/PDF) دقیقاً همین تابع را صدا می‌زنند.

    ورودی: خروجی‌های *از قبل محاسبه‌شده*‌ی خط لوله‌ی تحلیلی (Phase 1) —
    هیچ‌چیز اینجا دوباره محاسبه نمی‌شود.
    """
    log.info("Building report context (%d trades)",
              result.performance.get("total_trades", 0) if result.performance else 0)

    context = result.context or {}
    performance = result.performance or {}
    edge_map = result.edge_map or {}
    behavior = result.behavior

    trader_dna = coach.get("trader_dna", {}) if coach else {}
    diagnosis = coach.get("diagnosis", {}) if coach else {}
    key_evidence = coach.get("key_evidence", []) if coach else []
    action_plan = coach.get("action_plan", []) if coach else []
    explainable_ai = coach.get("explainable_ai", "") if coach else ""
    reality_check = coach.get("reality_check", "") if coach else ""

    strengths_weaknesses = _build_strengths_weaknesses(context, edge_map, performance)

    data_quality_warnings = list(getattr(doctor, "data_quality_warnings", []) or [])

    overall_score = behavior.scores.get("discipline_score", 0) if behavior else 0

    ctx_rows = []
    for key, block in context.items():
        ctx_rows.append({
            "key": key,
            "label": key.replace("_", " ").title(),
            "score": block.score,
            "severity": block.severity,
            "event_count": block.event_count,
            "dollars_lost": block.dollars_lost,
            "dollars_lost_fmt": _fmt_money(block.dollars_lost),
            "pct_of_total_profit": block.pct_of_total_profit,
            "insight": block.insight,
        })

    evidence_rows = []
    for e in key_evidence:
        evidence_rows.append({
            "type": e.get("type", "unknown"),
            "label": str(e.get("type", "unknown")).replace("_", " ").title(),
            "description": e.get("description", ""),
            "severity": e.get("severity", 0),
            "frequency": e.get("frequency", 0),
            "financial_impact": e.get("financial_impact", 0),
            "financial_impact_fmt": _fmt_money(e.get("financial_impact", 0)),
            "priority_score": e.get("priority_score", 0),
            "confidence": e.get("confidence", 0),
        })

    context_dict = {
        "meta": {
            "report_title": report_title,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "engine_version": REPORT_ENGINE_VERSION,
            "total_trades": performance.get("total_trades", 0),
        },
        "executive_summary": {
            "summary_text": result.summary,
            "overall_score": overall_score,
            "primary_diagnosis": diagnosis.get("primary", "N/A"),
            "archetype": trader_dna.get("archetype", "N/A"),
        },
        "overall_score": {
            "value": overall_score,
            "label": "Overall Trading Score (Discipline Composite)",
            "severity": _severity_rank(context.get("discipline_score").severity)
            if context.get("discipline_score") else 1,
        },
        "diagnosis": diagnosis,
        "trader_profile": trader_dna,
        "strengths": strengths_weaknesses["strengths"],
        "weaknesses": strengths_weaknesses["weaknesses"],
        "behavior_analysis": {
            "scores": behavior.scores if behavior else {},
            "context_rows": ctx_rows,
            "detected_patterns": behavior.detected_patterns if behavior else [],
            "what_if": behavior.what_if if behavior else {},
        },
        "psychology": {
            "dna": trader_dna,
            "narrative": (
                f"پروفایل رفتاری غالب: «{trader_dna.get('archetype', 'نامشخص')}». "
                "این آرچیتایپ بر اساس مهم‌ترین شاهد رفتاری شناسایی‌شده در تاریخچه‌ی "
                "معاملاتی شما تعیین شده است (نه یک آستانه‌ی ثابت)."
            ),
        },
        "evidence": evidence_rows,
        "statistics": {
            "total_trades": performance.get("total_trades", 0),
            "win_rate_pct": performance.get("win_rate_pct", 0),
            "max_win_streak": performance.get("max_win_streak", 0),
            "max_loss_streak": performance.get("max_loss_streak", 0),
        },
        "performance": {
            "net_profit": performance.get("net_profit", 0),
            "net_profit_fmt": _fmt_money(performance.get("net_profit", 0)),
            "profit_factor": performance.get("profit_factor", 0),
            "avg_win": performance.get("avg_win", 0),
            "avg_win_fmt": _fmt_money(performance.get("avg_win", 0)),
            "avg_loss": performance.get("avg_loss", 0),
            "avg_loss_fmt": _fmt_money(performance.get("avg_loss", 0)),
            "reward_risk_ratio": performance.get("reward_risk_ratio", 0),
        },
        "risk": {
            "max_drawdown": performance.get("max_drawdown", 0),
            "max_drawdown_fmt": _fmt_money(performance.get("max_drawdown", 0)),
            "risk_taking_score": behavior.scores.get("risk_taking_score", 0) if behavior else 0,
            "revenge_score": behavior.scores.get("revenge_score", 0) if behavior else 0,
            "what_if_no_revenge": (behavior.what_if.get("if_revenge_fixed", {}) if behavior else {}),
        },
        "recommendations": action_plan,
        "ai_coaching": {
            "explainable_ai": explainable_ai,
            "reality_check": reality_check,
        },
        "appendix": {
            "performance_raw": performance,
            "edge_map_raw": edge_map,
            "data_quality_warnings": data_quality_warnings,
            "generation_metadata": {
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "engine_version": REPORT_ENGINE_VERSION,
                "total_trades": performance.get("total_trades", 0),
            },
        },
    }
    log.info("Report context built successfully (%d evidence items, %d recommendations)",
              len(evidence_rows), len(action_plan))
    return context_dict
