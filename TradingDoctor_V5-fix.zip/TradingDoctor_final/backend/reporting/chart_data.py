# -*- coding: utf-8 -*-
"""
reporting/chart_data.py
------------------------
استخراج سری‌های زمانی JSON-serializable برای مصross برنامه‌نویسی (frontend)
از DataFrame خام معاملات. اینجا همان فرمول‌های reporting/charts.py اعمال
می‌شود ولی به‌جای تولید تصویر PNG، داده‌ی خام (x/y) برمی‌گردد تا کلاینت
(recharts در فرانت‌اند) آن را رسم کند.

اصل طراحی حیاتی: هیچ محاسبه‌ی تحلیلی جدیدی انجام نمی‌شود. فقط همان
فرمول‌های presentación که در reporting/charts.py و pages/02_Charts.py
وجود دارند، به‌صورت JSON بازتولید می‌شوند. به‌علاوه، استخراج فهرست خام
معاملات با pagination و فیلتر ساده برای endpoint /analyses/{id}/trades.

خروجی همه‌ی توابع JSON-serializable است (list/dict/number/str/bool/None).
"""

from typing import Any, Dict, List, Optional

import pandas as pd

from utils.logger import get_logger

log = get_logger(__name__)


# ----------------------------------------------------------------------
# توابع کمکی داخلی
# ----------------------------------------------------------------------

def _safe_int(value: Any) -> int:
    """تبدیل امن به int؛ NaN/None/رشته به 0 تبدیل می‌شوند."""
    try:
        if value is None or pd.isna(value):
            return 0
        return int(value)
    except (TypeError, ValueError):
        return 0


def _safe_float(value: Any) -> float:
    """تبدیل امن به float؛ NaN/None/رشته به 0.0 تبدیل می‌شوند."""
    try:
        if value is None or pd.isna(value):
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _safe_str(value: Any) -> str:
    """تبدیل امن به str؛ NaT/NaN به رشته‌ی خالی تبدیل می‌شوند."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        # pd.isna روی برخی‌ مقادیر (مثل list) TypeError پرتاب می‌کند.
        pass
    return str(value)


def _derive_side(row: pd.Series) -> Optional[str]:
    """سمت معامله (Long/Short) را فقط وقتی از داده واقعاً قابل استخراج است برمی‌گرداند.

    pipeline بارگذاری فایل (utils/column_mapper.py) تنها سه ستون استاندارد
    تولید می‌کند: Open Time / Profit / Size — و Size همیشه یک مقدار حجم
    غیرمنفی (lots/qty/volume) است، هرگز علامتِ جهت معامله را کدگذاری
    نمی‌کند. یعنی اگر فایل ورودی ستون صریح Side/Type نداشته باشد (که برای
    اکثر فایل‌های واقعی این‌طور است)، جهتِ معامله واقعاً نامعلوم است.

    نسخه‌ی قبلی این تابع در این حالت حدس می‌زد «Size <= 0 یعنی Short،
    وگرنه Long» — اما چون Size هیچ‌وقت منفی نمی‌شود، این حدس عملاً همیشه
    «Long» برمی‌گرداند: یک برچسبِ ثابت و گمراه‌کننده، نه داده‌ی واقعی.
    اینجا آن فالبک حذف شده و در نبود ستون صریح Side/Type مقدار None
    برگردانده می‌شود تا فرانت‌اند این را «نامعلوم» نمایش دهد، نه «Long».
    """
    for col in ("Side", "side", "Type", "type"):
        if col in row.index:
            v = _safe_str(row[col]).lower().strip()
            if v in ("long", "buy", "b"):
                return "Long"
            if v in ("short", "sell", "s"):
                return "Short"
    return None


# ----------------------------------------------------------------------
# استخراج فهرست خام معاملات
# ----------------------------------------------------------------------

def extract_trades_list(
    df: Optional[pd.DataFrame],
    page: int = 1,
    page_size: int = 50,
    side_filter: Optional[str] = None,
    outcome_filter: Optional[str] = None,
) -> Dict[str, Any]:
    """فهرست خام معاملات را با pagination برمی‌گرداند.

    خروجی: { trades: [...], total, page, page_size }

    فیلترها:
      side_filter:   "Long" | "Short" | None
      outcome_filter: "win" | "loss" | None
    """
    if df is None or len(df) == 0:
        return {"trades": [], "total": 0, "page": page, "page_size": page_size, "side_available": False}

    # اطمینان از وجود ستون hour/weekday برای هر trade row
    df = df.copy()
    if "Open Time" in df.columns:
        ot = pd.to_datetime(df["Open Time"], errors="coerce")
        if "hour" not in df.columns:
            df["hour"] = ot.dt.hour.fillna(-1).astype(int)
        if "weekday" not in df.columns:
            df["weekday"] = ot.dt.day_name().fillna("")
    else:
        if "hour" not in df.columns:
            df["hour"] = -1
        if "weekday" not in df.columns:
            df["weekday"] = ""

    # آیا جهتِ معامله اصلاً برای این dataset قابل استخراج است؟ اگر فایل ورودی
    # هیچ ستون Side/Type نداشته باشد، _derive_side برای همه‌ی ردیف‌ها None
    # برمی‌گرداند — فرانت‌اند باید فیلتر Long/Short را در این حالت غیرفعال
    # کند به‌جای نمایش نتیجه‌ی خالی/گمراه‌کننده.
    has_explicit_side_column = any(
        col in df.columns for col in ("Side", "side", "Type", "type")
    )

    # اعمال فیلترها
    mask = pd.Series([True] * len(df), index=df.index)
    if side_filter in ("Long", "Short"):
        # سمت را به‌صورت lazy روی کل df محاسبه نمی‌کنیم تا در حافظه سنگین نباشد؛
        # به‌جای آن، در یک پاس روی هر row اعمال می‌کنیم.
        sides = df.apply(_derive_side, axis=1)
        mask &= sides == side_filter
    if outcome_filter in ("win", "loss"):
        if "Profit" in df.columns:
            if outcome_filter == "win":
                mask &= df["Profit"] > 0
            else:
                mask &= df["Profit"] < 0

    filtered = df[mask]
    total = int(len(filtered))

    # Pagination (1-indexed)
    page = max(1, int(page))
    page_size = max(1, min(500, int(page_size)))  # حداکثر 500 ردیف در هر درخواست
    start = (page - 1) * page_size
    end = start + page_size
    page_df = filtered.iloc[start:end]

    trades: List[Dict[str, Any]] = []
    for idx, (_, row) in enumerate(page_df.iterrows()):
        trade_id = start + idx + 1  # 1-indexed در کل فیلتر شده، نه در صفحه
        open_time = _safe_str(row.get("Open Time", ""))
        # اگر datetime است، آن را به ISO با ثانیه تبدیل کن (بدون میکروثانیه).
        try:
            ts = pd.to_datetime(open_time, errors="coerce")
            if not pd.isna(ts):
                open_time = ts.strftime("%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            pass

        trades.append({
            "id": trade_id,
            "open_time": open_time,
            "side": _derive_side(row),
            "size": _safe_float(row.get("Size", 0)),
            "profit": _safe_float(row.get("Profit", 0)),
            "hour": _safe_int(row.get("hour", -1)),
            "weekday": _safe_str(row.get("weekday", "")),
            "date": open_time.split(" ")[0] if " " in open_time else open_time,
        })

    log.info("Extracted %d trades (page %d of %d total)", len(trades), page, total)
    return {
        "trades": trades,
        "total": total,
        "page": page,
        "page_size": page_size,
        "side_available": has_explicit_side_column,
    }


# ----------------------------------------------------------------------
# استخراج سری‌های نموداری (charts)
# ----------------------------------------------------------------------

def extract_equity_curve(df: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    """Equity = cumsum(Profit). همان فرمول charts.equity_curve_chart."""
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return []
    equity = df["Profit"].cumsum()
    return [
        {"trade": i + 1, "equity": _safe_float(v)}
        for i, v in enumerate(equity.values)
    ]


def extract_drawdown(df: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    """Drawdown = Equity - cummax(Equity). همان فرمول charts.drawdown_chart."""
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return []
    equity = df["Profit"].cumsum()
    drawdown = equity - equity.cummax()
    return [
        {"trade": i + 1, "drawdown": _safe_float(v)}
        for i, v in enumerate(drawdown.values)
    ]


def extract_pnl_distribution(
    df: Optional[pd.DataFrame],
    n_bins: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """توزیع سود/زیان هر معامله به‌صورت histogram آماده‌ی نمایش.

    هر bin یک رکورد است: { range, count, type }.
    type: "win" اگر left_edge >= 0، در غیر این صورت "loss".
    """
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return []
    profit = df["Profit"].values
    if n_bins is None:
        n_bins = min(40, max(10, len(profit) // 5))
    # از np.histogram استفاده می‌کنیم (ساده‌تر از pd.cut + groupby) و برای
    # پانداس جدید/قدیم بدون هشدار کار می‌کند.
    import numpy as np
    counts_arr, bin_edges = np.histogram(profit, bins=n_bins)
    out: List[Dict[str, Any]] = []
    for i, count in enumerate(counts_arr):
        left = _safe_float(bin_edges[i])
        right = _safe_float(bin_edges[i + 1])
        out.append({
            "range": f"{left:.2f}–{right:.2f}",
            "count": int(count),
            "type": "win" if left >= 0 else "loss",
            "bin_left": left,
            "bin_right": right,
        })
    return out


def extract_hourly_pnl(df: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    """سود/زیان گروه‌بندی‌شده بر اساس ساعت روز (0-23)."""
    if df is None or len(df) == 0 or "Open Time" not in df.columns:
        return []
    df = df.copy()
    ot = pd.to_datetime(df["Open Time"], errors="coerce")
    if ot.isna().all():
        return []
    df["_hour"] = ot.dt.hour
    # observed=False صریح: رفتار یکسان روی pandas قدیم/جدید.
    hourly = df.groupby("_hour", observed=False)["Profit"].sum()
    hourly = hourly.reindex(range(24), fill_value=0)
    return [
        {"hour": int(h), "pnl": _safe_float(v)}
        for h, v in hourly.items()
    ]


def extract_weekday_pnl(df: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    """سود/زیان گروه‌بندی‌شده بر اساس روز هفته."""
    if df is None or len(df) == 0 or "Open Time" not in df.columns:
        return []
    df = df.copy()
    ot = pd.to_datetime(df["Open Time"], errors="coerce")
    if ot.isna().all():
        return []
    df["_weekday"] = ot.dt.day_name()
    weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    # observed=False صریح: رفتار یکسان روی pandas قدیم/جدید.
    grouped = df.groupby("_weekday", observed=False)["Profit"].sum()
    grouped = grouped.reindex(weekday_order, fill_value=0)
    return [
        {"weekday": w, "pnl": _safe_float(v)}
        for w, v in grouped.items()
    ]


def extract_win_loss_pie(df: Optional[pd.DataFrame]) -> Dict[str, Any]:
    """توزیع برد/باخت/سربه‌سر به‌صورت counts."""
    if df is None or len(df) == 0 or "Profit" not in df.columns:
        return {"wins": 0, "losses": 0, "breakeven": 0, "total": 0}
    profit = df["Profit"]
    wins = int((profit > 0).sum())
    losses = int((profit < 0).sum())
    breakeven = int((profit == 0).sum())
    return {
        "wins": wins,
        "losses": losses,
        "breakeven": breakeven,
        "total": wins + losses + breakeven,
    }


def build_chart_series(df: Optional[pd.DataFrame]) -> Dict[str, Any]:
    """همه‌ی سری‌های نموداری را به‌صورت یک دیکشنری JSON-serializable برمی‌گرداند.

    خروجی:
      {
        equity_curve: [{trade, equity}, ...],
        drawdown:     [{trade, drawdown}, ...],
        pnl_distribution: [{range, count, type, bin_left, bin_right}, ...],
        hourly_pnl:   [{hour, pnl}, ...],
        weekday_pnl:  [{weekday, pnl}, ...],
        win_loss_pie: {wins, losses, breakeven, total},
      }
    """
    return {
        "equity_curve": extract_equity_curve(df),
        "drawdown": extract_drawdown(df),
        "pnl_distribution": extract_pnl_distribution(df),
        "hourly_pnl": extract_hourly_pnl(df),
        "weekday_pnl": extract_weekday_pnl(df),
        "win_loss_pie": extract_win_loss_pie(df),
    }
