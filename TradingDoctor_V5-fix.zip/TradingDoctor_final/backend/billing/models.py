# -*- coding: utf-8 -*-
"""
billing/models.py
-----------------
Phase 10 — ORM models for the subscription & billing subsystem.

Tables added:
  - plans           (catalog of subscription plans; seeded at deploy time)
  - subscriptions   (a user's current subscription state)
  - invoices        (one per billing period; mirrors Stripe invoices)
  - usage_events    (append-only log of metered usage)

Design:
  - UUID primary keys
  - Per-user isolation: subscriptions/invoices/usage_events all have user_id
  - Plans are stored in DB (not just code) so they can be added without redeploy
  - Subscriptions track Stripe customer_id + subscription_id for reconciliation
  - Usage events are append-only (never UPDATE) — usage is computed by aggregation
  - Soft-delete NOT used here — billing records are permanent (compliance)
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.base import Base
from db.models import TimestampMixin, UUIDPkMixin


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class PlanTier(str, enum.Enum):
    """Tier identifier used for feature gating.

    The string values are stable across renames — never change them once
    shipped, or existing subscriptions will be orphaned.
    """
    free = "free"
    pro = "pro"
    premium = "premium"


class SubscriptionStatus(str, enum.Enum):
    """Lifecycle states for a subscription.

    Mirrors Stripe's subscription status enum for easy reconciliation.
    """
    trialing = "trialing"
    active = "active"
    past_due = "past_due"
    canceled = "canceled"
    unpaid = "unpaid"
    incomplete = "incomplete"


class InvoiceStatus(str, enum.Enum):
    """Status of an invoice.

    Mirrors Stripe's invoice status enum.
    """
    draft = "draft"
    open = "open"
    paid = "paid"
    void = "void"
    uncollectible = "uncollectible"


class UsageEventType(str, enum.Enum):
    """Type of metered usage event.

    Append-only log; aggregation queries compute monthly totals.
    """
    analysis_run = "analysis_run"
    upload_bytes = "upload_bytes"
    llm_call = "llm_call"
    report_download = "report_download"


# ---------------------------------------------------------------------------
# Plan
# ---------------------------------------------------------------------------

class Plan(UUIDPkMixin, TimestampMixin, Base):
    """A subscription plan (Free / Pro / Premium).

    Plans are seeded at deploy time via `billing.services.plans.seed_plans()`.
    They can be added or modified without redeploy by updating the DB directly,
    but the `tier` enum value must remain stable.
    """

    __tablename__ = "plans"

    tier: Mapped[PlanTier] = mapped_column(
        Enum(PlanTier, name="plan_tier",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        unique=True,
        index=True,
    )

    # Display name (Persian, since the product is Persian-first)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Price in minor units (cents). 0 for free tier.
    price_cents: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="usd")

    # Billing interval: "month" | "year" | "one_time" (free tier)
    interval: Mapped[str] = mapped_column(String(20), nullable=False, default="month")

    # Usage limits (-1 means unlimited)
    max_analyses_per_month: Mapped[int] = mapped_column(Integer, nullable=False, default=-1)
    max_upload_size_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=-1)
    max_total_upload_bytes: Mapped[int] = mapped_column(Integer, nullable=False, default=-1)
    max_llm_calls_per_month: Mapped[int] = mapped_column(Integer, nullable=False, default=-1)

    # Feature flags (checked at the route layer)
    allows_pdf_export: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    allows_ai_coaching: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    allows_history_search: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    allows_favorites: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    priority_support: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Stripe price ID (for paid tiers; None for free)
    stripe_price_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # Whether this plan is publicly selectable
    is_public: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # Sort order for display
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    def __repr__(self) -> str:
        return f"<Plan tier={self.tier.value} name={self.name!r} price={self.price_cents}c>"


# ---------------------------------------------------------------------------
# Subscription
# ---------------------------------------------------------------------------

class Subscription(UUIDPkMixin, TimestampMixin, Base):
    """A user's subscription state.

    One row per user (enforced by unique constraint on user_id where status
    is active/trialing/past_due). Canceled subscriptions remain in the table
    for historical audit.
    """

    __tablename__ = "subscriptions"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    plan_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("plans.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    status: Mapped[SubscriptionStatus] = mapped_column(
        Enum(SubscriptionStatus, name="subscription_status",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=SubscriptionStatus.active,
        index=True,
    )

    # Stripe IDs for reconciliation
    stripe_customer_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, index=True)
    stripe_subscription_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, index=True)

    # Billing period boundaries (UTC)
    current_period_start: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    current_period_end: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # When the subscription was canceled (if applicable)
    canceled_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # Why it was canceled (user_request, payment_failed, admin_action, etc.)
    cancel_reason: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Trial period (if any)
    trial_start: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    trial_end: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    plan: Mapped["Plan"] = relationship("Plan", lazy="selectin")

    __table_args__ = (
        # One active subscription per user. Multiple canceled ones allowed
        # for history. This is a partial unique index.
        Index(
            "uq_subscriptions_user_active",
            "user_id",
            unique=True,
            postgresql_where="status IN ('trialing', 'active', 'past_due', 'unpaid', 'incomplete')",
        ),
    )

    def __repr__(self) -> str:
        return f"<Subscription user_id={self.user_id} plan={self.plan_id} status={self.status.value}>"


# ---------------------------------------------------------------------------
# Invoice
# ---------------------------------------------------------------------------

class Invoice(UUIDPkMixin, TimestampMixin, Base):
    """An invoice for a billing period.

    Mirrors Stripe invoices. Stored locally so users can view their history
    without round-tripping to Stripe.
    """

    __tablename__ = "invoices"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    subscription_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("subscriptions.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    plan_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("plans.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Stripe invoice ID (for reconciliation)
    stripe_invoice_id: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True, unique=True, index=True,
    )

    status: Mapped[InvoiceStatus] = mapped_column(
        Enum(InvoiceStatus, name="invoice_status",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=InvoiceStatus.draft,
        index=True,
    )

    # Amount in minor units (cents)
    amount_due_cents: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    amount_paid_cents: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="usd")

    # Billing period covered by this invoice
    period_start: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    period_end: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # When the invoice was paid (None until paid)
    paid_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # PDF URL (hosted by Stripe) or local path
    invoice_pdf_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    hosted_invoice_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # Free-text description (e.g. "Pro plan — Monthly subscription")
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Optional relationship to subscription (may be null if sub was deleted)
    subscription: Mapped[Optional["Subscription"]] = relationship("Subscription")

    def __repr__(self) -> str:
        return f"<Invoice id={self.id} user_id={self.user_id} amount={self.amount_due_cents}c status={self.status.value}>"


# ---------------------------------------------------------------------------
# UsageEvent
# ---------------------------------------------------------------------------

class UsageEvent(UUIDPkMixin, TimestampMixin, Base):
    """An append-only log of metered usage.

    Used to compute monthly usage totals per user. Never UPDATE — only INSERT.
    Aggregation queries compute the running totals.

    Examples:
      - (user_id, "analysis_run", 1, 2026-07-18) — one analysis run
      - (user_id, "upload_bytes", 1048576, 2026-07-18) — 1MB upload
      - (user_id, "llm_call", 1, 2026-07-18) — one LLM API call
    """

    __tablename__ = "usage_events"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    event_type: Mapped[UsageEventType] = mapped_column(
        Enum(UsageEventType, name="usage_event_type",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        index=True,
    )

    # Quantity consumed (e.g. 1 for one analysis, 1048576 for 1MB upload).
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    # Optional reference to the resource that triggered the event
    # (e.g. analysis_id for analysis_run events).
    resource_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    # Optional metadata (JSON-encoded string)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Billing period this event counts toward (denormalized for fast aggregation).
    # Format: "2026-07" (YYYY-MM).
    billing_period: Mapped[str] = mapped_column(String(7), nullable=False, index=True)

    __table_args__ = (
        Index("ix_usage_events_user_period_type", "user_id", "billing_period", "event_type"),
    )

    def __repr__(self) -> str:
        return f"<UsageEvent user_id={self.user_id} type={self.event_type.value} qty={self.quantity}>"
