# -*- coding: utf-8 -*-
"""
billing/schemas.py
------------------
Phase 10 — Pydantic schemas for billing endpoints.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from billing.models import PlanTier, SubscriptionStatus, InvoiceStatus


class _StrictBase(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
    )


# ---------------------------------------------------------------------------
# Plan
# ---------------------------------------------------------------------------

class PlanLimits(_StrictBase):
    max_analyses_per_month: int
    max_upload_size_bytes: int
    max_total_upload_bytes: int
    max_llm_calls_per_month: int


class PlanFeatures(_StrictBase):
    allows_pdf_export: bool
    allows_ai_coaching: bool
    allows_history_search: bool
    allows_favorites: bool
    priority_support: bool


class PlanResponse(_StrictBase):
    plan_id: str
    tier: str
    name: str
    description: Optional[str] = None
    price_cents: int
    currency: str
    interval: str
    limits: PlanLimits
    features: PlanFeatures
    stripe_price_id: Optional[str] = None
    sort_order: int


class PlanListResponse(_StrictBase):
    plans: List[PlanResponse]


# ---------------------------------------------------------------------------
# Subscription
# ---------------------------------------------------------------------------

class SubscriptionResponse(_StrictBase):
    subscription_id: str
    plan: PlanResponse
    status: str
    current_period_start: Optional[datetime] = None
    current_period_end: Optional[datetime] = None
    trial_start: Optional[datetime] = None
    trial_end: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
    stripe_customer_id: Optional[str] = None


class CurrentPlanResponse(_StrictBase):
    """Compact response for 'what plan am I on?' queries."""
    tier: str
    plan_name: str
    status: str
    current_period_end: Optional[datetime] = None
    is_active: bool
    is_trial: bool


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------

class UsageSummaryResponse(_StrictBase):
    billing_period: str
    analyses_run: int
    llm_calls: int
    upload_bytes: int
    report_downloads: int
    plan_limits: PlanLimits


# ---------------------------------------------------------------------------
# Checkout / portal
# ---------------------------------------------------------------------------

class CheckoutRequest(_StrictBase):
    target_tier: PlanTier
    success_url: str = Field(..., description="URL to redirect to after successful payment")
    cancel_url: str = Field(..., description="URL to redirect to if user cancels")


class CheckoutResponse(_StrictBase):
    session_id: str
    url: str


class PortalRequest(_StrictBase):
    return_url: str


class PortalResponse(_StrictBase):
    url: str


class CancelSubscriptionRequest(_StrictBase):
    cancel_at_period_end: bool = Field(
        True,
        description="If True (default), cancels at end of billing period. If False, cancels immediately.",
    )
    reason: Optional[str] = Field(None, max_length=100)


# ---------------------------------------------------------------------------
# Invoices
# ---------------------------------------------------------------------------

class InvoiceResponse(_StrictBase):
    invoice_id: str
    stripe_invoice_id: Optional[str] = None
    status: str
    amount_due_cents: int
    amount_paid_cents: int
    currency: str
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    paid_at: Optional[datetime] = None
    invoice_pdf_url: Optional[str] = None
    hosted_invoice_url: Optional[str] = None
    description: Optional[str] = None
    created_at: datetime


class InvoiceListResponse(_StrictBase):
    invoices: List[InvoiceResponse]
    total: int
