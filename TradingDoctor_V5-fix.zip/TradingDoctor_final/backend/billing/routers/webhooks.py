# -*- coding: utf-8 -*-
"""
billing/routers/webhooks.py
---------------------------
Phase 10 — Stripe webhook receiver.

CRITICAL SECURITY:
  - This router is NOT behind verify_api_key or get_current_user.
  - Authentication is via Stripe webhook signature verification ONLY.
  - Every request must have a valid Stripe-Signature header matching
    the raw body + STRIPE_WEBHOOK_SECRET.
  - Without signature verification, an attacker could forge webhooks to
    grant themselves premium subscriptions.

The raw body MUST be used for signature verification (not the parsed JSON).
FastAPI's default JSON parsing consumes the body, so we use `Request.body()`
directly.

Endpoint:
  - POST /billing/webhooks/stripe
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Request, status
from fastapi.responses import JSONResponse

from billing import config as billing_config
from billing.services import stripe_provider
from billing.services.subscriptions import (
    upsert_invoice_from_stripe,
    upsert_subscription_from_stripe,
)
from db.base import get_db
from utils.logger import get_logger

log = get_logger("billing.webhooks")

router = APIRouter(tags=["Webhooks"])


# ---------------------------------------------------------------------------
# Webhook event handlers (one per event type we care about)
# ---------------------------------------------------------------------------

async def _handle_checkout_session_completed(event: dict) -> None:
    """Fired when a user completes a Stripe Checkout Session.

    The actual subscription data comes from the customer.subscription.*
    events. We just log here; the subscription lifecycle is driven by
    customer.subscription.created/updated/deleted.
    """
    session = event.get("data", {}).get("object", {})
    log.info(
        "Stripe checkout.session.completed: session_id=%s customer=%s",
        session.get("id"), session.get("customer"),
    )


async def _handle_customer_subscription_created(event: dict) -> None:
    """Fired when a new subscription is created in Stripe."""
    sub_obj = event.get("data", {}).get("object", {})
    log.info("Stripe customer.subscription.created: sub_id=%s", sub_obj.get("id"))

    # Get an async DB session
    from db.base import async_session_factory
    if async_session_factory is None:
        log.error("DB not configured; cannot process webhook")
        return

    # Extract user_id from metadata
    metadata = sub_obj.get("metadata", {}) or {}
    user_id_str = metadata.get("tradingdoctor_user_id")

    # Extract price_id from subscription items
    items = sub_obj.get("items", {}).get("data", [])
    price_id = items[0].get("price", {}).get("id") if items else None

    import uuid as uuid_mod
    user_id = uuid_mod.UUID(user_id_str) if user_id_str else None

    async with async_session_factory() as db:
        try:
            await upsert_subscription_from_stripe(
                db=db,
                stripe_subscription_id=sub_obj["id"],
                stripe_customer_id=sub_obj["customer"],
                status=sub_obj["status"],
                current_period_start=_ts_to_dt(sub_obj.get("current_period_start")),
                current_period_end=_ts_to_dt(sub_obj.get("current_period_end")),
                trial_start=_ts_to_dt(sub_obj.get("trial_start")),
                trial_end=_ts_to_dt(sub_obj.get("trial_end")),
                canceled_at=_ts_to_dt(sub_obj.get("canceled_at")),
                price_id=price_id,
                user_id=user_id,
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


async def _handle_customer_subscription_updated(event: dict) -> None:
    """Fired when a subscription is updated (plan change, cancellation, etc.).

    Phase 12 audit fix (C7): extract user_id from metadata so the upsert can
    find-or-create even if the `created` webhook hasn't been processed yet.
    """
    sub_obj = event.get("data", {}).get("object", {})
    log.info("Stripe customer.subscription.updated: sub_id=%s status=%s",
             sub_obj.get("id"), sub_obj.get("status"))

    from db.base import async_session_factory
    if async_session_factory is None:
        log.error("DB not configured; cannot process webhook")
        return

    items = sub_obj.get("items", {}).get("data", [])
    price_id = items[0].get("price", {}).get("id") if items else None

    # Phase 12 audit fix (C7): extract user_id from metadata (same as `created`)
    metadata = sub_obj.get("metadata", {}) or {}
    user_id_str = metadata.get("tradingdoctor_user_id")
    import uuid as uuid_mod
    user_id = uuid_mod.UUID(user_id_str) if user_id_str else None

    async with async_session_factory() as db:
        try:
            await upsert_subscription_from_stripe(
                db=db,
                stripe_subscription_id=sub_obj["id"],
                stripe_customer_id=sub_obj["customer"],
                status=sub_obj["status"],
                current_period_start=_ts_to_dt(sub_obj.get("current_period_start")),
                current_period_end=_ts_to_dt(sub_obj.get("current_period_end")),
                trial_start=_ts_to_dt(sub_obj.get("trial_start")),
                trial_end=_ts_to_dt(sub_obj.get("trial_end")),
                canceled_at=_ts_to_dt(sub_obj.get("canceled_at")),
                price_id=price_id,
                user_id=user_id,  # Phase 12 fix: pass user_id for find-or-create
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


async def _handle_customer_subscription_deleted(event: dict) -> None:
    """Fired when a subscription is fully deleted (after period end)."""
    sub_obj = event.get("data", {}).get("object", {})
    log.info("Stripe customer.subscription.deleted: sub_id=%s", sub_obj.get("id"))

    from db.base import async_session_factory
    if async_session_factory is None:
        log.error("DB not configured; cannot process webhook")
        return

    async with async_session_factory() as db:
        try:
            await upsert_subscription_from_stripe(
                db=db,
                stripe_subscription_id=sub_obj["id"],
                stripe_customer_id=sub_obj["customer"],
                status="canceled",
                canceled_at=_ts_to_dt(sub_obj.get("canceled_at")),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


async def _handle_invoice_finalized(event: dict) -> None:
    """Fired when an invoice is finalized (ready to be paid)."""
    inv_obj = event.get("data", {}).get("object", {})
    log.info("Stripe invoice.finalized: inv_id=%s", inv_obj.get("id"))
    await _upsert_invoice(inv_obj)


async def _handle_invoice_paid(event: dict) -> None:
    """Fired when an invoice is paid."""
    inv_obj = event.get("data", {}).get("object", {})
    log.info("Stripe invoice.paid: inv_id=%s amount=%dc",
             inv_obj.get("id"), inv_obj.get("amount_paid"))
    await _upsert_invoice(inv_obj)


async def _handle_invoice_payment_failed(event: dict) -> None:
    """Fired when an invoice payment fails. Subscription goes past_due."""
    inv_obj = event.get("data", {}).get("object", {})
    log.warning("Stripe invoice.payment_failed: inv_id=%s", inv_obj.get("id"))
    await _upsert_invoice(inv_obj)


async def _upsert_invoice(inv_obj: dict) -> None:
    """Helper: upsert an invoice from Stripe's invoice object."""
    from db.base import async_session_factory
    if async_session_factory is None:
        log.error("DB not configured; cannot process webhook")
        return

    async with async_session_factory() as db:
        try:
            await upsert_invoice_from_stripe(
                db=db,
                stripe_invoice_id=inv_obj["id"],
                stripe_customer_id=inv_obj.get("customer"),
                stripe_subscription_id=inv_obj.get("subscription"),
                status=inv_obj.get("status", "draft"),
                amount_due_cents=inv_obj.get("amount_due", 0),
                amount_paid_cents=inv_obj.get("amount_paid", 0),
                currency=inv_obj.get("currency", "usd"),
                period_start=_ts_to_dt(inv_obj.get("period_start")),
                period_end=_ts_to_dt(inv_obj.get("period_end")),
                paid_at=_ts_to_dt(
                    inv_obj.get("status_transitions", {}).get("paid_at")
                    if inv_obj.get("status_transitions") else None
                ),
                invoice_pdf_url=inv_obj.get("invoice_pdf"),
                hosted_invoice_url=inv_obj.get("hosted_invoice_url"),
                description=inv_obj.get("description"),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


# ---------------------------------------------------------------------------
# Event dispatcher
# ---------------------------------------------------------------------------

EVENT_HANDLERS = {
    "checkout.session.completed": _handle_checkout_session_completed,
    "customer.subscription.created": _handle_customer_subscription_created,
    "customer.subscription.updated": _handle_customer_subscription_updated,
    "customer.subscription.deleted": _handle_customer_subscription_deleted,
    "invoice.finalized": _handle_invoice_finalized,
    "invoice.paid": _handle_invoice_paid,
    "invoice.payment_failed": _handle_invoice_payment_failed,
}


def _ts_to_dt(ts: Any) -> Any:
    """Convert a Unix timestamp to a timezone-aware datetime, or None."""
    if ts is None:
        return None
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc)


# ---------------------------------------------------------------------------
# Webhook endpoint
# ---------------------------------------------------------------------------

@router.post(
    "/billing/webhooks/stripe",
    status_code=status.HTTP_200_OK,
    include_in_schema=False,  # don't expose in OpenAPI (webhook endpoints are internal)
    summary="Stripe webhook receiver",
)
async def stripe_webhook(request: Request) -> JSONResponse:
    """Receive + verify + dispatch a Stripe webhook.

    Returns 200 if the event was processed successfully.
    Returns 400 if signature verification fails.
    Returns 500 if the event handler raises.

    Stripe retries webhooks that don't return 2xx — so we MUST be idempotent.
    All upsert operations are idempotent (find-or-create by stripe_*_id).
    """
    # 1. Read the raw body — signature verification requires the exact bytes.
    payload = await request.body()

    # 2. Get the signature header
    signature_header = request.headers.get("stripe-signature", "")
    if not signature_header:
        log.warning("Webhook received without Stripe-Signature header")
        return JSONResponse(
            status_code=400,
            content={"error": {"code": "missing_signature",
                                "message": "Stripe-Signature header is required."}},
        )

    # Stripe's signature header format: "t=1234567890,v1=abc123..."
    # The stripe_provider.verify_webhook_signature expects the raw header.
    # Re-implement here for clarity + to handle the parsing explicitly.
    try:
        # Parse the signature header
        parts = dict(part.split("=", 1) for part in signature_header.split(","))
        timestamp = parts.get("t", "")
        signature = parts.get("v1", "")
        if not timestamp or not signature:
            raise ValueError("Malformed Stripe-Signature header")

        # Verify using the stripe SDK
        import stripe as stripe_sdk  # type: ignore
        event = stripe_sdk.Webhook.construct_event(
            payload,
            signature_header,
            billing_config.STRIPE_WEBHOOK_SECRET,
            tolerance=billing_config.WEBHOOK_TOLERANCE_SECONDS,
        )
    except ValueError as exc:
        log.warning("Malformed Stripe-Signature: %s", exc)
        return JSONResponse(
            status_code=400,
            content={"error": {"code": "malformed_signature",
                                "message": "Stripe-Signature header is malformed."}},
        )
    except Exception as exc:
        # stripe.error.SignatureVerificationError or similar
        log.warning("Webhook signature verification failed: %s", exc)
        return JSONResponse(
            status_code=400,
            content={"error": {"code": "invalid_signature",
                                "message": "Webhook signature verification failed."}},
        )

    # 3. Dispatch to the appropriate handler
    event_type = event.get("type", "")
    log.info("Stripe webhook received: type=%s id=%s", event_type, event.get("id"))

    handler = EVENT_HANDLERS.get(event_type)
    if handler is None:
        # Unknown event type — log + return 200 so Stripe doesn't retry.
        # We don't want to handle events we don't care about, but we also
        # don't want Stripe to keep retrying them.
        log.info("Unhandled Stripe event type=%s (returning 200 to stop retries)", event_type)
        return JSONResponse(
            status_code=200,
            content={"received": True, "type": event_type, "handled": False},
        )

    try:
        await handler(event)
        log.info("Stripe webhook handled: type=%s", event_type)
        return JSONResponse(
            status_code=200,
            content={"received": True, "type": event_type, "handled": True},
        )
    except Exception as exc:
        # Handler raised — return 500 so Stripe retries.
        # BUT: be careful. If the handler is not idempotent, retries can
        # cause duplicates. All our handlers ARE idempotent (find-or-create).
        log.error("Webhook handler failed for type=%s: %s", event_type, exc, exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": {"code": "handler_failed",
                                "message": "Webhook handler raised an exception."}},
        )
