# -*- coding: utf-8 -*-
"""
billing/routers/billing.py
--------------------------
Phase 10 — User-facing billing endpoints.

All endpoints require authentication. Free-plan users can call these
to view their plan + upgrade; paid users can manage their subscription.

Endpoints:
  - GET    /billing/plans                  — list public plans
  - GET    /billing/subscription           — current subscription details
  - GET    /billing/usage                  — current period usage + limits
  - POST   /billing/checkout               — create Stripe Checkout Session
  - POST   /billing/portal                 — create Stripe Customer Portal session
  - POST   /billing/cancel                 — cancel subscription
  - GET    /billing/invoices               — list user's invoices
  - GET    /billing/invoices/{id}          — single invoice detail
"""

from __future__ import annotations

import uuid
from typing import Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import enforce_rate_limit, verify_api_key
from auth.dependencies import get_current_user
from auth.exceptions import AuthError
from auth.models import User
from billing import config as billing_config
from billing.exceptions import BillingError, NoActiveSubscriptionError
from billing.dependencies import get_user_plan
from billing.models import Invoice, Plan, PlanTier
from billing.schemas import (
    CancelSubscriptionRequest,
    CheckoutRequest,
    CheckoutResponse,
    CurrentPlanResponse,
    InvoiceListResponse,
    InvoiceResponse,
    PlanListResponse,
    PlanResponse,
    PortalRequest,
    PortalResponse,
    SubscriptionResponse,
    UsageSummaryResponse,
)
from billing.services import stripe_provider
from billing.services.plans import get_plan_by_id, list_public_plans, plan_to_dict
from billing.services.subscriptions import (
    cancel_subscription,
    create_billing_portal_session,
    create_checkout_session,
    get_user_subscription,
)
from billing.services.usage import get_user_usage_summary
from db.base import get_db
from utils.logger import get_logger

log = get_logger("billing.routers")

router = APIRouter(
    tags=["Billing"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


def _require_db(db):
    if db is None:
        raise AuthError("Database is required but is not configured.")


def _plan_to_response(plan: Plan) -> PlanResponse:
    return PlanResponse(
        plan_id=str(plan.id),
        tier=plan.tier.value,
        name=plan.name,
        description=plan.description,
        price_cents=plan.price_cents,
        currency=plan.currency,
        interval=plan.interval,
        limits={
            "max_analyses_per_month": plan.max_analyses_per_month,
            "max_upload_size_bytes": plan.max_upload_size_bytes,
            "max_total_upload_bytes": plan.max_total_upload_bytes,
            "max_llm_calls_per_month": plan.max_llm_calls_per_month,
        },
        features={
            "allows_pdf_export": plan.allows_pdf_export,
            "allows_ai_coaching": plan.allows_ai_coaching,
            "allows_history_search": plan.allows_history_search,
            "allows_favorites": plan.allows_favorites,
            "priority_support": plan.priority_support,
        },
        stripe_price_id=plan.stripe_price_id,
        sort_order=plan.sort_order,
    )


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------

@router.get(
    "/billing/plans",
    response_model=PlanListResponse,
    summary="فهرست طرح‌های اشتراک",
    description="لیست طرح‌های قابل انتخاب به‌همراه قیمت و محدودیت‌ها.",
)
async def list_plans(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PlanListResponse:
    _require_db(db)
    plans = await list_public_plans(db)
    return PlanListResponse(plans=[_plan_to_response(p) for p in plans])


# ---------------------------------------------------------------------------
# Current subscription
# ---------------------------------------------------------------------------

@router.get(
    "/billing/subscription",
    response_model=SubscriptionResponse,
    summary="جزئیات اشتراک فعلی",
)
async def get_subscription(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> SubscriptionResponse:
    _require_db(db)
    sub = await get_user_subscription(db, user.id)
    if sub is None:
        # Should not happen because get_user_plan auto-assigns free, but
        # be defensive.
        raise NoActiveSubscriptionError("اشتراکی برای این حساب یافت نشد.")

    return SubscriptionResponse(
        subscription_id=str(sub.id),
        plan=_plan_to_response(sub.plan),
        status=sub.status.value,
        current_period_start=sub.current_period_start,
        current_period_end=sub.current_period_end,
        trial_start=sub.trial_start,
        trial_end=sub.trial_end,
        canceled_at=sub.canceled_at,
        stripe_customer_id=sub.stripe_customer_id,
    )


@router.get(
    "/billing/current-plan",
    response_model=CurrentPlanResponse,
    summary="طرح فعلی (خلاصه)",
    description="نمای جهت کلاینت — فقط نام طرح و وضعیت، بدون جزئیات Stripe.",
)
async def get_current_plan(
    plan: Plan = Depends(get_user_plan),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> CurrentPlanResponse:
    _require_db(db)
    sub = await get_user_subscription(db, user.id)
    is_trial = sub is not None and sub.status.value == "trialing" and sub.trial_end is not None
    return CurrentPlanResponse(
        tier=plan.tier.value,
        plan_name=plan.name,
        status=sub.status.value if sub else "active",
        current_period_end=sub.current_period_end if sub else None,
        is_active=sub is not None and sub.status.value in ("active", "trialing"),
        is_trial=is_trial,
    )


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------

@router.get(
    "/billing/usage",
    response_model=UsageSummaryResponse,
    summary="مصرف فعلی + محدودیت طرح",
    description="مصرف ماه جاری به‌همراه محدودیت‌های طرح فعلی.",
)
async def get_usage(
    user: User = Depends(get_current_user),
    plan: Plan = Depends(get_user_plan),
    db: AsyncSession = Depends(get_db),
) -> UsageSummaryResponse:
    _require_db(db)
    usage = await get_user_usage_summary(db, user.id)
    return UsageSummaryResponse(
        billing_period=usage["billing_period"],
        analyses_run=usage["analyses_run"],
        llm_calls=usage["llm_calls"],
        upload_bytes=usage["upload_bytes"],
        report_downloads=usage["report_downloads"],
        plan_limits={
            "max_analyses_per_month": plan.max_analyses_per_month,
            "max_upload_size_bytes": plan.max_upload_size_bytes,
            "max_total_upload_bytes": plan.max_total_upload_bytes,
            "max_llm_calls_per_month": plan.max_llm_calls_per_month,
        },
    )


# ---------------------------------------------------------------------------
# Checkout (upgrade)
# ---------------------------------------------------------------------------

@router.post(
    "/billing/checkout",
    response_model=CheckoutResponse,
    summary="ایجاد جلسه‌ی پرداخت Stripe",
    description=(
        "برای ارتقا به یک طرح پرداختی، یک Stripe Checkout Session ایجاد می‌کند. "
        "کاربر به URL برگشتی هدایت می‌شود. پس از تکمیل پرداخت، Stripe وب‌هوک "
        "می‌فرستد و اشتراک محلی به‌روز می‌شود."
    ),
)
async def create_checkout(
    body: CheckoutRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> CheckoutResponse:
    _require_db(db)
    if body.target_tier == PlanTier.free:
        raise BillingError("برای طرح رایگان نیازی به پرداخت نیست.")

    session = await create_checkout_session(
        db=db,
        user_id=user.id,
        user_email=user.email,
        target_tier=body.target_tier,
        success_url=body.success_url,
        cancel_url=body.cancel_url,
        user_full_name=user.full_name,
    )
    return CheckoutResponse(session_id=session["session_id"], url=session["url"])


# ---------------------------------------------------------------------------
# Customer portal
# ---------------------------------------------------------------------------

@router.post(
    "/billing/portal",
    response_model=PortalResponse,
    summary="ایجاد جلسه‌ی پورتال مشتری Stripe",
    description=(
        "پورتال مشتری به کاربر اجازه می‌دهد کارت اعتباری خود را تغییر دهد، "
        "فاکتورها را ببیند، و اشتراک را مدیریت کند — همه روی Stripe."
    ),
)
async def create_portal(
    body: PortalRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> PortalResponse:
    _require_db(db)
    url = await create_billing_portal_session(db, user.id, body.return_url)
    return PortalResponse(url=url)


# ---------------------------------------------------------------------------
# Cancel
# ---------------------------------------------------------------------------

@router.post(
    "/billing/cancel",
    response_model=SubscriptionResponse,
    summary="لغو اشتراک",
    description=(
        "اشتراک را لغو می‌کند. به‌طور پیش‌فرض در پایان دوره‌ی فعلی لغو می‌شود "
        "(cancel_at_period_end=True). برای لغو فوری، false بفرستید."
    ),
)
async def cancel(
    body: CancelSubscriptionRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> SubscriptionResponse:
    _require_db(db)
    sub = await cancel_subscription(
        db=db,
        user_id=user.id,
        cancel_at_period_end=body.cancel_at_period_end,
        reason=body.reason or "user_request",
    )
    await db.commit()
    return SubscriptionResponse(
        subscription_id=str(sub.id),
        plan=_plan_to_response(sub.plan),
        status=sub.status.value,
        current_period_start=sub.current_period_start,
        current_period_end=sub.current_period_end,
        trial_start=sub.trial_start,
        trial_end=sub.trial_end,
        canceled_at=sub.canceled_at,
        stripe_customer_id=sub.stripe_customer_id,
    )


# ---------------------------------------------------------------------------
# Invoices
# ---------------------------------------------------------------------------

@router.get(
    "/billing/invoices",
    response_model=InvoiceListResponse,
    summary="فهرست فاکتورها",
)
async def list_invoices(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> InvoiceListResponse:
    _require_db(db)
    from sqlalchemy import func
    count_stmt = select(func.count(Invoice.id)).where(Invoice.user_id == user.id)
    total = (await db.execute(count_stmt)).scalar_one()

    offset = (page - 1) * page_size
    stmt = (
        select(Invoice)
        .where(Invoice.user_id == user.id)
        .order_by(Invoice.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    invoices = list((await db.execute(stmt)).scalars().all())
    return InvoiceListResponse(
        invoices=[_invoice_to_response(i) for i in invoices],
        total=total,
    )


@router.get(
    "/billing/invoices/{invoice_id}",
    response_model=InvoiceResponse,
    summary="جزئیات یک فاکتور",
)
async def get_invoice(
    invoice_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> InvoiceResponse:
    _require_db(db)
    stmt = select(Invoice).where(
        Invoice.id == invoice_id,
        Invoice.user_id == user.id,  # multi-tenant isolation
    )
    inv = (await db.execute(stmt)).scalar_one_or_none()
    if inv is None:
        from api.exceptions import NotFoundError
        raise NotFoundError("فاکتور یافت نشد.")
    return _invoice_to_response(inv)


def _invoice_to_response(inv: Invoice) -> InvoiceResponse:
    return InvoiceResponse(
        invoice_id=str(inv.id),
        stripe_invoice_id=inv.stripe_invoice_id,
        status=inv.status.value,
        amount_due_cents=inv.amount_due_cents,
        amount_paid_cents=inv.amount_paid_cents,
        currency=inv.currency,
        period_start=inv.period_start,
        period_end=inv.period_end,
        paid_at=inv.paid_at,
        invoice_pdf_url=inv.invoice_pdf_url,
        hosted_invoice_url=inv.hosted_invoice_url,
        description=inv.description,
        created_at=inv.created_at,
    )
