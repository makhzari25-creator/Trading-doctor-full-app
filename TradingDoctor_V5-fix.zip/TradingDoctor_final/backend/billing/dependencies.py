# -*- coding: utf-8 -*-
"""
billing/dependencies.py
-----------------------
Phase 10 — FastAPI dependencies for tier-based feature gating.

Two main dependencies:
  - get_user_plan:       returns the user's current Plan (or auto-assigns free)
  - require_tier("pro"): raises 402 if user's plan tier < required tier

Usage:
    @router.post("/premium-feature")
    async def premium_endpoint(
        user: User = Depends(get_current_user),
        plan: Plan = Depends(get_user_plan),
    ):
        if not plan.allows_ai_coaching:
            raise TierRequiredError("This feature requires the Pro plan.")
        ...

    # Or use the require_tier dependency for stricter gating:
    @router.post("/admin-only")
    async def admin_endpoint(
        user: User = Depends(get_current_user),
        _=Depends(require_tier(PlanTier.premium)),
    ):
        ...
"""

from __future__ import annotations

from typing import Optional

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from auth.dependencies import get_current_user
from auth.exceptions import AuthError, TierRequiredError
from auth.models import User
from billing import config as billing_config
from billing.models import Plan, PlanTier
from billing.services.subscriptions import (
    ensure_free_subscription,
    get_user_plan as _get_user_plan,  # rename to avoid shadowing
)
from db.base import get_db
from utils.logger import get_logger

log = get_logger("billing.dependencies")


# ---------------------------------------------------------------------------
# Plan lookup
# ---------------------------------------------------------------------------

async def get_user_plan(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Plan:
    """Return the user's current plan.

    If the user has no subscription AND AUTO_ASSIGN_FREE_PLAN is True,
    creates a free plan subscription on the fly.

    Raises AuthError if DB is unavailable.
    """
    if db is None:
        raise AuthError("Database is required but is not configured.")

    plan = await _get_user_plan(db, user.id)
    if plan is not None:
        return plan

    # No subscription — auto-assign free if configured.
    if billing_config.AUTO_ASSIGN_FREE_PLAN:
        await ensure_free_subscription(db, user.id, user.email)
        await db.commit()
        plan = await _get_user_plan(db, user.id)
        if plan is not None:
            return plan

    # Should never happen if free plan is seeded
    raise AuthError("No subscription found and free plan could not be auto-assigned.")


# ---------------------------------------------------------------------------
# Tier enforcement
# ---------------------------------------------------------------------------

# Tier ordering for comparison (lower = more restrictive).
_TIER_ORDER = {
    PlanTier.free: 0,
    PlanTier.pro: 1,
    PlanTier.premium: 2,
}


def require_tier(minimum_tier: PlanTier):
    """Return a FastAPI dependency that requires at least `minimum_tier`.

    Raises TierRequiredError (HTTP 402) if the user's plan tier is lower.
    """
    async def _check(
        plan: Plan = Depends(get_user_plan),
    ):
        user_order = _TIER_ORDER.get(plan.tier, 0)
        required_order = _TIER_ORDER[minimum_tier]
        if user_order < required_order:
            raise TierRequiredError(
                f"این قابلیت به طرح {minimum_tier.value} یا بالاتر نیاز دارد.",
                details={
                    "required_tier": minimum_tier.value,
                    "current_tier": plan.tier.value,
                    "upgrade_url": "/billing/plans",
                },
            )
        return plan

    return _check


def require_feature(feature: str):
    """Return a FastAPI dependency that requires a specific feature flag.

    Args:
      feature: "pdf_export" | "ai_coaching" | "history_search" | "favorites" | "priority_support"
    """
    async def _check(
        plan: Plan = Depends(get_user_plan),
    ):
        from billing.services.usage import plan_allows_feature
        if not plan_allows_feature(plan, feature):
            raise TierRequiredError(
                f"این قابلیت در طرح شما فعال نیست: {feature}",
                details={
                    "required_feature": feature,
                    "current_tier": plan.tier.value,
                    "upgrade_url": "/billing/plans",
                },
            )
        return plan

    return _check
