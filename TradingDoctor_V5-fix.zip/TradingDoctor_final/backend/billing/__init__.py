# -*- coding: utf-8 -*-
"""
billing
-------
Phase 10 — Subscription & Billing for TradingDoctor SaaS.

Public API:
  - Models:        billing.models.Plan, Subscription, Invoice, UsageEvent
  - Services:      billing.services.plans, billing.services.stripe_provider,
                   billing.services.subscriptions, billing.services.usage,
                   billing.services.invoices
  - Routers:       billing.routers.billing (checkout, portal, current plan, invoices)
                   billing.routers.webhooks (Stripe webhook receiver)
  - Dependencies:  billing.dependencies.require_tier (feature gating)

Design rules (carry forward from Phases 7.5 + 8 + 9):
  - Frozen V23 engine (engines/*) is never imported by anything in billing/.
  - Payment provider is pluggable: Stripe today, Paddle/LemonSqueezy later.
  - Webhook handler is unauthenticated by route (signature verification only).
  - Usage tracking is append-only (every event recorded for audit).
  - Tier enforcement is structural: require_tier("pro") blocks free users.
  - Invoices reuse Phase 2's reportlab + Vazirmatn font infrastructure.
"""

__all__: list[str] = []
