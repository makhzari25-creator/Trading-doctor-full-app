# -*- coding: utf-8 -*-
"""
billing/exceptions.py
----------------------
Exception hierarchy for user-triggered billing errors.

Before this file existed, the billing service layer (billing/services/
subscriptions.py) raised bare `ValueError` for conditions a *user* can
legitimately trigger from an API call — e.g. requesting checkout for a
plan tier that doesn't exist, opening the billing portal before ever
having a Stripe customer, or canceling a subscription that isn't there.

Those bare ValueErrors were not registered with any exception handler in
api/main.py, so they fell through to the catch-all `Exception` handler and
were returned to the client as HTTP 500 — even though nothing was actually
broken on the server; the *request* was invalid.

`BillingError` reuses the same {"error": {...}} envelope as `AuthError`
(auth/exceptions.py already provides a registered handler for any
`AuthError` subclass in api/main.py, keyed on the exception's own
status_code / error_code), so no new handler registration is required —
subclassing `AuthError` here is enough to get the correct 4xx envelope.

Errors that indicate genuine *server* misconfiguration (e.g. "the free
plan hasn't been seeded in the DB yet", "STRIPE_WEBHOOK_SECRET is not
set") are intentionally left as RuntimeError/500 — those are ops
problems, not something the requesting user did wrong.
"""

from __future__ import annotations

from auth.exceptions import AuthError


class BillingError(AuthError):
    """Base class for user-facing billing errors. Default: 400 Bad Request."""
    status_code = 400
    error_code = "billing_error"


class PlanNotFoundError(BillingError):
    """The requested plan tier doesn't exist or isn't purchasable."""
    status_code = 404
    error_code = "plan_not_found"


class NoStripeCustomerError(BillingError):
    """User tried to open the billing portal without ever starting a subscription."""
    status_code = 400
    error_code = "no_stripe_customer"


class NoActiveSubscriptionError(BillingError):
    """User tried to cancel/modify a subscription that doesn't exist."""
    status_code = 404
    error_code = "no_active_subscription"


class UsageLimitExceededError(BillingError):
    """User's plan quota (uploads/analyses/etc.) has been exhausted."""
    status_code = 402  # Payment Required
    error_code = "usage_limit_exceeded"


class BillingRateLimitedError(BillingError):
    """Too many billing actions (e.g. checkout attempts) in a short window."""
    status_code = 429
    error_code = "billing_rate_limited"
