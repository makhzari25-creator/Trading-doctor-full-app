# -*- coding: utf-8 -*-
"""
billing/services/plans.py
-------------------------
Phase 10 — Plan definitions and seeding.

Defines the three subscription plans (Free / Pro / Premium) with their
limits and feature flags. Plans are seeded into the DB at deploy time
via `seed_plans()` — they live in the DB so they can be updated without
redeploying.

The plan tier enum values (free/pro/premium) are STABLE — never change them
once shipped, or existing subscriptions will be orphaned.
"""

from __future__ import annotations

import uuid
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from billing import config as billing_config
from billing.models import Plan, PlanTier
from utils.logger import get_logger

log = get_logger("billing.plans")


# ---------------------------------------------------------------------------
# Plan definitions (canonical source of truth)
# ---------------------------------------------------------------------------

PLAN_DEFINITIONS = [
    {
        "tier": PlanTier.free,
        "name": "رایگان",
        "description": "برای شروع — مناسب برای آشنایی با پلتفرم",
        "price_cents": 0,
        "currency": "usd",
        "interval": "one_time",
        "max_analyses_per_month": 5,
        "max_upload_size_bytes": 5 * 1024 * 1024,  # 5 MB
        "max_total_upload_bytes": 50 * 1024 * 1024,  # 50 MB
        "max_llm_calls_per_month": 0,  # No LLM on free tier
        "allows_pdf_export": True,
        "allows_ai_coaching": False,
        "allows_history_search": False,
        "allows_favorites": True,
        "priority_support": False,
        "stripe_price_id": None,
        "is_public": True,
        "sort_order": 1,
    },
    {
        "tier": PlanTier.pro,
        "name": "حرفه‌ای",
        "description": "برای تریدرهای جدی — تحلیل نامحدود و مربی هوش مصنوعی",
        "price_cents": 1900,  # $19/month
        "currency": "usd",
        "interval": "month",
        "max_analyses_per_month": 100,
        "max_upload_size_bytes": 25 * 1024 * 1024,  # 25 MB
        "max_total_upload_bytes": 1024 * 1024 * 1024,  # 1 GB
        "max_llm_calls_per_month": 50,
        "allows_pdf_export": True,
        "allows_ai_coaching": True,
        "allows_history_search": True,
        "allows_favorites": True,
        "priority_support": False,
        "stripe_price_id": billing_config.STRIPE_PRICE_ID_PRO_MONTHLY or None,
        "is_public": True,
        "sort_order": 2,
    },
    {
        "tier": PlanTier.premium,
        "name": "پرمیوم",
        "description": "برای تریدرهای حرفه‌ای — همه چیز نامحدود + پشتیبانی اولویت‌دار",
        "price_cents": 4900,  # $49/month
        "currency": "usd",
        "interval": "month",
        "max_analyses_per_month": -1,  # unlimited
        "max_upload_size_bytes": 100 * 1024 * 1024,  # 100 MB
        "max_total_upload_bytes": 10 * 1024 * 1024 * 1024,  # 10 GB
        "max_llm_calls_per_month": -1,  # unlimited
        "allows_pdf_export": True,
        "allows_ai_coaching": True,
        "allows_history_search": True,
        "allows_favorites": True,
        "priority_support": True,
        "stripe_price_id": billing_config.STRIPE_PRICE_ID_PREMIUM_MONTHLY or None,
        "is_public": True,
        "sort_order": 3,
    },
]


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------

async def seed_plans(db: AsyncSession) -> int:
    """Idempotently insert the canonical plans into the DB.

    Returns the number of plans inserted (0 if all already existed).

    Safe to call multiple times — existing plans are NOT modified.
    To change a plan's price/limits, update the DB directly or add a new
    migration (never edit the seeded row in place if it has subscriptions).
    """
    inserted = 0
    for plan_def in PLAN_DEFINITIONS:
        # Check if a plan with this tier already exists
        stmt = select(Plan).where(Plan.tier == plan_def["tier"])
        existing = (await db.execute(stmt)).scalar_one_or_none()
        if existing is not None:
            continue

        plan = Plan(
            id=uuid.uuid4(),
            **plan_def,
        )
        db.add(plan)
        inserted += 1
        log.info("Seeded plan: tier=%s name=%s", plan_def["tier"].value, plan_def["name"])

    if inserted > 0:
        await db.flush()
    return inserted


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------

async def get_plan_by_tier(db: AsyncSession, tier: PlanTier) -> Optional[Plan]:
    """Return the Plan row for a tier, or None."""
    stmt = select(Plan).where(Plan.tier == tier)
    return (await db.execute(stmt)).scalar_one_or_none()


async def get_plan_by_id(db: AsyncSession, plan_id: uuid.UUID) -> Optional[Plan]:
    stmt = select(Plan).where(Plan.id == plan_id)
    return (await db.execute(stmt)).scalar_one_or_none()


async def list_public_plans(db: AsyncSession) -> list[Plan]:
    """Return all public plans, sorted by sort_order."""
    stmt = (
        select(Plan)
        .where(Plan.is_public == True)  # noqa: E712
        .order_by(Plan.sort_order.asc())
    )
    return list((await db.execute(stmt)).scalars().all())


# ---------------------------------------------------------------------------
# Plan comparison helpers (used by the frontend pricing page)
# ---------------------------------------------------------------------------

def plan_to_dict(plan: Plan) -> dict:
    """Serialize a Plan to a dict suitable for API responses."""
    return {
        "plan_id": str(plan.id),
        "tier": plan.tier.value,
        "name": plan.name,
        "description": plan.description,
        "price_cents": plan.price_cents,
        "currency": plan.currency,
        "interval": plan.interval,
        "limits": {
            "max_analyses_per_month": plan.max_analyses_per_month,
            "max_upload_size_bytes": plan.max_upload_size_bytes,
            "max_total_upload_bytes": plan.max_total_upload_bytes,
            "max_llm_calls_per_month": plan.max_llm_calls_per_month,
        },
        "features": {
            "allows_pdf_export": plan.allows_pdf_export,
            "allows_ai_coaching": plan.allows_ai_coaching,
            "allows_history_search": plan.allows_history_search,
            "allows_favorites": plan.allows_favorites,
            "priority_support": plan.priority_support,
        },
        "stripe_price_id": plan.stripe_price_id,
        "sort_order": plan.sort_order,
    }
