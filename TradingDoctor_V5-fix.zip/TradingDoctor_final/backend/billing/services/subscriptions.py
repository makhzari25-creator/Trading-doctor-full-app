# -*- coding: utf-8 -*-
"""
billing/services/subscriptions.py
---------------------------------
Phase 10 — Subscription lifecycle service.

Encapsulates all DB operations on the subscriptions table. The Stripe
provider is called for side-effects (create customer, checkout session)
but the subscription row is only created/updated when we receive a
webhook confirming the change.

This avoids race conditions: the local DB always reflects Stripe's view
of the world, never the other way around.

Flow:
  1. User clicks "Upgrade to Pro" → POST /billing/checkout
     → creates Stripe Checkout Session (NO local DB change yet)
  2. User completes payment on Stripe
  3. Stripe sends `checkout.session.completed` webhook
  4. Webhook handler calls `upsert_subscription_from_stripe()`
  5. Local DB now reflects the new subscription

Cancellation flow:
  1. User clicks "Cancel" → POST /billing/cancel
     → calls Stripe to cancel at period end
  2. Stripe sends `customer.subscription.updated` webhook
  3. Webhook handler updates local subscription status + canceled_at
  4. At period end, Stripe sends `customer.subscription.deleted` webhook
  5. Webhook handler sets status=canceled
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from billing import config as billing_config
from billing.exceptions import (
    NoActiveSubscriptionError,
    NoStripeCustomerError,
    PlanNotFoundError,
)
from billing.models import Plan, PlanTier, Subscription, SubscriptionStatus
from billing.services import stripe_provider
from billing.services.plans import get_plan_by_tier
from utils.logger import get_logger

log = get_logger("billing.subscriptions")


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

async def get_user_subscription(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> Optional[Subscription]:
    """Return the user's ACTIVE subscription, or None.

    "Active" includes trialing, active, past_due, unpaid, incomplete —
    anything that isn't canceled. There's at most one per user (enforced
    by partial unique index).
    """
    stmt = select(Subscription).where(
        Subscription.user_id == user_id,
        Subscription.status.in_([
            SubscriptionStatus.trialing,
            SubscriptionStatus.active,
            SubscriptionStatus.past_due,
            SubscriptionStatus.unpaid,
            SubscriptionStatus.incomplete,
        ]),
    )
    return (await db.execute(stmt)).scalar_one_or_none()


async def get_user_plan(db: AsyncSession, user_id: uuid.UUID) -> Optional[Plan]:
    """Return the user's current plan, or None if no subscription.

    If the user has no subscription AND AUTO_ASSIGN_FREE_PLAN is True,
    callers should call `ensure_free_subscription()` first.
    """
    sub = await get_user_subscription(db, user_id)
    if sub is None:
        return None
    return sub.plan


async def get_subscription_by_stripe_id(
    db: AsyncSession,
    stripe_subscription_id: str,
) -> Optional[Subscription]:
    stmt = select(Subscription).where(
        Subscription.stripe_subscription_id == stripe_subscription_id,
    )
    return (await db.execute(stmt)).scalar_one_or_none()


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

async def ensure_free_subscription(
    db: AsyncSession,
    user_id: uuid.UUID,
    user_email: Optional[str] = None,
) -> Subscription:
    """Ensure the user has at least a free plan subscription.

    Called at user registration (when AUTO_ASSIGN_FREE_PLAN=True) and
    as a fallback when a user has no subscription but tries to use the app.

    Idempotent: if the user already has an active subscription, returns it.
    """
    existing = await get_user_subscription(db, user_id)
    if existing is not None:
        return existing

    free_plan = await get_plan_by_tier(db, PlanTier.free)
    if free_plan is None:
        # Plans not seeded yet — fail loudly.
        raise RuntimeError(
            "Free plan not found in DB. Run `seed_plans()` at startup."
        )

    sub = Subscription(
        id=uuid.uuid4(),
        user_id=user_id,
        plan_id=free_plan.id,
        status=SubscriptionStatus.active,
    )
    db.add(sub)
    await db.flush()
    log.info("Created free subscription for user_id=%s", user_id)
    return sub


# ---------------------------------------------------------------------------
# Stripe-side actions (no local DB change until webhook confirms)
# ---------------------------------------------------------------------------

async def create_checkout_session(
    db: AsyncSession,
    user_id: uuid.UUID,
    user_email: str,
    target_tier: PlanTier,
    success_url: str,
    cancel_url: str,
    user_full_name: Optional[str] = None,
) -> dict:
    """Create a Stripe Checkout Session for upgrading to a paid plan.

    Returns {"session_id": "...", "url": "..."}.

    The local DB is NOT modified — wait for the webhook.
    """
    target_plan = await get_plan_by_tier(db, target_tier)
    if target_plan is None:
        raise PlanNotFoundError(f"Plan tier {target_tier!r} not found.")
    if not target_plan.stripe_price_id:
        raise PlanNotFoundError(
            f"Plan tier {target_tier!r} is not currently purchasable."
        )

    # Get or create the Stripe customer for this user.
    sub = await get_user_subscription(db, user_id)
    stripe_customer_id: Optional[str] = None
    if sub is not None:
        stripe_customer_id = sub.stripe_customer_id

    if stripe_customer_id is None:
        # Create a new Stripe customer.
        # Phase 12 audit fix (C8): wrap sync Stripe call in run_in_threadpool
        # to avoid blocking the event loop.
        stripe_customer_id = await run_in_threadpool(
            stripe_provider.create_customer,
            email=user_email,
            name=user_full_name,
            user_id=str(user_id),
        )
        # Stash the customer ID on the existing subscription (if any) so we
        # can reconcile later.
        if sub is not None:
            sub.stripe_customer_id = stripe_customer_id
            await db.flush()

    # Determine trial days.
    trial_days = billing_config.TRIAL_DAYS_DEFAULT if billing_config.TRIAL_DAYS_DEFAULT > 0 else None

    # Create the checkout session.
    # Phase 12 audit fix (C8): wrap sync Stripe call in run_in_threadpool.
    session = await run_in_threadpool(
        stripe_provider.create_checkout_session,
        customer_id=stripe_customer_id,
        price_id=target_plan.stripe_price_id,
        success_url=success_url,
        cancel_url=cancel_url,
        trial_days=trial_days,
        metadata={
            "tradingdoctor_user_id": str(user_id),
            "target_tier": target_tier.value,
        },
    )
    log.info("Created checkout session for user_id=%s tier=%s",
             user_id, target_tier.value)
    return session


async def create_billing_portal_session(
    db: AsyncSession,
    user_id: uuid.UUID,
    return_url: str,
) -> str:
    """Create a Stripe Customer Portal session URL.

    The portal lets users update their payment method, view invoices, etc.
    """
    sub = await get_user_subscription(db, user_id)
    if sub is None or not sub.stripe_customer_id:
        raise NoStripeCustomerError(
            "هنوز هیچ اشتراک پرداختی برای این حساب ثبت نشده است."
        )

    result = await run_in_threadpool(
        stripe_provider.create_billing_portal_session,
        customer_id=sub.stripe_customer_id,
        return_url=return_url,
    )
    return result["url"]


async def cancel_subscription(
    db: AsyncSession,
    user_id: uuid.UUID,
    cancel_at_period_end: bool = True,
    reason: str = "user_request",
) -> Subscription:
    """Cancel the user's subscription via Stripe.

    The local DB is updated by the webhook that Stripe sends after the
    cancellation takes effect. We do NOT update the local status here —
    that's the webhook's job.

    Returns the subscription (with stripe_subscription_id populated so the
    webhook can match it).
    """
    sub = await get_user_subscription(db, user_id)
    if sub is None:
        raise NoActiveSubscriptionError("اشتراک فعالی برای این حساب یافت نشد.")
    if not sub.stripe_subscription_id:
        # Free tier has no Stripe subscription — just mark as canceled locally.
        sub.status = SubscriptionStatus.canceled
        sub.canceled_at = datetime.now(timezone.utc)
        sub.cancel_reason = reason
        await db.flush()
        log.info("Canceled local-only (free) subscription for user_id=%s", user_id)
        return sub

    # Paid subscription — cancel via Stripe. Webhook will update local status.
    # Phase 12 audit fix (C8): wrap sync Stripe call in run_in_threadpool.
    await run_in_threadpool(
        stripe_provider.cancel_subscription,
        sub.stripe_subscription_id,
        cancel_at_period_end=cancel_at_period_end,
    )
    # Optimistic local update — webhook will confirm.
    if not cancel_at_period_end:
        sub.status = SubscriptionStatus.canceled
        sub.canceled_at = datetime.now(timezone.utc)
    sub.cancel_reason = reason
    await db.flush()
    return sub


# ---------------------------------------------------------------------------
# Webhook-driven upsert (the source of truth for local DB state)
# ---------------------------------------------------------------------------

async def upsert_subscription_from_stripe(
    db: AsyncSession,
    stripe_subscription_id: str,
    stripe_customer_id: str,
    status: str,
    current_period_start: Optional[datetime] = None,
    current_period_end: Optional[datetime] = None,
    trial_start: Optional[datetime] = None,
    trial_end: Optional[datetime] = None,
    canceled_at: Optional[datetime] = None,
    price_id: Optional[str] = None,
    user_id: Optional[uuid.UUID] = None,
) -> Subscription:
    """Create or update a subscription based on Stripe webhook data.

    This is called by the webhook handler. It's the ONLY way subscription
    state should change for paid plans.

    Args:
      price_id: used to look up the local Plan row (via plans.stripe_price_id).
      user_id: optional; if provided, used to create a new subscription row
        (for new subscriptions where we don't have a local row yet).
    """
    # Find existing subscription by stripe_subscription_id
    sub = await get_subscription_by_stripe_id(db, stripe_subscription_id)

    # If not found, try by user_id (for new subscriptions)
    if sub is None and user_id is not None:
        sub = await get_user_subscription(db, user_id)

    # Map Stripe status to local enum
    status_map = {
        "trialing": SubscriptionStatus.trialing,
        "active": SubscriptionStatus.active,
        "past_due": SubscriptionStatus.past_due,
        "canceled": SubscriptionStatus.canceled,
        "unpaid": SubscriptionStatus.unpaid,
        "incomplete": SubscriptionStatus.incomplete,
        "incomplete_expired": SubscriptionStatus.canceled,
    }
    local_status = status_map.get(status, SubscriptionStatus.active)

    # Look up the local plan via the Stripe price_id
    plan: Optional[Plan] = None
    if price_id:
        from sqlalchemy import select as sa_select
        stmt = sa_select(Plan).where(Plan.stripe_price_id == price_id)
        plan = (await db.execute(stmt)).scalar_one_or_none()

    if sub is None:
        # New subscription — must have user_id to create
        if user_id is None:
            raise ValueError(
                f"Cannot create new subscription for stripe_sub={stripe_subscription_id} "
                "without user_id."
            )
        if plan is None:
            raise ValueError(
                f"Cannot find local plan with stripe_price_id={price_id!r}. "
                "Is the plan seeded?"
            )
        sub = Subscription(
            id=uuid.uuid4(),
            user_id=user_id,
            plan_id=plan.id,
            status=local_status,
            stripe_customer_id=stripe_customer_id,
            stripe_subscription_id=stripe_subscription_id,
            current_period_start=current_period_start,
            current_period_end=current_period_end,
            trial_start=trial_start,
            trial_end=trial_end,
            canceled_at=canceled_at,
        )
        db.add(sub)
        log.info(
            "Created subscription from webhook: user=%s tier=%s status=%s",
            user_id, plan.tier.value, local_status.value,
        )
    else:
        # Update existing
        sub.status = local_status
        sub.stripe_customer_id = stripe_customer_id
        sub.stripe_subscription_id = stripe_subscription_id
        if current_period_start is not None:
            sub.current_period_start = current_period_start
        if current_period_end is not None:
            sub.current_period_end = current_period_end
        if trial_start is not None:
            sub.trial_start = trial_start
        if trial_end is not None:
            sub.trial_end = trial_end
        if canceled_at is not None:
            sub.canceled_at = canceled_at
        if plan is not None:
            sub.plan_id = plan.id
        log.info(
            "Updated subscription from webhook: stripe_sub=%s status=%s",
            stripe_subscription_id, local_status.value,
        )

    await db.flush()
    return sub


async def upsert_invoice_from_stripe(
    db: AsyncSession,
    stripe_invoice_id: str,
    stripe_customer_id: Optional[str] = None,
    stripe_subscription_id: Optional[str] = None,
    status: str = "draft",
    amount_due_cents: int = 0,
    amount_paid_cents: int = 0,
    currency: str = "usd",
    period_start: Optional[datetime] = None,
    period_end: Optional[datetime] = None,
    paid_at: Optional[datetime] = None,
    invoice_pdf_url: Optional[str] = None,
    hosted_invoice_url: Optional[str] = None,
    description: Optional[str] = None,
    user_id: Optional[uuid.UUID] = None,
) -> "Invoice":  # noqa: F821 — forward ref
    """Create or update an invoice based on Stripe webhook data."""
    from billing.models import Invoice, InvoiceStatus

    # Look up existing
    from sqlalchemy import select as sa_select
    stmt = sa_select(Invoice).where(Invoice.stripe_invoice_id == stripe_invoice_id)
    inv = (await db.execute(stmt)).scalar_one_or_none()

    status_map = {
        "draft": InvoiceStatus.draft,
        "open": InvoiceStatus.open,
        "paid": InvoiceStatus.paid,
        "void": InvoiceStatus.void,
        "uncollectible": InvoiceStatus.uncollectible,
    }
    local_status = status_map.get(status, InvoiceStatus.draft)

    # Look up subscription by stripe_subscription_id (if provided)
    local_sub_id: Optional[uuid.UUID] = None
    if stripe_subscription_id:
        sub = await get_subscription_by_stripe_id(db, stripe_subscription_id)
        if sub is not None:
            local_sub_id = sub.id
            if user_id is None:
                user_id = sub.user_id

    if inv is None:
        if user_id is None:
            raise ValueError(
                f"Cannot create invoice {stripe_invoice_id} without user_id."
            )
        inv = Invoice(
            id=uuid.uuid4(),
            user_id=user_id,
            subscription_id=local_sub_id,
            stripe_invoice_id=stripe_invoice_id,
            status=local_status,
            amount_due_cents=amount_due_cents,
            amount_paid_cents=amount_paid_cents,
            currency=currency,
            period_start=period_start,
            period_end=period_end,
            paid_at=paid_at,
            invoice_pdf_url=invoice_pdf_url,
            hosted_invoice_url=hosted_invoice_url,
            description=description,
        )
        db.add(inv)
        log.info("Created invoice from webhook: stripe_inv=%s user=%s amount=%dc",
                 stripe_invoice_id, user_id, amount_due_cents)
    else:
        inv.status = local_status
        inv.amount_due_cents = amount_due_cents
        inv.amount_paid_cents = amount_paid_cents
        if period_start is not None:
            inv.period_start = period_start
        if period_end is not None:
            inv.period_end = period_end
        if paid_at is not None:
            inv.paid_at = paid_at
        if invoice_pdf_url is not None:
            inv.invoice_pdf_url = invoice_pdf_url
        if hosted_invoice_url is not None:
            inv.hosted_invoice_url = hosted_invoice_url
        if description is not None:
            inv.description = description
        log.info("Updated invoice from webhook: stripe_inv=%s status=%s",
                 stripe_invoice_id, local_status.value)

    await db.flush()
    return inv
