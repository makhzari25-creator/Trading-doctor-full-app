# -*- coding: utf-8 -*-
"""
billing/services/usage.py
-------------------------
Phase 10 — Usage tracking service.

Records metered usage events (analysis runs, upload bytes, LLM calls) in an
append-only log. Provides queries for current-month totals + tier-limit
enforcement.

Usage is computed by aggregating the events table — never stored as a
running counter. This ensures:
  - We can recompute usage if limits change
  - We have an audit trail of every usage event
  - We can build detailed usage reports per period
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from billing.models import Plan, UsageEvent, UsageEventType
from utils.logger import get_logger

log = get_logger("billing.usage")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _current_billing_period() -> str:
    """Return the current billing period as 'YYYY-MM' (UTC)."""
    return datetime.now(timezone.utc).strftime("%Y-%m")


def _ensure_aware(dt: datetime) -> datetime:
    """Force a datetime to be timezone-aware (assume UTC if naive)."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


# ---------------------------------------------------------------------------
# Record events (append-only)
# ---------------------------------------------------------------------------

async def record_analysis_run(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    llm_provider: str = "none",
) -> UsageEvent:
    """Record one analysis_run event + (if LLM was used) one llm_call event.

    Called by the analyses router after a successful analysis.
    """
    events: list[UsageEvent] = []
    period = _current_billing_period()

    analysis_event = UsageEvent(
        id=uuid.uuid4(),
        user_id=user_id,
        event_type=UsageEventType.analysis_run,
        quantity=1,
        resource_id=str(analysis_id),
        details=json.dumps({"llm_provider": llm_provider}),
        billing_period=period,
    )
    db.add(analysis_event)
    events.append(analysis_event)

    if llm_provider != "none":
        llm_event = UsageEvent(
            id=uuid.uuid4(),
            user_id=user_id,
            event_type=UsageEventType.llm_call,
            quantity=1,
            resource_id=str(analysis_id),
            details=json.dumps({"provider": llm_provider}),
            billing_period=period,
        )
        db.add(llm_event)
        events.append(llm_event)

    await db.flush()
    return analysis_event


async def record_upload_bytes(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    size_bytes: int,
) -> UsageEvent:
    """Record an upload_bytes event (for storage quota tracking)."""
    period = _current_billing_period()
    event = UsageEvent(
        id=uuid.uuid4(),
        user_id=user_id,
        event_type=UsageEventType.upload_bytes,
        quantity=size_bytes,
        resource_id=str(upload_id),
        billing_period=period,
    )
    db.add(event)
    await db.flush()
    return event


async def record_report_download(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    format: str,
) -> UsageEvent:
    """Record a report_download event (for tracking engagement)."""
    period = _current_billing_period()
    event = UsageEvent(
        id=uuid.uuid4(),
        user_id=user_id,
        event_type=UsageEventType.report_download,
        quantity=1,
        resource_id=str(analysis_id),
        details=json.dumps({"format": format}),
        billing_period=period,
    )
    db.add(event)
    await db.flush()
    return event


# ---------------------------------------------------------------------------
# Aggregation queries
# ---------------------------------------------------------------------------

async def get_monthly_usage(
    db: AsyncSession,
    user_id: uuid.UUID,
    event_type: UsageEventType,
    period: Optional[str] = None,
) -> int:
    """Return total usage of `event_type` for the user in the given period.

    Defaults to current period.
    """
    period = period or _current_billing_period()
    stmt = select(func.coalesce(func.sum(UsageEvent.quantity), 0)).where(
        UsageEvent.user_id == user_id,
        UsageEvent.event_type == event_type,
        UsageEvent.billing_period == period,
    )
    return int((await db.execute(stmt)).scalar_one())


async def get_user_usage_summary(
    db: AsyncSession,
    user_id: uuid.UUID,
    period: Optional[str] = None,
) -> dict:
    """Return a usage summary for the user in the given period.

    Returns dict with:
      - billing_period: "YYYY-MM"
      - analyses_run: int
      - llm_calls: int
      - upload_bytes: int
      - report_downloads: int
    """
    period = period or _current_billing_period()

    stmt = (
        select(UsageEvent.event_type, func.coalesce(func.sum(UsageEvent.quantity), 0))
        .where(
            UsageEvent.user_id == user_id,
            UsageEvent.billing_period == period,
        )
        .group_by(UsageEvent.event_type)
    )
    rows = (await db.execute(stmt)).all()
    usage_map = {row[0]: int(row[1]) for row in rows}

    return {
        "billing_period": period,
        "analyses_run": usage_map.get(UsageEventType.analysis_run, 0),
        "llm_calls": usage_map.get(UsageEventType.llm_call, 0),
        "upload_bytes": usage_map.get(UsageEventType.upload_bytes, 0),
        "report_downloads": usage_map.get(UsageEventType.report_download, 0),
    }


# ---------------------------------------------------------------------------
# Tier enforcement
# ---------------------------------------------------------------------------

async def check_analysis_allowed(
    db: AsyncSession,
    user_id: uuid.UUID,
    plan: Plan,
) -> tuple[bool, str | None, int, int]:
    """Check if the user can run a new analysis under their plan.

    Returns (is_allowed, error_message, current_count, max_count).
    max_count = -1 means unlimited.
    """
    if plan.max_analyses_per_month == -1:
        return True, None, await get_monthly_usage(
            db, user_id, UsageEventType.analysis_run,
        ), -1

    current = await get_monthly_usage(db, user_id, UsageEventType.analysis_run)
    if current >= plan.max_analyses_per_month:
        return False, (
            f"محدودیت ماهانه‌ی تحلیل ({plan.max_analyses_per_month}) تکمیل شده است. "
            "برای ارتقای طرح، به تنظیمات اشتراک مراجعه کنید."
        ), current, plan.max_analyses_per_month
    return True, None, current, plan.max_analyses_per_month


async def check_upload_allowed(
    db: AsyncSession,
    user_id: uuid.UUID,
    plan: Plan,
    upload_size_bytes: int,
) -> tuple[bool, str | None]:
    """Check if an upload of `upload_size_bytes` is allowed under the plan.

    Checks both per-file size limit AND monthly total storage limit.
    """
    # Per-file size limit
    if plan.max_upload_size_bytes != -1 and upload_size_bytes > plan.max_upload_size_bytes:
        return False, (
            f"حجم فایل ({upload_size_bytes / (1024*1024):.1f}MB) از حد مجاز طرح "
            f"({plan.max_upload_size_bytes / (1024*1024):.1f}MB) بیشتر است."
        )

    # Monthly total storage limit
    if plan.max_total_upload_bytes != -1:
        current_bytes = await get_monthly_usage(
            db, user_id, UsageEventType.upload_bytes,
        )
        if current_bytes + upload_size_bytes > plan.max_total_upload_bytes:
            remaining = max(0, plan.max_total_upload_bytes - current_bytes)
            return False, (
                f"ظرفیت ذخیره‌سازی ماهانه پر است. "
                f"باقی‌مانده: {remaining / (1024*1024):.1f}MB از "
                f"{plan.max_total_upload_bytes / (1024*1024):.1f}MB."
            )

    return True, None


async def check_llm_call_allowed(
    db: AsyncSession,
    user_id: uuid.UUID,
    plan: Plan,
) -> tuple[bool, str | None]:
    """Check if the user can make a new LLM call under their plan."""
    if not plan.allows_ai_coaching:
        return False, "طرح شما از مربی هوش مصنوعی پشتیبانی نمی‌کند."
    if plan.max_llm_calls_per_month == -1:
        return True, None
    current = await get_monthly_usage(db, user_id, UsageEventType.llm_call)
    if current >= plan.max_llm_calls_per_month:
        return False, (
            f"محدودیت ماهانه‌ی مربی هوش مصنوعی ({plan.max_llm_calls_per_month}) تکمیل شده است."
        )
    return True, None


# ---------------------------------------------------------------------------
# Feature flag checks
# ---------------------------------------------------------------------------

def plan_allows_feature(plan: Plan, feature: str) -> bool:
    """Check if a plan allows a specific feature flag.

    Args:
      feature: "pdf_export" | "ai_coaching" | "history_search" | "favorites" | "priority_support"
    """
    flag_map = {
        "pdf_export": plan.allows_pdf_export,
        "ai_coaching": plan.allows_ai_coaching,
        "history_search": plan.allows_history_search,
        "favorites": plan.allows_favorites,
        "priority_support": plan.priority_support,
    }
    return flag_map.get(feature, False)
