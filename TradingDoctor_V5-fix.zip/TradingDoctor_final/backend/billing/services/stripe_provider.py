# -*- coding: utf-8 -*-
"""
billing/services/stripe_provider.py
-----------------------------------
Phase 10 — Stripe payment provider adapter.

Wraps the Stripe SDK behind a stable interface so we can swap providers
(Paddle, LemonSqueezy) in the future without touching the rest of the codebase.

All Stripe API calls go through this module. The rest of the billing layer
never imports stripe directly.

Stripe SDK is required only when Stripe is the active provider. If `stripe`
isn't installed, the provider raises a clear error message.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from billing import config as billing_config
from utils.logger import get_logger

log = get_logger("billing.stripe")


# ---------------------------------------------------------------------------
# Lazy SDK loading
# ---------------------------------------------------------------------------

_stripe_sdk = None


def _get_stripe():
    """Lazily import the stripe SDK. Cached after first call."""
    global _stripe_sdk
    if _stripe_sdk is not None:
        return _stripe_sdk
    try:
        import stripe
    except ImportError as exc:
        raise RuntimeError(
            "Stripe SDK is not installed. Install with: pip install stripe"
        ) from exc

    # Configure with secret key.
    if not billing_config.STRIPE_SECRET_KEY:
        raise RuntimeError(
            "STRIPE_SECRET_KEY is not set. Cannot make Stripe API calls."
        )

    stripe.api_key = billing_config.STRIPE_SECRET_KEY
    # Optional: pin API version for stability.
    # stripe.api_version = "2024-06-20"

    _stripe_sdk = stripe
    log.info("Stripe SDK initialized (mode=%s)", billing_config.STRIPE_MODE)
    return _stripe_sdk


# ---------------------------------------------------------------------------
# Customer management
# ---------------------------------------------------------------------------

def create_customer(email: str, name: Optional[str] = None, user_id: Optional[str] = None) -> str:
    """Create a Stripe customer. Returns the customer ID."""
    stripe = _get_stripe()
    customer = stripe.Customer.create(
        email=email,
        name=name or email,
        metadata={"tradingdoctor_user_id": user_id} if user_id else {},
    )
    log.info("Created Stripe customer id=%s email=%s", customer.id, email)
    return customer.id


def get_customer(customer_id: str) -> Optional[dict]:
    """Fetch a customer by ID. Returns None if not found."""
    stripe = _get_stripe()
    try:
        customer = stripe.Customer.retrieve(customer_id)
        return _customer_to_dict(customer)
    except stripe.error.InvalidRequestError as exc:
        if "No such customer" in str(exc):
            return None
        raise


# ---------------------------------------------------------------------------
# Checkout sessions (for subscription sign-up)
# ---------------------------------------------------------------------------

def create_checkout_session(
    customer_id: str,
    price_id: str,
    success_url: str,
    cancel_url: str,
    trial_days: Optional[int] = None,
    metadata: Optional[dict] = None,
) -> dict:
    """Create a Stripe Checkout Session for subscribing to a price.

    Returns a dict with `session_id` and `url`.
    """
    stripe = _get_stripe()
    params: dict[str, Any] = {
        "customer": customer_id,
        "payment_method_types": ["card"],
        "line_items": [{"price": price_id, "quantity": 1}],
        "mode": "subscription",
        "success_url": success_url,
        "cancel_url": cancel_url,
        "metadata": metadata or {},
    }
    if trial_days and trial_days > 0:
        params["subscription_data"] = {"trial_period_days": trial_days}

    session = stripe.checkout.Session.create(**params)
    log.info("Created checkout session id=%s customer=%s", session.id, customer_id)
    return {"session_id": session.id, "url": session.url}


# ---------------------------------------------------------------------------
# Billing portal (for self-service subscription management)
# ---------------------------------------------------------------------------

def create_billing_portal_session(
    customer_id: str,
    return_url: str,
) -> dict:
    """Create a Stripe Customer Portal session. Returns dict with `url`."""
    stripe = _get_stripe()
    session = stripe.billing_portal.Session.create(
        customer=customer_id,
        return_url=return_url,
    )
    log.info("Created billing portal session for customer=%s", customer_id)
    return {"url": session.url}


# ---------------------------------------------------------------------------
# Subscription retrieval
# ---------------------------------------------------------------------------

def retrieve_subscription(subscription_id: str) -> Optional[dict]:
    """Fetch a subscription by ID. Returns None if not found."""
    stripe = _get_stripe()
    try:
        sub = stripe.Subscription.retrieve(subscription_id)
        return _subscription_to_dict(sub)
    except stripe.error.InvalidRequestError as exc:
        if "No such subscription" in str(exc):
            return None
        raise


def cancel_subscription(subscription_id: str, cancel_at_period_end: bool = True) -> dict:
    """Cancel a subscription. By default cancels at period end (prorated).

    Set cancel_at_period_end=False to cancel immediately.
    """
    stripe = _get_stripe()
    if cancel_at_period_end:
        sub = stripe.Subscription.modify(
            subscription_id,
            cancel_at_period_end=True,
        )
    else:
        sub = stripe.Subscription.cancel(subscription_id)
    log.info("Canceled subscription id=%s at_period_end=%s",
             subscription_id, cancel_at_period_end)
    return _subscription_to_dict(sub)


# ---------------------------------------------------------------------------
# Invoice retrieval
# ---------------------------------------------------------------------------

def retrieve_invoice(invoice_id: str) -> Optional[dict]:
    """Fetch an invoice by ID. Returns None if not found."""
    stripe = _get_stripe()
    try:
        inv = stripe.Invoice.retrieve(invoice_id)
        return _invoice_to_dict(inv)
    except stripe.error.InvalidRequestError as exc:
        if "No such invoice" in str(exc):
            return None
        raise


# ---------------------------------------------------------------------------
# Webhook signature verification
# ---------------------------------------------------------------------------

def verify_webhook_signature(payload: bytes, signature: str, timestamp_header: str) -> Any:
    """Verify the signature of an incoming Stripe webhook.

    Returns the parsed Event object on success. Raises
    stripe.error.SignatureVerificationError on failure.
    """
    stripe = _get_stripe()
    if not billing_config.STRIPE_WEBHOOK_SECRET:
        raise RuntimeError(
            "STRIPE_WEBHOOK_SECRET is not set. Cannot verify webhook signatures."
        )

    event = stripe.Webhook.construct_event(
        payload,
        f"t={timestamp_header},v1={signature}",
        billing_config.STRIPE_WEBHOOK_SECRET,
        tolerance=billing_config.WEBHOOK_TOLERANCE_SECONDS,
    )
    return event


# ---------------------------------------------------------------------------
# Conversion helpers (Stripe SDK objects → plain dicts)
# ---------------------------------------------------------------------------

def _customer_to_dict(c: Any) -> dict:
    return {
        "stripe_customer_id": c.id,
        "email": c.email,
        "name": c.name,
        "created": datetime.fromtimestamp(c.created) if c.created else None,
    }


def _subscription_to_dict(s: Any) -> dict:
    return {
        "stripe_subscription_id": s.id,
        "stripe_customer_id": s.customer,
        "status": s.status,
        "current_period_start": datetime.fromtimestamp(s.current_period_start)
            if s.current_period_start else None,
        "current_period_end": datetime.fromtimestamp(s.current_period_end)
            if s.current_period_end else None,
        "trial_start": datetime.fromtimestamp(s.trial_start) if s.trial_start else None,
        "trial_end": datetime.fromtimestamp(s.trial_end) if s.trial_end else None,
        "canceled_at": datetime.fromtimestamp(s.canceled_at) if s.canceled_at else None,
        "items": [
            {"price_id": item.price.id, "quantity": item.quantity}
            for item in s.items.data
        ] if s.items else [],
    }


def _invoice_to_dict(i: Any) -> dict:
    return {
        "stripe_invoice_id": i.id,
        "stripe_customer_id": i.customer,
        "stripe_subscription_id": i.subscription,
        "status": i.status,
        "amount_due_cents": i.amount_due,
        "amount_paid_cents": i.amount_paid,
        "currency": i.currency,
        "period_start": datetime.fromtimestamp(i.period_start) if i.period_start else None,
        "period_end": datetime.fromtimestamp(i.period_end) if i.period_end else None,
        "paid_at": datetime.fromtimestamp(i.status_transitions.paid_at)
            if i.status_transitions and i.status_transitions.paid_at else None,
        "invoice_pdf_url": i.invoice_pdf,
        "hosted_invoice_url": i.hosted_invoice_url,
        "description": i.description,
    }
