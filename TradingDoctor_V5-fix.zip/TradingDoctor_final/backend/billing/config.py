# -*- coding: utf-8 -*-
"""
billing/config.py
-----------------
Phase 10 — Configuration for the billing subsystem.

All values are env-overridable. Stripe keys MUST be set in production.
"""

from __future__ import annotations

import os
from typing import Optional

from utils.logger import get_logger

log = get_logger("billing.config")


def _safe_int(env_var: str, default: int) -> int:
    raw = os.getenv(env_var)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        log.warning("Invalid int for %s=%r, falling back to %s", env_var, raw, default)
        return default


def _safe_bool(env_var: str, default: bool) -> bool:
    raw = os.getenv(env_var, "").strip().lower()
    if raw in ("true", "1", "yes"):
        return True
    if raw in ("false", "0", "no"):
        return False
    return default


# ---------------------------------------------------------------------------
# Stripe configuration
# ---------------------------------------------------------------------------

STRIPE_SECRET_KEY: str = os.getenv("STRIPE_SECRET_KEY", "")
"""Stripe API secret key. Required when Stripe is the active provider."""

STRIPE_PUBLISHABLE_KEY: str = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
"""Stripe publishable key (for frontend)."""

STRIPE_WEBHOOK_SECRET: str = os.getenv("STRIPE_WEBHOOK_SECRET", "")
"""Stripe webhook signing secret. Required to verify webhook signatures."""

STRIPE_MODE: str = os.getenv("STRIPE_MODE", "test").strip().lower()
"""'test' (default) or 'live'. Controls which Stripe API base is used."""

STRIPE_CURRENCY: str = os.getenv("STRIPE_CURRENCY", "usd").strip().lower()
"""Currency code (ISO 4217, lowercase)."""

# ---------------------------------------------------------------------------
# Stripe price IDs (one per plan tier + interval)
# ---------------------------------------------------------------------------

STRIPE_PRICE_ID_PRO_MONTHLY: str = os.getenv("STRIPE_PRICE_ID_PRO_MONTHLY", "")
STRIPE_PRICE_ID_PRO_YEARLY: str = os.getenv("STRIPE_PRICE_ID_PRO_YEARLY", "")
STRIPE_PRICE_ID_PREMIUM_MONTHLY: str = os.getenv("STRIPE_PRICE_ID_PREMIUM_MONTHLY", "")
STRIPE_PRICE_ID_PREMIUM_YEARLY: str = os.getenv("STRIPE_PRICE_ID_PREMIUM_YEARLY", "")

# ---------------------------------------------------------------------------
# Trial configuration
# ---------------------------------------------------------------------------

TRIAL_DAYS_DEFAULT: int = _safe_int("TRADING_DOCTOR_TRIAL_DAYS_DEFAULT", 14)
"""Default trial period in days for paid plans. 0 = no trial."""

# ---------------------------------------------------------------------------
# Webhook tolerance
# ---------------------------------------------------------------------------

WEBHOOK_TOLERANCE_SECONDS: int = _safe_int("STRIPE_WEBHOOK_TOLERANCE", 300)
"""Reject webhooks with timestamps older than this (Stripe default: 5 min)."""

# ---------------------------------------------------------------------------
# Auto-assign free plan on registration
# ---------------------------------------------------------------------------

AUTO_ASSIGN_FREE_PLAN: bool = _safe_bool("TRADING_DOCTOR_AUTO_ASSIGN_FREE", True)
"""If True, new users get a free plan subscription automatically on registration."""

# ---------------------------------------------------------------------------
# Provider selection
# ---------------------------------------------------------------------------

PAYMENT_PROVIDER: str = os.getenv("PAYMENT_PROVIDER", "stripe").strip().lower()
"""Active payment provider. Currently only 'stripe' is supported.
Future: 'paddle', 'lemonsqueezy'."""


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_billing_config() -> list[str]:
    """Return a list of config problems. Empty = OK."""
    problems: list[str] = []

    if PAYMENT_PROVIDER == "stripe":
        if not STRIPE_SECRET_KEY:
            problems.append(
                "STRIPE_SECRET_KEY is not set. Paid subscriptions will fail."
            )
        if not STRIPE_WEBHOOK_SECRET:
            problems.append(
                "STRIPE_WEBHOOK_SECRET is not set. Webhook signature verification "
                "will fail — webhooks will be rejected."
            )
        if STRIPE_MODE not in ("test", "live"):
            problems.append(
                f"STRIPE_MODE={STRIPE_MODE!r} is not 'test' or 'live'."
            )
        if STRIPE_MODE == "live" and not STRIPE_SECRET_KEY.startswith("sk_live_"):
            problems.append(
                "STRIPE_MODE=live but STRIPE_SECRET_KEY does not start with 'sk_live_'. "
                "Are you using test keys in production?"
            )

    return problems
