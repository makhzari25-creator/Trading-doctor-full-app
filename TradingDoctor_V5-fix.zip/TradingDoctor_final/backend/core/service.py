# -*- coding: utf-8 -*-
"""
core/service.py
------------------
لایه‌ی مرکزی سرویس: فایل/DataFrame خام → اعتبارسنجی → خط لوله‌ی کامل
تحلیل (Behavior → Score → Coaching). استفاده‌شده توسط CLI (main.py) و
Streamlit (app.py)، و نقطه‌ی طبیعی برای هر لایه‌ی API آینده (Step 10).

[AUDIT FIX] این ماژول قبلاً هیچ اعتبارسنجی یا لاگی نداشت — یک فایل خالی،
فایل بدون ستون قابل‌شناسایی، یا خطای غیرمنتظره در هر Engine مستقیماً به‌صورت
traceback خام تا CLI/Streamlit بالا می‌رفت. حالا:
  - قبل از تحلیل، utils.validation.validate_and_normalize اجرا می‌شود.
  - نتیجه‌ی هر مرحله لاگ می‌شود (Step 6: analysis start/finish، خطاها).
  - هشدارهای کیفیت داده (غیرفاجعه‌بار) روی خود `doctor` (به‌عنوان
    `doctor.data_quality_warnings`) قرار می‌گیرند تا UI بتواند در صورت
    تمایل نمایششان دهد — بدون تغییر امضای تابع (سازگار با کد قبلی که
    خروجی را (doctor, result, coach) باز می‌کند).
"""

import time

import pandas as pd

from engines.behavior_engine import BehaviorEngine
from engines.score_engine import ScoreEngine
from engines.coaching_engine import CoachingEngine
from utils.file_loader import load_any_file
from utils.validation import validate_and_normalize, DataValidationError
from utils.logger import get_logger

log = get_logger(__name__)


def analyze_dataframe(df: pd.DataFrame, llm_provider: str = "gemini"):
    """
    تابع مرکزی تحلیل — استفاده شده توسط CLI و Streamlit.

    raises DataValidationError: اگر داده‌ی ورودی فاجعه‌بار باشد (خالی،
    بدون ستون مالی/زمانی قابل‌شناسایی، و...).
    """
    start = time.monotonic()
    log.info("analyze_dataframe() started (%d rows, %d cols)",
              len(df) if df is not None else 0,
              df.shape[1] if df is not None else 0)

    normalized_df, warnings = validate_and_normalize(df)

    # BehaviorEngine خودش دوباره ColumnMapper.normalize را صدا می‌زند؛
    # این عملیات idempotent است (نتیجه‌ی یکسان روی داده‌ی از قبل نرمال)،
    # پس هیچ رفتاری تغییر نمی‌کند — فقط اعتبارسنجی زودتر انجام شده است.
    doctor = BehaviorEngine(normalized_df)
    doctor.data_quality_warnings = warnings

    result = ScoreEngine(doctor).run()
    coach = CoachingEngine(doctor, llm_provider=llm_provider).generate(result)

    elapsed = round(time.monotonic() - start, 3)
    log.info(
        "analyze_dataframe() finished in %.3fs (%d trades, %d data-quality warning(s))",
        elapsed, len(doctor.df), len(warnings),
    )
    return doctor, result, coach


def analyze_file(file, filename: str = None, llm_provider: str = "gemini"):
    """
    نسخه‌ی سطح‌بالاتر: هر فایلی (csv/xlsx/xls/htm/html/log/json/txt) را
    می‌گیرد — چه مسیر روی دیسک (CLI) چه یک file-like object (آپلود
    Streamlit) — با utils.file_loader می‌خواند و مستقیماً تحلیل می‌کند.

    این تابع دقیقاً همان analyze_dataframe را صدا می‌زند، فقط لایه‌ی
    بارگذاری فایل را جلوی آن اضافه می‌کند، تا نیازی به تبدیل دستی هر
    بروکر به CSV نباشد.

    raises utils.file_loader.UnsupportedFileError: فرمت فایل قابل‌خواندن نیست.
    raises utils.validation.DataValidationError: محتوای فایل فاجعه‌بار است.
    """
    display_name = filename or getattr(file, "name", str(file))
    log.info("analyze_file() started for '%s'", display_name)
    try:
        df = load_any_file(file, filename=filename)
    except DataValidationError:
        raise
    except Exception as e:
        log.error("Failed to load file '%s': %s", display_name, e, exc_info=True)
        raise

    return analyze_dataframe(df, llm_provider=llm_provider)
