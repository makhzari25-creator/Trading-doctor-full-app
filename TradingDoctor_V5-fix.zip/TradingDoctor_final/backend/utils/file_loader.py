# -*- coding: utf-8 -*-
"""
utils/file_loader.py
-----------------------
بارگذاری «هر فرمتی» از خروجی بروکر/صرافی و تبدیل آن به یک pandas.DataFrame
خام (بدون نرمال‌سازی ستون — آن کار برعهده‌ی ColumnMapper است).

فرمت‌های پشتیبانی‌شده:
  - .csv / .txt / .tsv   : با تشخیص خودکار جداکننده و انکودینگ
  - .xlsx / .xls         : با انتخاب خودکار بهترین شیت (اگر چند شیت باشد)
  - .htm / .html         : گزارش‌های HTML بروکر (مثل Statement.htm در MT4/5)
  - .log                 : در عمل دو نوع رایج دارد:
        1) HTML با پسوند تغییرکرده (خیلی از بروکرها همین‌طورند) → همان
           مسیر htm/html استفاده می‌شود.
        2) لاگ متنی خط‌به‌خط (مثل log ترمینال MT4) → با regex بر مبنای
           الگوی معمول ستون‌های تاریخ/نماد/حجم/سود پارس می‌شود.
  - .json                : با pandas.json_normalize

خروجی همیشه یک DataFrame «خام» است — نگاشت ستون‌ها (Open Time/Profit/Size)
همچنان توسط ColumnMapper.normalize() در BehaviorEngine انجام می‌شود، پس
این لایه هیچ فرضی درباره‌ی نام دقیق ستون‌ها نمی‌گذارد.
"""

import io
import json
import re
from pathlib import Path
from typing import Union

import pandas as pd

from utils.logger import get_logger

log = get_logger(__name__)


class UnsupportedFileError(Exception):
    """وقتی هیچ‌کدام از استراتژی‌های بارگذاری جواب نداد."""


# ------------------------------------------------------------------
# ابزارهای کمکی
# ------------------------------------------------------------------

def _sniff_encoding_and_read_csv(raw: bytes) -> pd.DataFrame:
    """تلاش با چند انکودینگ رایج و چند جداکننده‌ی محتمل.

    [AUDIT FIX - real bug] ترتیب قبلی جداکننده‌ها با `None` (تشخیص خودکار
    pandas/csv.Sniffer) شروع می‌شد. روی فایل‌هایی که واقعاً فقط یک ستون
    دارند (یا جداکننده‌ی واقعی‌شان نادر است)، csv.Sniffer گاهی به‌اشتباه
    یک کاراکتر تصادفیِ داخل خودِ متن (مثلاً حرف "n" در کلمه‌ی "OnlyOne")
    را به‌عنوان جداکننده حدس می‌زد و داده را به ستون‌های بی‌معنی می‌شکست —
    و چون شرط پذیرش فقط «حداقل ۲ ستون» بود، این حدسِ غلط بی‌هیچ هشداری
    پذیرفته می‌شد، حتی اگر جداکننده‌ی درست و رایج (کاما) نتیجه‌ی درستی
    می‌داد. حالا ابتدا جداکننده‌های صریح و رایج (کاما، سمی‌کالن، تب،
    پایپ) امتحان می‌شوند و auto-sniff فقط آخرین راه‌حل (fallback) است.
    """
    if raw is None or len(raw.strip()) == 0:
        raise UnsupportedFileError(
            "فایل آپلودشده خالی است. لطفاً یک فایل معتبر با حداقل یک ردیف معامله آپلود کنید."
        )

    encodings = ["utf-8-sig", "utf-8", "cp1256", "latin-1"]
    separators = [",", ";", "\t", "|", None]  # None (auto-sniff) آخرین fallback

    last_err = None
    for enc in encodings:
        try:
            text = raw.decode(enc)
        except (UnicodeDecodeError, LookupError) as e:
            last_err = e
            continue
        for sep in separators:
            try:
                df = pd.read_csv(
                    io.StringIO(text),
                    sep=sep,
                    engine="python",
                    on_bad_lines="skip",
                )
                if df.shape[1] >= 2 and len(df) > 0:
                    log.info(
                        "CSV parsed successfully (encoding=%s, separator=%r, rows=%d, cols=%d)",
                        enc, sep, len(df), df.shape[1],
                    )
                    return df
            except Exception as e:
                last_err = e
                continue

    log.warning("Could not parse CSV/TXT with any known encoding/separator: %s", last_err)
    raise UnsupportedFileError(f"نتوانستم CSV/TXT را بخوانم: {last_err}")


def _read_excel_best_sheet(raw: bytes) -> pd.DataFrame:
    """اگر چند شیت وجود داشته باشد، شیتی که بیشترین ردیف را دارد انتخاب می‌شود
    (معمولاً شیت اصلی معاملات، نه شیت خلاصه/سامری)."""
    if raw is None or len(raw) == 0:
        raise UnsupportedFileError("فایل اکسل آپلودشده خالی است.")
    try:
        xls = pd.ExcelFile(io.BytesIO(raw))
    except Exception as e:
        raise UnsupportedFileError(f"فایل اکسل خراب یا نامعتبر است: {e}") from e
    best_df, best_len = None, -1
    for sheet in xls.sheet_names:
        try:
            df = xls.parse(sheet)
        except Exception:
            continue
        if len(df) > best_len and df.shape[1] >= 2:
            best_df, best_len = df, len(df)
    if best_df is None:
        raise UnsupportedFileError("هیچ شیت قابل‌استفاده‌ای در فایل اکسل پیدا نشد.")
    log.info("Excel sheet selected (rows=%d, cols=%d)", best_len, best_df.shape[1])
    return best_df


def _read_html_best_table(raw: bytes) -> pd.DataFrame:
    """گزارش‌های HTML بروکر (Statement.htm) را می‌خواند و بزرگ‌ترین جدول
    (که معمولاً جدول تاریخچه‌ی معاملات است) را انتخاب می‌کند."""
    if raw is None or len(raw) == 0:
        raise UnsupportedFileError("فایل HTML آپلودشده خالی است.")
    text = raw.decode("utf-8", errors="ignore")
    try:
        tables = pd.read_html(io.StringIO(text))
    except Exception as e:
        raise UnsupportedFileError(f"نتوانستم جدولی در فایل HTML پیدا کنم: {e}") from e
    if not tables:
        raise UnsupportedFileError("هیچ جدولی در فایل HTML پیدا نشد.")
    best = max(tables, key=lambda t: t.shape[0] * t.shape[1])
    log.info("HTML table selected (rows=%d, cols=%d) out of %d tables found", len(best), best.shape[1], len(tables))
    return best


# الگوی رایج خط لاگ MT4 (مثال): می‌تواند بسته به بروکر کمی فرق کند —
# اینجا مقاوم‌ترین حالت (فیلدهای جداشده با فاصله/تب چندگانه) گرفته می‌شود.
_MT_LOG_LINE_RE = re.compile(
    r"(?P<time>\d{4}[./-]\d{2}[./-]\d{2}\s+\d{2}:\d{2}(:\d{2})?)"
    r"\s+.*?(?P<ticket>#?\d{5,})?"
    r".*?\b(?P<symbol>[A-Z]{3,10})\b"
    r".*?\b(?P<volume>\d+(\.\d+)?)\b"
    r".*?(?P<profit>-?\d+(\.\d+)?)\s*$"
)


def _parse_plaintext_mt_log(raw: bytes) -> pd.DataFrame:
    """پارس خط‌به‌خط یک لاگ متنی سبک MT4/MT5 با regex.
    اگر ساختار لاگ با این الگو مطابقت نداشت، Exception می‌دهد تا فراخوان
    بتواند fallback بزند یا خطای واضح نشان دهد."""
    text = raw.decode("utf-8", errors="ignore")
    rows = []
    for line in text.splitlines():
        m = _MT_LOG_LINE_RE.search(line)
        if m:
            rows.append({
                "Open Time": m.group("time"),
                "Symbol": m.group("symbol"),
                "Size": m.group("volume"),
                "Profit": m.group("profit"),
            })
    if not rows:
        raise UnsupportedFileError(
            "این فایل .log با الگوی شناخته‌شده‌ی MT4/MT5 مطابقت ندارد. "
            "اگر فایل شما HTML است، پسوند را به .htm تغییر دهید؛ در غیر "
            "این صورت یک نمونه از فرمت لاگ خود را برای افزودن پشتیبانی ارسال کنید."
        )
    return pd.DataFrame(rows)


# ------------------------------------------------------------------
# API عمومی
# ------------------------------------------------------------------

def load_any_file(file: Union[str, Path, "io.BufferedIOBase"], filename: str = None) -> pd.DataFrame:
    """
    ورودی می‌تواند مسیر فایل، یا یک file-like object (مثل خروجی
    st.file_uploader در Streamlit) باشد.

    filename: اگر `file` یک file-like object باشد (که اسم فایل ندارد)،
    باید نام اصلی فایل (با پسوند) جداگانه داده شود تا پسوند تشخیص داده شود.
    """
    if isinstance(file, (str, Path)):
        path = Path(file)
        name = path.name
        raw = path.read_bytes()
    else:
        # file-like (مثل UploadedFile در Streamlit)
        name = filename or getattr(file, "name", "")
        raw = file.read()
        if hasattr(file, "seek"):
            file.seek(0)

    if raw is None or len(raw) == 0:
        log.warning("Empty file rejected: '%s'", name)
        raise UnsupportedFileError(
            f"فایل '{name}' خالی است. لطفاً فایلی با محتوای معاملات آپلود کنید."
        )

    ext = Path(name).suffix.lower().lstrip(".")
    log.info("Loading file '%s' (ext=%s, size=%d bytes)", name, ext or "unknown", len(raw))

    if ext in ("csv", "txt", "tsv"):
        return _sniff_encoding_and_read_csv(raw)

    if ext in ("xlsx", "xls"):
        return _read_excel_best_sheet(raw)

    if ext in ("htm", "html"):
        return _read_html_best_table(raw)

    if ext == "json":
        try:
            data = json.loads(raw.decode("utf-8", errors="ignore"))
        except json.JSONDecodeError as e:
            raise UnsupportedFileError(f"فایل JSON نامعتبر است (قابل‌پارس نیست): {e}") from e
        try:
            df = pd.json_normalize(data)
        except Exception as e:
            raise UnsupportedFileError(f"ساختار JSON قابل‌تبدیل به جدول نیست: {e}") from e
        if len(df) == 0:
            raise UnsupportedFileError("فایل JSON هیچ رکورد قابل‌استفاده‌ای ندارد.")
        return df

    if ext == "log":
        # اول فرض می‌کنیم HTML با پسوند تغییرکرده است (خیلی رایج در
        # خروجی بروکرهای MT4/MT5)؛ اگر جواب نداد، به پارسر متنی برمی‌گردیم.
        try:
            return _read_html_best_table(raw)
        except Exception:
            return _parse_plaintext_mt_log(raw)

    # اگر پسوند ناشناخته بود، به‌ترتیب همه‌ی استراتژی‌ها را امتحان می‌کنیم
    for strategy in (_read_excel_best_sheet, _read_html_best_table, _sniff_encoding_and_read_csv):
        try:
            return strategy(raw)
        except Exception:
            continue

    log.warning("Unsupported file format: '%s'", name)
    raise UnsupportedFileError(
        f"فرمت فایل '{name}' پشتیبانی نمی‌شود. فرمت‌های مجاز: "
        "csv, txt, tsv, xlsx, xls, htm, html, log, json."
    )
