# -*- coding: utf-8 -*-
"""
utils/column_mapper.py
-----------------------
نگاشت و نرمال‌سازی ستون‌های خام هر بروکر/صرافی (MT4, MT5, Binance, Bybit, ...)
به سه ستون استاندارد: "Open Time", "Profit", "Size".

این منطق قبلاً داخل TradingDoctorV21_3 بود و بدون هیچ تغییری در رفتار،
به یک ابزار مستقل (ColumnMapper) منتقل شده تا engines/behavior_engine.py
فقط مسئول امتیازدهی رفتاری باشد، نه تشخیص ستون‌ها.
"""

import re
import pandas as pd


class ColumnMapper:
    """نگاشت ستون‌های خام یک DataFrame به شِمای استاندارد TradingDoctor."""

    # ------------------------------------------------------------------
    # جداول نگاشت ستون‌ها
    # ------------------------------------------------------------------

    _EXACT_ALIASES = {
        # Open Time
        "open time": "Open Time", "time": "Open Time", "opentime": "Open Time",
        "open_time": "Open Time", "date": "Open Time", "datetime": "Open Time",
        "date(utc)": "Open Time", "entry time": "Open Time", "entry date": "Open Time",
        "trade time": "Open Time", "trade date": "Open Time", "timestamp": "Open Time",
        "deal time": "Open Time", "execution time": "Open Time",
        # Profit
        "profit": "Profit", "pnl": "Profit", "realized pnl": "Profit",
        "realised pnl": "Profit", "net profit": "Profit", "net pnl": "Profit",
        "closed pnl": "Profit", "p/l": "Profit", "p&l": "Profit", "result": "Profit",
        "gain/loss": "Profit", "profit/loss": "Profit",
        # Size
        "size": "Size", "volume": "Size", "lots": "Size", "lot": "Size",
        "executed": "Size", "qty": "Size", "quantity": "Size",
        "position size": "Size", "filled qty": "Size", "filled": "Size",
    }

    _OPEN_TIME_FUZZY = [
        ["open time", "opentime", "entry time", "entrytime"],
        ["trade time", "trade date", "execution time", "deal time"],
        ["date utc", "datetime", "timestamp"],
        ["date", "time"],
    ]
    _PROFIT_FUZZY = [
        ["realized pnl", "realised pnl", "net profit", "net pnl", "closed pnl"],
        ["profit loss", "gain loss", "p l"],
        ["pnl", "profit", "result"],
    ]
    _SIZE_FUZZY = [
        ["position size", "lot size", "trade size"],
        ["executed", "filled qty", "filled"],
        ["volume", "lots", "lot", "qty", "quantity"],
        ["size"],
        ["amount"],
    ]

    _TIME_ONLY_RE = re.compile(r"^\s*\d{1,2}:\d{2}(:\d{2})?(\s*[ap]m)?\s*$", re.I)

    # ------------------------------------------------------------------
    # ابزارهای داخلی
    # ------------------------------------------------------------------

    @staticmethod
    def _clean(name: str) -> str:
        return re.sub(r"[^a-z0-9]+", " ", str(name).strip().lower()).strip()

    @classmethod
    def _is_time_only_series(cls, s: pd.Series, sample: int = 25) -> bool:
        """
        تشخیص می‌دهد که آیا یک ستون فقط ساعت (بدون تاریخ) است، مثل '10:00:00'.
        اگر بله، باید قبل از تبدیل به datetime با ستون Date ترکیب شود؛
        وگرنه بخش تاریخ گم شده و همه‌ی معاملات روی تاریخ امروز (سیستم) می‌افتند.
        """
        vals = s.dropna().astype(str).str.strip()
        vals = vals[vals != ""].head(sample)
        if len(vals) == 0:
            return False
        return bool(vals.map(lambda v: bool(cls._TIME_ONLY_RE.match(v))).all())

    @classmethod
    def _fuzzy_find(cls, df, priority_groups, used_cols, exclude=None, deprioritize=None):
        """
        [FIX 1 - جدی] قبلاً matching با substring خام انجام می‌شد:
        `"p l" in "stop loss"` به‌اشتباه True برمی‌گشت (چون کاراکترهای
        اندیس ۳ تا ۵ در "stop loss" دقیقاً "p l" هستند)، و همین باعث
        می‌شد ستون Stop_Loss به‌جای Profit_Loss_USD به عنوان "Profit"
        شناسایی شود. الان matching بر اساس دنباله‌ی کامل کلمات (word-level
        phrase) انجام می‌شود، نه substring خام روی رشته‌ی چسبیده.

        [FIX 2] وقتی چند ستون هم‌زمان با یک گروه اولویت match می‌شوند
        (مثلاً هم Profit_Loss_Pips و هم Profit_Loss_USD هر دو شامل
        عبارت "profit loss" هستند)، به‌جای انتخاب اولین ستون بر اساس
        ترتیب ظاهرشدن در فایل CSV، ستون‌هایی که شامل کلیدواژه‌های
        غیرپولی (pip, point, percent, ...) هستند deprioritize می‌شوند
        تا ستون واقعی دلاری/مالی برنده شود.
        """
        exclude = exclude or []
        deprioritize = deprioritize or []
        cleaned = {col: cls._clean(col) for col in df.columns}

        for group in priority_groups:
            candidates = []
            for col, c in cleaned.items():
                if col in used_cols:
                    continue
                if any(cls._contains_phrase(c, ex) for ex in exclude):
                    continue
                if any(cls._contains_phrase(c, kw) for kw in group):
                    candidates.append(col)

            if not candidates:
                continue

            preferred = [
                c for c in candidates
                if not any(cls._contains_phrase(cleaned[c], d) for d in deprioritize)
            ]
            return preferred[0] if preferred else candidates[0]

        return None

    @staticmethod
    def _contains_phrase(cleaned_text: str, keyword: str) -> bool:
        """
        [FIX 1] تشخیص می‌دهد که آیا `keyword` به‌صورت یک دنباله‌ی کامل
        از کلمات (نه substring خام) در `cleaned_text` وجود دارد.
        مثال: "p l" در "stop loss" دیگر match نمی‌شود چون کلمات
        ["stop", "loss"] شامل دنباله‌ی ["p", "l"] نیستند؛ ولی "p l"
        در "p l amount" یا "profit loss usd" (به‌واسطه‌ی "profit loss")
        درست تشخیص داده می‌شود.
        """
        text_words = cleaned_text.split()
        kw_words = keyword.split()
        n, k = len(text_words), len(kw_words)
        if k == 0 or k > n:
            return False
        for i in range(n - k + 1):
            if text_words[i:i + k] == kw_words:
                return True
        return False

    # ------------------------------------------------------------------
    # API عمومی
    # ------------------------------------------------------------------

    @classmethod
    def normalize(cls, df: pd.DataFrame) -> pd.DataFrame:
        """DataFrame خام هر بروکر را به شِمای استاندارد نگاشت می‌کند."""
        df.columns = [str(c).strip().lower() for c in df.columns]
        used = set()

        # مرحله‌ی ۰ (باگ‌فیکس): ستون‌های جدای Date و Time
        # بسیاری از بروکرها (MT4/MT5 و...) تاریخ و ساعت را در دو ستون جدا
        # می‌دهند، مثلاً date='2024.01.01' و time='10:00:00'.
        # قبل از این فیکس، الگوریتم فقط ستون «time» را به Open Time نگاشت
        # می‌کرد و بخش تاریخ کاملاً گم می‌شد (همه‌ی معاملات روی تاریخ اجرای
        # برنامه می‌افتادند)؛ همین باعث خراب‌شدن overtrading/weekday/edge‌map
        # می‌شد. اینجا اگر ستون time فقط ساعت باشد، با date ترکیب می‌شود.
        if "date" in df.columns and "time" in df.columns:
            if cls._is_time_only_series(df["time"]):
                df["open time"] = (
                    df["date"].astype(str).str.strip()
                    + " "
                    + df["time"].astype(str).str.strip()
                )
                used.add("date")
                used.add("time")

        # مرحله ۱: تطبیق دقیق
        for old, new in cls._EXACT_ALIASES.items():
            if old in df.columns and old not in used and new not in df.columns:
                df = df.rename(columns={old: new})
                used.add(old)

        # مرحله ۲: fuzzy fallback
        if "Open Time" not in df.columns:
            found = cls._fuzzy_find(df, cls._OPEN_TIME_FUZZY, used, exclude=["close"])
            if found:
                df = df.rename(columns={found: "Open Time"})
                used.add(found)

        if "Profit" not in df.columns:
            # [FIX 1] ستون‌های استاندارد Stop_Loss و Take_Profit در تقریباً
            # همه‌ی بروکرها یک قیمت هستند، نه سود/زیان — صراحتاً exclude
            # می‌شوند تا هرگز به‌اشتباه به عنوان "Profit" شناسایی نشوند
            # (فارغ از اینکه کدام کلیدواژه‌ی fuzzy با آن‌ها تصادفاً match کند).
            # [FIX 2] ستون‌های مبتنی بر pip/point/percent نسبت به ستون‌های
            # دلاری/مالی deprioritize می‌شوند (مثلاً Profit_Loss_Pips در
            # برابر Profit_Loss_USD).
            found = cls._fuzzy_find(
                df, cls._PROFIT_FUZZY, used,
                exclude=["stop loss", "take profit", "stop", "take"],
                deprioritize=["pip", "pips", "point", "points", "percent", "pct"],
            )
            if found:
                df = df.rename(columns={found: "Profit"})
                used.add(found)

        if "Size" not in df.columns:
            found = cls._fuzzy_find(df, cls._SIZE_FUZZY, used)
            if found:
                df = df.rename(columns={found: "Size"})
                used.add(found)

        # تبدیل نوع داده
        for col in ["Profit", "Size"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
            else:
                df[col] = 0

        # پردازش زمان
        if "Open Time" in df.columns:
            try:
                df["Open Time"] = pd.to_datetime(
                    df["Open Time"], errors="coerce", format="mixed"
                )
            except (TypeError, ValueError):
                df["Open Time"] = pd.to_datetime(df["Open Time"], errors="coerce")
            df["hour"] = df["Open Time"].dt.hour
            df["date"] = df["Open Time"].dt.date

            # باگ‌فیکس: تحلیل رفتاری (revenge streak، quick re-entry، تغییر
            # حجم بین معاملات و...) کاملاً به ترتیب ردیف‌ها وابسته است.
            # اگر فایل CSV از قبل به‌ترتیب زمانی نبود (خیلی از اکسپورت‌های
            # بروکر مرتب نیستند)، محاسبات streak/patience اشتباه می‌شدند.
            # اینجا با مرتب‌سازی پایدار بر اساس Open Time این مشکل رفع شده.
            if df["Open Time"].notna().any():
                df = df.sort_values(
                    "Open Time", kind="mergesort", na_position="last"
                ).reset_index(drop=True)
                df["hour"] = df["Open Time"].dt.hour
                df["date"] = df["Open Time"].dt.date
        else:
            df["Open Time"] = pd.NaT
            df["hour"] = 0
            df["date"] = pd.NaT

        return df
