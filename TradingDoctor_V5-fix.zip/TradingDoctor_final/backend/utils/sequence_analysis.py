# -*- coding: utf-8 -*-
"""
utils/sequence_analysis.py
-----------------------------
[AUDIT FIX] محاسبه‌ی "طول رشته‌ی رخدادهای پشت‌سرهم" (streak) قبلاً به‌صورت
یک حلقه‌ی دستی پایتون، دقیقاً با همان منطق، در سه جای مختلف کد تکرار شده
بود:
  - engines/behavior_engine.py -> revenge_analysis()
  - engines/behavior_engine.py -> _simulate_what_if()
  - engines/score_engine.py    -> _revenge_mask()
  - engines/evidence_engine.py -> _sequential_masks()

این تکرار (duplicated logic) دو مشکل واقعی داشت:
  1) نگه‌داری: هر تغییر در منطق streak باید در ۴ جای مختلف هم‌زمان اعمال
     می‌شد؛ فراموش‌کردن حتی یکی باعث ناسازگاری بین Engineها می‌شد.
  2) کارایی: حلقه‌ی صریح پایتون روی هر ردیف، برای دیتاست‌های بزرگ
     (ده‌ها/صدها هزار معامله) به‌مراتب کندتر از معادل برداری (vectorized)
     pandas/numpy است.

این ماژول یک پیاده‌سازی *برداری* واحد و تست‌شده ارائه می‌کند که دقیقاً
همان نتیجه‌ی عددی حلقه‌ی قدیمی را تولید می‌کند (تأییدشده با تست واحد در
tests/test_pipeline.py)، و همه‌ی Engineهای بالا اکنون از همین یک منبع
استفاده می‌کنند.
"""

from typing import Optional

import numpy as np
import pandas as pd


def consecutive_streak(mask: np.ndarray) -> np.ndarray:
    """
    برای هر موقعیت i، طول رشته‌ی مقادیر True که دقیقاً به i ختم می‌شود را
    برمی‌گرداند (اگر mask[i] برابر False باشد، streak[i] == 0).

    معادل برداری این حلقه‌ی دستی:
        running = 0
        for i in range(n):
            running = running + 1 if mask[i] else 0
            streak[i] = running
    """
    mask = np.asarray(mask, dtype=bool)
    n = len(mask)
    if n == 0:
        return np.zeros(0, dtype=int)

    s = pd.Series(mask.astype(int))
    cumsum = s.cumsum()
    # مقدار cumsum را فقط در نقاطی که mask False است نگه می‌داریم، بقیه NaN
    reset_points = cumsum.where(~mask)
    baseline = reset_points.ffill().fillna(0)
    streak = (cumsum - baseline).astype(int)
    return streak.values


def size_increased_mask(size: np.ndarray, threshold: float = 1.05) -> np.ndarray:
    """
    آیا حجم معامله‌ی فعلی نسبت به حجم معامله‌ی قبلی، بیش از `threshold`
    برابر افزایش یافته؟ اولین ردیف همیشه False است (حجم قبلی ندارد).
    """
    size = np.asarray(size, dtype=float)
    if len(size) == 0:
        return np.zeros(0, dtype=bool)
    prev_size = np.concatenate(([np.nan], size[:-1]))
    with np.errstate(invalid="ignore"):
        return (size > prev_size * threshold) & ~np.isnan(prev_size)


def revenge_mask_from_df(df: pd.DataFrame) -> np.ndarray:
    """
    ماسک Revenge Trading: حداقل ۲ باخت پشت‌سرهم + باخت فعلی + افزایش حجم
    نسبت به معامله‌ی قبلی. منطق تغییر نکرده — فقط از منبع مشترک بالا
    استفاده می‌کند.
    """
    if len(df) == 0:
        return np.zeros(0, dtype=bool)
    profit = df["Profit"].values
    size = df["Size"].values
    is_loss = profit < 0
    loss_streak = consecutive_streak(is_loss)
    increased = size_increased_mask(size)
    return (loss_streak >= 2) & is_loss & increased


def sequential_masks(df: pd.DataFrame, quick_reentry_minutes: int = 15) -> Optional[dict]:
    """
    خروجی ترکیبی مورد استفاده‌ی EvidenceEngine: win/loss streak، افزایش
    حجم، فاصله‌ی زمانی سریع بین معاملات، و ماسک‌های ترکیبی revenge/fomo.
    اگر df خالی باشد None برمی‌گرداند.
    """
    if len(df) == 0:
        return None
    profit = df["Profit"].values
    size = df["Size"].values
    n = len(profit)
    is_win = profit > 0
    is_loss = profit < 0

    win_streak = consecutive_streak(is_win)
    loss_streak = consecutive_streak(is_loss)
    size_increased = size_increased_mask(size)

    has_time = not df["Open Time"].isna().all()
    if has_time:
        gap_minutes = df["Open Time"].diff().dt.total_seconds().values / 60.0
        quick = gap_minutes < quick_reentry_minutes
    else:
        quick = np.ones(n, dtype=bool)

    return dict(
        profit=profit, size=size, is_win=is_win, is_loss=is_loss,
        win_streak=win_streak, loss_streak=loss_streak,
        size_increased=size_increased, quick=quick,
        revenge_mask=(loss_streak >= 2) & is_loss & size_increased,
        fomo_mask=(win_streak >= 2) & is_win & size_increased & quick,
    )
