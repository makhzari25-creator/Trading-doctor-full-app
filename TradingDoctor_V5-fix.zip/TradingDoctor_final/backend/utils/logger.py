# -*- coding: utf-8 -*-
"""
utils/logger.py
------------------
پیکربندی متمرکز لاگینگ برای کل پروژه (CLI، Streamlit، Engines، LLM).

هدف:
  - یک نقطه‌ی واحد برای گرفتن logger با تنظیمات یکسان در همه‌ی ماژول‌ها.
  - لاگ هم روی کنسول و هم (اختیاری) روی فایل `reports/trading_doctor.log`
    نوشته می‌شود تا مشکلات production قابل‌بررسی باشند.
  - هرگز هیچ کلید API یا محتوای کامل پاسخ LLM لاگ نمی‌شود — فقط رویدادها
    (شروع/پایان درخواست، provider، موفقیت/خطا) برای حفظ حریم خصوصی و امنیت.

استفاده:
    from utils.logger import get_logger
    log = get_logger(__name__)
    log.info("چیزی")
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

_CONFIGURED = False


def _is_production() -> bool:
    return os.getenv("TRADING_DOCTOR_ENV", "development").strip().lower() == "production"


def _use_json_logging() -> bool:
    """JSON logging when explicitly enabled OR when in production."""
    explicit = os.getenv("TRADING_DOCTOR_LOG_JSON", "").strip().lower()
    if explicit in ("true", "1", "yes"):
        return True
    if explicit in ("false", "0", "no"):
        return False
    # Default: JSON in production, plain text elsewhere.
    return _is_production()


def _build_formatter() -> logging.Formatter:
    """Return the formatter appropriate for the configured log mode.

    Phase 7.5 addition: when TRADING_DOCTOR_LOG_JSON=true (or implicitly in
    production), emit single-line JSON records suitable for log aggregators
    (Loki, Datadog, CloudWatch Logs, ELK). Each record includes timestamp,
    level, logger name, message, and any `extra=...` fields passed to the
    log call.
    """
    if not _use_json_logging():
        return logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    # Try to use python-json-logger if available; fall back to a manual JSON
    # formatter if the package is not installed.
    try:
        from pythonjsonlogger import jsonlogger
        return jsonlogger.JsonFormatter(
            "%(asctime)s %(levelname)s %(name)s %(message)s",
            rename_fields={"asctime": "timestamp", "levelname": "level", "name": "logger"},
            json_ensure_ascii=False,
        )
    except ImportError:
        import json
        from datetime import datetime, timezone

        class _ManualJsonFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                payload = {
                    "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
                    "level": record.levelname,
                    "logger": record.name,
                    "message": record.getMessage(),
                }
                if record.exc_info:
                    payload["exc_info"] = self.formatException(record.exc_info)
                # Include any extra fields passed via log.info(..., extra={...}).
                standard = set(vars(record).keys()) - {"args", "msg", "levelname", "levelno",
                                                       "pathname", "filename", "module", "exc_info",
                                                       "exc_text", "stack_info", "lineno", "funcName",
                                                       "created", "msecs", "relativeCreated", "thread",
                                                       "threadName", "processName", "process", "name",
                                                       "message"}
                for key in standard:
                    val = getattr(record, key, None)
                    if val is not None:
                        payload[key] = val
                return json.dumps(payload, ensure_ascii=False, default=str)

        return _ManualJsonFormatter()


def _configure_root() -> None:
    """پیکربندی یک‌باره‌ی root logger پروژه (idempotent)."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    level_name = os.getenv("TRADING_DOCTOR_LOG_LEVEL", "INFO").strip().upper()
    level = getattr(logging, level_name, logging.INFO)

    root = logging.getLogger("trading_doctor")
    root.setLevel(level)
    root.propagate = False  # جلوگیری از لاگ تکراری در root logger پیش‌فرض

    if root.handlers:
        _CONFIGURED = True
        return

    fmt = _build_formatter()

    # کنسول — همیشه فعال
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(fmt)
    root.addHandler(console_handler)

    # فایل — بهترین تلاش؛ اگر مسیر reports/ قابل‌نوشتن نبود (مثلاً محیط
    # read-only)، بی‌صدا فقط لاگ کنسول باقی می‌ماند، برنامه کرش نمی‌کند.
    try:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        log_dir = os.path.join(base_dir, "reports")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, "trading_doctor.log")
        file_handler = RotatingFileHandler(
            log_path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
        )
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)
    except OSError:
        pass

    _CONFIGURED = True


def get_logger(name: str = "trading_doctor") -> logging.Logger:
    """logger فرزند زیر namespace مشترک 'trading_doctor' برمی‌گرداند."""
    _configure_root()
    if not name.startswith("trading_doctor"):
        name = f"trading_doctor.{name}"
    return logging.getLogger(name)
