# -*- coding: utf-8 -*-
"""
utils/validation.py
----------------------
اعتبارسنجی production-grade داده‌ی معاملاتی آپلودشده، پیش از ورود به خط
لوله‌ی تحلیلی (BehaviorEngine/ScoreEngine/...).

فلسفه:
  - خطاهای فاجعه‌بار (فایل خالی، هیچ ستون مالی/زمانی قابل‌شناسایی نیست) →
    DataValidationError با پیام کاربرپسند و واضح (نه traceback خام).
  - مشکلات جزئی/قابل‌تحمل (چند ردیف تکراری، چند تاریخ نامعتبر، چند حجم
    صفر/منفی) → هرگز باعث کرش نمی‌شوند؛ فقط جمع‌آوری و لاگ می‌شوند تا
    کاربر/توسعه‌دهنده از کیفیت داده مطلع باشد، بدون این‌که هیچ ردیفی حذف
    یا داده‌ای دستکاری شود — تا منطق تحلیلی و سازگاری با نتایج قبلی کاملاً
    حفظ شود (طبق قانون پروژه: هرگز داده‌ی معتبر را بی‌صدا تغییر نده).
"""

from typing import List, Optional, Tuple

import pandas as pd

from utils.column_mapper import ColumnMapper
from utils.logger import get_logger

log = get_logger(__name__)


class DataValidationError(Exception):
    """خطای فاجعه‌بار داده که اجازه نمی‌دهد تحلیل ادامه یابد."""


def _find_original_time_col(original_columns: List[str]) -> Optional[str]:
    """بهترین حدس برای ستون خام زمان قبل از نرمال‌سازی (برای شمارش تاریخ‌های نامعتبر)."""
    lowered = {str(c).strip().lower(): c for c in original_columns}
    for key in ("open time", "time", "date", "datetime", "timestamp", "trade time", "deal time"):
        if key in lowered:
            return lowered[key]
    return None


def validate_and_normalize(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    """
    df خام (خروجی utils.file_loader.load_any_file) را اعتبارسنجی و
    نرمال‌سازی می‌کند.

    برمی‌گرداند: (normalized_df, warnings)
      normalized_df : خروجی ColumnMapper.normalize (idempotent — دوباره‌
                      نرمال‌سازی توسط BehaviorEngine بی‌ضرر است).
      warnings      : فهرست پیام‌های غیرفاجعه‌بار برای لاگ/نمایش کیفیت داده.

    raises DataValidationError برای مشکلات فاجعه‌بار: فایل خالی، ورودی از
    نوع اشتباه، یا هیچ ستون مالی/زمانی قابل‌شناسایی نیست.
    """
    if df is None:
        raise DataValidationError("هیچ داده‌ای برای تحلیل دریافت نشد (فایل خالی یا خراب است).")

    if not isinstance(df, pd.DataFrame):
        raise DataValidationError(
            f"نوع داده‌ی ورودی نامعتبر است: انتظار جدول داده (DataFrame) بود، "
            f"{type(df).__name__} دریافت شد."
        )

    if len(df) == 0:
        raise DataValidationError(
            "فایل آپلودشده هیچ ردیف معامله‌ای ندارد (فایل خالی است یا فقط شامل هدر ستون‌هاست)."
        )

    if df.shape[1] < 2:
        raise DataValidationError(
            "فایل آپلودشده حداقل باید ۲ ستون داشته باشد (مثلاً سود/زیان و تاریخ یا حجم). "
            f"فقط {df.shape[1]} ستون در فایل شناسایی شد."
        )

    original_columns = list(df.columns)
    warnings: List[str] = []

    # ردیف‌های کاملاً تکراری — فقط گزارش می‌شود، هیچ ردیفی حذف نمی‌شود
    # (ممکن است دو معامله‌ی واقعی و مجزا کاملاً مشابه باشند؛ حذف خودکار
    # می‌تواند معاملات واقعی را از تحلیل حذف کند).
    dup_count = int(df.duplicated().sum())
    if dup_count > 0:
        pct = round(dup_count / len(df) * 100, 1)
        msg = f"{dup_count} ردیف کاملاً تکراری در فایل شناسایی شد ({pct}% از کل داده)."
        warnings.append(msg)
        log.warning(msg)

    normalized = ColumnMapper.normalize(df.copy())

    # [FIX] بررسی "آیا ستون واقعاً شناسایی شد" باید بر مبنای «همه‌ی مقادیر
    # دقیقاً صفر هستند» باشد، نه «مجموع صفر است» — یک ستون Profit واقعی که
    # اتفاقی برد/باخت‌هایش دقیقاً هم را خنثی می‌کنند (net profit == 0)
    # نباید به‌اشتباه «شناسایی نشد» تشخیص داده شود.
    has_profit = "Profit" in normalized.columns and not (normalized["Profit"] == 0).all()
    has_size = "Size" in normalized.columns and not (normalized["Size"] == 0).all()
    has_time = "Open Time" in normalized.columns and normalized["Open Time"].notna().any()

    if not has_profit and not has_size and not has_time:
        raise DataValidationError(
            "هیچ ستون مالی (سود/زیان) یا زمانی قابل‌شناسایی در این فایل پیدا نشد. "
            f"ستون‌های موجود در فایل شما: {original_columns}. "
            "لطفاً مطمئن شوید فایل شامل ستون‌هایی مانند Profit/PnL، Size/Volume/Lots "
            "یا Open Time/Date است، یا از یک اکسپورت استاندارد بروکر استفاده کنید."
        )

    if not has_profit:
        msg = (
            "ستون سود/زیان (Profit) قابل‌شناسایی نبود یا مقدار همه‌ی ردیف‌ها صفر است — "
            "امتیازهای رفتاری مبتنی بر سود (Revenge/Discipline/Overtrading) قابل‌اعتماد نخواهند بود."
        )
        warnings.append(msg)
        log.warning(msg)

    if not has_size:
        msg = (
            "ستون حجم معامله (Size/Volume/Lots) قابل‌شناسایی نبود — "
            "امتیازهای Risk Taking و Revenge Trading (که به تغییر حجم بین معاملات وابسته‌اند) دقیق نخواهند بود."
        )
        warnings.append(msg)
        log.warning(msg)

    if not has_time:
        msg = (
            "ستون زمان معامله (Open Time/Date) قابل‌شناسایی نبود — "
            "تحلیل‌های وابسته به زمان (Overtrading، Patience، Edge Map ساعتی/روزانه، صفحه‌ی Trends) در دسترس نخواهند بود."
        )
        warnings.append(msg)
        log.warning(msg)

    # تاریخ‌های نامعتبر (coerce شده به NaT توسط pandas) در بین داده‌ای که
    # اصلاً یک ستون زمان دارد.
    if has_time:
        raw_time_col = _find_original_time_col(original_columns)
        if raw_time_col is not None:
            raw_vals = df[raw_time_col].astype(str).str.strip()
            raw_non_empty = raw_vals[(raw_vals != "") & (raw_vals.str.lower() != "nan")]
            invalid_dates = len(raw_non_empty) - int(normalized["Open Time"].notna().sum())
            if invalid_dates > 0 and len(raw_non_empty) > 0:
                pct = round(invalid_dates / len(raw_non_empty) * 100, 1)
                if pct >= 5:
                    msg = f"{invalid_dates} مقدار تاریخ/زمان نامعتبر شناسایی و نادیده گرفته شد ({pct}%)."
                    warnings.append(msg)
                    log.warning(msg)

    # حجم‌های نامعتبر (صفر یا منفی) — لات/حجم منفی یا صفر معمولاً یعنی
    # داده خراب است یا ستون اشتباه نگاشت شده.
    if has_size:
        invalid_size = int((normalized["Size"] <= 0).sum())
        if invalid_size > 0:
            pct = round(invalid_size / len(normalized) * 100, 1)
            msg = f"{invalid_size} معامله حجم صفر یا منفی (نامعتبر) دارند ({pct}% از کل)."
            warnings.append(msg)
            log.warning(msg)

    log.info(
        "Validation complete: %d rows, %d columns, %d warning(s) generated",
        len(df), df.shape[1], len(warnings),
    )
    return normalized, warnings
