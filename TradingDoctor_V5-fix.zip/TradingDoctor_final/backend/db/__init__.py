# -*- coding: utf-8 -*-
"""
db
--
Phase 7.5 — Database layer for TradingDoctor SaaS.

This package provides:
  - async SQLAlchemy engine + session factory (Phase 8/9/10 use this)
  - declarative Base for ORM models
  - get_db() FastAPI dependency (yields an AsyncSession)
  - health check helper (used by api/routers/health.py)
  - graceful fallback when DATABASE_URL is unset (engine stays runnable
    for tests and Streamlit-only deployments)

DESIGN PRINCIPLES:
  - The frozen V23 engine (engines/*) has zero DB awareness. It operates
    on DataFrames. This layer wraps persistence around it; the engine
    itself never imports `db.*`.
  - All DB I/O is async (asyncpg). Sync access is only via Alembic, which
    uses DATABASE_URL_SYNC.
  - Repository pattern is layered on top in Phase 9 (api/services/store.py
    becomes a thin shim over repositories); the engine contract is preserved.
"""

from db.base import Base, engine, async_session_factory, get_db, db_health_check
from db.models import TimestampMixin, UUIDPkMixin

__all__ = [
    "Base",
    "engine",
    "async_session_factory",
    "get_db",
    "db_health_check",
    "TimestampMixin",
    "UUIDPkMixin",
]
