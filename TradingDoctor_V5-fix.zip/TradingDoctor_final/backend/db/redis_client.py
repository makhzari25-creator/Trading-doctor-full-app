# -*- coding: utf-8 -*-
"""
db/redis_client.py
------------------
Phase 7.5 — Async Redis client for caching and background queue.

Used by:
  - Phase 9 — report cache (optional, future)
  - Phase 11 — Celery broker (uses REDIS_URL directly via Celery config)
  - /health/ready endpoint — Redis reachability check

NOTE: Rate limiting is currently in-process (api/dependencies.py:_SlidingWindowRateLimiter).
For multi-worker deployments, rely on nginx's `limit_req_zone` (configured in
deploy/nginx/nginx.conf) which is multi-worker safe. A Redis-backed rate limiter
can be added here in the future if per-user rate limiting is needed.

Safety:
  - Returns None when REDIS_URL is unset (in-process fallbacks remain).
  - All operations are best-effort; Redis outages degrade gracefully to
    in-memory fallback (logged warning, never a hard failure).
"""

from __future__ import annotations

import os
from typing import Optional

from utils.logger import get_logger

log = get_logger("db.redis_client")


def _read_redis_url() -> Optional[str]:
    url = os.getenv("REDIS_URL", "").strip()
    return url or None


REDIS_URL: Optional[str] = _read_redis_url()

# Lazy-init: redis.asyncio is only imported when first needed.
# This keeps `import db.redis_client` cheap and safe in environments
# without redis installed (e.g. minimal Streamlit-only deployments).
_redis_client = None
_redis_lock = None


async def get_redis():
    """Return an async Redis client, or None if REDIS_URL is unset.

    The client is lazily created on first call and reused across requests.
    """
    global _redis_client, _redis_lock

    if not REDIS_URL:
        return None

    if _redis_client is not None:
        return _redis_client

    # Lazy import — keeps module load cheap when Redis is not used.
    try:
        import redis.asyncio as aioredis
    except ImportError:
        log.warning("redis package not installed — Redis features disabled.")
        return None

    if _redis_lock is None:
        import asyncio
        _redis_lock = asyncio.Lock()

    async with _redis_lock:
        if _redis_client is None:
            _redis_client = aioredis.from_url(
                REDIS_URL,
                decode_responses=True,
                socket_timeout=2.0,
                socket_connect_timeout=2.0,
                retry_on_timeout=True,
            )
            log.info("Redis client initialized for URL=%s", _redact_redis_url(REDIS_URL))
    return _redis_client


async def redis_health_check() -> bool:
    """Return True if Redis is reachable (or unset). False on failure."""
    if not REDIS_URL:
        return True
    try:
        client = await get_redis()
        if client is None:
            return False
        await client.ping()
        return True
    except Exception as exc:
        log.warning("Redis health check failed: %s", exc)
        return False


async def close_redis() -> None:
    """Close the Redis connection pool. Called on app shutdown."""
    global _redis_client
    if _redis_client is not None:
        try:
            await _redis_client.aclose()
        except Exception as exc:
            log.warning("Error closing Redis client: %s", exc)
        finally:
            _redis_client = None


def _redact_redis_url(url: str) -> str:
    """Hide password in Redis URL for log output."""
    if "://" not in url:
        return url
    try:
        scheme, rest = url.split("://", 1)
        if "@" not in rest:
            return url
        creds, hostpart = rest.split("@", 1)
        if ":" in creds:
            user = creds.split(":", 1)[0]
        else:
            user = creds
        return f"{scheme}://{user}:***@{hostpart}"
    except Exception:
        return url
