# -*- coding: utf-8 -*-
"""
db/models.py
------------
Phase 7.5 — Shared ORM mixins for all SaaS tables.

Concrete models (User, Upload, Analysis, Subscription, etc.) are added in
later phases. They all inherit these mixins to ensure consistent PK format,
timestamps, and audit fields.

DESIGN CHOICES:
  - UUID primary keys (UUID v4, stored as native UUID in Postgres).
    Avoids sequential ID enumeration attacks; safe for URL exposure.
  - created_at / updated_at timestamps with timezone awareness.
  - All timestamps stored as UTC.
  - Soft-delete via `deleted_at` column (added per-table when needed).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, func, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from db.base import Base


def _utcnow() -> datetime:
    """Return current UTC datetime (callable for server_default)."""
    return datetime.now(timezone.utc)


class UUIDPkMixin:
    """UUID primary key mixin. Inherit on any model that needs a UUID PK."""

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=func.gen_random_uuid(),
    )


class TimestampMixin:
    """created_at + updated_at with timezone, auto-managed by DB.

    - `created_at` is set once at INSERT (server_default=now()).
    - `updated_at` is set at INSERT and refreshed on every UPDATE
      (server_default=now() + onupdate=now()).
    """

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )


class SoftDeleteMixin:
    """Optional soft-delete column. When present, queries must filter `deleted_at IS NULL`."""

    deleted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None,
    )


# ---------------------------------------------------------------------------
# Concrete models — registered via imports so Alembic autogenerate sees them.
# ---------------------------------------------------------------------------

# Phase 8 — auth tables (User, RefreshToken, AuditLog, EmailVerification).
# Imported for side effect: each class registers itself on Base.metadata.
try:
    import auth.models  # noqa: F401
except ImportError as _e:  # pragma: no cover
    # Allows `db.models` to be imported in environments where the auth layer
    # is not yet installed (e.g. minimal Streamlit-only deployment).
    import logging
    logging.getLogger("db.models").debug("auth.models not imported: %s", _e)

# Phase 9 — workspace tables (Upload, Analysis, AnalysisReportCache, Favorite).
try:
    import workspace.models  # noqa: F401
except ImportError as _e:  # pragma: no cover
    import logging
    logging.getLogger("db.models").debug("workspace.models not imported: %s", _e)

# Phase 10 — billing tables (Plan, Subscription, Invoice, UsageEvent).
try:
    import billing.models  # noqa: F401
except ImportError as _e:  # pragma: no cover
    import logging
    logging.getLogger("db.models").debug("billing.models not imported: %s", _e)
