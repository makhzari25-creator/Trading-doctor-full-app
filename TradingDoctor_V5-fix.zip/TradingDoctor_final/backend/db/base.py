# -*- coding: utf-8 -*-
"""
db/base.py
----------
Phase 7.5 — Async SQLAlchemy engine, session factory, and Base.

This module is imported lazily and is safe to import even when DATABASE_URL
is unset (the engine is created with `null_pool`-like behavior in that case;
actual connection attempts are deferred to first use, so import never fails).

Why async:
  - FastAPI runs on asyncio; sync DB calls would block the event loop.
  - All Phase 8/9/10 code paths must use AsyncSession.
  - Alembic migrations use a SEPARATE sync engine (DATABASE_URL_SYNC) because
    Alembic does not support async drivers directly.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from utils.logger import get_logger

log = get_logger("db.base")


# ---------------------------------------------------------------------------
# Configuration (read once at import; immutable after)
# ---------------------------------------------------------------------------

def _read_db_url() -> Optional[str]:
    """Return async DB URL, or None if not configured / invalid.

    Validates that the URL uses an async-compatible SQLAlchemy dialect.
    This guards against accidentally setting DATABASE_URL to a non-SQLAlchemy
    format (e.g. Prisma's `file:...` syntax, or a plain path) which would
    crash the app at import time.
    """
    url = os.getenv("DATABASE_URL", "").strip()
    if not url:
        return None
    # Accepted async dialects. Add more (e.g. mysql+asyncmy) if needed.
    _VALID_PREFIXES = (
        "postgresql+asyncpg://",
        "sqlite+aiosqlite://",  # for tests / ephemeral dev DBs
    )
    if not url.startswith(_VALID_PREFIXES):
        log.warning(
            "DATABASE_URL=%r does not start with a supported async dialect "
            "(postgresql+asyncpg:// or sqlite+aiosqlite://). DB layer disabled. "
            "If this is intentional (e.g. Prisma), unset DATABASE_URL for this app.",
            url,
        )
        return None
    return url


def _redact_url(url: str) -> str:
    """Hide password in DB URL for log output.

    postgresql+asyncpg://user:secret@host/db  ->  postgresql+asyncpg://user:***@host/db
    """
    if "://" not in url:
        return url
    try:
        scheme, rest = url.split("://", 1)
        if "@" not in rest:
            return url
        creds, hostpart = rest.split("@", 1)
        if ":" in creds:
            user = creds.split(":", 1)[0]
        else:
            user = creds
        return f"{scheme}://{user}:***@{hostpart}"
    except Exception:
        return url


DATABASE_URL: Optional[str] = _read_db_url()


# ---------------------------------------------------------------------------
# Engine + session factory
# ---------------------------------------------------------------------------

# When DATABASE_URL is unset, engine is None — DB-dependent code must guard.
# This keeps the app importable in test environments and Streamlit-only mode.

engine: Optional[AsyncEngine] = None
async_session_factory: Optional[async_sessionmaker[AsyncSession]] = None

if DATABASE_URL:
    # SQLite (used in tests + ephemeral dev DBs) does NOT support pool_size etc.
    # Build kwargs conditionally to avoid TypeError.
    _is_sqlite = DATABASE_URL.startswith("sqlite")

    _echo = os.getenv("DB_ECHO", "false").lower() == "true"

    _engine_kwargs: dict = {
        "echo": _echo,
        "pool_pre_ping": True,  # detect stale connections after deploys / DB restarts
    }
    if not _is_sqlite:
        _engine_kwargs.update(
            pool_size=int(os.getenv("DB_POOL_SIZE", "10")),
            max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "20")),
            pool_timeout=int(os.getenv("DB_POOL_TIMEOUT", "30")),
            pool_recycle=int(os.getenv("DB_POOL_RECYCLE", "1800")),
        )

    engine = create_async_engine(DATABASE_URL, **_engine_kwargs)
    async_session_factory = async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    log.info("Database engine initialized for URL=%s", _redact_url(DATABASE_URL))
else:
    log.warning(
        "DATABASE_URL not set — DB layer disabled. "
        "App will run in Streamlit-only / no-DB mode. "
        "Set DATABASE_URL to enable persistence (Phase 8+)."
    )


# ---------------------------------------------------------------------------
# Declarative Base
# ---------------------------------------------------------------------------

class Base(DeclarativeBase):
    """Declarative base for all ORM models.

    Phase 8 will register User, Phase 9 will register Upload + Analysis, etc.
    Migrations are managed by Alembic (see alembic/ folder).
    """


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

async def get_db() -> AsyncIterator[Optional[AsyncSession]]:
    """FastAPI dependency yielding an AsyncSession.

    Usage:
        @router.get("/...")
        async def handler(db: AsyncSession = Depends(get_db)):
            ...

    When DATABASE_URL is unset, yields None — handlers must check.
    Phase 8 endpoints will raise ServiceUnavailable if DB is required
    but unavailable.

    Reads `async_session_factory` LAZILY at call time so tests that
    monkeypatch `db.base.async_session_factory` are respected.
    """
    # Lazy lookup — do NOT cache the factory at function definition time.
    # Tests monkeypatch this module's async_session_factory attribute.
    factory = globals().get("async_session_factory")
    if factory is None:
        yield None
        return

    async with factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Convenience context manager (for non-FastAPI code paths: workers, scripts)
# ---------------------------------------------------------------------------

@asynccontextmanager
async def db_session() -> AsyncIterator[Optional[AsyncSession]]:
    """Async context manager yielding an AsyncSession.

    Usage:
        async with db_session() as db:
            ...
    """
    if async_session_factory is None:
        yield None
        return
    async with async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

async def db_health_check() -> bool:
    """Return True if DB is reachable (or unset). False on connection failure.

    Used by api/routers/health.py for readiness probe.
    """
    if engine is None:
        return True  # DB not required — healthy in no-DB mode
    try:
        from sqlalchemy import text
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except Exception as exc:
        log.warning("DB health check failed: %s", exc)
        return False
