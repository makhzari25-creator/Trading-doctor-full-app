# -*- coding: utf-8 -*-
"""
workspace/schemas.py
--------------------
Phase 9 — Pydantic schemas for workspace endpoints.

Schemas extend the existing api/models/analysis.py schemas where possible,
adding only what's new in Phase 9: labels, favorites, search/sort params,
and the dashboard summary.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from api.models.analysis import AnalysisSummary, HistoryItem


# ---------------------------------------------------------------------------
# Common base (strict — forbids extra fields)
# ---------------------------------------------------------------------------

class _StrictBase(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
    )


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

class UploadItem(_StrictBase):
    """One upload in a user's upload list."""
    upload_id: str
    filename: str
    size_bytes: int
    file_type: str
    label: Optional[str] = None
    content_hash: Optional[str] = None
    created_at: datetime


class UploadListResponse(_StrictBase):
    items: List[UploadItem]
    total: int
    page: int
    page_size: int


class UploadDetailResponse(_StrictBase):
    upload_id: str
    filename: str
    size_bytes: int
    file_type: str
    label: Optional[str] = None
    content_hash: Optional[str] = None
    created_at: datetime
    analysis_count: int = 0


class RenameUploadRequest(_StrictBase):
    label: str = Field(..., min_length=1, max_length=255)


# ---------------------------------------------------------------------------
# Analysis (extends existing AnalysisSummary)
# ---------------------------------------------------------------------------

class AnalysisItem(_StrictBase):
    """One analysis in a user's analysis list. Adds label + is_favorite."""
    analysis_id: str
    upload_id: str
    filename: str
    label: Optional[str] = None
    created_at: datetime
    total_trades: int
    overall_score: float
    primary_diagnosis: str
    data_quality_warning_count: int
    is_favorite: bool = False
    llm_provider: str = "none"


class AnalysisListResponse(_StrictBase):
    items: List[AnalysisItem]
    total: int
    page: int
    page_size: int


class RenameAnalysisRequest(_StrictBase):
    label: str = Field(..., min_length=1, max_length=255)


class AnalysisListQueryParams(_StrictBase):
    """Query parameters for GET /workspace/analyses."""
    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=100)
    sort_by: str = Field("created_at", pattern="^(created_at|overall_score|filename|total_trades)$")
    sort_order: str = Field("desc", pattern="^(asc|desc)$")
    search: Optional[str] = None
    only_favorites: bool = False
    min_score: Optional[int] = Field(None, ge=0, le=100)
    max_score: Optional[int] = Field(None, ge=0, le=100)


# ---------------------------------------------------------------------------
# Favorites
# ---------------------------------------------------------------------------

class FavoriteRequest(_StrictBase):
    """Body for POST /workspace/analyses/{id}/favorite."""
    note: Optional[str] = Field(None, max_length=1000)


class FavoriteItem(_StrictBase):
    """One favorite in a user's favorites list."""
    analysis_id: str
    filename: str
    label: Optional[str] = None
    overall_score: float
    primary_diagnosis: str
    favorited_at: datetime
    note: Optional[str] = None


class FavoriteListResponse(_StrictBase):
    items: List[FavoriteItem]
    total: int
    page: int
    page_size: int


# ---------------------------------------------------------------------------
# Dashboard summary
# ---------------------------------------------------------------------------

class WorkspaceSummaryResponse(_StrictBase):
    """High-level KPIs for the user's dashboard."""
    total_uploads: int
    total_analyses: int
    total_favorites: int
    total_upload_bytes: int
    average_score: Optional[float] = None
    latest_analysis_at: Optional[datetime] = None
    best_analysis_score: Optional[float] = None
    worst_analysis_score: Optional[float] = None
