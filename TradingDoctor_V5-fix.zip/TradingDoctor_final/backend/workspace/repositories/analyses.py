# -*- coding: utf-8 -*-
"""
workspace/repositories/analyses.py
----------------------------------
Phase 9 — Repository for the analyses table.

Stores the engine's outputs (doctor/result/coach) as compressed pickle
bytes. Loads them back as Python objects on demand.

This is the CRITICAL repository — it preserves the engine contract:
  - `core.service.analyze_dataframe(df, llm_provider)` is the ONLY
    way to produce analysis results.
  - This repository ONLY persists + retrieves those results.
  - It never recomputes, re-scores, or modifies engine output.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import select, update, func, or_
from sqlalchemy.ext.asyncio import AsyncSession

from api.exceptions import AnalysisNotFoundError
from utils.logger import get_logger
from workspace.models import Analysis, AnalysisReportCache
from workspace.repositories.uploads import get_upload_by_id, get_upload_bytes
from workspace.services.serialization import (
    deserialize_engine_outputs,
    serialize_engine_outputs,
)
from workspace.services.storage import LocalStorageBackend, StorageBackend

log = get_logger("workspace.analyses_repo")


# ---------------------------------------------------------------------------
# Run + persist (the single integration point with the engine)
# ---------------------------------------------------------------------------

async def run_and_persist_analysis(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    llm_provider: str = "none",
    storage_backend: Optional[StorageBackend] = None,
) -> Analysis:
    """Run the V23 engine on an upload and persist the result.

    This is the ONLY method in the workspace layer that calls the engine.
    It mirrors the original `AnalysisStore.run_analysis` exactly:
      1. Load the upload bytes (via storage backend).
      2. Parse the file (utils.file_loader.load_any_file).
      3. Run analyze_dataframe (core.service).
      4. Serialize engine outputs to compressed pickle.
      5. Persist the Analysis row.
    """
    # Lazy imports to keep the workspace layer decoupled at module-load time.
    import io
    from core.service import analyze_dataframe
    from utils.file_loader import load_any_file, UnsupportedFileError
    from utils.validation import DataValidationError

    backend = storage_backend or LocalStorageBackend()
    upload, raw_bytes = await get_upload_bytes(db, user_id, upload_id, backend)

    try:
        df = load_any_file(io.BytesIO(raw_bytes), filename=upload.filename)
    except (UnsupportedFileError, DataValidationError):
        raise

    # ⚠️ ENGINE CALL — this is the only call to the frozen V23 engine.
    doctor, result, coach = analyze_dataframe(df, llm_provider=llm_provider)

    # Serialize for DB storage.
    doctor_bytes, result_bytes, coach_bytes = serialize_engine_outputs(
        doctor, result, coach,
    )

    # Cache scalar fields for fast history listing.
    overall_score = int(result.behavior.scores.get("discipline_score", 0))
    primary_diagnosis = coach.get("diagnosis", {}).get("primary", "N/A")
    warning_count = len(getattr(doctor, "data_quality_warnings", []) or [])
    total_trades = len(doctor.df)

    analysis = Analysis(
        id=uuid.uuid4(),
        user_id=user_id,
        upload_id=upload_id,
        filename=upload.filename,
        llm_provider=llm_provider,
        total_trades=total_trades,
        overall_score=overall_score,
        primary_diagnosis=primary_diagnosis,
        data_quality_warning_count=warning_count,
        engine_doctor_bytes=doctor_bytes,
        engine_result_bytes=result_bytes,
        engine_coach_bytes=coach_bytes,
    )
    db.add(analysis)
    await db.flush()
    log.info(
        "Persisted analysis id=%s user_id=%s upload_id=%s trades=%d score=%d",
        analysis.id, user_id, upload_id, total_trades, overall_score,
    )
    return analysis


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

async def get_analysis_by_id(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
) -> Analysis:
    """Return the analysis row, or raise AnalysisNotFoundError.

    Filters by user_id — never returns another user's analysis.
    Soft-deleted analyses are excluded.
    """
    stmt = select(Analysis).where(
        Analysis.id == analysis_id,
        Analysis.user_id == user_id,
        Analysis.deleted_at.is_(None),
    )
    result = await db.execute(stmt)
    analysis = result.scalar_one_or_none()
    if analysis is None:
        raise AnalysisNotFoundError(f"تحلیلی با شناسه‌ی «{analysis_id}» یافت نشد.")
    return analysis


async def get_engine_outputs(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
) -> tuple[Any, Any, Any]:
    """Load the engine outputs (doctor, result, coach) back into memory.

    Used by report generators (HTML/PDF/JSON) — they need the in-memory
    objects, not the DB row.
    """
    analysis = await get_analysis_by_id(db, user_id, analysis_id)
    doctor, result, coach = deserialize_engine_outputs(
        analysis.engine_doctor_bytes,
        analysis.engine_result_bytes,
        analysis.engine_coach_bytes,
    )
    return doctor, result, coach


# ---------------------------------------------------------------------------
# List / search / filter / sort
# ---------------------------------------------------------------------------

async def list_analyses(
    db: AsyncSession,
    user_id: uuid.UUID,
    page: int = 1,
    page_size: int = 20,
    sort_by: str = "created_at",
    sort_order: str = "desc",
    search: Optional[str] = None,
    only_favorites: bool = False,
    min_score: Optional[int] = None,
    max_score: Optional[int] = None,
) -> tuple[list[Analysis], int]:
    """List a user's analyses with filtering + sorting.

    Args:
      sort_by: "created_at" | "overall_score" | "filename" | "total_trades"
      sort_order: "asc" | "desc"
      search: substring match on filename + label + primary_diagnosis
      only_favorites: if True, only return favorited analyses
      min_score / max_score: filter by overall_score range
    """
    # Base filter
    filters = [
        Analysis.user_id == user_id,
        Analysis.deleted_at.is_(None),
    ]
    if search:
        pattern = f"%{search.lower()}%"
        filters.append(
            or_(
                func.lower(Analysis.filename).like(pattern),
                func.lower(func.coalesce(Analysis.label, "")).like(pattern),
                func.lower(func.coalesce(Analysis.primary_diagnosis, "")).like(pattern),
            )
        )
    if min_score is not None:
        filters.append(Analysis.overall_score >= min_score)
    if max_score is not None:
        filters.append(Analysis.overall_score <= max_score)
    if only_favorites:
        # Subquery: analyses that have a favorite row for this user
        from workspace.models import Favorite
        fav_subquery = select(Favorite.analysis_id).where(Favorite.user_id == user_id)
        filters.append(Analysis.id.in_(fav_subquery))

    # Count
    count_stmt = select(func.count(Analysis.id)).where(*filters)
    total = (await db.execute(count_stmt)).scalar_one()

    # Sort
    sort_column_map = {
        "created_at": Analysis.created_at,
        "overall_score": Analysis.overall_score,
        "filename": Analysis.filename,
        "total_trades": Analysis.total_trades,
    }
    sort_col = sort_column_map.get(sort_by, Analysis.created_at)
    order = sort_col.desc() if sort_order.lower() == "desc" else sort_col.asc()

    # Page
    offset = (page - 1) * page_size
    stmt = (
        select(Analysis)
        .where(*filters)
        .order_by(order)
        .offset(offset)
        .limit(page_size)
    )
    items = list((await db.execute(stmt)).scalars().all())
    return items, total


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

async def rename_analysis(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    new_label: str,
) -> Analysis:
    """Update the label (display name) of an analysis."""
    analysis = await get_analysis_by_id(db, user_id, analysis_id)
    analysis.label = new_label
    await db.flush()
    return analysis


# ---------------------------------------------------------------------------
# Soft delete
# ---------------------------------------------------------------------------

async def soft_delete_analysis(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
) -> None:
    """Soft-delete an analysis. Cached reports are also deleted."""
    analysis = await get_analysis_by_id(db, user_id, analysis_id)
    analysis.deleted_at = datetime.now(timezone.utc)
    # Invalidate cache (will be cascade-deleted by FK constraint)
    await db.flush()
    log.info("Soft-deleted analysis id=%s user_id=%s", analysis_id, user_id)


# ---------------------------------------------------------------------------
# Report cache
# ---------------------------------------------------------------------------

async def get_cached_report(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    format: str,  # "html" or "pdf"
) -> Optional[bytes]:
    """Return cached report bytes, or None if not cached.

    Verifies ownership via the analysis row.
    """
    # Ensure the analysis exists + belongs to the user.
    await get_analysis_by_id(db, user_id, analysis_id)

    stmt = select(AnalysisReportCache).where(
        AnalysisReportCache.analysis_id == analysis_id,
    )
    cache = (await db.execute(stmt)).scalar_one_or_none()
    if cache is None:
        return None
    if cache.cache_version != "v1":
        return None  # version mismatch — caller should regenerate

    if format == "html":
        return cache.html_bytes
    if format == "pdf":
        return cache.pdf_bytes
    return None


async def save_cached_report(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    format: str,
    data: bytes,
) -> None:
    """Cache report bytes for an analysis. Upsert semantics."""
    # Verify ownership
    await get_analysis_by_id(db, user_id, analysis_id)

    stmt = select(AnalysisReportCache).where(
        AnalysisReportCache.analysis_id == analysis_id,
    )
    cache = (await db.execute(stmt)).scalar_one_or_none()

    if cache is None:
        cache = AnalysisReportCache(
            analysis_id=analysis_id,
            cache_version="v1",
        )
        db.add(cache)

    if format == "html":
        cache.html_bytes = data
    elif format == "pdf":
        cache.pdf_bytes = data
    else:
        raise ValueError(f"Unknown report format: {format!r}")

    await db.flush()


# ---------------------------------------------------------------------------
# Stats (for dashboard)
# ---------------------------------------------------------------------------

async def count_user_analyses(db: AsyncSession, user_id: uuid.UUID) -> int:
    stmt = select(func.count(Analysis.id)).where(
        Analysis.user_id == user_id,
        Analysis.deleted_at.is_(None),
    )
    return (await db.execute(stmt)).scalar_one()


async def avg_user_score(db: AsyncSession, user_id: uuid.UUID) -> Optional[float]:
    """Average overall_score across a user's analyses. None if no analyses."""
    stmt = select(func.avg(Analysis.overall_score)).where(
        Analysis.user_id == user_id,
        Analysis.deleted_at.is_(None),
    )
    return (await db.execute(stmt)).scalar_one()
