# -*- coding: utf-8 -*-
"""
workspace/repositories package — repository pattern for DB access.

Each repository encapsulates all DB operations for one table.
Repositories are stateless; the AsyncSession is passed in per call.
"""
