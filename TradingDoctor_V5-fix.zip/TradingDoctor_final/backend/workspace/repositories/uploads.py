# -*- coding: utf-8 -*-
"""
workspace/repositories/uploads.py
---------------------------------
Phase 9 — Repository for the uploads table.

All DB operations on the `uploads` table go through this module.
Every method requires `user_id` — there is NO way to fetch another user's
uploads through this API. This is the multi-tenant isolation boundary.
"""

from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession

from api.exceptions import UploadNotFoundError
from utils.logger import get_logger
from workspace.models import Upload
from workspace.services.storage import (
    LocalStorageBackend,
    StorageBackend,
    build_upload_path,
    file_extension,
)

log = get_logger("workspace.uploads_repo")


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

async def create_upload(
    db: AsyncSession,
    user_id: uuid.UUID,
    filename: str,
    raw_bytes: bytes,
    storage_backend: Optional[StorageBackend] = None,
    label: Optional[str] = None,
) -> Upload:
    """Create a new upload record + persist the file bytes.

    The file is written via the storage backend (local FS by default).
    The DB row stores metadata only.
    """
    backend = storage_backend or LocalStorageBackend()
    upload_id = uuid.uuid4()
    storage_path = build_upload_path(str(user_id), str(upload_id), filename)
    content_hash = hashlib.sha256(raw_bytes).hexdigest()
    file_type = file_extension(filename) or "bin"

    # Persist the file FIRST — if this fails, we don't create a dangling DB row.
    await backend.save(storage_path, raw_bytes)

    upload = Upload(
        id=upload_id,
        user_id=user_id,
        filename=filename,
        size_bytes=len(raw_bytes),
        storage_path=storage_path,
        content_hash=content_hash,
        file_type=file_type,
        label=label,
    )
    db.add(upload)
    await db.flush()
    log.info(
        "Created upload id=%s user_id=%s filename=%s size=%d",
        upload_id, user_id, filename, len(raw_bytes),
    )
    return upload


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

async def get_upload_by_id(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
) -> Upload:
    """Return the upload, or raise UploadNotFoundError.

    Filters by user_id — never returns another user's upload.
    Soft-deleted uploads are excluded.
    """
    stmt = select(Upload).where(
        Upload.id == upload_id,
        Upload.user_id == user_id,
        Upload.deleted_at.is_(None),
    )
    result = await db.execute(stmt)
    upload = result.scalar_one_or_none()
    if upload is None:
        raise UploadNotFoundError(f"آپلودی با شناسه‌ی «{upload_id}» یافت نشد.")
    return upload


async def list_uploads(
    db: AsyncSession,
    user_id: uuid.UUID,
    page: int = 1,
    page_size: int = 20,
) -> tuple[list[Upload], int]:
    """List a user's uploads, newest first."""
    # Count
    count_stmt = select(func.count(Upload.id)).where(
        Upload.user_id == user_id,
        Upload.deleted_at.is_(None),
    )
    total = (await db.execute(count_stmt)).scalar_one()

    # Page
    offset = (page - 1) * page_size
    stmt = (
        select(Upload)
        .where(Upload.user_id == user_id, Upload.deleted_at.is_(None))
        .order_by(Upload.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    items = list((await db.execute(stmt)).scalars().all())
    return items, total


async def get_upload_bytes(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    storage_backend: Optional[StorageBackend] = None,
) -> tuple[Upload, bytes]:
    """Return the upload record + the raw file bytes.

    Convenience method — loads both in one call (most callers need both).
    """
    upload = await get_upload_by_id(db, user_id, upload_id)
    backend = storage_backend or LocalStorageBackend()
    raw_bytes = await backend.load(upload.storage_path)
    return upload, raw_bytes


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

async def rename_upload(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    new_label: str,
) -> Upload:
    """Update the label (display name) of an upload. Does NOT change the file."""
    upload = await get_upload_by_id(db, user_id, upload_id)
    upload.label = new_label
    await db.flush()
    return upload


# ---------------------------------------------------------------------------
# Delete (soft)
# ---------------------------------------------------------------------------

async def soft_delete_upload(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
) -> None:
    """Soft-delete an upload. The file on disk is NOT removed (retention).

    Hard delete + file removal happens in a separate cleanup job (Phase 11).
    """
    upload = await get_upload_by_id(db, user_id, upload_id)
    upload.deleted_at = datetime.now(timezone.utc)
    await db.flush()
    log.info("Soft-deleted upload id=%s user_id=%s", upload_id, user_id)


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

async def count_user_uploads(db: AsyncSession, user_id: uuid.UUID) -> int:
    """Total non-deleted uploads for a user."""
    stmt = select(func.count(Upload.id)).where(
        Upload.user_id == user_id,
        Upload.deleted_at.is_(None),
    )
    return (await db.execute(stmt)).scalar_one()


async def total_user_upload_bytes(db: AsyncSession, user_id: uuid.UUID) -> int:
    """Total bytes used by a user's uploads (for quota tracking)."""
    stmt = select(func.sum(Upload.size_bytes)).where(
        Upload.user_id == user_id,
        Upload.deleted_at.is_(None),
    )
    result = (await db.execute(stmt)).scalar_one()
    return int(result or 0)
