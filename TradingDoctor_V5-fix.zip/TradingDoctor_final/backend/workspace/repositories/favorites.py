# -*- coding: utf-8 -*-
"""
workspace/repositories/favorites.py
-----------------------------------
Phase 9 — Repository for the favorites table.

A user can star an analysis to surface it at the top of their workspace.
One favorite per (user, analysis) — enforced by unique constraint.
"""

from __future__ import annotations

import uuid
from typing import Optional

from sqlalchemy import select, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from api.exceptions import AnalysisNotFoundError, FavoriteNotFoundError
from utils.logger import get_logger
from workspace.models import Favorite, Analysis
from workspace.repositories.analyses import get_analysis_by_id

log = get_logger("workspace.favorites_repo")


# ---------------------------------------------------------------------------
# Add / remove
# ---------------------------------------------------------------------------

async def add_favorite(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
    note: Optional[str] = None,
) -> Favorite:
    """Mark an analysis as favorite. Idempotent (returns existing if already fav)."""
    # Verify the analysis belongs to the user.
    await get_analysis_by_id(db, user_id, analysis_id)

    # Check existing
    stmt = select(Favorite).where(
        Favorite.user_id == user_id,
        Favorite.analysis_id == analysis_id,
    )
    existing = (await db.execute(stmt)).scalar_one_or_none()
    if existing is not None:
        # Update note if provided
        if note is not None:
            existing.note = note
            await db.flush()
        return existing

    fav = Favorite(
        user_id=user_id,
        analysis_id=analysis_id,
        note=note,
    )
    db.add(fav)
    await db.flush()
    log.info("Added favorite user_id=%s analysis_id=%s", user_id, analysis_id)
    return fav


async def remove_favorite(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
) -> None:
    """Remove a favorite. Raises FavoriteNotFoundError if not favorited."""
    stmt = select(Favorite).where(
        Favorite.user_id == user_id,
        Favorite.analysis_id == analysis_id,
    )
    fav = (await db.execute(stmt)).scalar_one_or_none()
    if fav is None:
        raise FavoriteNotFoundError("این تحلیل در علاقه‌مندی‌های شما نیست.")
    await db.delete(fav)
    await db.flush()
    log.info("Removed favorite user_id=%s analysis_id=%s", user_id, analysis_id)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

async def is_favorite(
    db: AsyncSession,
    user_id: uuid.UUID,
    analysis_id: uuid.UUID,
) -> bool:
    stmt = select(Favorite.id).where(
        Favorite.user_id == user_id,
        Favorite.analysis_id == analysis_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none() is not None


async def list_favorites(
    db: AsyncSession,
    user_id: uuid.UUID,
    page: int = 1,
    page_size: int = 20,
) -> tuple[list[Favorite], int]:
    """List a user's favorited analyses, newest favorite first."""
    count_stmt = select(func.count(Favorite.id)).where(Favorite.user_id == user_id)
    total = (await db.execute(count_stmt)).scalar_one()

    offset = (page - 1) * page_size
    stmt = (
        select(Favorite)
        .where(Favorite.user_id == user_id)
        .order_by(Favorite.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    items = list((await db.execute(stmt)).scalars().all())
    return items, total


async def count_favorites(db: AsyncSession, user_id: uuid.UUID) -> int:
    stmt = select(func.count(Favorite.id)).where(Favorite.user_id == user_id)
    return (await db.execute(stmt)).scalar_one()
