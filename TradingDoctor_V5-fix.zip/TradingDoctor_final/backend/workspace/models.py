# -*- coding: utf-8 -*-
"""
workspace/models.py
-------------------
Phase 9 — ORM models for the persistent workspace subsystem.

Tables added:
  - uploads               (raw uploaded trade-log files, per user)
  - analyses              (analysis results, per user — pickled engine output)
  - analysis_report_cache (cached HTML/PDF renders, keyed by analysis_id)
  - favorites             (user's starred analyses, one-to-many)

Design:
  - UUID primary keys (UUIDPkMixin from db.models)
  - Timestamps with timezone (TimestampMixin)
  - Soft-delete on uploads + analyses (deletion is reversible)
  - Per-user isolation: every table has `user_id` FK + index
  - Cached analysis output stored as LONGBLOB (pickle) — the engine's
    `doctor` (DataFrame), `result` (FullResult), `coach` (dict) are not
    JSON-serializable without losing the engine contract, so we pickle.
    Pickle is safe here because we ONLY store our own engine output
    (never user-controlled data structures).
  - Content hash on uploads (SHA-256) for deduplication potential.
  - Cached HTML/PDF reports stored as bytes for fast retrieval.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.base import Base
from db.models import TimestampMixin, UUIDPkMixin, SoftDeleteMixin


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

class Upload(UUIDPkMixin, TimestampMixin, SoftDeleteMixin, Base):
    """A raw trade-log file uploaded by a user.

    The file bytes live on disk (or S3); only metadata is in the DB.
    `storage_path` is a relative path under the storage backend root —
    the backend resolves it to an absolute location at read time.
    """

    __tablename__ = "uploads"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Original filename as the user provided it (sanitized: basename only).
    filename: Mapped[str] = mapped_column(String(255), nullable=False)

    # Size of the raw upload in bytes (for quota tracking + display).
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)

    # Storage path (relative to backend root).
    # e.g. "uploads/{user_id}/{upload_id}_trades.csv"
    storage_path: Mapped[str] = mapped_column(String(512), nullable=False)

    # SHA-256 of the file content (for dedup + integrity check).
    content_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)

    # File extension, lowercased without dot (csv, xlsx, etc.).
    file_type: Mapped[str] = mapped_column(String(10), nullable=False)

    # Optional user-supplied label for the upload (rename from filename).
    label: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Relationship: one upload → many analyses (re-analyzing with different LLMs).
    analyses: Mapped[list["Analysis"]] = relationship(
        "Analysis",
        back_populates="upload",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        Index("ix_uploads_user_created", "user_id", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<Upload id={self.id} user_id={self.user_id} filename={self.filename!r}>"


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

class Analysis(UUIDPkMixin, TimestampMixin, SoftDeleteMixin, Base):
    """A single analysis run on an upload.

    Stores the pickled outputs of `core.service.analyze_dataframe`:
      - `engine_doctor_bytes`  → pickle of `doctor` (BehaviorEngine instance with df)
      - `engine_result_bytes`  → pickle of `result` (FullResult dataclass)
      - `engine_coach_bytes`   → pickle of `coach` (dict from CoachingEngine)

    These are loaded back into memory when the user requests the report.
    Pickle is intentional: the engine's outputs are not JSON-serializable
    without losing the engine contract. We ONLY store our own engine
    output — never user-supplied structures — so pickle is safe here.

    Cached HTML/PDF renders live in `AnalysisReportCache` for fast retrieval.
    """

    __tablename__ = "analyses"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    upload_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("uploads.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Snapshot of filename at analysis time (in case upload is renamed later).
    filename: Mapped[str] = mapped_column(String(255), nullable=False)

    # LLM provider used (gemini/openai/claude/none).
    llm_provider: Mapped[str] = mapped_column(String(20), nullable=False, default="none")

    # Number of trades analyzed (cached for fast history listing).
    total_trades: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Overall discipline score (cached for sorting + dashboard).
    overall_score: Mapped[float] = mapped_column(Integer, nullable=False, default=0)
    # Note: stored as Integer (0-100) for efficient sorting; float not needed
    # at this layer since the engine's discipline_score is always int-valued.

    # Primary diagnosis (cached for history listing).
    primary_diagnosis: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Data quality warning count (cached for history listing).
    data_quality_warning_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
    )

    # Pickled engine outputs (LONGBLOB in MySQL, BYTEA in Postgres).
    # Stored together so they can be loaded in one query.
    engine_doctor_bytes: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    engine_result_bytes: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    engine_coach_bytes: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)

    # Optional user-supplied label for the analysis (rename from auto-generated).
    label: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Relationships
    upload: Mapped["Upload"] = relationship("Upload", back_populates="analyses")
    favorites: Mapped[list["Favorite"]] = relationship(
        "Favorite",
        back_populates="analysis",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    report_cache: Mapped[Optional["AnalysisReportCache"]] = relationship(
        "AnalysisReportCache",
        back_populates="analysis",
        cascade="all, delete-orphan",
        uselist=False,
        lazy="selectin",
    )

    __table_args__ = (
        Index("ix_analyses_user_created", "user_id", "created_at"),
        Index("ix_analyses_user_score", "user_id", "overall_score"),
        Index("ix_analyses_upload", "upload_id"),
    )

    def __repr__(self) -> str:
        return f"<Analysis id={self.id} user_id={self.user_id} score={self.overall_score}>"


# ---------------------------------------------------------------------------
# AnalysisReportCache
# ---------------------------------------------------------------------------

class AnalysisReportCache(UUIDPkMixin, TimestampMixin, Base):
    """Cached HTML/PDF renders for an analysis.

    Generated on first request for /report.html or /report.pdf, then
    cached here. Invalidated (deleted) when the analysis is updated.
    """

    __tablename__ = "analysis_report_cache"

    analysis_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("analyses.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )

    html_bytes: Mapped[Optional[bytes]] = mapped_column(LargeBinary, nullable=True)
    pdf_bytes: Mapped[Optional[bytes]] = mapped_column(LargeBinary, nullable=True)

    # Cache key — version of the renderer. If we upgrade report templates,
    # bump this version and old caches are automatically invalidated.
    cache_version: Mapped[str] = mapped_column(String(20), nullable=False, default="v1")

    analysis: Mapped["Analysis"] = relationship("Analysis", back_populates="report_cache")

    def __repr__(self) -> str:
        return f"<AnalysisReportCache analysis_id={self.analysis_id} version={self.cache_version}>"


# ---------------------------------------------------------------------------
# Favorite
# ---------------------------------------------------------------------------

class Favorite(UUIDPkMixin, TimestampMixin, Base):
    """A user's starred analysis.

    Used to surface frequently-accessed analyses at the top of the workspace.
    One user can favorite an analysis only once (unique constraint).
    """

    __tablename__ = "favorites"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    analysis_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("analyses.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Optional note the user can attach to the favorite.
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    analysis: Mapped["Analysis"] = relationship("Analysis", back_populates="favorites")

    __table_args__ = (
        # One favorite per (user, analysis) — prevents duplicates.
        UniqueConstraint("user_id", "analysis_id", name="uq_favorites_user_analysis"),
    )

    def __repr__(self) -> str:
        return f"<Favorite user_id={self.user_id} analysis_id={self.analysis_id}>"


# ---------------------------------------------------------------------------
# AnalysisJob (Phase 11 — async analysis runs via Celery)
# ---------------------------------------------------------------------------

class AnalysisJob(UUIDPkMixin, TimestampMixin, Base):
    """A background analysis job (Phase 11 — async POST /analyses).

    When Celery is enabled, POST /analyses creates an AnalysisJob row +
    dispatches a Celery task, then returns 202 + job_id immediately.
    The client polls GET /analyses/jobs/{job_id} until status=completed.

    Lifecycle:
      pending → running → completed (analysis_id set)
                         → failed (error_message set)

    Jobs are retained for 30 days after completion for audit, then purged
    by the cleanup task.
    """

    __tablename__ = "analysis_jobs"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    upload_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("uploads.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # The analysis produced by this job (None until completed).
    analysis_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("analyses.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # LLM provider requested
    llm_provider: Mapped[str] = mapped_column(String(20), nullable=False, default="none")

    # Job status: pending | running | completed | failed
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending", index=True,
    )

    # Celery task ID (for correlation with worker logs)
    celery_task_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)

    # Cached result fields (populated when completed, for fast polling)
    total_trades: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    overall_score: Mapped[Optional[float]] = mapped_column(Integer, nullable=True)

    # Error message (populated when failed)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps for lifecycle tracking
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    finished_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_analysis_jobs_user_status", "user_id", "status"),
        Index("ix_analysis_jobs_created", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<AnalysisJob id={self.id} user_id={self.user_id} status={self.status}>"
