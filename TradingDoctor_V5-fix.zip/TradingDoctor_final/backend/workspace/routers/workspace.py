# -*- coding: utf-8 -*-
"""
workspace/routers/workspace.py
------------------------------
Phase 9 — Workspace management endpoints.

These endpoints sit ON TOP of the existing Phase 3 endpoints (uploads/
analyses/reports/history). They add:
  - GET    /workspace/summary                  — dashboard KPIs
  - GET    /workspace/uploads                  — paginated upload list
  - GET    /workspace/uploads/{id}             — upload detail
  - PATCH  /workspace/uploads/{id}             — rename upload
  - DELETE /workspace/uploads/{id}             — soft-delete upload
  - GET    /workspace/analyses                 — paginated + filtered + sorted analysis list
  - PATCH  /workspace/analyses/{id}            — rename analysis
  - DELETE /workspace/analyses/{id}            — soft-delete analysis
  - POST   /workspace/analyses/{id}/favorite   — mark as favorite
  - DELETE /workspace/analyses/{id}/favorite   — remove favorite
  - GET    /workspace/favorites                — list favorited analyses

All endpoints require authentication (get_current_user).
All endpoints scope by user_id — a user can only see/modify their own data.
"""

from __future__ import annotations

import uuid
from typing import Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import enforce_rate_limit, verify_api_key
from auth.dependencies import get_current_user
from auth.models import User
from billing.dependencies import get_user_plan
from db.base import get_db
from utils.logger import get_logger
from workspace.models import Favorite
from workspace.repositories.analyses import (
    avg_user_score,
    count_user_analyses,
    get_analysis_by_id,
    list_analyses,
    rename_analysis,
    soft_delete_analysis,
)
from workspace.repositories.favorites import (
    add_favorite,
    count_favorites,
    is_favorite,
    list_favorites,
    remove_favorite,
)
from workspace.repositories.uploads import (
    count_user_uploads,
    get_upload_by_id,
    list_uploads,
    rename_upload,
    soft_delete_upload,
    total_user_upload_bytes,
)
from workspace.schemas import (
    AnalysisItem,
    AnalysisListResponse,
    FavoriteItem,
    FavoriteListResponse,
    FavoriteRequest,
    RenameAnalysisRequest,
    RenameUploadRequest,
    UploadDetailResponse,
    UploadItem,
    UploadListResponse,
    WorkspaceSummaryResponse,
)

log = get_logger("workspace.routers")

router = APIRouter(
    prefix="/workspace",
    tags=["Workspace"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


# ---------------------------------------------------------------------------
# Dashboard summary
# ---------------------------------------------------------------------------

@router.get(
    "/summary",
    response_model=WorkspaceSummaryResponse,
    summary="خلاصه‌ی داشبورد کاربر",
    description=(
        "شاخص‌های کلیدی حساب کاربر: تعداد آپلودها، تحلیل‌ها، علاقه‌مندی‌ها، "
        "حجم کل، میانگین امتیاز، آخرین تحلیل، بهترین/بدترین امتیاز."
    ),
)
async def get_workspace_summary(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> WorkspaceSummaryResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    from sqlalchemy import select, func
    from workspace.models import Analysis

    total_uploads = await count_user_uploads(db, user.id)
    total_analyses = await count_user_analyses(db, user.id)
    total_favorites = await count_favorites(db, user.id)
    total_upload_bytes = await total_user_upload_bytes(db, user.id)
    average_score = await avg_user_score(db, user.id)

    # Latest analysis timestamp + best/worst scores
    stmt = select(
        func.max(Analysis.created_at),
        func.max(Analysis.overall_score),
        func.min(Analysis.overall_score),
    ).where(
        Analysis.user_id == user.id,
        Analysis.deleted_at.is_(None),
    )
    row = (await db.execute(stmt)).one()
    latest_at, best_score, worst_score = row

    return WorkspaceSummaryResponse(
        total_uploads=total_uploads,
        total_analyses=total_analyses,
        total_favorites=total_favorites,
        total_upload_bytes=total_upload_bytes,
        average_score=float(average_score) if average_score is not None else None,
        latest_analysis_at=latest_at,
        best_analysis_score=float(best_score) if best_score is not None else None,
        worst_analysis_score=float(worst_score) if worst_score is not None else None,
    )


# ---------------------------------------------------------------------------
# Uploads
# ---------------------------------------------------------------------------

@router.get(
    "/uploads",
    response_model=UploadListResponse,
    summary="فهرست آپلودهای کاربر",
)
async def list_user_uploads(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UploadListResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    uploads, total = await list_uploads(db, user.id, page, page_size)
    items = [
        UploadItem(
            upload_id=str(u.id),
            filename=u.filename,
            size_bytes=u.size_bytes,
            file_type=u.file_type,
            label=u.label,
            content_hash=u.content_hash,
            created_at=u.created_at,
        )
        for u in uploads
    ]
    return UploadListResponse(items=items, total=total, page=page, page_size=page_size)


@router.get(
    "/uploads/{upload_id}",
    response_model=UploadDetailResponse,
    summary="جزئیات یک آپلود",
)
async def get_upload_detail(
    upload_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UploadDetailResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    upload = await get_upload_by_id(db, user.id, upload_id)

    # Count analyses on this upload
    from sqlalchemy import select, func
    from workspace.models import Analysis
    stmt = select(func.count(Analysis.id)).where(
        Analysis.upload_id == upload.id,
        Analysis.deleted_at.is_(None),
    )
    analysis_count = (await db.execute(stmt)).scalar_one()

    return UploadDetailResponse(
        upload_id=str(upload.id),
        filename=upload.filename,
        size_bytes=upload.size_bytes,
        file_type=upload.file_type,
        label=upload.label,
        content_hash=upload.content_hash,
        created_at=upload.created_at,
        analysis_count=analysis_count,
    )


@router.patch(
    "/uploads/{upload_id}",
    response_model=UploadDetailResponse,
    summary="تغییر نام آپلود",
)
async def rename_user_upload(
    upload_id: uuid.UUID,
    body: RenameUploadRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UploadDetailResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    upload = await rename_upload(db, user.id, upload_id, body.label)
    await db.commit()
    return UploadDetailResponse(
        upload_id=str(upload.id),
        filename=upload.filename,
        size_bytes=upload.size_bytes,
        file_type=upload.file_type,
        label=upload.label,
        content_hash=upload.content_hash,
        created_at=upload.created_at,
        analysis_count=0,  # not fetching for rename response
    )


@router.delete(
    "/uploads/{upload_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="حذف آپلود",
    description=(
        "حذف نرم آپلود. فایل روی دیسک تا پاک‌سازی دوره‌ای نگه داشته می‌شود "
        "(برای بازیابی در صورت اشتباه). تمام تحلیل‌های مرتبط هم soft-delete می‌شوند."
    ),
)
async def delete_user_upload(
    upload_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    # Verify the upload belongs to the user before soft-deleting analyses
    await get_upload_by_id(db, user.id, upload_id)

    # Soft-delete all analyses on this upload
    from sqlalchemy import update
    from workspace.models import Analysis
    stmt = (
        update(Analysis)
        .where(
            Analysis.upload_id == upload_id,
            Analysis.user_id == user.id,
            Analysis.deleted_at.is_(None),
        )
        .values(deleted_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc))
    )
    await db.execute(stmt)

    await soft_delete_upload(db, user.id, upload_id)
    await db.commit()


# ---------------------------------------------------------------------------
# Analyses
# ---------------------------------------------------------------------------

@router.get(
    "/analyses",
    response_model=AnalysisListResponse,
    summary="فهرست تحلیل‌های کاربر",
    description=(
        "فهرست صفحه‌بندی‌شده با قابلیت جستجو، مرتب‌سازی، و فیلتر بر اساس "
        "امتیاز و علاقه‌مندی."
    ),
)
async def list_user_analyses(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    sort_by: str = Query("created_at", pattern="^(created_at|overall_score|filename|total_trades)$"),
    sort_order: str = Query("desc", pattern="^(asc|desc)$"),
    search: Optional[str] = Query(None, max_length=255),
    only_favorites: bool = Query(False),
    min_score: Optional[int] = Query(None, ge=0, le=100),
    max_score: Optional[int] = Query(None, ge=0, le=100),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    plan=Depends(get_user_plan),
) -> AnalysisListResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    # Phase 12 audit fix (C5): enforce allows_history_search feature gate.
    # Free-tier users (allows_history_search=False) cannot use the search param.
    if search and not plan.allows_history_search:
        from auth.exceptions import TierRequiredError
        raise TierRequiredError(
            "جستجوی تاریخچه در طرح شما فعال نیست. برای ارتقا، به تنظیمات اشتراک مراجعه کنید.",
            details={
                "limit_type": "feature_gate",
                "required_feature": "history_search",
                "current_tier": plan.tier.value,
            },
        )

    analyses, total = await list_analyses(
        db, user.id, page, page_size, sort_by, sort_order,
        search, only_favorites, min_score, max_score,
    )

    # Batch-check favorites for efficiency (1 query instead of N).
    fav_ids: set[uuid.UUID] = set()
    if analyses:
        from sqlalchemy import select
        stmt = select(Favorite.analysis_id).where(
            Favorite.user_id == user.id,
            Favorite.analysis_id.in_([a.id for a in analyses]),
        )
        fav_ids = set((await db.execute(stmt)).scalars().all())

    items = [
        AnalysisItem(
            analysis_id=str(a.id),
            upload_id=str(a.upload_id),
            filename=a.filename,
            label=a.label,
            created_at=a.created_at,
            total_trades=a.total_trades,
            overall_score=float(a.overall_score),
            primary_diagnosis=a.primary_diagnosis or "N/A",
            data_quality_warning_count=a.data_quality_warning_count,
            is_favorite=a.id in fav_ids,
            llm_provider=a.llm_provider,
        )
        for a in analyses
    ]
    return AnalysisListResponse(items=items, total=total, page=page, page_size=page_size)


@router.patch(
    "/analyses/{analysis_id}",
    response_model=AnalysisItem,
    summary="تغییر نام تحلیل",
)
async def rename_user_analysis(
    analysis_id: uuid.UUID,
    body: RenameAnalysisRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AnalysisItem:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    analysis = await rename_analysis(db, user.id, analysis_id, body.label)
    is_fav = await is_favorite(db, user.id, analysis.id)
    await db.commit()
    return AnalysisItem(
        analysis_id=str(analysis.id),
        upload_id=str(analysis.upload_id),
        filename=analysis.filename,
        label=analysis.label,
        created_at=analysis.created_at,
        total_trades=analysis.total_trades,
        overall_score=float(analysis.overall_score),
        primary_diagnosis=analysis.primary_diagnosis or "N/A",
        data_quality_warning_count=analysis.data_quality_warning_count,
        is_favorite=is_fav,
        llm_provider=analysis.llm_provider,
    )


@router.delete(
    "/analyses/{analysis_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="حذف تحلیل",
    description="حذف نرم تحلیل. در صورت بازیابی، با support تماس بگیرید."
)
async def delete_user_analysis(
    analysis_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    await soft_delete_analysis(db, user.id, analysis_id)
    await db.commit()


# ---------------------------------------------------------------------------
# Favorites
# ---------------------------------------------------------------------------

@router.post(
    "/analyses/{analysis_id}/favorite",
    status_code=status.HTTP_201_CREATED,
    summary="افزودن به علاقه‌مندی‌ها",
    description="یک تحلیل را به علاقه‌مندی‌های کاربر اضافه می‌کند. idempotent است.",
)
async def add_to_favorites(
    analysis_id: uuid.UUID,
    body: FavoriteRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    fav = await add_favorite(db, user.id, analysis_id, body.note)
    await db.commit()
    return {
        "analysis_id": str(fav.analysis_id),
        "favorited_at": fav.created_at.isoformat() if fav.created_at else None,
        "note": fav.note,
    }


@router.delete(
    "/analyses/{analysis_id}/favorite",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="حذف از علاقه‌مندی‌ها",
)
async def remove_from_favorites(
    analysis_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    await remove_favorite(db, user.id, analysis_id)
    await db.commit()


@router.get(
    "/favorites",
    response_model=FavoriteListResponse,
    summary="فهرست علاقه‌مندی‌های کاربر",
)
async def list_user_favorites(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> FavoriteListResponse:
    if db is None:
        from auth.exceptions import AuthError
        raise AuthError("Database is required but is not configured.")

    favs, total = await list_favorites(db, user.id, page, page_size)

    # Eager-load the related analyses in ONE query to avoid N+1 + lazy-load
    # issues after session close.
    from sqlalchemy import select
    from workspace.models import Analysis
    if favs:
        analysis_ids = [f.analysis_id for f in favs]
        stmt = select(Analysis).where(Analysis.id.in_(analysis_ids))
        analysis_map = {
            a.id: a for a in (await db.execute(stmt)).scalars().all()
        }
    else:
        analysis_map = {}

    items = [
        FavoriteItem(
            analysis_id=str(f.analysis_id),
            filename=analysis_map[f.analysis_id].filename if f.analysis_id in analysis_map else "",
            label=analysis_map[f.analysis_id].label if f.analysis_id in analysis_map else None,
            overall_score=float(analysis_map[f.analysis_id].overall_score) if f.analysis_id in analysis_map else 0,
            primary_diagnosis=(analysis_map[f.analysis_id].primary_diagnosis if f.analysis_id in analysis_map else "N/A") or "N/A",
            favorited_at=f.created_at,
            note=f.note,
        )
        for f in favs
    ]
    return FavoriteListResponse(items=items, total=total, page=page, page_size=page_size)
