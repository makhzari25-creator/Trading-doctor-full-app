# -*- coding: utf-8 -*-
"""
workspace
---------
Phase 9 — Persistent SaaS Workspace for TradingDoctor users.

Converts the in-memory `AnalysisStore` (Phase 3) into a DB-backed
repository pattern. Every user now has their own private workspace:
uploads, analyses, favorites — all scoped by `user_id`.

Public API:
  - Models:        workspace.models.Upload, Analysis, Favorite, AnalysisReportCache
  - Repositories:  workspace.repositories.uploads.UploadRepository,
                   workspace.repositories.analyses.AnalysisRepository,
                   workspace.repositories.favorites.FavoriteRepository
  - Services:      workspace.services.storage (file storage abstraction),
                   workspace.services.serialization (pickle→bytes for DB)
  - Routers:       workspace.routers.workspace (summary + favorites)

Design rules (carry forward from Phases 7.5 + 8):
  - Frozen V23 engine (engines/*) is never imported by anything in workspace/.
  - The engine contract is preserved: `core.service.analyze_dataframe(df, llm_provider)`
    is still the only entry point. Repository just persists its outputs.
  - All DB I/O is async (asyncpg + SQLAlchemy 2.0 async).
  - File storage is pluggable: local FS today, S3 in Phase 11+.
  - Existing API endpoint URLs and response shapes are preserved — only
    the persistence backend changes. Tests written in Phase 3 continue to pass.
  - Multi-tenant isolation: every query filters by `user_id`.
"""

__all__: list[str] = []
