# -*- coding: utf-8 -*-
"""
workspace/services/serialization.py
-----------------------------------
Phase 9 — Serialization helpers for engine outputs.

The V23 engine's `doctor` (BehaviorEngine with embedded DataFrame),
`result` (FullResult dataclass), and `coach` (dict) are NOT JSON-serializable
without losing the engine contract. We pickle them for DB storage.

SECURITY (Phase 12 audit fix C3):
  Pickle.loads on DB-stored bytes is a known RCE vector if the DB is compromised.
  We mitigate by using a RESTRICTED Unpickler with an allow-list of safe classes.
  Only classes from pandas, numpy, engines.*, and builtins are permitted.

  Long-term plan (v2.0): replace pickle with structured JSON serialization.
  The engine's `result.to_dict()` and `coach` are already JSON-serializable;
  only the embedded DataFrame needs special handling (can be re-loaded from
  the original upload bytes + a small JSON manifest).
"""

from __future__ import annotations

import io
import pickle
import zlib
from typing import Any, Tuple

from utils.logger import get_logger

log = get_logger("workspace.serialization")


# ---------------------------------------------------------------------------
# Restricted Unpickler — security mitigation for pickle RCE
# ---------------------------------------------------------------------------

# Allow-list of modules whose classes are permitted in the pickle stream.
# Anything outside this list raises UnpicklingError (not silently loaded).
_ALLOWED_MODULE_PREFIXES = (
    "pandas.",
    "pandas.core.",
    "pandas._libs.",
    "numpy.",
    "numpy.core.",
    "engines.",       # the frozen V23 engine's own classes
    "datetime",
    "decimal",
    "collections",
    "collections.abc",
    "builtins",
)


class _RestrictedUnpickler(pickle.Unpickler):
    """Unpickler that only allows a whitelist of safe modules.

    Phase 12 audit fix (C3): prevents arbitrary code execution via pickle
    if the DB is compromised. Only pandas/numpy/engines/builtins classes
    can be reconstructed.
    """

    def find_class(self, module: str, name: str) -> Any:
        # Check if the module is in the allow-list
        full_name = f"{module}.{name}" if module else name
        for prefix in _ALLOWED_MODULE_PREFIXES:
            if module == prefix.rstrip(".") or module.startswith(prefix):
                return super().find_class(module, name)
        # Also allow bare module names (e.g. "datetime", "decimal")
        if module in ("datetime", "decimal", "collections", "builtins"):
            return super().find_class(module, name)
        raise pickle.UnpicklingError(
            f"Security: refused to unpickle class {full_name!r} — "
            f"module {module!r} not in allow-list. "
            f"This protects against pickle-based RCE if the DB is compromised."
        )


# ---------------------------------------------------------------------------
# Engine output (de)serialization
# ---------------------------------------------------------------------------

def serialize_engine_outputs(
    doctor: Any,
    result: Any,
    coach: Any,
) -> Tuple[bytes, bytes, bytes]:
    """Serialize the three engine outputs to compressed pickle bytes.

    Returns (doctor_bytes, result_bytes, coach_bytes) — all compressed
    with zlib to reduce DB storage footprint (DataFrames compress well).

    Pickle protocol 4 (Python 3.8+) for compatibility + performance.
    """
    doctor_bytes = _pickle_zlib(doctor)
    result_bytes = _pickle_zlib(result)
    coach_bytes = _pickle_zlib(coach)
    log.debug(
        "Serialized engine outputs: doctor=%dB result=%dB coach=%dB",
        len(doctor_bytes), len(result_bytes), len(coach_bytes),
    )
    return doctor_bytes, result_bytes, coach_bytes


def deserialize_engine_outputs(
    doctor_bytes: bytes,
    result_bytes: bytes,
    coach_bytes: bytes,
) -> Tuple[Any, Any, Any]:
    """Reverse of serialize_engine_outputs.

    Returns (doctor, result, coach) — reconstructed in memory.

    Uses _RestrictedUnpickler to mitigate pickle RCE risk (Phase 12 fix C3).
    """
    doctor = _unpickle_zlib(doctor_bytes)
    result = _unpickle_zlib(result_bytes)
    coach = _unpickle_zlib(coach_bytes)
    return doctor, result, coach


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _pickle_zlib(obj: Any) -> bytes:
    """Pickle + zlib compress."""
    raw = pickle.dumps(obj, protocol=4)
    return zlib.compress(raw, level=6)


def _unpickle_zlib(data: bytes) -> Any:
    """zlib decompress + unpickle with restricted allow-list.

    Phase 12 audit fix (C3): uses _RestrictedUnpickler instead of pickle.loads
    to prevent arbitrary code execution if the DB is compromised.
    Only pandas/numpy/engines/builtins classes can be reconstructed.
    """
    raw = zlib.decompress(data)
    return _RestrictedUnpickler(io.BytesIO(raw)).load()
