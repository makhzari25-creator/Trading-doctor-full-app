# -*- coding: utf-8 -*-
"""
workspace/services/storage.py
-----------------------------
Phase 9 — File storage abstraction.

Backends:
  - LocalStorageBackend (default): writes to a local directory under API_DATA_DIR.
    This remains the default in dev — STORAGE_BACKEND is only set to "s3" in
    staging/production (see docker/deploy config), so local dev never needs
    AWS credentials.
  - S3StorageBackend: writes to an S3 bucket via boto3 (see requirements.txt).
    All boto3 calls run in a threadpool (`run_in_threadpool`) since boto3 is
    synchronous and would otherwise block the async event loop.

Both backends expose the same async API:
  - save(path: str, data: bytes) -> str   (returns final storage_path)
  - load(path: str) -> bytes
  - delete(path: str) -> bool
  - exists(path: str) -> bool

Path semantics:
  - `path` is a RELATIVE path under the backend root.
  - For local FS, this is relative to API_DATA_DIR/uploads/.
  - For S3, this is the object key under STORAGE_S3_PREFIX.

The active backend is chosen by STORAGE_BACKEND env var.
"""

from __future__ import annotations

import abc
import os
import shutil
from typing import Optional

from starlette.concurrency import run_in_threadpool

from api import config as api_config
from utils.logger import get_logger

log = get_logger("workspace.storage")


# ---------------------------------------------------------------------------
# Backend selection
# ---------------------------------------------------------------------------

def get_storage_backend() -> "StorageBackend":
    """Return the configured storage backend instance.

    Selection by STORAGE_BACKEND env var:
      - "local" (default)
      - "s3"    (Phase 11+; raises NotImplementedError if boto3 not installed)
    """
    backend_name = os.getenv("STORAGE_BACKEND", "local").strip().lower()

    if backend_name == "local":
        return LocalStorageBackend()
    if backend_name == "s3":
        return S3StorageBackend()

    log.warning("Unknown STORAGE_BACKEND=%r, falling back to local", backend_name)
    return LocalStorageBackend()


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class StorageBackend(abc.ABC):
    """Base class for all storage backends."""

    @abc.abstractmethod
    async def save(self, path: str, data: bytes) -> str:
        """Save bytes to the backend. Returns the final storage_path."""
        raise NotImplementedError

    @abc.abstractmethod
    async def load(self, path: str) -> bytes:
        """Load bytes from the backend. Raises FileNotFoundError if missing."""
        raise NotImplementedError

    @abc.abstractmethod
    async def delete(self, path: str) -> bool:
        """Delete a file. Returns True if deleted, False if not found."""
        raise NotImplementedError

    @abc.abstractmethod
    async def exists(self, path: str) -> bool:
        """Return True if the file exists."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Local filesystem backend
# ---------------------------------------------------------------------------

class LocalStorageBackend(StorageBackend):
    """Writes files to a local directory under API_DATA_DIR/uploads/.

    Path semantics:
      - `path` argument is RELATIVE to the uploads root.
      - e.g. "user_id/upload_id_trades.csv" → {API_DATA_DIR}/uploads/user_id/upload_id_trades.csv
    """

    def __init__(self):
        self.root = os.path.join(api_config.API_DATA_DIR, "uploads")
        os.makedirs(self.root, exist_ok=True)

    def _resolve(self, path: str) -> str:
        """Resolve a relative path to an absolute filesystem path.

        SECURITY: explicitly reject any path that escapes the root via ../
        or absolute paths. Path traversal is the #1 storage security bug.
        """
        if not path:
            raise ValueError("Path cannot be empty.")
        if os.path.isabs(path):
            raise ValueError(f"Absolute paths not allowed: {path!r}")
        absolute = os.path.normpath(os.path.join(self.root, path))
        # Verify the resolved path is still under self.root.
        if not absolute.startswith(os.path.normpath(self.root) + os.sep):
            raise ValueError(f"Path escapes storage root: {path!r}")
        return absolute

    async def save(self, path: str, data: bytes) -> str:
        absolute = self._resolve(path)
        os.makedirs(os.path.dirname(absolute), exist_ok=True)
        with open(absolute, "wb") as f:
            f.write(data)
        log.debug("Saved %d bytes to %s", len(data), path)
        return path

    async def load(self, path: str) -> bytes:
        absolute = self._resolve(path)
        if not os.path.exists(absolute):
            raise FileNotFoundError(f"Storage path not found: {path!r}")
        with open(absolute, "rb") as f:
            return f.read()

    async def delete(self, path: str) -> bool:
        absolute = self._resolve(path)
        if not os.path.exists(absolute):
            return False
        try:
            os.remove(absolute)
            log.debug("Deleted %s", path)
            return True
        except OSError as exc:
            log.warning("Failed to delete %s: %s", path, exc)
            return False

    async def exists(self, path: str) -> bool:
        absolute = self._resolve(path)
        return os.path.exists(absolute)


# ---------------------------------------------------------------------------
# S3 backend (stub — full implementation in Phase 11)
# ---------------------------------------------------------------------------

class S3StorageBackend(StorageBackend):
    """S3 storage backend, used when STORAGE_BACKEND=s3 (staging/production).

    The bucket, region and prefix come from STORAGE_S3_BUCKET,
    STORAGE_S3_REGION, STORAGE_S3_PREFIX env vars; credentials from
    STORAGE_S3_ACCESS_KEY_ID / STORAGE_S3_SECRET_ACCESS_KEY, or the
    ambient AWS credential chain (IAM role, etc.) if those are unset.

    If boto3 isn't installed, every method still raises NotImplementedError
    with an actionable message rather than crashing at import time — this
    keeps `local` the safe, zero-dependency default for anyone who hasn't
    opted into S3.
    """

    def __init__(self):
        self.bucket = os.getenv("STORAGE_S3_BUCKET", "")
        self.region = os.getenv("STORAGE_S3_REGION", "us-east-1")
        self.prefix = os.getenv("STORAGE_S3_PREFIX", "uploads/").rstrip("/") + "/"
        self.access_key = os.getenv("STORAGE_S3_ACCESS_KEY_ID", "")
        self.secret_key = os.getenv("STORAGE_S3_SECRET_ACCESS_KEY", "")

        if not self.bucket:
            raise RuntimeError(
                "STORAGE_S3_BUCKET must be set when STORAGE_BACKEND=s3"
            )

        try:
            import boto3  # noqa: F401
            self._boto3_available = True
        except ImportError:
            self._boto3_available = False
            log.warning(
                "boto3 not installed; S3StorageBackend will fall back to raising "
                "NotImplementedError on all operations. Install boto3 to enable S3."
            )

    def _client(self):
        if not self._boto3_available:
            raise NotImplementedError(
                "S3 backend requires boto3. Install with: pip install boto3"
            )
        import boto3
        kwargs = {"region_name": self.region}
        if self.access_key and self.secret_key:
            kwargs["aws_access_key_id"] = self.access_key
            kwargs["aws_secret_access_key"] = self.secret_key
        return boto3.client("s3", **kwargs)

    async def save(self, path: str, data: bytes) -> str:
        client = self._client()
        key = self.prefix + path
        # boto3 is a synchronous library; running it directly in an async
        # method would block the event loop for every other request while
        # the upload/download is in flight. run_in_threadpool moves the
        # blocking call off the event loop (same pattern already used for
        # Stripe calls in billing/services/subscriptions.py).
        await run_in_threadpool(client.put_object, Bucket=self.bucket, Key=key, Body=data)
        log.debug("Saved %d bytes to s3://%s/%s", len(data), self.bucket, key)
        return path

    async def load(self, path: str) -> bytes:
        client = self._client()
        key = self.prefix + path
        try:
            response = await run_in_threadpool(
                client.get_object, Bucket=self.bucket, Key=key
            )
        except client.exceptions.NoSuchKey:
            raise FileNotFoundError(f"S3 object not found: {key!r}")
        body = await run_in_threadpool(response["Body"].read)
        return body

    async def delete(self, path: str) -> bool:
        client = self._client()
        key = self.prefix + path
        try:
            await run_in_threadpool(client.head_object, Bucket=self.bucket, Key=key)
        except client.exceptions.ClientError:
            return False  # not found
        await run_in_threadpool(client.delete_object, Bucket=self.bucket, Key=key)
        return True

    async def exists(self, path: str) -> bool:
        client = self._client()
        key = self.prefix + path
        try:
            await run_in_threadpool(client.head_object, Bucket=self.bucket, Key=key)
            return True
        except client.exceptions.ClientError:
            return False


# ---------------------------------------------------------------------------
# Convenience helpers
# ---------------------------------------------------------------------------

def build_upload_path(user_id: str, upload_id: str, filename: str) -> str:
    """Build a relative storage path for a new upload.

    Format: "{user_id}/{upload_id}_{filename}"
    Namespacing by user_id keeps the local FS tidy and enables per-user
    backup/restore without walking the whole tree.
    """
    safe_name = os.path.basename(filename or "upload.csv")
    return f"{user_id}/{upload_id}_{safe_name}"


def file_extension(filename: str) -> str:
    """Return the lowercase extension without dot, e.g. 'csv' from 'trades.CSV'."""
    if not filename or "." not in filename:
        return ""
    return filename.rsplit(".", 1)[-1].lower()
