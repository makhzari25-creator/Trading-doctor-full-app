# -*- coding: utf-8 -*-
"""
conftest.py
-------------
Shared pytest configuration for the Trading Doctor backend test suite.

Disables API rate limiting for the entire test session. The rate limiter is
a module-level SlidingWindowRateLimiter instance in api/dependencies.py —
without this fixture, tests that run together can starve the shared counter
and trigger spurious 429s in unrelated tests (especially in test_phase10_billing
and test_phase11_workers, which create many requests per test). Individual
tests that explicitly verify rate-limiting behaviour (e.g. test_rate_limit_enforced)
re-enable it locally via monkeypatch.
"""

import os

# Set this BEFORE any api.* module is imported. The config module reads env
# vars at import time, so setting it here guarantees RATE_LIMIT_ENABLED=False
# by default for the whole session.
os.environ.setdefault("TRADING_DOCTOR_API_RATE_LIMIT_ENABLED", "false")

import pytest


@pytest.fixture(autouse=True, scope="session")
def _disable_rate_limit_for_session():
    """Belt-and-suspenders: also patch the config attribute in case the env
    var was overridden (e.g. by an explicit test fixture)."""
    from api import config as api_config
    api_config.RATE_LIMIT_ENABLED = False
    yield
    api_config.RATE_LIMIT_ENABLED = True
