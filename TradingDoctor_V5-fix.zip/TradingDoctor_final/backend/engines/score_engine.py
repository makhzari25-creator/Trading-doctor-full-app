# -*- coding: utf-8 -*-
"""
engines/score_engine.py
-------------------------
هر Score خام رفتاری را با داده‌ی مالی واقعی غنی می‌کند (ContextBlock)،
و روند این امتیازها/عملکرد را در طول زمان محاسبه می‌کند (TrendEngine).
قبلاً این دو کلاس به‌ترتیب ContextEngine و TrendEngine نام داشتند.
"""

import re
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np
import pandas as pd

from engines.behavior_engine import BehaviorEngine
from utils.sequence_analysis import revenge_mask_from_df
from utils.logger import get_logger

log = get_logger(__name__)
from utils.sequence_analysis import revenge_mask_from_df
from utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class ContextBlock:
    score: float
    dollars_lost: float
    pct_of_total_profit: float
    avg_per_event: float
    event_count: int
    severity: str    # Low / Medium / High / Critical
    insight: str
    profit_base: float = 0.0
    profit_base_label: str = ""


class ScoreEngine:
    """
    هر Score از BehaviorEngine را با داده‌ی مالی واقعی غنی می‌کند.
    عدد انتزاعی (مثل 43.8) تبدیل به بار مالی ملموس می‌شود.
    """

    def __init__(self, doctor: BehaviorEngine):
        self.doctor = doctor
        self.df = doctor.df
        self._total_profit = float(self.df["Profit"].sum()) if len(self.df) else 0.0
        # باگ‌فیکس: pct_of_total_profit قبلاً بر مبنای سود خالص (net) محاسبه
        # می‌شد. وقتی سود خالص نزدیک صفر بود (مثلاً ۹.۹۸$)، تقسیم بر آن عددی
        # بی‌معنی و گمراه‌کننده مثل «۱۳۴۹٪ از کل سود» تولید می‌کرد. حالا مبنا
        # مجموع سودهای مثبت (gross profit) است که پایدارتر و قابل‌فهم‌تر است؛
        # اگر gross profit صفر بود، به قدر مطلق سود خالص برمی‌گردد.
        self._gross_profit = (
            float(self.df.loc[self.df["Profit"] > 0, "Profit"].sum())
            if len(self.df) else 0.0
        )
        self._n = len(self.df)

    # ------------------------------------------------------------------
    # ابزارهای داخلی
    # ------------------------------------------------------------------

    @staticmethod
    def _severity(score: float) -> str:
        if score < 25: return "Low"
        if score < 50: return "Medium"
        if score < 75: return "High"
        return "Critical"

    def _pct_of_profit(self, dollars: float) -> float:
        base = self._gross_profit if self._gross_profit > 0 else abs(self._total_profit)
        if base == 0:
            return 0.0
        return round(abs(dollars) / base * 100, 1)

    def _current_base(self) -> "tuple[float, str]":
        """
        [FIX] مقدار و برچسبِ مبنایی که _pct_of_profit همین الان استفاده
        می‌کند را برمی‌گرداند، تا در ContextBlock و متن گزارش صراحتاً
        نشان داده شود (به‌جای پنهان‌ماندن در پس‌زمینه‌ی محاسبه).
        """
        if self._gross_profit > 0:
            return self._gross_profit, "Gross Profit (مجموع معاملات سودده، قبل از کسر ضررها)"
        return abs(self._total_profit), "Net Profit (قدر مطلق سود خالص)"

    def _revenge_mask(self) -> np.ndarray:
        # [AUDIT FIX] duplicated logic حذف شد — همان منطق مشترک
        # utils/sequence_analysis.revenge_mask_from_df که BehaviorEngine
        # هم استفاده می‌کند؛ نتیجه‌ی عددی بدون تغییر (تست‌شده).
        return revenge_mask_from_df(self.df)

    # ------------------------------------------------------------------
    # Context هر Score
    # ------------------------------------------------------------------

    def _context_revenge(self) -> ContextBlock:
        score, count = self.doctor.revenge_analysis()
        mask = self._revenge_mask()
        lost = float(self.df["Profit"].values[mask].sum())
        avg = round(lost / count, 2) if count else 0.0
        base, base_label = self._current_base()
        return ContextBlock(
            score=score,
            dollars_lost=round(lost, 2),
            pct_of_total_profit=self._pct_of_profit(lost),
            avg_per_event=avg,
            event_count=count,
            severity=self._severity(score),
            profit_base=round(base, 2),
            profit_base_label=base_label,
            insight=(
                f"{count} معامله‌ی Revenge باعث {abs(round(lost, 2))}$ ضرر شده — "
                f"معادل {self._pct_of_profit(lost)}% از {base_label} "
                f"(${round(base, 2):,.2f})."
            ),
        )

    def _context_overtrading(self) -> ContextBlock:
        score = self.doctor.overtrading_score()
        if self._n == 0 or self.df["Open Time"].isna().all():
            return ContextBlock(
                score=score, dollars_lost=0, pct_of_total_profit=0,
                avg_per_event=0, event_count=0, severity="Low",
                insight="داده‌ی زمانی برای محاسبه وجود ندارد.",
            )
        trades_per_day = self.df["date"].value_counts()
        heavy_days = trades_per_day[trades_per_day > 5].index
        count = int(len(heavy_days))
        lost = (
            float(self.df[self.df["date"].isin(heavy_days)]["Profit"].sum())
            if count else 0.0
        )
        avg = round(lost / count, 2) if count else 0.0
        base, base_label = self._current_base()
        return ContextBlock(
            score=score,
            dollars_lost=round(lost, 2),
            pct_of_total_profit=self._pct_of_profit(lost) if lost < 0 else 0.0,
            avg_per_event=avg,
            event_count=count,
            severity=self._severity(score),
            profit_base=round(base, 2),
            profit_base_label=base_label,
            insight=(
                f"{count} روز با بیش از ۵ معامله شناسایی شد. "
                f"نتیجه‌ی مالی: {'+' if lost >= 0 else ''}{round(lost, 2)}$."
            ),
        )

    def _context_risk_taking(self) -> ContextBlock:
        score = self.doctor.risk_taking_score()
        if self._n == 0 or self.df["Size"].mean() <= 0:
            return ContextBlock(
                score=score, dollars_lost=0, pct_of_total_profit=0,
                avg_per_event=0, event_count=0, severity="Low",
                insight="داده‌ی حجم معامله وجود ندارد.",
            )
        avg_size = self.df["Size"].mean()
        high_mask = self.df["Size"] > avg_size * 1.5
        count = int(high_mask.sum())
        lost = float(self.df.loc[high_mask, "Profit"].sum()) if count else 0.0
        avg = round(lost / count, 2) if count else 0.0
        base, base_label = self._current_base()
        return ContextBlock(
            score=score,
            dollars_lost=round(lost, 2),
            pct_of_total_profit=self._pct_of_profit(lost) if lost < 0 else 0.0,
            avg_per_event=avg,
            event_count=count,
            severity=self._severity(score),
            profit_base=round(base, 2),
            profit_base_label=base_label,
            insight=(
                f"{count} معامله با حجم بیش از ۱.۵ برابر میانگین. "
                f"نتیجه‌ی مالی: {'+' if lost >= 0 else ''}{round(lost, 2)}$"
                + (f" (معادل {self._pct_of_profit(lost)}% از {base_label})." if lost < 0 else ".")
            ),
        )

    def _context_patience(self) -> ContextBlock:
        score = self.doctor.patience_score()
        impatience = round(100 - score, 1)
        if self._n < 2 or self.df["Open Time"].isna().all():
            return ContextBlock(
                score=score, dollars_lost=0, pct_of_total_profit=0,
                avg_per_event=0, event_count=0, severity="Low",
                insight="داده‌ی زمانی کافی نیست.",
            )
        gap_minutes = self.df["Open Time"].diff().dt.total_seconds() / 60.0
        loss = self.df["Profit"] < 0
        prev_loss = loss.shift(1).fillna(False)
        quick_mask = prev_loss & (gap_minutes < 15) & ~gap_minutes.isna()
        count = int(quick_mask.sum())
        lost = float(self.df.loc[quick_mask, "Profit"].sum()) if count else 0.0
        avg = round(lost / count, 2) if count else 0.0
        base, base_label = self._current_base()
        return ContextBlock(
            score=score,
            dollars_lost=round(lost, 2),
            pct_of_total_profit=self._pct_of_profit(lost) if lost < 0 else 0.0,
            avg_per_event=avg,
            event_count=count,
            severity=self._severity(impatience),
            profit_base=round(base, 2),
            profit_base_label=base_label,
            insight=(
                f"{count} بار کمتر از ۱۵ دقیقه بعد از ضرر دوباره معامله کردی. "
                f"نتیجه‌ی مالی: {'+' if lost >= 0 else ''}{round(lost, 2)}$"
                + (f" (معادل {self._pct_of_profit(lost)}% از {base_label})." if lost < 0 else ".")
            ),
        )

    def _context_discipline(self) -> ContextBlock:
        score = self.doctor.discipline_score()
        lost = float(self.df[self.df["Profit"] < 0]["Profit"].sum())
        count = int((self.df["Profit"] < 0).sum())
        avg = round(lost / count, 2) if count else 0.0
        base, base_label = self._current_base()
        return ContextBlock(
            score=score,
            dollars_lost=round(lost, 2),
            pct_of_total_profit=self._pct_of_profit(lost),
            avg_per_event=avg,
            event_count=count,
            severity=self._severity(100 - score),
            profit_base=round(base, 2),
            profit_base_label=base_label,
            insight=(
                f"امتیاز Discipline {score}/100. "
                f"کل ضررها: {round(abs(lost), 2)}$ در {count} معامله "
                f"(معادل {self._pct_of_profit(lost)}% از {base_label})."
            ),
        )

    # ------------------------------------------------------------------
    # معیارهای کلی عملکرد
    # ------------------------------------------------------------------

    def _performance(self) -> dict:
        p = self.df["Profit"]
        if len(p) == 0:
            return {}
        wins = p[p > 0]
        losses = p[p < 0]
        equity = p.cumsum()
        dd = equity.cummax() - equity
        pf = round(float(wins.sum() / abs(losses.sum())), 3) if len(losses) else 0.0
        return {
            "total_trades": self._n,
            "net_profit": round(float(p.sum()), 2),
            "win_rate_pct": round(float((p > 0).mean() * 100), 1),
            "profit_factor": pf,
            "avg_win": round(float(wins.mean()), 2) if len(wins) else 0.0,
            "avg_loss": round(float(losses.mean()), 2) if len(losses) else 0.0,
            "reward_risk_ratio": (
                round(float(abs(wins.mean() / losses.mean())), 3)
                if len(wins) and len(losses) else 0.0
            ),
            "max_drawdown": round(float(dd.max()), 2),
            "max_win_streak": self._max_streak(p, winning=True),
            "max_loss_streak": self._max_streak(p, winning=False),
        }

    @staticmethod
    def _max_streak(profit_series: pd.Series, winning: bool) -> int:
        is_target = (profit_series > 0) if winning else (profit_series < 0)
        groups = (is_target != is_target.shift()).cumsum()
        streaks = is_target.groupby(groups).sum()
        return int(streaks.max()) if len(streaks) else 0

    # ------------------------------------------------------------------
    # Edge Map
    # ------------------------------------------------------------------

    @staticmethod
    def _clean_col(name: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(name).strip().lower())

    def _edge_map(self) -> dict:
        result = {}
        has_time = not self.df["Open Time"].isna().all()

        if has_time:
            by_hour = self.df.groupby("hour")["Profit"].agg(["sum", "mean", "count"])
            by_hour = by_hour[by_hour["count"] >= 5]
            if not by_hour.empty:
                result["best_hour"] = {
                    "hour": int(by_hour["sum"].idxmax()),
                    "avg_pnl": round(float(by_hour.loc[by_hour["sum"].idxmax(), "mean"]), 2),
                }
                result["worst_hour"] = {
                    "hour": int(by_hour["sum"].idxmin()),
                    "avg_pnl": round(float(by_hour.loc[by_hour["sum"].idxmin(), "mean"]), 2),
                }

            self.df["_weekday"] = pd.to_datetime(
                self.df["Open Time"], errors="coerce"
            ).dt.day_name()
            by_day = self.df.groupby("_weekday")["Profit"].agg(["sum", "mean", "count"])
            by_day = by_day[by_day["count"] >= 5]
            self.df.drop(columns=["_weekday"], inplace=True)
            if not by_day.empty:
                result["best_weekday"] = {
                    "day": str(by_day["sum"].idxmax()),
                    "total_pnl": round(float(by_day["sum"].max()), 2),
                }
                result["worst_weekday"] = {
                    "day": str(by_day["sum"].idxmin()),
                    "total_pnl": round(float(by_day["sum"].min()), 2),
                }

        strat_col = next(
            (c for c in self.df.columns
             if self._clean_col(c) in {"strategy", "strat", "setup", "type"}),
            None,
        )
        if strat_col:
            by_strat = self.df.groupby(strat_col)["Profit"].agg(
                ["sum", "mean", "count",
                 lambda x: round(float((x > 0).mean() * 100), 1)]
            )
            by_strat.columns = ["total", "avg", "count", "win_rate"]
            by_strat = by_strat[by_strat["count"] >= 5]
            if not by_strat.empty:
                best = by_strat["avg"].idxmax()
                worst = by_strat["avg"].idxmin()
                result["best_strategy"] = {
                    "name": str(best),
                    "avg_pnl": round(float(by_strat.loc[best, "avg"]), 2),
                    "win_rate_pct": float(by_strat.loc[best, "win_rate"]),
                }
                result["worst_strategy"] = {
                    "name": str(worst),
                    "avg_pnl": round(float(by_strat.loc[worst, "avg"]), 2),
                    "win_rate_pct": float(by_strat.loc[worst, "win_rate"]),
                }

        side_col = next(
            (c for c in self.df.columns
             if self._clean_col(c) in {"side", "direction", "action"}),
            None,
        )
        if side_col:
            by_side = self.df.groupby(side_col)["Profit"].agg(["sum", "mean", "count"])
            by_side = by_side[by_side["count"] >= 5]
            if not by_side.empty:
                result["side_comparison"] = {
                    str(idx): {
                        "total_pnl": round(float(row["sum"]), 2),
                        "avg_pnl": round(float(row["mean"]), 2),
                        "count": int(row["count"]),
                    }
                    for idx, row in by_side.iterrows()
                }

        return result

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def _summary(self, context: dict, perf: dict) -> str:
        if not perf:
            return "داده‌ی کافی برای تولید خلاصه وجود ندارد."
        rev_ctx = context.get("revenge_score")
        rev_lost = abs(rev_ctx.dollars_lost) if rev_ctx else 0
        rev_pct = rev_ctx.pct_of_total_profit if rev_ctx else 0
        base_label = rev_ctx.profit_base_label if rev_ctx else ""
        net = perf.get("net_profit", 0)
        return (
            f"در {perf.get('total_trades', 0)} معامله با Win Rate "
            f"{perf.get('win_rate_pct', 0)}% و Profit Factor "
            f"{perf.get('profit_factor', 0)}، سود خالص "
            f"{'+' if net >= 0 else ''}{net}$ بدست آمده. "
            f"جدی‌ترین مشکل: معاملات Revenge که {rev_lost}$ "
            f"(معادل {rev_pct}% از {base_label}) را از بین برده‌اند. "
            f"اگر فقط این رفتار اصلاح شود، عملکرد به‌شدت بهبود می‌یابد."
        )

    # ------------------------------------------------------------------
    # متد اصلی
    # ------------------------------------------------------------------

    def run(self):
        """اجرای کامل: BehaviorResult + Context + Performance + EdgeMap → FullResult."""
        from engines.report_engine import FullResult  # جلوگیری از import چرخه‌ای

        behavior = self.doctor.build_behavior_engine()
        context = {
            "revenge_score": self._context_revenge(),
            "overtrading_score": self._context_overtrading(),
            "risk_taking_score": self._context_risk_taking(),
            "patience_score": self._context_patience(),
            "discipline_score": self._context_discipline(),
        }
        perf = self._performance()
        edge = self._edge_map()
        summary = self._summary(context, perf)
        return FullResult(
            behavior=behavior,
            context=context,
            performance=perf,
            edge_map=edge,
            summary=summary,
        )


# نام قدیمی برای سازگاری با کد قبلی
ContextEngine = ScoreEngine


class TrendEngine:
    """
    محاسبه‌ی روند امتیازهای رفتاری (Revenge / Overtrading / Risk / Patience /
    Discipline) و عملکرد (Win Rate / Net Profit / Profit Factor) در طول زمان،
    با سطل‌بندی هفتگی یا ماهانه.

    نکته‌ی معماری مهم: این کلاس با فرض طراحی می‌شود که هر بار کاربر فقط
    معاملات جدید (نه کل تاریخچه) آپلود می‌کند. پس مسئولیت بک‌اند این است که
    معاملات جدید را به تاریخچه‌ی خام ذخیره‌شده‌ی همان کاربر اضافه (append)
    کند و *کل مجموعه‌ی تجمعی* (قدیم + جدید) را یکجا به این کلاس بدهد — نه
    فقط فایل تازه‌آپلودشده. این کلاس خودش هیچ چیزی را در دیتابیس ذخیره
    نمی‌کند (بدون وابستگی به DB)، فقط از روی یک DataFrame کامل، روند را
    محاسبه می‌کند.

    دو حالت محاسبه:
      - mode="independent": هر دوره (هفته/ماه) کاملاً مستقل و فقط بر اساس
        معاملات همان دوره حساب می‌شود.
      - mode="cumulative": هر دوره بر اساس تمام معاملات از ابتدای تاریخچه
        تا پایان آن دوره حساب می‌شود.

    مثال استفاده:
        trend = TrendEngine(all_trades_df)
        weekly_independent = trend.compute(granularity="week", mode="independent")
        both = trend.compute_both_granularities(mode="cumulative")
    """

    def __init__(self, raw_df: pd.DataFrame):
        # نرمالایز یک‌بار روی کل داده انجام می‌شود تا ستون استاندارد
        # "Open Time" برای سطل‌بندی زمانی در دسترس باشد. از همان
        # BehaviorEngine استفاده می‌شود — منطق نرمالایز تکراری نوشته نشده.
        self._doctor_full = BehaviorEngine(raw_df)
        self._df = self._doctor_full.df

    @staticmethod
    def _profit_factor(profit: pd.Series) -> float:
        wins, losses = profit[profit > 0], profit[profit < 0]
        if len(losses) > 0:
            return round(float(wins.sum() / abs(losses.sum())), 3)
        return 999.99 if profit.sum() > 0 else 0.0

    def compute(self, granularity: str = "week", mode: str = "independent") -> List[dict]:
        """
        خروجی: لیستی از دیکشنری‌ها به ترتیب زمانی، هرکدام شامل بازه‌ی
        زمانی، تعداد معاملات، ۵ امتیاز رفتاری، و ۳ معیار عملکرد پایه.
        اگر داده‌ی زمانی (Open Time) موجود نباشد، لیست خالی برمی‌گردد.
        """
        if granularity not in ("week", "month"):
            raise ValueError('granularity باید "week" یا "month" باشد.')
        if mode not in ("independent", "cumulative"):
            raise ValueError('mode باید "independent" یا "cumulative" باشد.')

        df = self._df
        if len(df) == 0 or df["Open Time"].isna().all():
            return []

        freq = "M" if granularity == "month" else "W"
        df = df.copy()
        df["_period"] = df["Open Time"].dt.to_period(freq)

        ordered_periods = sorted(p for p in df["_period"].unique() if pd.notna(p))
        results: List[dict] = []

        for period in ordered_periods:
            if mode == "cumulative":
                subset = df.loc[df["_period"] <= period].drop(columns=["_period"])
            else:
                subset = df.loc[df["_period"] == period].drop(columns=["_period"])

            if len(subset) == 0:
                continue

            sub_doctor = BehaviorEngine(subset)
            profit = sub_doctor.df["Profit"]

            results.append({
                "period_start": str(period.start_time.date()),
                "period_end": str(period.end_time.date()),
                "trades_count": int(len(subset)),
                "revenge_score": sub_doctor.revenge_analysis()[0],
                "overtrading_score": sub_doctor.overtrading_score(),
                "risk_taking_score": sub_doctor.risk_taking_score(),
                "patience_score": sub_doctor.patience_score(),
                "discipline_score": sub_doctor.discipline_score(),
                "net_profit": round(float(profit.sum()), 2),
                "win_rate_pct": round(float((profit > 0).mean() * 100), 1),
                "profit_factor": self._profit_factor(profit),
            })

        return results

    def compute_both_granularities(self, mode: str = "independent") -> dict:
        """خروجی ترکیبی راحت برای فرانت‌اند: هم روند هفتگی هم ماهانه."""
        return {
            "weekly": self.compute(granularity="week", mode=mode),
            "monthly": self.compute(granularity="month", mode=mode),
        }
