# -*- coding: utf-8 -*-
"""
engines/report_engine.py
--------------------------
FullResult: خروجی نهایی خط لوله‌ی تحلیل (BehaviorResult + Context + Performance
+ EdgeMap + Summary).

ReportEngine: تبدیل FullResult و خروجی CoachingEngine به گزارش‌های قابل چاپ
(متنی) یا قابل سریالایز (dict/JSON)، تا هم CLI (main.py) و هم لایه‌های دیگر
(مثل API یا فایل‌های reports/) بتوانند از یک منبع مشترک استفاده کنند.
"""

from dataclasses import dataclass
from typing import Optional

from engines.behavior_engine import BehaviorResult


@dataclass
class FullResult:
    behavior: BehaviorResult
    context: dict
    performance: dict
    edge_map: dict
    summary: str


class ReportEngine:
    """قالب‌بندی FullResult + خروجی CoachingEngine به گزارش متنی یا dict."""

    SEP = "=" * 62

    def __init__(self, result: FullResult, coach: Optional[dict] = None):
        self.result = result
        self.coach = coach or {}

    # ------------------------------------------------------------------
    # گزارش متنی (برای CLI / لاگ)
    # ------------------------------------------------------------------

    def _section(self, title: str) -> str:
        return f"\n{self.SEP}\n{title}\n{self.SEP}"

    def to_text(self) -> str:
        result = self.result
        coach = self.coach
        lines = []

        lines.append(self._section("SUMMARY"))
        lines.append(result.summary)

        lines.append(self._section("PERFORMANCE"))
        for k, v in result.performance.items():
            lines.append(f"  {k:<26}: {v}")

        lines.append(self._section("BEHAVIOR SCORES + CONTEXT"))
        for name, ctx in result.context.items():
            lines.append(f"\n  [{name}]")
            lines.append(f"    score          : {ctx.score}")
            lines.append(f"    severity       : {ctx.severity}")
            lines.append(f"    event_count    : {ctx.event_count}")
            lines.append(f"    dollars_impact : {ctx.dollars_lost}")
            lines.append(f"    insight        : {ctx.insight}")

        lines.append(self._section("EDGE MAP"))
        for k, v in result.edge_map.items():
            lines.append(f"  {k}: {v}")

        if coach:
            lines.append(self._section("TRADER DNA"))
            for k, v in coach.get("trader_dna", {}).items():
                lines.append(f"  {k}: {v}")

            lines.append(self._section("DIAGNOSIS"))
            for k, v in coach.get("diagnosis", {}).items():
                if v:
                    lines.append(f"  {k}: {v}")

            lines.append(self._section("EXPLAINABLE AI"))
            lines.append(str(coach.get("explainable_ai", "")))

            lines.append(self._section("ACTION PLAN"))
            for item in coach.get("action_plan", []):
                lines.append(f"  [{item['priority']}] {item['issue']}: {item['action']}")

            lines.append(self._section("KEY EVIDENCE"))
            for e in coach.get("key_evidence", []):
                t = e["type"].value if hasattr(e["type"], "value") else str(e["type"])
                lines.append(
                    f"  {t:<20} priority={e['priority_score']:<6} "
                    f"freq={e['frequency']:<5} impact={round(e['financial_impact'], 2)}$"
                )

        return "\n".join(lines)

    def print_report(self) -> None:
        print(self.to_text())

    # ------------------------------------------------------------------
    # گزارش dict (برای API / ذخیره در reports/)
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        result = self.result
        return {
            "summary": result.summary,
            "performance": result.performance,
            "context": {
                name: ctx.__dict__ for name, ctx in result.context.items()
            },
            "edge_map": result.edge_map,
            "behavior": result.behavior.__dict__,
            "coach": self.coach,
        }
