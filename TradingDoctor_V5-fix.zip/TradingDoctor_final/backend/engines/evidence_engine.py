# -*- coding: utf-8 -*-
"""
engines/evidence_engine.py
----------------------------
از خروجی ScoreEngine (context / performance / edge_map / df خام) شواهد
رفتاری واقعی و قابل‌توضیح استخراج می‌کند. هر Evidence شامل شدت، فراوانی،
اثر مالی، احتمال واقعی‌بودن الگو و اطمینان آماری است تا CoachingEngine
بتواند بر مبنای داده تشخیص بدهد، نه فرض ثابت.
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Any

import numpy as np
import pandas as pd

from utils.sequence_analysis import sequential_masks as _shared_sequential_masks
from utils.logger import get_logger

log = get_logger(__name__)

class EvidenceType(Enum):
    REVENGE="revenge"
    OVERTRADING="overtrading"
    RISK="risk"
    PATIENCE="patience"
    EMOTIONAL="emotional"
    CONFIDENCE="confidence"
    RECOVERY="recovery"
    SESSION="session"
    DECISION_QUALITY="decision_quality"
    DRAWDOWN="drawdown"
    POSITION_SIZING="position_sizing"
    STREAK="streak"
    TIMING="timing"
    CONSISTENCY="consistency"
    FOMO="fomo"

@dataclass
class Evidence:
    type: EvidenceType
    description:str
    severity:float
    frequency:int
    financial_impact:float
    probability:float
    confidence:float
    details:Dict[str,Any]
    priority_score:float=0.0

class EvidenceEngine:
    """
    از خروجی TradingDoctor (context / performance / df خام) شواهد رفتاری
    واقعی و قابل‌توضیح استخراج می‌کند. هر Evidence شامل شدت، فراوانی، اثر
    مالی، احتمال واقعی‌بودن الگو و اطمینار آماری است تا CoachingEngine
    بتواند بر مبنای داده تشخیص بدهد، نه فرض ثابت.

    probability : سهم اثر مالی این الگو از کل تصویر (۰ تا ۱) — هرچه بیشتر،
                  این رفتار بخش بزرگ‌تری از نتیجه‌ی معاملاتی را توضیح می‌دهد.
    confidence  : اطمینان آماری بر اساس تعداد رخداد (۰ تا ۱) — نمونه‌ی کم
                  یعنی اطمینان کم، حتی اگر شدت بالا باشد.
    """

    MIN_SAMPLE = 5  # حداقل تعداد رخداد/روز برای معتبر دانستن یک الگوی آماری

    def __init__(self, doctor, context, performance, edge_map=None):
        self.doctor      = doctor
        self.df           = doctor.df
        self.context      = context
        self.performance  = performance
        self.edge_map     = edge_map or {}
        self.library      = self._extract_evidence()

    # ------------------------------------------------------------------
    # امتیازدهی اولویت
    # ------------------------------------------------------------------
    @staticmethod
    def _finalize_priority(raw_evidences):
        """
        priority_score = ترکیب وزن‌دار شدت (۳۵٪) + احتمال (۲۵٪) +
        اطمینان آماری (۱۵٪) + اثر مالی نرمال‌شده نسبت به بزرگ‌ترین اثر
        مالی در بین همه‌ی شواهد این دیتاست (۲۵٪).
        """
        if not raw_evidences:
            return []
        max_impact = max(abs(e.financial_impact) for e in raw_evidences) or 1.0
        for e in raw_evidences:
            norm_impact = abs(e.financial_impact) / max_impact
            score = (
                0.35 * (e.severity / 100.0)
                + 0.25 * e.probability
                + 0.15 * e.confidence
                + 0.25 * norm_impact
            )
            e.priority_score = round(min(1.0, max(0.0, score)) * 100, 1)
        return raw_evidences

    def _extract_evidence(self) -> List[Evidence]:
        builders = (
            self._ev_revenge, self._ev_overtrading, self._ev_risk,
            self._ev_patience, self._ev_discipline, self._ev_drawdown,
            self._ev_streak, self._ev_consistency, self._ev_timing,
            self._ev_session, self._ev_fomo, self._ev_overconfidence,
            self._ev_recovery, self._ev_position_sizing_trend, self._ev_emotional,
        )
        evs = []
        for build in builders:
            try:
                e = build()
            except Exception:
                # یک شاهد ناقص نباید کل تحلیل را متوقف کند، اما باید لاگ
                # شود تا مشکلات پنهان در production قابل‌ردیابی باشند
                # (قبلاً این خطا کاملاً بی‌صدا بلعیده می‌شد).
                log.warning(
                    "Evidence builder '%s' failed and was skipped",
                    getattr(build, "__name__", str(build)),
                    exc_info=True,
                )
                e = None
            if e is not None:
                evs.append(e)
        return self._finalize_priority(evs)

    # ------------------------------------------------------------------
    # ابزار داخلی: streak/size/quick-reentry برای شواهد رفتاری-توالی‌محور
    # ------------------------------------------------------------------
    def _sequential_masks(self):
        # [AUDIT FIX] duplicated logic حذف شد — همان منبع مشترک
        # utils/sequence_analysis.sequential_masks() که در BehaviorEngine
        # و ScoreEngine هم استفاده می‌شود؛ نتیجه‌ی عددی بدون تغییر (تست‌شده).
        return _shared_sequential_masks(self.df, quick_reentry_minutes=15)

    # ------------------------------------------------------------------
    # شواهد مبتنی بر ContextBlockهای موجود
    # ------------------------------------------------------------------
    def _ev_revenge(self):
        ctx = self.context.get("revenge_score")
        if not ctx or ctx.event_count == 0:
            return None
        return Evidence(
            type=EvidenceType.REVENGE,
            description=(
                f"در {ctx.event_count} معامله، بعد از یک باخت حجم را افزایش دادی "
                f"و بلافاصله دوباره وارد شدی — نشانه‌ی معامله‌ی انتقامی."
            ),
            severity=ctx.score, frequency=ctx.event_count,
            financial_impact=ctx.dollars_lost,
            probability=round(min(1.0, ctx.pct_of_total_profit / 100.0), 2),
            confidence=round(min(1.0, ctx.event_count / 10.0), 2),
            details={"avg_per_event": ctx.avg_per_event, "severity_label": ctx.severity},
        )

    def _ev_overtrading(self):
        ctx = self.context.get("overtrading_score")
        if not ctx or ctx.event_count == 0:
            return None
        return Evidence(
            type=EvidenceType.OVERTRADING,
            description=(
                f"در {ctx.event_count} روز بیش از ۵ معامله انجام دادی — "
                f"نشانه‌ی بیش‌معامله‌گری."
            ),
            severity=ctx.score, frequency=ctx.event_count,
            financial_impact=ctx.dollars_lost,
            probability=round(min(1.0, ctx.pct_of_total_profit / 100.0), 2) if ctx.dollars_lost < 0 else 0.3,
            confidence=round(min(1.0, ctx.event_count / 10.0), 2),
            details={"avg_per_event": ctx.avg_per_event, "severity_label": ctx.severity},
        )

    def _ev_risk(self):
        ctx = self.context.get("risk_taking_score")
        if not ctx or ctx.event_count == 0:
            return None
        return Evidence(
            type=EvidenceType.RISK,
            description=(
                f"{ctx.event_count} معامله با حجمی بیش از ۱.۵ برابر میانگین "
                f"حجم معمولت باز کردی."
            ),
            severity=ctx.score, frequency=ctx.event_count,
            financial_impact=ctx.dollars_lost,
            probability=round(min(1.0, ctx.pct_of_total_profit / 100.0), 2) if ctx.dollars_lost < 0 else 0.3,
            confidence=round(min(1.0, ctx.event_count / 10.0), 2),
            details={"avg_per_event": ctx.avg_per_event, "severity_label": ctx.severity},
        )

    def _ev_patience(self):
        ctx = self.context.get("patience_score")
        if not ctx or ctx.event_count == 0:
            return None
        impatience = round(100 - ctx.score, 1)
        return Evidence(
            type=EvidenceType.PATIENCE,
            description=(
                f"{ctx.event_count} بار کمتر از ۱۵ دقیقه بعد از یک باخت دوباره "
                f"وارد معامله شدی."
            ),
            severity=impatience, frequency=ctx.event_count,
            financial_impact=ctx.dollars_lost,
            probability=round(min(1.0, ctx.pct_of_total_profit / 100.0), 2) if ctx.dollars_lost < 0 else 0.3,
            confidence=round(min(1.0, ctx.event_count / 10.0), 2),
            details={"avg_per_event": ctx.avg_per_event, "severity_label": ctx.severity},
        )

    def _ev_discipline(self):
        ctx = self.context.get("discipline_score")
        if not ctx:
            return None
        weakness = round(100 - ctx.score, 1)
        if weakness < 20:
            return None  # انضباط قابل‌قبول است، شاهدی برای گزارش نیست
        return Evidence(
            type=EvidenceType.DECISION_QUALITY,
            description=(
                f"امتیاز انضباط کلی {ctx.score}/100 است — ترکیبی از انتقام‌جویی، "
                f"بیش‌معامله‌گری، کم‌صبری و ریسک بالا."
            ),
            severity=weakness, frequency=max(ctx.event_count, 1),
            financial_impact=ctx.dollars_lost,
            probability=round(min(1.0, weakness / 100.0), 2),
            confidence=round(min(1.0, max(ctx.event_count, 1) / 15.0), 2),
            details={"discipline_score": ctx.score},
        )

    # ------------------------------------------------------------------
    # شواهد مبتنی بر عملکرد کلی (performance)
    # ------------------------------------------------------------------
    def _ev_drawdown(self):
        perf = self.performance
        if not perf or len(self.df) == 0:
            return None
        dd = perf.get("max_drawdown", 0)
        gross_profit = float(self.df.loc[self.df["Profit"] > 0, "Profit"].sum())
        base = gross_profit if gross_profit > 0 else (abs(perf.get("net_profit", 0)) or 1.0)
        pct = min(1.0, dd / base) if base else 0.0
        if dd <= 0 or pct < 0.15:
            return None
        return Evidence(
            type=EvidenceType.DRAWDOWN,
            description=(
                f"بزرگ‌ترین افت سرمایه (Drawdown) شما {round(dd, 2)}$ بوده — "
                f"معادل {round(pct * 100, 1)}% از سود ناخالصت."
            ),
            severity=round(pct * 100, 1), frequency=1, financial_impact=dd,
            probability=round(pct, 2), confidence=0.7,
            details={"max_drawdown": dd},
        )

    def _ev_streak(self):
        perf = self.performance
        if not perf:
            return None
        loss_streak = perf.get("max_loss_streak", 0)
        n = perf.get("total_trades", 0)
        if loss_streak < 4 or n < 10:
            return None
        severity = min(100.0, loss_streak * 12.0)
        return Evidence(
            type=EvidenceType.STREAK,
            description=(
                f"طولانی‌ترین رشته‌ی ضرر پشت‌سرهمت {loss_streak} معامله بوده — "
                f"ریسک فرسایش روانی و تصمیم‌گیری هیجانی در ادامه‌ی رشته بالاست."
            ),
            severity=round(severity, 1), frequency=loss_streak,
            financial_impact=perf.get("avg_loss", 0) * loss_streak,
            probability=round(min(1.0, loss_streak / max(n, 1) * 5), 2),
            confidence=0.6,
            details={"max_loss_streak": loss_streak, "max_win_streak": perf.get("max_win_streak", 0)},
        )

    def _ev_consistency(self):
        if len(self.df) == 0 or self.df["date"].isna().all():
            return None
        daily = self.df.groupby("date")["Profit"].sum()
        if len(daily) < self.MIN_SAMPLE:
            return None
        mean, std = daily.mean(), daily.std()
        if mean == 0 or pd.isna(std):
            return None
        cv = abs(std / mean)
        if cv < 1.5:
            return None
        return Evidence(
            type=EvidenceType.CONSISTENCY,
            description=(
                "سود و زیان روزانه‌ات نوسان بسیار زیادی دارد؛ عملکردت از یک روز "
                "به روز دیگر به‌شدت غیرقابل‌پیش‌بینی است."
            ),
            severity=round(min(100.0, cv * 25), 1), frequency=int(len(daily)),
            financial_impact=float(std),
            probability=round(min(1.0, cv / 3), 2),
            confidence=round(min(1.0, len(daily) / 20.0), 2),
            details={"daily_std": round(float(std), 2), "daily_mean": round(float(mean), 2)},
        )

    def _ev_timing(self):
        worst = self.edge_map.get("worst_hour")
        if not worst or worst.get("avg_pnl", 0) >= 0:
            return None
        return Evidence(
            type=EvidenceType.TIMING,
            description=(
                f"معاملات ساعت {worst['hour']} به‌طور میانگین {worst['avg_pnl']}$ "
                f"ضرر داده‌اند — این بازه‌ی ساعتی نقطه‌ضعف زمانی توست."
            ),
            severity=round(min(100.0, abs(worst["avg_pnl"]) * 5), 1), frequency=1,
            financial_impact=worst["avg_pnl"], probability=0.5, confidence=0.5,
            details=worst,
        )

    def _ev_session(self):
        worst = self.edge_map.get("worst_weekday")
        if not worst or worst.get("total_pnl", 0) >= 0:
            return None
        return Evidence(
            type=EvidenceType.SESSION,
            description=(
                f"روزهای {worst['day']} در مجموع {worst['total_pnl']}$ ضرر داده‌ای — "
                f"شاید بهتر باشد آن روز محتاط‌تر معامله کنی یا اصلاً معامله نکنی."
            ),
            severity=round(min(100.0, abs(worst["total_pnl"]) / 2), 1), frequency=1,
            financial_impact=worst["total_pnl"], probability=0.5, confidence=0.5,
            details=worst,
        )

    # ------------------------------------------------------------------
    # شواهد مبتنی بر توالی معاملات (df خام)
    # ------------------------------------------------------------------
    def _ev_fomo(self):
        m = self._sequential_masks()
        if m is None:
            return None
        count = int(m["fomo_mask"].sum())
        if count == 0:
            return None
        pnl = float(m["profit"][m["fomo_mask"]].sum())
        n = len(m["profit"])
        return Evidence(
            type=EvidenceType.FOMO,
            description=(
                f"در {count} مورد، بعد از حداقل دو برد پشت‌سرهم و با فاصله‌ی "
                f"کمتر از ۱۵ دقیقه، حجم را افزایش دادی و دوباره وارد شدی — "
                f"رفتاری شبیه دنبال‌کردن هیجانی بازار (FOMO)."
            ),
            severity=round(min(100.0, (count / max(n, 1)) * 400), 1), frequency=count,
            financial_impact=pnl,
            probability=round(min(1.0, count / max(n, 1) * 5), 2),
            confidence=round(min(1.0, count / 10.0), 2),
            details={"total_pnl_in_fomo_trades": round(pnl, 2)},
        )

    def _ev_overconfidence(self):
        m = self._sequential_masks()
        if m is None or len(m["size"]) < self.MIN_SAMPLE:
            return None
        size = m["size"]
        avg_size = float(np.mean(size))
        if avg_size <= 0:
            return None
        after_streak = m["win_streak"] >= 3
        if after_streak.sum() < 3:
            return None
        avg_after = float(size[after_streak].mean())
        ratio = avg_after / avg_size
        if ratio < 1.3:
            return None
        pnl = float(m["profit"][after_streak].sum())
        return Evidence(
            type=EvidenceType.CONFIDENCE,
            description=(
                f"بعد از ۳ برد پشت‌سرهم یا بیشتر، میانگین حجم معاملاتت "
                f"{round(ratio, 2)} برابر حجم عادی می‌شود — نشانه‌ی "
                f"اعتمادبه‌نفس بیش‌ازحد بعد از موفقیت."
            ),
            severity=round(min(100.0, (ratio - 1) * 100), 1), frequency=int(after_streak.sum()),
            financial_impact=pnl,
            probability=round(min(1.0, ratio - 1), 2),
            confidence=round(min(1.0, after_streak.sum() / 10.0), 2),
            details={"size_ratio_after_win_streak": round(ratio, 2)},
        )

    def _ev_recovery(self):
        perf = self.performance
        if not perf or len(self.df) < self.MIN_SAMPLE:
            return None
        profit = self.df["Profit"].values
        equity = np.cumsum(profit)
        trough_idx = int(np.argmax(np.maximum.accumulate(equity) - equity))
        window = profit[trough_idx + 1: trough_idx + 6]
        if len(window) < 3:
            return None
        recovery_pnl = float(window.sum())
        if recovery_pnl >= 0:
            return None  # ریکاوری خوب بوده، شاهدی برای گزارش مشکل نیست
        return Evidence(
            type=EvidenceType.RECOVERY,
            description=(
                f"بعد از عمیق‌ترین افت سرمایه‌ات، در {len(window)} معامله‌ی بعدی "
                f"مجموعاً {round(recovery_pnl, 2)}$ بیشتر از دست دادی — نشانه‌ی "
                f"ادامه‌ی رفتار هیجانی به‌جای ریست ذهنی بعد از افت بزرگ."
            ),
            severity=round(min(100.0, abs(recovery_pnl) * 2), 1), frequency=len(window),
            financial_impact=recovery_pnl, probability=0.5, confidence=0.4,
            details={"trades_after_max_drawdown": len(window)},
        )

    def _ev_position_sizing_trend(self):
        if len(self.df) < 10:
            return None
        size = self.df["Size"].values
        profit = self.df["Profit"].values
        n = len(size)
        half = n // 2
        first_avg = float(np.mean(size[:half])) if half else 0.0
        second_avg = float(np.mean(size[half:])) if n - half else 0.0
        if first_avg <= 0:
            return None
        growth = (second_avg - first_avg) / first_avg
        if growth < 0.3:
            return None
        pnl_second_half = float(profit[half:].sum())
        return Evidence(
            type=EvidenceType.POSITION_SIZING,
            description=(
                f"میانگین حجم معاملاتت در نیمه‌ی دوم تاریخچه نسبت به نیمه‌ی اول "
                f"{round(growth * 100, 1)}% رشد کرده — احتمال افزایش تدریجی و "
                f"ناخودآگاه ریسک با گذر زمان."
            ),
            severity=round(min(100.0, growth * 100), 1), frequency=n - half,
            financial_impact=pnl_second_half,
            probability=round(min(1.0, growth), 2),
            confidence=round(min(1.0, (n - half) / 20.0), 2),
            details={"first_half_avg_size": round(first_avg, 3), "second_half_avg_size": round(second_avg, 3)},
        )

    def _ev_emotional(self):
        if len(self.df) == 0 or self.df["date"].isna().all():
            return None
        m = self._sequential_masks()
        if m is None:
            return None
        emotional_mask = m["revenge_mask"] | m["fomo_mask"]
        df_tmp = self.df.assign(_emotional=emotional_mask)
        active_days = df_tmp["date"].nunique()
        if active_days == 0:
            return None
        emotional_days = df_tmp.loc[df_tmp["_emotional"], "date"].nunique()
        ratio = emotional_days / active_days
        if ratio < 0.2:
            return None
        pnl = float(df_tmp.loc[df_tmp["_emotional"], "Profit"].sum())
        return Evidence(
            type=EvidenceType.EMOTIONAL,
            description=(
                f"در {round(ratio * 100, 1)}% از روزهای معاملاتی‌ات حداقل یک "
                f"رفتار هیجانی (انتقام‌جویی یا دنبال‌کردن هیجانی بازار) دیده شده."
            ),
            severity=round(min(100.0, ratio * 150), 1), frequency=int(emotional_days),
            financial_impact=pnl, probability=round(ratio, 2),
            confidence=round(min(1.0, active_days / 20.0), 2),
            details={"emotional_days": int(emotional_days), "active_days": int(active_days)},
        )

    def get_top(self, n=8):
        return sorted(self.library, key=lambda e: e.priority_score, reverse=True)[:n]


