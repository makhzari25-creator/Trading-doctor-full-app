# -*- coding: utf-8 -*-
"""
engines/coaching_engine.py
-----------------------------
لایه‌ی نهایی: شواهد → تشخیص → DNA معاملاتی → برنامه‌ی اقدام + توضیح شفاف
(با پشتیبانی از LLM برای تولید توضیح coach-محور، و fallback هوشمند وقتی
LLM در دسترس نباشد).
"""

from typing import List

import config
from engines.evidence_engine import Evidence, EvidenceEngine, EvidenceType
from engines.diagnosis_engine import DiagnosisEngine
from engines.psychology_engine import PsychologyEngine
from engines.report_engine import FullResult
from llm.provider import get_llm
from utils.logger import get_logger

log = get_logger(__name__)


class CoachingEngine:
    """لایه‌ی نهایی: شواهد → تشخیص → DNA معاملاتی → برنامه‌ی اقدام + توضیح شفاف."""

    _ACTIONS = {
        EvidenceType.REVENGE: "بعد از هر باخت، حداقل یک استراحت اجباری (مثلاً ۳۰ دقیقه) بگذار و حجم بعدی را افزایش نده.",
        EvidenceType.OVERTRADING: "برای خودت سقف روزانه‌ی تعداد معامله تعیین کن (مثلاً حداکثر ۵ معامله در روز).",
        EvidenceType.RISK: "برای هر معامله یک حداکثر حجم ثابت (٪ از سرمایه) تعیین کن و از آن عبور نکن.",
        EvidenceType.PATIENCE: "بین دو معامله حداقل ۱۵ دقیقه فاصله بگذار، مخصوصاً بعد از باخت.",
        EvidenceType.EMOTIONAL: "یک چک‌لیست ذهنی قبل از هر ورود بساز و قبل از کلیک، آن را مرور کن.",
        EvidenceType.CONFIDENCE: "بعد از رشته‌ی بردهای پیاپی، حجم را عمداً همان سطح عادی نگه دار.",
        EvidenceType.RECOVERY: "بعد از یک افت بزرگ سرمایه، حداقل یک روز فقط با حجم کوچک یا کاغذی معامله کن.",
        EvidenceType.SESSION: "در روزهای ضعیفت یا معامله نکن یا حجم را به‌شدت کاهش بده.",
        EvidenceType.DECISION_QUALITY: "یک دفترچه‌ی معاملاتی (Trading Journal) شروع کن و دلیل هر ورود را قبل از انجامش بنویس.",
        EvidenceType.DRAWDOWN: "یک قانون توقف‌ضرر روزانه/هفتگی تعیین کن (مثلاً توقف بعد از ۵٪ افت).",
        EvidenceType.POSITION_SIZING: "حجم معاملاتت را دوره‌ای مرور کن تا از رشد ناخودآگاه آن جلوگیری شود.",
        EvidenceType.STREAK: "بعد از ۳ باخت پیاپی، معامله را برای بقیه‌ی روز متوقف کن.",
        EvidenceType.TIMING: "در بازه‌ی ساعتی ضعیفت یا معامله نکن یا استراتژی متفاوتی امتحان کن.",
        EvidenceType.CONSISTENCY: "روی یک استراتژی و اندازه‌ی پوزیشن ثابت تمرکز کن تا واریانس نتایج کم شود.",
        EvidenceType.FOMO: "قبل از ورود به یک حرکت قوی بازار، حداقل یک تاییدِ غیرِهیجانی از خودت بخواه.",
    }

    def __init__(self, doctor, llm_provider: str = None):
        self.doctor = doctor
        self.llm = None
        provider_name = (llm_provider or config.DEFAULT_LLM_PROVIDER or "").strip().lower()
        if provider_name in ("", "none"):
            return
        try:
            self.llm = get_llm(provider_name)
            log.info("LLM provider '%s' initialized successfully", provider_name)
        except Exception as e:
            # [AUDIT FIX] print() جایگزین شد با لاگینگ ساختاریافته (Step 6):
            # قبلاً این هشدار فقط با print() به stdout می‌رفت و در محیط
            # production (مثلاً Streamlit سرور) اصلاً قابل‌ردیابی نبود.
            log.warning("LLM provider '%s' unavailable, falling back to heuristic explanation: %s", provider_name, e)
            self.llm = None

    def generate(self, result: FullResult) -> dict:
        log.info("CoachingEngine.generate() started (%d trades)", len(self.doctor.df))
        ev = EvidenceEngine(self.doctor, result.context, result.performance, result.edge_map)
        evidences = ev.get_top(8)
        diagnosis = DiagnosisEngine().diagnose(evidences, result.behavior, result.performance)
        dna = PsychologyEngine().generate(evidences, result.context)
        explainable_ai = self._generate_explainable_ai(evidences, diagnosis, result)
        # [AUDIT FIX - real bug] Evidence.type است یک عضو Enum (EvidenceType)،
        # نه رشته. قبلاً e.__dict__ همان شیء Enum خام را در key_evidence
        # می‌گذاشت؛ صفحات UI (مثل pages/04_Diagnosis.py) که مستقیماً
        # ev.get('type') را در f-string چاپ می‌کردند، به‌جای "revenge" مقدار
        # زشت "EvidenceType.REVENGE" نمایش می‌دادند. اینجا در منبع مشترک
        # سریالایز می‌شود تا همه‌ی مصرف‌کننده‌ها (UI/JSON/API) رشته‌ی ساده
        # و قابل‌سریالایز ببینند؛ منطق تشخیص شواهد بدون تغییر است.
        key_evidence = [
            {**e.__dict__, "type": e.type.value if hasattr(e.type, "value") else e.type}
            for e in evidences
        ]
        log.info(
            "CoachingEngine.generate() finished: %d evidences, primary=%s",
            len(evidences), diagnosis.get("primary"),
        )
        return {
            "trader_dna": dna,
            "diagnosis": diagnosis,
            "key_evidence": key_evidence,
            "action_plan": self._build_action_plan(evidences),
            "explainable_ai": explainable_ai,
            "reality_check": "این تحلیل بر اساس داده‌های تاریخی شماست و تضمین آینده نیست.",
        }

    def answer_followup(self, question: str, result: FullResult, coach: dict, chat_history: List[dict]) -> str:
        """
        [Phase 6 — AI Coach workspace] پاسخ به یک سوال پیگیری آزاد درباره‌ی
        همین تحلیل. اگر LLM در دسترس نباشد، پیام روشن برمی‌گرداند (بدون
        هیچ ادعای جعلی) — هرگز یک پاسخ heuristic جعلی به‌جای LLM واقعی
        تولید نمی‌کند، چون این ویژگی صراحتاً یک گفت‌وگوی آزاد است، نه یک
        متن از‌پیش‌قالب‌بندی‌شده مثل explainable_ai.
        """
        if not self.llm:
            return "این ویژگی نیاز به یک LLM فعال دارد (در config.py تنظیم نشده است)."

        from llm.prompts import build_followup_prompt
        context_summary = (
            f"خلاصه: {result.summary}\n"
            f"امتیاز انضباط: {result.behavior.scores.get('discipline_score', 'N/A')}/100\n"
            f"تشخیص اصلی: {coach['diagnosis'].get('primary', 'N/A')}\n"
            f"تشخیص ثانویه: {coach['diagnosis'].get('secondary', 'ندارد')}\n"
            f"Trader DNA: {coach['trader_dna']}\n"
            f"شواهد کلیدی: {[e.get('description', '') for e in coach.get('key_evidence', [])[:5]]}\n"
            f"برنامه اقدام: {[a.get('action', '') for a in coach.get('action_plan', [])[:5]]}"
        )
        prompt = build_followup_prompt(context_summary, question, chat_history)
        log.info("LLM follow-up request started (provider=%s, history_len=%d)", self.llm.name, len(chat_history))
        try:
            response = self.llm.chat(prompt)
            log.info("LLM follow-up request succeeded (provider=%s, response_chars=%d)", self.llm.name, len(response or ""))
            return response
        except Exception as e:
            log.warning("LLM follow-up request failed (provider=%s): %s", self.llm.name, e, exc_info=True)
            return f"⚠️ پاسخ‌دهی موقتاً با خطا مواجه شد: {e}"

    def _generate_explainable_ai(self, evidences: List[Evidence], diagnosis: dict, result: FullResult) -> str:
        """اگر LLM در دسترس باشد از آن برای تولید توضیح coach-محور استفاده می‌کند،
        در غیر این صورت به توضیح قالب‌محور (heuristic) قدیمی برمی‌گردد."""
        if not self.llm:
            return self._fallback_explanation(evidences, diagnosis)

        # SAFE extraction
        primary = (
            diagnosis.get("primary")
            if isinstance(diagnosis, dict)
            else getattr(diagnosis, "primary", "نامشخص")
        )
        secondary = (
            diagnosis.get("secondary")
            if isinstance(diagnosis, dict)
            else getattr(diagnosis, "secondary", "ندارد")
        )

        evidence_text = []
        for e in evidences[:5]:
            evidence_text.append(getattr(e, "description", str(e)))

        from llm.prompts import build_coaching_prompt
        prompt = build_coaching_prompt(
            summary=getattr(result, "summary", "N/A"),
            primary=primary,
            secondary=secondary,
            evidence_text=evidence_text,
        )
        # [AUDIT FIX] لاگ درخواست/پاسخ LLM (Step 6) — عمداً فقط متادیتا
        # (provider، اندازه‌ی prompt/پاسخ) لاگ می‌شود، نه محتوای کامل
        # پرامپت یا پاسخ، چون این‌ها می‌توانند داده‌ی معاملاتی حساس کاربر
        # یا محتوای تولیدشده توسط LLM را در فایل لاگ ذخیره کنند.
        log.info("LLM request started (provider=%s, prompt_messages=%d)", self.llm.name, len(prompt))
        try:
            response = self.llm.chat(prompt)
            log.info("LLM request succeeded (provider=%s, response_chars=%d)", self.llm.name, len(response or ""))
            return response
        except Exception as e:
            log.warning("LLM request failed (provider=%s): %s", self.llm.name, e, exc_info=True)
            return self._fallback_explanation(evidences, diagnosis, str(e))

    def _fallback_explanation(self, evidences: List[Evidence], diagnosis: dict, error: str = None) -> str:
        base = self._explain(evidences, diagnosis)
        if error:
            return f"⚠️ LLM موقتاً در دسترس نیست\n\n{base}"
        return base

    @classmethod
    def _build_action_plan(cls, evidences: List[Evidence]) -> List[dict]:
        plan = []
        for e in evidences:
            action = cls._ACTIONS.get(e.type)
            if not action:
                continue
            plan.append({"issue": e.type.value, "action": action, "priority": e.priority_score})
        return plan

    @staticmethod
    def _explain(evidences: List[Evidence], diagnosis: dict) -> str:
        if not evidences:
            return "شاهد رفتاری قابل‌توجهی در داده‌ی فعلی پیدا نشد، بنابراین تشخیص خاصی صادر نشده است."
        header = (
            f"تشخیص اصلی «{diagnosis['primary']}» بر اساس {len(evidences)} شاهد رفتاری "
            f"استخراج‌شده از تاریخچه‌ی معاملاتت انتخاب شد. رتبه‌بندی بر اساس ترکیب چهار عامل "
            f"است: شدت رفتار، سهم آن از کل ضررها، اطمینان آماری (بر اساس تعداد رخداد) و اثر "
            f"مالی نسبی نسبت به بزرگ‌ترین شاهد."
        )
        lines = [header]
        for e in evidences[:3]:
            lines.append(
                f"- {e.type.value}: امتیاز اولویت {e.priority_score}/100 "
                f"({e.frequency} رخداد، اثر مالی {round(e.financial_impact, 2)}$، "
                f"اطمینان {round(e.confidence * 100)}%)."
            )
        return "\n".join(lines)
