# -*- coding: utf-8 -*-
"""
engines/behavior_engine.py
---------------------------
موتور اصلی تحلیل رفتار معاملاتی (قبلاً TradingDoctorV21_3).
ورودی: هر DataFrame از هر بروکر/صرافی (MT4, MT5, Binance, Bybit, ...)
خروجی: BehaviorResult شامل امتیازهای رفتاری و شبیه‌سازی what-if واقعی.

نگاشت ستون‌ها به utils/column_mapper.py منتقل شده تا این فایل فقط مسئول
منطق رفتاری/امتیازدهی باشد.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from utils.column_mapper import ColumnMapper
from utils.sequence_analysis import consecutive_streak, size_increased_mask
from utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class BehaviorResult:
    behavior_profile: dict
    scores: dict
    detected_patterns: List[str]
    explanations: dict
    what_if: dict


class BehaviorEngine:
    """موتور تحلیل رفتار معاملاتی — نسخه‌ی ماژولار TradingDoctorV21_3."""

    def __init__(self, df: pd.DataFrame):
        self._revenge_cache = None
        self.df = ColumnMapper.normalize(df.copy())
        self.df = self.df.reset_index(drop=True)

    @property
    def df(self) -> pd.DataFrame:
        return self._df

    @df.setter
    def df(self, new_df: pd.DataFrame):
        self._df = new_df
        self.invalidate_cache()

    def invalidate_cache(self):
        """پاک کردن کش — بعد از هر تغییر df به‌صورت خودکار صدا زده می‌شود."""
        self._revenge_cache = None

    # ------------------------------------------------------------------
    # امتیازهای رفتاری
    # ------------------------------------------------------------------

    def revenge_analysis(self):
        """
        تشخیص Revenge Trading (vectorized).
        برمی‌گرداند: (score: float, count: int)
        """
        if self._revenge_cache is not None:
            return self._revenge_cache

        if len(self.df) == 0:
            self._revenge_cache = (0.0, 0)
            return self._revenge_cache

        profit = self.df["Profit"].values
        size = self.df["Size"].values
        n = len(profit)

        # [AUDIT FIX] streak/size-increase قبلاً با یک حلقه‌ی دستی پایتون
        # این‌جا و در سه جای دیگر پروژه محاسبه می‌شد (duplicated logic).
        # حالا از یک پیاده‌سازی برداری مشترک استفاده می‌شود که با تست واحد
        # تأیید شده دقیقاً همان اعداد حلقه‌ی قدیمی را تولید می‌کند —
        # منطق تحلیلی هیچ تغییری نکرده، فقط سریع‌تر و بدون تکرار است.
        is_loss = profit < 0
        streak = consecutive_streak(is_loss)
        size_increased = size_increased_mask(size)
        revenge_mask = (streak >= 2) & is_loss & size_increased
        revenge_count = int(revenge_mask.sum())

        score = min(100.0, (revenge_count / max(n, 1)) * 500)
        self._revenge_cache = (round(score, 1), revenge_count)
        return self._revenge_cache

    def overtrading_score(self) -> float:
        """روزهایی با بیش از ۵ معامله / کل روزها."""
        if len(self.df) == 0 or self.df["Open Time"].isna().all():
            return 0.0
        trades_per_day = self.df["date"].value_counts()
        heavy_days_ratio = (trades_per_day > 5).mean() * 100
        return round(min(100.0, float(heavy_days_ratio)), 1)

    def risk_taking_score(self) -> float:
        """نسبت معاملاتی که حجمشان بیش از ۱.۵ برابر میانگین است."""
        if len(self.df) == 0 or self.df["Size"].mean() <= 0:
            return 0.0
        avg_size = self.df["Size"].mean()
        high_risk_ratio = (self.df["Size"] > avg_size * 1.5).mean() * 100
        return round(min(100.0, float(high_risk_ratio)), 1)

    def patience_score(self) -> float:
        """
        اندازه‌گیری صبر بر اساس فاصله‌ی زمانی بین معاملات.
        اگر Open Time نباشد، از fallback توالی ضررها استفاده می‌شود.
        """
        if len(self.df) < 2:
            return 100.0

        if self.df["Open Time"].isna().all():
            loss = self.df["Profit"] < 0
            quick_reentry = ((loss.shift(1) == True) & (loss == True)).sum()
            return round(max(0, 100 - int(quick_reentry) * 4), 1)

        gap_minutes = self.df["Open Time"].diff().dt.total_seconds() / 60.0
        loss = self.df["Profit"] < 0
        prev_loss = loss.shift(1).fillna(False)
        quick = (prev_loss & (gap_minutes < 15) & ~gap_minutes.isna()).sum()
        return round(max(0, 100 - int(quick) * 4), 1)

    def discipline_score(self) -> float:
        """
        امتیاز انضباط ترکیب‌شده:
          40% Revenge  +  25% Overtrading  +  15% Impatience  +  20% Risk
        """
        revenge, _ = self.revenge_analysis()
        over = self.overtrading_score()
        patience = self.patience_score()
        risk = self.risk_taking_score()
        score = max(
            0.0,
            100
            - (revenge * 0.40)
            - (over * 0.25)
            - ((100 - patience) * 0.15)
            - (risk * 0.20)
        )
        return round(score, 1)

    # ------------------------------------------------------------------
    # شبیه‌سازی what-if
    # ------------------------------------------------------------------

    def _simulate_what_if(self) -> dict:
        """
        شبیه‌سازی واقعی: اگر معاملات Revenge بدون افزایش حجم اتفاق می‌افتاد،
        discipline و سود خالص چقدر تغییر می‌کرد؟
        """
        _, revenge_count = self.revenge_analysis()
        if len(self.df) == 0 or revenge_count == 0:
            return {
                "discipline_improvement": "+0",
                "expected_profit_increase": "0%",
                "revenge_trades_adjusted": 0,
                "note": "معامله‌ی Revenge شناسایی نشد.",
            }

        profit = self.df["Profit"].values.copy()
        size = self.df["Size"].values.copy()
        is_loss = profit < 0

        # [AUDIT FIX] همان تحکیم منطق streak/size-increase به یک منبع
        # مشترک (utils/sequence_analysis) که در revenge_analysis() بالا هم
        # استفاده می‌شود — نتیجه‌ی عددی بدون تغییر.
        streak = consecutive_streak(is_loss)
        size_increased = size_increased_mask(size)
        revenge_mask = (streak >= 2) & is_loss & size_increased
        prev_size = np.concatenate(([np.nan], size[:-1]))

        with np.errstate(divide="ignore", invalid="ignore"):
            scale = np.where(
                revenge_mask & (size != 0),
                np.nan_to_num(prev_size / size, nan=1.0, posinf=1.0),
                1.0,
            )

        sim_df = self.df.copy()
        sim_df["Profit"] = profit * scale
        sim_df["Size"] = size * scale

        sim = BehaviorEngine.__new__(BehaviorEngine)
        sim._revenge_cache = None
        sim._df = sim_df

        disc_diff = round(sim.discipline_score() - self.discipline_score(), 1)
        curr_profit = float(self.df["Profit"].sum())
        sim_profit = float(sim_df["Profit"].sum())

        if curr_profit != 0:
            pct_chg = round((sim_profit - curr_profit) / abs(curr_profit) * 100, 1)
            profit_str = f"{'+' if pct_chg >= 0 else ''}{pct_chg}%"
        else:
            profit_str = "نامشخص (سود فعلی صفر است)"

        return {
            "discipline_improvement": f"{'+' if disc_diff >= 0 else ''}{disc_diff}",
            "expected_profit_increase": profit_str,
            "revenge_trades_adjusted": revenge_count,
            "disclaimer": "شبیه‌سازی what-if آماری روی داده‌ی تاریخی — نه تضمین آینده.",
        }

    # ------------------------------------------------------------------
    # خروجی اصلی
    # ------------------------------------------------------------------

    def build_behavior_engine(self) -> BehaviorResult:
        revenge_score, revenge_count = self.revenge_analysis()

        scores = {
            "revenge_score": revenge_score,
            "risk_taking_score": self.risk_taking_score(),
            "overtrading_score": self.overtrading_score(),
            "patience_score": self.patience_score(),
            "discipline_score": self.discipline_score(),
        }

        candidates = [
            ("Revenge trading behavior detected", revenge_score),
            ("High trading frequency detected", scores["overtrading_score"]),
            ("Risk escalation detected", scores["risk_taking_score"]),
        ]
        patterns = [name for name, sc in candidates if sc > 40]
        main_problem = (
            max([(n, s) for n, s in candidates if s > 40], key=lambda x: x[1])[0]
            if patterns else "No critical behavior issue"
        )

        return BehaviorResult(
            behavior_profile={
                "revenge_trades": revenge_count,
                "main_problem": main_problem,
            },
            scores=scores,
            detected_patterns=patterns,
            explanations={
                "revenge_score": (
                    f"از {len(self.df)} معامله، {revenge_count} معامله "
                    f"بعد از باخت حجم افزایش داده."
                ),
                "discipline_score": "ترکیب revenge + overtrading + patience + risk_taking",
            },
            what_if={"if_revenge_fixed": self._simulate_what_if()},
        )


# نام قدیمی برای سازگاری با کدهای قبلی که مستقیماً TradingDoctorV21_3 را
# ایمپورت می‌کنند.
TradingDoctorV21_3 = BehaviorEngine
