# -*- coding: utf-8 -*-
"""
engines/psychology_engine.py
-------------------------------
پروفایل روان‌شناختی/DNA معاملاتی تریدر (قبلاً TraderDNAEngine)، بر اساس
شواهد رفتاری اولویت‌بندی‌شده — نه آستانه‌های ثابت.
"""

from typing import List

from engines.evidence_engine import Evidence, EvidenceType


class PsychologyEngine:
    """پروفایل کیفی سبک معاملاتی کاربر بر اساس امتیازهای رفتاری واقعی (نه اعداد ثابت)."""

    # [FIX 3] نگاشت مستقیم از نوع «شاهد اصلی» (همان evidences[0] که
    # DiagnosisEngine هم برای diagnosis.primary استفاده می‌کند) به Archetype.
    # قبل از این فیکس، این موتور کاملاً مستقل از DiagnosisEngine عمل
    # می‌کرد؛ حالا هر دو از یک منبع واحد (evidences[0]) می‌آیند و همیشه
    # سازگارند.
    _ARCHETYPE_BY_PRIMARY_EVIDENCE = {
        EvidenceType.REVENGE:          "شکارچی انتقام‌جو (Impulsive Revenge Trader)",
        EvidenceType.OVERTRADING:      "معامله‌گر پرتکرار و بی‌ثبات (Overtrading-Driven Trader)",
        EvidenceType.RISK:             "معامله‌گر پرریسک با اعتمادبه‌نفس کاذب",
        EvidenceType.PATIENCE:         "معامله‌گر عجول (Impatient Trader)",
        EvidenceType.EMOTIONAL:        "معامله‌گر هیجانی (Emotional Trader)",
        EvidenceType.CONFIDENCE:       "معامله‌گر پرریسک با اعتمادبه‌نفس کاذب",
        EvidenceType.RECOVERY:         "معامله‌گر با ریکاوری ضعیف بعد از افت سرمایه",
        EvidenceType.SESSION:          "معامله‌گر وابسته به زمان (Session-Dependent Trader)",
        EvidenceType.DECISION_QUALITY: "معامله‌گر با کیفیت تصمیم‌گیری ناپایدار",
        EvidenceType.DRAWDOWN:         "معامله‌گر در معرض افت سرمایه‌ی شدید",
        EvidenceType.POSITION_SIZING:  "معامله‌گر با رشد ناخودآگاه ریسک",
        EvidenceType.STREAK:           "معامله‌گر بی‌ثبات",
        EvidenceType.TIMING:           "معامله‌گر وابسته به زمان (Session-Dependent Trader)",
        EvidenceType.CONSISTENCY:      "معامله‌گر بی‌ثبات",
        EvidenceType.FOMO:             "دنبال‌کننده‌ی هیجانی بازار (FOMO Trader)",
    }

    @staticmethod
    def _label(score: float, invert: bool = False) -> str:
        # invert=True یعنی هرچه امتیاز بالاتر بهتر است (مثل patience) و باید معکوس شود
        s = (100 - score) if invert else score
        if s < 30:
            return "Low"
        if s < 65:
            return "Medium"
        return "High"

    def generate(self, evidence: List[Evidence], context: dict) -> dict:
        revenge = context.get("revenge_score")
        overtrade = context.get("overtrading_score")
        risk = context.get("risk_taking_score")
        patience = context.get("patience_score")
        discipline = context.get("discipline_score")

        risk_label = self._label(risk.score) if risk else "Unknown"
        emotion_label = self._label(max(
            revenge.score if revenge else 0.0,
            overtrade.score if overtrade else 0.0,
        ))
        patience_label = self._label(patience.score, invert=True) if patience else "Unknown"

        conf_ev = next((e for e in evidence if e.type == EvidenceType.CONFIDENCE), None)
        confidence_label = self._label(conf_ev.severity) if conf_ev else "Medium"

        recovery_ev = next((e for e in evidence if e.type == EvidenceType.RECOVERY), None)
        if recovery_ev:
            recovery_label = "Weak"
        elif discipline and discipline.score >= 65:
            recovery_label = "Strong"
        else:
            recovery_label = "Medium"

        consistency_ev = next((e for e in evidence if e.type == EvidenceType.CONSISTENCY), None)
        if consistency_ev:
            consistency_label = "Low"
        elif discipline:
            consistency_label = self._label(discipline.score, invert=True)
        else:
            consistency_label = "Unknown"

        dna = {
            "risk": risk_label, "emotion": emotion_label, "patience": patience_label,
            "confidence": confidence_label, "recovery": recovery_label,
            "consistency": consistency_label,
        }
        # [FIX 3] archetype اکنون در وهله‌ی اول از همان evidence غالب
        # (evidence[0]) می‌آید که DiagnosisEngine هم برای diagnosis.primary
        # استفاده می‌کند. فقط وقتی هیچ شاهدی وجود ندارد (evidence خالی)
        # به heuristic قدیمی مبتنی بر برچسب‌های dna برمی‌گردیم.
        dna["archetype"] = self._archetype(dna, evidence)
        return dna

    @classmethod
    def _archetype(cls, dna: dict, evidence: "List[Evidence]" = None) -> str:
        if evidence:
            primary_type = evidence[0].type
            mapped = cls._ARCHETYPE_BY_PRIMARY_EVIDENCE.get(primary_type)
            if mapped:
                return mapped
        # fallback heuristic قدیمی — فقط وقتی هیچ شاهدی در دسترس نیست
        if dna["emotion"] == "High" and dna["patience"] == "Low":
            return "شکارچی انتقام‌جو (Impulsive Revenge Trader)"
        if dna["confidence"] == "High" and dna["risk"] == "High":
            return "معامله‌گر پرریسک با اعتمادبه‌نفس کاذب"
        if dna["consistency"] == "Low":
            return "معامله‌گر بی‌ثبات"
        if dna["risk"] == "Low" and dna["patience"] == "High":
            return "معامله‌گر محافظه‌کار و منضبط"
        return "معامله‌گر با سبک ترکیبی"


# نام قدیمی برای سازگاری با کد قبلی
TraderDNAEngine = PsychologyEngine
