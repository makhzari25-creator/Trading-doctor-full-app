# -*- coding: utf-8 -*-
"""
engines/diagnosis_engine.py
------------------------------
از فهرست شواهد اولویت‌بندی‌شده (Evidence)، مهم‌ترین و دومین مشکل رفتاری
تریدر را استخراج می‌کند.
"""

from typing import List

from engines.behavior_engine import BehaviorResult
from engines.evidence_engine import Evidence, EvidenceType


class DiagnosisEngine:
    """از فهرست شواهد اولویت‌بندی‌شده، مهم‌ترین و دومین مشکل رفتاری را استخراج می‌کند."""

    _LABELS = {
        EvidenceType.REVENGE: "معامله‌ی انتقامی (Revenge Trading)",
        EvidenceType.OVERTRADING: "بیش‌معامله‌گری (Overtrading)",
        EvidenceType.RISK: "ریسک‌پذیری بیش‌ازحد در حجم معاملات",
        EvidenceType.PATIENCE: "کم‌صبری و ورود سریع بعد از باخت",
        EvidenceType.EMOTIONAL: "معامله‌ی هیجانی مکرر",
        EvidenceType.CONFIDENCE: "اعتمادبه‌نفس بیش‌ازحد بعد از موفقیت",
        EvidenceType.RECOVERY: "ریکاوری ضعیف بعد از افت سرمایه",
        EvidenceType.SESSION: "عملکرد ضعیف در روزهای خاص هفته",
        EvidenceType.DECISION_QUALITY: "افت کیفیت تصمیم‌گیری کلی",
        EvidenceType.DRAWDOWN: "افت سرمایه‌ی قابل‌توجه",
        EvidenceType.POSITION_SIZING: "رشد ناخودآگاه حجم معاملات با گذر زمان",
        EvidenceType.STREAK: "رشته‌ی ضرر طولانی",
        EvidenceType.TIMING: "عملکرد ضعیف در بازه‌ی ساعتی خاص",
        EvidenceType.CONSISTENCY: "ناپایداری شدید عملکرد روزانه",
        EvidenceType.FOMO: "دنبال‌کردن هیجانی بازار (FOMO)",
    }

    def diagnose(self, evidence: List[Evidence], behavior: BehaviorResult, performance: dict) -> dict:
        if not evidence:
            return {
                "primary": "مشکل رفتاری قابل‌توجهی شناسایی نشد",
                "primary_detail": "با داده‌ی فعلی، رفتار معاملاتی در محدوده‌ی طبیعی به‌نظر می‌رسد.",
                "secondary": None,
                "secondary_detail": None,
                "confidence_level": "Low",
            }

        primary = evidence[0]
        secondary = next((e for e in evidence[1:] if e.type != primary.type), None)

        def _confidence_label(e: Evidence) -> str:
            if e.confidence >= 0.7 and e.priority_score >= 60:
                return "High"
            if e.confidence >= 0.4 or e.priority_score >= 35:
                return "Medium"
            return "Low"

        return {
            "primary": self._LABELS.get(primary.type, primary.type.value),
            "primary_detail": primary.description,
            "secondary": self._LABELS.get(secondary.type, secondary.type.value) if secondary else None,
            "secondary_detail": secondary.description if secondary else None,
            "confidence_level": _confidence_label(primary),
        }
