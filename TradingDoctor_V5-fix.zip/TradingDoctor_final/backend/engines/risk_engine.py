# -*- coding: utf-8 -*-
"""
engines/risk_engine.py
------------------------
لایه‌ی متمرکز روی «ریسک» معاملاتی: حجم‌گذاری، Revenge Trading، و
شبیه‌سازی what-if. محاسبات پایه هنوز داخل BehaviorEngine انجام می‌شود
(چون revenge/discipline/risk به‌شدت به‌هم وابسته و کش‌شده هستند)، اما
این کلاس یک واجهه‌ی تمیز و مستقل برای هر بخشی از برنامه که فقط به
تحلیل ریسک نیاز دارد (بدون کل خط لوله‌ی رفتاری) فراهم می‌کند.
"""

from typing import Tuple

import pandas as pd

from engines.behavior_engine import BehaviorEngine


class RiskEngine:
    """واجهه‌ی مستقل برای پرسش‌های مربوط به ریسک معاملاتی."""

    def __init__(self, df_or_engine):
        if isinstance(df_or_engine, BehaviorEngine):
            self._engine = df_or_engine
        else:
            self._engine = BehaviorEngine(df_or_engine)

    # ------------------------------------------------------------------
    # متریک‌های ریسک
    # ------------------------------------------------------------------

    def revenge_analysis(self) -> Tuple[float, int]:
        """امتیاز و تعداد رخدادهای Revenge Trading."""
        return self._engine.revenge_analysis()

    def risk_taking_score(self) -> float:
        """نسبت معاملاتی با حجم غیرعادی (بیش از ۱.۵ برابر میانگین)."""
        return self._engine.risk_taking_score()

    def position_sizing_stats(self) -> dict:
        """آمار پایه‌ی حجم معاملات، برای مانیتور کردن رشد ناخودآگاه حجم."""
        df = self._engine.df
        if len(df) == 0:
            return {"avg_size": 0.0, "max_size": 0.0, "std_size": 0.0}
        size = df["Size"]
        return {
            "avg_size": round(float(size.mean()), 4),
            "max_size": round(float(size.max()), 4),
            "std_size": round(float(size.std(ddof=0)), 4) if len(size) > 1 else 0.0,
        }

    def what_if_no_revenge(self) -> dict:
        """شبیه‌سازی: اگر معاملات Revenge بدون افزایش حجم رخ می‌داد چه می‌شد؟"""
        return self._engine._simulate_what_if()

    def risk_report(self) -> dict:
        """گزارش کامل ریسک، برای استفاده در ReportEngine یا CoachingEngine."""
        score, count = self.revenge_analysis()
        return {
            "revenge_score": score,
            "revenge_trade_count": count,
            "risk_taking_score": self.risk_taking_score(),
            "position_sizing": self.position_sizing_stats(),
            "what_if_no_revenge": self.what_if_no_revenge(),
        }
