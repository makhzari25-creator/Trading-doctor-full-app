import streamlit as st
import pandas as pd
import sys
from pathlib import Path

# اضافه کردن مسیرها
BASE_DIR = Path(__file__).parent
sys.path.append(str(BASE_DIR))

from core.service import analyze_file
from utils.file_loader import UnsupportedFileError
from utils.validation import DataValidationError
from utils.logger import get_logger
from ui.theme import inject_theme
from ui.history import add_entry
from ui.shortcuts import inject_keyboard_shortcuts

log = get_logger("app")

st.set_page_config(page_title="Trading Doctor V23", layout="wide", page_icon="🩺")
inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6 — design/07... (see design/06_PHASE_5B... for prior phases)

st.title("🩺 Trading Doctor V23")
st.subheader("تحلیل روانشناسی و رفتار معاملاتی")

# [Phase 6] راهنمای گام‌به‌گام — بهبود onboarding بدون تغییر منطق آپلود.
# پیش از این، صفحه فقط یک uploader خام بدون زمینه بود.
_has_result = 'result' in st.session_state
step_cols = st.columns(3)
with step_cols[0]:
    st.markdown(f'<span class="td-badge {"td-badge-low" if _has_result else "td-badge-neutral"}">۱ · آپلود فایل</span>', unsafe_allow_html=True)
with step_cols[1]:
    st.markdown(f'<span class="td-badge {"td-badge-low" if _has_result else "td-badge-neutral"}">۲ · اجرای تحلیل</span>', unsafe_allow_html=True)
with step_cols[2]:
    st.markdown(f'<span class="td-badge {"td-badge-low" if _has_result else "td-badge-neutral"}">۳ · بررسی نتایج در صفحات کناری</span>', unsafe_allow_html=True)

st.caption(
    "فرمت‌های پشتیبانی‌شده: CSV، Excel (xlsx/xls)، HTML/HTM، TXT/LOG، JSON — "
    "ستون‌های Profit/Size/Open Time به‌صورت خودکار شناسایی می‌شوند، حتی اگر نام‌گذاری بروکر شما متفاوت باشد."
)

# پشتیبانی از هر فرمت خروجی بروکر — نه فقط CSV. utils/file_loader.py
# تشخیص می‌دهد فایل xlsx/htm/log(HTML یا متنی)/json/csv است و آن را به
# DataFrame استاندارد تبدیل می‌کند؛ نیازی به تبدیل دستی نیست.
uploaded_file = st.file_uploader(
    "فایل معاملات را آپلود کنید",
    type=["csv", "txt", "tsv", "xlsx", "xls", "htm", "html", "log", "json"],
)

if uploaded_file:
    if st.button("🚀 شروع تحلیل", type="primary"):
        progress = st.progress(0, text="در حال خواندن فایل...")
        try:
            log.info("Analysis requested for uploaded file: %s", uploaded_file.name)
            progress.progress(25, text="در حال بارگذاری و اعتبارسنجی داده...")
            _llm_provider = "gemini"
            doctor, result, coach = analyze_file(
                uploaded_file, filename=uploaded_file.name, llm_provider=_llm_provider
            )
            progress.progress(90, text="در حال نهایی‌سازی نتایج...")

            st.session_state['result'] = result
            st.session_state['coach'] = coach
            # [Phase 6] ذخیره‌ی provider واقعاً استفاده‌شده تا AI Coach
            # workspace (pages/05_Coaching.py) بتواند سوالات پیگیری را با
            # همان provider اصلی (نه یک حدس جدا) پاسخ دهد.
            st.session_state['llm_provider'] = _llm_provider
            # مهم: doctor.df (نرمال‌شده، با ستون‌های استاندارد Open
            # Time/Profit/Size/hour) ذخیره می‌شود، نه فایل خام آپلودی
            # — وگرنه صفحاتی مثل Charts/Trends که دنبال این ستون‌های
            # استاندارد می‌گردند چیزی پیدا نمی‌کنند و سایلنت خالی
            # می‌مانند.
            st.session_state['df'] = doctor.df
            st.session_state['doctor'] = doctor
            progress.progress(95, text="در حال ذخیره در تاریخچه...")

            # [Phase 6 — Auto-save] هر تحلیل موفق بلافاصله و بدون نیاز به
            # اقدام دستی کاربر به تاریخچه‌ی همین session اضافه می‌شود.
            add_entry(uploaded_file.name, doctor, result, coach, llm_provider=_llm_provider)

            progress.progress(100, text="تحلیل کامل شد.")

            log.info("Analysis completed successfully (%d trades)", len(doctor.df))
            st.success(
                f"تحلیل با موفقیت انجام شد ({len(doctor.df)} معامله). "
                "از منوی سمت چپ صفحات را ببینید."
            )

            # [AUDIT FIX] هشدارهای کیفیت داده (Step 4) قبلاً فقط در CLI
            # (main.py) نمایش داده می‌شدند؛ کاربر Streamlit هیچ نشانه‌ای از
            # مشکلات جزئی داده (ستون شناسایی‌نشده، تاریخ‌های نامعتبر، حجم
            # صفر/منفی) نمی‌دید. حالا هر دو مسیر ورودی (CLI و Web) یکسان
            # این هشدارها را نشان می‌دهند.
            warnings = getattr(doctor, "data_quality_warnings", [])
            if warnings:
                with st.expander(f"⚠️ {len(warnings)} هشدار کیفیت داده — کلیک برای مشاهده", expanded=False):
                    for w in warnings:
                        st.warning(w)
        except UnsupportedFileError as e:
            # [AUDIT FIX] پیام واضح و کاربرپسند به‌جای traceback خام؛
            # جزئیات فنی کامل فقط در لاگ (Step 5: هرگز traceback به
            # کاربر نهایی نشان داده نشود).
            progress.empty()
            log.warning("Unsupported file rejected: %s", e)
            st.error(f"❌ فرمت یا محتوای فایل قابل‌پردازش نیست:\n\n{e}")
        except DataValidationError as e:
            progress.empty()
            log.warning("Data validation failed: %s", e)
            st.error(f"❌ داده‌ی فایل معتبر نیست:\n\n{e}")
        except Exception as e:
            progress.empty()
            log.error("Unexpected error during analysis", exc_info=True)
            st.error(
                "❌ خطای غیرمنتظره‌ای در تحلیل رخ داد. تیم فنی از طریق لاگ‌های "
                "سرور مطلع خواهد شد. لطفاً دوباره تلاش کنید یا فایل دیگری را "
                "آپلود کنید.\n\n"
                f"جزئیات خلاصه: {type(e).__name__}"
            )

# صفحات دیگر
st.sidebar.title("منو")
# [AUDIT FIX - real bug] این لینک‌ها قبلاً به فایل‌های غیرموجود
# "pages/1_Analysis.py", "pages/2_Report.py", "pages/3_Settings.py" اشاره
# می‌کردند (باقی‌مانده از یک ساختار قدیمی‌تر صفحات) و کلیک روی هرکدام در
# Streamlit با خطای «صفحه پیدا نشد» مواجه می‌شد. نام فایل‌های واقعی و
# موجود در پوشه‌ی pages/ جایگزین شدند.
st.sidebar.page_link("pages/01_Dashboard.py", label="📊 داشبورد")
st.sidebar.page_link("pages/02_Charts.py", label="📈 نمودارها")
st.sidebar.page_link("pages/03_Behavioral_Analysis.py", label="📉 تحلیل رفتاری")
st.sidebar.page_link("pages/04_Diagnosis.py", label="🔍 تشخیص")
st.sidebar.page_link("pages/05_Coaching.py", label="💡 Coaching")
st.sidebar.page_link("pages/06_Trader_DNA.py", label="🧬 Trader DNA")
st.sidebar.page_link("pages/07_Edge_Map.py", label="🗺️ Edge Map")
st.sidebar.page_link("pages/08_Report.py", label="📄 گزارش")
st.sidebar.page_link("pages/09_Trends.py", label="📈 روند")
st.sidebar.page_link("pages/10_History.py", label="🕘 تاریخچه")
st.sidebar.page_link("pages/11_Downloads.py", label="⬇️ مرکز دانلود")
