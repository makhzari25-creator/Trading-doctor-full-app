# -*- coding: utf-8 -*-
"""
alembic/env.py
--------------
Phase 7.5 — Alembic migration environment for TradingDoctor SaaS.

Reads DATABASE_URL_SYNC (NOT DATABASE_URL) because Alembic does not support
asyncpg directly. Models are auto-discovered by importing `db.models` so
`alembic revision --autogenerate` sees all registered tables.

Usage:
    alembic upgrade head              # apply all migrations
    alembic revision --autogenerate -m "description"
    alembic downgrade -1              # rollback last migration
    alembic current                   # show current revision
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

# Make the project root importable so `from db.base import Base` works.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Import the declarative Base and ensure all models are registered.
# (Importing db.models is enough — each model class registers itself with
# Base.metadata on import.)
from db.base import Base  # noqa: E402
import db.models  # noqa: F401, E402  — registers ORM classes on Base.metadata

# Load logging config from alembic.ini.
config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Set target_metadata so autogenerate can diff against current models.
target_metadata = Base.metadata


def _get_sync_url() -> str:
    """Return sync DB URL. Falls back to async URL with driver swap."""
    url = os.getenv("DATABASE_URL_SYNC", "").strip()
    if url:
        return url

    # Allow async URL by stripping the +asyncpg suffix.
    async_url = os.getenv("DATABASE_URL", "").strip()
    if not async_url:
        raise RuntimeError(
            "Neither DATABASE_URL_SYNC nor DATABASE_URL is set. "
            "Configure one in your .env before running migrations."
        )
    # postgresql+asyncpg://...  ->  postgresql://...
    return async_url.replace("+asyncpg", "")


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode — emit SQL to stdout without DB connection."""
    url = _get_sync_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode — connect to DB and apply."""
    cfg = config.get_section(config.config_ini_section) or {}
    cfg["sqlalchemy.url"] = _get_sync_url()

    connectable = engine_from_config(
        cfg,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
