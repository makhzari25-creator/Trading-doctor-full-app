"""phase 10: billing tables (plans, subscriptions, invoices, usage_events)

Revision ID: 0004_phase10_billing
Revises: 0003_phase9_workspace
Create Date: 2026-07-18 00:03:00.000000

Phase 10 — Subscription & Billing System.

Adds four tables:
  - plans           (catalog of subscription plans; seeded at deploy time)
  - subscriptions   (a user's current subscription state)
  - invoices        (one per billing period; mirrors Stripe invoices)
  - usage_events    (append-only log of metered usage)

Design notes:
  - Plans stored in DB so they can be updated without redeploy
  - Subscriptions track Stripe IDs for reconciliation
  - Partial unique index: one ACTIVE subscription per user (canceled kept for history)
  - Usage events append-only (no UPDATE) — aggregation computes monthly totals
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "0004_phase10_billing"
down_revision: Union[str, None] = "0003_phase9_workspace"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- Enums ---
    plan_tier_enum = sa.Enum("free", "pro", "premium", name="plan_tier")
    subscription_status_enum = sa.Enum(
        "trialing", "active", "past_due", "canceled", "unpaid", "incomplete",
        name="subscription_status",
    )
    invoice_status_enum = sa.Enum(
        "draft", "open", "paid", "void", "uncollectible",
        name="invoice_status",
    )
    usage_event_type_enum = sa.Enum(
        "analysis_run", "upload_bytes", "llm_call", "report_download",
        name="usage_event_type",
    )

    plan_tier_enum.create(op.get_bind(), checkfirst=True)
    subscription_status_enum.create(op.get_bind(), checkfirst=True)
    invoice_status_enum.create(op.get_bind(), checkfirst=True)
    usage_event_type_enum.create(op.get_bind(), checkfirst=True)

    # --- plans ---
    op.create_table(
        "plans",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("tier", plan_tier_enum, nullable=False, unique=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("price_cents", sa.Integer, nullable=False, server_default="0"),
        sa.Column("currency", sa.String(3), nullable=False, server_default="usd"),
        sa.Column("interval", sa.String(20), nullable=False, server_default="month"),
        sa.Column("max_analyses_per_month", sa.Integer, nullable=False, server_default="-1"),
        sa.Column("max_upload_size_bytes", sa.Integer, nullable=False, server_default="-1"),
        sa.Column("max_total_upload_bytes", sa.Integer, nullable=False, server_default="-1"),
        sa.Column("max_llm_calls_per_month", sa.Integer, nullable=False, server_default="-1"),
        sa.Column("allows_pdf_export", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("allows_ai_coaching", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("allows_history_search", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("allows_favorites", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("priority_support", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("stripe_price_id", sa.String(100), nullable=True),
        sa.Column("is_public", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_plans_tier", "plans", ["tier"], unique=True)

    # --- subscriptions ---
    op.create_table(
        "subscriptions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("plan_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("plans.id", ondelete="RESTRICT"),
                  nullable=False),
        sa.Column("status", subscription_status_enum, nullable=False,
                  server_default="active"),
        sa.Column("stripe_customer_id", sa.String(100), nullable=True),
        sa.Column("stripe_subscription_id", sa.String(100), nullable=True),
        sa.Column("current_period_start", sa.DateTime(timezone=True), nullable=True),
        sa.Column("current_period_end", sa.DateTime(timezone=True), nullable=True),
        sa.Column("canceled_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("cancel_reason", sa.String(50), nullable=True),
        sa.Column("trial_start", sa.DateTime(timezone=True), nullable=True),
        sa.Column("trial_end", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_subscriptions_user_id", "subscriptions", ["user_id"])
    op.create_index("ix_subscriptions_plan_id", "subscriptions", ["plan_id"])
    op.create_index("ix_subscriptions_status", "subscriptions", ["status"])
    op.create_index("ix_subscriptions_stripe_customer_id", "subscriptions", ["stripe_customer_id"])
    op.create_index("ix_subscriptions_stripe_subscription_id", "subscriptions", ["stripe_subscription_id"])
    # Partial unique index: one active subscription per user.
    op.create_index(
        "uq_subscriptions_user_active",
        "subscriptions",
        ["user_id"],
        unique=True,
        postgresql_where=sa.text("status IN ('trialing', 'active', 'past_due', 'unpaid', 'incomplete')"),
    )

    # --- invoices ---
    op.create_table(
        "invoices",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("subscription_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("subscriptions.id", ondelete="SET NULL"),
                  nullable=True),
        sa.Column("plan_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("plans.id", ondelete="SET NULL"),
                  nullable=True),
        sa.Column("stripe_invoice_id", sa.String(100), nullable=True, unique=True),
        sa.Column("status", invoice_status_enum, nullable=False, server_default="draft"),
        sa.Column("amount_due_cents", sa.Integer, nullable=False, server_default="0"),
        sa.Column("amount_paid_cents", sa.Integer, nullable=False, server_default="0"),
        sa.Column("currency", sa.String(3), nullable=False, server_default="usd"),
        sa.Column("period_start", sa.DateTime(timezone=True), nullable=True),
        sa.Column("period_end", sa.DateTime(timezone=True), nullable=True),
        sa.Column("paid_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("invoice_pdf_url", sa.String(512), nullable=True),
        sa.Column("hosted_invoice_url", sa.String(512), nullable=True),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_invoices_user_id", "invoices", ["user_id"])
    op.create_index("ix_invoices_subscription_id", "invoices", ["subscription_id"])
    op.create_index("ix_invoices_plan_id", "invoices", ["plan_id"])
    op.create_index("ix_invoices_stripe_invoice_id", "invoices", ["stripe_invoice_id"], unique=True)
    op.create_index("ix_invoices_status", "invoices", ["status"])

    # --- usage_events ---
    op.create_table(
        "usage_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("event_type", usage_event_type_enum, nullable=False),
        sa.Column("quantity", sa.Integer, nullable=False, server_default="1"),
        sa.Column("resource_id", sa.String(64), nullable=True),
        sa.Column("details", sa.Text, nullable=True),
        sa.Column("billing_period", sa.String(7), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_usage_events_user_id", "usage_events", ["user_id"])
    op.create_index("ix_usage_events_event_type", "usage_events", ["event_type"])
    op.create_index("ix_usage_events_billing_period", "usage_events", ["billing_period"])
    op.create_index(
        "ix_usage_events_user_period_type",
        "usage_events", ["user_id", "billing_period", "event_type"],
    )


def downgrade() -> None:
    op.drop_table("usage_events")
    op.drop_table("invoices")
    op.drop_table("subscriptions")
    op.drop_table("plans")
    usage_event_type_enum = sa.Enum("analysis_run", "upload_bytes", "llm_call", "report_download",
                                    name="usage_event_type")
    invoice_status_enum = sa.Enum("draft", "open", "paid", "void", "uncollectible",
                                  name="invoice_status")
    subscription_status_enum = sa.Enum("trialing", "active", "past_due", "canceled", "unpaid", "incomplete",
                                       name="subscription_status")
    plan_tier_enum = sa.Enum("free", "pro", "premium", name="plan_tier")
    usage_event_type_enum.drop(op.get_bind(), checkfirst=True)
    invoice_status_enum.drop(op.get_bind(), checkfirst=True)
    subscription_status_enum.drop(op.get_bind(), checkfirst=True)
    plan_tier_enum.drop(op.get_bind(), checkfirst=True)
