"""phase 11: analysis_jobs table for async Celery-based analysis

Revision ID: 0005_phase11_jobs
Revises: 0004_phase10_billing
Create Date: 2026-07-18 00:04:00.000000

Phase 11 — Async analysis runs via Celery.

Adds one table:
  - analysis_jobs  (background job tracking for POST /analyses)

When Celery is enabled (TRADING_DOCTOR_USE_CELERY=true), POST /analyses
creates an AnalysisJob row + dispatches a Celery task, then returns 202 +
job_id immediately. The client polls GET /analyses/jobs/{job_id} until
status=completed.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "0005_phase11_jobs"
down_revision: Union[str, None] = "0004_phase10_billing"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "analysis_jobs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("upload_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("uploads.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("analysis_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("analyses.id", ondelete="SET NULL"),
                  nullable=True),
        sa.Column("llm_provider", sa.String(20), nullable=False, server_default="none"),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("celery_task_id", sa.String(64), nullable=True),
        sa.Column("total_trades", sa.Integer, nullable=True),
        sa.Column("overall_score", sa.Integer, nullable=True),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_analysis_jobs_user_id", "analysis_jobs", ["user_id"])
    op.create_index("ix_analysis_jobs_upload_id", "analysis_jobs", ["upload_id"])
    op.create_index("ix_analysis_jobs_analysis_id", "analysis_jobs", ["analysis_id"])
    op.create_index("ix_analysis_jobs_status", "analysis_jobs", ["status"])
    op.create_index("ix_analysis_jobs_celery_task_id", "analysis_jobs", ["celery_task_id"])
    op.create_index("ix_analysis_jobs_user_status", "analysis_jobs", ["user_id", "status"])
    op.create_index("ix_analysis_jobs_created", "analysis_jobs", ["created_at"])


def downgrade() -> None:
    op.drop_table("analysis_jobs")
