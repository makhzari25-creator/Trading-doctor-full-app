"""phase 9: workspace tables (uploads, analyses, cache, favorites)

Revision ID: 0003_phase9_workspace
Revises: 0002_phase8_auth
Create Date: 2026-07-18 00:02:00.000000

Phase 9 — Persistent SaaS Workspace.

Adds four tables:
  - uploads                (raw trade-log file metadata, per user)
  - analyses               (analysis results, per user — pickled engine output)
  - analysis_report_cache  (cached HTML/PDF renders, keyed by analysis_id)
  - favorites              (user's starred analyses, one-to-many)

Design notes:
  - Per-user isolation: every table has user_id FK + index
  - Soft-delete on uploads + analyses (reversible deletion)
  - Cached engine outputs stored as BYTEA (Postgres) / LONGBLOB (MySQL)
  - Content hash on uploads for deduplication potential
  - Unique constraint on (user_id, analysis_id) in favorites
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = "0003_phase9_workspace"
down_revision: Union[str, None] = "0002_phase8_auth"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- uploads ---
    op.create_table(
        "uploads",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("size_bytes", sa.Integer, nullable=False),
        sa.Column("storage_path", sa.String(512), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=True),
        sa.Column("file_type", sa.String(10), nullable=False),
        sa.Column("label", sa.String(255), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_uploads_user_id", "uploads", ["user_id"])
    op.create_index("ix_uploads_content_hash", "uploads", ["content_hash"])
    op.create_index("ix_uploads_user_created", "uploads", ["user_id", "created_at"])

    # --- analyses ---
    op.create_table(
        "analyses",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("upload_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("uploads.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("llm_provider", sa.String(20), nullable=False, server_default="none"),
        sa.Column("total_trades", sa.Integer, nullable=False, server_default="0"),
        sa.Column("overall_score", sa.Integer, nullable=False, server_default="0"),
        sa.Column("primary_diagnosis", sa.String(255), nullable=True),
        sa.Column("data_quality_warning_count", sa.Integer, nullable=False, server_default="0"),
        # BYTEA in Postgres, LONGBLOB equivalent in MySQL
        sa.Column("engine_doctor_bytes", postgresql.BYTEA, nullable=False),
        sa.Column("engine_result_bytes", postgresql.BYTEA, nullable=False),
        sa.Column("engine_coach_bytes", postgresql.BYTEA, nullable=False),
        sa.Column("label", sa.String(255), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_analyses_user_id", "analyses", ["user_id"])
    op.create_index("ix_analyses_upload_id", "analyses", ["upload_id"])
    op.create_index("ix_analyses_user_created", "analyses", ["user_id", "created_at"])
    op.create_index("ix_analyses_user_score", "analyses", ["user_id", "overall_score"])

    # --- analysis_report_cache ---
    op.create_table(
        "analysis_report_cache",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("analysis_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("analyses.id", ondelete="CASCADE"),
                  nullable=False, unique=True),
        sa.Column("html_bytes", postgresql.BYTEA, nullable=True),
        sa.Column("pdf_bytes", postgresql.BYTEA, nullable=True),
        sa.Column("cache_version", sa.String(20), nullable=False, server_default="v1"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_analysis_report_cache_analysis_id",
                    "analysis_report_cache", ["analysis_id"], unique=True)

    # --- favorites ---
    op.create_table(
        "favorites",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("analysis_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("analyses.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("note", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_favorites_user_id", "favorites", ["user_id"])
    op.create_index("ix_favorites_analysis_id", "favorites", ["analysis_id"])
    op.create_unique_constraint("uq_favorites_user_analysis", "favorites",
                                ["user_id", "analysis_id"])


def downgrade() -> None:
    op.drop_table("favorites")
    op.drop_table("analysis_report_cache")
    op.drop_table("analyses")
    op.drop_table("uploads")
