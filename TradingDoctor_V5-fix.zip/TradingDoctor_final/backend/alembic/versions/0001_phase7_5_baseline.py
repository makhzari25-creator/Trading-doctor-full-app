"""phase 7.5 baseline — empty schema marker

Revision ID: 0001_phase7_5_baseline
Revises:
Create Date: 2026-07-18 00:00:00.000000

Phase 7.5 baseline migration.

This migration does NOT create any tables — it establishes the migration
framework baseline only. Phase 8 will introduce the first real table (users).

Run this against an EMPTY database to mark it as "managed by Alembic".
If the database already contains tables (e.g. from a previous non-Alembic
deployment), use `alembic stamp head` instead of `alembic upgrade head` to
mark the current state without applying migrations.

Usage:
    # Fresh database:
    alembic upgrade head

    # Pre-existing database (mark as already at baseline):
    alembic stamp 0001_phase7_5_baseline
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "0001_phase7_5_baseline"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Baseline migration — no-op. Tables will be added in Phase 8+."""
    # Explicitly enable the gen_random_uuid() extension (required by
    # UUIDPkMixin's server_default). Safe to call if already enabled.
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")


def downgrade() -> None:
    """Cannot downgrade past baseline."""
    pass
