"""phase 8: users + refresh_tokens + audit_logs + email_verifications

Revision ID: 0002_phase8_auth
Revises: 0001_phase7_5_baseline
Create Date: 2026-07-18 00:01:00.000000

Phase 8 — Authentication & User Management.

Adds four tables:
  - users              (the central account record)
  - refresh_tokens     (rotating refresh tokens, hashed at rest)
  - audit_logs         (immutable record of every auth event)
  - email_verifications (one-time tokens for verification + password reset)

Design notes:
  - UUID primary keys (uses pgcrypto's gen_random_uuid())
  - Email uniqueness among non-deleted users only (partial index)
  - Refresh tokens stored as SHA-256 hash — DB dump cannot be used to mint tokens
  - Audit logs are append-only (no UPDATE or DELETE exposed at service layer)
  - Soft-delete on users via deleted_at column
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = "0002_phase8_auth"
down_revision: Union[str, None] = "0001_phase7_5_baseline"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

user_status_enum = sa.Enum(
    "pending", "active", "suspended", "deleted",
    name="user_status",
)
audit_event_type_enum = sa.Enum(
    "register", "login", "login_failed", "logout", "refresh", "refresh_failed",
    "email_verification_sent", "email_verified",
    "password_reset_requested", "password_reset_completed", "password_changed",
    "account_suspended", "account_reactivated", "account_deleted",
    name="audit_event_type",
)
email_verification_type_enum = sa.Enum(
    "email_verification", "password_reset",
    name="email_verification_type",
)


def upgrade() -> None:
    # --- Enums ---
    user_status_enum.create(op.get_bind(), checkfirst=True)
    audit_event_type_enum.create(op.get_bind(), checkfirst=True)
    email_verification_type_enum.create(op.get_bind(), checkfirst=True)

    # --- users ---
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(255), nullable=True),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("status", user_status_enum, nullable=False,
                  server_default="pending"),
        sa.Column("email_verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("failed_login_attempts", sa.Integer, nullable=False,
                  server_default="0"),
        sa.Column("locked_until", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_login_ip", sa.String(45), nullable=True),
        sa.Column("locale", sa.String(10), nullable=True),
        sa.Column("marketing_consent", sa.Boolean, nullable=False,
                  server_default=sa.text("false")),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_users_email", "users", ["email"])
    op.create_index("ix_users_status", "users", ["status"])
    # Partial unique index: email must be unique among non-deleted users.
    op.create_index(
        "uq_users_email_active",
        "users",
        ["email"],
        unique=True,
        postgresql_where=sa.text("deleted_at IS NULL"),
    )

    # --- refresh_tokens ---
    op.create_table(
        "refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("token_hash", sa.String(64), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revoked_reason", sa.String(50), nullable=True),
        sa.Column("replaced_by_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("refresh_tokens.id", ondelete="SET NULL"),
                  nullable=True),
        sa.Column("issued_ip", sa.String(45), nullable=True),
        sa.Column("issued_user_agent", sa.String(512), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_refresh_tokens_token_hash", "refresh_tokens", ["token_hash"], unique=True)
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])
    op.create_index("ix_refresh_tokens_expires_at", "refresh_tokens", ["expires_at"])
    op.create_index(
        "ix_refresh_tokens_user_active",
        "refresh_tokens", ["user_id", "revoked_at"],
    )

    # --- audit_logs ---
    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="SET NULL"),
                  nullable=True),
        sa.Column("event_type", audit_event_type_enum, nullable=False),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("user_agent", sa.String(512), nullable=True),
        sa.Column("details", sa.Text, nullable=True),
        sa.Column("outcome", sa.String(20), nullable=False, server_default="info"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index("ix_audit_logs_user_id", "audit_logs", ["user_id"])
    op.create_index("ix_audit_logs_event_type", "audit_logs", ["event_type"])
    op.create_index("ix_audit_logs_ip_address", "audit_logs", ["ip_address"])

    # --- email_verifications ---
    op.create_table(
        "email_verifications",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("verification_type", email_verification_type_enum, nullable=False),
        sa.Column("token_hash", sa.String(64), nullable=False),
        sa.Column("sent_to_email", sa.String(255), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("consumed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("issued_ip", sa.String(45), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False,
                  server_default=sa.text("now()")),
    )
    op.create_index(
        "ix_email_verifications_token_hash",
        "email_verifications", ["token_hash"], unique=True,
    )
    op.create_index(
        "ix_email_verifications_user_type_active",
        "email_verifications",
        ["user_id", "verification_type", "consumed_at"],
    )


def downgrade() -> None:
    op.drop_table("email_verifications")
    op.drop_table("audit_logs")
    op.drop_table("refresh_tokens")
    op.drop_table("users")
    email_verification_type_enum.drop(op.get_bind(), checkfirst=True)
    audit_event_type_enum.drop(op.get_bind(), checkfirst=True)
    user_status_enum.drop(op.get_bind(), checkfirst=True)
