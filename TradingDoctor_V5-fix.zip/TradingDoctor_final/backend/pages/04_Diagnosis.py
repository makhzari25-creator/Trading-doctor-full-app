import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import severity_badge

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6

if 'result' not in st.session_state or 'coach' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
coach = st.session_state['coach']
diag = coach["diagnosis"]

st.title("🔍 تشخیص و تحلیل")

st.subheader("تشخیص اصلی")
st.error(f"{diag.get('primary', 'نامشخص')}")

if diag.get('primary_detail'):
    st.info(diag['primary_detail'])

if diag.get('secondary'):
    st.subheader("تشخیص ثانویه")
    st.warning(f"{diag.get('secondary')}")

# [AUDIT FIX — Phase 5B] "سطح اطمینان" قبلاً با st.metric (بدون رنگ‌بندی)
# نمایش داده می‌شد. مهم: این مقدار "severity" نیست — جهت رنگ آن برعکس
# است (اطمینان بالا = خوب/سبز، برخلاف شدت بالا = بد/قرمز). severity_badge
# با extra_label برای نگاشت صحیح این وارونگی استفاده شده: متن نمایشی
# همان "High"/"Medium"/"Low" واقعی می‌ماند، اما رنگ متناظرِ درست اعمال
# می‌شود (engines/diagnosis_engine.py::_confidence_label تأیید شد).
_confidence = diag.get('confidence_level', 'Medium')
_confidence_color_map = {"High": "Low", "Medium": "Medium", "Low": "Critical"}
st.markdown("**سطح اطمینان تشخیص**")
severity_badge(_confidence_color_map.get(_confidence, "Medium"), extra_label=_confidence)

# توضیح هوشمند LLM
st.subheader("🤖 تحلیل هوشمند هوش مصنوعی")
if "enhanced_explanation" in coach:
    st.info(coach["enhanced_explanation"])
else:
    st.write(coach.get("explainable_ai", "توضیح هوشمند در دسترس نیست."))

st.divider()

# شواهد کلیدی
st.subheader("🧾 شواهد کلیدی")
for ev in coach.get("key_evidence", [])[:6]:
    with st.expander(f"{ev.get('type', 'Unknown')} — اولویت {ev.get('priority_score', 0)}"):
        st.write(ev.get('description', ''))
        col1, col2, col3 = st.columns(3)
        with col1: st.metric("شدت", ev.get('severity', 0))
        with col2: st.metric("تعداد", ev.get('frequency', 0))
        with col3: st.metric("تأثیر مالی", f"${ev.get('financial_impact', 0):,.0f}")
