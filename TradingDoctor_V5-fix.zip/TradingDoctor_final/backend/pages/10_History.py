# -*- coding: utf-8 -*-
"""
pages/10_History.py
-----------------------
Phase 6 — تاریخچه‌ی تحلیل‌های همین نشست (session). محدوده‌ی صادقانه در
ui/history.py مستند شده: این تاریخچه با بستن/رفرش کامل مرورگر از بین
می‌رود، یک پایگاه‌داده‌ی دائمی چندکاربره نیست.
"""

import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import severity_badge, empty_state
from ui.history import get_history, search_and_filter, toggle_favorite, delete_entry, load_entry

inject_theme()  # Phase 5A design system

st.title("🕘 تاریخچه تحلیل‌ها")
st.caption("این تاریخچه محدود به نشست فعلی مرورگر شماست — با بستن کامل مرورگر پاک می‌شود.")

history = get_history()

if not history:
    empty_state(
        "هنوز تحلیلی در این نشست انجام نشده",
        "از صفحه‌ی اصلی یک فایل معاملات آپلود کنید تا اینجا ثبت شود.",
        icon="🕘",
    )
    st.stop()

# --- جست‌وجو، فیلتر، مرتب‌سازی — Phase 6: Global search / Advanced filters / Sorting ---
col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
with col1:
    query = st.text_input("🔍 جست‌وجو (نام فایل یا تشخیص)", placeholder="مثلاً sample_trades یا انتقام‌جویی")
with col2:
    favorites_only = st.checkbox("⭐ فقط موردعلاقه‌ها")
with col3:
    score_range = st.slider("بازه‌ی امتیاز انضباط", 0, 100, (0, 100))
with col4:
    sort_by = st.selectbox("مرتب‌سازی", ["newest", "oldest", "score_desc", "score_asc"],
                            format_func=lambda x: {"newest": "جدیدترین", "oldest": "قدیمی‌ترین",
                                                    "score_desc": "امتیاز: زیاد به کم", "score_asc": "امتیاز: کم به زیاد"}[x])

filtered = search_and_filter(query=query, favorites_only=favorites_only,
                              min_score=score_range[0], max_score=score_range[1], sort_by=sort_by)

st.caption(f"{len(filtered)} از {len(history)} تحلیل نمایش داده می‌شود.")

if not filtered:
    empty_state("نتیجه‌ای یافت نشد", "فیلترها را تغییر دهید.", icon="🔍")
    st.stop()

for entry in filtered:
    with st.container():
        c1, c2, c3, c4, c5 = st.columns([3, 2, 2, 1, 1])
        with c1:
            star = "⭐" if entry["favorite"] else "☆"
            st.markdown(f"**{star} {entry['filename']}**")
            st.caption(entry["timestamp"].strftime("%Y-%m-%d %H:%M"))
        with c2:
            st.metric("امتیاز انضباط", f"{entry['discipline_score']}/100", label_visibility="collapsed")
        with c3:
            st.write(entry["primary_diagnosis"])
        with c4:
            if st.button("باز کردن", key=f"open_{entry['id']}", type="primary"):
                load_entry(entry["id"])
                st.switch_page("pages/01_Dashboard.py")
        with c5:
            if st.button("⭐" if not entry["favorite"] else "★", key=f"fav_{entry['id']}"):
                toggle_favorite(entry["id"])
                st.rerun()
        st.divider()
