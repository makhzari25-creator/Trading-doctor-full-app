import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import severity_badge

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
from datetime import datetime

from reporting import generate_html_report, generate_pdf_report, ReportRenderError
from utils.logger import get_logger

log = get_logger(__name__)

if 'result' not in st.session_state or 'coach' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
coach = st.session_state['coach']

st.title("📄 گزارش کامل")

st.subheader(f"گزارش Trading Doctor — {datetime.now().strftime('%Y-%m-%d %H:%M')}")

# خلاصه اصلی
st.markdown("### 📋 خلاصه اجرایی")
st.write(result.summary)

st.divider()

# بخش‌های کلیدی
tab1, tab2, tab3, tab4 = st.tabs(["Performance", "Behavior", "Diagnosis", "Action Plan"])

with tab1:
    st.subheader("عملکرد کلی")
    if result.performance:
        for k, v in result.performance.items():
            st.write(f"{k.replace('_', ' ').title()}: {v}")

with tab2:
    st.subheader("امتیازهای رفتاری")
    for name, ctx in result.context.items():
        col_a, col_b = st.columns([3, 1])
        with col_a:
            st.write(f"{name.replace('_', ' ').title()}: {ctx.score}")
        with col_b:
            severity_badge(ctx.severity)

with tab3:
    st.subheader("تشخیص")
    diag = coach["diagnosis"]
    st.write(f"اصلی: {diag.get('primary')}")
    if diag.get('secondary'):
        st.write(f"ثانویه: {diag.get('secondary')}")

with tab4:
    st.subheader("برنامه اقدام")
    for item in coach.get("action_plan", []):
        st.write(f"- {item.get('issue','')}: {item.get('action','')}")

st.divider()

# دکمه‌های دانلود
st.subheader("دانلود گزارش")

full_report = f"""Trading Doctor V23 - گزارش کامل
تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}

خلاصه:
{result.summary}

امتیاز Discipline: {result.behavior.scores.get('discipline_score', 'N/A')}

تشخیص اصلی: {coach['diagnosis'].get('primary', 'N/A')}

Trader DNA: {coach['trader_dna']}
"""

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.download_button(
        label="⬇️ دانلود گزارش کامل (TXT)",
        data=full_report,
        file_name=f"Trading_Doctor_Report_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain"
    )

with col2:
    # [AUDIT FIX — Phase 2] این دکمه قبلاً یک placeholder غیرفعال بود که
    # فقط همان متن TXT را با نام‌گذاری اشتباه ارائه می‌داد. حالا از
    # ماژول reporting/ (HTML واقعی، خوانا، با نمودار و همه‌ی ۱۵ بخش
    # گزارش) استفاده می‌کند.
    #
    # [AUDIT FIX — self-review] Streamlit کل اسکریپت صفحه را با هر
    # تعامل (کلیک روی هر ویجت، حتی در تب‌های بالا) دوباره اجرا می‌کند.
    # قبلاً این یعنی هر بار generate_html_report()/generate_pdf_report()
    # (که شامل رسم ۸ نمودار matplotlib هستند) از صفر دوباره اجرا می‌شدند
    # — حتی اگر کاربر هرگز روی دانلود کلیک نکند. حالا نتیجه در
    # session_state کش می‌شود و فقط یک‌بار به‌ازای هر تحلیل ساخته می‌شود.
    doctor = st.session_state.get("doctor")
    cache_key = len(doctor.df) if doctor is not None else id(result)

    if st.session_state.get("_html_cache_key") != cache_key:
        try:
            with st.spinner("در حال ساخت گزارش HTML..."):
                st.session_state["_html_cache_bytes"] = generate_html_report(result, coach, doctor).encode("utf-8")
                st.session_state["_html_cache_key"] = cache_key
        except ReportRenderError as e:
            log.error("HTML report generation failed on Report page: %s", e)
            st.session_state["_html_cache_bytes"] = None
            st.session_state["_html_cache_key"] = cache_key
            st.session_state["_html_cache_error"] = str(e)

    if st.session_state.get("_html_cache_bytes"):
        st.download_button(
            label="⬇️ دانلود گزارش HTML",
            data=st.session_state["_html_cache_bytes"],
            file_name=f"Trading_Doctor_Report_{datetime.now().strftime('%Y%m%d')}.html",
            mime="text/html",
        )
    else:
        st.error(f"ساخت گزارش HTML با خطا مواجه شد: {st.session_state.get('_html_cache_error', '')}")

with col3:
    # [AUDIT FIX — Phase 2] قبلاً دکمه‌ی PDF همیشه غیرفعال بود
    # ("در حال توسعه"). حالا از reportlab (بدون وابستگی به باینری
    # سیستمی) یک PDF واقعی و کامل تولید می‌کند. همان کش session_state
    # بالا برای جلوگیری از بازتولید غیرضروری در هر rerun اعمال شده است.
    if st.session_state.get("_pdf_cache_key") != cache_key:
        try:
            with st.spinner("در حال ساخت گزارش PDF..."):
                st.session_state["_pdf_cache_bytes"] = generate_pdf_report(result, coach, doctor)
                st.session_state["_pdf_cache_key"] = cache_key
        except ReportRenderError as e:
            log.error("PDF report generation failed on Report page: %s", e)
            st.session_state["_pdf_cache_bytes"] = None
            st.session_state["_pdf_cache_key"] = cache_key
            st.session_state["_pdf_cache_error"] = str(e)

    if st.session_state.get("_pdf_cache_bytes"):
        st.download_button(
            label="⬇️ دانلود گزارش PDF",
            data=st.session_state["_pdf_cache_bytes"],
            file_name=f"Trading_Doctor_Report_{datetime.now().strftime('%Y%m%d')}.pdf",
            mime="application/pdf",
        )
    else:
        st.error(f"ساخت گزارش PDF با خطا مواجه شد: {st.session_state.get('_pdf_cache_error', '')}")

with col4:
    if st.button("🔄 تحلیل جدید"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

st.success("گزارش آماده دانلود است. این فایل را برای آرشیو یا به اشتراک‌گذاری استفاده کنید.")

st.caption("این گزارش توسط تمام لایه‌های Trading Doctor V23 تولید شده است.")
