# -*- coding: utf-8 -*-
"""
pages/11_Downloads.py
-------------------------
Phase 6 — مرکز دانلود: تمام خروجی‌های تحلیل فعلی در یک‌جا، به‌علاوه‌ی
یک گزینه‌ی «دانلود همه به‌صورت ZIP». از همان کش session_state گزارش
HTML/PDF که در pages/08_Report.py ساخته شده استفاده می‌کند — این صفحه
هیچ منطق تولید گزارش جدیدی اضافه نمی‌کند، فقط دسترسی را متمرکز می‌کند.
"""

import io
import zipfile
from datetime import datetime

import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from reporting import generate_html_report, generate_pdf_report, ReportRenderError
from utils.logger import get_logger

log = get_logger(__name__)
inject_theme()  # Phase 5A design system

if 'result' not in st.session_state or 'coach' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
coach = st.session_state['coach']
doctor = st.session_state.get('doctor')
date_str = datetime.now().strftime('%Y%m%d')

st.title("⬇️ مرکز دانلود")
st.caption("همه‌ی خروجی‌های قابل‌دانلود این تحلیل، در یک‌جا.")

# --- همان کش session_state که pages/08_Report.py می‌سازد؛ اینجا فقط
# در صورت نبودِ کش، می‌سازیم — بدون تکرار منطق تولید گزارش ---
cache_key = len(doctor.df) if doctor is not None else id(result)

if st.session_state.get("_html_cache_key") != cache_key:
    try:
        with st.spinner("در حال آماده‌سازی گزارش HTML..."):
            st.session_state["_html_cache_bytes"] = generate_html_report(result, coach, doctor).encode("utf-8")
            st.session_state["_html_cache_key"] = cache_key
    except ReportRenderError as e:
        log.error("HTML generation failed on Downloads page: %s", e)
        st.session_state["_html_cache_bytes"] = None

if st.session_state.get("_pdf_cache_key") != cache_key:
    try:
        with st.spinner("در حال آماده‌سازی گزارش PDF..."):
            st.session_state["_pdf_cache_bytes"] = generate_pdf_report(result, coach, doctor)
            st.session_state["_pdf_cache_key"] = cache_key
    except ReportRenderError as e:
        log.error("PDF generation failed on Downloads page: %s", e)
        st.session_state["_pdf_cache_bytes"] = None

html_bytes = st.session_state.get("_html_cache_bytes")
pdf_bytes = st.session_state.get("_pdf_cache_bytes")

txt_report = f"""Trading Doctor V23 - گزارش کامل
تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}

خلاصه:
{result.summary}

امتیاز Discipline: {result.behavior.scores.get('discipline_score', 'N/A')}
تشخیص اصلی: {coach['diagnosis'].get('primary', 'N/A')}
Trader DNA: {coach['trader_dna']}
"""
action_text = "\n".join(f"{i.get('issue')}: {i.get('action')}" for i in coach.get("action_plan", []))

st.subheader("گزارش‌ها")
c1, c2, c3 = st.columns(3)
with c1:
    st.download_button("📄 گزارش متنی (TXT)", txt_report, f"Trading_Doctor_Report_{date_str}.txt", "text/plain", use_container_width=True)
with c2:
    if html_bytes:
        st.download_button("🌐 گزارش HTML", html_bytes, f"Trading_Doctor_Report_{date_str}.html", "text/html", use_container_width=True)
    else:
        st.button("🌐 گزارش HTML (ناموفق)", disabled=True, use_container_width=True)
with c3:
    if pdf_bytes:
        st.download_button("📕 گزارش PDF", pdf_bytes, f"Trading_Doctor_Report_{date_str}.pdf", "application/pdf", use_container_width=True)
    else:
        st.button("📕 گزارش PDF (ناموفق)", disabled=True, use_container_width=True)

st.subheader("سایر خروجی‌ها")
c4, c5 = st.columns(2)
with c4:
    st.download_button("💡 برنامه اقدام (TXT)", action_text, f"action_plan_{date_str}.txt", "text/plain", use_container_width=True)
with c5:
    if doctor is not None:
        csv_bytes = doctor.df.to_csv(index=False).encode("utf-8")
        st.download_button("📊 داده‌ی خام معاملات (CSV)", csv_bytes, f"trades_normalized_{date_str}.csv", "text/csv", use_container_width=True)

st.divider()

# --- دانلود همه به‌صورت ZIP ---
st.subheader("📦 دانلود همه (ZIP)")
zip_buf = io.BytesIO()
with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
    zf.writestr(f"report_{date_str}.txt", txt_report)
    if html_bytes:
        zf.writestr(f"report_{date_str}.html", html_bytes)
    if pdf_bytes:
        zf.writestr(f"report_{date_str}.pdf", pdf_bytes)
    zf.writestr(f"action_plan_{date_str}.txt", action_text)
    if doctor is not None:
        zf.writestr(f"trades_normalized_{date_str}.csv", doctor.df.to_csv(index=False))

st.download_button(
    "📦 دانلود همه‌ی فایل‌ها در یک ZIP",
    zip_buf.getvalue(), f"Trading_Doctor_Export_{date_str}.zip", "application/zip",
    type="primary", use_container_width=True,
)
