import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import severity_badge

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import plotly.graph_objects as go

if 'result' not in st.session_state or 'coach' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
context = result.context

st.title("📉 تحلیل رفتاری")

st.subheader("امتیازهای اصلی رفتار")

# نمایش Gauge برای هر امتیاز (زیباتر از Progress)
cols = st.columns(3)

scores = {
    "Discipline": result.behavior.scores.get("discipline_score", 0),
    "Revenge": result.behavior.scores.get("revenge_score", 0),
    "Patience": result.behavior.scores.get("patience_score", 0),
    "Risk Taking": result.behavior.scores.get("risk_taking_score", 0),
    "Overtrading": result.behavior.scores.get("overtrading_score", 0),
}

for i, (name, score) in enumerate(scores.items()):
    with cols[i % 3]:
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=score,
            title={'text': name},
            gauge={
                'axis': {'range': [0, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 40], 'color': "red"},
                    {'range': [40, 70], 'color': "yellow"},
                    {'range': [70, 100], 'color': "green"}
                ],
                'threshold': {'line': {'color': "red", 'width': 4}, 'value': 50}
            }
        ))
        fig.update_layout(height=250, margin=dict(l=10, r=10, t=40, b=10))
        st.plotly_chart(fig, use_container_width=True)

st.divider()

# جزئیات کامل هر رفتار
st.subheader("جزئیات هر رفتار")
for name, ctx in context.items():
    with st.expander(f"🔍 {name.replace('_', ' ').title()} — {ctx.severity}"):
        severity_badge(ctx.severity)
        st.write(ctx.insight)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("امتیاز", f"{ctx.score}")
        with col2:
            st.metric("تعداد رخداد", ctx.event_count)
        with col3:
            st.metric("تأثیر مالی", f"${ctx.dollars_lost:,.0f}")
        
        if ctx.pct_of_total_profit > 0:
            # [AUDIT FIX - real bug] pct_of_total_profit می‌تواند از ۱۰۰
            # بیشتر شود (وقتی ضرر یک رفتار خاص از کل سود ناخالص عبور
            # می‌کند) — st.progress() مقداری خارج از [0,1] بگیرد با
            # StreamlitAPIException کرش می‌کند. اینجا کلمپ می‌شود؛ خودِ
            # عدد pct_of_total_profit در caption بدون تغییر و کامل نمایش
            # داده می‌شود، فقط نوار پیشرفت بصری محدود به ۱۰۰٪ است.
            st.progress(min(ctx.pct_of_total_profit / 100, 1.0))
            st.caption(f"معادل {ctx.pct_of_total_profit}% از کل سود")

# الگوهای شناسایی‌شده
if result.behavior.detected_patterns:
    st.subheader("⚠️ الگوهای شناسایی‌شده")
    for pattern in result.behavior.detected_patterns:
        st.error(f"• {pattern}")

st.divider()
st.caption("این صفحه مستقیماً از ContextEngine موتور V23 تغذیه می‌شود.")
