import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# Phase 5B — design/03_COMPONENTS.md §Charts Styling: پالت مشترک با
# reporting/charts.py (همان مقادیر _COLOR_POS/_COLOR_NEG/_COLOR_NEUTRAL)
# به‌جای پالت پیش‌فرض Plotly — یکی از تنها یافته‌های باز design/00_UI_AUDIT.md
# ("نمودارهای پیش‌فرض Plotly، هم‌راستا با پالت اپ نیستند") که در این فاز
# رفع می‌شود. رنگ‌ها ثابت (نه CSS variable) هستند چون Plotly از CSS
# custom properties پشتیبانی نمی‌کند — محدودیت مستندشده در تِک‌دبت فاز.
_TD_POSITIVE = "#00A67D"
_TD_NEGATIVE = "#E5484D"
_TD_ACCENT = "#3B6FD4"
_TD_GRID = "rgba(148,163,184,0.25)"
_TD_TEXT_MUTED = "#5B6472"

_CHART_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color=_TD_TEXT_MUTED, family="Inter, Vazirmatn, sans-serif", size=12),
    xaxis=dict(gridcolor=_TD_GRID, zerolinecolor=_TD_GRID),
    yaxis=dict(gridcolor=_TD_GRID, zerolinecolor=_TD_GRID),
    margin=dict(t=48, b=32, l=48, r=24),
)

if 'result' not in st.session_state or 'df' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
df = st.session_state['df']

st.title("📈 نمودارها و تحلیل بصری")

# Equity Curve
st.subheader("📈 Equity Curve (رشد سرمایه)")
if not df.empty and "Profit" in df.columns:
    df['Equity'] = df['Profit'].cumsum()
    fig_equity = px.line(
        df, x=df.index, y='Equity',
        title="Equity Curve",
        labels={"index": "شماره معامله", "Equity": "سود تجمعی"}
    )
    fig_equity.update_traces(line_color=_TD_ACCENT, line_width=2)
    fig_equity.update_layout(height=400, **_CHART_LAYOUT)
    st.plotly_chart(fig_equity, use_container_width=True)

# Drawdown
st.subheader("📉 Maximum Drawdown")
if not df.empty:
    equity = df['Profit'].cumsum()
    cummax = equity.cummax()
    drawdown = equity - cummax
    fig_dd = go.Figure()
    fig_dd.add_trace(go.Scatter(
        x=df.index, y=drawdown, fill='tozeroy', name='Drawdown',
        line=dict(color=_TD_NEGATIVE), fillcolor="rgba(229,72,77,0.18)",
    ))
    fig_dd.update_layout(title="Drawdown", height=350, **_CHART_LAYOUT)
    st.plotly_chart(fig_dd, use_container_width=True)

col1, col2 = st.columns(2)

with col1:
    # Win/Loss Distribution
    st.subheader("📊 توزیع برد و باخت")
    if "Profit" in df.columns:
        fig_pie = px.pie(
            names=['برد', 'باخت'],
            values=[(df['Profit'] > 0).sum(), (df['Profit'] < 0).sum()],
            color_discrete_sequence=[_TD_POSITIVE, _TD_NEGATIVE]
        )
        fig_pie.update_layout(**_CHART_LAYOUT)
        st.plotly_chart(fig_pie, use_container_width=True)

with col2:
    # Profit by Hour
    st.subheader("🕒 سود بر اساس ساعت روز")
    if "hour" in df.columns:
        hourly = df.groupby("hour")["Profit"].agg(['sum', 'count']).reset_index()
        fig_hour = px.bar(
            hourly, x="hour", y="sum",
            title="سود/زیان بر اساس ساعت",
            labels={"sum": "سود کل", "hour": "ساعت"},
            color="sum", color_continuous_scale=[_TD_NEGATIVE, _TD_GRID, _TD_POSITIVE],
            color_continuous_midpoint=0,
        )
        fig_hour.update_layout(**_CHART_LAYOUT, coloraxis_showscale=False)
        st.plotly_chart(fig_hour, use_container_width=True)

# Profit by Weekday
st.subheader("📅 سود بر اساس روز هفته")
if "Open Time" in df.columns:
    df['weekday'] = pd.to_datetime(df['Open Time']).dt.day_name()
    weekday = df.groupby("weekday")["Profit"].sum().reset_index()
    fig_week = px.bar(
        weekday, x="weekday", y="Profit", title="سود بر اساس روز هفته",
        color="Profit", color_continuous_scale=[_TD_NEGATIVE, _TD_GRID, _TD_POSITIVE],
        color_continuous_midpoint=0,
    )
    fig_week.update_layout(**_CHART_LAYOUT, coloraxis_showscale=False)
    st.plotly_chart(fig_week, use_container_width=True)

# Size vs Profit
st.subheader("📦 حجم معاملات در مقابل سود")
if all(col in df.columns for col in ["Size", "Profit"]):
    fig_size = px.scatter(
        df, x="Size", y="Profit",
        title="ارتباط حجم و سود",
        trendline="ols",
    )
    fig_size.update_traces(marker=dict(color=_TD_ACCENT, size=7, opacity=0.7))
    fig_size.update_layout(**_CHART_LAYOUT)
    st.plotly_chart(fig_size, use_container_width=True)

st.divider()
st.caption("این نمودارها مستقیماً از داده‌های خام و نتیجه موتور V23 ساخته شده‌اند.")
