import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import tag

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import plotly.graph_objects as go

# Phase 5B — design/03_COMPONENTS.md §Charts Styling: همان پالت مشترک
# استفاده‌شده در pages/02_Charts.py، به‌جای رنگ‌های ad hoc قبلی
# ("royalblue", "#ff4d4d", "#ffd633", "#00cc96") که با هیچ توکن طراحی
# هم‌خوانی نداشتند.
_TD_ACCENT = "#3B6FD4"
_TD_NEGATIVE = "#E5484D"
_TD_WARNING = "#B98900"
_TD_POSITIVE = "#00A67D"

if 'coach' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

coach = st.session_state['coach']
dna = coach["trader_dna"]

st.title("🧬 Trader DNA — پروفایل شخصیتی معاملاتی")

st.subheader("آرچیتایپ اصلی")
st.success(f"{dna.get('archetype', 'معامله‌گر ترکیبی')}")

st.divider()

# نمایش گرافیکی ویژگی‌ها
st.subheader("ویژگی‌های رفتاری")

traits = {k: v for k, v in dna.items() if k != "archetype"}

cols = st.columns(3)

for i, (trait, level) in enumerate(traits.items()):
    with cols[i % 3]:
        # تبدیل سطح به عدد تقریبی برای نمایش
        value_map = {"Low": 25, "Medium": 55, "High": 85, "Strong": 80, "Weak": 30}
        value = value_map.get(level, 50)

        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=value,
            title={"text": trait.replace("_", " ").title()},
            gauge={
                'axis': {'range': [0, 100]},
                'bar': {'color': _TD_ACCENT},
                'steps': [
                    {'range': [0, 40], 'color': _TD_NEGATIVE},
                    {'range': [40, 70], 'color': _TD_WARNING},
                    {'range': [70, 100], 'color': _TD_POSITIVE}
                ]
            }
        ))
        fig.update_layout(
            height=220, margin=dict(t=30, b=10),
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#5B6472", family="Inter, Vazirmatn, sans-serif"),
        )
        st.plotly_chart(fig, use_container_width=True)

        tag(level)

st.divider()

# توضیحات متنی
st.subheader("تحلیل پروفایل")
st.write("""
این پروفایل بر اساس الگوهای واقعی معاملات شما ساخته شده است.
ترکیب امتیازهای Revenge، Risk، Patience و Consistency تعیین‌کننده آرچیتایپ شماست.
""")

# پیشنهاد شخصی‌سازی
st.info("""
پیشنهاد: 
- اگر "Revenge" یا "Emotion" بالا است → قوانین استراحت اجباری بعد از ضرر بگذارید.
- اگر "Risk" بالا است → حجم ثابت تعریف کنید.
""")

st.caption("این بخش توسط TraderDNAEngine موتور V23 تولید شده است.")
