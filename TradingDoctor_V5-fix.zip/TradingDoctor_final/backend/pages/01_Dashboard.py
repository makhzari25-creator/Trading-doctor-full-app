import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import kpi_card, severity_badge, tag

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import pandas as pd
from datetime import datetime

# دسترسی به داده‌های تحلیل‌شده
if 'result' not in st.session_state or 'coach' not in st.session_state:
    st.warning("ابتدا از صفحه اصلی فایل CSV آپلود کنید و تحلیل را اجرا کنید.")
    st.stop()

result = st.session_state['result']
coach = st.session_state['coach']
df = st.session_state.get('df')

st.title("📊 داشبورد کلی")

# کارت‌های بزرگ بالا (۴ کارت) — Phase 5B: kpi_card با رنگ‌بندی معنایی
# به‌جای st.metric خام (design/03_COMPONENTS.md §KPI Widgets)
col1, col2, col3, col4 = st.columns(4)

with col1:
    discipline_score = result.behavior.scores.get("discipline_score", 0)
    delta_positive = discipline_score >= 65
    kpi_card(
        "امتیاز کلی انضباط", f"{discipline_score}/100",
        delta="سالم" if delta_positive else ("متوسط" if discipline_score >= 35 else "نیاز به توجه"),
        delta_positive=delta_positive if discipline_score >= 65 else (None if discipline_score >= 35 else False),
    )
    # [AUDIT FIX] کلمپ دفاعی؛ فرمول discipline_score همیشه در [0,100] است
    # اما اگر منطق در آینده تغییر کند، این خط از کرش UI جلوگیری می‌کند.
    st.progress(max(0.0, min(discipline_score / 100, 1.0)))

with col2:
    revenge_score = result.behavior.scores.get("revenge_score", 0)
    kpi_card(
        "ریسک Revenge Trading", f"{revenge_score}%",
        delta="بالا" if revenge_score > 50 else "متوسط", delta_positive=False if revenge_score > 50 else None,
    )

with col3:
    dna = coach["trader_dna"]
    archetype = dna.get("archetype", "نامشخص")
    kpi_card("نوع معامله‌گر", archetype)

with col4:
    diag = coach["diagnosis"]
    _primary_text = diag.get("primary", "نامشخص")
    # [AUDIT FIX — Phase 5B] design/03_COMPONENTS.md §Tooltips: قبلاً متن
    # بریده‌شده (truncated) هیچ راهی برای دیدن نسخه‌ی کامل نداشت — همان
    # یافته‌ی #5 در design/00_UI_AUDIT.md. حالا نسخه‌ی کامل از طریق
    # tooltip بومی (help=) در دسترس است، بدون تغییر منطق کوتاه‌سازی.
    _display_text = _primary_text if len(_primary_text) <= 25 else _primary_text[:25] + "..."
    st.metric(label="تشخیص اصلی", value=_display_text, help=_primary_text)

st.divider()

# بخش دوم - خلاصه عملکرد
st.subheader("📈 عملکرد کلی معاملات")
perf = result.performance

c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    st.metric("تعداد معاملات", perf.get("total_trades", 0))
with c2:
    st.metric("سود خالص", f"${perf.get('net_profit', 0):,.0f}")
with c3:
    st.metric("Win Rate", f"{perf.get('win_rate_pct', 0)}%")
with c4:
    st.metric("Profit Factor", perf.get("profit_factor", 0))
with c5:
    st.metric("بیشترین Drawdown", f"${perf.get('max_drawdown', 0):,.0f}")

st.divider()

# Trader DNA سریع — Phase 5B: تگ‌های سبک به‌جای متن خام برای مقادیر
# کیفی (Low/Medium/High) — design/03_COMPONENTS.md §Badges & Tags
st.subheader("🧬 پروفایل رفتاری (Trader DNA)")
dna_cols = st.columns(len(dna))
for i, (key, value) in enumerate(dna.items()):
    if key == "archetype":
        continue
    with dna_cols[i]:
        st.markdown(f"**{key.replace('_', ' ').title()}**")
        tag(value)

# تشخیص و توضیح کوتاه
st.subheader("🔍 تشخیص اصلی")
st.error(f"مشکل اصلی: {diag.get('primary', '')}")
if diag.get('secondary'):
    st.warning(f"مشکل ثانویه: {diag.get('secondary', '')}")

st.info(diag.get('primary_detail', ''))

# خلاصه Revenge (مهم‌ترین)
revenge_ctx = result.context.get("revenge_score")
if revenge_ctx and revenge_ctx.event_count > 0:
    st.subheader("⚠️ هشدار Revenge Trading")
    severity_badge(revenge_ctx.severity)
    st.write(revenge_ctx.insight)

# دکمه رفتن به صفحات بعدی
st.divider()
st.markdown("صفحات بعدی:")
cols = st.columns(4)
with cols[0]:
    st.page_link("pages/02_Charts.py", label="📈 نمودارها", icon="📊")
with cols[1]:
    st.page_link("pages/03_Behavioral_Analysis.py", label="Behavioral Analysis", icon="📉")
with cols[2]:
    st.page_link("pages/04_Diagnosis.py", label="Diagnosis", icon="🔍")
with cols[3]:
    st.page_link("pages/05_Coaching.py", label="Coaching Plan", icon="💡")
