import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import empty_state
from engines.coaching_engine import CoachingEngine
from utils.logger import get_logger

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
log = get_logger(__name__)

if 'coach' not in st.session_state or 'result' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

coach = st.session_state['coach']
result = st.session_state['result']

st.title("💡 برنامه Coaching و اقدام")

st.subheader("برنامه عملی (Action Plan)")

action_plan = coach.get("action_plan", [])
if not action_plan:
    # [AUDIT FIX — Phase 5B] design/00_UI_AUDIT.md finding #7: قبلاً اگر
    # action_plan خالی بود، هیچ پیامی نشان داده نمی‌شد (فقط یک بخش خالی
    # و گیج‌کننده). حالا از empty_state مشترک استفاده می‌شود.
    empty_state(
        "اقدام خاصی ثبت نشده است",
        "بر اساس تحلیل فعلی، مورد قابل‌توجهی برای برنامه‌ی اقدام شناسایی نشد.",
        icon="✅",
    )
else:
    for i, item in enumerate(action_plan):
        with st.expander(f"#{i+1} {item.get('issue','').title()} — اولویت {item.get('priority', 0)}"):
            st.write(item.get('action', ''))
            st.checkbox("انجام شد", key=f"check_{i}")

st.divider()

# تحلیل هوشمند LLM (جدید)
st.subheader("🤖 تحلیل عمیق هوش مصنوعی")
if "enhanced_explanation" in coach:
    st.info(coach["enhanced_explanation"])
else:
    st.write(coach.get("explainable_ai", "تحلیل هوشمند در دسترس نیست."))

st.divider()

st.subheader("⚠️ یادآوری مهم")
st.warning(coach.get("reality_check", "این تحلیل بر اساس داده‌های تاریخی است."))

# دانلود
action_text = "\n".join([f"{item.get('issue')}: {item.get('action')}" for item in action_plan])
st.download_button("⬇️ دانلود برنامه اقدام", action_text, "action_plan.txt")

st.divider()

# [Phase 6 — AI Coach workspace] پرسش‌وپاسخ آزاد و محدود درباره‌ی همین
# تحلیل. محدودیت‌های صریح (نه فقط تزئینی):
#  - سقف تعداد سوال در هر تحلیل (کنترل هزینه/سواستفاده)
#  - غیرفعال و با پیام روشن اگر LLM پیکربندی نشده باشد
#  - هر پاسخ صراحتاً به prompt محدود به «نتایج از‌قبل‌محاسبه‌شده» است
#    (llm/prompts.py::FOLLOWUP_SYSTEM_PROMPT) — هرگز عدد جدید اختراع نمی‌کند
st.subheader("💬 پرسش از AI Coach")

_MAX_FOLLOWUPS = 8
if "coach_chat_history" not in st.session_state:
    st.session_state["coach_chat_history"] = []
if "coach_followup_count" not in st.session_state:
    st.session_state["coach_followup_count"] = 0

for msg in st.session_state["coach_chat_history"]:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

remaining = _MAX_FOLLOWUPS - st.session_state["coach_followup_count"]
if remaining <= 0:
    st.info(f"به سقف {_MAX_FOLLOWUPS} سوال برای این تحلیل رسیدید. برای پرسش بیشتر، تحلیل جدیدی اجرا کنید.")
else:
    question = st.chat_input(f"سوالی درباره‌ی این تحلیل بپرسید... ({remaining} سوال باقی‌مانده)")
    if question:
        st.session_state["coach_followup_count"] += 1
        st.session_state["coach_chat_history"].append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.write(question)
        with st.chat_message("assistant"):
            with st.spinner("در حال فکر کردن..."):
                doctor = st.session_state.get("doctor")
                llm_provider = st.session_state.get("llm_provider", "gemini")
                try:
                    _engine = CoachingEngine(doctor, llm_provider=llm_provider)
                    answer = _engine.answer_followup(
                        question, result, coach, st.session_state["coach_chat_history"][:-1]
                    )
                except Exception as e:
                    log.error("Follow-up Q&A failed: %s", e, exc_info=True)
                    answer = "متأسفانه پاسخ‌دهی با خطا مواجه شد. لطفاً دوباره تلاش کنید."
                st.write(answer)
        st.session_state["coach_chat_history"].append({"role": "assistant", "content": answer})
