import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Phase 5B — همان پالت مشترک pages/02_Charts.py (design/03_COMPONENTS.md §Charts Styling)
_TD_ACCENT = "#3B6FD4"
_CHART_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#5B6472", family="Inter, Vazirmatn, sans-serif", size=12),
    xaxis=dict(gridcolor="rgba(148,163,184,0.25)"), yaxis=dict(gridcolor="rgba(148,163,184,0.25)"),
    margin=dict(t=48, b=32, l=48, r=24),
)

if 'df' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

# ایمپورت درست از ساختار ماژولار جدید (نه فایل تک‌تکه‌ی قدیمی).
# نکته: قبلاً اینجا از یک فایل قدیمی (TradingDoctor_V22_Fixed...) که دیگر
# وجود ندارد import می‌شد و علاوه‌بر آن Path(file) به‌جای Path(__file__)
# نوشته شده بود که باعث NameError می‌شد.
from engines.score_engine import TrendEngine

st.title("📈 روند تغییرات (Trends)")

# از df نرمال‌شده (ستون Open Time/Profit/Size استاندارد) استفاده می‌کنیم،
# نه فایل خام آپلودی. TrendEngine خودش دوباره normalize می‌کند (بی‌ضرر و
# idempotent است)، پس دادن doctor.df یا raw df هر دو کار می‌کند — ولی برای
# سازگاری با بقیه‌ی صفحات از همان df استاندارد استفاده می‌کنیم.
df = st.session_state['df']

# Initialize TrendEngine
trend = TrendEngine(df)

# تنظیمات
col1, col2 = st.columns(2)
with col1:
    granularity = st.radio("دوره زمانی", ["هفتگی", "ماهانه"], horizontal=True)
with col2:
    mode = st.radio("نوع محاسبه", ["Independent (دوره مستقل)", "Cumulative (تجمعی)"], horizontal=True)

mode_value = "independent" if "Independent" in mode else "cumulative"
gran_value = "week" if granularity == "هفتگی" else "month"

# محاسبه روند
with st.spinner("در حال محاسبه روند..."):
    trends_data = trend.compute(granularity=gran_value, mode=mode_value)

if not trends_data:
    st.warning("داده زمانی کافی برای نمایش روند وجود ندارد.")
    st.stop()

# اگر داده فقط یک دوره (مثلاً یک هفته‌ی تقویمی) را پوشش می‌دهد، چارت خطی
# عملاً یک نقطه خواهد داشت و چیزی قابل‌مشاهده نیست. این هشدار شفاف‌تر از
# یک نمودار خالی و گیج‌کننده است.
if len(trends_data) < 2:
    st.info(
        f"داده‌ی شما فقط یک دوره‌ی «{granularity}» را پوشش می‌دهد "
        f"({trends_data[0]['period_start']} تا {trends_data[0]['period_end']})، "
        "بنابراین نمودار روند خطی نقطه‌ی کافی برای رسم ندارد. "
        "دوره‌ی زمانی دیگری (مثلاً ماهانه) را امتحان کنید یا داده‌ی بیشتری آپلود کنید."
    )

# تبدیل به DataFrame برای نمایش و چارت
df_trend = pd.DataFrame(trends_data)

st.subheader(f"روند {granularity} — حالت {mode.split(' ')[0]}")

# چارت اصلی Discipline Score
fig_disc = px.line(
    df_trend, x="period_start", y="discipline_score",
    title="روند امتیاز Discipline",
    markers=True,
    labels={"period_start": "دوره", "discipline_score": "امتیاز انضباط"}
)
fig_disc.update_traces(line_color=_TD_ACCENT)
fig_disc.update_layout(height=400, **_CHART_LAYOUT)
st.plotly_chart(fig_disc, use_container_width=True)

# چارت‌های متعدد
tabs = st.tabs(["امتیازهای رفتاری", "عملکرد", "جدول کامل"])

with tabs[0]:
    cols = st.columns(2)
    with cols[0]:
        fig_rev = px.line(df_trend, x="period_start", y="revenge_score", title="روند Revenge Trading", markers=True)
        fig_rev.update_traces(line_color=_TD_ACCENT)
        fig_rev.update_layout(**_CHART_LAYOUT)
        st.plotly_chart(fig_rev, use_container_width=True)
    with cols[1]:
        fig_pat = px.line(df_trend, x="period_start", y="patience_score", title="روند Patience", markers=True)
        fig_pat.update_traces(line_color=_TD_ACCENT)
        fig_pat.update_layout(**_CHART_LAYOUT)
        st.plotly_chart(fig_pat, use_container_width=True)

with tabs[1]:
    col1, col2 = st.columns(2)
    with col1:
        fig_wr = px.line(df_trend, x="period_start", y="win_rate_pct", title="روند Win Rate", markers=True)
        fig_wr.update_traces(line_color=_TD_ACCENT)
        fig_wr.update_layout(**_CHART_LAYOUT)
        st.plotly_chart(fig_wr, use_container_width=True)
    with col2:
        fig_pf = px.line(df_trend, x="period_start", y="profit_factor", title="روند Profit Factor", markers=True)
        fig_pf.update_traces(line_color=_TD_ACCENT)
        fig_pf.update_layout(**_CHART_LAYOUT)
        st.plotly_chart(fig_pf, use_container_width=True)

with tabs[2]:
    st.dataframe(df_trend, use_container_width=True)

st.caption("این روندها توسط TrendEngine (engines/score_engine.py) محاسبه شده‌اند.")

# دانلود
csv = df_trend.to_csv(index=False).encode('utf-8')
st.download_button("دانلود داده روند (CSV)", csv, "trends_data.csv", "text/csv")
