import streamlit as st
from ui.theme import inject_theme
from ui.shortcuts import inject_keyboard_shortcuts
from ui.components import empty_state

inject_theme()  # Phase 5A design system — design/01_DESIGN_RATIONALE.md
inject_keyboard_shortcuts()  # Phase 6
import pandas as pd

if 'result' not in st.session_state:
    st.warning("ابتدا تحلیل را از صفحه اصلی انجام دهید.")
    st.stop()

result = st.session_state['result']
edge = result.edge_map

st.title("🗺️ Edge Map — نقشه نقاط قوت و ضعف")

if not edge:
    empty_state(
        "داده‌ی کافی برای Edge Map موجود نیست",
        "حداقل ۵ معامله در هر دسته (ساعت/روز/استراتژی) برای این تحلیل نیاز است.",
        icon="🗺️",
    )
    st.stop()

# بهترین و بدترین ساعت
col1, col2 = st.columns(2)

with col1:
    best_hour = edge.get("best_hour")
    if best_hour:
        st.success(f"بهترین ساعت: {best_hour.get('hour')}:00")
        st.metric("میانگین سود", f"${best_hour.get('avg_pnl', 0)}")

with col2:
    worst_hour = edge.get("worst_hour")
    if worst_hour:
        st.error(f"بدترین ساعت: {worst_hour.get('hour')}:00")
        st.metric("میانگین سود", f"${worst_hour.get('avg_pnl', 0)}")

st.divider()

# روزهای هفته
col3, col4 = st.columns(2)

with col3:
    best_day = edge.get("best_weekday")
    if best_day:
        st.success(f"بهترین روز: {best_day.get('day')}")
        st.metric("سود کل", f"${best_day.get('total_pnl', 0)}")

with col4:
    worst_day = edge.get("worst_weekday")
    if worst_day:
        st.error(f"بدترین روز: {worst_day.get('day')}")
        st.metric("سود کل", f"${worst_day.get('total_pnl', 0)}")

st.divider()

# استراتژی‌ها
if "best_strategy" in edge:
    st.subheader("بهترین و بدترین استراتژی")
    col5, col6 = st.columns(2)
    with col5:
        best_strat = edge["best_strategy"]
        st.success(f"بهترین: {best_strat.get('name')}")
        st.metric("میانگین سود", f"${best_strat.get('avg_pnl', 0)}")
        st.metric("Win Rate", f"{best_strat.get('win_rate_pct', 0)}%")
    with col6:
        worst_strat = edge["worst_strategy"]
        st.error(f"بدترین: {worst_strat.get('name')}")
        st.metric("میانگین سود", f"${worst_strat.get('avg_pnl', 0)}")

st.divider()

# مقایسه جهت (Long/Short)
if "side_comparison" in edge:
    st.subheader("مقایسه Long vs Short")
    side_df = pd.DataFrame.from_dict(edge["side_comparison"], orient='index')
    st.dataframe(side_df, use_container_width=True)

# جدول خلاصه — [AUDIT FIX — Phase 5B] design/00_UI_AUDIT.md /
# design/03_COMPONENTS.md: قبلاً st.json خام (یک TODO صریح در کامنت
# قبلی: "بعداً می‌توان زیباتر کرد") — دقیقاً نمونه‌ی ظاهر پیش‌فرض
# Streamlit که این فاز باید حذف کند. حالا جدول کلید-مقدار مرتب.
st.subheader("خلاصه Edge Map")
_summary_rows = []
for key, val in edge.items():
    if isinstance(val, dict):
        _summary_rows.append({"مورد": key, "مقدار": ", ".join(f"{k}={v}" for k, v in val.items())})
    else:
        _summary_rows.append({"مورد": key, "مقدار": str(val)})
st.dataframe(pd.DataFrame(_summary_rows), use_container_width=True, hide_index=True)

st.caption("این نقشه بر اساس داده‌های واقعی معاملات شما توسط ContextEngine ساخته شده است.")
