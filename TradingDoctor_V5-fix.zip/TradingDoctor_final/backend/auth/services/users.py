# -*- coding: utf-8 -*-
"""
auth/services/users.py
----------------------
Phase 8 — User lifecycle service.

Encapsulates all DB operations on the User table:
  - create (registration)
  - get by id / email
  - update
  - soft-delete
  - email verification
  - password change
  - brute-force protection (increment failures, lock, reset on success)

This is the ONLY module that should write to the users table.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import select, update, func, case
from sqlalchemy.ext.asyncio import AsyncSession

from auth import config as auth_config
from auth.models import User, UserStatus, EmailVerification, EmailVerificationType
from auth.services.passwords import hash_password, verify_and_maybe_rehash
from utils.logger import get_logger

log = get_logger("auth.users")


def _utcnow() -> datetime:
    """Return current UTC datetime (timezone-aware)."""
    return datetime.now(timezone.utc)


def _ensure_aware(dt: datetime) -> datetime:
    """Force a datetime to be timezone-aware (assume UTC if naive).

    SQLite returns naive datetimes; Postgres returns aware ones (with
    `DateTime(timezone=True)`). This helper unifies behavior across DBs.
    """
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

async def create_user(
    db: AsyncSession,
    email: str,
    password: str,
    full_name: Optional[str] = None,
    locale: Optional[str] = None,
    marketing_consent: bool = False,
) -> User:
    """Create a new user with status=pending (awaiting email verification).

    Email is normalized to lowercase BEFORE insertion.

    Raises ValueError if email is already taken by an active user.
    """
    email = _normalize_email(email)

    # Check for existing active user with this email.
    existing = await get_user_by_email(db, email)
    if existing is not None and existing.deleted_at is None:
        raise ValueError("EMAIL_ALREADY_REGISTERED")

    hashed = hash_password(password)

    user = User(
        email=email,
        password_hash=hashed,
        full_name=full_name,
        status=UserStatus.pending,
        locale=locale,
        marketing_consent=marketing_consent,
    )
    db.add(user)
    await db.flush()  # populate user.id
    log.info("Created user id=%s email=%s", user.id, email)
    return user


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

async def get_user_by_id(db: AsyncSession, user_id: uuid.UUID) -> Optional[User]:
    """Return the user with the given ID, or None.

    Returns soft-deleted users too — caller must check deleted_at.
    """
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
    """Return the active user with the given email, or None.

    Soft-deleted users are excluded (allows re-registration).
    """
    email = _normalize_email(email)
    stmt = select(User).where(
        User.email == email,
        User.deleted_at.is_(None),
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def count_users(db: AsyncSession) -> int:
    """Total count of non-deleted users (for admin dashboard)."""
    stmt = select(func.count(User.id)).where(User.deleted_at.is_(None))
    result = await db.execute(stmt)
    return result.scalar_one()


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

async def verify_email(db: AsyncSession, user_id: uuid.UUID) -> User:
    """Mark a user's email as verified and activate the account."""
    user = await get_user_by_id(db, user_id)
    if user is None:
        raise ValueError("USER_NOT_FOUND")

    user.email_verified_at = datetime.now(timezone.utc)
    user.status = UserStatus.active
    log.info("Verified email for user_id=%s", user_id)
    return user


async def change_password(
    db: AsyncSession,
    user_id: uuid.UUID,
    new_password: str,
) -> User:
    """Set a new password hash for a user.

    Does NOT validate the old password — caller must do that.
    Revokes all existing refresh tokens for this user (security best practice
    on password change).
    """
    from auth.services.tokens import revoke_all_user_tokens
    user = await get_user_by_id(db, user_id)
    if user is None:
        raise ValueError("USER_NOT_FOUND")

    user.password_hash = hash_password(new_password)
    await revoke_all_user_tokens(db, user_id, reason="password_changed")
    log.info("Password changed for user_id=%s", user_id)
    return user


async def update_login_success(
    db: AsyncSession,
    user_id: uuid.UUID,
    ip_address: Optional[str] = None,
) -> None:
    """Reset failed-login counter + record last login info on successful login."""
    now = datetime.now(timezone.utc)
    stmt = (
        update(User)
        .where(User.id == user_id)
        .values(
            failed_login_attempts=0,
            locked_until=None,
            last_login_at=now,
            last_login_ip=ip_address,
        )
    )
    await db.execute(stmt)


async def update_login_failure(
    db: AsyncSession,
    user_id: uuid.UUID,
) -> tuple[int, Optional[datetime]]:
    """Increment failed-login counter; lock if threshold exceeded.

    Returns (new_failure_count, locked_until_or_None).

    Concurrency: this used to be a read (SELECT) → modify in Python → write,
    which race-conditions under concurrent requests (e.g. parallel brute-force
    attempts) — two overlapping requests can both read the same starting
    count and one increment gets silently lost, letting the account exceed
    MAX_FAILED_LOGIN_ATTEMPTS without locking. Using a single
    `UPDATE ... SET failed_login_attempts = failed_login_attempts + 1`
    performs the read-increment-write as one atomic statement at the
    database level, so concurrent callers always see a consistent count.
    """
    lock_until = datetime.now(timezone.utc) + timedelta(
        minutes=auth_config.ACCOUNT_LOCKOUT_MINUTES
    )
    stmt = (
        update(User)
        .where(User.id == user_id)
        .values(
            failed_login_attempts=User.failed_login_attempts + 1,
            locked_until=case(
                (
                    User.failed_login_attempts + 1 >= auth_config.MAX_FAILED_LOGIN_ATTEMPTS,
                    lock_until,
                ),
                else_=User.locked_until,
            ),
        )
        .returning(User.failed_login_attempts, User.locked_until)
    )
    result = await db.execute(stmt)
    row = result.first()
    if row is None:
        return 0, None

    attempts, locked_until = row
    if locked_until is not None and locked_until == lock_until:
        log.warning(
            "User_id=%s locked after %d failed attempts for %d minutes",
            user_id, attempts, auth_config.ACCOUNT_LOCKOUT_MINUTES,
        )
    else:
        log.info("Failed login attempt %d for user_id=%s", attempts, user_id)

    return attempts, locked_until


async def is_account_locked(db: AsyncSession, user_id: uuid.UUID) -> bool:
    """Return True if the account is currently locked (lockout not yet expired)."""
    user = await get_user_by_id(db, user_id)
    if user is None or user.locked_until is None:
        return False
    return _ensure_aware(user.locked_until) > _utcnow()


# ---------------------------------------------------------------------------
# Soft-delete
# ---------------------------------------------------------------------------

async def soft_delete_user(db: AsyncSession, user_id: uuid.UUID) -> None:
    """Soft-delete a user (reversible within retention period).

    Also revokes all refresh tokens and sets status=deleted.
    """
    from auth.services.tokens import revoke_all_user_tokens
    user = await get_user_by_id(db, user_id)
    if user is None:
        return

    user.deleted_at = datetime.now(timezone.utc)
    user.status = UserStatus.deleted
    await revoke_all_user_tokens(db, user_id, reason="account_deleted")
    log.info("Soft-deleted user_id=%s", user_id)


# ---------------------------------------------------------------------------
# Email verification tokens
# ---------------------------------------------------------------------------

async def create_email_verification_token(
    db: AsyncSession,
    user: User,
    verification_type: EmailVerificationType,
    issued_ip: Optional[str] = None,
) -> tuple[str, datetime]:
    """Create a new email verification / password reset token.

    Returns (plaintext_token, expires_at).

    All other active tokens of the same type for this user are revoked
    (prevents accumulation of valid tokens).
    """
    import hashlib
    import secrets

    plaintext = secrets.token_hex(32)
    token_hash = hashlib.sha256(plaintext.encode("utf-8")).hexdigest()

    if verification_type == EmailVerificationType.email_verification:
        expires_at = datetime.now(timezone.utc) + timedelta(
            hours=auth_config.EMAIL_VERIFICATION_TOKEN_EXPIRE_HOURS
        )
    else:  # password_reset
        expires_at = datetime.now(timezone.utc) + timedelta(
            minutes=auth_config.PASSWORD_RESET_TOKEN_EXPIRE_MINUTES
        )

    # Mark all previous tokens of same type as consumed (single-use semantics).
    stmt = (
        update(EmailVerification)
        .where(
            EmailVerification.user_id == user.id,
            EmailVerification.verification_type == verification_type,
            EmailVerification.consumed_at.is_(None),
        )
        .values(consumed_at=datetime.now(timezone.utc))
    )
    await db.execute(stmt)

    # Insert the new token.
    record = EmailVerification(
        user_id=user.id,
        verification_type=verification_type,
        token_hash=token_hash,
        sent_to_email=user.email,
        expires_at=expires_at,
        issued_ip=issued_ip,
    )
    db.add(record)
    await db.flush()

    log.info("Created %s token for user_id=%s expires_at=%s",
             verification_type.value, user.id, expires_at.isoformat())
    return plaintext, expires_at


async def consume_email_verification_token(
    db: AsyncSession,
    plaintext_token: str,
    verification_type: EmailVerificationType,
) -> Optional[User]:
    """Validate and consume a one-time token.

    Returns the User if valid, None if:
      - token not found
      - already consumed
      - expired
      - wrong type

    On success, also revokes all other tokens of the same type for safety.
    """
    import hashlib
    token_hash = hashlib.sha256(plaintext_token.encode("utf-8")).hexdigest()

    stmt = select(EmailVerification).where(
        EmailVerification.token_hash == token_hash,
        EmailVerification.verification_type == verification_type,
    )
    result = await db.execute(stmt)
    record = result.scalar_one_or_none()

    if record is None:
        log.info("Email verification token not found")
        return None

    if record.consumed_at is not None:
        log.warning("Email verification token reuse attempt! id=%s", record.id)
        return None

    if _ensure_aware(record.expires_at) <= _utcnow():
        log.info("Email verification token expired id=%s", record.id)
        return None

    # Consume the token.
    record.consumed_at = _utcnow()

    user = await get_user_by_id(db, record.user_id)
    if user is None:
        return None

    log.info("Consumed %s token for user_id=%s", verification_type.value, user.id)
    return user


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_email(email: str) -> str:
    """Lowercase and strip whitespace. Does NOT validate format — caller must."""
    if email is None:
        raise ValueError("Email cannot be None")
    return email.strip().lower()


def authenticate_user_sync(user: Optional[User], plaintext_password: str) -> tuple[bool, Optional[User], Optional[str]]:
    """Verify password and return (is_valid, user, new_hash_or_None).

    Pure function — no DB calls. The caller is responsible for:
      - calling update_login_success or update_login_failure based on result
      - persisting the new_hash if returned (cost-factor upgrade)
    """
    if user is None:
        # Run a dummy bcrypt verify to keep timing consistent
        # (prevents timing-based user enumeration).
        try:
            verify_and_maybe_rehash(plaintext_password, "$2b$12$" + "x" * 53)
        except Exception:
            pass
        return False, None, None

    if user.status != UserStatus.active:
        return False, None, None

    is_valid, new_hash = verify_and_maybe_rehash(plaintext_password, user.password_hash)
    return is_valid, (user if is_valid else None), new_hash
