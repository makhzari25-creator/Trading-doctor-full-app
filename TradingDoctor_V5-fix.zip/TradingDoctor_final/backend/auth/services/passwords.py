# -*- coding: utf-8 -*-
"""
auth/services/passwords.py
--------------------------
Phase 8 — Password hashing and verification using bcrypt.

Security properties:
  - bcrypt with cost factor from PASSWORD_HASH_ROUNDS (default 12).
  - bcrypt internally generates and embeds a 16-byte salt in the hash output,
    so we do NOT manage salts separately.
  - bcrypt truncates input at 72 bytes. We do NOT pre-hash with SHA-256
    (the "bcrypt(sha256(password))" pattern) because:
      (a) it removes bcrypt's 72-byte DoS protection,
      (b) modern research (Django, OWASP) considers direct bcrypt preferable.
    Instead, we reject passwords longer than 128 chars at the validator layer.
  - Verification is constant-time (bcrypt's password_verify handles this).
  - Rehashing on cost-factor upgrade: if a stored hash has a lower cost factor
    than the current PASSWORD_HASH_ROUNDS, we transparently re-hash on next
    successful login (see `verify_and_maybe_rehash`).
"""

from __future__ import annotations

import bcrypt
from utils.logger import get_logger

from auth import config as auth_config

log = get_logger("auth.passwords")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def hash_password(plaintext: str) -> str:
    """Hash a plaintext password using bcrypt.

    Returns a string like '$2b$12$....' (60 chars total).
    """
    if not plaintext:
        raise ValueError("Password cannot be empty.")
    if len(plaintext) > auth_config.PASSWORD_MAX_LENGTH:
        raise ValueError(
            f"Password is longer than {auth_config.PASSWORD_MAX_LENGTH} characters."
        )

    # bcrypt requires bytes, not str.
    plaintext_bytes = plaintext.encode("utf-8")

    # bcrypt.gensalt(rounds) returns a salt with the cost factor embedded.
    salt = bcrypt.gensalt(rounds=auth_config.PASSWORD_HASH_ROUNDS)

    # bcrypt.hashpw returns the full hash (incl. algorithm, cost, salt, digest).
    hashed = bcrypt.hashpw(plaintext_bytes, salt)

    return hashed.decode("utf-8")


def verify_password(plaintext: str, hashed: str) -> bool:
    """Verify a plaintext password against a stored bcrypt hash.

    Returns True on match, False otherwise. NEVER raises on mismatch.
    """
    if not plaintext or not hashed:
        return False
    try:
        plaintext_bytes = plaintext.encode("utf-8")
        hashed_bytes = hashed.encode("utf-8")
        # bcrypt.checkpw is constant-time.
        return bcrypt.checkpw(plaintext_bytes, hashed_bytes)
    except (ValueError, TypeError) as exc:
        # Malformed hash (e.g. wrong algorithm prefix). Log and fail closed.
        log.warning("Malformed password hash during verify: %s", exc)
        return False


def verify_and_maybe_rehash(plaintext: str, hashed: str) -> tuple[bool, str | None]:
    """Verify password; if cost factor is outdated, return a new hash.

    Returns (is_valid, new_hash_or_None).
      - is_valid=False, new_hash=None    → password did not match
      - is_valid=True,  new_hash=None    → password matched, hash is up-to-date
      - is_valid=True,  new_hash="..."   → password matched, hash was re-hashed
                                            (caller should UPDATE the user row)
    """
    if not verify_password(plaintext, hashed):
        return False, None

    new_hash = None
    if _needs_rehash(hashed):
        try:
            new_hash = hash_password(plaintext)
            log.info("Re-hashed password with higher cost factor.")
        except Exception as exc:
            # Re-hashing is best-effort; never block login.
            log.warning("Failed to re-hash password: %s", exc)

    return True, new_hash


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _needs_rehash(hashed: str) -> bool:
    """Return True if the bcrypt hash uses a lower cost factor than configured."""
    try:
        # bcrypt hash format: $2b$<rounds>$<22-char-salt><31-char-digest>
        # Extract the rounds portion.
        parts = hashed.split("$")
        if len(parts) < 3:
            return True  # malformed; treat as needing rehash
        current_rounds = int(parts[2])
        return current_rounds < auth_config.PASSWORD_HASH_ROUNDS
    except (ValueError, IndexError):
        return True


def password_meets_policy(password: str) -> tuple[bool, str | None]:
    """Check if a password meets the minimum policy.

    Returns (is_valid, error_message).
      - is_valid=True, error_message=None  → password is acceptable
      - is_valid=False, error_message="…"  → password rejected with reason
    """
    if not password:
        return False, "Password cannot be empty."

    if len(password) < auth_config.PASSWORD_MIN_LENGTH:
        return False, (
            f"Password must be at least {auth_config.PASSWORD_MIN_LENGTH} characters long."
        )

    if len(password) > auth_config.PASSWORD_MAX_LENGTH:
        return False, (
            f"Password cannot be longer than {auth_config.PASSWORD_MAX_LENGTH} characters."
        )

    # Require at least one letter and one digit (no special-char requirement;
    # see module docstring for rationale).
    has_letter = any(c.isalpha() for c in password)
    has_digit = any(c.isdigit() for c in password)
    if not (has_letter and has_digit):
        return False, "Password must contain at least one letter and one digit."

    return True, None
