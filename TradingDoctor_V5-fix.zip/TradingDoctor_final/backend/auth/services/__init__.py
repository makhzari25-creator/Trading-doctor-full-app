# -*- coding: utf-8 -*-
"""
auth/services package — internal service-layer modules for auth.
"""
