# -*- coding: utf-8 -*-
"""
auth/services/audit.py
----------------------
Phase 8 — Audit log service.

Records every authentication-related event in the audit_log table.
Records are append-only (no UPDATE or DELETE exposed at the service layer).
"""

from __future__ import annotations

import json
import uuid
from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from auth.models import AuditLog, AuditEventType
from utils.logger import get_logger

log = get_logger("auth.audit")


async def record_event(
    db: AsyncSession,
    event_type: AuditEventType,
    user_id: Optional[uuid.UUID] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    outcome: str = "info",
    details: Optional[dict[str, Any]] = None,
    commit: bool = False,
) -> AuditLog:
    """Append an entry to the audit log.

    Args:
      event_type:   what happened
      user_id:      the user the event is about (None if not yet identified)
      ip_address:   request.remote_addr
      user_agent:   request.headers.get("user-agent")
      outcome:      "success" | "failure" | "info"
      details:      optional dict, JSON-encoded into the details column
      commit:       if True, also commits the transaction (default False)

    Returns the created AuditLog record.
    """
    record = AuditLog(
        event_type=event_type,
        user_id=user_id,
        ip_address=ip_address,
        user_agent=(user_agent or "")[:512] or None,
        outcome=outcome,
        details=json.dumps(details, ensure_ascii=False, default=str) if details else None,
    )
    db.add(record)
    await db.flush()

    if commit:
        await db.commit()

    log.debug("Audit: event=%s user=%s outcome=%s ip=%s",
              event_type.value, user_id, outcome, ip_address)
    return record


# ---------------------------------------------------------------------------
# Convenience wrappers (semantic API)
# ---------------------------------------------------------------------------

async def record_register(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None, user_agent: str | None
) -> None:
    await record_event(
        db, AuditEventType.register, user_id=user_id,
        ip_address=ip, user_agent=user_agent, outcome="success",
    )


async def record_login_success(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None, user_agent: str | None
) -> None:
    await record_event(
        db, AuditEventType.login, user_id=user_id,
        ip_address=ip, user_agent=user_agent, outcome="success",
    )


async def record_login_failure(
    db: AsyncSession,
    email: str,
    ip: str | None,
    user_agent: str | None,
    reason: str = "invalid_credentials",
    user_id: Optional[uuid.UUID] = None,
) -> None:
    await record_event(
        db, AuditEventType.login_failed, user_id=user_id,
        ip_address=ip, user_agent=user_agent, outcome="failure",
        details={"email": email, "reason": reason},
    )


async def record_logout(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.logout, user_id=user_id,
        ip_address=ip, outcome="success",
    )


async def record_refresh(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.refresh, user_id=user_id,
        ip_address=ip, outcome="success",
    )


async def record_refresh_failure(
    db: AsyncSession, ip: str | None, reason: str
) -> None:
    await record_event(
        db, AuditEventType.refresh_failed, user_id=None,
        ip_address=ip, outcome="failure", details={"reason": reason},
    )


async def record_email_verification_sent(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.email_verification_sent, user_id=user_id,
        ip_address=ip, outcome="success",
    )


async def record_email_verified(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.email_verified, user_id=user_id,
        ip_address=ip, outcome="success",
    )


async def record_password_reset_requested(
    db: AsyncSession, email: str, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.password_reset_requested,
        ip_address=ip, outcome="success", details={"email": email},
    )


async def record_password_reset_completed(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.password_reset_completed, user_id=user_id,
        ip_address=ip, outcome="success",
    )


async def record_password_changed(
    db: AsyncSession, user_id: uuid.UUID, ip: str | None
) -> None:
    await record_event(
        db, AuditEventType.password_changed, user_id=user_id,
        ip_address=ip, outcome="success",
    )
