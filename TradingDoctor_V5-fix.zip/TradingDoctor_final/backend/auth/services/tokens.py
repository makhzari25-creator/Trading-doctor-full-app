# -*- coding: utf-8 -*-
"""
auth/services/tokens.py
-----------------------
Phase 8 — JWT access tokens + opaque refresh tokens.

Two distinct token types with different security properties:

  ACCESS TOKEN (JWT):
    - Self-contained: contains user_id, email, status, expiry, issuer, audience.
    - Signed with JWT_SECRET_KEY (HS256) or RSA private key (RS256).
    - Short-lived (default 15 min).
    - Stateless: server does NOT consult DB to validate (only signature + claims).
    - Cannot be revoked without a blacklist (acceptable tradeoff for short TTL).
    - Sent in `Authorization: Bearer <token>` header.

  REFRESH TOKEN (opaque):
    - NOT a JWT. A 32-byte random string, returned as 64-char hex.
    - Stored in DB as SHA-256 hash (token_hash column).
    - Long-lived (default 30 days).
    - Stateful: server consults DB on every refresh to check revocation.
    - Single-use: each refresh rotates (old token revoked, new one issued).
    - Sent as HTTP-only cookie OR in request body (NEVER in URL — logged everywhere).

Reuse detection (forward security):
    If a refresh token is presented AFTER it has been rotated, the entire
    token family is revoked (the user must re-authenticate). This catches
    token theft where an attacker stole a refresh token and the legitimate
    user also continues to use the app.
"""

from __future__ import annotations

import hashlib
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from auth import config as auth_config
from auth.models import RefreshToken, User, UserStatus
from utils.logger import get_logger

log = get_logger("auth.tokens")


def _utcnow() -> datetime:
    """Return current UTC datetime (timezone-aware)."""
    return datetime.now(timezone.utc)


def _ensure_aware(dt: datetime) -> datetime:
    """Force a datetime to be timezone-aware (assume UTC if naive).

    SQLite returns naive datetimes; Postgres returns aware ones (with
    `DateTime(timezone=True)`). This helper unifies behavior across DBs.
    """
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


# ---------------------------------------------------------------------------
# Access token (JWT)
# ---------------------------------------------------------------------------

def create_access_token(
    user: User,
    extra_claims: dict[str, Any] | None = None,
) -> tuple[str, datetime]:
    """Create a signed JWT access token for a user.

    Returns (token_string, expires_at_utc).
    """
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(seconds=auth_config.ACCESS_TOKEN_EXPIRE_SECONDS)

    payload: dict[str, Any] = {
        "sub": str(user.id),                # subject = user ID (string for JWT)
        "email": user.email,
        "status": user.status.value,
        "iss": auth_config.JWT_ISSUER,
        "aud": auth_config.JWT_AUDIENCE,
        "iat": int(now.timestamp()),
        "exp": int(expires_at.timestamp()),
        "jti": uuid.uuid4().hex,            # unique token ID (for future blacklisting)
        "type": "access",
    }
    if extra_claims:
        # Whitelist of allowed claim keys (defensive: callers cannot inject 'iss' etc.)
        _ALLOWED_EXTRA = {"plan", "role", "tier"}
        for k, v in extra_claims.items():
            if k in _ALLOWED_EXTRA:
                payload[k] = v

    token = jwt.encode(
        payload,
        auth_config.JWT_SECRET_KEY,
        algorithm=auth_config.JWT_ALGORITHM,
    )
    return token, expires_at


def decode_access_token(token: str) -> dict[str, Any]:
    """Decode and validate a JWT access token.

    Returns the claims dict on success.
    Raises:
      - jwt.InvalidTokenError (or subclass) on any failure:
        ExpiredSignatureError, InvalidAudienceError, InvalidIssuerError, etc.
    """
    claims = jwt.decode(
        token,
        auth_config.JWT_SECRET_KEY,
        algorithms=[auth_config.JWT_ALGORITHM],
        audience=auth_config.JWT_AUDIENCE,
        issuer=auth_config.JWT_ISSUER,
        options={"require": ["exp", "iat", "sub", "iss", "aud"]},
    )
    if claims.get("type") != "access":
        raise jwt.InvalidTokenError("Token is not an access token.")
    return claims


# ---------------------------------------------------------------------------
# Refresh token (opaque, stored in DB)
# ---------------------------------------------------------------------------

def _generate_refresh_token() -> tuple[str, str]:
    """Generate a new refresh token.

    Returns (plaintext_token, sha256_hash).
      - plaintext_token: 64-char hex string (32 bytes of entropy)
      - sha256_hash:     64-char hex string (for DB storage)
    """
    plaintext = secrets.token_hex(32)
    token_hash = hashlib.sha256(plaintext.encode("utf-8")).hexdigest()
    return plaintext, token_hash


def _hash_refresh_token(plaintext: str) -> str:
    """Hash a plaintext refresh token for DB lookup."""
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()


async def issue_refresh_token(
    db: AsyncSession,
    user: User,
    issued_ip: str | None = None,
    issued_user_agent: str | None = None,
) -> tuple[str, datetime, RefreshToken]:
    """Create a new refresh token for a user.

    Returns (plaintext_token, expires_at_utc, refresh_token_record).

    The plaintext is returned to the caller exactly once. The DB stores
    only the hash.
    """
    plaintext, token_hash = _generate_refresh_token()
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(seconds=auth_config.REFRESH_TOKEN_EXPIRE_SECONDS)

    record = RefreshToken(
        user_id=user.id,
        token_hash=token_hash,
        expires_at=expires_at,
        issued_ip=issued_ip,
        issued_user_agent=issued_user_agent,
    )
    db.add(record)
    await db.flush()  # populate record.id
    log.info("Issued refresh token id=%s for user_id=%s", record.id, user.id)
    return plaintext, expires_at, record


async def rotate_refresh_token(
    db: AsyncSession,
    presented_plaintext: str,
    new_issued_ip: str | None = None,
    new_issued_user_agent: str | None = None,
) -> tuple[User, str, datetime, RefreshToken] | None:
    """Use a refresh token to mint a new one (rotation).

    Steps:
      1. Look up the token by hash. If not found → return None (invalid).
      2. If token is revoked → return None (reuse detected!).
      3. If token is expired → return None.
      4. Mark old token as revoked (reason="rotated"), set replaced_by_id.
      5. Issue a new refresh token, link its ID to the old token.
      6. Return (user, new_plaintext, new_expires_at, new_record).

    Returns None on any failure (caller should return 401).
    """
    token_hash = _hash_refresh_token(presented_plaintext)

    # Load the token with its user in one query.
    stmt = (
        select(RefreshToken)
        .where(RefreshToken.token_hash == token_hash)
        .options(selectinload_user())  # type: ignore[attr-defined]
    )
    result = await db.execute(stmt)
    old_token = result.scalar_one_or_none()

    if old_token is None:
        log.info("Refresh token rotation failed: token not found")
        return None

    if old_token.revoked_at is not None:
        # REUSE DETECTED — revoke the entire chain.
        log.warning(
            "Refresh token reuse detected! token_id=%s user_id=%s — "
            "revoking entire token family",
            old_token.id, old_token.user_id,
        )
        await _revoke_token_family(db, old_token)
        return None

    if _ensure_aware(old_token.expires_at) <= _utcnow():
        log.info("Refresh token rotation failed: expired token_id=%s", old_token.id)
        # Clean up: mark as revoked (reason="expired")
        old_token.revoked_at = _utcnow()
        old_token.revoked_reason = "expired"
        return None

    # Load the user.
    user = old_token.user
    if user is None or user.status != UserStatus.active:
        log.info("Refresh token rotation failed: user not active")
        return None

    # Issue the new token FIRST so we can link it.
    new_plaintext, new_expires_at, new_record = await issue_refresh_token(
        db, user, issued_ip=new_issued_ip, issued_user_agent=new_issued_user_agent,
    )

    # Mark old token as rotated.
    old_token.revoked_at = _utcnow()
    old_token.revoked_reason = "rotated"
    old_token.replaced_by_id = new_record.id

    log.info("Rotated refresh token old=%s new=%s for user_id=%s",
             old_token.id, new_record.id, user.id)

    return user, new_plaintext, new_expires_at, new_record


async def revoke_refresh_token(
    db: AsyncSession,
    presented_plaintext: str,
    reason: str = "logout",
) -> bool:
    """Revoke a single refresh token (e.g. on logout).

    Returns True if a token was found and revoked, False if not found.
    """
    token_hash = _hash_refresh_token(presented_plaintext)
    stmt = select(RefreshToken).where(RefreshToken.token_hash == token_hash)
    result = await db.execute(stmt)
    token = result.scalar_one_or_none()

    if token is None:
        return False

    if token.revoked_at is None:
        token.revoked_at = datetime.now(timezone.utc)
        token.revoked_reason = reason
        log.info("Revoked refresh token id=%s reason=%s", token.id, reason)
    return True


async def revoke_all_user_tokens(
    db: AsyncSession,
    user_id: uuid.UUID,
    reason: str = "admin_action",
) -> int:
    """Revoke all active refresh tokens for a user.

    Used on password change, account suspension, or admin force-logout.
    Returns the count of revoked tokens.
    """
    now = datetime.now(timezone.utc)
    stmt = (
        update(RefreshToken)
        .where(
            RefreshToken.user_id == user_id,
            RefreshToken.revoked_at.is_(None),
        )
        .values(revoked_at=now, revoked_reason=reason)
    )
    result = await db.execute(stmt)
    count = result.rowcount or 0
    log.info("Revoked %d refresh tokens for user_id=%s reason=%s", count, user_id, reason)
    return count


async def _revoke_token_family(db: AsyncSession, token: RefreshToken) -> None:
    """Revoke all tokens in the same chain as `token`.

    Walks the replaced_by chain forward (token → its replacement → ...).
    Also revokes the original token. This is the standard "reuse detection"
    response: assume compromise, force re-authentication.

    Performance: a rotation chain only ever links tokens belonging to the
    same user (each refresh reuses `user_id`), so instead of issuing one
    SELECT per hop (N+1), we fetch every token for that user in a single
    query and walk the chain in memory.
    """
    now = datetime.now(timezone.utc)

    # Single query: load all of this user's tokens once, keyed by id.
    stmt = select(RefreshToken).where(RefreshToken.user_id == token.user_id)
    result = await db.execute(stmt)
    tokens_by_id: dict[uuid.UUID, RefreshToken] = {
        t.id: t for t in result.scalars().all()
    }
    tokens_by_id.setdefault(token.id, token)

    # Walk forward through replacements using the in-memory map (no further queries).
    chain_ids: list[uuid.UUID] = [token.id]
    current = token
    seen: set[uuid.UUID] = {token.id}
    while current.replaced_by_id is not None and current.replaced_by_id not in seen:
        nxt = tokens_by_id.get(current.replaced_by_id)
        chain_ids.append(current.replaced_by_id)
        seen.add(current.replaced_by_id)
        if nxt is None:
            break
        current = nxt

    # Bulk-revoke all tokens in the chain.
    stmt = (
        update(RefreshToken)
        .where(RefreshToken.id.in_(chain_ids))
        .values(revoked_at=now, revoked_reason="reuse_detected")
    )
    await db.execute(stmt)
    log.warning("Revoked %d tokens in family due to reuse detection", len(chain_ids))


# ---------------------------------------------------------------------------
# Helper: selectinload user relationship
# ---------------------------------------------------------------------------

def selectinload_user():
    """Return a selectinload option for RefreshToken.user.

    Lazy import to avoid circular dependency at module load time.
    """
    from sqlalchemy.orm import selectinload
    return selectinload(RefreshToken.user)
