# -*- coding: utf-8 -*-
"""
auth/services/email.py
----------------------
Phase 8 — Pluggable email service for auth-related transactional emails.

Backends:
  - console:    dev only — prints to stdout (default)
  - smtp:       any SMTP server (async via aiosmtplib)
  - ses:        AWS SES (uses boto3 if installed, otherwise raw SMTP)
  - sendgrid:   SendGrid API (uses sendgrid library if installed)

Email types sent:
  - email_verification:   "Verify your email" with token link
  - password_reset:       "Reset your password" with token link
  - welcome:              "Welcome to Trading Doctor" (after verification)
  - login_alert:          "New login from X" (optional, on new IP)

All emails are async. Failures are logged but NEVER raise to the caller
(transactional emails should not break registration / login flows).
"""

from __future__ import annotations

import abc
import os
from typing import Optional

from utils.logger import get_logger

log = get_logger("auth.email")


# ---------------------------------------------------------------------------
# Backend selection
# ---------------------------------------------------------------------------

def get_email_backend() -> "EmailBackend":
    """Return the configured email backend instance.

    Selection is by EMAIL_BACKEND env var:
      - "console"  (default — dev)
      - "smtp"
      - "ses"
      - "sendgrid"

    Backends are instantiated lazily; heavy imports (boto3, sendgrid) only
    happen when that backend is selected.
    """
    backend_name = os.getenv("EMAIL_BACKEND", "console").strip().lower()

    if backend_name == "console":
        return ConsoleEmailBackend()
    if backend_name == "smtp":
        return SMTPEmailBackend()
    if backend_name == "ses":
        return SESEmailBackend()
    if backend_name == "sendgrid":
        return SendGridEmailBackend()

    log.warning("Unknown EMAIL_BACKEND=%r, falling back to console", backend_name)
    return ConsoleEmailBackend()


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class EmailBackend(abc.ABC):
    """Base class for all email backends."""

    @abc.abstractmethod
    async def send(
        self,
        to_email: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
    ) -> bool:
        """Send an email. Returns True on success, False on failure.

        Implementations MUST catch all exceptions and return False — never raise.
        """
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Console (dev)
# ---------------------------------------------------------------------------

class ConsoleEmailBackend(EmailBackend):
    """Prints emails to stdout. Useful for local development.

    No network calls. Always returns True.
    """

    async def send(
        self,
        to_email: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
    ) -> bool:
        from_addr = from_email or os.getenv("EMAIL_SMTP_FROM", "noreply@tradingdoctor.local")
        separator = "=" * 70
        print(f"\n{separator}\nEMAIL (console backend)\n{separator}")
        print(f"From:    {from_addr}")
        print(f"To:      {to_email}")
        print(f"Subject: {subject}")
        print(separator)
        if text_body:
            print(text_body)
        else:
            # Strip HTML tags for console readability.
            import re
            stripped = re.sub(r"<[^>]+>", "", html_body)
            print(stripped.strip())
        print(separator + "\n")
        return True


# ---------------------------------------------------------------------------
# SMTP
# ---------------------------------------------------------------------------

class SMTPEmailBackend(EmailBackend):
    """Async SMTP backend using aiosmtplib.

    Configuration:
      - EMAIL_SMTP_HOST
      - EMAIL_SMTP_PORT (default 587)
      - EMAIL_SMTP_USERNAME
      - EMAIL_SMTP_PASSWORD
      - EMAIL_SMTP_USE_TLS (default true)
      - EMAIL_SMTP_FROM
    """

    async def send(
        self,
        to_email: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
    ) -> bool:
        try:
            import aiosmtplib
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
        except ImportError:
            log.error("aiosmtplib not installed; cannot send SMTP email")
            return False

        host = os.getenv("EMAIL_SMTP_HOST", "")
        port = int(os.getenv("EMAIL_SMTP_PORT", "587"))
        username = os.getenv("EMAIL_SMTP_USERNAME", "")
        password = os.getenv("EMAIL_SMTP_PASSWORD", "")
        use_tls = os.getenv("EMAIL_SMTP_USE_TLS", "true").lower() in ("true", "1", "yes")
        from_addr = from_email or os.getenv("EMAIL_SMTP_FROM", "noreply@tradingdoctor.local")

        if not host:
            log.error("EMAIL_SMTP_HOST not set; cannot send SMTP email")
            return False

        msg = MIMEMultipart("alternative")
        msg["From"] = from_addr
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(text_body or "(this email requires HTML)", "plain"))
        msg.attach(MIMEText(html_body, "html"))

        try:
            await aiosmtplib.send(
                msg.as_bytes(),
                hostname=host,
                port=port,
                username=username or None,
                password=password or None,
                start_tls=use_tls,
            )
            log.info("SMTP email sent to=%s subject=%r", to_email, subject)
            return True
        except Exception as exc:
            log.error("SMTP send failed to=%s: %s", to_email, exc)
            return False


# ---------------------------------------------------------------------------
# AWS SES (via SMTP — simplest, no extra SDK needed)
# ---------------------------------------------------------------------------

class SESEmailBackend(EmailBackend):
    """AWS SES via SMTP interface.

    Uses the same SMTP code as SMTPEmailBackend but reads SES-specific env:
      - SES_AWS_REGION
      - SES_FROM_EMAIL
      - (SMTP credentials must be configured in SES console and set via
         EMAIL_SMTP_USERNAME / EMAIL_SMTP_PASSWORD)
    """

    async def send(
        self,
        to_email: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
    ) -> bool:
        region = os.getenv("SES_AWS_REGION", "us-east-1")
        from_addr = from_email or os.getenv("SES_FROM_EMAIL", "noreply@tradingdoctor.local")

        # Override SMTP host to SES endpoint if not explicitly set.
        if not os.getenv("EMAIL_SMTP_HOST"):
            os.environ["EMAIL_SMTP_HOST"] = f"email-smtp.{region}.amazonaws.com"

        # Delegate to SMTP backend.
        smtp_backend = SMTPEmailBackend()
        return await smtp_backend.send(to_email, subject, html_body, text_body, from_addr)


# ---------------------------------------------------------------------------
# SendGrid (via API)
# ---------------------------------------------------------------------------

class SendGridEmailBackend(EmailBackend):
    """SendGrid API backend.

    Requires SENDGRID_API_KEY env var. Uses the SendGrid REST API directly
    (no SDK dependency).
    """

    async def send(
        self,
        to_email: str,
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        from_email: Optional[str] = None,
    ) -> bool:
        api_key = os.getenv("SENDGRID_API_KEY", "")
        if not api_key:
            log.error("SENDGRID_API_KEY not set; cannot send SendGrid email")
            return False

        from_addr = from_email or os.getenv("EMAIL_SMTP_FROM", "noreply@tradingdoctor.local")

        try:
            import aiohttp
        except ImportError:
            # Fall back to sync requests in a thread
            return await self._send_sync(to_email, subject, html_body, text_body, from_addr, api_key)

        payload = {
            "personalizations": [{"to": [{"email": to_email}]}],
            "from": {"email": from_addr},
            "subject": subject,
            "content": [
                {"type": "text/plain", "value": text_body or "(this email requires HTML)"},
                {"type": "text/html", "value": html_body},
            ],
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://api.sendgrid.com/v3/mail/send",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    if 200 <= resp.status < 300:
                        log.info("SendGrid email sent to=%s subject=%r", to_email, subject)
                        return True
                    body = await resp.text()
                    log.error("SendGrid API error %d: %s", resp.status, body[:300])
                    return False
        except Exception as exc:
            log.error("SendGrid send failed to=%s: %s", to_email, exc)
            return False

    async def _send_sync(self, to_email, subject, html_body, text_body, from_addr, api_key):
        """Fallback when aiohttp is not installed."""
        import requests
        payload = {
            "personalizations": [{"to": [{"email": to_email}]}],
            "from": {"email": from_addr},
            "subject": subject,
            "content": [
                {"type": "text/plain", "value": text_body or "(this email requires HTML)"},
                {"type": "text/html", "value": html_body},
            ],
        }
        try:
            resp = requests.post(
                "https://api.sendgrid.com/v3/mail/send",
                json=payload,
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            if 200 <= resp.status_code < 300:
                log.info("SendGrid email sent to=%s subject=%r", to_email, subject)
                return True
            log.error("SendGrid API error %d: %s", resp.status_code, resp.text[:300])
            return False
        except Exception as exc:
            log.error("SendGrid send failed to=%s: %s", to_email, exc)
            return False


# ---------------------------------------------------------------------------
# Convenience: send pre-built auth emails
# ---------------------------------------------------------------------------

async def send_email_verification_email(to_email: str, token: str, user_name: str | None = None) -> bool:
    """Send the 'verify your email' email with a verification link."""
    from auth.templates.email_templates import render_email_verification

    base_url = os.getenv("FRONTEND_BASE_URL", "http://localhost:3000")
    verification_url = f"{base_url}/auth/verify-email?token={token}"

    subject = "تأیید ایمیل — Trading Doctor"  # Persian: "Email verification — Trading Doctor"
    html = render_email_verification(
        user_name=user_name or to_email,
        verification_url=verification_url,
    )

    backend = get_email_backend()
    return await backend.send(to_email, subject, html_body=html)


async def send_password_reset_email(to_email: str, token: str, user_name: str | None = None) -> bool:
    """Send the 'reset your password' email with a reset link."""
    from auth.templates.email_templates import render_password_reset

    base_url = os.getenv("FRONTEND_BASE_URL", "http://localhost:3000")
    reset_url = f"{base_url}/auth/reset-password?token={token}"

    subject = "بازنشانی رمز عبور — Trading Doctor"  # Persian: "Password reset — Trading Doctor"
    html = render_password_reset(
        user_name=user_name or to_email,
        reset_url=reset_url,
    )

    backend = get_email_backend()
    return await backend.send(to_email, subject, html_body=html)


async def send_welcome_email(to_email: str, user_name: str | None = None) -> bool:
    """Send the post-verification welcome email."""
    from auth.templates.email_templates import render_welcome

    subject = "خوش آمدید به Trading Doctor"
    html = render_welcome(user_name=user_name or to_email)

    backend = get_email_backend()
    return await backend.send(to_email, subject, html_body=html)
