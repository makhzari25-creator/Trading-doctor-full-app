# -*- coding: utf-8 -*-
"""
auth/routers/me.py
------------------
Phase 8 — Profile management endpoints (authenticated).

  - GET    /api/v1/me                — get current user profile
  - PATCH  /api/v1/me                 — update profile (full_name, locale)
  - POST   /api/v1/me/password        — change password (requires current)
  - DELETE /api/v1/me                 — soft-delete account
  - GET    /api/v1/me/activity        — recent audit events for this user
"""

from __future__ import annotations

import uuid
from typing import List

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from auth.dependencies import get_current_user
from auth.exceptions import InvalidCredentialsError
from auth.models import AuditLog, User
from auth.schemas import (
    ChangePasswordRequest,
    UpdateProfileRequest,
    UserProfileResponse,
    UserPublic,
)
from auth.services import audit
from auth.services.passwords import verify_password
from auth.services.tokens import revoke_all_user_tokens
from auth.services.users import change_password, soft_delete_user
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.me")

router = APIRouter(prefix="/me", tags=["User Profile"])


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


# ---------------------------------------------------------------------------
# Profile read/update
# ---------------------------------------------------------------------------

@router.get(
    "",
    response_model=UserProfileResponse,
    summary="دریافت پروفایل کاربر فعلی",
)
async def get_profile(
    user: User = Depends(get_current_user),
) -> UserProfileResponse:
    return UserProfileResponse(user=UserPublic.from_orm_user(user))


@router.patch(
    "",
    response_model=UserProfileResponse,
    summary="به‌روزرسانی پروفایل",
    description="به‌روزرسانی فیلدهای اختیاری: full_name و locale.",
)
async def update_profile(
    body: UpdateProfileRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserProfileResponse:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    if body.full_name is not None:
        user.full_name = body.full_name
    if body.locale is not None:
        user.locale = body.locale

    await db.commit()
    return UserProfileResponse(user=UserPublic.from_orm_user(user))


# ---------------------------------------------------------------------------
# Password change
# ---------------------------------------------------------------------------

@router.post(
    "/password",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="تغییر رمز عبور",
    description=(
        "تغییر رمز عبور با ارائه‌ی رمز فعلی. پس از تغییر، تمام توکن‌های "
        "بازنشانی باطل می‌شوند (نیاز به ورود مجدد در همه‌ی دستگاه‌ها)."
    ),
)
async def change_my_password(
    body: ChangePasswordRequest,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    # Verify current password.
    if not verify_password(body.current_password, user.password_hash):
        ip = _client_ip(request)
        await audit.record_event(
            db,
            event_type=__import__("auth.models", fromlist=["AuditEventType"]).AuditEventType.password_changed,
            user_id=user.id, ip_address=ip, outcome="failure",
            details={"reason": "invalid_current_password"},
        )
        await db.commit()
        raise InvalidCredentialsError("رمز عبور فعلی نادرست است.")

    await change_password(db, user.id, body.new_password)
    ip = _client_ip(request)
    await audit.record_password_changed(db, user.id, ip)
    await db.commit()


# ---------------------------------------------------------------------------
# Account deletion (soft)
# ---------------------------------------------------------------------------

@router.delete(
    "",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="حذف حساب کاربری",
    description=(
        "حذف نرم حساب کاربری. حساب قابل بازگردانی است تا ۳۰ روز. پس از آن "
        "حذف دائمی خواهد شد. تمام توکن‌های بازنشانی فوراً باطل می‌شوند."
    ),
)
async def delete_my_account(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    await soft_delete_user(db, user.id)
    await audit.record_event(
        db,
        event_type=__import__("auth.models", fromlist=["AuditEventType"]).AuditEventType.account_deleted,
        user_id=user.id, outcome="success",
    )
    await db.commit()


# ---------------------------------------------------------------------------
# Activity log
# ---------------------------------------------------------------------------

@router.get(
    "/activity",
    summary="رویدادهای اخیر حساب کاربری",
    description="آخرین ۲۰ رویداد امنیتی حساب کاربری (ورود، خروج، تغییر رمز و ...).",
)
async def get_my_activity(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> List[dict]:
    if db is None:
        return []

    stmt = (
        select(AuditLog)
        .where(AuditLog.user_id == user.id)
        .order_by(AuditLog.created_at.desc())
        .limit(20)
    )
    result = await db.execute(stmt)
    rows = result.scalars().all()

    import json
    return [
        {
            "event_type": r.event_type.value,
            "outcome": r.outcome,
            "ip_address": r.ip_address,
            "user_agent": r.user_agent,
            "timestamp": r.created_at.isoformat() if r.created_at else None,
            "details": json.loads(r.details) if r.details else None,
        }
        for r in rows
    ]
