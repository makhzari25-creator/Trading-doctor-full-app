# -*- coding: utf-8 -*-
"""
auth/routers/register.py
------------------------
Phase 8 — POST /api/v1/auth/register + resend verification.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from auth import config as auth_config
from auth.exceptions import EmailAlreadyRegisteredError
from auth.models import EmailVerificationType
from auth.schemas import (
    RegisterRequest,
    RegisterResponse,
    ResendVerificationRequest,
    PasswordResetRequestResponse,
)
from auth.services import audit
from auth.services.email import send_email_verification_email
from auth.services.users import create_user, create_email_verification_token, get_user_by_email
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.register")

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _client_ip(request: Request) -> str | None:
    """Extract client IP, honoring X-Forwarded-For from trusted proxies."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        # First IP in the chain is the original client.
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


def _user_agent(request: Request) -> str | None:
    return request.headers.get("user-agent")


@router.post(
    "/register",
    response_model=RegisterResponse,
    status_code=status.HTTP_201_CREATED,
    summary="ثبت‌نام کاربر جدید",
    description=(
        "ایجاد حساب کاربری جدید. پس از ثبت‌نام، ایمیل تأیید ارسال می‌شود. "
        "کاربر تا پیش از تأیید ایمیل نمی‌تواند وارد شود (در صورت فعال بودن "
        "REQUIRE_EMAIL_VERIFICATION). رمز عبور با bcrypt هش می‌شود."
    ),
)
async def register(
    body: RegisterRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> RegisterResponse:
    if db is None:
        raise RuntimeError("Database is required for registration but is not configured.")

    ip = _client_ip(request)
    ua = _user_agent(request)

    try:
        user = await create_user(
            db=db,
            email=body.email,
            password=body.password,
            full_name=body.full_name,
            locale=body.locale,
            marketing_consent=body.marketing_consent,
        )
    except ValueError as exc:
        if "EMAIL_ALREADY_REGISTERED" in str(exc):
            # Anti-enumeration: do NOT reveal that the email is taken.
            # Instead, return 409 with a generic message.
            log.info("Registration attempt with existing email: %s", body.email)
            raise EmailAlreadyRegisteredError(
                "این ایمیل قبلاً ثبت شده است. برای ورود به صفحه‌ی ورود بروید."
            )
        raise

    # Issue an email verification token.
    token, _expires = await create_email_verification_token(
        db, user, EmailVerificationType.email_verification, issued_ip=ip,
    )

    # Send the verification email (best-effort; never block registration).
    try:
        await send_email_verification_email(user.email, token, user.full_name)
    except Exception as exc:
        log.error("Failed to send verification email to %s: %s", user.email, exc)

    # Phase 10: Auto-assign free plan subscription (best-effort).
    # Failure here must NOT block registration — the user can still log in;
    # they'll just hit the "no subscription" path on first workspace access,
    # which also auto-assigns free.
    try:
        from billing import config as billing_config
        if billing_config.AUTO_ASSIGN_FREE_PLAN:
            from billing.services.subscriptions import ensure_free_subscription
            await ensure_free_subscription(db, user.id, user.email)
    except Exception as exc:
        log.warning("Failed to auto-assign free plan for user_id=%s: %s",
                    user.id, exc)

    await audit.record_register(db, user.id, ip, ua)
    await db.commit()

    return RegisterResponse(
        user_id=str(user.id),
        email=user.email,
        status=user.status.value,
    )


@router.post(
    "/resend-verification",
    response_model=PasswordResetRequestResponse,
    summary="ارسال مجدد ایمیل تأیید",
    description=(
        "اگر ایمیل تأیید دریافت نکرده‌اید، با این مسیر می‌توانید درخواست ارسال "
        "مجدد بدهید. به دلایل امنیتی، حتی اگر ایمیل در سیستم موجود نباشد، "
        "پیام موفقیت برمی‌گردد (جلوگیری از enumeration)."
    ),
)
async def resend_verification(
    body: ResendVerificationRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> PasswordResetRequestResponse:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    ip = _client_ip(request)

    # Anti-enumeration: always return the same response.
    user = await get_user_by_email(db, body.email)
    if user is not None and user.email_verified_at is None:
        token, _ = await create_email_verification_token(
            db, user, EmailVerificationType.email_verification, issued_ip=ip,
        )
        try:
            await send_email_verification_email(user.email, token, user.full_name)
        except Exception as exc:
            log.error("Failed to resend verification email: %s", exc)
        await audit.record_email_verification_sent(db, user.id, ip)
        await db.commit()

    return PasswordResetRequestResponse()
