# -*- coding: utf-8 -*-
"""
auth/routers package — auth-related API routers.
"""
