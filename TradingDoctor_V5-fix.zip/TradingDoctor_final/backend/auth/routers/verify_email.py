# -*- coding: utf-8 -*-
"""
auth/routers/verify_email.py
----------------------------
Phase 8 — POST /api/v1/auth/verify-email
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from auth.exceptions import InvalidResetTokenError
from auth.models import EmailVerificationType
from auth.schemas import VerifyEmailRequest, VerifyEmailResponse
from auth.services import audit
from auth.services.email import send_welcome_email
from auth.services.users import consume_email_verification_token, verify_email
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.verify_email")

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


@router.post(
    "/verify-email",
    response_model=VerifyEmailResponse,
    summary="تأیید ایمیل کاربر",
    description=(
        "با ارائه‌ی توکن تأیید ایمیل (از لینک ارسال‌شده به ایمیل کاربر)، "
        "حساب کاربری فعال می‌شود. این توکن یک‌بار مصرف است و پس از ۲۴ ساعت "
        "منقضی می‌شود."
    ),
)
async def verify_email_endpoint(
    body: VerifyEmailRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> VerifyEmailResponse:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    ip = _client_ip(request)

    user = await consume_email_verification_token(
        db, body.token, EmailVerificationType.email_verification,
    )

    if user is None:
        await audit.record_event(
            db, __import__("auth.models", fromlist=["AuditEventType"]).AuditEventType.email_verified,
            ip_address=ip, outcome="failure", details={"reason": "invalid_token"},
        )
        await db.commit()
        raise InvalidResetTokenError(
            "توکن تأیید نامعتبر است یا منقضی شده است. لطفاً درخواست توکن جدید بدهید."
        )

    user = await verify_email(db, user.id)

    # Send welcome email (best-effort).
    try:
        await send_welcome_email(user.email, user.full_name)
    except Exception as exc:
        log.error("Failed to send welcome email: %s", exc)

    await audit.record_email_verified(db, user.id, ip)
    await db.commit()

    return VerifyEmailResponse(
        user_id=str(user.id),
        email=user.email,
        status=user.status.value,
    )
