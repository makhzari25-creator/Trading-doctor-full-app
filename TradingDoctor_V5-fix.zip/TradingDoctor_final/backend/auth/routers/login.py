# -*- coding: utf-8 -*-
"""
auth/routers/login.py
---------------------
Phase 8 — POST /api/v1/auth/login + /logout + /refresh.
"""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from auth import config as auth_config
from auth.dependencies import _extract_bearer_token  # internal reuse
from auth.exceptions import (
    AccountLockedError,
    EmailNotVerifiedError,
    InvalidCredentialsError,
)
from auth.models import UserStatus
from auth.schemas import (
    LoginRequest,
    LoginResponse,
    LogoutRequest,
    RefreshRequest,
    TokenResponse,
    UserPublic,
)
from auth.services import audit
from auth.services.tokens import (
    create_access_token,
    decode_access_token,
    issue_refresh_token,
    revoke_refresh_token,
    rotate_refresh_token,
)
from auth.services.users import (
    authenticate_user_sync,
    get_user_by_email,
    is_account_locked,
    update_login_failure,
    update_login_success,
)
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.login")

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


def _user_agent(request: Request) -> str | None:
    return request.headers.get("user-agent")


@router.post(
    "/login",
    response_model=LoginResponse,
    summary="ورود کاربر",
    description=(
        "ورود با ایمیل و رمز عبور. در صورت موفقیت، توکن دسترسی (JWT) و توکن "
        "بازنشانی (refresh token) برمی‌گردد. در صورت ۵ تلاش ناموفق متوالی، "
        "حساب کاربری به مدت ۱۵ دقیقه قفل می‌شود."
    ),
)
async def login(
    body: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> LoginResponse:
    if db is None:
        raise RuntimeError("Database is required for login but is not configured.")

    ip = _client_ip(request)
    ua = _user_agent(request)

    # Load the user (or None) by email — keep timing consistent on both paths.
    user = await get_user_by_email(db, body.email)

    # If account is locked, refuse even with correct password.
    if user is not None and await is_account_locked(db, user.id):
        await audit.record_login_failure(db, body.email, ip, ua, reason="account_locked", user_id=user.id)
        await db.commit()
        raise AccountLockedError(locked_until=user.locked_until)

    # Verify password (constant-time bcrypt check; also runs on None user
    # to prevent timing-based user enumeration).
    is_valid, valid_user, new_hash = authenticate_user_sync(user, body.password)

    if not is_valid:
        if user is not None:
            await update_login_failure(db, user.id)
            # Re-check lock — the failure may have triggered it.
            if await is_account_locked(db, user.id):
                await audit.record_login_failure(
                    db, body.email, ip, ua, reason="account_locked_after_failures",
                    user_id=user.id,
                )
                await db.commit()
                raise AccountLockedError(locked_until=user.locked_until)

        await audit.record_login_failure(
            db, body.email, ip, ua, reason="invalid_credentials",
            user_id=(user.id if user else None),
        )
        await db.commit()
        raise InvalidCredentialsError("ایمیل یا رمز عبور نادرست است.")

    # If we got here: password matched an active user.
    assert valid_user is not None
    user = valid_user

    # If email verification is required, block login until verified.
    if auth_config.REQUIRE_EMAIL_VERIFICATION and user.email_verified_at is None:
        await audit.record_login_failure(
            db, body.email, ip, ua, reason="email_not_verified", user_id=user.id,
        )
        await db.commit()
        raise EmailNotVerifiedError(
            "ایمیل شما هنوز تأیید نشده است. لطفاً صندوق ورودی خود را بررسی کنید."
        )

    # If hash cost-factor is outdated, transparently re-hash.
    if new_hash is not None:
        user.password_hash = new_hash
        log.info("Re-hashed password for user_id=%s during login", user.id)

    # Issue access + refresh tokens.
    access_token, _access_expires = create_access_token(user)
    refresh_plaintext, refresh_expires, _record = await issue_refresh_token(
        db, user, issued_ip=ip, issued_user_agent=ua,
    )

    # Record successful login + reset failure counter.
    await update_login_success(db, user.id, ip_address=ip)
    await audit.record_login_success(db, user.id, ip, ua)
    await db.commit()

    return LoginResponse(
        user=UserPublic.from_orm_user(user),
        tokens=TokenResponse(
            access_token=access_token,
            expires_in=auth_config.ACCESS_TOKEN_EXPIRE_SECONDS,
            refresh_token=refresh_plaintext,
            refresh_expires_in=auth_config.REFRESH_TOKEN_EXPIRE_SECONDS,
        ),
    )


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="صدور توکن دسترسی جدید با توکن بازنشانی",
    description=(
        "با ارائه‌ی refresh token معتبر، یک access token جدید و یک refresh "
        "token جدید (چرخش) برمی‌گردد. توکن قبلی بلافاصله باطل می‌شود. "
        "اگر توکنی که قبلاً باطل شده استفاده شود، کل خانواده‌ی توکن‌ها "
        "باطل می‌شود (تشخیص سرقت)."
    ),
)
async def refresh(
    body: RefreshRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> TokenResponse:
    if db is None:
        raise RuntimeError("Database is required for refresh but is not configured.")

    ip = _client_ip(request)
    ua = _user_agent(request)

    result = await rotate_refresh_token(
        db, body.refresh_token, new_issued_ip=ip, new_issued_user_agent=ua,
    )

    if result is None:
        await audit.record_refresh_failure(db, ip, reason="invalid_or_revoked_token")
        await db.commit()
        raise InvalidCredentialsError("توکن بازنشانی نامعتبر است.")

    user, new_refresh_plaintext, new_refresh_expires, _record = result

    access_token, _access_expires = create_access_token(user)
    await audit.record_refresh(db, user.id, ip)
    await db.commit()

    return TokenResponse(
        access_token=access_token,
        expires_in=auth_config.ACCESS_TOKEN_EXPIRE_SECONDS,
        refresh_token=new_refresh_plaintext,
        refresh_expires_in=int(
            (new_refresh_expires - datetime.now(timezone.utc)).total_seconds()
        ),
    )


@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="خروج کاربر",
    description=(
        "توکن بازنشانی ارائه‌شده را باطل می‌کند. توکن دسترسی (JWT) کوتاه‌مدت "
        "است و به‌طور طبیعی منقضی می‌شود — امکان باطل‌سازی فوری آن وجود ندارد "
        "بدون blacklist. برای خروج کامل از همه‌ی دستگاه‌ها، از مسیر "
        "/me/sessions استفاده کنید."
    ),
)
async def logout(
    request: Request,
    body: LogoutRequest,
    db: AsyncSession = Depends(get_db),
) -> None:
    if db is None:
        return  # nothing to revoke without DB

    ip = _client_ip(request)

    if body.refresh_token:
        # Phase 12 audit fix (C6): look up the user from the refresh token
        # so we can attribute the logout event + verify ownership.
        from auth.services.tokens import _hash_refresh_token
        from sqlalchemy import select as sa_select
        from auth.models import RefreshToken
        import hashlib

        token_hash = hashlib.sha256(body.refresh_token.encode("utf-8")).hexdigest()
        stmt = sa_select(RefreshToken).where(RefreshToken.token_hash == token_hash)
        result = await db.execute(stmt)
        token_record = result.scalar_one_or_none()

        revoked = await revoke_refresh_token(db, body.refresh_token, reason="logout")
        if revoked:
            log.info("Refresh token revoked via logout")
            # Now we have the user_id from the token record.
            user_id = token_record.user_id if token_record else None
            await audit.record_event(
                db,
                event_type=__import__("auth.models", fromlist=["AuditEventType"]).AuditEventType.logout,
                user_id=user_id,
                ip_address=ip, outcome="success",
            )
            await db.commit()
    # Else: caller is logging out without a refresh token (e.g. they cleared
    # it already). Nothing to do server-side; access token will expire.
