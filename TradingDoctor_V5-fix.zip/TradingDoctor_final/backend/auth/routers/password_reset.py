# -*- coding: utf-8 -*-
"""
auth/routers/password_reset.py
------------------------------
Phase 8 — POST /api/v1/auth/password-reset/request + /confirm
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from auth.exceptions import InvalidResetTokenError
from auth.models import EmailVerificationType
from auth.schemas import (
    PasswordResetConfirmRequest,
    PasswordResetConfirmResponse,
    PasswordResetRequestRequest,
    PasswordResetRequestResponse,
)
from auth.services import audit
from auth.services.email import send_password_reset_email
from auth.services.tokens import revoke_all_user_tokens
from auth.services.users import (
    consume_email_verification_token,
    create_email_verification_token,
    get_user_by_email,
    change_password,
)
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.password_reset")

router = APIRouter(prefix="/auth/password-reset", tags=["Authentication"])


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


@router.post(
    "/request",
    response_model=PasswordResetRequestResponse,
    summary="درخواست بازنشانی رمز عبور",
    description=(
        "با دریافت ایمیل، در صورت وجود حساب کاربری با آن ایمیل، لینک بازنشانی "
        "رمز عبور ارسال می‌شود. به دلایل امنیتی (جلوگیری از enumeration)، "
        "حتی اگر ایمیل موجود نباشد، همان پیام موفقیت برمی‌گردد."
    ),
)
async def password_reset_request(
    body: PasswordResetRequestRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> PasswordResetRequestResponse:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    ip = _client_ip(request)

    user = await get_user_by_email(db, body.email)

    # Anti-enumeration: always return the same response.
    if user is not None:
        token, _ = await create_email_verification_token(
            db, user, EmailVerificationType.password_reset, issued_ip=ip,
        )
        try:
            await send_password_reset_email(user.email, token, user.full_name)
        except Exception as exc:
            log.error("Failed to send password reset email to %s: %s", user.email, exc)

        await audit.record_password_reset_requested(db, body.email, ip)
        await db.commit()
    else:
        log.info("Password reset requested for non-existent email: %s", body.email)

    return PasswordResetRequestResponse()


@router.post(
    "/confirm",
    response_model=PasswordResetConfirmResponse,
    summary="تنظیم رمز عبور جدید با توکن بازنشانی",
    description=(
        "با ارائه‌ی توکن بازنشانی و رمز عبور جدید، رمز عبور کاربر تغییر "
        "می‌کند. تمام توکن‌های بازنشانی فعلی کاربر باطل می‌شوند (نیاز به "
        "ورود مجدد در همه‌ی دستگاه‌ها)."
    ),
)
async def password_reset_confirm(
    body: PasswordResetConfirmRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> PasswordResetConfirmResponse:
    if db is None:
        raise RuntimeError("Database is required but is not configured.")

    ip = _client_ip(request)

    user = await consume_email_verification_token(
        db, body.token, EmailVerificationType.password_reset,
    )

    if user is None:
        raise InvalidResetTokenError(
            "توکن بازنشانی نامعتبر است یا منقضی شده است. لطفاً درخواست جدید بدهید."
        )

    # Change password + revoke all refresh tokens.
    await change_password(db, user.id, body.new_password)
    await revoke_all_user_tokens(db, user.id, reason="password_reset")

    await audit.record_password_reset_completed(db, user.id, ip)
    await db.commit()

    return PasswordResetConfirmResponse()
