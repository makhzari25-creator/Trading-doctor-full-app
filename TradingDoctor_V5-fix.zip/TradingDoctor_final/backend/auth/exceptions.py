# -*- coding: utf-8 -*-
"""
auth/exceptions.py
------------------
Phase 8 — Exception hierarchy for the auth subsystem.

All auth errors subclass AuthError, which carries:
  - status_code (HTTP)
  - error_code  (machine-readable, e.g. "token_expired")
  - message     (user-facing Persian message)
  - details     (optional dict)

The api/main.py exception handler is extended to map AuthError → its
status_code/error_code. This preserves the unified {"error": {...}} envelope.
"""

from __future__ import annotations

from typing import Optional


class AuthError(Exception):
    """Base class for all auth-related errors.

    Attributes:
      status_code: HTTP status code to return
      error_code:  machine-readable code (used by frontend for i18n + branching)
      message:     user-facing message (Persian, since the product is Persian-first)
      details:     optional structured details (e.g. {"field": "email"})
    """
    status_code: int = 401
    error_code: str = "auth_error"

    def __init__(
        self,
        message: str = "",
        details: Optional[dict] = None,
        *,
        error_code: Optional[str] = None,
        status_code: Optional[int] = None,
    ):
        super().__init__(message)
        self.message = message or self.__class__.__name__
        self.details = details or {}
        if error_code is not None:
            self.error_code = error_code
        if status_code is not None:
            self.status_code = status_code


# ---------------------------------------------------------------------------
# Token-related (401)
# ---------------------------------------------------------------------------

class InvalidTokenError(AuthError):
    status_code = 401
    error_code = "invalid_token"


class TokenExpiredError(AuthError):
    status_code = 401
    error_code = "token_expired"


class MissingTokenError(AuthError):
    status_code = 401
    error_code = "missing_token"


# ---------------------------------------------------------------------------
# User-related (401 / 403 / 404)
# ---------------------------------------------------------------------------

class UserNotFoundError(AuthError):
    status_code = 401  # 401 not 404 — don't leak whether user exists
    error_code = "invalid_credentials"


class UserNotActiveError(AuthError):
    status_code = 403
    error_code = "account_not_active"


class AccountLockedError(AuthError):
    status_code = 423  # Locked
    error_code = "account_locked"

    def __init__(self, locked_until, **kwargs):
        details = kwargs.get("details", {}) or {}
        details["locked_until"] = locked_until.isoformat() if locked_until else None
        kwargs["details"] = details
        super().__init__(
            message="حساب کاربری به دلیل تلاش‌های ناموفق متعدد موقتاً قفل شده است.",
            **kwargs,
        )


class EmailNotVerifiedError(AuthError):
    status_code = 403
    error_code = "email_not_verified"


# ---------------------------------------------------------------------------
# Registration (409)
# ---------------------------------------------------------------------------

class EmailAlreadyRegisteredError(AuthError):
    status_code = 409
    error_code = "email_already_registered"


# ---------------------------------------------------------------------------
# Login (401)
# ---------------------------------------------------------------------------

class InvalidCredentialsError(AuthError):
    status_code = 401
    error_code = "invalid_credentials"


# ---------------------------------------------------------------------------
# Password reset (400)
# ---------------------------------------------------------------------------

class InvalidResetTokenError(AuthError):
    status_code = 400
    error_code = "invalid_reset_token"


class PasswordPolicyError(AuthError):
    status_code = 422
    error_code = "password_policy_violation"


# ---------------------------------------------------------------------------
# Authorization (403)
# ---------------------------------------------------------------------------

class InsufficientPermissionsError(AuthError):
    status_code = 403
    error_code = "insufficient_permissions"


class TierRequiredError(AuthError):
    """Raised when an endpoint requires a subscription tier the user doesn't have.

    Used in Phase 10 (billing). Stubbed here for forward compatibility.
    """
    status_code = 402  # Payment Required
    error_code = "tier_required"
