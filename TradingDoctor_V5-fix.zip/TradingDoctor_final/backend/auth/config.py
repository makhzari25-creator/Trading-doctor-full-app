# -*- coding: utf-8 -*-
"""
auth/config.py
--------------
Phase 8 — Configuration for the authentication subsystem.

All values are env-overridable. Defaults are safe for development; production
deployment must override the secrets (JWT_SECRET_KEY, JWT_REFRESH_SECRET_KEY).

Design:
  - This module reads config at import time. Tests that need to vary config
    should monkeypatch the relevant attribute (e.g. `monkeypatch.setattr(
    auth.config, "ACCESS_TOKEN_EXPIRE_SECONDS", 1)`).
  - The existing `config.py` (engine config) and `api/config.py` (API config)
    are left untouched — auth config lives separately to keep auth concerns
    isolated (security boundary).
"""

from __future__ import annotations

import os
from typing import Optional

from utils.logger import get_logger

log = get_logger("auth.config")


# ---------------------------------------------------------------------------
# Helpers (mirror the pattern from engine config.py)
# ---------------------------------------------------------------------------

def _safe_int(env_var: str, default: int) -> int:
    raw = os.getenv(env_var)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        log.warning("Invalid int for %s=%r, falling back to default %s",
                    env_var, raw, default)
        return default


def _safe_bool(env_var: str, default: bool) -> bool:
    raw = os.getenv(env_var, "").strip().lower()
    if raw in ("true", "1", "yes"):
        return True
    if raw in ("false", "0", "no"):
        return False
    return default


# ---------------------------------------------------------------------------
# JWT configuration
# ---------------------------------------------------------------------------

JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY", "")
"""Secret used to sign access tokens. MUST be set in production (≥32 chars)."""

JWT_REFRESH_SECRET_KEY: str = os.getenv("JWT_REFRESH_SECRET_KEY", "")
"""Secret used to sign refresh tokens. MUST be different from JWT_SECRET_KEY."""

JWT_ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")
"""Algorithm for JWT signing. HS256 (single secret) or RS256 (keypair)."""

JWT_ISSUER: str = os.getenv("JWT_ISSUER", "tradingdoctor")
"""Issuer claim (`iss`) — used to reject tokens minted for other apps."""

JWT_AUDIENCE: str = os.getenv("JWT_AUDIENCE", "tradingdoctor-users")
"""Audience claim (`aud`) — used to reject tokens minted for other services."""

ACCESS_TOKEN_EXPIRE_SECONDS: int = _safe_int("JWT_ACCESS_TOKEN_EXPIRE_SECONDS", 900)
"""Access token TTL. Default 15 minutes (900s) — OWASP recommendation."""

REFRESH_TOKEN_EXPIRE_SECONDS: int = _safe_int("JWT_REFRESH_TOKEN_EXPIRE_SECONDS", 2592000)
"""Refresh token TTL. Default 30 days (2592000s)."""

# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------

PASSWORD_HASH_ROUNDS: int = _safe_int("PASSWORD_HASH_ROUNDS", 12)
"""bcrypt rounds. 12 is OWASP 2024 minimum. Higher = slower but more secure."""

# ---------------------------------------------------------------------------
# Brute-force protection
# ---------------------------------------------------------------------------

MAX_FAILED_LOGIN_ATTEMPTS: int = _safe_int("TRADING_DOCTOR_MAX_FAILED_LOGINS", 5)
"""After this many failed logins, the account is locked temporarily."""

ACCOUNT_LOCKOUT_MINUTES: int = _safe_int("TRADING_DOCTOR_LOCKOUT_MINUTES", 15)
"""How long the account stays locked after MAX_FAILED_LOGIN_ATTEMPTS failures."""

# ---------------------------------------------------------------------------
# Email verification
# ---------------------------------------------------------------------------

EMAIL_VERIFICATION_TOKEN_EXPIRE_HOURS: int = _safe_int(
    "TRADING_DOCTOR_EMAIL_VERIFY_HOURS", 24
)
"""How long an email verification link is valid. Default 24 hours."""

PASSWORD_RESET_TOKEN_EXPIRE_MINUTES: int = _safe_int(
    "TRADING_DOCTOR_PASSWORD_RESET_MINUTES", 15
)
"""How long a password reset link is valid. Default 15 minutes (tight for security)."""

REQUIRE_EMAIL_VERIFICATION: bool = _safe_bool(
    "TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY", True
)
"""If True, users cannot log in until their email is verified.
   Set to False for development or internal deployments."""

# ---------------------------------------------------------------------------
# Cookie settings (for refresh token, if using cookie-based storage)
# ---------------------------------------------------------------------------

COOKIE_SECURE: bool = _safe_bool("COOKIE_SECURE", True)
"""Set to True in production (requires HTTPS)."""

COOKIE_SAMESITE: str = os.getenv("COOKIE_SAMESITE", "lax")
"""'lax' (default, recommended) | 'strict' | 'none' (requires SECURE=True)."""

COOKIE_DOMAIN: Optional[str] = os.getenv("COOKIE_DOMAIN") or None
"""Optional cookie domain. Set to '.yourdomain.com' for cross-subdomain cookies."""

REFRESH_TOKEN_COOKIE_NAME: str = "td_refresh_token"
"""Name of the cookie used to store the refresh token (if cookie mode)."""

# ---------------------------------------------------------------------------
# Token request sources (which header/field to read from the request)
# ---------------------------------------------------------------------------

ACCESS_TOKEN_HEADER: str = "Authorization"
"""The HTTP header that carries the access token. Standard: 'Authorization'."""

ACCESS_TOKEN_PREFIX: str = "Bearer"
"""The prefix before the token in the header. Standard: 'Bearer <token>'."""

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_auth_config() -> list[str]:
    """Return a list of configuration problems. Empty list = OK.

    Called at app startup (api/main.py) to fail fast on misconfiguration.
    """
    problems: list[str] = []

    if not JWT_SECRET_KEY or len(JWT_SECRET_KEY) < 32:
        problems.append(
            "JWT_SECRET_KEY is missing or shorter than 32 characters. "
            "Generate with: openssl rand -hex 32"
        )

    if not JWT_REFRESH_SECRET_KEY or len(JWT_REFRESH_SECRET_KEY) < 32:
        problems.append(
            "JWT_REFRESH_SECRET_KEY is missing or shorter than 32 characters. "
            "Must be different from JWT_SECRET_KEY."
        )

    if JWT_SECRET_KEY and JWT_REFRESH_SECRET_KEY and \
       JWT_SECRET_KEY == JWT_REFRESH_SECRET_KEY:
        problems.append(
            "JWT_SECRET_KEY and JWT_REFRESH_SECRET_KEY must be different."
        )

    if JWT_ALGORITHM not in ("HS256", "HS384", "HS512", "RS256", "RS384", "RS512"):
        problems.append(f"JWT_ALGORITHM={JWT_ALGORITHM!r} is not a supported algorithm.")

    if PASSWORD_HASH_ROUNDS < 10:
        problems.append(
            f"PASSWORD_HASH_ROUNDS={PASSWORD_HASH_ROUNDS} is below the OWASP "
            "minimum of 10. Use 12 or higher in production."
        )

    if ACCESS_TOKEN_EXPIRE_SECONDS > 3600:
        problems.append(
            f"ACCESS_TOKEN_EXPIRE_SECONDS={ACCESS_TOKEN_EXPIRE_SECONDS} is "
            "longer than 1 hour. OWASP recommends 15 minutes."
        )

    return problems


# ---------------------------------------------------------------------------
# Email regex (used by both Pydantic validators and the auth service)
# ---------------------------------------------------------------------------

# Simple but RFC-ish: matches the vast majority of real-world addresses.
# Rejects addresses with spaces, missing @, missing TLD, etc.
# Not 100% RFC 5322 compliant (that regex is ~6000 chars); pragmatic tradeoff.
EMAIL_REGEX = r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"

# Password policy: at least 8 chars, at least one letter and one digit.
# Deliberately NOT enforcing special chars or mixed case — research shows
# these rules reduce security (users pick weaker but compliant passwords).
# Users can use any password that passes this check, including passphrases.
PASSWORD_MIN_LENGTH: int = _safe_int("TRADING_DOCTOR_PASSWORD_MIN_LENGTH", 8)
PASSWORD_MAX_LENGTH: int = 128  # bcrypt truncates at 72 bytes anyway
