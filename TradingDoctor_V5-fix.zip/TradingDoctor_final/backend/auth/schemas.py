# -*- coding: utf-8 -*-
"""
auth/schemas.py
---------------
Phase 8 — Pydantic schemas for auth request/response bodies.

All schemas inherit from a common base that forbids extra fields (defensive:
callers cannot smuggle in `is_admin=true` etc.).
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from auth import config as auth_config


class _StrictBase(BaseModel):
    """Base config: forbid extra fields, validate on assignment."""
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

class RegisterRequest(_StrictBase):
    email: EmailStr = Field(..., description="ایمیل کاربر — باید معتبر باشد.")
    password: str = Field(..., min_length=8, max_length=128,
                          description="رمز عبور — حداقل ۸ کاراکتر، شامل حرف و عدد.")
    full_name: Optional[str] = Field(None, max_length=255)
    locale: Optional[str] = Field(None, max_length=10)
    marketing_consent: bool = False

    @field_validator("password")
    @classmethod
    def _validate_password_policy(cls, v: str) -> str:
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy(v)
        if not ok:
            raise ValueError(msg)
        return v


class RegisterResponse(_StrictBase):
    user_id: str
    email: str
    status: str
    message: str = "حساب کاربری ایجاد شد. لطفاً ایمیل خود را تأیید کنید."


# ---------------------------------------------------------------------------
# Email verification
# ---------------------------------------------------------------------------

class VerifyEmailRequest(_StrictBase):
    token: str = Field(..., min_length=64, max_length=64)


class VerifyEmailResponse(_StrictBase):
    user_id: str
    email: str
    status: str
    message: str = "ایمیل شما تأیید شد. می‌توانید وارد شوید."


class ResendVerificationRequest(_StrictBase):
    email: EmailStr


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

class LoginRequest(_StrictBase):
    email: EmailStr
    password: str = Field(..., min_length=1)


class TokenResponse(_StrictBase):
    """Returned by /login and /refresh."""
    access_token: str
    token_type: str = "Bearer"
    expires_in: int  # seconds until access_token expires
    refresh_token: str  # opaque, also returned here for non-cookie flows
    refresh_expires_in: int  # seconds until refresh_token expires


class LoginResponse(_StrictBase):
    user: "UserPublic"
    tokens: TokenResponse


# ---------------------------------------------------------------------------
# Refresh
# ---------------------------------------------------------------------------

class RefreshRequest(_StrictBase):
    """Body schema for /refresh when using non-cookie flow."""
    refresh_token: str = Field(..., min_length=64, max_length=64)


# ---------------------------------------------------------------------------
# Logout
# ---------------------------------------------------------------------------

class LogoutRequest(_StrictBase):
    refresh_token: Optional[str] = Field(None, min_length=64, max_length=64)


# ---------------------------------------------------------------------------
# Password reset
# ---------------------------------------------------------------------------

class PasswordResetRequestRequest(_StrictBase):
    """Body for /password-reset/request — 'I forgot my password'."""
    email: EmailStr


class PasswordResetConfirmRequest(_StrictBase):
    """Body for /password-reset/confirm — 'set new password with this token'."""
    token: str = Field(..., min_length=64, max_length=64)
    new_password: str = Field(..., min_length=8, max_length=128)

    @field_validator("new_password")
    @classmethod
    def _validate_password_policy(cls, v: str) -> str:
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy(v)
        if not ok:
            raise ValueError(msg)
        return v


class PasswordResetRequestResponse(_StrictBase):
    """Always returns the same message regardless of whether the email exists.

    This is a security measure to prevent email enumeration via this endpoint.
    """
    message: str = "اگر ایمیل در سیستم موجود باشد، لینک بازنشانی ارسال شده است."


class PasswordResetConfirmResponse(_StrictBase):
    message: str = "رمز عبور با موفقیت تغییر کرد. می‌توانید وارد شوید."


# ---------------------------------------------------------------------------
# Change password (authenticated)
# ---------------------------------------------------------------------------

class ChangePasswordRequest(_StrictBase):
    """Body for /me/password — change password while logged in."""
    current_password: str = Field(..., min_length=1)
    new_password: str = Field(..., min_length=8, max_length=128)

    @field_validator("new_password")
    @classmethod
    def _validate_password_policy(cls, v: str) -> str:
        from auth.services.passwords import password_meets_policy
        ok, msg = password_meets_policy(v)
        if not ok:
            raise ValueError(msg)
        return v


# ---------------------------------------------------------------------------
# User profile
# ---------------------------------------------------------------------------

class UserPublic(_StrictBase):
    """Public-safe user representation (no password_hash)."""
    id: str
    email: str
    full_name: Optional[str] = None
    status: str
    email_verified_at: Optional[datetime] = None
    last_login_at: Optional[datetime] = None
    locale: Optional[str] = None
    created_at: datetime

    @classmethod
    def from_orm_user(cls, user) -> "UserPublic":
        return cls(
            id=str(user.id),
            email=user.email,
            full_name=user.full_name,
            status=user.status.value if hasattr(user.status, "value") else str(user.status),
            email_verified_at=user.email_verified_at,
            last_login_at=user.last_login_at,
            locale=user.locale,
            created_at=user.created_at,
        )


class UserProfileResponse(_StrictBase):
    user: UserPublic


class UpdateProfileRequest(_StrictBase):
    full_name: Optional[str] = Field(None, max_length=255)
    locale: Optional[str] = Field(None, max_length=10)


# ---------------------------------------------------------------------------
# Resolve forward references
# ---------------------------------------------------------------------------

LoginResponse.model_rebuild()
