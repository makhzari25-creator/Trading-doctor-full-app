# -*- coding: utf-8 -*-
"""
auth
----
Phase 8 — Authentication & User Management for TradingDoctor SaaS.

Public API:
  - Routers:      auth.routers.register, auth.routers.login, auth.routers.refresh,
                  auth.routers.logout, auth.routers.verify_email, auth.routers.password_reset
  - Services:     auth.services.passwords, auth.services.tokens, auth.services.users,
                  auth.services.email, auth.services.audit
  - Dependencies: auth.dependencies.get_current_user, auth.dependencies.get_current_user_optional
  - Models:       auth.models.User, auth.models.RefreshToken, auth.models.AuditLog

Design rules (carry forward from Phase 7.5):
  - Frozen V23 engine (engines/*) is never imported by anything in auth/.
  - All DB I/O is async (asyncpg + SQLAlchemy 2.0 async).
  - Passwords hashed with bcrypt (rounds from PASSWORD_HASH_ROUNDS, default 12).
  - JWT access tokens (HS256 or RS256) with short TTL (15 min default).
  - Refresh tokens stored as SHA-256 hashes in DB (never plaintext).
  - All auth events recorded in audit_log table.
  - Email service is pluggable (console / smtp / ses / sendgrid).
  - Existing API-key auth (`verify_api_key`) is preserved for service-to-service;
    per-user JWT auth (`get_current_user`) is layered on top for user-facing endpoints.
"""

from auth.dependencies import (
    get_current_user,
    get_current_user_optional,
    get_authenticated_user,  # alias
)

__all__ = [
    "get_current_user",
    "get_current_user_optional",
    "get_authenticated_user",
]
