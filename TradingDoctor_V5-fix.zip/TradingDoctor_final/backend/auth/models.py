# -*- coding: utf-8 -*-
"""
auth/models.py
--------------
Phase 8 — ORM models for the authentication subsystem.

Tables added:
  - users           (the central account record)
  - refresh_tokens  (rotating refresh tokens, hashed at rest)
  - audit_logs      (every auth-related event: register, login, logout, etc.)
  - email_verifications  (one-time tokens for email verification + password reset)

Design:
  - UUID primary keys (UUIDPkMixin from db.models)
  - Timestamps with timezone (TimestampMixin)
  - Soft-delete on users (deletion is reversible for 30 days)
  - Email + username uniqueness enforced at DB level (partial index on
    non-deleted users only — allows re-registration after deletion)
  - Refresh tokens stored as SHA-256 hash, NOT plaintext. A stolen DB
    dump cannot be used to mint new access tokens.
  - All tokens have absolute expiry (separate from revocation).
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.base import Base
from db.models import TimestampMixin, UUIDPkMixin, SoftDeleteMixin


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class UserStatus(str, enum.Enum):
    """Lifecycle states for a user account."""
    pending = "pending"        # registered, email not yet verified
    active = "active"          # email verified, can log in
    suspended = "suspended"    # admin-disabled (e.g. abuse, billing failure)
    deleted = "deleted"        # soft-deleted, will be purged after retention


class AuditEventType(str, enum.Enum):
    """Events recorded in the audit_log table."""
    register = "register"
    login = "login"
    login_failed = "login_failed"
    logout = "logout"
    refresh = "refresh"
    refresh_failed = "refresh_failed"
    email_verification_sent = "email_verification_sent"
    email_verified = "email_verified"
    password_reset_requested = "password_reset_requested"
    password_reset_completed = "password_reset_completed"
    password_changed = "password_changed"
    account_suspended = "account_suspended"
    account_reactivated = "account_reactivated"
    account_deleted = "account_deleted"


class EmailVerificationType(str, enum.Enum):
    """Purpose of an email verification token."""
    email_verification = "email_verification"
    password_reset = "password_reset"


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------

class User(UUIDPkMixin, TimestampMixin, SoftDeleteMixin, Base):
    """Central user account record.

    Passwords are stored as bcrypt hashes in `password_hash`. The plaintext
    password is NEVER stored or logged.

    Email uniqueness is enforced via a partial index that excludes soft-deleted
    users — this allows a user to delete their account and another user to
    later register with the same email.
    """

    __tablename__ = "users"

    email: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        index=True,
        # Case-insensitive comparison happens at the application layer; we store
        # email lowercased in the service to ensure uniqueness matches.
    )

    # Optional display name; can be empty until the user sets one in onboarding.
    full_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # bcrypt hash, format: $2b$12$... (60 chars total)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)

    status: Mapped[UserStatus] = mapped_column(
        Enum(UserStatus, name="user_status", values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=UserStatus.pending,
        server_default=UserStatus.pending.value,
        index=True,
    )

    # When email was verified (None until verification completes).
    email_verified_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Failed login attempts (for brute-force protection; reset on successful login).
    failed_login_attempts: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    # Account lockout timestamp — when set, login is refused until this time.
    locked_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Last login timestamp (for activity tracking + "logged in from X" emails).
    last_login_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Last login IP (security audit; allows user to see "recent logins").
    last_login_ip: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)

    # Optional: user-supplied locale preference ("fa", "en", etc.)
    locale: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)

    # Optional: accepts marketing emails
    marketing_consent: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )

    # Relationships (lazy-loaded via selectinlead in service layer)
    refresh_tokens: Mapped[list["RefreshToken"]] = relationship(
        "RefreshToken",
        back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        # Unique email among non-deleted users only.
        # Allows re-registration after soft-delete with the same email.
        Index(
            "uq_users_email_active",
            "email",
            unique=True,
            postgresql_where="deleted_at IS NULL",
        ),
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} email={self.email!r} status={self.status.value}>"


# ---------------------------------------------------------------------------
# RefreshToken
# ---------------------------------------------------------------------------

class RefreshToken(UUIDPkMixin, TimestampMixin, Base):
    """A rotating refresh token.

    Security:
      - `token_hash` is SHA-256 of the plaintext token, NOT the token itself.
        A DB dump cannot be used to mint access tokens.
      - The plaintext token is returned to the client exactly once at login
        and never stored server-side.
      - On refresh, the old token is revoked (revoked_at set) and a new one
        issued. This is "refresh token rotation."
      - `replaced_by_id` creates an audit chain — if a stolen token is used
        after the legitimate user has refreshed, we can detect reuse and
        revoke the entire chain.
    """

    __tablename__ = "refresh_tokens"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # SHA-256 hex digest (64 chars)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)

    # When this token expires (absolute lifetime, regardless of use).
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )

    # When this token was revoked (logout, refresh rotation, or admin action).
    revoked_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    # Reason for revocation (for audit trail)
    revoked_reason: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Chain link: when this token is rotated, the replacement token's ID is stored here.
    replaced_by_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("refresh_tokens.id", ondelete="SET NULL"),
        nullable=True,
    )

    # IP + user agent at issuance — for "logged in from X" detection.
    issued_ip: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    issued_user_agent: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="refresh_tokens")
    replaced_by: Mapped[Optional["RefreshToken"]] = relationship(
        "RefreshToken",
        remote_side="RefreshToken.id",
        foreign_keys=[replaced_by_id],
    )

    __table_args__ = (
        Index("ix_refresh_tokens_user_active", "user_id", "revoked_at"),
    )

    def __repr__(self) -> str:
        return f"<RefreshToken id={self.id} user_id={self.user_id} revoked={self.revoked_at is not None}>"


# ---------------------------------------------------------------------------
# AuditLog
# ---------------------------------------------------------------------------

class AuditLog(UUIDPkMixin, TimestampMixin, Base):
    """Immutable record of every authentication-related event.

    Used for:
      - Security audits (who logged in when, from where)
      - Brute-force detection (count failed logins per IP)
      - Compliance (GDPR: "we know what we know about you")
      - User-visible activity log ("recent activity on your account")

    Records are append-only. Updates are forbidden at the application layer.
    """

    __tablename__ = "audit_logs"

    # The user the event is about. Nullable for events that happen before
    # a user is identified (e.g. failed login with wrong email).
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    event_type: Mapped[AuditEventType] = mapped_column(
        Enum(AuditEventType, name="audit_event_type",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        index=True,
    )

    # IP address of the actor (request.remote_addr). Stored as string to
    # support both IPv4 and IPv6 without separate columns.
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True, index=True)

    # User-Agent header (truncated to 512 chars)
    user_agent: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # Optional structured details (JSON-encoded string). Examples:
    #   {"provider": "gemini", "outcome": "success"}
    #   {"reason": "invalid_password"}
    #   {"new_email": "user@example.com"}
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Outcome: "success" | "failure" | "info"
    outcome: Mapped[str] = mapped_column(String(20), nullable=False, default="info")

    def __repr__(self) -> str:
        return f"<AuditLog id={self.id} event={self.event_type.value} user_id={self.user_id}>"


# ---------------------------------------------------------------------------
# EmailVerification
# ---------------------------------------------------------------------------

class EmailVerification(UUIDPkMixin, TimestampMixin, Base):
    """One-time tokens for email verification and password reset.

    Two purposes (EmailVerificationType):
      - email_verification: confirms the user owns the email at registration
      - password_reset: allows the user to set a new password without being logged in

    Security:
      - `token_hash` is SHA-256 of the plaintext token (same pattern as refresh tokens)
      - Tokens are single-use (consumed_at set on first use)
      - Tokens have absolute expiry (15 min for password reset, 24 hours for email verification)
      - On consumption, all OTHER tokens of the same type for the same user are
        revoked (prevents accumulation of valid tokens).
    """

    __tablename__ = "email_verifications"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    verification_type: Mapped[EmailVerificationType] = mapped_column(
        Enum(EmailVerificationType, name="email_verification_type",
             values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        index=True,
    )

    # SHA-256 hex digest (64 chars)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)

    # The email address this token was sent to (in case the user has since
    # changed their email, we can detect mismatched tokens).
    sent_to_email: Mapped[str] = mapped_column(String(255), nullable=False)

    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )

    consumed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    issued_ip: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)

    __table_args__ = (
        Index("ix_email_verifications_user_type_active", "user_id", "verification_type", "consumed_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<EmailVerification id={self.id} type={self.verification_type.value} "
            f"user_id={self.user_id} consumed={self.consumed_at is not None}>"
        )
