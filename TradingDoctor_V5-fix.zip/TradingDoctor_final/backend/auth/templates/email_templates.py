# -*- coding: utf-8 -*-
"""
auth/templates/email_templates.py
---------------------------------
Phase 8 — HTML email templates for auth flows.

All templates are bilingual-aware: Persian RTL is the primary language,
with key CTAs in English where appropriate (token URLs, button text).

Templates are pure functions (no Jinja2 dependency for emails) to keep the
email subsystem lightweight. For complex future templates, switch to Jinja2.
"""

from __future__ import annotations

from html import escape


def _base_template(content_html: str, preheader: str = "") -> str:
    """Return a complete HTML email with shared shell.

    Uses inline CSS (email clients strip <style> tags).
    RTL is set on the <html> and <body> tags for Persian text.
    """
    return f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="color-scheme" content="light only">
  <meta name="supported-color-schemes" content="light only">
  <title>Trading Doctor</title>
  <!-- Preheader: shown in email preview, hidden in body -->
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">
    {escape(preheader)}
  </div>
</head>
<body style="margin:0;padding:0;background:#f5f5f7;font-family:Vazirmatn,Tahoma,Arial,sans-serif;color:#1d1d1f;font-size:15px;line-height:1.6;">

  <!-- Logo / Header -->
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0b1220;padding:20px 0;">
    <tr>
      <td align="center">
        <span style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:0.5px;">
          Trading Doctor
        </span>
      </td>
    </tr>
  </table>

  <!-- Body -->
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;padding:40px;box-shadow:0 2px 8px rgba(0,0,0,0.04);max-width:600px;width:100%;">

          {content_html}

        </table>
      </td>
    </tr>
  </table>

  <!-- Footer -->
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 16px;">
    <tr>
      <td align="center" style="color:#6e6e73;font-size:13px;">
        <p style="margin:0 0 8px 0;">این ایمیل توسط Trading Doctor ارسال شده است.</p>
        <p style="margin:0;">اگر این کار را شما انجام نداده‌اید، این پیام را نادیده بگیرید.</p>
        <p style="margin:12px 0 0 0;color:#a1a1a6;">© 2026 Trading Doctor. All rights reserved.</p>
      </td>
    </tr>
  </table>

</body>
</html>"""


def render_email_verification(user_name: str, verification_url: str) -> str:
    """Render the email verification email body."""
    content = f"""
    <h1 style="margin:0 0 24px 0;font-size:24px;color:#0b1220;">تأیید ایمیل</h1>

    <p style="margin:0 0 16px 0;">{escape(user_name)} عزیز،</p>

    <p style="margin:0 0 24px 0;">
      برای تکمیل ثبت‌نام و فعال‌سازی حساب کاربری خود، لطفاً روی دکمه‌ی زیر کلیک کنید
      یا لینک را در مرورگر خود کپی کنید:
    </p>

    <p style="margin:24px 0;text-align:center;">
      <a href="{escape(verification_url)}"
         style="display:inline-block;padding:14px 32px;background:#0066cc;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:600;font-size:16px;">
        تأیید ایمیل
      </a>
    </p>

    <p style="margin:24px 0 0 0;font-size:13px;color:#6e6e73;word-break:break-all;">
      اگر دکمه کار نمی‌کند، این لینک را در مرورگر کپی کنید:<br>
      <span style="direction:ltr;display:inline-block;">{escape(verification_url)}</span>
    </p>

    <p style="margin:32px 0 0 0;font-size:13px;color:#6e6e73;">
      این لینک تا ۲۴ ساعت معتبر است. پس از آن باید درخواست لینک جدید بدهید.
    </p>

    <hr style="margin:32px 0;border:none;border-top:1px solid #e5e5e7;">

    <p style="margin:0;font-size:13px;color:#6e6e73;">
      اگر شما ثبت‌نام نکرده‌اید، این ایمیل را نادیده بگیرید. هیچ اقدام دیگری لازم نیست.
    </p>
    """
    return _base_template(content, preheader="لطفاً ایمیل خود را تأیید کنید")


def render_password_reset(user_name: str, reset_url: str) -> str:
    """Render the password reset email body."""
    content = f"""
    <h1 style="margin:0 0 24px 0;font-size:24px;color:#0b1220;">بازنشانی رمز عبور</h1>

    <p style="margin:0 0 16px 0;">{escape(user_name)} عزیز،</p>

    <p style="margin:0 0 24px 0;">
      درخواست بازنشانی رمز عبور برای حساب کاربری شما دریافت شد. برای تنظیم رمز عبور جدید،
      روی دکمه‌ی زیر کلیک کنید:
    </p>

    <p style="margin:24px 0;text-align:center;">
      <a href="{escape(reset_url)}"
         style="display:inline-block;padding:14px 32px;background:#e5484d;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:600;font-size:16px;">
        بازنشانی رمز عبور
      </a>
    </p>

    <p style="margin:24px 0 0 0;font-size:13px;color:#6e6e73;word-break:break-all;">
      اگر دکمه کار نمی‌کند، این لینک را در مرورگر کپی کنید:<br>
      <span style="direction:ltr;display:inline-block;">{escape(reset_url)}</span>
    </p>

    <p style="margin:32px 0 0 0;font-size:13px;color:#6e6e73;">
      این لینک تا ۱۵ دقیقه معتبر است. پس از آن باید درخواست لینک جدید بدهید.
    </p>

    <hr style="margin:32px 0;border:none;border-top:1px solid #e5e5e7;">

    <p style="margin:0;font-size:13px;color:#6e6e73;">
      اگر شما درخواست بازنشانی رمز عبور نکرده‌اید، این ایمیل را نادیده بگیرید.
      رمز عبور شما بدون کلیک روی لینک بالا تغییر نخواهد کرد.
    </p>
    """
    return _base_template(content, preheader="درخواست بازنشانی رمز عبور")


def render_welcome(user_name: str) -> str:
    """Render the post-verification welcome email body."""
    content = f"""
    <h1 style="margin:0 0 24px 0;font-size:24px;color:#0b1220;">خوش آمدید! 🎉</h1>

    <p style="margin:0 0 16px 0;">{escape(user_name)} عزیز،</p>

    <p style="margin:0 0 24px 0;">
      حساب کاربری شما با موفقیت فعال شد. از این پس می‌توانید وارد شوید و اولین
      تحلیل رفتار معاملاتی خود را شروع کنید.
    </p>

    <p style="margin:24px 0;text-align:center;">
      <a href="#" style="display:inline-block;padding:14px 32px;background:#00a67d;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:600;font-size:16px;">
        شروع اولین تحلیل
      </a>
    </p>

    <h2 style="margin:32px 0 12px 0;font-size:18px;color:#0b1220;">گام‌های بعدی:</h2>

    <ul style="margin:0 0 24px 0;padding-right:24px;color:#1d1d1f;">
      <li style="margin:0 0 8px 0;">فایل لاگ معاملات خود را آپلود کنید (MT4، MT5، Binance و ...)</li>
      <li style="margin:0 0 8px 0;">منتظر بمانید تا موتور تحلیلی تحلیل را کامل کند</li>
      <li style="margin:0 0 8px 0;">گزارش کامل HTML یا PDF را دانلود کنید</li>
      <li style="margin:0 0 8px 0;">اگر سؤالی دارید، از مربی هوش مصنوعی بپرسید</li>
    </ul>

    <hr style="margin:32px 0;border:none;border-top:1px solid #e5e5e7;">

    <p style="margin:0;font-size:13px;color:#6e6e73;">
      اگر سؤالی دارید، به
      <a href="mailto:support@tradingdoctor.local" style="color:#0066cc;">support@tradingdoctor.local</a>
      ایمیل بزنید.
    </p>
    """
    return _base_template(content, preheader="حساب شما فعال شد — شروع کنید")
