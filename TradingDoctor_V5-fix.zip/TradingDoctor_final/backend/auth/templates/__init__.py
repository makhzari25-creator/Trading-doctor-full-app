# -*- coding: utf-8 -*-
"""
auth/templates package — HTML email templates for auth flows.
"""
