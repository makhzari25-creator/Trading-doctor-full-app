# -*- coding: utf-8 -*-
"""
auth/dependencies.py
--------------------
Phase 8 — FastAPI dependencies for authenticated routes.

Two main dependencies:
  - get_current_user:           requires a valid access token, raises 401 if missing/invalid
  - get_current_user_optional:  returns User or None (for endpoints that behave
                                differently for anonymous vs. authenticated users)

How they work:
  1. Extract the access token from the Authorization header ("Bearer <token>").
  2. Decode the JWT (verifies signature, expiry, issuer, audience).
  3. Load the user from DB by the `sub` claim.
  4. Verify the user is still active (status=active, not soft-deleted).
  5. Return the User.

If any step fails, raises 401 with the unified error envelope.

The existing `api.dependencies.verify_api_key` is preserved for
service-to-service auth (e.g. internal cron jobs, Stripe webhook caller
via shared secret). Per-user JWT auth is layered on top for user-facing endpoints.
"""

from __future__ import annotations

import uuid
from typing import Optional

import jwt
from fastapi import Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from auth import config as auth_config
from auth.exceptions import (
    AuthError,
    InvalidTokenError,
    TokenExpiredError,
    UserNotFoundError,
    UserNotActiveError,
)
from auth.models import User, UserStatus
from auth.services.tokens import decode_access_token
from db.base import get_db
from utils.logger import get_logger

log = get_logger("auth.dependencies")


# ---------------------------------------------------------------------------
# Token extraction
# ---------------------------------------------------------------------------

def _extract_bearer_token(authorization: Optional[str]) -> str:
    """Extract the token from an `Authorization: Bearer <token>` header.

    Returns the token string, or raises InvalidTokenError.
    """
    if not authorization:
        raise InvalidTokenError("Authorization header is missing.")

    parts = authorization.split(" ", 1)
    if len(parts) != 2:
        raise InvalidTokenError("Authorization header is malformed.")

    scheme, token = parts
    if scheme.lower() != auth_config.ACCESS_TOKEN_PREFIX.lower():
        raise InvalidTokenError(
            f"Authorization scheme must be {auth_config.ACCESS_TOKEN_PREFIX!r}."
        )

    token = token.strip()
    if not token:
        raise InvalidTokenError("Authorization token is empty.")
    return token


# ---------------------------------------------------------------------------
# User loading
# ---------------------------------------------------------------------------

async def _load_user_from_token(
    db: AsyncSession,
    token: str,
) -> User:
    """Decode token, load user, verify status. Raises AuthError subclass on failure."""
    try:
        claims = decode_access_token(token)
    except jwt.ExpiredSignatureError:
        raise TokenExpiredError("Access token has expired.")
    except jwt.InvalidTokenError as exc:
        raise InvalidTokenError(f"Invalid access token: {exc}")

    # Extract user_id from sub claim.
    sub = claims.get("sub")
    if not sub:
        raise InvalidTokenError("Token is missing the 'sub' claim.")

    try:
        user_id = uuid.UUID(sub)
    except (ValueError, AttributeError):
        raise InvalidTokenError("Token 'sub' claim is not a valid UUID.")

    # Load user from DB.
    from auth.services.users import get_user_by_id
    user = await get_user_by_id(db, user_id)
    if user is None:
        raise UserNotFoundError("User no longer exists.")

    if user.deleted_at is not None:
        raise UserNotFoundError("User account has been deleted.")

    if user.status != UserStatus.active:
        raise UserNotActiveError(
            f"Account is not active (status={user.status.value})."
        )

    return user


# ---------------------------------------------------------------------------
# Public dependencies
# ---------------------------------------------------------------------------

async def get_current_user(
    request: Request,
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Require a valid access token. Raises 401 (AuthError) on failure.

    Usage:
        @router.get("/me")
        async def get_me(user: User = Depends(get_current_user)):
            return UserPublic.from_orm_user(user)
    """
    if db is None:
        # DB not configured — auth requires DB.
        log.error("Auth dependency called but DB is not configured.")
        raise AuthError("Authentication is unavailable (database not configured).")

    token = _extract_bearer_token(authorization)
    user = await _load_user_from_token(db, token)

    # Attach user_id to request state for downstream use (logging, audit).
    request.state.user_id = user.id
    request.state.user_email = user.email

    return user


async def get_current_user_optional(
    request: Request,
    authorization: Optional[str] = Header(None),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    """Like get_current_user but returns None instead of raising 401.

    Useful for endpoints that show different data for anonymous vs.
    authenticated users (e.g. /config shows auth_enabled for anonymous,
    full plan info for authenticated).
    """
    if db is None or not authorization:
        return None
    try:
        token = _extract_bearer_token(authorization)
        return await _load_user_from_token(db, token)
    except AuthError:
        return None


# Alias for clarity at call sites
get_authenticated_user = get_current_user
