# -*- coding: utf-8 -*-
"""
api/routers/analyses.py
---------------------------
POST /api/v1/analyses          — اجرای تحلیل روی یک آپلود (Phase 9: user-scoped)
GET  /api/v1/analyses/{id}      — خلاصه‌ی تحلیل (Phase 9: user-scoped)
GET  /api/v1/analyses/{id}/report — گزارش کامل ساختاریافته (JSON) (Phase 9: user-scoped)
GET  /api/v1/analyses/jobs/{job_id} — status of async analysis job (Phase 11)

[Phase 9] تمام مسیرها حالا به user احراز هویت‌شده محدود شده‌اند. تحلیل فقط
روی آپلودهای متعلق به همان کاربر قابل اجراست. خروجی موتور در DB ذخیره
می‌شود (نه حافظه) و با repository pattern بازیابی می‌شود.

[Phase 10] بررسی محدودیت ماهانه‌ی تحلیل بر اساس طرح کاربر قبل از اجرای موتور
+ ثبت رویداد مصرف پس از اجرای موفق.

[Phase 11] اگر TRADING_DOCTOR_USE_CELERY=true باشد، POST /analyses به‌صورت async
اجرا می‌شود: یک AnalysisJob row ساخته می‌شود + یک Celery task دیسپچ می‌شود
و فوراً 202 + job_id برمی‌گرداند. کلاینت با GET /analyses/jobs/{job_id} وضعیت
را poll می‌کند تا completed شود. در غیر این صورت، همان مسیر sync قبلی اجرا می‌شود.

[Async] اجرای تحلیل CPU-bound است (pandas/numpy)، نه I/O-bound؛
async def مستقیم آن را روی event loop مسدود می‌کرد. اینجا با
run_in_threadpool واقعاً event loop آزاد می‌ماند.
"""

import os
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from api.dependencies import enforce_rate_limit, verify_api_key
from api.exceptions import NotFoundError
from api.models.analysis import AnalysisReport, AnalysisRequest, AnalysisSummary, TradesResponse
from auth.dependencies import get_current_user
from auth.exceptions import AuthError, TierRequiredError
from auth.models import User
from billing.dependencies import get_user_plan
from billing.models import Plan
from billing.services.usage import (
    check_analysis_allowed,
    check_llm_call_allowed,
    record_analysis_run,
)
from db.base import get_db
from reporting.chart_data import build_chart_series, extract_trades_list
from reporting.data_context import build_report_context
from utils.logger import get_logger
from workspace.models import AnalysisJob
from workspace.repositories.analyses import (
    get_analysis_by_id,
    get_engine_outputs,
    run_and_persist_analysis,
)

log = get_logger("api.routers.analyses")

router = APIRouter(
    tags=["Analyses"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


def _use_celery() -> bool:
    """Whether to dispatch analysis runs to Celery (async) vs run sync."""
    return os.getenv("TRADING_DOCTOR_USE_CELERY", "false").strip().lower() in ("true", "1", "yes")


def _require_db(db):
    if db is None:
        raise AuthError("Database is required but is not configured.")


def _to_summary(analysis) -> AnalysisSummary:
    """Build the summary response from the cached analysis row."""
    return AnalysisSummary(
        analysis_id=str(analysis.id),
        upload_id=str(analysis.upload_id),
        filename=analysis.filename,
        created_at=analysis.created_at,
        total_trades=analysis.total_trades,
        overall_score=float(analysis.overall_score),
        primary_diagnosis=analysis.primary_diagnosis or "N/A",
        data_quality_warning_count=analysis.data_quality_warning_count,
    )


# ---------------------------------------------------------------------------
# Phase 11: Async job response model
# ---------------------------------------------------------------------------

class AnalysisJobResponse(BaseModel):
    """Response for async POST /analyses (Phase 11 — 202 Accepted)."""
    job_id: str = Field(..., description="UUID of the analysis job — poll GET /analyses/jobs/{job_id}")
    status: str = Field("pending", description="pending | running | completed | failed")
    upload_id: str
    llm_provider: str
    message: str = "تحلیل در پس‌زمینه شروع شد. برای بررسی وضعیت، job_id را poll کنید."
    poll_url: str = Field(..., description="URL to poll for job status")


class AnalysisJobStatusResponse(BaseModel):
    """Status response for GET /analyses/jobs/{job_id}."""
    job_id: str
    status: str
    upload_id: str
    llm_provider: str
    analysis_id: str | None = None
    total_trades: int | None = None
    overall_score: float | None = None
    error_message: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None


@router.post(
    "/analyses",
    response_model=AnalysisSummary | AnalysisJobResponse,
    status_code=201,
    summary="اجرای تحلیل روی یک فایل آپلودشده",
    description="موتور تحلیلی کامل (Behavior → Score → Coaching، بدون هیچ تغییری نسبت به Phase 1) "
                "را روی فایل آپلودشده اجرا می‌کند و شناسه‌ی تحلیل را برمی‌گرداند. "
                "تحلیل در workspace کاربر ذخیره می‌شود (Phase 9). "
                "محدودیت ماهانه‌ی تحلیل بر اساس طرح کاربر اعمال می‌شود (Phase 10). "
                "اگر Celery فعال باشد (Phase 11)، تحلیل async اجرا می‌شود و 202 + job_id برمی‌گردد.",
    responses={
        201: {"model": AnalysisSummary, "description": "Sync mode — analysis complete"},
        202: {"model": AnalysisJobResponse, "description": "Async mode — job dispatched"},
    },
)
async def run_analysis(
    body: AnalysisRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    plan: Plan = Depends(get_user_plan),
):
    _require_db(db)

    # Phase 10: check tier limit BEFORE running the engine (don't waste CPU).
    allowed, error_msg, current, maximum = await check_analysis_allowed(db, user.id, plan)
    if not allowed:
        raise TierRequiredError(
            error_msg,
            details={
                "limit_type": "analyses_per_month",
                "current": current,
                "maximum": maximum,
            },
        )

    # Phase 12 audit fix (C4): check LLM-specific limit BEFORE running the engine.
    # Free-tier users (allows_ai_coaching=False, max_llm_calls_per_month=0) must
    # NOT be able to call the LLM — this was a revenue leak.
    if body.llm_provider != "none":
        llm_allowed, llm_error = await check_llm_call_allowed(db, user.id, plan)
        if not llm_allowed:
            raise TierRequiredError(
                llm_error,
                details={
                    "limit_type": "llm_call",
                    "current_tier": plan.tier.value,
                    "required_feature": "ai_coaching",
                },
            )

    # Parse the upload_id (now a UUID string from Phase 9 onward; was a hex string before).
    try:
        upload_uuid = uuid.UUID(body.upload_id) if isinstance(body.upload_id, str) else body.upload_id
    except (ValueError, TypeError):
        from api.exceptions import UploadNotFoundError
        raise UploadNotFoundError(f"شناسه‌ی آپلود نامعتبر است: «{body.upload_id}»")

    # Phase 11: if Celery is enabled, dispatch async.
    if _use_celery():
        return await _dispatch_async_analysis(db, user.id, upload_uuid, body.llm_provider)

    # Sync flow (default): run in threadpool + return AnalysisSummary (201).
    analysis = await run_in_threadpool(
        lambda: _run_analysis_sync_bridge(db, user.id, upload_uuid, body.llm_provider),
    )

    # Phase 10: record usage event (analysis_run + llm_call if applicable).
    # Done AFTER successful analysis — don't count failed attempts against quota.
    try:
        await record_analysis_run(db, user.id, analysis.id, body.llm_provider)
        await db.commit()
    except Exception as exc:
        log.warning("Failed to record usage event: %s", exc)

    return _to_summary(analysis)


# ---------------------------------------------------------------------------
# Phase 11: async dispatch + job status endpoint
# ---------------------------------------------------------------------------

async def _dispatch_async_analysis(
    db: AsyncSession,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    llm_provider: str,
) -> AnalysisJobResponse:
    """Create an AnalysisJob row + dispatch a Celery task.

    Returns 202 + job_id. The client polls GET /analyses/jobs/{job_id}.
    """
    # Verify the upload exists + belongs to the user (raises if not).
    from workspace.repositories.uploads import get_upload_by_id
    await get_upload_by_id(db, user_id, upload_id)

    # Create the job row.
    job = AnalysisJob(
        id=uuid.uuid4(),
        user_id=user_id,
        upload_id=upload_id,
        llm_provider=llm_provider,
        status="pending",
    )
    db.add(job)
    await db.flush()

    # Dispatch the Celery task.
    try:
        from workers.tasks.analysis_tasks import run_analysis_task
        task = run_analysis_task.delay(
            job_id=str(job.id),
            user_id=str(user_id),
            upload_id=str(upload_id),
            llm_provider=llm_provider,
        )
        job.celery_task_id = task.id
        await db.commit()
        log.info(
            "Dispatched async analysis: job_id=%s celery_task_id=%s user_id=%s",
            job.id, task.id, user_id,
        )
    except Exception as exc:
        # Celery dispatch failed — mark job as failed so client isn't stuck polling.
        job.status = "failed"
        job.error_message = f"Failed to dispatch Celery task: {exc}"[:500]
        job.finished_at = datetime.now(timezone.utc)
        await db.commit()
        log.error("Failed to dispatch Celery task: %s", exc, exc_info=True)
        raise AuthError("Failed to start analysis. Please try again.")

    return AnalysisJobResponse(
        job_id=str(job.id),
        status="pending",
        upload_id=str(upload_id),
        llm_provider=llm_provider,
        poll_url=f"/api/v1/analyses/jobs/{job.id}",
    )


@router.get(
    "/analyses/jobs/{job_id}",
    response_model=AnalysisJobStatusResponse,
    summary="بررسی وضعیت job تحلیل (Phase 11)",
    description="وضعیت یک job تحلیل async را برمی‌گرداند. status می‌تواند pending، "
                "running، completed یا failed باشد. وقتی completed شد، analysis_id "
                "در دسترس است.",
)
async def get_analysis_job_status(
    job_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AnalysisJobStatusResponse:
    _require_db(db)
    stmt = select(AnalysisJob).where(
        AnalysisJob.id == job_id,
        AnalysisJob.user_id == user.id,  # multi-tenant isolation
    )
    job = (await db.execute(stmt)).scalar_one_or_none()
    if job is None:
        raise NotFoundError("job یافت نشد.")

    return AnalysisJobStatusResponse(
        job_id=str(job.id),
        status=job.status,
        upload_id=str(job.upload_id),
        llm_provider=job.llm_provider,
        analysis_id=str(job.analysis_id) if job.analysis_id else None,
        total_trades=job.total_trades,
        overall_score=float(job.overall_score) if job.overall_score is not None else None,
        error_message=job.error_message,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
    )


async def _run_analysis_async(user_id, upload_id, llm_provider):
    """Real async entry point — used by the sync bridge below.

    Uses a fresh session for the analysis (don't share with the request session,
    because the engine call is CPU-bound and we don't want to hold a DB
    connection open during pandas work).

    Imports async_session_factory lazily at call time so monkeypatching
    db.base.async_session_factory (e.g. in tests) is respected.
    """
    import db.base as db_base
    factory = db_base.async_session_factory
    if factory is None:
        raise AuthError("Database is required but is not configured.")
    async with factory() as session:
        try:
            analysis = await run_and_persist_analysis(
                session, user_id, upload_id, llm_provider,
            )
            await session.commit()
            return analysis
        except Exception:
            await session.rollback()
            raise


def _run_analysis_sync_bridge(db, user_id, upload_id, llm_provider):
    """Bridge: run the async analysis function from within run_in_threadpool.

    run_in_threadpool runs a SYNC callable in a thread; the callable itself
    needs to await an async function. We use asyncio.run to create a fresh
    event loop in the thread.
    """
    import asyncio
    return asyncio.run(_run_analysis_async(user_id, upload_id, llm_provider))


@router.get(
    "/analyses/{analysis_id}",
    response_model=AnalysisSummary,
    summary="دریافت خلاصه‌ی یک تحلیل",
)
async def get_analysis_summary(
    analysis_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AnalysisSummary:
    _require_db(db)
    try:
        analysis_uuid = uuid.UUID(analysis_id)
    except (ValueError, TypeError):
        from api.exceptions import AnalysisNotFoundError
        raise AnalysisNotFoundError(f"شناسه‌ی تحلیل نامعتبر است: «{analysis_id}»")

    analysis = await get_analysis_by_id(db, user.id, analysis_uuid)
    return _to_summary(analysis)


@router.get(
    "/analyses/{analysis_id}/report",
    response_model=AnalysisReport,
    summary="دریافت گزارش کامل تحلیل (JSON)",
    description="همان context مشترکی که گزارش‌های HTML/PDF (Phase 2) از آن رندر می‌شوند، "
                "به‌صورت JSON ساختاریافته. شامل فیلد charts با سری‌های زمانی برای "
                "مصرف مستقیم در views/charts.tsx.",
)
async def get_analysis_report(
    analysis_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> AnalysisReport:
    _require_db(db)
    try:
        analysis_uuid = uuid.UUID(analysis_id)
    except (ValueError, TypeError):
        from api.exceptions import AnalysisNotFoundError
        raise AnalysisNotFoundError(f"شناسه‌ی تحلیل نامعتبر است: «{analysis_id}»")

    # Verify ownership + load engine outputs.
    doctor, result, coach = await get_engine_outputs(db, user.id, analysis_uuid)

    # Build the shared report context (CPU-bound but quick — mostly dict assembly).
    ctx = await run_in_threadpool(build_report_context, result, coach, doctor)

    # [v2] سری‌های نموداری JSON-serializable را از همان DataFrame خام
    # استخراج می‌کنیم و در ctx قرار می‌دهیم. در v1 این ctx.pop("charts", None)
    # انجام می‌شد چون charts در حال حاضر فقط تصاویر PNG بودند — حالا
    # build_chart_series داده‌ی JSON برمی‌گرداند و فرانت‌اند مستقیماً با
    # recharts رسم می‌کند.
    df = getattr(doctor, "df", None)
    ctx["charts"] = await run_in_threadpool(build_chart_series, df)
    return AnalysisReport(**ctx)


@router.get(
    "/analyses/{analysis_id}/trades",
    response_model=TradesResponse,
    summary="دریافت فهرست خام معاملات یک تحلیل (v2)",
    description="معاملات خام (per-trade) را با pagination و فیلتر اختیاری بر اساس "
                "سمت (Long/Short) و نتیجه (win/loss) برمی‌گرداند. این داده مستقیماً "
                "از همان DataFrame خام معاملات (doctor.df) استخراج می‌شود که موتور "
                "تحلیلی روی آن اجرا شده — پس با اعداد گزارش همخوانی دارد.",
)
async def get_analysis_trades(
    analysis_id: str,
    page: int = 1,
    page_size: int = 50,
    side: str | None = None,
    outcome: str | None = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> TradesResponse:
    _require_db(db)
    try:
        analysis_uuid = uuid.UUID(analysis_id)
    except (ValueError, TypeError):
        from api.exceptions import AnalysisNotFoundError
        raise AnalysisNotFoundError(f"شناسه‌ی تحلیل نامعتبر است: «{analysis_id}»")

    # Validate filters (return 422 implicitly via FastAPI if invalid).
    if side is not None and side not in ("Long", "Short"):
        from api.exceptions import ValidationError
        raise ValidationError("side باید یکی از Long یا Short باشد.")
    if outcome is not None and outcome not in ("win", "loss"):
        from api.exceptions import ValidationError
        raise ValidationError("outcome باید یکی از win یا loss باشد.")

    # Verify ownership + load engine outputs.
    doctor, _result, _coach = await get_engine_outputs(db, user.id, analysis_uuid)
    df = getattr(doctor, "df", None)
    payload = await run_in_threadpool(
        extract_trades_list, df, page, page_size, side, outcome
    )
    return TradesResponse(**payload)
