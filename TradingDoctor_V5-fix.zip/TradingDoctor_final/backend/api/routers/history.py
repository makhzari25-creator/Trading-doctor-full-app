# -*- coding: utf-8 -*-
"""api/routers/history.py — GET /api/v1/history (Phase 9: user-scoped)

[Phase 9] history is now scoped to the authenticated user. Returns only
the user's own analyses, newest first. The previous global-scope behavior
is intentionally broken — multi-tenant isolation is mandatory.
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from api import config as api_config
from api.dependencies import enforce_rate_limit, verify_api_key
from api.models.analysis import HistoryItem, HistoryResponse
from auth.dependencies import get_current_user
from auth.exceptions import AuthError
from auth.models import User
from db.base import get_db
from utils.logger import get_logger
from workspace.repositories.analyses import list_analyses

log = get_logger("api.routers.history")

router = APIRouter(
    tags=["History"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


@router.get(
    "/history",
    response_model=HistoryResponse,
    summary="تاریخچه‌ی تحلیل‌های اجراشده",
    description="فهرست صفحه‌بندی‌شده‌ی تحلیل‌های قبلی کاربر، جدیدترین اول. "
                "(Phase 9: فقط تحلیل‌های متعلق به کاربر احراز هویت‌شده.)",
)
async def get_history(
    page: int = Query(1, ge=1),
    page_size: int = Query(api_config.HISTORY_DEFAULT_PAGE_SIZE, ge=1, le=api_config.HISTORY_MAX_PAGE_SIZE),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> HistoryResponse:
    if db is None:
        raise AuthError("Database is required but is not configured.")

    analyses, total = await list_analyses(db, user.id, page, page_size)
    items = [
        HistoryItem(
            analysis_id=str(a.id),
            upload_id=str(a.upload_id),
            filename=a.filename,
            created_at=a.created_at,
            total_trades=a.total_trades,
            overall_score=float(a.overall_score),
            primary_diagnosis=a.primary_diagnosis or "N/A",
        )
        for a in analyses
    ]
    return HistoryResponse(items=items, total=total, page=page, page_size=page_size)
