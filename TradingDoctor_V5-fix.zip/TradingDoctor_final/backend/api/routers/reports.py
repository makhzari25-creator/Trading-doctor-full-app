# -*- coding: utf-8 -*-
"""
api/routers/reports.py
---------------------------
GET /api/v1/analyses/{id}/report.html — دانلود گزارش HTML (Phase 9: user-scoped)
GET /api/v1/analyses/{id}/report.pdf   — دانلود گزارش PDF (Phase 9: user-scoped)

[Phase 9] reports are cached in the DB (analysis_report_cache table) on
first request. Subsequent requests for the same analysis return the cached
bytes without re-running reportlab (which is CPU-heavy).

Both endpoints require authentication (get_current_user) and verify the
analysis belongs to the user.
"""

import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse, Response
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from api.dependencies import enforce_rate_limit, verify_api_key
from api.exceptions import AnalysisNotFoundError, ReportGenerationError
from auth.dependencies import get_current_user
from auth.exceptions import AuthError
from auth.models import User
from db.base import get_db
from reporting import ReportRenderError, generate_html_report, generate_pdf_report
from utils.logger import get_logger
from workspace.repositories.analyses import (
    get_analysis_by_id,
    get_cached_report,
    get_engine_outputs,
    save_cached_report,
)

log = get_logger("api.routers.reports")

router = APIRouter(
    tags=["Reports"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


def _require_db(db):
    if db is None:
        raise AuthError("Database is required but is not configured.")


def _parse_analysis_id(analysis_id: str) -> uuid.UUID:
    try:
        return uuid.UUID(analysis_id)
    except (ValueError, TypeError):
        raise AnalysisNotFoundError(f"شناسه‌ی تحلیل نامعتبر است: «{analysis_id}»")


@router.get(
    "/analyses/{analysis_id}/report.html",
    response_class=HTMLResponse,
    summary="دانلود گزارش HTML",
    description="فایل HTML کامل و مستقل (CSS/نمودارها inline). در اولین درخواست رندر و "
                "در DB کش می‌شود؛ درخواست‌های بعدی از کش برمی‌گردند (Phase 9).",
)
async def download_html_report(
    analysis_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> HTMLResponse:
    _require_db(db)
    analysis_uuid = _parse_analysis_id(analysis_id)

    # 1. Try cache first.
    cached = await get_cached_report(db, user.id, analysis_uuid, "html")
    if cached is not None:
        log.debug("HTML cache hit: analysis_id=%s", analysis_uuid)
        return HTMLResponse(content=cached, media_type="text/html")

    # 2. Cache miss — render fresh.
    doctor, result, coach = await get_engine_outputs(db, user.id, analysis_uuid)
    try:
        html = await run_in_threadpool(generate_html_report, result, coach, doctor)
    except ReportRenderError as e:
        log.error("HTML report generation failed for analysis %s: %s", analysis_uuid, e)
        raise ReportGenerationError(str(e))

    # 3. Save to cache (best-effort — don't fail the request if cache write fails).
    try:
        await save_cached_report(db, user.id, analysis_uuid, "html", html.encode("utf-8"))
        await db.commit()
    except Exception as exc:
        log.warning("Failed to cache HTML report: %s", exc)

    return HTMLResponse(content=html, media_type="text/html")


@router.get(
    "/analyses/{analysis_id}/report.pdf",
    summary="دانلود گزارش PDF",
    description="فایل PDF کامل (reportlab، فونت فارسی صحیح). در اولین درخواست رندر و "
                "در DB کش می‌شود؛ درخواست‌های بعدی از کش برمی‌گردند (Phase 9).",
    responses={200: {"content": {"application/pdf": {}}}},
)
async def download_pdf_report(
    analysis_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Response:
    _require_db(db)
    analysis_uuid = _parse_analysis_id(analysis_id)

    # 1. Try cache first.
    cached = await get_cached_report(db, user.id, analysis_uuid, "pdf")
    if cached is not None:
        log.debug("PDF cache hit: analysis_id=%s", analysis_uuid)
        return Response(
            content=cached,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="report_{analysis_id}.pdf"'},
        )

    # 2. Cache miss — render fresh.
    doctor, result, coach = await get_engine_outputs(db, user.id, analysis_uuid)
    try:
        pdf_bytes = await run_in_threadpool(generate_pdf_report, result, coach, doctor)
    except ReportRenderError as e:
        log.error("PDF report generation failed for analysis %s: %s", analysis_uuid, e)
        raise ReportGenerationError(str(e))

    # 3. Save to cache (best-effort).
    try:
        await save_cached_report(db, user.id, analysis_uuid, "pdf", pdf_bytes)
        await db.commit()
    except Exception as exc:
        log.warning("Failed to cache PDF report: %s", exc)

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="report_{analysis_id}.pdf"'},
    )
