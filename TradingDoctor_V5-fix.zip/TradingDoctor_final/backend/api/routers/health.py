# -*- coding: utf-8 -*-
"""api/routers/health.py — GET /api/v1/health (extended in Phase 7.5)

Phase 7.5 additions:
  - DB reachability check (returns db_ready: true/false)
  - Redis reachability check (returns redis_ready: true/false)
  - Distinguishes /health (liveness, cheap) from /health/ready (readiness,
    includes DB+Redis). Kubernetes probes should use /health for liveness
    and /health/ready for readiness.

The original /health endpoint behavior (engine importable + status ok)
is preserved for backwards compatibility with existing probes.
"""

from datetime import datetime, timezone

from fastapi import APIRouter
from pydantic import BaseModel, Field

from api import config as api_config
from api.models.common import HealthResponse
from db.base import db_health_check
from db.redis_client import redis_health_check

router = APIRouter(tags=["Health"])


class ReadinessResponse(BaseModel):
    """Detailed readiness probe — includes DB + Redis status."""
    status: str = Field(..., examples=["ok", "degraded", "unhealthy"])
    version: str
    engine_ready: bool
    db_ready: bool
    redis_ready: bool
    timestamp: datetime


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="بررسی سلامت سرویس (liveness)",
    description=(
        "Liveness probe — سبک و سریع. فقط بررسی می‌کند که موتور تحلیلی قابل‌"
        "بارگذاری است و پردازش پاسخ‌گو است. مناسب برای livenessProbe در "
        "Kubernetes. بررسی‌های سنگین‌تر (DB، Redis) در /health/ready هستند."
    ),
)
async def health_check() -> HealthResponse:
    engine_ready = True
    try:
        import core.service  # noqa: F401  — فقط برای اطمینان از قابل‌import بودن موتور
    except Exception:
        engine_ready = False

    return HealthResponse(
        status="ok" if engine_ready else "degraded",
        version=api_config.API_VERSION,
        engine_ready=engine_ready,
        timestamp=datetime.now(timezone.utc),
    )


@router.get(
    "/health/ready",
    response_model=ReadinessResponse,
    summary="بررسی آمادگی سرویس (readiness)",
    description=(
        "Readiness probe — کامل‌تر از /health. علاوه بر موتور، وضعیت "
        "پایگاه‌داده (PostgreSQL) و Redis را هم بررسی می‌کند. "
        "Kubernetes readinessProbe باید این مسیر را استفاده کند تا ترافیک "
        "فقط زمانی به Pods برسد که وابستگی‌ها برقرار باشند."
    ),
)
async def readiness_check() -> ReadinessResponse:
    engine_ready = True
    try:
        import core.service  # noqa: F401
    except Exception:
        engine_ready = False

    db_ready = await db_health_check()
    redis_ready = await redis_health_check()

    # Status logic: "ok" only when all checks pass; "degraded" when one or
    # more optional dependencies are down but engine is fine; "unhealthy"
    # when the engine itself is broken.
    if not engine_ready:
        status = "unhealthy"
    elif not (db_ready and redis_ready):
        status = "degraded"
    else:
        status = "ok"

    return ReadinessResponse(
        status=status,
        version=api_config.API_VERSION,
        engine_ready=engine_ready,
        db_ready=db_ready,
        redis_ready=redis_ready,
        timestamp=datetime.now(timezone.utc),
    )
