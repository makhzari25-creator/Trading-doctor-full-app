# -*- coding: utf-8 -*-
"""api/routers/config.py — GET /api/v1/config"""

from fastapi import APIRouter

from api import config as api_config
from api.models.common import ConfigResponse

router = APIRouter(tags=["Configuration"])


@router.get(
    "/config",
    response_model=ConfigResponse,
    summary="دریافت تنظیمات عمومی (غیرحساس)",
    description="مقادیری که کلاینت‌ها (وب/موبایل) برای اعتبارسنجی سمت کلاینت قبل از "
                "آپلود نیاز دارند. هرگز شامل کلید API یا مسیر داخلی دیسک نیست.",
)
async def get_config() -> ConfigResponse:
    return ConfigResponse(
        max_upload_size_mb=api_config.MAX_UPLOAD_SIZE_BYTES // (1024 * 1024),
        supported_file_types=["csv", "xlsx", "xls", "htm", "html", "json", "log", "txt"],
        available_llm_providers=["gemini", "openai", "claude", "none"],
        auth_enabled=api_config.AUTH_ENABLED,
        rate_limit_enabled=api_config.RATE_LIMIT_ENABLED,
        rate_limit_requests_per_minute=api_config.RATE_LIMIT_REQUESTS_PER_MINUTE,
        api_version=api_config.API_VERSION,
    )
