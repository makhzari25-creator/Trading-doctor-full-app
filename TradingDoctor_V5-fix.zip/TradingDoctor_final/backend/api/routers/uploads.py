# -*- coding: utf-8 -*-
"""api/routers/uploads.py — POST /api/v1/uploads

Phase 9 update: now user-scoped. The upload is persisted to the user's
workspace via the repository pattern.
Phase 10 update: enforces tier-based upload size + storage quota limits.
"""

from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession

from api import config as api_config
from api.dependencies import enforce_rate_limit, verify_api_key
from api.exceptions import FileTooLargeError
from api.models.uploads import UploadResponse
from auth.dependencies import get_current_user
from auth.exceptions import AuthError, TierRequiredError
from auth.models import User
from billing.dependencies import get_user_plan
from billing.models import Plan
from billing.services.usage import check_upload_allowed, record_upload_bytes
from db.base import get_db
from utils.logger import get_logger
from workspace.repositories.uploads import create_upload

log = get_logger("api.routers.uploads")

router = APIRouter(
    tags=["Uploads"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)


@router.post(
    "/uploads",
    response_model=UploadResponse,
    status_code=201,
    summary="آپلود فایل معاملات",
    description="فایل خام معاملات (csv, xlsx, xls, htm, html, json, log, txt) را آپلود می‌کند. "
                "این مرحله فقط فایل را ذخیره می‌کند — تحلیل در POST /analyses انجام می‌شود. "
                "فایل به workspace کاربر اضافه می‌شود (Phase 9). "
                "محدودیت حجم و سهمیه‌ی ذخیره‌سازی بر اساس طرح کاربر اعمال می‌شود (Phase 10).",
)
async def upload_file(
    file: UploadFile = File(..., description="فایل معاملات"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    plan: Plan = Depends(get_user_plan),
) -> UploadResponse:
    if db is None:
        raise AuthError("Database is required for uploads but is not configured.")

    raw_bytes = await file.read()

    # Phase 3 hard limit (defense in depth — never trust plan config alone).
    if len(raw_bytes) > api_config.MAX_UPLOAD_SIZE_BYTES:
        raise FileTooLargeError(
            f"حجم فایل ({len(raw_bytes) / (1024*1024):.1f}MB) از حد مجاز سرور "
            f"({api_config.MAX_UPLOAD_SIZE_BYTES / (1024*1024):.0f}MB) بیشتر است.",
        )

    # Phase 10: tier-based limit check (per-file size + monthly storage quota).
    allowed, error_msg = await check_upload_allowed(db, user.id, plan, len(raw_bytes))
    if not allowed:
        raise TierRequiredError(error_msg, details={"limit_type": "upload_quota"})

    upload = await create_upload(
        db=db,
        user_id=user.id,
        filename=file.filename or "upload.csv",
        raw_bytes=raw_bytes,
    )
    # Record usage event for storage quota tracking.
    await record_upload_bytes(db, user.id, upload.id, len(raw_bytes))
    await db.commit()

    return UploadResponse(
        upload_id=str(upload.id),
        filename=upload.filename,
        size_bytes=upload.size_bytes,
        uploaded_at=upload.created_at,
    )
