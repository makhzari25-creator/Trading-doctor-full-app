# -*- coding: utf-8 -*-
"""
api/metrics.py
--------------
Phase 7.5 — Prometheus metrics + Sentry initialization.

Metrics exposed at GET /metrics when METRICS_ENABLED=true.
Protected by METRICS_AUTH_TOKEN (Bearer) when set; otherwise relies on
network-level ACL.

Metrics tracked:
  - http_requests_total{method, path, status}   — counter
  - http_request_duration_seconds{method, path}  — histogram
  - http_requests_in_progress                    — gauge
  - analysis_runs_total{llm_provider, outcome}   — counter (engine runs)
  - analysis_duration_seconds{llm_provider}      — histogram

Sentry:
  - Initialized when SENTRY_DSN is set.
  - FastAPI integration auto-instruments request handlers.
  - Traces sample rate from SENTRY_TRACES_SAMPLE_RATE (default 0.1).
  - Disabled silently when DSN is unset (dev/test environments).
"""

from __future__ import annotations

import os
import time
from typing import Optional

from fastapi import FastAPI, Request, Response
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Gauge,
    Histogram,
    REGISTRY,
    generate_latest,
)

from utils.logger import get_logger

log = get_logger("api.metrics")


# ---------------------------------------------------------------------------
# Metric definitions (registered on the default REGISTRY)
# ---------------------------------------------------------------------------

HTTP_REQUESTS_TOTAL = Counter(
    "http_requests_total",
    "Total HTTP requests by method, path, status",
    ["method", "path", "status"],
)

HTTP_REQUEST_DURATION_SECONDS = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "path"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
)

HTTP_REQUESTS_IN_PROGRESS = Gauge(
    "http_requests_in_progress",
    "Number of HTTP requests currently in progress",
)

ANALYSIS_RUNS_TOTAL = Counter(
    "analysis_runs_total",
    "Total engine analyses run, by LLM provider and outcome",
    ["llm_provider", "outcome"],
)

ANALYSIS_DURATION_SECONDS = Histogram(
    "analysis_duration_seconds",
    "Engine analysis duration in seconds, by LLM provider",
    ["llm_provider"],
    buckets=(0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, 120.0),
)


# ---------------------------------------------------------------------------
# Middleware installer
# ---------------------------------------------------------------------------


def _normalize_path(path: str) -> str:
    """Collapse ID-bearing path segments to {id} to keep label cardinality bounded."""
    if not path:
        return "/"
    parts = path.strip("/").split("/")
    if len(parts) >= 4 and parts[0] == "api" and parts[1] == "v1" and parts[2] == "analyses":
        # /api/v1/analyses/{id}[/...]
        if len(parts) == 4:
            return "/api/v1/analyses/{id}"
        if len(parts) >= 5:
            return "/api/v1/analyses/{id}/" + "/".join(parts[4:])
    if len(parts) >= 4 and parts[0] == "api" and parts[1] == "v1" and parts[2] == "uploads":
        return "/api/v1/uploads"
    return path


def install_metrics_middleware(app: FastAPI) -> None:
    """Attach Prometheus request-tracking middleware to the FastAPI app."""

    @app.middleware("http")
    async def prometheus_middleware(request: Request, call_next):
        if not _metrics_enabled():
            return await call_next(request)

        path = _normalize_path(request.url.path)
        method = request.method

        HTTP_REQUESTS_IN_PROGRESS.inc()
        start = time.monotonic()
        try:
            response = await call_next(request)
            elapsed = time.monotonic() - start
            HTTP_REQUESTS_TOTAL.labels(method=method, path=path, status=str(response.status_code)).inc()
            HTTP_REQUEST_DURATION_SECONDS.labels(method=method, path=path).observe(elapsed)
            return response
        finally:
            HTTP_REQUESTS_IN_PROGRESS.dec()


def _metrics_enabled() -> bool:
    return os.getenv("METRICS_ENABLED", "true").strip().lower() in ("true", "1", "yes")


def _metrics_auth_token() -> Optional[str]:
    return os.getenv("METRICS_AUTH_TOKEN", "").strip() or None


async def metrics_endpoint(request: Request) -> Response:
    """Prometheus /metrics endpoint. Protected by Bearer token when configured."""
    token = _metrics_auth_token()
    if token:
        auth = request.headers.get("authorization", "")
        if not auth.startswith("Bearer ") or auth.removeprefix("Bearer ").strip() != token:
            return Response(status_code=401, content=b"Unauthorized\n")
    data = generate_latest(REGISTRY)
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)


# ---------------------------------------------------------------------------
# Sentry
# ---------------------------------------------------------------------------

def init_sentry() -> None:
    """Initialize Sentry SDK when SENTRY_DSN is set. No-op otherwise."""
    dsn = os.getenv("SENTRY_DSN", "").strip()
    if not dsn:
        return
    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.starlette import StarletteIntegration

        traces_sample_rate = float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.1"))
        sentry_sdk.init(
            dsn=dsn,
            traces_sample_rate=traces_sample_rate,
            environment=os.getenv("TRADING_DOCTOR_ENV", "development"),
            release=f"tradingdoctor@{os.getenv('API_VERSION', '1.0.0')}",
            integrations=[
                StarletteIntegration(transaction_style="endpoint"),
                FastApiIntegration(transaction_style="endpoint"),
            ],
        )
        log.info("Sentry initialized (traces_sample_rate=%.2f)", traces_sample_rate)
    except Exception as exc:
        # Sentry failure must NEVER break the app.
        log.warning("Failed to initialize Sentry: %s", exc)
