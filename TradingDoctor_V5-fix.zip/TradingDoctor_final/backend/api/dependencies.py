# -*- coding: utf-8 -*-
"""
api/dependencies.py
-----------------------
وابستگی‌های مشترک FastAPI: احراز هویت (auth-ready)، محدودسازی نرخ
(rate-limit-ready).

Phase 12 audit fix (C2): removed the dead `AnalysisStore` + `get_store`.
Phase 9 replaced all usages with the DB-backed repository pattern.
The dead code imported `core.service.analyze_dataframe` directly,
creating a second unmonitored engine call path that violated the
engine-immutability contract.
"""

import threading
import time
from collections import defaultdict, deque
from typing import Optional

from fastapi import Request, Security
from fastapi.security import APIKeyHeader

from api import config as api_config
from api.exceptions import RateLimitedError, UnauthorizedError
from utils.logger import get_logger

log = get_logger("api.dependencies")


# ------------------------------------------------------------- Auth -----

# [AUDIT FIX — self-review] قبلاً از یک Header ساده استفاده می‌شد که در
# OpenAPI فقط به‌صورت یک پارامتر هدر معمولی نمایش داده می‌شد — نه یک
# "security scheme" رسمی. یعنی نه دکمه‌ی Authorize در Swagger UI ظاهر
# می‌شد و نه ابزارهای تولید کلاینت از روی OpenAPI (client codegen)
# می‌فهمیدند این API نیاز به احراز هویت دارد. APIKeyHeader دقیقاً همان
# رفتار قبلی را حفظ می‌کند (auto_error=False یعنی وقتی احراز هویت
# غیرفعال است چیزی را رد نمی‌کند) اما به‌شکل صحیح در OpenAPI ثبت می‌شود.
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def verify_api_key(x_api_key: Optional[str] = Security(_api_key_header)) -> Optional[str]:
    """
    [Authentication-ready] اگر TRADING_DOCTOR_API_KEYS تنظیم نشده باشد
    (حالت پیش‌فرض توسعه)، این وابستگی چیزی را رد نمی‌کند — اما مسیر
    کامل (هدر، خطای 401، schema امنیتی OpenAPI) از قبل جاست. فعال‌سازی
    واقعی enforcement فقط یک متغیر محیطی است، نه تغییر معماری.
    """
    if not api_config.AUTH_ENABLED:
        return None
    if x_api_key is None or x_api_key not in api_config.API_KEYS:
        raise UnauthorizedError("کلید API نامعتبر یا ارسال‌نشده است.")
    return x_api_key


# --------------------------------------------------------- Rate limit ---

class _SlidingWindowRateLimiter:
    """
    [Rate-limiting-ready] محدودکننده‌ی نرخ ساده‌ی sliding-window، درون‌حافظه.
    برای استقرار تک‌پردازشی کاملاً کاربردی است؛ برای استقرار
    چندپردازشی/چندسرور، این کلاس باید با یک بک‌اند مشترک (Redis) عوض
    شود — چون مصرف‌کنندگان همه از طریق تابع get_rate_limiter زیر به آن
    دسترسی دارند، آن تعویض به یک فایل محدود می‌شود.
    """

    def __init__(self, requests_per_minute: int):
        self.limit = requests_per_minute
        self._hits: "defaultdict[str, deque]" = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> bool:
        now = time.monotonic()
        window_start = now - 60.0
        with self._lock:
            q = self._hits[key]
            while q and q[0] < window_start:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True


_rate_limiter = _SlidingWindowRateLimiter(api_config.RATE_LIMIT_REQUESTS_PER_MINUTE)


async def enforce_rate_limit(request: Request) -> None:
    if not api_config.RATE_LIMIT_ENABLED:
        return
    client_key = request.headers.get("x-api-key") or (request.client.host if request.client else "unknown")
    if not _rate_limiter.check(client_key):
        log.warning("Rate limit exceeded for client=%s path=%s", client_key, request.url.path)
        raise RateLimitedError(
            f"تعداد درخواست‌ها از حد مجاز ({api_config.RATE_LIMIT_REQUESTS_PER_MINUTE} در دقیقه) عبور کرد.",
        )
