# -*- coding: utf-8 -*-
"""
api/config.py
----------------
تنظیمات مخصوص لایه‌ی API. این فایل روی config.py پروژه (تنظیمات موتور
تحلیلی/LLM) اضافه می‌شود، نه جایگزین آن — همان اصل «موتور مستقل از
رابط» که در Phase 1/2 رعایت شد: API فقط یک لایه‌ی ارائه/orchestration
است، هیچ آستانه یا منطق تحلیلی اینجا تعریف نمی‌شود.

همه‌ی مقادیر از متغیر محیطی با fallback امن قابل‌بازنویسی‌اند (همان الگوی
_safe_int/_safe_float که در config.py اصلی برای جلوگیری از کرش با مقدار
نامعتبر استفاده شده است).
"""

import os

import config as engine_config  # تنظیمات موتور تحلیلی (Phase 1) — فقط خوانده می‌شود
from utils.logger import get_logger

log = get_logger("api.config")


def _safe_int(env_var: str, default: int) -> int:
    raw = os.getenv(env_var)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        log.warning("Invalid int for %s=%r, falling back to default %s", env_var, raw, default)
        return default


API_TITLE = "Trading Doctor API"
API_DESCRIPTION = (
    "REST API برای موتور تحلیلی Trading Doctor. این API لایه‌ی نازکی "
    "روی موتور تحلیلی (core/service.py) و ماژول گزارش‌گیری (reporting/) "
    "است — هیچ منطق تحلیلی‌ای در خود API پیاده‌سازی نشده است."
)
API_VERSION = "1.0.0"

# محدودیت حجم آپلود (بایت) — برای جلوگیری از DoS با فایل‌های عظیم
MAX_UPLOAD_SIZE_BYTES = _safe_int("TRADING_DOCTOR_API_MAX_UPLOAD_MB", 25) * 1024 * 1024

# محل ذخیره‌ی آرتیفکت‌های API (آپلودهای خام + گزارش‌های تولیدشده)
API_DATA_DIR = os.path.join(engine_config.BASE_DIR, "data", "api_runs")
os.makedirs(API_DATA_DIR, exist_ok=True)

# --- Auth (authentication-ready) ---
# اگر TRADING_DOCTOR_API_KEYS تنظیم نشده باشد، احراز هویت غیرفعال است
# (حالت توسعه/دمو) — اما تمام مسیر کد (header، خطای 401، schema امنیتی
# OpenAPI) از قبل سرجایش است؛ فعال‌سازی واقعی فقط یک متغیر محیطی است.
_raw_keys = os.getenv("TRADING_DOCTOR_API_KEYS", "").strip()
API_KEYS = set(k.strip() for k in _raw_keys.split(",") if k.strip())
AUTH_ENABLED = len(API_KEYS) > 0

# --- Rate limiting (rate-limiting-ready) ---
RATE_LIMIT_ENABLED = os.getenv("TRADING_DOCTOR_API_RATE_LIMIT_ENABLED", "true").lower() != "false"
RATE_LIMIT_REQUESTS_PER_MINUTE = _safe_int("TRADING_DOCTOR_API_RATE_LIMIT_RPM", 60)

# --- CORS ---
_raw_origins = os.getenv("TRADING_DOCTOR_API_CORS_ORIGINS", "*").strip()
CORS_ORIGINS = [o.strip() for o in _raw_origins.split(",") if o.strip()]

# --- History pagination ---
HISTORY_DEFAULT_PAGE_SIZE = _safe_int("TRADING_DOCTOR_API_HISTORY_PAGE_SIZE", 20)
HISTORY_MAX_PAGE_SIZE = 100

# --- Store bounds (AUDIT FIX — self-review: prevent unbounded memory/disk growth) ---
# بدون این حد، یک سرور API طولانی‌مدت هر تحلیل و هر فایل آپلودی را برای
# همیشه در حافظه/دیسک نگه می‌داشت — نشتی حافظه‌ی تضمین‌شده. وقتی از این
# حد عبور شود، قدیمی‌ترین آیتم‌ها (چه در حافظه چه روی دیسک) حذف می‌شوند.
STORE_MAX_ANALYSES = _safe_int("TRADING_DOCTOR_API_MAX_ANALYSES", 500)
STORE_MAX_UPLOADS = _safe_int("TRADING_DOCTOR_API_MAX_UPLOADS", 1000)
