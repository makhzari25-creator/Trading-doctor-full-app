# -*- coding: utf-8 -*-
"""
api/main.py
--------------
نقطه‌ورود اپلیکیشن FastAPI. اجرا:
    uvicorn api.main:app --reload --port 8000
مستندات تعاملی (OpenAPI/Swagger) خودکار در /docs و /redoc در دسترس است.

[Centralized Error Handling] تمام استثناهای شناخته‌شده (چه از خود API،
چه از موتور تحلیلی/Phase 1، چه از ماژول گزارش‌گیری/Phase 2) دقیقاً
همین‌جا، یک‌بار، به کد HTTP و شکل JSON یکسان نگاشت می‌شوند — هیچ route
مجبور به تکرار try/except نیست، و هرگز traceback خام به کلاینت برنمی‌گردد.
"""

import os
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from api import config as api_config
from api.exceptions import APIError
from api.metrics import init_sentry, install_metrics_middleware, metrics_endpoint
from api.routers import analyses, config as config_router, health, history, reports, uploads
from auth import config as auth_config
from auth.exceptions import AuthError, TierRequiredError
from auth.routers import login, me, password_reset, register, verify_email
from billing.routers import billing as billing_router, webhooks as webhooks_router
from reporting import ReportRenderError
from utils.file_loader import UnsupportedFileError
from utils.logger import get_logger
from utils.validation import DataValidationError
from workspace.routers import workspace as workspace_router

# Phase 12 audit fix (C1): removed `from engines.report_engine import FullResult`
# This violated the engine-immutability contract (no api/* file may import engines/*).
# The health endpoint already does `import core.service` for boot-time smoke testing.

log = get_logger("api.main")

# ---------------------------------------------------------------------------
# Phase 7.5: Initialize Sentry BEFORE creating the app so its middleware can
# instrument request handlers from the very first request.
# ---------------------------------------------------------------------------
init_sentry()


def _is_production() -> bool:
    return os.getenv("TRADING_DOCTOR_ENV", "development").strip().lower() == "production"


# ---------------------------------------------------------------------------
# Phase 7.5: Lifespan handler (replaces deprecated @app.on_event).
# Cleans up Redis pool on shutdown. Engine disposal is handled by the
# process exit (or by test fixtures).
# ---------------------------------------------------------------------------

@asynccontextmanager
async def _lifespan(app: FastAPI):
    log.info("Application startup: %s env=%s",
             api_config.API_TITLE, os.getenv("TRADING_DOCTOR_ENV", "development"))

    # Phase 8: Validate auth config at startup. In production, missing JWT
    # secrets are logged as errors so the operator notices immediately.
    auth_problems = auth_config.validate_auth_config()
    for p in auth_problems:
        if _is_production():
            log.error("[auth config] %s", p)
        else:
            log.warning("[auth config] %s", p)

    # Phase 10: Validate billing config + seed plans on startup.
    try:
        from billing import config as billing_config
        from billing.services.plans import seed_plans
        from db.base import async_session_factory

        billing_problems = billing_config.validate_billing_config()
        for p in billing_problems:
            if _is_production():
                log.error("[billing config] %s", p)
            else:
                log.warning("[billing config] %s", p)

        # Seed plans (idempotent — skips existing)
        if async_session_factory is not None:
            async with async_session_factory() as db:
                count = await seed_plans(db)
                if count > 0:
                    await db.commit()
                    log.info("Seeded %d billing plans", count)
                else:
                    log.debug("Billing plans already seeded")
        else:
            log.warning("DB not configured; skipping plan seeding")
    except Exception as exc:
        log.warning("Billing startup checks failed: %s", exc)

    yield

    # ---- shutdown cleanup ----
    # NOTE: Engine disposal is intentionally skipped here to avoid breaking
    # test fixtures that share the app across multiple TestClient contexts
    # (each context triggers lifespan startup+shutdown). The engine is owned
    # by db.base module state; disposal should happen via the fixture's own
    # teardown (db_engine fixture in tests). In production, the process
    # exit cleans up resources anyway.
    try:
        from db.redis_client import close_redis
        await close_redis()
    except Exception as exc:
        log.warning("Error during Redis shutdown: %s", exc)


# In production, disable /docs and /redoc to avoid leaking the API surface.
_docs_url = None if _is_production() else "/docs"
_redoc_url = None if _is_production() else "/redoc"
_openapi_url = None if _is_production() else "/openapi.json"

app = FastAPI(
    title=api_config.API_TITLE,
    description=api_config.API_DESCRIPTION,
    version=api_config.API_VERSION,
    docs_url=_docs_url,
    redoc_url=_redoc_url,
    openapi_url=_openapi_url,
    lifespan=_lifespan,
)

# Phase 7.5: Prometheus metrics middleware (no-op when METRICS_ENABLED=false).
install_metrics_middleware(app)

# In production, tighten CORS by NOT allowing credentials when origins is "*".
# Browsers reject credentialed requests to "*" anyway; we keep the existing
# behavior in dev for backwards compatibility but log a warning in prod.
_cors_credentials = True
if _is_production() and ("*" in api_config.CORS_ORIGINS):
    log.warning(
        "TRADING_DOCTOR_API_CORS_ORIGINS=* in production — disabling "
        "allow_credentials to comply with CORS spec. Set explicit origins."
    )
    _cors_credentials = False

app.add_middleware(
    CORSMiddleware,
    allow_origins=api_config.CORS_ORIGINS,
    allow_credentials=_cors_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------- Request logging ---

@app.middleware("http")
async def log_requests(request: Request, call_next):
    request_id = uuid.uuid4().hex[:12]
    start = time.monotonic()
    response = await call_next(request)
    elapsed_ms = (time.monotonic() - start) * 1000
    log.info(
        "[%s] %s %s -> %d (%.1fms)",
        request_id, request.method, request.url.path, response.status_code, elapsed_ms,
    )
    response.headers["X-Request-ID"] = request_id
    return response


# --------------------------------------------------- Exception handlers -

def _error_json(status_code: int, code: str, message: str, details: dict = None) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": {"code": code, "message": message, "details": details or {}}},
    )


@app.exception_handler(APIError)
async def handle_api_error(request: Request, exc: APIError):
    return _error_json(exc.status_code, exc.error_code, exc.message, exc.details)


@app.exception_handler(AuthError)
async def handle_auth_error(request: Request, exc: AuthError):
    """Phase 8 — map AuthError subclasses to the unified envelope.

    All AuthError subclasses carry their own status_code + error_code, so
    this handler is a thin pass-through. The 401/403/409/422/423 codes
    all flow through the same envelope.
    """
    return _error_json(exc.status_code, exc.error_code, exc.message, exc.details)


@app.exception_handler(UnsupportedFileError)
async def handle_unsupported_file(request: Request, exc: UnsupportedFileError):
    # [Phase 1] پیام همین الان هم برای کاربر نهایی واضح است (تولیدشده
    # توسط utils/file_loader.py) — فقط به کد HTTP درست نگاشت می‌شود.
    return _error_json(400, "invalid_file", str(exc))


@app.exception_handler(DataValidationError)
async def handle_data_validation_error(request: Request, exc: DataValidationError):
    return _error_json(422, "invalid_data", str(exc))


@app.exception_handler(RequestValidationError)
async def handle_request_validation_error(request: Request, exc: RequestValidationError):
    # [AUDIT FIX — self-review, یافته‌ی واقعی] این هندلر قبلاً ثبت نشده
    # بود، پس FastAPI از هندلر پیش‌فرض خودش استفاده می‌کرد که شکل
    # {"detail": [...]} برمی‌گرداند — نه envelope یکسان {"error": {...}}
    # که بقیه‌ی خطاهای API استفاده می‌کنند. یک مصرف‌کننده‌ی API که فقط
    # روی شکل {"error": ...} برنامه‌نویسی کرده بود، برای خطاهای
    # اعتبارسنجی بدنه‌ی درخواست (رایج‌ترین نوع خطای کلاینت) غافلگیر
    # می‌شد. حالا با همان envelope یکسان، شامل جزئیات فیلد-به-فیلد.
    field_errors = [
        {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]}
        for e in exc.errors()
    ]
    return _error_json(
        422, "request_validation_error",
        "درخواست نامعتبر است؛ لطفاً فیلدهای ورودی را بررسی کنید.",
        details={"fields": field_errors},
    )


@app.exception_handler(ReportRenderError)
async def handle_report_render_error(request: Request, exc: ReportRenderError):
    log.error("Unhandled ReportRenderError reached global handler: %s", exc, exc_info=True)
    return _error_json(500, "report_generation_failed", str(exc))


@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception):
    # [همان فلسفه‌ی Phase 1] traceback کامل فقط در لاگ؛ به کلاینت پیام کوتاه و امن.
    log.error("Unhandled exception on %s %s", request.method, request.url.path, exc_info=True)
    return _error_json(500, "internal_error", "خطای داخلی سرور رخ داد. لطفاً بعداً دوباره تلاش کنید.")


# --------------------------------------------------------------- Routes -

API_PREFIX = "/api/v1"
app.include_router(health.router, prefix=API_PREFIX)
app.include_router(config_router.router, prefix=API_PREFIX)

# Phase 8 — Authentication & user profile routers
app.include_router(register.router, prefix=API_PREFIX)
app.include_router(login.router, prefix=API_PREFIX)
app.include_router(verify_email.router, prefix=API_PREFIX)
app.include_router(password_reset.router, prefix=API_PREFIX)
app.include_router(me.router, prefix=API_PREFIX)

# Phase 3 + Phase 9 — Core API endpoints (now user-scoped)
app.include_router(uploads.router, prefix=API_PREFIX)
app.include_router(analyses.router, prefix=API_PREFIX)
app.include_router(reports.router, prefix=API_PREFIX)
app.include_router(history.router, prefix=API_PREFIX)

# Phase 9 — Workspace management endpoints
app.include_router(workspace_router.router, prefix=API_PREFIX)

# Phase 10 — Billing + Stripe webhooks
app.include_router(billing_router.router, prefix=API_PREFIX)
app.include_router(webhooks_router.router, prefix=API_PREFIX)


# ------------------------------------------------- Phase 8: Startup config check -
# Auth config is validated inside the lifespan handler at startup (see above).
# Any problems are logged; in production, missing secrets cause a clear error.


# ------------------------------------------------- Phase 7.5: Metrics ---

@app.get("/metrics", include_in_schema=False)
async def _metrics(request: Request):
    """Prometheus metrics endpoint. No-op (returns 404) when disabled.

    Protected by Bearer token when METRICS_AUTH_TOKEN is set; otherwise
    relies on network-level ACL (do not expose publicly without a firewall).
    """
    if not os.getenv("METRICS_ENABLED", "true").strip().lower() in ("true", "1", "yes"):
        return _error_json(404, "not_found", "Metrics endpoint is disabled.")
    return await metrics_endpoint(request)


# ---------------------------------------------------- Phase 7.5: Lifespan -
# Cleanup hooks for graceful shutdown (Redis pool, DB engine) are registered
# via the _lifespan context manager above (replaces deprecated @app.on_event).


@app.get("/", include_in_schema=False)
async def root():
    docs_url = _docs_url if _docs_url else None
    return {
        "service": api_config.API_TITLE,
        "version": api_config.API_VERSION,
        "env": os.getenv("TRADING_DOCTOR_ENV", "development"),
        "docs": docs_url,
    }
