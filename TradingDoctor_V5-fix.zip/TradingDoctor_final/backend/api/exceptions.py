# -*- coding: utf-8 -*-
"""
api/exceptions.py
--------------------
سلسله‌مراتب استثناهای لایه‌ی API + مدیریت متمرکز خطا (Centralized Error
Handling). هر endpoint فقط این استثناهای واضح را raise می‌کند؛ نگاشت به
کد HTTP و شکل پاسخ JSON یک‌جا اینجا و در api/main.py انجام می‌شود — نه
پراکنده در هر route.

اصل: هرگز traceback خام به کلاینت برنگردد (همان فلسفه‌ی Phase 1 برای
CLI/Streamlit)، اما جزئیات کامل همیشه لاگ شود.
"""

from utils.logger import get_logger

log = get_logger("api.exceptions")


class APIError(Exception):
    """پایه‌ی همه‌ی خطاهای شناخته‌شده‌ی API. status_code همیشه صریح است."""
    status_code = 500
    error_code = "internal_error"

    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class NotFoundError(APIError):
    status_code = 404
    error_code = "not_found"


class UploadNotFoundError(NotFoundError):
    error_code = "upload_not_found"


class AnalysisNotFoundError(NotFoundError):
    error_code = "analysis_not_found"


class FavoriteNotFoundError(NotFoundError):
    """Phase 9 — favorite does not exist for this user."""
    error_code = "favorite_not_found"


class InvalidFileError(APIError):
    """فایل آپلودی قابل‌خواندن نیست یا فرمت پشتیبانی‌نشده دارد."""
    status_code = 400
    error_code = "invalid_file"


class DataInvalidError(APIError):
    """محتوای فایل معتبر نیست (بدون ستون مالی/زمانی قابل‌شناسایی، خالی، و...)."""
    status_code = 422
    error_code = "invalid_data"


class FileTooLargeError(APIError):
    status_code = 413
    error_code = "file_too_large"


class ReportGenerationError(APIError):
    status_code = 500
    error_code = "report_generation_failed"


class UnauthorizedError(APIError):
    status_code = 401
    error_code = "unauthorized"


class RateLimitedError(APIError):
    status_code = 429
    error_code = "rate_limited"


class ValidationError(APIError):
    """پارامترهای query/body معتبر نیستند (مثلاً side باید Long/Short باشد).

    [v2] اضافه شد برای endpoint /analyses/{id}/trades.
    """
    status_code = 422
    error_code = "validation_error"
