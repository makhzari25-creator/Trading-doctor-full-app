# -*- coding: utf-8 -*-
"""
api/models/analysis.py
--------------------------
مدل‌های درخواست/پاسخ تحلیل. `AnalysisReport` دقیقاً همان ساختار
`reporting/data_context.py::build_report_context()` را آینه می‌کند —
همان context مشترکی که رندررهای HTML/PDF (Phase 2) استفاده می‌کنند؛
پس /analyses/{id}/report (JSON)، /report.html و /report.pdf هر سه از
یک منبع داده‌ی واحد می‌آیند و هرگز نمی‌توانند با هم مغایرت داشته باشند.
"""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class AnalysisRequest(BaseModel):
    upload_id: str = Field(..., description="شناسه‌ی برگشتی از POST /uploads")
    llm_provider: Literal["gemini", "openai", "claude", "none"] = Field(
        "none",
        description="پیش‌فرض 'none' در API عمداً محافظه‌کارانه است — تا فراخوانی "
                    "به یک LLM خارجی (هزینه/تأخیر) تنها با انتخاب صریح مصرف‌کننده‌ی API رخ دهد.",
    )


class AnalysisSummary(BaseModel):
    analysis_id: str
    upload_id: str
    filename: str
    created_at: datetime
    total_trades: int
    overall_score: float
    primary_diagnosis: str
    data_quality_warning_count: int


class AnalysisReport(BaseModel):
    """
    خروجی کامل و ساختاریافته‌ی تحلیل — بدون هیچ محاسبه‌ی جدید، مستقیماً
    برگرفته از FullResult/coach که توسط core/service.py (Phase 1) تولید
    شده‌اند.

    [v2] فیلد charts اضافه شد: سری‌های زمانی JSON-serializable برای
    مصرف مستقیم در فرانت‌اند (recharts در views/charts.tsx). این فیلد
    توسط reporting/chart_data.py::build_chart_series از همان DataFrame
    خام معاملات (doctor.df) استخراج می‌شود، با همان فرمول‌های
    reporting/charts.py — پس اعداد نمودارها هرگز نمی‌توانند با اعداد
    گزارش PDF/HTML مغایرت داشته باشند.
    """
    meta: Dict[str, Any]
    executive_summary: Dict[str, Any]
    overall_score: Dict[str, Any]
    diagnosis: Dict[str, Any]
    trader_profile: Dict[str, Any]
    strengths: List[str]
    weaknesses: List[str]
    behavior_analysis: Dict[str, Any]
    psychology: Dict[str, Any]
    evidence: List[Dict[str, Any]]
    statistics: Dict[str, Any]
    performance: Dict[str, Any]
    risk: Dict[str, Any]
    recommendations: List[Dict[str, Any]]
    ai_coaching: Dict[str, Any]
    appendix: Dict[str, Any]
    # سری‌های نموداری برای مصرف در views/charts.tsx.
    # در v1 این فیلد وجود نداشت و charts از ctx حذف می‌شد.
    charts: Dict[str, Any] = Field(default_factory=dict)


class TradesResponse(BaseModel):
    """پاسخ endpoint GET /analyses/{id}/trades — فهرست خام معاملات با pagination.

    [v2] این مدل جدید است؛ قبلاً endpoint وجود نداشت و فرانت‌اند از
    mockTrades استفاده می‌کرد.
    """
    trades: List[Dict[str, Any]]
    total: int
    page: int
    page_size: int
    # [v5 fix] آیا دیتاست منبع اصلاً ستون صریح Side/Type دارد؟ اگر False باشد،
    # یعنی این pipeline (utils/column_mapper.py فقط Open Time/Profit/Size را
    # می‌شناسد) هیچ سرنخ واقعی جهت معامله ندارد و هر trade.side مقدار null
    # خواهد داشت — فرانت‌اند باید فیلتر Long/Short را در این حالت پنهان/غیرفعال
    # کند، نه اینکه نتیجه‌ی خالیِ فیلترشده را به‌عنوان «صفر معامله‌ی Long» نشان دهد.
    side_available: bool = True


class HistoryItem(BaseModel):
    analysis_id: str
    upload_id: str
    filename: str
    created_at: datetime
    total_trades: int
    overall_score: float
    primary_diagnosis: str


class HistoryResponse(BaseModel):
    items: List[HistoryItem]
    total: int
    page: int
    page_size: int
