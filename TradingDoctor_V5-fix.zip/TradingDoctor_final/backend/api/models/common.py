# -*- coding: utf-8 -*-
"""api/models/common.py — مدل‌های مشترک پاسخ (خطا، سلامت، تنظیمات)."""

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class ErrorDetail(BaseModel):
    code: str = Field(..., description="کد ماشین‌خوان خطا، مثلاً 'upload_not_found'")
    message: str = Field(..., description="پیام قابل‌نمایش به کاربر")
    details: Dict[str, Any] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    """شکل یکسان تمام پاسخ‌های خطا در کل API — تولیدشده توسط exception handler مرکزی."""
    error: ErrorDetail


class HealthResponse(BaseModel):
    status: str = Field(..., examples=["ok"])
    version: str
    engine_ready: bool
    timestamp: datetime


class ConfigResponse(BaseModel):
    """تنها تنظیمات غیرحساس — هرگز کلید API یا مسیر داخلی دیسک را افشا نمی‌کند."""
    max_upload_size_mb: int
    supported_file_types: list
    available_llm_providers: list
    auth_enabled: bool
    rate_limit_enabled: bool
    rate_limit_requests_per_minute: int
    api_version: str
