# -*- coding: utf-8 -*-
"""api/models/uploads.py — مدل‌های آپلود فایل."""

from datetime import datetime

from pydantic import BaseModel, Field


class UploadResponse(BaseModel):
    upload_id: str = Field(..., description="شناسه‌ی یکتای این آپلود — برای صدا زدن /analyses از آن استفاده کنید")
    filename: str
    size_bytes: int
    uploaded_at: datetime
