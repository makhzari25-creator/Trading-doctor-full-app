# -*- coding: utf-8 -*-
"""
workers/celery_app.py
---------------------
Phase 11 — Celery application configuration.

Celery is used for background job processing:
  - Async analysis runs (POST /analyses → 202 + job_id)
  - Email sending
  - Report pre-generation
  - Cleanup tasks

Configuration:
  - Broker: Redis (CELERY_BROKER_URL)
  - Result backend: Redis (CELERY_RESULT_BACKEND)
  - Task serialization: JSON (not pickle — security)
  - Timezone: UTC
  - Task time limit: 10 minutes (configurable)

Usage:
  # Start a worker:
  celery -A workers.celery_app worker --loglevel=info --concurrency=4

  # Beat scheduler (for periodic tasks like cleanup):
  celery -A workers.celery_app beat --loglevel=info

  # Monitor:
  celery -A workers.celery_app flower
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from celery import Celery
from celery.signals import task_failure, task_success

from utils.logger import get_logger

log = get_logger("workers.celery_app")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Ensure the project root is on sys.path so tasks can import db.*, auth.*, etc.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Redis URLs (shared with the API's Redis for simplicity)
BROKER_URL = os.getenv("CELERY_BROKER_URL", "redis://redis:6379/1")
RESULT_BACKEND = os.getenv("CELERY_RESULT_BACKEND", "redis://redis:6379/2")

# Worker concurrency (override via env)
WORKER_CONCURRENCY = int(os.getenv("CELERY_WORKER_CONCURRENCY", "4"))

# Task time limit in seconds (hard kill)
TASK_TIME_LIMIT = int(os.getenv("CELERY_TASK_TIME_LIMIT", "600"))  # 10 min

# Soft time limit (raises SoftTimeLimitExceeded — task can catch + cleanup)
TASK_SOFT_TIME_LIMIT = int(os.getenv("CELERY_TASK_SOFT_TIME_LIMIT", "540"))  # 9 min


# ---------------------------------------------------------------------------
# Celery app
# ---------------------------------------------------------------------------

app = Celery(
    "tradingdoctor",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
    include=[
        # Task modules are imported on worker startup.
        # Listed explicitly so the worker discovers them.
        "workers.tasks.analysis_tasks",
        "workers.tasks.email_tasks",
        "workers.tasks.cleanup_tasks",
    ],
)

app.conf.update(
    # Serialization (JSON, not pickle — security)
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],

    # Timezone
    timezone="UTC",
    enable_utc=True,

    # Performance
    worker_concurrency=WORKER_CONCURRENCY,
    worker_prefetch_multiplier=1,  # 1 task at a time per worker process (CPU-bound)
    task_acks_late=True,  # ack only after task completes (crash-safe)

    # Time limits
    task_time_limit=TASK_TIME_LIMIT,
    task_soft_time_limit=TASK_SOFT_TIME_LIMIT,

    # Result expiry (results expire from Redis after 1 hour)
    result_expires=3600,

    # Task routing (optional — for priority queues)
    task_routes={
        "workers.tasks.analysis_tasks.*": {"queue": "analyses"},
        "workers.tasks.email_tasks.*": {"queue": "emails"},
        "workers.tasks.cleanup_tasks.*": {"queue": "cleanup"},
    },

    # Beat schedule (periodic tasks)
    # Phase 12 audit fix (C4-deploy): replaced `schedule: 0.0` placeholder
    # (which fired continuously, DDoSing the DB) with real crontab schedules.
    beat_schedule={
        # Purge old soft-deleted records every day at 3 AM UTC
        "cleanup-soft-deleted-daily": {
            "task": "workers.tasks.cleanup_tasks.purge_old_soft_deletes",
            "schedule": __import__("celery.schedules", fromlist=["crontab"]).crontab(hour=3, minute=0),
        },
        # Purge old completed/failed jobs every day at 3:30 AM UTC
        "purge-old-jobs-daily": {
            "task": "workers.tasks.cleanup_tasks.purge_old_jobs",
            "schedule": __import__("celery.schedules", fromlist=["crontab"]).crontab(hour=3, minute=30),
        },
        # Cleanup orphan upload files every Sunday at 4 AM UTC
        "cleanup-orphan-uploads-weekly": {
            "task": "workers.tasks.cleanup_tasks.cleanup_orphan_uploads",
            "schedule": __import__("celery.schedules", fromlist=["crontab"]).crontab(hour=4, minute=0, day_of_week=0),
        },
    },

    # Security: don't send task events (reduces Redis traffic)
    task_send_sent_event=False,
    worker_send_task_events=False,
)

log.info(
    "Celery app configured: broker=%s concurrency=%d time_limit=%ds",
    BROKER_URL, WORKER_CONCURRENCY, TASK_TIME_LIMIT,
)


# ---------------------------------------------------------------------------
# Signals (structured logging of task outcomes)
# ---------------------------------------------------------------------------

@task_success.connect
def _on_task_success(sender=None, **kwargs):
    """Log successful task completion."""
    task_id = getattr(sender.request, "id", "unknown") if sender else "unknown"
    task_name = getattr(sender, "name", "unknown") if sender else "unknown"
    log.info("Task succeeded: %s id=%s", task_name, task_id)


@task_failure.connect
def _on_task_failure(sender=None, **kwargs):
    """Log failed task completion."""
    task_id = getattr(sender.request, "id", "unknown") if sender else "unknown"
    task_name = getattr(sender, "name", "unknown") if sender else "unknown"
    exception = kwargs.get("exception")
    log.error(
        "Task failed: %s id=%s exception=%s",
        task_name, task_id, exception,
        exc_info=True,
    )
