# -*- coding: utf-8 -*-
"""
workers/tasks package — Celery task definitions.

Each module groups related tasks:
  - analysis_tasks: async analysis runs (replaces sync POST /analyses)
  - email_tasks: verification, password reset, invoice emails
  - cleanup_tasks: periodic purges of soft-deleted records
"""
