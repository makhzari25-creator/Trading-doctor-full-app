# -*- coding: utf-8 -*-
"""
workers/tasks/email_tasks.py
----------------------------
Phase 11 — Async email sending via Celery.

Decouples email delivery from request handlers:
  - Registration → verification email (was sync in Phase 8)
  - Password reset → reset email (was sync in Phase 8)
  - Subscription lifecycle → invoice emails (Phase 10)

Tasks defined here:
  - send_email_verification_task(user_id, email, token, full_name)
  - send_password_reset_task(user_id, email, token, full_name)
  - send_welcome_email_task(user_id, email, full_name)
  - send_invoice_email_task(user_id, email, invoice_id, invoice_pdf_url)

Why async?
  - SMTP/SES/SendGrid calls can take 1-5 seconds
  - Don't block the HTTP request on email delivery
  - Retry on transient failures (Celery handles this)
"""

from __future__ import annotations

import asyncio
import uuid

from workers.celery_app import app
from utils.logger import get_logger

log = get_logger("workers.email_tasks")


@app.task(
    name="workers.tasks.email_tasks.send_email_verification_task",
    bind=True,
    max_retries=3,
    default_retry_delay=60,  # 1 min between retries
    acks_late=True,
)
def send_email_verification_task(self, user_id: str, email: str, token: str, full_name: str = None):
    """Send the email verification email asynchronously."""
    try:
        from auth.services.email import send_email_verification_email
        result = asyncio.run(send_email_verification_email(email, token, full_name))
        log.info("Verification email sent: user_id=%s email=%s", user_id, email)
        return {"user_id": user_id, "email": email, "sent": result}
    except Exception as exc:
        log.warning("Verification email failed (attempt %d): %s", self.request.retries, exc)
        raise self.retry(exc=exc)


@app.task(
    name="workers.tasks.email_tasks.send_password_reset_task",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    acks_late=True,
)
def send_password_reset_task(self, user_id: str, email: str, token: str, full_name: str = None):
    """Send the password reset email asynchronously."""
    try:
        from auth.services.email import send_password_reset_email
        result = asyncio.run(send_password_reset_email(email, token, full_name))
        log.info("Password reset email sent: user_id=%s email=%s", user_id, email)
        return {"user_id": user_id, "email": email, "sent": result}
    except Exception as exc:
        log.warning("Password reset email failed (attempt %d): %s", self.request.retries, exc)
        raise self.retry(exc=exc)


@app.task(
    name="workers.tasks.email_tasks.send_welcome_email_task",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    acks_late=True,
)
def send_welcome_email_task(self, user_id: str, email: str, full_name: str = None):
    """Send the post-verification welcome email asynchronously."""
    try:
        from auth.services.email import send_welcome_email
        result = asyncio.run(send_welcome_email(email, full_name))
        log.info("Welcome email sent: user_id=%s email=%s", user_id, email)
        return {"user_id": user_id, "email": email, "sent": result}
    except Exception as exc:
        log.warning("Welcome email failed (attempt %d): %s", self.request.retries, exc)
        raise self.retry(exc=exc)


@app.task(
    name="workers.tasks.email_tasks.send_invoice_email_task",
    bind=True,
    max_retries=3,
    default_retry_delay=120,  # 2 min between retries (invoices are less urgent)
    acks_late=True,
)
def send_invoice_email_task(self, user_id: str, email: str, invoice_id: str, invoice_pdf_url: str = None):
    """Send an invoice receipt email (Phase 10 — triggered by Stripe webhook).

    TODO (future): implement the invoice email template + send.
    For now, just log — the user can view invoices via the billing portal.
    """
    log.info(
        "Invoice email queued (not yet implemented): user_id=%s email=%s invoice_id=%s",
        user_id, email, invoice_id,
    )
    return {
        "user_id": user_id,
        "email": email,
        "invoice_id": invoice_id,
        "sent": False,  # not yet implemented
        "note": "Invoice emails are not yet sent; users can view invoices via the billing portal.",
    }
