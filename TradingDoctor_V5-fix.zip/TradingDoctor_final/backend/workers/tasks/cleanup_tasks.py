# -*- coding: utf-8 -*-
"""
workers/tasks/cleanup_tasks.py
------------------------------
Phase 11 — Periodic cleanup tasks via Celery beat.

Tasks defined here:
  - purge_old_soft_deletes() — hard-delete records soft-deleted >30 days ago
  - purge_old_jobs() — delete completed/failed jobs older than 30 days
  - cleanup_orphan_uploads() — delete upload files whose DB row is gone

These run on a schedule via Celery beat (see workers/celery_app.py).
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, select, func

from workers.celery_app import app
from utils.logger import get_logger

log = get_logger("workers.cleanup_tasks")

# Retention period for soft-deleted records (days)
SOFT_DELETE_RETENTION_DAYS = int(os.getenv("TRADING_DOCTOR_SOFT_DELETE_RETENTION_DAYS", "30"))
# Retention period for completed/failed jobs (days)
JOB_RETENTION_DAYS = int(os.getenv("TRADING_DOCTOR_JOB_RETENTION_DAYS", "30"))


@app.task(
    name="workers.tasks.cleanup_tasks.purge_old_soft_deletes",
    acks_late=True,
)
def purge_old_soft_deletes():
    """Hard-delete records that were soft-deleted more than 30 days ago.

    Runs daily via Celery beat. Affects:
      - uploads (soft-deleted rows + their files on disk)
      - analyses (soft-deleted rows + cached reports)
      - users (soft-deleted accounts)
    """
    log.info("Starting purge_old_soft_deletes (retention=%d days)", SOFT_DELETE_RETENTION_DAYS)
    try:
        result = asyncio.run(_purge_old_soft_deletes_async())
        log.info("Purge complete: %s", result)
        return result
    except Exception as exc:
        log.error("Purge failed: %s", exc, exc_info=True)
        raise


async def _purge_old_soft_deletes_async() -> dict:
    """Async implementation of soft-delete purge."""
    import db.base as db_base
    from workspace.models import Upload, Analysis
    from auth.models import User

    factory = db_base.async_session_factory
    if factory is None:
        return {"error": "DB not configured"}

    cutoff = datetime.now(timezone.utc) - timedelta(days=SOFT_DELETE_RETENTION_DAYS)
    deleted = {"uploads": 0, "analyses": 0, "users": 0, "files": 0}

    async with factory() as session:
        # Delete soft-deleted analyses (cascade will remove cached reports + favorites)
        stmt = delete(Analysis).where(
            Analysis.deleted_at.is_not(None),
            Analysis.deleted_at < cutoff,
        )
        result = await session.execute(stmt)
        deleted["analyses"] = result.rowcount or 0

        # Delete soft-deleted uploads (also remove files from disk)
        from workspace.services.storage import LocalStorageBackend
        backend = LocalStorageBackend()

        stmt = select(Upload).where(
            Upload.deleted_at.is_not(None),
            Upload.deleted_at < cutoff,
        )
        old_uploads = (await session.execute(stmt)).scalars().all()
        for upload in old_uploads:
            try:
                await backend.delete(upload.storage_path)
                deleted["files"] += 1
            except Exception as exc:
                log.warning("Failed to delete file %s: %s", upload.storage_path, exc)

        stmt = delete(Upload).where(
            Upload.deleted_at.is_not(None),
            Upload.deleted_at < cutoff,
        )
        result = await session.execute(stmt)
        deleted["uploads"] = result.rowcount or 0

        # Delete soft-deleted users
        stmt = delete(User).where(
            User.deleted_at.is_not(None),
            User.deleted_at < cutoff,
        )
        result = await session.execute(stmt)
        deleted["users"] = result.rowcount or 0

        await session.commit()

    return {
        "cutoff": cutoff.isoformat(),
        "deleted": deleted,
    }


@app.task(
    name="workers.tasks.cleanup_tasks.purge_old_jobs",
    acks_late=True,
)
def purge_old_jobs():
    """Delete completed/failed jobs older than 30 days."""
    log.info("Starting purge_old_jobs (retention=%d days)", JOB_RETENTION_DAYS)
    try:
        result = asyncio.run(_purge_old_jobs_async())
        log.info("Job purge complete: %s", result)
        return result
    except Exception as exc:
        log.error("Job purge failed: %s", exc, exc_info=True)
        raise


async def _purge_old_jobs_async() -> dict:
    """Async implementation of job purge."""
    import db.base as db_base
    from workspace.models import AnalysisJob

    factory = db_base.async_session_factory
    if factory is None:
        return {"error": "DB not configured"}

    cutoff = datetime.now(timezone.utc) - timedelta(days=JOB_RETENTION_DAYS)

    async with factory() as session:
        stmt = delete(AnalysisJob).where(
            AnalysisJob.status.in_(["completed", "failed"]),
            AnalysisJob.created_at < cutoff,
        )
        result = await session.execute(stmt)
        deleted_count = result.rowcount or 0
        await session.commit()

    return {
        "cutoff": cutoff.isoformat(),
        "deleted_jobs": deleted_count,
    }


@app.task(
    name="workers.tasks.cleanup_tasks.cleanup_orphan_uploads",
    acks_late=True,
)
def cleanup_orphan_uploads():
    """Delete upload files on disk whose DB row no longer exists.

    Defensive cleanup — runs weekly. Catches files that were orphaned by
    crashes during delete operations.
    """
    log.info("Starting cleanup_orphan_uploads")
    try:
        result = asyncio.run(_cleanup_orphan_uploads_async())
        log.info("Orphan cleanup complete: %s", result)
        return result
    except Exception as exc:
        log.error("Orphan cleanup failed: %s", exc, exc_info=True)
        raise


async def _cleanup_orphan_uploads_async() -> dict:
    """Async implementation of orphan upload cleanup."""
    import os
    import glob
    from api import config as api_config

    uploads_dir = os.path.join(api_config.API_DATA_DIR, "uploads")
    if not os.path.exists(uploads_dir):
        return {"orphan_files": 0, "freed_bytes": 0}

    # Walk the uploads directory and check each file against the DB
    import db.base as db_base
    from workspace.models import Upload

    factory = db_base.async_session_factory
    if factory is None:
        return {"error": "DB not configured"}

    orphan_count = 0
    freed_bytes = 0

    async with factory() as session:
        for root, dirs, files in os.walk(uploads_dir):
            for filename in files:
                file_path = os.path.join(root, filename)
                rel_path = os.path.relpath(file_path, uploads_dir)

                # Check if any upload row has this storage_path
                stmt = select(Upload.id).where(Upload.storage_path == rel_path).limit(1)
                result = await session.execute(stmt)
                if result.scalar_one_or_none() is None:
                    # Orphan — delete
                    try:
                        size = os.path.getsize(file_path)
                        os.remove(file_path)
                        orphan_count += 1
                        freed_bytes += size
                        log.info("Removed orphan upload file: %s (%d bytes)", rel_path, size)
                    except OSError as exc:
                        log.warning("Failed to remove orphan %s: %s", file_path, exc)

    return {
        "orphan_files": orphan_count,
        "freed_bytes": freed_bytes,
    }
