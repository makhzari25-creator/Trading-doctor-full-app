# -*- coding: utf-8 -*-
"""
workers/tasks/analysis_tasks.py
-------------------------------
Phase 11 — Async analysis tasks via Celery.

Replaces the sync POST /analyses flow with an async pattern:
  1. POST /analyses → creates a Job row + dispatches Celery task → returns 202 + job_id
  2. Client polls GET /analyses/jobs/{job_id} until status=completed
  3. When complete, the job row points to the analysis_id
  4. Client fetches the analysis via existing GET /analyses/{id}

Tasks defined here:
  - run_analysis_task(job_id, user_id, upload_id, llm_provider)

The task calls workspace.repositories.analyses.run_and_persist_analysis —
the SAME function the sync flow uses. Engine contract preserved.

Why Celery + async?
  - Large CSV files (10k+ trades) can take 30+ seconds to analyze
  - With LLM, add 10-30s of network latency
  - HTTP request timeout is typically 30s; sync flow risks 504 Gateway Timeout
  - Celery decouples client wait time from analysis time
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from celery import shared_task
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from utils.logger import get_logger
from workers.celery_app import app

log = get_logger("workers.analysis_tasks")


# ---------------------------------------------------------------------------
# Job status enum (mirrors AnalysisJob model)
# ---------------------------------------------------------------------------

JOB_PENDING = "pending"
JOB_RUNNING = "running"
JOB_COMPLETED = "completed"
JOB_FAILED = "failed"


# ---------------------------------------------------------------------------
# Lazy model import (avoid circular dependency at module load)
# ---------------------------------------------------------------------------

def _get_job_model():
    """Lazily import AnalysisJob to avoid circular imports at module load."""
    from workspace.models import AnalysisJob  # noqa: F401  (will be defined below)
    return AnalysisJob


# ---------------------------------------------------------------------------
# Core task
# ---------------------------------------------------------------------------

@app.task(
    name="workers.tasks.analysis_tasks.run_analysis_task",
    bind=True,  # self = the task instance
    max_retries=0,  # don't retry — analysis is deterministic; retry won't help
    acks_late=True,  # ack only after completion (crash-safe)
)
def run_analysis_task(self, job_id: str, user_id: str, upload_id: str, llm_provider: str = "none") -> dict:
    """Run an analysis in the background.

    Args:
      job_id: UUID of the AnalysisJob row (created by the API before dispatch)
      user_id: UUID of the user who requested the analysis
      upload_id: UUID of the upload to analyze
      llm_provider: "none" | "gemini" | "openai" | "claude"

    Returns:
      Dict with job_id, status, analysis_id (if completed), error (if failed).
    """
    log.info(
        "Starting analysis task: job_id=%s user_id=%s upload_id=%s llm=%s",
        job_id, user_id, upload_id, llm_provider,
    )

    try:
        # Run the async work in a fresh event loop (Celery tasks are sync).
        result = asyncio.run(_run_analysis_async(
            job_id=uuid.UUID(job_id),
            user_id=uuid.UUID(user_id),
            upload_id=uuid.UUID(upload_id),
            llm_provider=llm_provider,
        ))
        log.info("Analysis task completed: job_id=%s analysis_id=%s", job_id, result.get("analysis_id"))
        return result

    except Exception as exc:
        log.error("Analysis task failed: job_id=%s error=%s", job_id, exc, exc_info=True)
        # Mark the job as failed in the DB
        try:
            asyncio.run(_mark_job_failed(uuid.UUID(job_id), str(exc)))
        except Exception as mark_exc:
            log.error("Failed to mark job as failed: %s", mark_exc)
        # Re-raise so Celery records the failure
        raise


# ---------------------------------------------------------------------------
# Async implementation (uses SQLAlchemy async session)
# ---------------------------------------------------------------------------

async def _run_analysis_async(
    job_id: uuid.UUID,
    user_id: uuid.UUID,
    upload_id: uuid.UUID,
    llm_provider: str,
) -> dict:
    """Async entry point — runs inside asyncio.run() from the sync task."""

    # Mark job as running
    await _update_job_status(job_id, JOB_RUNNING)

    # Lazy imports (avoid circular dependency at module load)
    import db.base as db_base
    from workspace.repositories.analyses import run_and_persist_analysis
    from billing.services.usage import record_analysis_run, check_llm_call_allowed
    from billing.services.subscriptions import get_user_plan as _get_user_plan

    factory = db_base.async_session_factory
    if factory is None:
        raise RuntimeError("Database is not configured for worker tasks.")

    async with factory() as session:
        try:
            # Phase 12 audit fix (C4): check LLM limit in worker too.
            # The API checks before dispatch, but a race condition could
            # let a job slip through (e.g. user downgrades between dispatch
            # and execution). Defense in depth.
            if llm_provider != "none":
                plan = await _get_user_plan(session, user_id)
                if plan is not None:
                    llm_allowed, llm_error = await check_llm_call_allowed(session, user_id, plan)
                    if not llm_allowed:
                        raise PermissionError(llm_error)

            # THE engine call — same function as the sync flow.
            analysis = await run_and_persist_analysis(
                db=session,
                user_id=user_id,
                upload_id=upload_id,
                llm_provider=llm_provider,
            )

            # Record usage event (analysis_run + llm_call if applicable)
            try:
                await record_analysis_run(session, user_id, analysis.id, llm_provider)
            except Exception as exc:
                log.warning("Failed to record usage event: %s", exc)

            await session.commit()

            # Mark job as completed with the analysis_id
            await _update_job_status(
                job_id, JOB_COMPLETED,
                analysis_id=analysis.id,
                total_trades=analysis.total_trades,
                overall_score=float(analysis.overall_score),
            )

            return {
                "job_id": str(job_id),
                "status": JOB_COMPLETED,
                "analysis_id": str(analysis.id),
                "total_trades": analysis.total_trades,
                "overall_score": float(analysis.overall_score),
            }

        except Exception as exc:
            await session.rollback()
            await _update_job_status(job_id, JOB_FAILED, error=str(exc))
            raise


# ---------------------------------------------------------------------------
# Job status helpers
# ---------------------------------------------------------------------------

async def _update_job_status(
    job_id: uuid.UUID,
    status: str,
    analysis_id: Optional[uuid.UUID] = None,
    error: Optional[str] = None,
    total_trades: Optional[int] = None,
    overall_score: Optional[float] = None,
) -> None:
    """Update the AnalysisJob row with the new status + result."""
    import db.base as db_base
    from workspace.models import AnalysisJob

    factory = db_base.async_session_factory
    if factory is None:
        log.warning("Cannot update job status — DB not configured")
        return

    values: dict[str, Any] = {
        "status": status,
        "updated_at": datetime.now(timezone.utc),
    }
    if analysis_id is not None:
        values["analysis_id"] = analysis_id
    if error is not None:
        values["error_message"] = error[:500]  # truncate
    if total_trades is not None:
        values["total_trades"] = total_trades
    if overall_score is not None:
        values["overall_score"] = overall_score
    if status == JOB_RUNNING:
        values["started_at"] = datetime.now(timezone.utc)
    if status in (JOB_COMPLETED, JOB_FAILED):
        values["finished_at"] = datetime.now(timezone.utc)

    async with factory() as session:
        stmt = update(AnalysisJob).where(AnalysisJob.id == job_id).values(**values)
        await session.execute(stmt)
        await session.commit()


async def _mark_job_failed(job_id: uuid.UUID, error: str) -> None:
    """Mark a job as failed (used in exception handler)."""
    await _update_job_status(job_id, JOB_FAILED, error=error)
