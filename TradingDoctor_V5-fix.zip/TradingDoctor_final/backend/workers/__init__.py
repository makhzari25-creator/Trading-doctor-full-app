# -*- coding: utf-8 -*-
"""
workers
-------
Phase 11 — Background task workers for TradingDoctor SaaS.

Provides async job processing via Celery + Redis for:
  - Long-running analyses (POST /analyses → 202 Accepted + job_id polling)
  - Email sending (verification, password reset, invoice emails)
  - Report pre-generation (warm the HTML/PDF cache)
  - Cleanup tasks (soft-delete purge, stale upload removal)

The Celery app is configured in workers.celery_app.
Tasks are defined in workers.tasks.

Design rules (carry forward from prior phases):
  - Frozen V23 engine (engines/*) is called only from workspace.repositories.analyses
    — the worker tasks call that same repository function, NOT the engine directly.
  - Workers use the same DB session factory as the API (db.base.async_session_factory).
  - Celery is OPTIONAL: the API can run without Celery (sync fallback via run_in_threadpool).
    Set TRADING_DOCTOR_USE_CELERY=true to enable async job dispatch.
  - Redis is required for Celery (broker + result backend).
"""

__all__: list[str] = []
