# -*- coding: utf-8 -*-
"""
config.py
----------
تنظیمات مرکزی پروژه. مقادیر حساس (کلید API) همیشه از متغیرهای محیطی
خوانده می‌شوند و هرگز نباید مستقیم در کد نوشته شوند.

[AUDIT FIX] قبلاً int(os.getenv(...)) و float(os.getenv(...)) مستقیماً
صدا زده می‌شدند. اگر کاربر production یک متغیر محیطی را با مقدار نامعتبر
تنظیم می‌کرد (مثلاً TRADING_DOCTOR_LLM_TIMEOUT="abc")، کل برنامه (چه CLI
چه Streamlit) در همان لحظه‌ی import با ValueError کرش می‌کرد — پیش از
اینکه حتی به هندلر خطای main.py/app.py برسد. حالا از _safe_int/_safe_float
استفاده می‌شود که مقدار نامعتبر را لاگ کرده و به مقدار پیش‌فرض امن
برمی‌گردد، تا یک تنظیمِ اشتباه هرگز کل برنامه را از کار نیندازد.
"""

import os

from utils.logger import get_logger

log = get_logger("config")


def _safe_int(env_name: str, default: int) -> int:
    raw = os.getenv(env_name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        log.warning(
            "Invalid integer in env var %s=%r, falling back to default %r",
            env_name, raw, default,
        )
        return default


def _safe_float(env_name: str, default: float) -> float:
    raw = os.getenv(env_name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        log.warning(
            "Invalid float in env var %s=%r, falling back to default %r",
            env_name, raw, default,
        )
        return default


# ------------------------------------------------------------------
# LLM Providers
# ------------------------------------------------------------------

# کدام provider پیش‌فرض برای CoachingEngine استفاده شود:
# یکی از "gemini" / "openai" / "claude" / "none"
DEFAULT_LLM_PROVIDER = os.getenv("TRADING_DOCTOR_LLM_PROVIDER", "gemini")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")

LLM_MAX_TOKENS = _safe_int("TRADING_DOCTOR_LLM_MAX_TOKENS", 1000)
LLM_TIMEOUT_SECONDS = _safe_int("TRADING_DOCTOR_LLM_TIMEOUT", 30)

# ------------------------------------------------------------------
# آستانه‌های تحلیل رفتاری (برای استفاده‌ی آینده در behavior/risk/score engine)
# ------------------------------------------------------------------

OVERTRADING_TRADES_PER_DAY = _safe_int("TRADING_DOCTOR_OVERTRADING_THRESHOLD", 5)
RISK_SIZE_MULTIPLIER = _safe_float("TRADING_DOCTOR_RISK_SIZE_MULTIPLIER", 1.5)
PATIENCE_QUICK_REENTRY_MINUTES = _safe_int("TRADING_DOCTOR_QUICK_REENTRY_MIN", 15)

# ------------------------------------------------------------------
# مسیرها
# ------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
DATA_DIR = os.path.join(BASE_DIR, "data")
