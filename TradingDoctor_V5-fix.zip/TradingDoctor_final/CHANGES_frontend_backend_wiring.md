# اتصال فرانت‌اند به بک‌اند واقعی V23 — گزارش تغییرات

این سند دقیقاً مشخص می‌کند چه فایل‌هایی اضافه/تغییر داده شدند تا فرانت‌اند اصلی Next.js
(همان ۱۴ View که قبلاً روی `mock-data.ts` کار می‌کردند) به بک‌اند واقعی FastAPI وصل شود —
بدون هیچ تغییری در منطق بک‌اند، auth/billing موجود، یا رفتار فایل‌های دیگر.

## ۱. مشکل اصلی که حل شد

فرانت‌اند و بک‌اند **دو سیستم auth کاملاً مستقل** دارند:
- Next.js: کوکی `td-session` + دیتابیس Prisma خودش.
- بک‌اند V23: `Authorization: Bearer <JWT>` + دیتابیس SQLAlchemy خودش.

هر endpoint تحلیلی بک‌اند (`get_current_user`) به JWT واقعی بک‌اند نیاز دارد. بدون تغییر در
فایل‌های auth موجود، یک «پل» جدید ساختم (`lib/server/backend-auth-bridge.ts`) که برای
کاربر لاگین‌شده‌ی Next.js، به‌صورت شفاف یک حساب معادل روی بک‌اند می‌سازد/واردش می‌شود
(پسورد آن به‌صورت قطعی از `HMAC(BRIDGE_SECRET, userId)` مشتق می‌شود، هرگز به کاربر نشان
داده نمی‌شود) و توکن‌های بک‌اند را در کوکی‌های httpOnly جداگانه (`td-backend-access` /
`td-backend-refresh`) کش می‌کند.

⚠️ چون بک‌اند به‌طور پیش‌فرض `REQUIRE_EMAIL_VERIFICATION=true` دارد، این پل خودکار در محیط
dev بدون تنظیم `TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY=false` روی بک‌اند کار نمی‌کند (به بخش ۴
مراجعه کنید).

## ۲. فایل‌های جدید (۱۷ فایل — هیچ‌کدام قبلاً وجود نداشتند)

**لایه‌ی پل/پروکسی (server-only):**
- `frontend/src/lib/server/backend-config.ts`
- `frontend/src/lib/server/session.ts`
- `frontend/src/lib/server/backend-auth-bridge.ts`
- `frontend/src/lib/server/backend-proxy.ts`

**Route Handlerهای واقعی (قبلاً پوشه‌ی `app/api/v1/` اصلاً وجود نداشت):**
- `app/api/v1/health/route.ts`
- `app/api/v1/config/route.ts` (با adapter برای تطبیق نام فیلدها با بک‌اند)
- `app/api/v1/uploads/route.ts`
- `app/api/v1/analyses/route.ts`
- `app/api/v1/analyses/[id]/route.ts`
- `app/api/v1/analyses/[id]/report/route.ts`
- `app/api/v1/analyses/[id]/report.html/route.ts`
- `app/api/v1/analyses/[id]/report.pdf/route.ts`
- `app/api/v1/analyses/jobs/[id]/route.ts`
- `app/api/v1/history/route.ts`
- `app/api/v1/workspace/analyses/[id]/route.ts` (DELETE — برای حذف تحلیل از تاریخچه)

**Hookهای React برای مصرف داده‌ی واقعی:**
- `frontend/src/lib/hooks/use-analysis-report.ts`
- `frontend/src/lib/hooks/use-history.ts`

## ۳. فایل‌های موجود که ویرایش شدند

| فایل | نوع تغییر |
|---|---|
| `views/dashboard.tsx`, `behavioral.tsx`, `diagnosis.tsx`, `coaching.tsx`, `trader-dna.tsx` | جایگزینی `mockAnalysisReport` با `useAnalysisReport()` واقعی + حالت‌های Loading/Empty/Error. منطق و JSX داخلی دست‌نخورده. |
| `views/edge-map.tsx` | همان + یک fallback امن برای فیلدهای اختیاری edge-map (چون داده‌ی واقعی برخلاف mock، همیشه همه‌ی بازه‌ها را پر نمی‌کند). |
| `views/report.tsx` | داده‌ی واقعی + دکمه‌های PDF/HTML حالا واقعاً `downloadReportPdf`/`downloadReportHtml` را صدا می‌زنند و فایل واقعی دانلود می‌کنند (قبلاً فقط toast تقلبی بود). |
| `views/charts.tsx` | اعداد خلاصه (سود خالص، میانگین سود/زیان) واقعی شدند؛ ۴ نمودار سری‌زمانی روی داده‌ی نمونه ماندند چون **بک‌اند endpoint ندارد** — با بنر صریح در UI مشخص شده. |
| `views/trends.tsx`, `history.tsx` | بازنویسی کامل روی `useHistory()` واقعی؛ حذف/دانلود PDF/باز کردن یک تحلیل قدیمی همگی واقعی شدند (قبلاً حذف فقط از state محلی پاک می‌شد، نه از سرور). |
| `views/settings.tsx` | داده‌ی نمونه به داده‌ی واقعیِ تحلیل جاری تبدیل شد. |
| `views/upload.tsx` | **مهم‌ترین تغییر**: جریان تحلیل قبلاً کاملاً با `setTimeout` شبیه‌سازی می‌شد. حالا واقعاً `uploadFile()` سپس `runAnalysis()` را صدا می‌زند، خطاهای واقعی API را نمایش می‌دهد، و شمارنده‌ی معاملات تقلبی (۱۲۴۵) حذف شد. |
| `views/trade-explorer.tsx` | **دست‌نخورده به‌عمد ماند** (فقط یک بنر/کامنت اضافه شد) چون بک‌اند هیچ endpoint برای فهرست خام معاملات ندارد — رجوع به بخش ۵. |
| `components/td/app-shell.tsx` | Badge بالای صفحه («trades_jan.csv» ثابت و جعلی) به تعداد معاملات واقعی تحلیل جاری تبدیل شد. |
| `lib/api/index.ts` | فقط یک تابع جدید `deleteAnalysis()` اضافه شد (افزایشی، هیچ export موجودی تغییر نکرد). |
| `.env.local.example` | متغیرهای محیطی جدید مورد نیاز پل مستند شدند (بخش ۴). |

## ۴. برای اجرا چه چیزی لازم است

در `.env.local` فرانت‌اند:
```
TRADING_DOCTOR_BACKEND_URL=http://localhost:8000/api/v1
TRADING_DOCTOR_BRIDGE_SECRET=<یک رشته‌ی تصادفی طولانی>
```
و روی **بک‌اند** (فقط برای محیط توسعه، تا پل بتواند بلافاصله بعد از ثبت‌نام خودکار وارد شود):
```
TRADING_DOCTOR_REQUIRE_EMAIL_VERIFY=false
```

## ۵. چیزی که همچنان واقعی نیست (و چرا)

- **۴ نمودار در `charts.tsx`** (equity curve، drawdown، توزیع P&L، P&L ساعتی) و **کل جدول `trade-explorer.tsx`**:
  بک‌اند از طریق `GET /analyses/{id}/report` این داده‌ها را برنمی‌گرداند (`ctx.pop("charts", None)`
  در `api/routers/analyses.py`) و هیچ endpoint دیگری برای فهرست خام معاملات وجود ندارد.
  به‌جای جعل این داده‌ها، هر دو صفحه با یک بنر صریح در UI مشخص شده‌اند. برای رفع کامل این
  مورد، باید یک endpoint جدید JSON روی بک‌اند اضافه شود (خارج از محدوده‌ی این تغییر، چون به
  کد Engine/backend دست نمی‌زدم).
- **حالت Celery/async** بک‌اند (`TRADING_DOCTOR_USE_CELERY=true`) پوشش داده شد: تابع جدید
  `runAnalysisWithPolling()` در `lib/api/index.ts` هم ۲۰۱ (sync) و هم ۲۰۲ (async + job_id)
  را به‌صورت شفاف هندل می‌کند و روی `GET /analyses/jobs/{id}` با timeout ۹۰ ثانیه poll می‌کند.
  `views/upload.tsx` از این تابع استفاده می‌کند.

## ۶. محدودیت اعتبارسنجی

این سند در نسخه‌ی اولیه نوشته شد چون محیط اجرای نویسنده به اینترنت دسترسی نداشت. در
نسخه‌ی فعلی (رفع ۱۳ نقطه ضعف):

- `npm install` و `npm run build` واقعاً اجرا شده‌اند.
- `next lint` با ESLint config جدید (ruleها به‌جای خاموش‌کردن کلی، روی "warn" تنظیم شده‌اند)
  اجرا شده.
- `pytest` بک‌اند با نصب کامل `requirements.txt + requirements-dev.txt` اجرا شده.
- تست‌های واحد فرانت‌اند با Vitest + React Testing Library اضافه شده و اجرا می‌شوند.

نتیجه‌ی کامل در `WORKLOG_v23_fixes.md` در ریشه‌ی پروژه آمده است.

## ۷. بهبودهای امنیتی و پایداری (v2 — رفع ۱۳ نقطه ضعف)

| # | ردیف | بهبود |
|---|------|-------|
| ۱ | نشت داده | حذف کامل پوشه‌ی `backend/data/api_runs/uploads/` (شامل ۲۶ فایل CSV واقعی کاربران) و افزودن `.gitkeep` + تقویت `.gitignore` |
| ۲-۴ | artifactهای build/runtime | حذف `.pytest_cache`، `tsconfig.tsbuildinfo`، `trading_doctor.log` و قوی‌تر کردن `.gitignore` برای جلوگیری از بازگشت |
| ۵ | setState در useEffect | refactor اصولی ۷ فایل React با `useSyncExternalStore` (use-mobile, ThemeToggle)، React Query (use-history, use-analysis-report)، microtask deferral (carousel, upload)، و الگوی key-reset (auth/index) |
| ۶ | وابستگی‌های تست | تفکیک `requirements.txt` (runtime) از `requirements-dev.txt` (تست/lint) و به‌روزرسانی CI برای نصب هر دو |
| ۷ | ESLint بی‌فایده | فعال‌سازی تدریجی ruleها به‌جای خاموش‌کردن کلی؛ ruleهای امن‌کننده روی "warn"، ruleهای پرتخلف با کامنت `TODO(gradual)` روی "off" |
| ۸ | حجم ZIP | با حذف artifactهای ردیف ۲-۴ به ۵.۸ مگابایت رسیدیم |
| ۹ | ناهماهنگی مستند | همین بخش اضافه شد |
| ۱۰ | نبود تست فرانت‌اند | افزودن Vitest + React Testing Library + ۳ فایل تست نمونه (DemoDataBanner، ApiError، useIsMobile) |
| ۱۱ | امنیت پل auth | `BRIDGE_SECRET` در production باید حداقل ۳۲ کاراکتر باشد (در غیر این صورت throw می‌شود)؛ توکن‌ها با TTL کوتاه‌تر از خود JWT کش می‌شوند |
| ۱۲ | بنر داده‌ی نمایشی | کامپوننت جدید `DemoDataBanner` با رنگ warning و role=status + aria-live=polite، جایگزین بنر کم‌رنگ قبلی در `charts.tsx` و `trade-explorer.tsx` |
| ۱۳ | پشتیبانی Celery | تابع جدید `runAnalysisWithPolling()` + `pollAnalysisJob()` در `lib/api/index.ts` |

## ۸. اتصال کامل Charts و Trade Explorer (v3 — رفع کامل mock)

این بخش آخرین باقی‌مانده‌ی صفحات mock را به‌صورت کامل به بک‌اند واقعی وصل می‌کند.
پس از این تغییر، هیچ صفحه‌ای از فرانت‌اند از `mock-data.ts` استفاده نمی‌کند و
فایل `lib/mock-data.ts` به‌طور کامل حذف شد.

### ۸.۱ — Backend: فیلد `charts` در report + endpoint `/analyses/{id}/trades`

**فایل جدید:** `backend/reporting/chart_data.py`
- توابع استخراج سری‌های JSON-serializable از همان DataFrame خام معاملات
  (`doctor.df`) که موتور V23 روی آن اجرا شده.
- فرمول‌ها دقیقاً همان `reporting/charts.py` (PNG) هستند:
  - `equity_curve`: `Profit.cumsum()`
  - `drawdown`: `equity - equity.cummax()`
  - `pnl_distribution`: `np.histogram(profit, bins=N)`
  - `hourly_pnl`: `groupby(Profit, hour=OpenTime.dt.hour)`
  - `weekday_pnl`: `groupby(Profit, weekday=OpenTime.dt.day_name())`
  - `win_loss_pie`: counts of Profit > 0 / < 0 / == 0
- تابع `extract_trades_list(df, page, page_size, side, outcome)` فهرست خام
  معاملات را با pagination و فیلتر سمت/نتیجه برمی‌گرداند.

**فایل تغییر کرده:** `backend/api/routers/analyses.py`
- endpoint `GET /analyses/{id}/report`: حالا `ctx["charts"] = build_chart_series(df)`
  را اضافه می‌کند (قبلاً `ctx.pop("charts", None)` بود).
- endpoint جدید `GET /analyses/{id}/trades?page=1&page_size=50&side=Long&outcome=win`
  برای فهرست خام معاملات با pagination و فیلتر اختیاری.

**فایل تغییر کرده:** `backend/api/models/analysis.py`
- `AnalysisReport.charts: Dict[str, Any]` با default `{}` اضافه شد (برای
  backward-compat با گزارش‌های قدیمی).
- مدل جدید `TradesResponse` برای endpoint trades.

**فایل تغییر کرده:** `backend/api/exceptions.py`
- `ValidationError` (HTTP 422) اضافه شد برای فیلترهای نامعتبر در `/trades`.

**فایل جدید:** `backend/conftest.py`
- rate-limit را برای کل session تست غیرفعال می‌کند تا از تداخل cross-test
  جلوگیری شود. تست‌هایی که به‌طور صریح rate-limit را بررسی می‌کنند (مثلاً
  `test_rate_limit_enforced`) آن را به‌صورت local با `monkeypatch` فعال می‌کنند.

### ۸.۲ — Backend: تست‌های جدید (۷ تست)

`tests/test_api.py`:
- `test_report_includes_charts_field` — charts در report موجود است و ۶ سری
  با ساختار درست دارد.
- `test_trades_endpoint_returns_paginated_list` — pagination صحیح، total
  برابر با تعداد معاملات، فیلد id از ۱ شروع می‌شود.
- `test_trades_endpoint_filters_by_side` — `?side=Long` فقط Long برمی‌گرداند.
- `test_trades_endpoint_filters_by_outcome` — `?outcome=win` فقط profit > 0.
- `test_trades_endpoint_rejects_invalid_side` — `?side=Invalid` → 422.
- `test_trades_endpoint_requires_auth` — بدون Authorization → 401.
- `test_trades_endpoint_respects_multi_tenant_isolation` — user A نمی‌تواند
  trades کاربر B را بخواند → 404.

### ۸.۳ — Frontend: حذف کامل mock و اتصال به داده‌ی واقعی

**فایل حذف شد:** `frontend/src/lib/mock-data.ts`
- قبلاً شامل `mockAnalysisReport`, `mockTrades`, `mockHistory`,
  `mockEquityCurve`, `mockDrawdown`, `mockPnLDistribution`, `mockHourlyPnL`.
- هیچ فایل دیگری از این ماژول import نمی‌کند (تأیید با grep).

**فایل جدید:** `frontend/src/lib/hooks/use-trades.ts`
- hook با TanStack Query برای fetch `/analyses/{id}/trades`.
- همان الگوی `use-history` و `use-analysis-report` (همگی روی TanStack Query).

**فایل جدید:** `frontend/src/app/api/v1/analyses/[id]/trades/route.ts`
- proxy route برای `/analyses/{id}/trades` (مثل سایر proxy routes).

**فایل تغییر کرد:** `frontend/src/lib/types.ts`
- اینترفیس‌های جدید: `ChartSeries`, `EquityCurvePoint`, `DrawdownPoint`,
  `PnLDistributionPoint`, `HourlyPnLPoint`, `WeekdayPnLPoint`, `WinLossPie`.
- `AnalysisReport.charts: ChartSeries` به اینترفیس اضافه شد.

**فایل تغییر کرد:** `frontend/src/lib/api/index.ts`
- `GetTradesParams.side` از `"long"|"short"` (که با backend همخوانی نداشت)
  به `"Long"|"Short"` تغییر کرد.

**فایل تغییر کرد:** `frontend/src/views/charts.tsx`
- حذف کامل import از `mock-data`.
- حذف کامپوننت `DemoDataBanner` (دیگر نیازی نیست — داده واقعی است).
- استفاده از `r.charts.equity_curve`, `r.charts.drawdown`,
  `r.charts.pnl_distribution`, `r.charts.hourly_pnl` برای رسم نمودارها.
- هر نمودار حالا حالت empty-state دارد (اگر داده‌ای نباشد، پیام نمایش داده می‌شود).
- Tooltipها با formatter فارسی برای مقادیر و labels.

**فایل تغییر کرد:** `frontend/src/views/trade-explorer.tsx`
- حذف کامل import از `mock-data`.
- حذف کامپوننت `DemoDataBanner`.
- بازنویسی جدول با `@tanstack/react-table` (که قبلاً در package.json بود ولی
  استفاده نمی‌شد):
  - `useReactTable` با `getCoreRowModel`, `getFilteredRowModel`,
    `getSortedRowModel`, `getPaginationRowModel`.
  - تعریف `COLUMNS` با `accessorKey` و `cell` formatter برای رنگ و اعداد فارسی.
  - کلیک روی row → باز شدن Drawer با جزئیات معامله.
- فیلتر side/outcome در state محلی انجام می‌شود (روی صفحه‌ی بارگذاری‌شده)
  تا chip toggleها بدون round-trip به سرور feel instantaneous داشته باشند.
- pagination client-side (PAGE_SIZE = 20 روی صفحه‌ی 200تایی از سرور).

### ۸.۴ — نتیجه‌ی تست‌ها

| لایه | نتیجه |
|---|---|
| Backend `pytest tests/` | ✅ **۲۴۱ تست پاس** (۲۳۴ اصلی + ۷ تست v3) — ۰ شکست در ۷۱ ثانیه |
| Frontend `vitest run` | ✅ **۱۲ تست پاس** — ۰ شکست در ۳ ثانیه |
| Frontend `next build` | ✅ **موفق** در ۱۱ ثانیه — ۲۷ route (۲ static + ۲۵ dynamic، شامل `/api/v1/analyses/[id]/trades` جدید) |
| Frontend `npm run lint` | ✅ **۰ خطا**، ۱۱۰ هشدار (۱۰۹ legacy + ۱ هشدار React Compiler روی `useReactTable` که رفتار شناخته‌شده‌ی کتابخانه است) |



## ۹. Merge Auth to Single Source (FastAPI) — v4

این بخش آخرین بخش از معماری موازی را حذف می‌کند: سیستم auth مستقل Next.js
(Prisma + next-auth + td-session cookie) که در کنار FastAPI auth وجود داشت.
از این پس FastAPI تنها منبع احراز هویت است و فرانت‌اند فقط از طریق
httpOnly cookies با آن صحبت می‌کند.

### ۹.۱ — Design decisions

| تصمیم | انتخاب | دلیل |
|---|---|---|
| Bridge strategy | ساده‌سازی کامل | حذف HMAC + shadow account؛ توکن مستقیماً از cookie خوانده می‌شود |
| Frontend routes | حذف + proxy جدید | تمام ۱۲ route قدیمی `/api/auth/*` حذف، ۸ route جدید `/api/v1/auth/*` + ۳ route `/api/v1/me/*` |
| Token storage | فقط httpOnly cookie | JavaScript به توکن دسترسی ندارد → حذف attack surface برای XSS token theft |
| Prisma | حذف کامل | schema، @prisma/client، prisma CLI، postinstall script همگی حذف |
| next-auth | حذف کامل | package از package.json حذف، NEXTAUTH_SECRET env var حذف |
| Migration | Fresh start | این dev/test است، بدون داده‌ی production |

### ۹.۲ — Frontend: حذف فایل‌ها

**حذف شد:**
- `frontend/prisma/` (تمام schema و migrations)
- `frontend/src/lib/db.ts` (Prisma client singleton)
- `frontend/src/lib/auth/` (csrf، audit-log، email، rate-limiter)
- `frontend/src/app/api/auth/` (تمام ۱۲ route قدیمی: login، register، verify-email، forgot-password، reset-password، profile، sessions، login-history، logout، avatar، resend-verification، session)
- ۵ dependency از package.json: `@prisma/client`، `prisma`، `next-auth`، `bcryptjs`، `jsonwebtoken` (و type packages مربوطه)
- ۶ script از package.json: `postinstall`، `db:push`، `db:generate`، `db:setup`، `db:migrate`، `db:reset`

### ۹.۳ — Frontend: فایل‌های جدید

**`frontend/src/lib/server/auth-cookies.ts`** (جدید)
- `setAuthCookies(tokens)` — set httpOnly `td-access` + `td-refresh` cookies با SameSite=lax، Secure در production، 30s buffer قبل از انقضای واقعی.
- `clearAuthCookies()` — پاک کردن هر دو cookie (logout / auth failure).

**`frontend/src/app/api/v1/auth/login/route.ts`** — POST: دریافت email/password، فراخوانی `loginBackend()`، set cookies، return user profile.
**`frontend/src/app/api/v1/auth/register/route.ts`** — POST: forward به `POST /auth/register` بک‌اند.
**`frontend/src/app/api/v1/auth/logout/route.ts`** — POST: فراخوانی `POST /auth/logout` بک‌اند (best-effort)، سپس clear cookies.
**`frontend/src/app/api/v1/auth/refresh/route.ts`** — POST: فراخوانی `refreshBackendTokens()`، rotate cookies.
**`frontend/src/app/api/v1/auth/session/route.ts`** — GET: فراخوانی `getSessionUser()`، return `{ user }` یا `{ user: null }`.
**`frontend/src/app/api/v1/auth/verify-email/route.ts`** — POST: forward به `/auth/verify-email`.
**`frontend/src/app/api/v1/auth/resend-verification/route.ts`** — POST: forward به `/auth/resend-verification`.
**`frontend/src/app/api/v1/auth/password-reset/request/route.ts`** — POST: forward به `/auth/password-reset/request`.
**`frontend/src/app/api/v1/auth/password-reset/confirm/route.ts`** — POST: forward به `/auth/password-reset/confirm`.
**`frontend/src/app/api/v1/me/route.ts`** — GET/PATCH/DELETE: proxy به `/me` (profile read/update/delete).
**`frontend/src/app/api/v1/me/password/route.ts`** — POST: proxy به `/me/password` (change password) + clear cookies روی موفقیت.
**`frontend/src/app/api/v1/me/activity/route.ts`** — GET: proxy به `/me/activity` (audit log).

### ۹.۴ — Frontend: فایل‌های تغییر کرده

**`frontend/src/lib/store/auth-store.ts`** (بازنویسی)
- حذف `sessionToken` field و `setSession` action.
- فقط `user` را نگه می‌دارد (id، email، name، role، image، emailVerified) — توکن‌ها هرگز در JS-visible state ذخیره نمی‌شوند.

**`frontend/src/lib/server/session.ts`** (بازنویسی)
- حذف Prisma lookup و NEXTAUTH_SECRET.
- `getAccessToken()` — خواندن از httpOnly cookie `td-access`.
- `getRefreshToken()` — خواندن از httpOnly cookie `td-refresh`.
- `getSessionUser()` — فراخوانی `GET /me` با access token (cached per-request با React `cache()`).

**`frontend/src/lib/server/backend-auth-bridge.ts`** (بازنویسی)
- حذف HMAC، shadow account، BRIDGE_SECRET برای password derivation.
- `getBackendAccessToken()` — حالا فقط `getAccessToken()` را wrap می‌کند.
- `refreshBackendTokens()` — فراخوانی `POST /auth/refresh` با refresh cookie.
- `loginBackend(email, password)` — فراخوانی `POST /auth/login` و return `{ tokens, user }`.

**`frontend/src/lib/server/backend-config.ts`** (بازنویسی)
- حذف validation پیچیده BRIDGE_SECRET.
- افزودن `ACCESS_COOKIE`، `REFRESH_COOKIE`، `cookieSecure()`، `COOKIE_SAME_SITE` constants.
- BRIDGE_SECRET به‌عنوان deprecated نگه داشته شد برای backward compat با env files موجود.

**`frontend/src/lib/server/backend-proxy.ts`** (تغییر)
- `resolveAuth()` حالا فقط `getBackendAccessToken()` را صدا می‌زند (بدون Prisma lookup).
- حذف import `getSessionUser` و `BackendBridgeError` از این فایل.

**`frontend/src/views/auth/index.tsx`** (تغییرات گسترده)
- حذف CSRF token helper (cookie-based auth دیگر نیازی به CSRF header ندارد).
- `LoginView`: از `setUser(user)` به‌جای `setSession(user, token)`؛ فراخوانی `/api/v1/auth/login`.
- `RegisterView`: فراخوانی `/api/v1/auth/register` با `full_name` (نه `name`)؛ auto-login با `/api/v1/auth/login`.
- `ForgotPasswordView`: فراخوانی `/api/v1/auth/password-reset/request`.
- `ResetPasswordView`: فراخوانی `/api/v1/auth/password-reset/confirm` با `new_password`.
- `VerifyEmailView`: فراخوانی `/api/v1/auth/verify-email`.
- `ProfileView`: حذف `sessionToken`، حذف `isUploadingAvatar`، حذف `handleAvatarUpload`، فراخوانی `/api/v1/me` (PATCH) با `full_name`، `/api/v1/me/password` با `current_password` + `new_password`، `/api/v1/auth/logout`، `/api/v1/auth/resend-verification`.
- `SecurityView`: حذف `/api/auth/sessions` و `/api/auth/login-history`، استفاده از `/api/v1/me/activity` (audit log بک‌اند که هم login events و هم password changes و غیره را شامل می‌شود).
- حذف imports بلااستفاده: `Camera`، `Monitor`، `Trash`.

**`frontend/src/app/page.tsx`** (تغییر)
- session check حالا `/api/v1/auth/session` را صدا می‌زند (به‌جای `/api/auth/session`).

**`frontend/package.json`** (تغییر)
- حذف ۵ dependency و ۶ script مربوط به Prisma/next-auth.
- نصب مجدد: ۸۸۹ package (در مقایسه با ۹۶۵ در v3 — ۷۶ package کمتر).

**`frontend/.env.example`** و **`frontend/.env.local.example`** (بازنویسی)
- حذف DATABASE_URL، DIRECT_URL، NEXTAUTH_SECRET، NEXTAUTH_URL، TRADING_DOCTOR_BRIDGE_SECRET.
- فقط TRADING_DOCTOR_BACKEND_URL و NEXT_PUBLIC_API_BASE_URL باقی ماند.

### ۹.۵ — Backend: بدون تغییر

موتور V23، APIهای موجود، auth endpoints (login، register، refresh، logout، verify-email، password-reset، /me، /me/password، /me/activity)، reporting، billing، workspace — همه دست‌نخورده باقی ماندند. فقط frontend با آن‌ها صحبت می‌کند.

تأیید: `pytest tests/` → ۲۴۱ تست پاس (بدون تغییر نسبت به v3).

### ۹.۶ — نتیجه‌ی تست‌ها (هر سه لایه پاس شد)

| لایه | نتیجه | زمان |
|---|---|---|
| Backend `pytest tests/` | ✅ **۲۴۱ تست پاس** — ۰ شکست | ۷۱ ثانیه |
| Frontend `vitest run` | ✅ **۱۲ تست پاس** — ۰ شکست | ۳ ثانیه |
| Frontend `next build` | ✅ **موفق** در ۱۱.۶ ثانیه — ۲۷ route (۲ static + ۲۵ dynamic) | — |
| Frontend `npm run lint` | ✅ **۰ خطا**، ۱۰۱ هشدار (کاهش از ۱۱۰ — حذف کد legacy) | — |

### ۹.۷ — مسیرهای جدید در next build

```
├ ƒ /api/v1/auth/login                     (NEW — was /api/auth/login)
├ ƒ /api/v1/auth/logout                    (NEW — was /api/auth/logout)
├ ƒ /api/v1/auth/password-reset/confirm    (NEW — was /api/auth/reset-password)
├ ƒ /api/v1/auth/password-reset/request    (NEW — was /api/auth/forgot-password)
├ ƒ /api/v1/auth/refresh                   (NEW — token rotation)
├ ƒ /api/v1/auth/register                  (NEW — was /api/auth/register)
├ ƒ /api/v1/auth/resend-verification       (NEW — was /api/auth/resend-verification)
├ ƒ /api/v1/auth/session                   (NEW — was /api/auth/session)
├ ƒ /api/v1/auth/verify-email              (NEW — was /api/auth/verify-email)
├ ƒ /api/v1/me                             (NEW — was /api/auth/profile)
├ ƒ /api/v1/me/activity                    (NEW — was /api/auth/login-history + /api/auth/sessions)
├ ƒ /api/v1/me/password                    (NEW — was /api/auth/profile PATCH)
```

### ۹.۸ — حفظ تمام کارهای قبلی

- ✅ Charts و Trade Explorer روی داده‌ی واقعی (از v3)
- ✅ Celery polling (`runAnalysisWithPolling`) — دست‌نخورده
- ✅ DemoDataBanner حذف‌شده از charts/trade-explorer (حالا داده واقعی است) — دست‌نخورده
- ✅ Vitest تست‌ها (۱۲ تست) — همه پاس
- ✅ ESLint rules تدریجی — ۰ خطا
- ✅ conftest.py برای rate-limit در تست — دست‌نخورده
- ✅ httpx در requirements-dev.txt — دست‌نخورده
- ✅ backend/reporting/chart_data.py — دست‌نخورده
- ✅ موتور V23 — دست‌نخورده
