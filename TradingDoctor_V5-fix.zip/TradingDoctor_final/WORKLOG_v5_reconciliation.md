# WORKLOG v5 — Reconciliation + bug fixes

**ورودی:** `TradingDoctor_V23_fixed_v4.zip`
**خروجی:** `TradingDoctor_V5.zip`

## زمینه
نسخه‌های v2/v3/v4 ظاهراً از روی یک zip قدیمی‌تر (خروجی اول یک بازبینی جدا،
پیش از رفع موارد N+1/race-condition/BillingError/S3) شاخه زده بودند —
نه از روی نسخه‌ی نهایی‌تر که آن رفع‌ها را داشت. نتیجه: کار خوب v4 روی
ادغام سیستم auth (`WORKLOG_v4_auth_merge.md`) حفظ شد، اما ۴ رفع قبلی
بی‌سروصدا از بین رفته بودند. این نسخه (v5) هر دو خط کار را با هم آشتی
می‌دهد.

## ۱. رگرسیون‌هایی که در v4 پیدا و دوباره اعمال شدند

| مورد | فایل | تغییر |
|---|---|---|
| N+1 در زنجیره‌ی Refresh Token | `auth/services/tokens.py` | `_revoke_token_family` از لوپ per-hop SELECT به یک کوئری واحد + پیمایش in-memory |
| Race condition در Account Lockout | `auth/services/users.py` | `update_login_failure` از read-modify-write پایتونی به `UPDATE ... RETURNING` اتمیک |
| BillingError → 5xx | `billing/exceptions.py` (بازسازی شد)، `billing/services/subscriptions.py`، `billing/routers/billing.py` | `ValueError`/`AuthError` نامناسب جایگزین با `BillingError`/`PlanNotFoundError`/`NoStripeCustomerError`/`NoActiveSubscriptionError` (400/404) شد؛ تست `test_checkout_rejects_free_tier` هم به‌روزرسانی شد |
| S3 Storage — بلاک‌کردن event loop | `workspace/services/storage.py`, `requirements.txt` | فراخوانی‌های sync boto3 داخل `run_in_threadpool` پیچیده شدند؛ `boto3` به requirements اضافه شد |

## ۲. باگ‌های جدیدی که در v4 پیدا و رفع شدند

### الف) Import مرده‌ی Prisma
`frontend/scripts/verify-supabase-tables.ts` بعد از حذف کامل Prisma در
ادغام auth (v4) هنوز `import { PrismaClient } from "@prisma/client"`
داشت — چون آن پکیج دیگر در `package.json` نیست، `tsc --noEmit` fail
می‌شد. این اسکریپت یک ابزار دیباگ برای معماری قدیمی (دسترسی مستقیم
Next.js به Postgres از طریق Prisma) بود؛ چون بعد از ادغام auth،
فرانت‌اند دیگر هیچ دسترسی مستقیمی به دیتابیس ندارد (همه‌چیز از طریق
`/api/v1/*` بک‌اند proxy می‌شود)، این اسکریپت کاملاً بلااستفاده شده بود
— **حذف شد** (تنها فایلی که نسبت به v4 از پروژه کم شده، و مستنداً به
همین دلیل).

### ب) داده‌ی فیک `side` (Long/Short) در Trade Explorer
`reporting/chart_data.py::_derive_side` وقتی ستون صریح Side/Type وجود
نداشت، حدس می‌زد: «Size ≤ 0 یعنی Short، وگرنه Long». اما
`utils/column_mapper.py` نشان می‌دهد Size همیشه یک مقدار حجم غیرمنفی
(lots/qty/volume) است و هرگز علامتِ جهت را کدگذاری نمی‌کند — یعنی این
فالبک عملاً همیشه «Long» برمی‌گرداند، برای هر فایل واقعی. این یعنی
فیلتر Long/Short در Trade Explorer داده‌ی گمراه‌کننده به کاربر نشان
می‌داد.

**رفع:** `_derive_side` دیگر حدس نمی‌زند — وقتی ستون صریح Side/Type
نباشد، `None` برمی‌گرداند. یک فیلد جدید `side_available: bool` به
`TradesResponse` (بک‌اند: `api/models/analysis.py`؛ فرانت‌اند:
`lib/types.ts`) اضافه شد تا فرانت‌اند بداند آیا اصلاً داده‌ی جهت برای
این دیتاست وجود دارد یا نه. در `views/trade-explorer.tsx`:
  - چیپ‌های فیلتر Long/Short وقتی `side_available === false` باشد
    مخفی می‌شوند (به‌جای نمایش همیشگی یک فیلتر بی‌نتیجه).
  - `side: null` به‌صورت «—» نمایش داده می‌شود (جدول، کارت‌ها، drawer
    جزئیات، خروجی CSV) — نه رشته‌ی خام `"null"`.
  - رنگ‌بندی (`sideColor`) برای `side` نامعلوم یک رنگ خنثی برمی‌گرداند
    (نه رنگ ضرر که برای Short استفاده می‌شود).

دو تست بک‌اند (`test_trades_endpoint_returns_paginated_list`,
`test_trades_endpoint_filters_by_side`) که قبلاً همین حدسِ نادرست را
به‌عنوان رفتار «درست» تست می‌کردند (و تست Short با `all()` روی یک
لیست خالی همیشه بی‌معنی pass می‌شد) اصلاح شدند؛ یک تست جدید
(`test_trades_endpoint_side_unavailable_without_direction_column`)
اضافه شد که رفتار صادقانه (side=None + side_available=False + فیلتر
خالی) را روی دیتاست بدون ستون جهت تأیید می‌کند، و fixture تست
(`_sample_csv_bytes`) یک حالت اختیاری `with_side=True` گرفت تا فیلتر
Long/Short واقعاً هم روی داده‌ی واقعی تست شود.

## ۳. تأیید نهایی (همه واقعاً اجرا شدند، نه فقط ادعا)

| بررسی | نتیجه |
|---|---|
| `pytest` (بک‌اند) — ۲ بار پشت‌سرهم از نصب تازه | ✅ ۲۴۲/۲۴۲ پاس (۲۴۱ قبلی + ۱ تست جدید) |
| `npx tsc --noEmit` (فرانت‌اند) | ✅ ۰ خطا (قبلاً به‌خاطر import مرده‌ی Prisma fail می‌شد) |
| `npx eslint .` (فرانت‌اند) | ✅ ۰ خطا |
| `npx vitest run` (فرانت‌اند) | ✅ ۱۲/۱۲ پاس |
| `npx next build` | ⚠️ در sandbox این بازبینی به‌خاطر بلاک‌بودن fonts.googleapis.com قابل تأیید نبود — محدودیت شبکه‌ی محیط بازبینی، نه لزوماً باگ پروژه |
| مقایسه‌ی فایل‌به‌فایل با v4 | فقط یک فایل عمداً حذف شده (بخش ۲-الف)؛ چیز دیگری گم نشده |

## آنچه هنوز خارج از این بازبینی مانده
مهاجرت کامل صفحات باقی‌مانده (Dashboard/Behavioral/Diagnosis/Coaching/
Trader DNA/Edge Map/Trends) از `mock-data.ts` — این بخش از قبل هم در
scope هیچ‌کدام از v1 تا v5 نبوده و نیاز به یک پاس جداگانه دارد.
