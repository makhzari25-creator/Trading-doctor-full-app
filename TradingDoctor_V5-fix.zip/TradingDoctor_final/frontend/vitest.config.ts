/**
 * Vitest configuration — frontend unit tests.
 *
 * Uses jsdom so any component reading `window`/`document` works out of the box,
 * and @vitejs/plugin-react for JSX transform. The `@/` alias matches the one
 * defined in `tsconfig.json`.
 *
 * PostCSS / CSS imports are stubbed out — none of our unit tests need
 * real CSS rendering, and the project's PostCSS config uses Tailwind v4's
 * plugin which Vite can't load outside of a Next.js context.
 */
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  plugins: [
    react(),
    {
      name: "stub-css",
      enforce: "pre",
      resolveId(id) {
        if (id.endsWith(".css") || id.endsWith(".css?url")) return id;
        return null;
      },
      load(id) {
        if (id.endsWith(".css") || id.endsWith(".css?url")) return "";
        return null;
      },
    },
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  css: {
    postcss: { plugins: [] },
  },
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./vitest.setup.ts"],
    include: [
      "src/**/*.{test,spec}.{ts,tsx}",
      "src/**/__tests__/**/*.{ts,tsx}",
    ],
    exclude: ["node_modules/**", ".next/**", "out/**", "build/**"],
    coverage: {
      provider: "v8",
      reporter: ["text", "html"],
      include: ["src/**/*.{ts,tsx}"],
      exclude: [
        "src/**/*.d.ts",
        "src/**/*.test.{ts,tsx}",
        "src/**/*.spec.{ts,tsx}",
        "src/**/__tests__/**",
        "src/**/types.ts",
      ],
    },
  },
});

