#!/bin/bash

# 将 stderr 重定向到 stdout，避免 execute_command 因为 stderr 输出而报错
exec 2>&1

set -e

# 获取脚本所在目录（.zscripts 目录，即 workspace-agent/.zscripts）
# 使用 $0 获取脚本路径（兼容 sh 和 bash）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Next.js 项目路径
NEXTJS_PROJECT_DIR="/home/z/my-project"

# 检查 Next.js 项目目录是否存在
if [ ! -d "$NEXTJS_PROJECT_DIR" ]; then
    echo "❌ 错误: Next.js 项目目录不存在: $NEXTJS_PROJECT_DIR"
    exit 1
fi

echo "🚀 开始构建 Next.js 应用和 mini-services..."
echo "📁 Next.js 项目路径: $NEXTJS_PROJECT_DIR"

# 切换到 Next.js 项目目录
cd "$NEXTJS_PROJECT_DIR" || exit 1

# 设置环境变量
export NEXT_TELEMETRY_DISABLED=1

# ──────────────────────────────────────────────────────────────────────────
# Load .env.production to override platform-injected SQLite DATABASE_URL
# The z.ai platform /start.sh overwrites /home/z/my-project/.env with a SQLite
# URL on every boot (lines 70 and 98 of /start.sh). It does NOT touch
# .env.production. So we source .env.production here to get the real PostgreSQL
# URLs, and export them to override the platform's SQLite value.
# ──────────────────────────────────────────────────────────────────────────
echo ""
echo "=== Load .env.production ==="
ENV_FILE="/home/z/my-project/.env.production"
if [ -f "$ENV_FILE" ]; then
    echo "📦 Loading $ENV_FILE..."
    set -a
    . "$ENV_FILE"
    set +a
    export DATABASE_URL
    export DIRECT_URL
    export NEXTAUTH_SECRET
    export NEXTAUTH_URL
else
    echo "⚠️  .env.production not found at $ENV_FILE"
fi

echo ""
echo "=== Environment validation ==="
echo "DATABASE_URL=${DATABASE_URL:-(not set)}"
echo "DIRECT_URL=${DIRECT_URL:-(not set)}"
echo "NEXTAUTH_SECRET=${NEXTAUTH_SECRET:+(set)}"
if [ -z "$DATABASE_URL" ]; then
    echo ""
    echo "❌ DATABASE_URL is not set."
    echo "   Create .env.production with the following variables:"
    echo "   - DATABASE_URL  (Supabase transaction pooler, port 6543, with ?pgbouncer=true)"
    echo "   - DIRECT_URL    (Supabase session pooler, port 5432)"
    echo "   - NEXTAUTH_SECRET"
    echo "   - NEXTAUTH_URL"
    exit 1
fi
if [ -z "$DIRECT_URL" ]; then
    echo ""
    echo "❌ DIRECT_URL is not set."
    echo "   DIRECT_URL is required by prisma db push (used by Prisma CLI for migrations)."
    echo "   Set DIRECT_URL in .env.production to your Supabase session pooler connection string (port 5432)."
    exit 1
fi
# Export to override any SQLite value that z.ai's /start.sh wrote to .env
export DATABASE_URL
export DIRECT_URL

BUILD_DIR="/tmp/build_fullstack_$BUILD_ID"
echo ""
echo "📁 清理并创建构建目录: $BUILD_DIR"
mkdir -p "$BUILD_DIR"

# 安装依赖
echo "📦 安装依赖..."
bun install

# ──────────────────────────────────────────────────────────────────────────
# Prisma Generate + DB Push
# This is the critical step — the schema MUST be applied to Supabase before
# the app can serve any auth request. We do NOT swallow errors. If db:push
# fails, build.sh aborts here and the deployment fails with the real error.
# ──────────────────────────────────────────────────────────────────────────
echo ""
echo "=== prisma generate ==="
bun run db:generate

echo ""
echo "=== prisma db push ==="
echo "Pushing schema to Supabase (DIRECT_URL)..."
echo ""
# IMPORTANT: do NOT wrap in `|| true` or `|| { warn }`. We want the real
# error to surface and we want build.sh to abort if db:push fails.
bun run db:push
echo ""
echo "✓ Schema pushed successfully. Tables created:"
echo "  - User"
echo "  - Account"
echo "  - Session"
echo "  - VerificationToken"
echo "  - PasswordResetToken"
echo "  - LoginEvent"

# 构建 Next.js 应用
echo ""
echo "🔨 构建 Next.js 应用..."
bun run build

# 构建 mini-services
# 检查 Next.js 项目目录下是否有 mini-services 目录
if [ -d "$NEXTJS_PROJECT_DIR/mini-services" ]; then
    echo "🔨 构建 mini-services..."
    # 使用 workspace-agent 目录下的 mini-services 脚本
    sh "$SCRIPT_DIR/mini-services-install.sh"
    sh "$SCRIPT_DIR/mini-services-build.sh"

    # 复制 mini-services-start.sh 到 mini-services-dist 目录
    echo "  - 复制 mini-services-start.sh 到 $BUILD_DIR"
    cp "$SCRIPT_DIR/mini-services-start.sh" "$BUILD_DIR/mini-services-start.sh"
    chmod +x "$BUILD_DIR/mini-services-start.sh"
else
    echo "ℹ️  mini-services 目录不存在，跳过"
fi

# 将所有构建产物复制到临时构建目录
echo "📦 收集构建产物到 $BUILD_DIR..."

# 复制 Next.js standalone 构建输出
if [ -d ".next/standalone" ]; then
    echo "  - 复制 .next/standalone"
    mkdir -p "$BUILD_DIR/next-service-dist/"
    cp -r .next/standalone/. "$BUILD_DIR/next-service-dist/"

    # ⚠️ 关键：删除 standalone 内嵌的 .env 文件
    # Next.js 在 standalone 构建时会将项目根目录的 .env 复制到 .next/standalone/.env。
    # 但 z.ai 平台的 /start.sh 会用 SQLite URL 覆盖项目根 .env，导致 standalone 包
    # 内的 .env 也是 SQLite URL。Prisma 会优先加载此 .env 而非 z.ai 运行时设置的环境变量。
    # 删除此文件，确保运行时使用 z.ai 环境变量中配置的 DATABASE_URL / DIRECT_URL。
    if [ -f "$BUILD_DIR/next-service-dist/.env" ]; then
        echo "  - 删除 standalone 内嵌的 .env (使用运行时环境变量)"
        rm -f "$BUILD_DIR/next-service-dist/.env"
    fi
else
    echo "❌ 未找到 .next/standalone —— next.config.ts 必须设置 output: \"standalone\""
    exit 1
fi

# 复制 Next.js 静态文件
if [ -d ".next/static" ]; then
    echo "  - 复制 .next/static"
    mkdir -p "$BUILD_DIR/next-service-dist/.next"
    cp -r .next/static "$BUILD_DIR/next-service-dist/.next/"
fi

# 复制 public 目录
if [ -d "public" ]; then
    echo "  - 复制 public"
    cp -r public "$BUILD_DIR/next-service-dist/"
fi

# 复制 Caddyfile（如果存在）
if [ -f "Caddyfile" ]; then
    echo "  - 复制 Caddyfile"
    cp Caddyfile "$BUILD_DIR/"
else
    echo "ℹ️  Caddyfile 不存在，跳过"
fi

# 复制 start.sh 脚本
echo "  - 复制 start.sh 到 $BUILD_DIR"
cp "$SCRIPT_DIR/start.sh" "$BUILD_DIR/start.sh"
chmod +x "$BUILD_DIR/start.sh"

# 打包到 $BUILD_DIR.tar.gz
PACKAGE_FILE="${BUILD_DIR}.tar.gz"
echo ""
echo "📦 打包构建产物到 $PACKAGE_FILE..."
cd "$BUILD_DIR" || exit 1
tar -czf "$PACKAGE_FILE" .
cd - > /dev/null || exit 1

# # 清理临时目录
# rm -rf "$BUILD_DIR"

echo ""
echo "✅ 构建完成！所有产物已打包到 $PACKAGE_FILE"
echo "📊 打包文件大小:"
ls -lh "$PACKAGE_FILE"
