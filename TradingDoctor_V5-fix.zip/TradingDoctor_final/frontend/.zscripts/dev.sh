#!/bin/bash

set -euo pipefail

# 获取脚本所在目录（.zscripts）
# 使用 $0 获取脚本路径（与 build.sh 保持一致）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

log_step_start() {
        local step_name="$1"
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting: $step_name"
        echo "=========================================="
        export STEP_START_TIME
        STEP_START_TIME=$(date +%s)
}

log_step_end() {
        local step_name="${1:-Unknown step}"
        local end_time
        end_time=$(date +%s)
        local duration=$((end_time - STEP_START_TIME))
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Completed: $step_name"
        echo "[LOG] Step: $step_name | Duration: ${duration}s"
        echo "=========================================="
        echo ""
}

start_mini_services() {
        local mini_services_dir="$PROJECT_DIR/mini-services"
        local started_count=0

        log_step_start "Starting mini-services"
        if [ ! -d "$mini_services_dir" ]; then
                echo "Mini-services directory not found, skipping..."
                log_step_end "Starting mini-services"
                return 0
        fi

        echo "Found mini-services directory, scanning for sub-services..."

        for service_dir in "$mini_services_dir"/*; do
                if [ ! -d "$service_dir" ]; then
                        continue
                fi

                local service_name
                service_name=$(basename "$service_dir")
                echo "Checking service: $service_name"

                if [ ! -f "$service_dir/package.json" ]; then
                        echo "[$service_name] No package.json found, skipping..."
                        continue
                fi

                if ! grep -q '"dev"' "$service_dir/package.json"; then
                        echo "[$service_name] No dev script found, skipping..."
                        continue
                fi

                echo "Starting $service_name in background..."
                (
                        cd "$service_dir"
                        echo "[$service_name] Installing dependencies..."
                        bun install
                        echo "[$service_name] Running bun run dev..."
                        exec bun run dev
                ) >"$PROJECT_DIR/.zscripts/mini-service-${service_name}.log" 2>&1 &

                local service_pid=$!
                echo "[$service_name] Started in background (PID: $service_pid)"
                echo "[$service_name] Log: $PROJECT_DIR/.zscripts/mini-service-${service_name}.log"
                disown "$service_pid" 2>/dev/null || true
                started_count=$((started_count + 1))
        done

        echo "Mini-services startup completed. Started $started_count service(s)."
        log_step_end "Starting mini-services"
}

wait_for_service() {
        local host="$1"
        local port="$2"
        local service_name="$3"
        local max_attempts="${4:-60}"
        local attempt=1

        echo "Waiting for $service_name to be ready on $host:$port..."

        while [ "$attempt" -le "$max_attempts" ]; do
                if curl -s --connect-timeout 2 --max-time 5 "http://$host:$port" >/dev/null 2>&1; then
                        echo "$service_name is ready!"
                        return 0
                fi

                echo "Attempt $attempt/$max_attempts: $service_name not ready yet, waiting..."
                sleep 1
                attempt=$((attempt + 1))
        done

        echo "ERROR: $service_name failed to start within $max_attempts seconds"
        return 1
}

cleanup() {
        if [ -n "${DEV_PID:-}" ] && kill -0 "$DEV_PID" >/dev/null 2>&1; then
                echo "Stopping Next.js dev server (PID: $DEV_PID)..."
                kill "$DEV_PID" >/dev/null 2>&1 || true
        fi
}

trap cleanup EXIT INT TERM

cd "$PROJECT_DIR"

if ! command -v bun >/dev/null 2>&1; then
        echo "ERROR: bun is not installed or in PATH"
        exit 1
fi

# ──────────────────────────────────────────────────────────────────────────
# Load .env.production to override platform-injected SQLite DATABASE_URL
# The z.ai platform /start.sh overwrites /home/z/my-project/.env with a SQLite
# URL on every boot (lines 70 and 98 of /start.sh). It does NOT touch
# .env.production. So we source .env.production here to get the real PostgreSQL
# URLs, and export them to override the platform's SQLite value.
# ──────────────────────────────────────────────────────────────────────────
log_step_start "Load .env.production and override platform env vars"
ENV_FILE="$PROJECT_DIR/.env.production"
if [ ! -f "$ENV_FILE" ]; then
        echo "❌ .env.production file not found at $ENV_FILE"
        echo "   This file is required because z.ai's platform overwrites .env with SQLite."
        exit 1
fi
# Source .env.production — set -a makes all subsequent var assignments exported
set -a
. "$ENV_FILE"
set +a
# Re-export critical vars to ensure they override platform defaults
export DATABASE_URL
export DIRECT_URL
export NEXTAUTH_SECRET
export NEXTAUTH_URL
# Verify DATABASE_URL is now PostgreSQL (not SQLite)
if [ -z "$DATABASE_URL" ]; then
        echo "❌ DATABASE_URL is not set in .env.production"
        exit 1
fi
case "$DATABASE_URL" in
        postgresql://*|postgres://*) ;;
        *)
                echo "❌ DATABASE_URL in .env.production is not a PostgreSQL URL: $DATABASE_URL"
                exit 1
                ;;
esac
if [ -z "$DIRECT_URL" ]; then
        echo "❌ DIRECT_URL is not set in .env.production"
        exit 1
fi
echo "[ENV] DATABASE_URL=${DATABASE_URL:0:40}...(masked)"
echo "[ENV] DIRECT_URL=${DIRECT_URL:0:40}...(masked)"
echo "[ENV] NEXTAUTH_SECRET=${NEXTAUTH_SECRET:+(set)}"
echo "[ENV] NEXTAUTH_URL=${NEXTAUTH_URL:-(not set)}"
log_step_end "Load .env.production and override platform env vars"

log_step_start "bun install"
echo "[BUN] Installing dependencies..."
bun install
log_step_end "bun install"

# ──────────────────────────────────────────────────────────────────────────
# Prisma Generate + DB Push
# This is the critical step — the schema MUST be applied to Supabase before
# the app can serve any auth request. We do NOT swallow errors. If db:push
# fails, dev.sh aborts here and the user sees the real Prisma error.
# ──────────────────────────────────────────────────────────────────────────
log_step_start "prisma generate"
echo "[PRISMA] Generating Prisma Client..."
bun run db:generate
log_step_end "prisma generate"

log_step_start "prisma db push"
echo "[PRISMA] Pushing schema to Supabase (DIRECT_URL)..."
echo "[PRISMA] Running: prisma db push"
echo ""
# IMPORTANT: do NOT wrap in `|| true` or `|| { warn }`. We want the real
# error to surface and we want dev.sh to abort if db:push fails.
bun run db:push
echo ""
echo "[PRISMA] ✓ Schema pushed successfully. Tables created:"
echo "         - User"
echo "         - Account"
echo "         - Session"
echo "         - VerificationToken"
echo "         - PasswordResetToken"
echo "         - LoginEvent"
log_step_end "prisma db push"

log_step_start "Starting Next.js dev server"
echo "[BUN] Starting development server..."
bun run dev &
DEV_PID=$!
log_step_end "Starting Next.js dev server"

log_step_start "Waiting for Next.js dev server"
wait_for_service "localhost" "3000" "Next.js dev server"
log_step_end "Waiting for Next.js dev server"

log_step_start "Health check"
echo "[BUN] Performing health check..."
curl -fsS localhost:3000 >/dev/null
echo "[BUN] Health check passed"
log_step_end "Health check"

start_mini_services

echo "Next.js dev server is running in background (PID: $DEV_PID)."
echo "Use 'kill $DEV_PID' to stop it."
disown "$DEV_PID" 2>/dev/null || true
unset DEV_PID
