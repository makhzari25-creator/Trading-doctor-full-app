import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";
import { dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * ESLint strategy
 * ----------------
 * Earlier revisions of this file disabled nearly every rule globally, which
 * made ESLint effectively useless. The current policy keeps the rules that
 * catch real bugs ON at "warn" so a green build is achievable but every
 * violation is visible in `next lint` output and in CI.
 *
 * Rules that are still OFF are the ones whose violation count in the legacy
 * codebase is large enough that turning them on would block development.
 * They are tagged with a "TODO(gradual): ..." comment so they can be flipped
 * to "warn" once the existing violations are cleaned up.
 */
const eslintConfig = [...nextCoreWebVitals, ...nextTypescript, {
  rules: {
    // ---- TypeScript rules -------------------------------------------------
    // ON as warn — these catch real bugs:
    "@typescript-eslint/no-unused-vars": [
      "warn",
      {
        argsIgnorePattern: "^_",
        varsIgnorePattern: "^_",
        caughtErrorsIgnorePattern: "^_",
      },
    ],
    "@typescript-eslint/no-non-null-assertion": "warn",
    "@typescript-eslint/ban-ts-comment": "warn",
    "@typescript-eslint/prefer-as-const": "warn",
    // TODO(gradual): flip to "warn" once existing `any` annotations are typed.
    "@typescript-eslint/no-explicit-any": "off",

    // ---- React rules ------------------------------------------------------
    // exhaustive-deps catches 90% of stale-closure bugs — warn-only for now.
    "react-hooks/exhaustive-deps": "warn",
    // purity / react-compiler: opt-in for the React Compiler migration later.
    "react-hooks/purity": "off",
    "react-compiler/react-compiler": "off",
    "react/no-unescaped-entities": "warn",
    "react/display-name": "off",
    "react/prop-types": "off",

    // ---- Next.js rules ----------------------------------------------------
    "@next/next/no-img-element": "warn",
    "@next/next/no-html-link-for-pages": "warn",

    // ---- General JavaScript rules ----------------------------------------
    "prefer-const": "warn",
    "no-unused-vars": "off", // covered by @typescript-eslint/no-unused-vars
    "no-console": ["warn", { allow: ["warn", "error", "info"] }],
    "no-debugger": "warn",
    "no-empty": "warn",
    "no-irregular-whitespace": "warn",
    "no-case-declarations": "warn",
    "no-fallthrough": "warn",
    "no-mixed-spaces-and-tabs": "warn",
    "no-redeclare": "warn",
    "no-undef": "off", // covered by TS compiler
    "no-unreachable": "warn",
    "no-useless-escape": "warn",
  },
}, {
  ignores: [
    "node_modules/**",
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
    "examples/**",
    "skills",
    "**/__tests__/**",
    "**/*.test.{ts,tsx,js,jsx}",
    "**/*.spec.{ts,tsx,js,jsx}",
    "jest.setup.ts",
    "jest.config.{ts,js,mjs}",
  ],
}];

export default eslintConfig;
