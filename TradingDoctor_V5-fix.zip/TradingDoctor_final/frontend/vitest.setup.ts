/**
 * Vitest global setup — runs once before the test suite.
 *
 * - Registers @testing-library/jest-dom matchers (toBeInTheDocument, etc.)
 * - Polyfills matchMedia for components that read it at module load time
 *   (e.g. use-mobile.ts).
 * - Stubs ResizeObserver, which Radix UI reads on import.
 */
import "@testing-library/jest-dom/vitest";

if (typeof window !== "undefined") {
  // matchMedia — required by use-mobile.ts and several Radix components.
  if (!window.matchMedia) {
    window.matchMedia = (query: string) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: () => {},
      removeListener: () => {},
      addEventListener: () => {},
      removeEventListener: () => {},
      dispatchEvent: () => false,
    });
  }

  // ResizeObserver — Radix UI / recharts read it on import.
  if (!(window as unknown as { ResizeObserver?: unknown }).ResizeObserver) {
    (window as unknown as { ResizeObserver: unknown }).ResizeObserver = class {
      observe() {}
      unobserve() {}
      disconnect() {}
    };
  }
}
