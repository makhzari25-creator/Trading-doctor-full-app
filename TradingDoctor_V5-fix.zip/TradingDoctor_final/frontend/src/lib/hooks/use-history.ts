/**
 * Trading Doctor — useHistory hook
 * ------------------------------------------------------------------
 * Fetches the real analysis history (GET /api/v1/history →
 * proxied to the V23 backend), replacing the previous `mockHistory`
 * import used by the history + trends views.
 *
 * Implementation note: now built on TanStack Query so we drop the manual
 * useState/useEffect bookkeeping (and the React 19 set-state-in-effect
 * warning that came with it). The exported shape is identical to the
 * previous version so callers don't change.
 */
"use client";

import { useQuery } from "@tanstack/react-query";
import { getHistory, ApiError } from "@/lib/api";
import type { HistoryItem } from "@/lib/types";

export interface UseHistoryResult {
  items: HistoryItem[];
  total: number;
  isLoading: boolean;
  error: string | null;
  refetch: () => void;
}

interface HistoryResponse {
  items: HistoryItem[];
  total: number;
}

function selectErrorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return "دریافت تاریخچه‌ی تحلیل‌ها ناموفق بود.";
}

export function useHistory(page = 1, pageSize = 50): UseHistoryResult {
  const q = useQuery<HistoryResponse>({
    queryKey: ["history", page, pageSize],
    queryFn: () => getHistory(page, pageSize),
    staleTime: 15_000,
    retry: 1,
  });

  return {
    items: q.data?.items ?? [],
    total: q.data?.total ?? 0,
    isLoading: q.isLoading,
    error: q.error ? selectErrorMessage(q.error) : null,
    refetch: () => {
      void q.refetch();
    },
  };
}
