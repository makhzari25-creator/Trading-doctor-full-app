/**
 * Trading Doctor — useTrades hook
 * ------------------------------------------------------------------
 * Fetches the raw per-trade list for the currently-selected analysis
 * (GET /api/v1/analyses/{id}/trades → proxied to the V23 backend).
 *
 * Built on TanStack Query so we get pagination, refetching, and stale
 * management for free. Replaces the previous direct mockTrades import
 * in views/trade-explorer.tsx.
 *
 * [v2] NEW — backend endpoint added in v2.
 */
"use client";

import { useQuery } from "@tanstack/react-query";
import { getTrades, ApiError } from "@/lib/api";
import { useAppStore } from "@/lib/store/app-store";
import type { TradesResponse } from "@/lib/types";

export interface UseTradesParams {
  page?: number;
  pageSize?: number;
  side?: "Long" | "Short";
  outcome?: "win" | "loss";
}

export interface UseTradesResult {
  data: TradesResponse | null;
  isLoading: boolean;
  error: string | null;
  noAnalysisSelected: boolean;
  refetch: () => void;
}

function selectErrorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return "دریافت فهرست معاملات ناموفق بود.";
}

export function useTrades(params: UseTradesParams = {}): UseTradesResult {
  const analysisId = useAppStore((s) => s.currentAnalysisId);
  const { page = 1, pageSize = 50, side, outcome } = params;

  const q = useQuery<TradesResponse>({
    queryKey: ["trades", analysisId ?? "none", page, pageSize, side ?? "all", outcome ?? "all"],
    queryFn: () => {
      if (!analysisId) return Promise.reject(new Error("no-analysis"));
      return getTrades(analysisId, { page, pageSize, side, outcome });
    },
    enabled: !!analysisId,
    staleTime: 15_000,
    retry: 1,
  });

  return {
    data: q.data ?? null,
    isLoading: analysisId ? q.isLoading : false,
    error: q.error ? selectErrorMessage(q.error) : null,
    noAnalysisSelected: !analysisId,
    refetch: () => {
      void q.refetch();
    },
  };
}
