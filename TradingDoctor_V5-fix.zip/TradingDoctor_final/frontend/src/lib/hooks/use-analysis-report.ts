/**
 * Trading Doctor — useAnalysisReport hook
 * ------------------------------------------------------------------
 * Fetches the real `AnalysisReport` (GET /api/v1/analyses/{id}/report
 * → proxied to the V23 backend) for whichever analysis is currently
 * selected in the app store (`currentAnalysisId`), replacing the
 * previous `mockAnalysisReport` import used across the result views.
 *
 * Implementation note: now built on TanStack Query (already a project
 * dependency) so we get rid of manual useState/useEffect bookkeeping and
 * the React 19 set-state-in-effect warning that the previous manual
 * implementation triggered. The exported shape is intentionally kept
 * identical to the previous version so consumers do not need any change.
 */
"use client";

import { useQuery, type UseQueryResult } from "@tanstack/react-query";
import { getAnalysisReport, ApiError } from "@/lib/api";
import { useAppStore } from "@/lib/store/app-store";
import type { AnalysisReport } from "@/lib/types";

export interface UseAnalysisReportResult {
  data: AnalysisReport | null;
  isLoading: boolean;
  error: string | null;
  /** True when there is no analysis selected yet (fresh session, no upload done). */
  noAnalysisSelected: boolean;
  refetch: () => void;
}

function selectErrorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return "دریافت گزارش تحلیل ناموفق بود.";
}

/**
 * Wrapped useQuery — typed as UseQueryResult to satisfy the result shape,
 * but `null` when no analysisId is selected (queries must be enabled).
 */
function useAnalysisReportQuery(
  analysisId: string | null,
): UseQueryResult<AnalysisReport | null> & { refetch: () => void } {
  return useQuery<AnalysisReport | null>({
    queryKey: ["analysis-report", analysisId ?? "none"],
    queryFn: () => {
      if (!analysisId) return null;
      return getAnalysisReport(analysisId);
    },
    enabled: !!analysisId,
    staleTime: 30_000,
    retry: 1,
  }) as UseQueryResult<AnalysisReport | null> & { refetch: () => void };
}

export function useAnalysisReport(): UseAnalysisReportResult {
  const analysisId = useAppStore((s) => s.currentAnalysisId);
  const q = useAnalysisReportQuery(analysisId);

  return {
    data: q.data ?? null,
    isLoading: analysisId ? q.isLoading : false,
    error: q.error ? selectErrorMessage(q.error) : null,
    noAnalysisSelected: !analysisId,
    refetch: () => {
      void q.refetch();
    },
  };
}
