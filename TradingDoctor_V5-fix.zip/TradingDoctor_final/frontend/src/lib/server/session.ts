/**
 * Trading Doctor — Server-side session reader (v4 — single-source FastAPI auth)
 * ------------------------------------------------------------------
 * The frontend no longer has its own user database. FastAPI is the single
 * source of truth. The user's access and refresh tokens live in httpOnly
 * cookies (`td-access`, `td-refresh`) set by the `/api/v1/auth/*` proxy
 * routes on login/refresh.
 *
 * This module exposes two helpers:
 *   - `getAccessToken()`  — returns the raw JWT string from the cookie, or null.
 *   - `getSessionUser()`  — calls FastAPI `GET /me` with the access token to
 *                           resolve the user profile (cached per-request via
 *                           React's `cache()` so multiple proxy routes in the
 *                           same request don't fan out multiple /me calls).
 *
 * The previous version (v3) read a `td-session` cookie signed with
 * NEXTAUTH_SECRET and looked up the user in Prisma. That entire pipeline is
 * gone — no more Prisma, no more NEXTAUTH_SECRET, no more td-session cookie.
 */

import { cookies } from "next/headers";
import { cache } from "react";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "./backend-config";

export const ACCESS_COOKIE = "td-access";
export const REFRESH_COOKIE = "td-refresh";

export interface SessionUser {
  id: string;
  email: string;
  name: string | null;
  role?: string;
  image?: string | null;
  email_verified?: boolean;
}

/**
 * Returns the raw access-token string from the httpOnly cookie, or null if
 * the user is not authenticated. Never throws.
 */
export async function getAccessToken(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(ACCESS_COOKIE)?.value ?? null;
}

/**
 * Returns the raw refresh-token string from the httpOnly cookie, or null.
 */
export async function getRefreshToken(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(REFRESH_COOKIE)?.value ?? null;
}

/**
 * Calls FastAPI `GET /me` to resolve the user profile for the current
 * request. Cached per-request via React's `cache()` so multiple proxy
 * routes in the same server-side pass reuse one /me call.
 *
 * Returns null if the user is not authenticated (no cookie) or the backend
 * rejects the token (401). Never throws.
 */
export const getSessionUser = cache(
  async (): Promise<SessionUser | null> => {
    const token = await getAccessToken();
    if (!token) return null;

    try {
      const controller = new AbortController();
      const timer = setTimeout(
        () => controller.abort(),
        BACKEND_REQUEST_TIMEOUT_MS,
      );
      try {
        const res = await fetch(`${BACKEND_API_URL}/me`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
          cache: "no-store",
          signal: controller.signal,
        });
        if (!res.ok) return null;
        const body = (await res.json()) as {
          user?: {
            id?: string;
            email?: string;
            full_name?: string | null;
            status?: string;
            email_verified_at?: string | null;
            locale?: string | null;
          };
        };
        // Backend wraps the profile in { user: { ... } } per UserProfileResponse schema.
        const u = body.user;
        if (!u) return null;
        return {
          id: u.id ?? "",
          email: u.email ?? "",
          name: u.full_name ?? null,
          role: u.status ?? "user",
          image: null,
          email_verified: !!u.email_verified_at,
        };
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return null;
    }
  },
);
