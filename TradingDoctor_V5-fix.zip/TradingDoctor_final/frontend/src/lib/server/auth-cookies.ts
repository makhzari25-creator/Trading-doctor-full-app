/**
 * Trading Doctor — Auth Cookie Helpers (v4)
 * ------------------------------------------------------------------
 * Centralized helpers for setting/clearing the httpOnly access/refresh
 * token cookies. Used by the `/api/v1/auth/*` proxy routes.
 *
 * Tokens are NEVER exposed to JavaScript (httpOnly: true). In production
 * they are also Secure (HTTPS-only). SameSite=lax provides CSRF protection
 * for cross-site POSTs while still allowing top-level navigations to keep
 * the user logged in.
 */

import { cookies } from "next/headers";
import {
  ACCESS_COOKIE,
  REFRESH_COOKIE,
  cookieSecure,
  COOKIE_SAME_SITE,
} from "./backend-config";

interface TokenPair {
  access_token: string;
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
}

/**
 * Sets the httpOnly access + refresh token cookies from a backend token
 * response. Refreshes the access cookie slightly before its real expiry
 * (30s buffer) to avoid edge-of-window 401s.
 */
export async function setAuthCookies(tokens: TokenPair): Promise<void> {
  const cookieStore = await cookies();
  const secure = cookieSecure();

  cookieStore.set(ACCESS_COOKIE, tokens.access_token, {
    httpOnly: true,
    secure,
    sameSite: COOKIE_SAME_SITE,
    path: "/",
    // 30-second buffer before the real expiry — gives the /auth/refresh
    // proxy route time to rotate the token without the user seeing a 401.
    maxAge: Math.max(60, tokens.expires_in - 30),
  });

  cookieStore.set(REFRESH_COOKIE, tokens.refresh_token, {
    httpOnly: true,
    secure,
    sameSite: COOKIE_SAME_SITE,
    path: "/",
    maxAge: tokens.refresh_expires_in,
  });
}

/**
 * Clears both auth cookies. Used on logout and on auth failure.
 */
export async function clearAuthCookies(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(ACCESS_COOKIE);
  cookieStore.delete(REFRESH_COOKIE);
}
