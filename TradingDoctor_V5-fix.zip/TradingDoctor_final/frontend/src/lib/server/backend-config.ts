/**
 * Trading Doctor — Backend (V23 FastAPI) connection config (v4)
 * ------------------------------------------------------------------
 * Server-only (never imported by client components — no "use client").
 *
 * [v4] The BRIDGE_SECRET validation has been removed. In v3, the bridge
 * used it to derive per-user shadow-account passwords via HMAC. In v4,
 * users log in DIRECTLY to FastAPI; there is no shadow account, no HMAC,
 * and therefore no BRIDGE_SECRET needed for auth. The env var is still
 * documented in .env.example for backward compatibility but is unused.
 *
 * What remains:
 *   - BACKEND_API_URL       — base URL of the FastAPI backend.
 *   - BACKEND_API_KEY       — optional service-level X-API-Key.
 *   - BACKEND_REQUEST_TIMEOUT_MS — per-request timeout.
 */

function readEnv(name: string, fallback: string): string {
  const v = process.env[name];
  return v && v.trim().length > 0 ? v.trim() : fallback;
}

/** Base URL of the FastAPI backend, e.g. "http://localhost:8000/api/v1". */
export const BACKEND_API_URL = readEnv(
  "TRADING_DOCTOR_BACKEND_URL",
  "http://localhost:8000/api/v1"
);

/**
 * @deprecated Since v4. Kept only for backward compatibility with
 * existing .env files; not used anywhere in the codebase.
 */
export const BRIDGE_SECRET = readEnv(
  "TRADING_DOCTOR_BRIDGE_SECRET",
  "trading-doctor-dev-bridge-secret-change-in-production"
);

/**
 * @deprecated Since v4. Use BRIDGE_SECRET for backward-compat reads only.
 */
export function getBridgeSecret(): string {
  return BRIDGE_SECRET;
}

/** Optional service-level API key (X-API-Key) — only used if the backend
 * has TRADING_DOCTOR_API_KEYS / AUTH_ENABLED configured. Safe to leave empty. */
export const BACKEND_API_KEY = readEnv("TRADING_DOCTOR_BACKEND_API_KEY", "");

export const BACKEND_REQUEST_TIMEOUT_MS = 30_000;

/**
 * Cookie names for the httpOnly access/refresh token cookies set by the
 * `/api/v1/auth/*` proxy routes. Centralized here so the proxy routes
 * (which set the cookies) and `lib/server/session.ts` (which reads them)
 * can't drift apart.
 */
export const ACCESS_COOKIE = "td-access";
export const REFRESH_COOKIE = "td-refresh";

/**
 * Whether the httpOnly cookies should be marked Secure. True in production
 * (HTTPS-only), false in dev (so http://localhost works).
 */
export function cookieSecure(): boolean {
  return process.env.NODE_ENV === "production";
}

/**
 * Same-Site policy for the auth cookies. `lax` is the safest choice for
 * a BFF proxy: it allows the cookie to be sent on top-level navigations
 * from external sites (so users can click a link to /dashboard and stay
 * logged in) but blocks it on cross-site POST requests (CSRF protection).
 */
export const COOKIE_SAME_SITE = "lax" as const;
