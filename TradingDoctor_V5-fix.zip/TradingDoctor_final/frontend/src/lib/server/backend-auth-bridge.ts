/**
 * Trading Doctor — Backend Auth Bridge (v4 — single-source FastAPI auth)
 * ------------------------------------------------------------------
 * REFACTORED. The previous version (v3) derived a per-user password from
 * `HMAC(BRIDGE_SECRET, prismaUserId)` and maintained a SHADOW backend
 * account so the Next.js session could obtain a matching V23 backend JWT
 * without the user logging in twice. That made sense when there were two
 * independent user databases (Prisma on the frontend, SQLAlchemy on the
 * backend).
 *
 * In v4, FastAPI is the SINGLE source of truth. The user logs in directly
 * to FastAPI via `POST /api/v1/auth/login` (proxied). The backend JWT
 * lives in httpOnly cookies (`td-access`, `td-refresh`) that JavaScript
 * cannot read. This module is preserved as a thin compatibility shim so
 * existing call sites (`getBackendAccessToken(user)` in backend-proxy.ts)
 * keep working — it now just returns the access token from the cookie.
 *
 * No HMAC. No shadow account. No BRIDGE_SECRET for password derivation.
 * The `BRIDGE_SECRET` validation in backend-config.ts is kept for backward
 * compatibility with existing env files, but is no longer used here.
 */

import { getAccessToken, getRefreshToken } from "./session";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "./backend-config";

export class BackendBridgeError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = "BackendBridgeError";
  }
}

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
}

/**
 * Backend user profile shape (subset of UserPublic from auth/schemas.py).
 * Used by `loginBackend()` to return the user alongside the tokens, so the
 * login proxy route doesn't need a separate /me call.
 */
export interface BackendUser {
  id: string;
  email: string;
  full_name: string | null;
  status: string;
  email_verified_at: string | null;
  locale: string | null;
}

export interface LoginResult {
  tokens: TokenResponse;
  user: BackendUser;
}

/**
 * Returns a valid V23 backend access token for the current request.
 *
 * In v4 this is trivial: read it from the httpOnly `td-access` cookie. If
 * the cookie is missing (user not logged in), return null and let the
 * caller decide how to respond (typically 401).
 *
 * If the access token is expired, the `/api/v1/auth/refresh` proxy route
 * will have already refreshed it on the previous response. We do NOT do
 * refresh here because refresh-token rotation should be a single,
 * well-audited code path (in the proxy route), not duplicated.
 *
 * The `user` parameter is kept for signature compatibility with v3 call
 * sites but is no longer used — the token IS the identity.
 */
export async function getBackendAccessToken(
  _user?: unknown,
): Promise<string | null> {
  return await getAccessToken();
}

/**
 * Refresh the backend tokens using the refresh-token cookie.
 *
 * Called by the `/api/v1/auth/refresh` proxy route when the access token
 * has expired (or proactively before it expires). Returns the new token
 * pair, or null if the refresh token is invalid/expired.
 *
 * NOTE: This is the ONLY place in the codebase that calls
 * `POST /auth/refresh` on the backend. Keeping it centralized here means
 * refresh-token rotation can be audited in one place.
 */
export async function refreshBackendTokens(): Promise<TokenResponse | null> {
  const refreshToken = await getRefreshToken();
  if (!refreshToken) return null;

  try {
    const controller = new AbortController();
    const timer = setTimeout(
      () => controller.abort(),
      BACKEND_REQUEST_TIMEOUT_MS,
    );
    try {
      const res = await fetch(`${BACKEND_API_URL}/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
        cache: "no-store",
        signal: controller.signal,
      });
      if (!res.ok) return null;
      return (await res.json()) as TokenResponse;
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return null;
  }
}

/**
 * Exchange an email+password for a fresh token pair AND user profile, by
 * calling the backend's `POST /auth/login` directly. Used by the
 * `/api/v1/auth/login` proxy route on the user's first login.
 *
 * Returns both tokens and the user profile so the proxy route doesn't need
 * a second /me call.
 *
 * Throws `BackendBridgeError` with a user-safe message if the backend
 * rejects the credentials or is unreachable.
 */
export async function loginBackend(
  email: string,
  password: string,
): Promise<LoginResult> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(
      () => controller.abort(),
      BACKEND_REQUEST_TIMEOUT_MS,
    );
    try {
      const res = await fetch(`${BACKEND_API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
        cache: "no-store",
        signal: controller.signal,
      });
      const body = (await res.json().catch(() => null)) as
        | { tokens?: TokenResponse; user?: BackendUser; error?: { code: string; message: string } }
        | null;
      if (!res.ok || !body?.tokens || !body?.user) {
        const msg = body?.error?.message ?? `HTTP ${res.status}`;
        throw new BackendBridgeError(msg);
      }
      return { tokens: body.tokens, user: body.user };
    } finally {
      clearTimeout(timer);
    }
  } catch (err) {
    if (err instanceof BackendBridgeError) throw err;
    throw new BackendBridgeError(
      "اتصال به سرور تحلیل (V23 backend) برقرار نشد.",
      err,
    );
  }
}
