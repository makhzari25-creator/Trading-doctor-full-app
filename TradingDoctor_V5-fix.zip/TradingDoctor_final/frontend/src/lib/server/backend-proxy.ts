/**
 * Trading Doctor — BFF Proxy Helpers (v4 — single-source FastAPI auth)
 * ------------------------------------------------------------------
 * Shared plumbing used by the Next.js Route Handlers under
 * src/app/api/v1/*. Each route handler stays a thin, readable wrapper
 * around one of these functions — see that folder for usage.
 *
 * Every function here returns a NextResponse whose error shape matches
 * `ApiErrorEnvelope` from lib/types.ts, so the existing `apiClient()` /
 * `apiUpload()` in lib/api/client.ts parses it correctly.
 *
 * [v4] Auth resolution is now trivial: the access token lives in an
 * httpOnly cookie set by the `/api/v1/auth/*` proxy routes. We read it
 * via `getBackendAccessToken()` (which wraps the cookie read) and forward
 * it as `Authorization: Bearer <token>` to the backend. No more bridge,
 * no more shadow accounts, no more Prisma lookup. If the cookie is
 * missing, we return 401.
 */

import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "./backend-config";
import { getBackendAccessToken } from "./backend-auth-bridge";

function errorEnvelope(code: string, message: string, details?: Record<string, unknown>) {
  return { error: { code, message, details } };
}

/**
 * Resolves the caller's backend bearer token, or returns (via the
 * `response` field) a ready-to-return NextResponse describing exactly
 * why authentication could not be established. Never throws.
 */
async function resolveAuth(): Promise<
  { token: string; response: null } | { token: null; response: NextResponse }
> {
  const token = await getBackendAccessToken();
  if (!token) {
    return {
      token: null,
      response: NextResponse.json(
        errorEnvelope("unauthorized", "لطفاً ابتدا وارد حساب کاربری خود شوید."),
        { status: 401 }
      ),
    };
  }
  return { token, response: null };
}

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    return await promise;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Proxies a JSON request/response to the backend. `init.body`, if
 * present, must already be a JSON string (or undefined for GET).
 */
export async function proxyJson(
  path: string,
  init: { method: string; body?: string; searchParams?: URLSearchParams }
): Promise<NextResponse> {
  const auth = await resolveAuth();
  if (auth.response) return auth.response;

  const qs = init.searchParams?.toString();
  const url = `${BACKEND_API_URL}${path}${qs ? `?${qs}` : ""}`;

  try {
    const res = await withTimeout(
      fetch(url, {
        method: init.method,
        body: init.body,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${auth.token}`,
        },
        cache: "no-store",
      }),
      BACKEND_REQUEST_TIMEOUT_MS
    );

    if (res.status === 204) {
      return new NextResponse(null, { status: 204 });
    }

    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      errorEnvelope("backend_unreachable", "اتصال به سرور تحلیل برقرار نشد."),
      { status: 502 }
    );
  }
}

/**
 * Proxies a JSON GET to a *public* backend endpoint (no session/backend
 * JWT required) — used for /health and /config.
 */
export async function proxyPublicJson(path: string): Promise<NextResponse> {
  try {
    const res = await withTimeout(
      fetch(`${BACKEND_API_URL}${path}`, { cache: "no-store" }),
      BACKEND_REQUEST_TIMEOUT_MS
    );
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      errorEnvelope("backend_unreachable", "اتصال به سرور تحلیل برقرار نشد."),
      { status: 502 }
    );
  }
}

/** Proxies a multipart file upload (POST /uploads). */

export async function proxyUpload(request: Request, path: string): Promise<NextResponse> {
  const auth = await resolveAuth();
  if (auth.response) return auth.response;

  try {
    const formData = await request.formData();
    const res = await withTimeout(
      fetch(`${BACKEND_API_URL}${path}`, {
        method: "POST",
        body: formData,
        headers: { Authorization: `Bearer ${auth.token}` },
        cache: "no-store",
      }),
      60_000
    );
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      errorEnvelope("backend_unreachable", "اتصال به سرور تحلیل برقرار نشد."),
      { status: 502 }
    );
  }
}

/** Proxies a text response (e.g. GET /analyses/{id}/report.html). */
export async function proxyText(path: string): Promise<NextResponse> {
  const auth = await resolveAuth();
  if (auth.response) return auth.response;

  try {
    const res = await withTimeout(
      fetch(`${BACKEND_API_URL}${path}`, {
        headers: { Authorization: `Bearer ${auth.token}` },
        cache: "no-store",
      }),
      BACKEND_REQUEST_TIMEOUT_MS
    );
    const text = await res.text();
    return new NextResponse(text, {
      status: res.status,
      headers: { "Content-Type": res.headers.get("Content-Type") || "text/html; charset=utf-8" },
    });
  } catch {
    return NextResponse.json(
      errorEnvelope("backend_unreachable", "اتصال به سرور تحلیل برقرار نشد."),
      { status: 502 }
    );
  }
}

/** Proxies a binary response (e.g. GET /analyses/{id}/report.pdf). */
export async function proxyBinary(path: string): Promise<NextResponse> {
  const auth = await resolveAuth();
  if (auth.response) return auth.response;

  try {
    const res = await withTimeout(
      fetch(`${BACKEND_API_URL}${path}`, {
        headers: { Authorization: `Bearer ${auth.token}` },
        cache: "no-store",
      }),
      BACKEND_REQUEST_TIMEOUT_MS
    );
    const buf = await res.arrayBuffer();
    return new NextResponse(buf, {
      status: res.status,
      headers: {
        "Content-Type": res.headers.get("Content-Type") || "application/pdf",
        "Content-Disposition": res.headers.get("Content-Disposition") || "attachment",
      },
    });
  } catch {
    return NextResponse.json(
      errorEnvelope("backend_unreachable", "اتصال به سرور تحلیل برقرار نشد."),
      { status: 502 }
    );
  }
}
