"use client";

/**
 * Trading Doctor — Auth Store (v4 — single-source FastAPI auth)
 * ----------------------------------------------------------------
 * The frontend no longer maintains its own user database or session tokens.
 * FastAPI is the single source of truth for authentication. The access and
 * refresh tokens live in httpOnly cookies (`td-access`, `td-refresh`) that
 * JavaScript cannot read directly; this store only mirrors the user-facing
 * profile fields (id, email, name, role, image, emailVerified) so the UI can
 * render the avatar/name without a round-trip on every navigation.
 *
 * Lifecycle:
 *   1. On mount, `app/page.tsx` calls `GET /api/v1/auth/session` (proxy that
 *      calls FastAPI `GET /me`). If a valid access cookie exists, the backend
 *      returns the profile and we `setUser(profile)` here.
 *   2. On login, the proxy route sets the httpOnly cookies and returns the
 *      profile; `views/auth/index.tsx` calls `setUser(profile)`.
 *   3. On logout, the proxy route clears the cookies; we call `logout()`.
 *
 * Tokens are NEVER stored in this store, localStorage, or any client-side
 * JS-readable location. This eliminates the XSS-token-theft attack surface.
 */

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface AuthUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  image: string | null;
  emailVerified: boolean;
}

interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUser: (user: AuthUser | null) => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: true,
      setUser: (user) =>
        set({ user, isAuthenticated: !!user, isLoading: false }),
      logout: () =>
        set({ user: null, isAuthenticated: false, isLoading: false }),
      setLoading: (loading) => set({ isLoading: loading }),
    }),
    {
      name: "td-auth",
      // Only persist the user profile (no tokens, ever).
      partialize: (s) => ({ user: s.user, isAuthenticated: s.isAuthenticated }),
    },
  ),
);
