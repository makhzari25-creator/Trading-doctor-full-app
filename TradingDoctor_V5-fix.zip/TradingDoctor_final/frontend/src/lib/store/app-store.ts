/**
 * Trading Doctor — App Store (Zustand)
 *
 * Client-only UI state: current view, analysis ID, sidebar/drawer state.
 * Phase 5 §6.
 */

"use client";

import { create } from "zustand";
import type { ViewId } from "../types";

interface AppState {
  /* -- Current view (SPA routing) -- */
  currentView: ViewId;
  setView: (view: ViewId) => void;

  /* -- Current analysis ID (context for all analysis pages) -- */
  currentAnalysisId: string | null;
  hasAnalysis: boolean;
  setAnalysisId: (id: string | null) => void;

  /* -- Mobile nav drawer -- */
  mobileNavOpen: boolean;
  setMobileNavOpen: (open: boolean) => void;
  toggleMobileNav: () => void;

  /* -- Command palette -- */
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  toggleCommandPalette: () => void;

  /* -- Navigation helper -- */
  navigate: (view: ViewId) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  currentView: "landing",
  setView: (view) => {
    set({ currentView: view });
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  },

  currentAnalysisId: null,
  hasAnalysis: false,
  setAnalysisId: (id) =>
    set({ currentAnalysisId: id, hasAnalysis: id !== null }),

  mobileNavOpen: false,
  setMobileNavOpen: (open) => set({ mobileNavOpen: open }),
  toggleMobileNav: () => set((s) => ({ mobileNavOpen: !s.mobileNavOpen })),

  commandPaletteOpen: false,
  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),
  toggleCommandPalette: () =>
    set((s) => ({ commandPaletteOpen: !s.commandPaletteOpen })),

  navigate: (view) => {
    get().setView(view);
    set({ mobileNavOpen: false });
  },
}));
