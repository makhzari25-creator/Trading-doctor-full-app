/**
 * Trading Doctor — Theme Store (Zustand + localStorage persistence)
 *
 * Persists user preferences: theme (dark/light/system), language (fa/en), density.
 * Phase 5 §6, §10, §11.
 */

"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

type Theme = "dark" | "light" | "system";
type Language = "fa" | "en";
type Density = "comfortable" | "compact";

interface ThemeState {
  theme: Theme;
  language: Language;
  density: Density;
  setTheme: (theme: Theme) => void;
  setLanguage: (language: Language) => void;
  setDensity: (density: Density) => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: "dark",
      language: "fa",
      density: "comfortable",
      setTheme: (theme) => set({ theme }),
      setLanguage: (language) => set({ language }),
      setDensity: (density) => set({ density }),
    }),
    {
      name: "td-theme",
      partialize: (state) => ({
        theme: state.theme,
        language: state.language,
        density: state.density,
      }),
    }
  )
);
