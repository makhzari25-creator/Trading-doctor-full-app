/**
 * Trading Doctor — Navigation Constants
 *
 * Sidebar + bottom tab bar configuration.
 * Phase 2 §4.5, Phase 3 §11.5.
 */

import {
  Gauge,
  ChartBar,
  Stethoscope,
  Lightbulb,
  Dna,
  MapPin,
  ChartLineUp,
  Table,
  TrendUp,
  FileText,
  ClockCounterClockwise,
  Gear,
  type Icon,
} from "@phosphor-icons/react";
import type { ViewId } from "../types";

export interface NavItem {
  id: ViewId;
  label: string;
  question: string;
  icon: Icon;
  tier: "primary" | "deep-dive" | "action" | "entry" | "future";
  requiresAnalysis: boolean;
}

export const NAV_ITEMS: NavItem[] = [
  {
    id: "dashboard",
    label: "داشبورد",
    question: "وضعیت کلی من چطور است؟",
    icon: Gauge,
    tier: "primary",
    requiresAnalysis: true,
  },
  {
    id: "behavioral",
    label: "تحلیل رفتاری",
    question: "کدام رفتارها به من ضرر می‌زنند؟",
    icon: ChartBar,
    tier: "primary",
    requiresAnalysis: true,
  },
  {
    id: "diagnosis",
    label: "تشخیص",
    question: "بزرگ‌ترین مشکل من چیست؟",
    icon: Stethoscope,
    tier: "primary",
    requiresAnalysis: true,
  },
  {
    id: "coaching",
    label: "برنامه‌ی اقدام",
    question: "چه کار باید بکنم؟",
    icon: Lightbulb,
    tier: "primary",
    requiresAnalysis: true,
  },
  {
    id: "trader-dna",
    label: "دی‌ان‌ای معامله‌گر",
    question: "من چه نوع معامله‌گری هستم؟",
    icon: Dna,
    tier: "deep-dive",
    requiresAnalysis: true,
  },
  {
    id: "edge-map",
    label: "نقشه‌ی نقاط قوت",
    question: "کِی و کجا بهترین/بدترین هستم؟",
    icon: MapPin,
    tier: "deep-dive",
    requiresAnalysis: true,
  },
  {
    id: "charts",
    label: "نمودارها",
    question: "نمودارها را نشانم بده",
    icon: ChartLineUp,
    tier: "deep-dive",
    requiresAnalysis: true,
  },
  {
    id: "trade-explorer",
    label: "کاوش معاملات",
    question: "معاملات خام را نشانم بده",
    icon: Table,
    tier: "deep-dive",
    requiresAnalysis: true,
  },
  {
    id: "trends",
    label: "روند تغییرات",
    question: "آیا در حال بهبود هستم؟",
    icon: TrendUp,
    tier: "deep-dive",
    requiresAnalysis: false,
  },
  {
    id: "report",
    label: "گزارش",
    question: "گزارش قابل‌دانلود بده",
    icon: FileText,
    tier: "action",
    requiresAnalysis: true,
  },
  {
    id: "history",
    label: "تاریخچه",
    question: "قبلاً چه تحلیل کرده‌ام؟",
    icon: ClockCounterClockwise,
    tier: "entry",
    requiresAnalysis: false,
  },
  {
    id: "settings",
    label: "تنظیمات",
    question: "حسابم را پیکربندی کن",
    icon: Gear,
    tier: "future",
    requiresAnalysis: false,
  },
];

/** Bottom tab bar items (mobile only, top 5) */
export const BOTTOM_TAB_ITEMS: NavItem[] = NAV_ITEMS.filter((item) =>
  ["dashboard", "behavioral", "diagnosis", "coaching", "report"].includes(
    item.id
  )
);

/** "More" sheet items (mobile, additional nav) */
export const MORE_SHEET_ITEMS: NavItem[] = NAV_ITEMS.filter((item) =>
  [
    "trader-dna",
    "edge-map",
    "charts",
    "trade-explorer",
    "trends",
    "history",
    "settings",
  ].includes(item.id)
);
