/**
 * Trading Doctor — API Functions
 *
 * Typed wrappers around the V23 REST API (proxied via BFF Route Handlers).
 * Each function corresponds to one V23 endpoint.
 *
 * Phase 5 §7, Phase 2 §5.1 (trades endpoint).
 */

export { ApiError } from "./client";

import { apiClient, apiUpload } from "./client";
import type {
  AnalysisReport,
  AnalysisSummary,
  AppConfig,
  HistoryResponse,
  TradesResponse,
  UploadResponse,
} from "../types";
import type { LLMProvider } from "../utils";

/* ============================================================================
   Health & Config
   ============================================================================ */

export async function getHealth(): Promise<{
  status: string;
  version: string;
  engine_ready: boolean;
  timestamp: string;
}> {
  return apiClient("/health");
}

export async function getConfig(): Promise<AppConfig> {
  return apiClient("/config");
}

/* ============================================================================
   Uploads
   ============================================================================ */

export async function uploadFile(file: File): Promise<UploadResponse> {
  return apiUpload<UploadResponse>("/uploads", file);
}

/* ============================================================================
   Analyses
   ============================================================================ */

export async function runAnalysis(
  uploadId: string,
  llmProvider: LLMProvider = "none"
): Promise<AnalysisSummary> {
  return apiClient<AnalysisSummary>("/analyses", {
    method: "POST",
    body: JSON.stringify({
      upload_id: uploadId,
      llm_provider: llmProvider,
    }),
  });
}

export async function getAnalysis(analysisId: string): Promise<AnalysisSummary> {
  return apiClient<AnalysisSummary>(`/analyses/${analysisId}`);
}

/**
 * Poll an analysis job's status. Used when the backend is running in Celery
 * async mode (TRADING_DOCTOR_USE_CELERY=true) and POST /analyses returns
 * 202 Accepted with a `job_id` instead of 201 Created with the analysis.
 *
 * Returns the final analysis once the job reaches a terminal state
 * ("completed" / "failed"). Throws an Error on "failed" or after
 * `timeoutMs` has elapsed without a terminal state.
 */
export async function pollAnalysisJob(
  jobId: string,
  opts: { intervalMs?: number; timeoutMs?: number } = {}
): Promise<AnalysisSummary> {
  const intervalMs = opts.intervalMs ?? 1500;
  const timeoutMs = opts.timeoutMs ?? 90_000;
  const startedAt = Date.now();

  // Reuse the apiClient for the job-status endpoint. The backend's
  // GET /analyses/jobs/{id} returns { status, analysis_id?, error? }.
  while (true) {
    if (Date.now() - startedAt > timeoutMs) {
      throw new Error("تحلیل بیش از حد طول کشید؛ لطفاً دوباره تلاش کنید.");
    }
    const job = await apiClient<{
      status: "pending" | "running" | "completed" | "failed";
      analysis_id?: string;
      error?: string;
    }>(`/analyses/jobs/${jobId}`);

    if (job.status === "completed" && job.analysis_id) {
      return getAnalysis(job.analysis_id);
    }
    if (job.status === "failed") {
      throw new Error(job.error || "تحلیل در بک‌اند ناموفق بود.");
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
}

/**
 * Run an analysis, transparently handling both synchronous (201) and
 * asynchronous / Celery (202) responses from the backend.
 */
export async function runAnalysisWithPolling(
  uploadId: string,
  llmProvider: LLMProvider = "none"
): Promise<AnalysisSummary> {
  const res = await fetch("/api/v1/analyses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ upload_id: uploadId, llm_provider: llmProvider }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `تحلیل ناموفق بود (HTTP ${res.status})`);
  }
  // 202 + job_id → Celery path. 201 + analysis object → sync path.
  if (res.status === 202) {
    const body = (await res.json()) as { job_id: string };
    return pollAnalysisJob(body.job_id);
  }
  return (await res.json()) as AnalysisSummary;
}

export async function getAnalysisReport(
  analysisId: string
): Promise<AnalysisReport> {
  return apiClient<AnalysisReport>(`/analyses/${analysisId}/report`);
}

/* ============================================================================
   Trades (NEW — Phase 2 §5.1)
   ============================================================================ */

export interface GetTradesParams {
  page?: number;
  pageSize?: number;
  /** Case-sensitive: "Long" or "Short" — matches backend `_derive_side` output. */
  side?: "Long" | "Short";
  outcome?: "win" | "loss";
}

/**
 * [v2] Fetch the raw per-trade list for an analysis.
 *
 * The backend reads doctor.df (the same DataFrame the V23 engine analyzed)
 * and returns paginated trade rows with optional side/outcome filters.
 * Previously this endpoint didn't exist and the Trade Explorer view used
 * mockTrades — now the data is real.
 */
export async function getTrades(
  analysisId: string,
  params: GetTradesParams = {}
): Promise<TradesResponse> {
  const searchParams = new URLSearchParams();
  if (params.page) searchParams.set("page", String(params.page));
  if (params.pageSize) searchParams.set("page_size", String(params.pageSize));
  if (params.side) searchParams.set("side", params.side);
  if (params.outcome) searchParams.set("outcome", params.outcome);

  const query = searchParams.toString();
  return apiClient<TradesResponse>(
    `/analyses/${analysisId}/trades${query ? `?${query}` : ""}`
  );
}

/* ============================================================================
   Workspace (analysis management — NEW, wires the history view's delete action)
   ============================================================================ */

export async function deleteAnalysis(analysisId: string): Promise<void> {
  await apiClient<void>(`/workspace/analyses/${analysisId}`, { method: "DELETE" });
}

/* ============================================================================
   History
   ============================================================================ */

export async function getHistory(
  page = 1,
  pageSize = 20
): Promise<HistoryResponse> {
  return apiClient<HistoryResponse>(
    `/history?page=${page}&page_size=${pageSize}`
  );
}

/* ============================================================================
   Reports (download endpoints — return blobs, not JSON)
   ============================================================================ */

export async function downloadReportHtml(analysisId: string): Promise<string> {
  const response = await fetch(`/api/v1/analyses/${analysisId}/report.html`);
  if (!response.ok) throw new Error("تولید HTML ناموفق بود");
  return response.text();
}

export async function downloadReportPdf(analysisId: string): Promise<Blob> {
  const response = await fetch(`/api/v1/analyses/${analysisId}/report.pdf`);
  if (!response.ok) throw new Error("تولید PDF ناموفق بود");
  return response.blob();
}
