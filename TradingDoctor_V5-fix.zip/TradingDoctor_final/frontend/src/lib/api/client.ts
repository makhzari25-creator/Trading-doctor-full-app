/**
 * Trading Doctor — API Base Client
 *
 * BFF (Backend-for-Frontend) client. All requests go through Next.js Route Handlers
 * at /api/v1/*, which proxy to the V23 FastAPI backend.
 *
 * Phase 5 §7: The browser never calls the V23 API directly.
 */

import type { ApiErrorEnvelope } from "../types";

/* ============================================================================
   Custom Error Class
   ============================================================================ */

export class ApiError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
    public readonly details?: Record<string, unknown>
  ) {
    super(message);
    this.name = "ApiError";
  }

  get isNotFound(): boolean {
    return this.statusCode === 404;
  }

  get isRateLimited(): boolean {
    return this.statusCode === 429;
  }

  get isValidationError(): boolean {
    return this.statusCode === 422;
  }

  get isServerError(): boolean {
    return this.statusCode >= 500;
  }

  get isNetworkError(): boolean {
    return this.statusCode === 0;
  }
}

/* ============================================================================
   Base Fetch Client
   ============================================================================ */

const API_BASE = "/api/v1";

const DEFAULT_TIMEOUT = 30_000; // 30 seconds

interface RequestOptions extends RequestInit {
  timeout?: number;
}

/**
 * Low-level API client. All other API functions delegate to this.
 *
 * @throws {ApiError} on non-2xx responses or network failures.
 */
export async function apiClient<T>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const { timeout = DEFAULT_TIMEOUT, ...fetchOptions } = options;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...fetchOptions,
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        ...fetchOptions.headers,
      },
    });

    if (!response.ok) {
      let errorEnvelope: ApiErrorEnvelope;
      try {
        errorEnvelope = (await response.json()) as ApiErrorEnvelope;
      } catch {
        errorEnvelope = {
          error: {
            code: "unknown",
            message: `HTTP ${response.status}`,
          },
        };
      }
      throw new ApiError(
        response.status,
        errorEnvelope.error?.code || "unknown",
        errorEnvelope.error?.message || "خطای نامشخص",
        errorEnvelope.error?.details
      );
    }

    // Handle 204 No Content
    if (response.status === 204) {
      return undefined as T;
    }

    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new ApiError(0, "timeout", "درخواست بیش از حد طول کشید");
    }
    // Network error
    throw new ApiError(0, "network_error", "اتصال به سرور برقرار نشد");
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Upload a file via multipart form data.
 * Uses a separate function because the Content-Type is different.
 */
export async function apiUpload<T>(
  path: string,
  file: File,
  fieldName = "file"
): Promise<T> {
  const formData = new FormData();
  formData.append(fieldName, file);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 60_000); // 60s for uploads

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      body: formData,
      signal: controller.signal,
    });

    if (!response.ok) {
      let errorEnvelope: ApiErrorEnvelope;
      try {
        errorEnvelope = (await response.json()) as ApiErrorEnvelope;
      } catch {
        errorEnvelope = {
          error: {
            code: "unknown",
            message: `HTTP ${response.status}`,
          },
        };
      }
      throw new ApiError(
        response.status,
        errorEnvelope.error?.code || "unknown",
        errorEnvelope.error?.message || "خطای نامشخص",
        errorEnvelope.error?.details
      );
    }

    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new ApiError(0, "timeout", "آپلود بیش از حد طول کشید");
    }
    throw new ApiError(0, "network_error", "اتصال به سرور برقرار نشد");
  } finally {
    clearTimeout(timeoutId);
  }
}
