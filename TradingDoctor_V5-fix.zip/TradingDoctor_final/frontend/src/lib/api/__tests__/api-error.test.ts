/**
 * Unit tests for the ApiError class.
 *
 * The class is the canonical error thrown by every apiClient call, so its
 * getter predicates (isNotFound, isRateLimited, etc.) are relied on by
 * every consumer — locking them down with tests prevents regressions
 * when the file is refactored.
 */
import { describe, it, expect } from "vitest";
import { ApiError } from "../client";

describe("ApiError", () => {
  it("preserves statusCode, code, message and details", () => {
    const err = new ApiError(422, "validation_failed", "bad input", {
      field: "upload_id",
    });
    expect(err.statusCode).toBe(422);
    expect(err.code).toBe("validation_failed");
    expect(err.message).toBe("bad input");
    expect(err.details).toEqual({ field: "upload_id" });
    expect(err.name).toBe("ApiError");
  });

  it("isNotFound is true only for 404", () => {
    expect(new ApiError(404, "not_found", "x").isNotFound).toBe(true);
    expect(new ApiError(403, "forbidden", "x").isNotFound).toBe(false);
  });

  it("isRateLimited is true only for 429", () => {
    expect(new ApiError(429, "rate_limited", "x").isRateLimited).toBe(true);
    expect(new ApiError(422, "x", "x").isRateLimited).toBe(false);
  });

  it("isValidationError is true only for 422", () => {
    expect(new ApiError(422, "x", "x").isValidationError).toBe(true);
    expect(new ApiError(400, "x", "x").isValidationError).toBe(false);
  });

  it("isServerError is true only for 5xx", () => {
    expect(new ApiError(500, "x", "x").isServerError).toBe(true);
    expect(new ApiError(503, "x", "x").isServerError).toBe(true);
    expect(new ApiError(422, "x", "x").isServerError).toBe(false);
  });

  it("isNetworkError is true only when statusCode === 0", () => {
    expect(new ApiError(0, "network_error", "x").isNetworkError).toBe(true);
    expect(new ApiError(500, "x", "x").isNetworkError).toBe(false);
  });
});
