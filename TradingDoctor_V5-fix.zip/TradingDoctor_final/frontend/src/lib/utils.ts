/**
 * Trading Doctor — Utility Functions
 *
 * Pure functions for formatting, severity mapping, Persian numerals, etc.
 * No side effects. No dependencies on React or DOM.
 *
 * Phase 3 §16, Phase 5 §3.
 */

import type { Severity, SeverityLevel } from "./types";

/* ============================================================================
   Class Name Merge (cn)
   ============================================================================ */

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/* ============================================================================
   Severity Utilities
   ============================================================================ */

const severityLevelMap: Record<Severity, SeverityLevel> = {
  Low: 0,
  Medium: 1,
  High: 2,
  Critical: 3,
};

const severityLabelMap: Record<SeverityLevel | Severity, string> = {
  Low: "پایین",
  Medium: "متوسط",
  High: "بالا",
  Critical: "بحرانی",
  0: "پایین",
  1: "متوسط",
  2: "بالا",
  3: "بحرانی",
};

const severityColorMap: Record<SeverityLevel, string> = {
  0: "var(--severity-low)",
  1: "var(--severity-medium)",
  2: "var(--severity-high)",
  3: "var(--severity-critical)",
};

const severityBgMap: Record<SeverityLevel, string> = {
  0: "color-mix(in srgb, var(--severity-low) 15%, transparent)",
  1: "color-mix(in srgb, var(--severity-medium) 15%, transparent)",
  2: "color-mix(in srgb, var(--severity-high) 15%, transparent)",
  3: "color-mix(in srgb, var(--severity-critical) 15%, transparent)",
};

export function severityToLevel(severity: Severity | SeverityLevel): SeverityLevel {
  if (typeof severity === "number") return severity;
  return severityLevelMap[severity];
}

export function severityLabel(severity: Severity | SeverityLevel): string {
  return severityLabelMap[severity];
}

export function severityColor(severity: Severity | SeverityLevel): string {
  return severityColorMap[severityToLevel(severity)];
}

export function severityBg(severity: Severity | SeverityLevel): string {
  return severityBgMap[severityToLevel(severity)];
}

/**
 * Map a 0–100 score to severity level.
 * Phase 3 §5.1: Low <25, Medium 25–49, High 50–74, Critical 75+.
 */
export function scoreToSeverity(score: number): Severity {
  if (score < 25) return "Low";
  if (score < 50) return "Medium";
  if (score < 75) return "High";
  return "Critical";
}

export function scoreToSeverityLevel(score: number): SeverityLevel {
  return severityToLevel(scoreToSeverity(score));
}

/* ============================================================================
   Number / Currency Formatting
   ============================================================================ */

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/**
 * Convert Latin digits to Persian numerals.
 * Used in prose/captions. Mono data fields keep Latin numerals.
 */
export function toPersianNumerals(value: string | number): string {
  return String(value).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[parseInt(d, 10)]);
}

/**
 * Format a number with Persian locale (thousand separators).
 */
export function formatNumber(value: number, decimals = 0): string {
  return toPersianNumerals(
    value.toLocaleString("en-US", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    })
  );
}

/**
 * Format a currency value.
 * @param value - The numeric value
 * @param showSign - Whether to show + for positive values
 * @returns Formatted string like "+$۱٬۲۴۰" or "-$۸۹۰"
 */
export function formatCurrency(value: number, showSign = true): string {
  const sign = value > 0 && showSign ? "+" : "";
  const abs = Math.abs(value);
  const formatted = abs.toLocaleString("en-US", { maximumFractionDigits: 0 });
  return `${sign}${value < 0 ? "-" : ""}$${toPersianNumerals(formatted)}`;
}

/**
 * Format a percentage value.
 * @param value - The percentage (e.g., 52.3 for 52.3%)
 * @param decimals - Number of decimal places
 */
export function formatPercent(value: number, decimals = 1): string {
  return `${toPersianNumerals(value.toFixed(decimals))}٪`;
}

/* ============================================================================
   Date Formatting
   ============================================================================ */

/**
 * Format an ISO date string to Shamsi (Persian solar) calendar.
 * Uses Intl.DateTimeFormat with fa-IR-u-ca-persian.
 */
export function toShamsi(isoDate: string): string {
  try {
    const date = new Date(isoDate);
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(date);
  } catch {
    return isoDate;
  }
}

/**
 * Format an ISO date string to Gregorian calendar (for English UI).
 */
export function toGregorian(isoDate: string): string {
  try {
    const date = new Date(isoDate);
    return new Intl.DateTimeFormat("en-CA", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(date);
  } catch {
    return isoDate;
  }
}

/**
 * Format date based on current language.
 */
export function formatDate(isoDate: string, lang: "fa" | "en" = "fa"): string {
  return lang === "fa" ? toShamsi(isoDate) : toGregorian(isoDate);
}

/**
 * Format date + time.
 */
export function formatDateTime(isoDate: string, lang: "fa" | "en" = "fa"): string {
  try {
    const date = new Date(isoDate);
    const locale = lang === "fa" ? "fa-IR-u-ca-persian" : "en-US";
    return new Intl.DateTimeFormat(locale, {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  } catch {
    return isoDate;
  }
}

/* ============================================================================
   Profit / Loss Helpers
   ============================================================================ */

export function profitColor(value: number): string {
  if (value > 0) return "var(--profit-positive)";
  if (value < 0) return "var(--profit-negative)";
  return "var(--profit-neutral)";
}

export function profitTrend(value: number): "up" | "down" | "neutral" {
  if (value > 0) return "up";
  if (value < 0) return "down";
  return "neutral";
}

/* ============================================================================
   File Size Formatting
   ============================================================================ */

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${toPersianNumerals(bytes)} B`;
  if (bytes < 1024 * 1024) return `${toPersianNumerals((bytes / 1024).toFixed(1))} KB`;
  return `${toPersianNumerals((bytes / (1024 * 1024)).toFixed(1))} MB`;
}

/* ============================================================================
   Constants
   ============================================================================ */

export const ALLOWED_FILE_TYPES = [
  "csv",
  "xlsx",
  "xls",
  "htm",
  "html",
  "json",
  "log",
  "txt",
] as const;

export const MAX_UPLOAD_SIZE_BYTES = 25 * 1024 * 1024; // 25 MB

export const LLM_PROVIDERS = ["none", "gemini", "openai", "claude"] as const;

export type LLMProvider = (typeof LLM_PROVIDERS)[number];
