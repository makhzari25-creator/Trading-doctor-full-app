/**
 * Trading Doctor — نمودارها View (v2)
 * ------------------------------------------------------------
 * 4 Recharts visualizations sourced from the REAL backend report:
 *   1. Equity Curve   (cumsum of Profit per trade)
 *   2. Drawdown       (Equity - cummax(Equity))
 *   3. P&L Distribution (histogram of per-trade Profit)
 *   4. Hourly P&L     (sum of Profit grouped by hour-of-day)
 *
 * The chart series come from `useAnalysisReport().data.charts` — they are
 * extracted server-side by `reporting/chart_data.py::build_chart_series`
 * from the same DataFrame the V23 engine analyzed, so the numbers shown
 * here always match the report.
 *
 * RTL-aware axes (XAxis reversed, YAxis orientation="right").
 */

"use client";

import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals } from "@/lib/utils";
import { ChartLineUp, ArrowLeft } from "@phosphor-icons/react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  ReferenceLine,
} from "recharts";

const tooltipStyle = {
  backgroundColor: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "8px",
  fontSize: "12px",
} as const;

const axisTick = { fill: "var(--muted-foreground)", fontSize: 11 } as const;
const smallTick = { fill: "var(--muted-foreground)", fontSize: 10 } as const;

export function ChartsView() {
  const navigate = useAppStore((s) => s.navigate);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی نمودارها، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  // Defensive: charts is a new field — older cached reports may not have it.
  // We treat its absence as "no data for this chart" rather than crashing.
  const charts = r.charts ?? {
    equity_curve: [],
    drawdown: [],
    pnl_distribution: [],
    hourly_pnl: [],
    weekday_pnl: [],
    win_loss_pie: { wins: 0, losses: 0, breakeven: 0, total: 0 },
  };

  // Drawdown minimum (most negative) — for the "biggest drop" badge.
  const maxDD = charts.drawdown.length
    ? Math.min(...charts.drawdown.map((d) => d.drawdown))
    : 0;

  // Hourly P&L is already a 24-element array from the backend (one per hour).
  // We just render it directly.
  const hourlyData = charts.hourly_pnl.map((p) => ({
    hour: `${toPersianNumerals(p.hour)}`,
    pnl: p.pnl,
  }));

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">نمودارها</h1>
        <p className="text-sm text-muted-foreground">visual deep-dive عملکرد معاملات</p>
      </div>

      {/* Equity Curve */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-1">
          <ChartLineUp size={18} className="text-[var(--primary)]" />
          <h3 className="text-sm font-semibold">منحنی سرمایه</h3>
        </div>
        <p className="text-xs text-muted-foreground mb-3">رشد حساب در طول زمان</p>
        {charts.equity_curve.length === 0 ? (
          <div className="h-[260px] flex items-center justify-center text-xs text-muted-foreground">
            داده‌ای برای نمایش موجود نیست.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={charts.equity_curve}>
              <defs>
                <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="trade" tick={axisTick} reversed />
              <YAxis tick={axisTick} orientation="right" />
              <Tooltip
                contentStyle={tooltipStyle}
                labelStyle={{ color: "var(--muted-foreground)" }}
                formatter={(value: number) => [`$${value.toFixed(2)}`, "سرمایه"]}
                labelFormatter={(label: number) => `معامله #${toPersianNumerals(label)}`}
              />
              <Area
                type="monotone"
                dataKey="equity"
                stroke="var(--chart-1)"
                strokeWidth={2}
                fill="url(#equityGradient)"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 سود خالص:{" "}
          <span className="td-mono font-bold text-foreground">
            {r.performance.net_profit_fmt}
          </span>{" "}
          در <span className="td-mono">{toPersianNumerals(r.statistics.total_trades)}</span> معامله
        </div>
      </Card>

      {/* Drawdown */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">دراودان (Drawdown)</h3>
        <p className="text-xs text-muted-foreground mb-3">افت سرمایه از اوج قبلی</p>
        {charts.drawdown.length === 0 ? (
          <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">
            داده‌ای برای نمایش موجود نیست.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={charts.drawdown}>
              <defs>
                <linearGradient id="ddGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--profit-negative)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="var(--profit-negative)" stopOpacity={0.6} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="trade" tick={axisTick} reversed />
              <YAxis tick={axisTick} orientation="right" />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(value: number) => [`$${value.toFixed(2)}`, "افت"]}
                labelFormatter={(label: number) => `معامله #${toPersianNumerals(label)}`}
              />
              <ReferenceLine y={0} stroke="var(--border)" />
              <Area
                type="monotone"
                dataKey="drawdown"
                stroke="var(--profit-negative)"
                strokeWidth={2}
                fill="url(#ddGradient)"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 بزرگ‌ترین افت:{" "}
          <span
            className="td-mono font-bold"
            style={{ color: "var(--profit-negative)" }}
          >
            ${toPersianNumerals(Math.abs(maxDD).toFixed(2))}
          </span>
        </div>
      </Card>

      {/* P&L Distribution */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">توزیع سود/زیان</h3>
        <p className="text-xs text-muted-foreground mb-3">آیا سودهای شما بزرگ‌تر از ضررهاست؟</p>
        {charts.pnl_distribution.length === 0 ? (
          <div className="h-[220px] flex items-center justify-center text-xs text-muted-foreground">
            داده‌ای برای نمایش موجود نیست.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={charts.pnl_distribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="range" tick={smallTick} reversed />
              <YAxis tick={axisTick} orientation="right" />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(value: number, _name: string, props: { payload?: { bin_left: number; bin_right: number } }) => {
                  const p = props?.payload;
                  if (!p) return [value, "تعداد"];
                  return [`${toPersianNumerals(value)} معامله`, `$${p.bin_left.toFixed(2)} تا $${p.bin_right.toFixed(2)}`];
                }}
              />
              <Bar dataKey="count" radius={[4, 4, 0, 0]} isAnimationActive={false}>
                {charts.pnl_distribution.map((entry, idx) => (
                  <Cell
                    key={idx}
                    fill={
                      entry.type === "win"
                        ? "var(--profit-positive)"
                        : "var(--profit-negative)"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
        <div className="mt-3 p-2 rounded-lg bg-accent/30 text-xs text-muted-foreground">
          💡 میانگین سود (
          <span className="td-mono" style={{ color: "var(--profit-positive)" }}>
            {r.performance.avg_win_fmt}
          </span>{" "}
          {r.performance.avg_win > Math.abs(r.performance.avg_loss)
            ? "بزرگ‌تر"
            : "کوچک‌تر"}{" "}
          از میانگین ضرر (
          <span className="td-mono" style={{ color: "var(--profit-negative)" }}>
            {r.performance.avg_loss_fmt}
          </span>
          )
        </div>
      </Card>

      {/* Hourly P&L */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-1">سود/زیان ساعتی</h3>
        <p className="text-xs text-muted-foreground mb-3">چه ساعتی بهترین/بدترین عملکرد را دارید؟</p>
        {hourlyData.length === 0 ? (
          <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">
            داده‌ی زمانی برای تحلیل ساعتی موجود نیست.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="hour" tick={smallTick} reversed />
              <YAxis tick={axisTick} orientation="right" />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(value: number) => [`$${value.toFixed(2)}`, "سود/زیان"]}
                labelFormatter={(label: string) => `ساعت ${label}`}
              />
              <ReferenceLine y={0} stroke="var(--border)" />
              <Bar dataKey="pnl" radius={[3, 3, 0, 0]} isAnimationActive={false}>
                {hourlyData.map((entry, idx) => (
                  <Cell
                    key={idx}
                    fill={
                      entry.pnl >= 0
                        ? "var(--profit-positive)"
                        : "var(--profit-negative)"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </Card>

      <button
        onClick={() => navigate("trade-explorer")}
        className="w-full py-3 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors flex items-center justify-center gap-2 td-press"
        aria-label="مشاهده‌ی معاملات خام"
      >
        مشاهده‌ی معاملات خام
        <ArrowLeft size={14} className="td-flip-rtl" />
      </button>
    </div>
  );
}
