"use client";
import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Eye, EyeSlash, ArrowLeft, Warning, CheckCircle, Mailbox, Shield, Clock, SignOut } from "@phosphor-icons/react";
import { useAuthStore } from "@/lib/store/auth-store";
import { useAppStore } from "@/lib/store/app-store";
import { toast } from "sonner";

// [v4] No more CSRF token — auth is httpOnly cookie-based. The browser
// automatically sends the cookie with same-origin requests, and Same-Site=lax
// provides the CSRF protection we need.
async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  return fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
}

export function LoginView() {
  const navigate = useAppStore((s) => s.navigate);
  const setUser = useAuthStore((s) => s.setUser);
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(""); setIsLoading(true);
    try {
      const res = await fetch("/api/v1/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error?.message || "ورود ناموفق بود."); return; }
      setUser(data.user); toast.success("خوش آمدید!"); navigate("dashboard");
    } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button>
        <Card className="p-6 md:p-8 fade-up">
          <div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div>
          <h1 className="text-xl font-bold text-center mb-1">ورود به حساب</h1>
          <p className="text-sm text-muted-foreground text-center mb-6">وارد حساب Trading Doctor خود شوید</p>
          {error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email" dir="ltr" className="text-left" /></div>
            <div className="space-y-1.5"><Label htmlFor="password">رمز عبور</Label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required autoComplete="current-password" dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "پنهان کردن" : "نمایش"}>{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
            <div className="flex items-center justify-between text-sm"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="w-4 h-4 rounded border-border accent-[var(--primary)]" /><span className="text-muted-foreground">مرا به خاطر بسپار</span></label><button type="button" onClick={() => navigate("forgot-password")} className="text-[var(--primary)] hover:underline">رمز عبور را فراموش کرده‌اید؟</button></div>
            <Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? (<><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> در حال ورود...</>) : ("ورود")}</Button>
          </form>
          <div className="flex items-center gap-3 my-6"><div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">یا</span><div className="flex-1 h-px bg-border" /></div>
          <button type="button" disabled className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-border text-sm text-muted-foreground opacity-50 cursor-not-allowed">ادامه با گوگل (به‌زودی)</button>
          <p className="text-sm text-center text-muted-foreground mt-6">حساب ندارید؟ <button onClick={() => navigate("register")} className="text-[var(--primary)] hover:underline font-medium">ثبت‌نام کنید</button></p>
        </Card>
      </div>
    </div>
  );
}

export function RegisterView() {
  const navigate = useAppStore((s) => s.navigate);
  const setUser = useAuthStore((s) => s.setUser);
  const [name, setName] = useState(""); const [email, setEmail] = useState("");
  const [password, setPassword] = useState(""); const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); const [acceptTerms, setAcceptTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError("");
    if (password !== confirmPassword) { setError("رمز عبور و تکرار آن یکسان نیستند."); return; }
    if (!acceptTerms) { setError("پذیرش قوانین الزامی است."); return; }
    setIsLoading(true);
    try {
      const res = await fetch("/api/v1/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password, full_name: name }) });
      const data = await res.json();
      if (!res.ok) { setError(data.error?.message || "ثبت‌نام ناموفق بود."); return; }
      // Try to auto-login after successful registration.
      const loginRes = await fetch("/api/v1/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const loginData = await loginRes.json();
      if (loginRes.ok && loginData.user) { setUser(loginData.user); toast.success("ثبت‌نام موفق بود!"); navigate("dashboard"); }
      else { toast.success("ثبت‌نام موفق بود. وارد شوید."); navigate("login"); }
    } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button>
        <Card className="p-6 md:p-8 fade-up">
          <div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div>
          <h1 className="text-xl font-bold text-center mb-1">ساخت حساب جدید</h1>
          <p className="text-sm text-muted-foreground text-center mb-6">تحلیل رفتاری معاملات خود را شروع کنید</p>
          {error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5"><Label htmlFor="name">نام (اختیاری)</Label><Input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="نام شما" /></div>
            <div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" className="text-left" /></div>
            <div className="space-y-1.5"><Label htmlFor="password">رمز عبور</Label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" required dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="نمایش/پنهان">{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
            <div className="space-y-1.5"><Label htmlFor="confirmPassword">تکرار رمز عبور</Label><Input id="confirmPassword" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="تکرار رمز" required dir="ltr" className="text-left" /></div>
            <label className="flex items-start gap-2 cursor-pointer text-sm"><input type="checkbox" checked={acceptTerms} onChange={(e) => setAcceptTerms(e.target.checked)} className="w-4 h-4 rounded border-border accent-[var(--primary)] mt-0.5" /><span className="text-muted-foreground">قوانین و مقررات را می‌پذیرم</span></label>
            <Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? (<><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> در حال ثبت‌نام...</>) : ("ثبت‌نام")}</Button>
          </form>
          <p className="text-sm text-center text-muted-foreground mt-6">حساب دارید؟ <button onClick={() => navigate("login")} className="text-[var(--primary)] hover:underline font-medium">وارد شوید</button></p>
        </Card>
      </div>
    </div>
  );
}

export function ForgotPasswordView() {
  const navigate = useAppStore((s) => s.navigate);
  const [email, setEmail] = useState(""); const [isLoading, setIsLoading] = useState(false);
  const [sent, setSent] = useState(false); const [resetToken, setResetToken] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setIsLoading(true);
    try { const res = await fetch("/api/v1/auth/password-reset/request", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) }); const data = await res.json(); if (res.ok) { setSent(true); if (data.resetToken) setResetToken(data.resetToken); } } catch { setSent(true); } finally { setIsLoading(false); }
  };

  if (sent) return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><Mailbox size={32} className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">ایمیل ارسال شد</h1><p className="text-sm text-muted-foreground mb-4">اگر این ایمیل ثبت شده باشد، لینک بازنشانی ارسال شده است.</p>{resetToken && (<div className="bg-accent/30 rounded-lg p-3 mb-4 text-left"><p className="text-xs text-muted-foreground mb-1">توکن بازنشانی (حالت توسعه):</p><code className="text-xs td-mono break-all">{resetToken}</code><button onClick={() => navigate("reset-password")} className="block w-full mt-2 text-xs text-[var(--primary)] hover:underline">استفاده از توکن →</button></div>)}<button onClick={() => navigate("login")} className="text-sm text-[var(--primary)] hover:underline">بازگشت به ورود</button></Card></div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("login")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به ورود</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">بازنشانی رمز عبور</h1><p className="text-sm text-muted-foreground text-center mb-6">ایمیل خود را وارد کنید</p><form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="email">ایمیل</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required dir="ltr" className="text-left" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال ارسال..." : "ارسال لینک بازنشانی"}</Button></form></Card></div></div>
  );
}

export function ResetPasswordView() {
  const navigate = useAppStore((s) => s.navigate);
  const [token, setToken] = useState(""); const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState(""); const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false); const [error, setError] = useState(""); const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError("");
    if (newPassword !== confirmPassword) { setError("رمزها یکسان نیستند."); return; }
    if (newPassword.length < 8) { setError("رمز باید حداقل ۸ کاراکتر باشد."); return; }
    setIsLoading(true);
    try { const res = await fetch("/api/v1/auth/password-reset/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, new_password: newPassword }) }); const data = await res.json(); if (!res.ok) { setError(data.error?.message || "بازنشانی ناموفق بود."); return; } setSuccess(true); toast.success("رمز عبور تغییر کرد."); } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  if (success) return (<div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><CheckCircle size={32} weight="fill" className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">رمز عبور تغییر کرد</h1><p className="text-sm text-muted-foreground mb-6">لطفاً با رمز جدید وارد شوید.</p><Button onClick={() => navigate("login")} className="bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90">ورود به حساب</Button></Card></div>);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("login")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به ورود</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">رمز عبور جدید</h1>{error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}<form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="token">توکن بازنشانی</Label><Input id="token" type="text" value={token} onChange={(e) => setToken(e.target.value)} placeholder="توکن" required dir="ltr" className="text-left text-sm" /></div><div className="space-y-1.5"><Label htmlFor="newPassword">رمز عبور جدید</Label><div className="relative"><Input id="newPassword" type={showPassword ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" required dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showPassword ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div><div className="space-y-1.5"><Label htmlFor="confirmPassword">تکرار رمز</Label><Input id="confirmPassword" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="تکرار" required dir="ltr" className="text-left" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال تغییر..." : "تغییر رمز عبور"}</Button></form></Card></div></div>
  );
}

export function VerifyEmailView() {
  const navigate = useAppStore((s) => s.navigate);
  const [token, setToken] = useState(""); const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(""); const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError(""); setIsLoading(true);
    try { const res = await fetch("/api/v1/auth/verify-email", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }) }); const data = await res.json(); if (!res.ok) { setError(data.error?.message || "تأیید ناموفق بود."); return; } setSuccess(true); } catch { setError("اتصال به سرور برقرار نشد."); } finally { setIsLoading(false); }
  };

  if (success) return (<div className="min-h-screen flex items-center justify-center p-4 bg-background"><Card className="p-6 md:p-8 text-center max-w-md w-full fade-up"><div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)" }}><CheckCircle size={32} weight="fill" className="text-[var(--severity-low)]" /></div><h1 className="text-xl font-bold mb-2">ایمیل تأیید شد</h1><Button onClick={() => navigate("login")} className="bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90">ورود به حساب</Button></Card></div>);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background"><div className="w-full max-w-md"><button onClick={() => navigate("landing")} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت به خانه</button><Card className="p-6 md:p-8 fade-up"><div className="flex justify-center mb-6"><div className="w-12 h-12 rounded-xl bg-[var(--primary)] flex items-center justify-center"><span className="text-white font-bold text-lg">TD</span></div></div><h1 className="text-xl font-bold text-center mb-1">تأیید ایمیل</h1>{error && (<div className="flex items-start gap-2 p-3 rounded-lg border border-[var(--severity-critical)]/30 bg-[var(--severity-critical)]/5 text-sm mb-4 fade-in"><Warning size={16} weight="fill" className="text-[var(--severity-critical)] shrink-0 mt-0.5" /><span>{error}</span></div>)}<form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="token">توکن تأیید</Label><Input id="token" type="text" value={token} onChange={(e) => setToken(e.target.value)} placeholder="توکن" required dir="ltr" className="text-left text-sm" /></div><Button type="submit" disabled={isLoading} className="w-full bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 td-press">{isLoading ? "در حال تأیید..." : "تأیید ایمیل"}</Button></form></Card></div></div>
  );
}

export function ProfileView() {
  const navigate = useAppStore((s) => s.navigate);
  const { user, logout, setUser } = useAuthStore();
  const [name, setName] = useState(user?.name || "");
  const [isSaving, setIsSaving] = useState(false);
  const [currentPassword, setCurrentPassword] = useState(""); const [newPassword, setNewPassword] = useState("");
  const [confirmNew, setConfirmNew] = useState(""); const [showPw, setShowPw] = useState(false); const [isChangingPw, setIsChangingPw] = useState(false);
  const [isResending, setIsResending] = useState(false);

  // [v4] No avatar upload — backend has no /me/avatar endpoint in v4.
  // The avatar UI is kept for forward compat but disabled.

  // Syncing the editable "name" field whenever the `user` object from the auth store changes
  // (e.g. after login or a profile refresh). Instead of setState-in-effect, we use the
  // `key`-reset pattern: the parent re-mounts this component whenever the userId changes,
  // which re-runs the lazy useState initializer below with the latest user.name — no effect
  // needed at all. The `key` itself is set at the call site (see app-shell.tsx).
  //
  // NOTE: the previous version had a `useEffect(() => { ... }, [user])` here that called
  // setName(user.name) inside the effect — that triggered React 19's
  // `react-hooks/set-state-in-effect` warning. The `key`-reset pattern at the call site
  // makes the effect unnecessary; the lazy `useState(user?.name || "")` initializer below
  // re-runs on every fresh mount with the latest user.name.

  if (!user) { navigate("login"); return null; }

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // [v4] Backend uses /me (PATCH) with full_name field (not /api/auth/profile with name).
      const res = await authFetch("/api/v1/me", { method: "PATCH", body: JSON.stringify({ full_name: name }) });
      if (res.ok) { const data = await res.json(); toast.success("پروفایل ذخیره شد"); setUser({ ...user, name }); }
      else { const d = await res.json().catch(() => ({})); toast.error(d.error?.message || "ذخیره ناموفق بود"); }
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsSaving(false); }
  };

  const handleChangePw = async () => {
    if (newPassword !== confirmNew) { toast.error("رمزهای جدید یکسان نیستند"); return; }
    if (newPassword.length < 8) { toast.error("رمز باید حداقل ۸ کاراکتر باشد"); return; }
    setIsChangingPw(true);
    try {
      // [v4] Backend uses /me/password with current_password + new_password.
      const res = await authFetch("/api/v1/me/password", { method: "POST", body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }) });
      if (res.ok) { toast.success("رمز تغییر کرد. لطفاً دوباره وارد شوید."); logout(); navigate("login"); }
      else { const d = await res.json().catch(() => ({})); toast.error(d.error?.message || "ناموفق"); }
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsChangingPw(false); }
  };

  const handleResendVerification = async () => {
    setIsResending(true);
    try {
      // [v4] Send email in body (not from session).
      const res = await fetch("/api/v1/auth/resend-verification", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: user.email }) });
      const data = await res.json().catch(() => ({}));
      if (res.ok) toast.success(data.message || "ایمیل ارسال شد");
      else toast.error(data.error?.message || "ارسال ناموفق بود");
    } catch { toast.error("اتصال برقرار نشد"); } finally { setIsResending(false); }
  };

  const handleLogout = async () => {
    try { await fetch("/api/v1/auth/logout", { method: "POST" }); } catch {}
    logout(); navigate("landing"); toast.success("خروج موفق بود");
  };

  return (
    <div className="space-y-4 fade-up max-w-2xl">
      <div><h1 className="text-2xl font-bold mb-1">پروفایل</h1><p className="text-sm text-muted-foreground">مدیریت حساب کاربری</p></div>

      {/* Profile Info with Avatar */}
      <Card className="p-4">
        <div className="flex items-center gap-4 mb-6">
          <div className="relative">
            {user.image ? (
              <img src={user.image} alt="avatar" className="w-20 h-20 rounded-full object-cover" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-[var(--primary)]/10 flex items-center justify-center text-2xl font-bold text-[var(--primary)]">
                {user.name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
              </div>
            )}
            {/* [v4] Avatar upload removed — backend has no /me/avatar endpoint.
                The avatar UI is kept for forward compat but the upload button is gone. */}
          </div>
          <div className="flex-1">
            <div className="font-medium">{user.name || "بدون نام"}</div>
            <div className="text-sm text-muted-foreground">{user.email}</div>
            {user.emailVerified ? (
              <div className="flex items-center gap-1 text-xs text-[var(--severity-low)] mt-1"><CheckCircle size={12} weight="fill" /> ایمیل تأیید شده</div>
            ) : (
              <div className="flex items-center gap-2 mt-1">
                <span className="flex items-center gap-1 text-xs text-[var(--severity-medium)]"><Warning size={12} weight="fill" /> تأیید نشده</span>
                <button onClick={handleResendVerification} disabled={isResending} className="text-xs text-[var(--primary)] hover:underline disabled:opacity-50">
                  {isResending ? "در حال ارسال..." : "ارسال مجدد"}
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-1.5 mb-4"><Label htmlFor="name">نام</Label><Input id="name" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1.5 mb-4"><Label>ایمیل</Label><Input value={user.email} disabled dir="ltr" className="text-left opacity-60" /></div>
        <div className="flex gap-2">
          <Button onClick={handleSave} disabled={isSaving} className="bg-[var(--primary)] text-white hover:opacity-90">{isSaving ? "در حال ذخیره..." : "ذخیره تغییرات"}</Button>
          <Button onClick={() => navigate("security")} variant="outline" className="border-[var(--primary)] text-[var(--primary)] hover:bg-[var(--primary)]/10">
            <Shield size={14} className="ml-1" /> امنیت حساب
          </Button>
        </div>
      </Card>

      {/* Password Change */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-4">تغییر رمز عبور</h3>
        <div className="space-y-3">
          <div className="space-y-1.5"><Label>رمز فعلی</Label><div className="relative"><Input type={showPw ? "text" : "password"} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="رمز فعلی" dir="ltr" className="text-left pl-10" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showPw ? <EyeSlash size={16} /> : <Eye size={16} />}</button></div></div>
          <div className="space-y-1.5"><Label>رمز جدید</Label><Input type={showPw ? "text" : "password"} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" dir="ltr" className="text-left" /></div>
          <div className="space-y-1.5"><Label>تکرار رمز جدید</Label><Input type={showPw ? "text" : "password"} value={confirmNew} onChange={(e) => setConfirmNew(e.target.value)} placeholder="تکرار" dir="ltr" className="text-left" /></div>
          <Button onClick={handleChangePw} disabled={isChangingPw || !currentPassword || !newPassword} variant="outline" className="border-[var(--primary)] text-[var(--primary)] hover:bg-[var(--primary)]/10">{isChangingPw ? "در حال تغییر..." : "تغییر رمز عبور"}</Button>
        </div>
      </Card>

      <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 py-3 rounded-lg border border-[var(--severity-critical)]/30 text-[var(--severity-critical)] text-sm font-medium hover:bg-[var(--severity-critical)]/10 transition-colors">
        <SignOut size={16} /> خروج از حساب
      </button>
    </div>
  );
}

export function SecurityView() {
  const navigate = useAppStore((s) => s.navigate);
  const { user } = useAuthStore();
  // [v4] Backend /me/activity returns an array of audit-log entries:
  //   { event_type, outcome, ip_address, user_agent, timestamp, details }
  // We map them to the same UI shape the previous /api/auth/login-history used.
  const [events, setEvents] = useState<Array<{
    event_type: string;
    outcome: string | null;
    ip_address: string | null;
    user_agent: string | null;
    timestamp: string | null;
  }>>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate("login"); return; }
    // [v4] Single call to /api/v1/me/activity (proxied to FastAPI GET /me/activity).
    fetch("/api/v1/me/activity")
      .then((r) => r.json())
      .then((data) => {
        // Backend returns an array; older responses may wrap in { events: [...] }.
        const list = Array.isArray(data) ? data : (data.events ?? []);
        setEvents(list);
        setIsLoading(false);
      })
      .catch(() => setIsLoading(false));
  }, [user, navigate]);

  if (!user) return null;

  const formatDateTime = (iso: string | null) => {
    if (!iso) return "نامشخص";
    try { return new Date(iso).toLocaleString("fa-IR", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
    catch { return iso; }
  };

  const parseUserAgent = (ua: string | null) => {
    if (!ua) return "نامشخص";
    if (ua.includes("Chrome")) return "Chrome";
    if (ua.includes("Firefox")) return "Firefox";
    if (ua.includes("Safari")) return "Safari";
    if (ua.includes("Edge")) return "Edge";
    return "مرورگر دیگر";
  };

  const formatEventType = (t: string) => {
    const map: Record<string, string> = {
      login: "ورود",
      logout: "خروج",
      password_changed: "تغییر رمز",
      account_deleted: "حذف حساب",
      refresh: "تمدید نشست",
    };
    return map[t] || t;
  };

  return (
    <div className="space-y-4 fade-up max-w-2xl">
      <div className="flex items-center gap-2">
        <button onClick={() => navigate("profile")} className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"><ArrowLeft size={14} className="td-flip-rtl" /> بازگشت</button>
      </div>
      <div><h1 className="text-2xl font-bold mb-1">امنیت حساب</h1><p className="text-sm text-muted-foreground">تاریخچه‌ی رویدادهای امنیتی و وضعیت حساب</p></div>

      {/* Security Status */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Shield size={16} className="text-[var(--primary)]" /> وضعیت امنیتی</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>تأیید ایمیل</span>
            {user.emailVerified ? <span className="text-[var(--severity-low)] text-xs font-medium flex items-center gap-1"><CheckCircle size={12} /> تأیید شده</span> : <span className="text-[var(--severity-medium)] text-xs">تأیید نشده</span>}
          </div>
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>احراز هویت دو مرحله‌ای</span>
            <span className="text-xs text-muted-foreground px-1.5 py-0.5 rounded bg-accent">به‌زودی</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-lg bg-accent/30">
            <span>رمز عبور</span>
            <span className="text-xs text-[var(--severity-low)] flex items-center gap-1"><CheckCircle size={12} /> تنظیم شده</span>
          </div>
        </div>
      </Card>

      {/* [v4] Active Sessions section removed — backend no longer exposes a
          per-session list. To revoke other sessions, the user changes their
          password (POST /me/password), which invalidates all existing tokens. */}

      {/* Audit Log (replaces both /api/auth/sessions and /api/auth/login-history) */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Clock size={16} className="text-[var(--primary)]" /> تاریخچه‌ی رویدادها</h3>
        {isLoading ? (
          <div className="space-y-2">{[1, 2, 3].map(i => <div key={i} className="h-10 rounded-lg bg-accent/30 skeleton-pulse" />)}</div>
        ) : events.length === 0 ? (
          <p className="text-sm text-muted-foreground">رویدادی ثبت نشده است.</p>
        ) : (
          <div className="space-y-1.5">
            {events.map((e, idx) => {
              const success = e.outcome !== "failure";
              return (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg text-sm">
                  <div className="flex items-center gap-2">
                    {success ? <CheckCircle size={14} className="text-[var(--severity-low)]" /> : <Warning size={14} className="text-[var(--severity-critical)]" />}
                    <span className="text-xs font-medium">{formatEventType(e.event_type)}</span>
                    <span className="text-muted-foreground">{e.ip_address || "نامشخص"}</span>
                    <span className="text-xs text-muted-foreground">·</span>
                    <span className="text-xs">{parseUserAgent(e.user_agent)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs ${success ? "text-[var(--severity-low)]" : "text-[var(--severity-critical)]"}`}>{success ? "موفق" : "ناموفق"}</span>
                    <span className="text-xs text-muted-foreground">{formatDateTime(e.timestamp)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
