/**
 * Trading Doctor — کاوش معاملات View (v2)
 * ------------------------------------------------------------
 * Real per-trade list with filter / sort / pagination / CSV export / detail
 * drawer, built on @tanstack/react-table.
 *
 * [v2] Previously this view used mockTrades (a static array). Now it fetches
 * the real trade list via `useTrades()` → GET /api/v1/analyses/{id}/trades,
 * which is sourced from the same DataFrame the V23 engine analyzed.
 */

"use client";

import { useMemo, useState, type ReactNode } from "react";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
  type ColumnFiltersState,
} from "@tanstack/react-table";
import { Card } from "@/components/ui/card";
import { StatCard } from "@/components/td/stat-card";
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription,
} from "@/components/ui/drawer";
import {
  EmptyState, ErrorState, PageSkeleton,
} from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useTrades } from "@/lib/hooks/use-trades";
import type { Trade } from "@/lib/types";
import { toPersianNumerals, formatCurrency } from "@/lib/utils";
import { Funnel, ArrowLeft, ArrowRight, DownloadSimple } from "@phosphor-icons/react";

const PAGE_SIZE = 20;
const PAGE_BTN = "p-2 rounded-lg border border-border disabled:opacity-40 hover:bg-accent transition-colors td-press";
type SideFilter = "all" | "Long" | "Short";
type OutcomeFilter = "all" | "win" | "loss";

const sideColor = (t: Trade) =>
  t.side === "Long" ? "var(--profit-positive)"
    : t.side === "Short" ? "var(--profit-negative)"
    : "var(--text-muted)"; // side unknown — this dataset has no Side/Type column
const pnlColor = (v: number) =>
  v >= 0 ? "var(--profit-positive)" : "var(--profit-negative)";

function Chip({ active, onClick, children, label }: {
  active: boolean; onClick: () => void; children: ReactNode; label: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors td-press ${
        active
          ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
          : "bg-accent text-muted-foreground hover:bg-accent/70"
      }`}
    >
      {children}
    </button>
  );
}

/**
 * Column definitions for @tanstack/react-table.
 *
 * We use `accessorKey` for primitive columns and `cell` render functions for
 * the colored/numeric-formatted ones. The table is fully client-side:
 * filtering, sorting, and pagination all happen in-memory on the page of
 * trades returned by the backend (which is paginated server-side at
 * page_size=200 — enough for typical interactive use).
 */
const COLUMNS: ColumnDef<Trade>[] = [
  {
    accessorKey: "id",
    header: "#",
    cell: (info) => (
      <span className="td-mono text-xs text-muted-foreground">
        {toPersianNumerals(info.getValue() as number)}
      </span>
    ),
    size: 50,
  },
  {
    accessorKey: "open_time",
    header: "زمان باز کردن",
    cell: (info) => (
      <span className="td-mono text-xs">{info.getValue() as string}</span>
    ),
  },
  {
    accessorKey: "side",
    header: "سمت",
    cell: (info) => {
      const t = info.row.original;
      return (
        <span className="text-xs" style={{ color: sideColor(t) }}>{t.side ?? "—"}</span>
      );
    },
    size: 70,
  },
  {
    accessorKey: "size",
    header: "حجم",
    cell: (info) => (
      <span className="td-mono text-xs">
        {toPersianNumerals((info.getValue() as number).toFixed(2))}
      </span>
    ),
    size: 80,
  },
  {
    accessorKey: "profit",
    header: "سود/زیان",
    cell: (info) => {
      const v = info.getValue() as number;
      return (
        <span className="td-mono text-xs font-semibold" style={{ color: pnlColor(v) }}>
          {formatCurrency(v)}
        </span>
      );
    },
    size: 110,
  },
  {
    accessorKey: "hour",
    header: "ساعت",
    cell: (info) => (
      <span className="td-mono text-xs">
        {toPersianNumerals(info.getValue() as number)}:۰۰
      </span>
    ),
    size: 70,
  },
  {
    accessorKey: "weekday",
    header: "روز",
    cell: (info) => <span className="text-xs">{info.getValue() as string}</span>,
    size: 100,
  },
];

export function TradeExplorerView() {
  const navigate = useAppStore((s) => s.navigate);
  const [side, setSide] = useState<SideFilter>("all");
  const [outcome, setOutcome] = useState<OutcomeFilter>("all");
  const [sorting, setSorting] = useState<SortingState>([{ id: "id", desc: false }]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  // Fetch real trades — server-side pagination at page_size=200 is enough
  // for in-table client-side filtering/sorting on the loaded page. For very
  // large analyses (>1000 trades), the user can still navigate via the
  // standard history view.
  const { data, isLoading, error, noAnalysisSelected, refetch } = useTrades({
    page: 1,
    pageSize: 200,
  });

  // Apply side/outcome filters client-side on top of the loaded page.
  // (The backend also supports server-side filters via query params; we
  // use the client-side path here so chip toggles feel instant without
  // a network round-trip.)
  const trades: Trade[] = useMemo(() => {
    if (!data?.trades) return [];
    return data.trades.filter((t) => {
      if (side !== "all" && t.side !== side) return false;
      if (outcome === "win" && t.profit <= 0) return false;
      if (outcome === "loss" && t.profit >= 0) return false;
      return true;
    });
  }, [data, side, outcome]);

  const table = useReactTable({
    data: trades,
    columns: COLUMNS,
    state: { sorting, columnFilters },
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: PAGE_SIZE } },
  });

  // Aggregate stats over the filtered set.
  const totalPnL = trades.reduce((s, t) => s + t.profit, 0);
  const winCount = trades.filter((t) => t.profit > 0).length;
  const winRate = trades.length ? (winCount / trades.length) * 100 : 0;
  const maxWin = trades.length ? Math.max(...trades.map((t) => t.profit)) : 0;

  const safePage = table.getState().pagination.pageIndex + 1;
  const totalPages = table.getPageCount();

  const selectedTrade = selectedId
    ? trades.find((t) => t.id === selectedId) ?? null
    : null;

  const exportCSV = () => {
    const rows = trades
      .map((t) => `${t.id},${t.open_time},${t.side ?? ""},${t.size},${t.profit},${t.hour},${t.weekday},${t.date}`)
      .join("\n");
    const blob = new Blob(["id,open_time,side,size,profit,hour,weekday,date\n" + rows], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trades_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const reset = (fn: () => void) => () => { fn(); table.setPageIndex(0); };
  const openTrade = (id: number) => () => setSelectedId(id);

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای کاوش معاملات خام، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !data) {
    return <ErrorState description={error || "دریافت فهرست معاملات ناموفق بود."} onRetry={refetch} />;
  }

  return (
    <div className="space-y-4 fade-up">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold mb-1">کاوش معاملات</h1>
          <p className="text-sm text-muted-foreground">معاملات خام را نشانم بده</p>
        </div>
        <button
          onClick={exportCSV}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-xs font-medium hover:bg-accent transition-colors td-press"
          aria-label="خروجی CSV"
        >
          <DownloadSimple size={14} />
          <span className="hidden sm:inline">خروجی CSV</span>
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <StatCard label="تعداد معاملات" value={toPersianNumerals(trades.length)} />
        <StatCard label="کل سود/زیان" value={formatCurrency(totalPnL)} trend={totalPnL >= 0 ? "up" : "down"} />
        <StatCard label="وین‌ریت" value={`${toPersianNumerals(winRate.toFixed(1))}٪`} />
        <StatCard label="بیشترین سود" value={formatCurrency(maxWin)} trend="up" />
      </div>

      <Card className="p-3">
        <div className="flex flex-wrap items-center gap-2">
          <Funnel size={14} className="text-muted-foreground" />
          {data?.side_available !== false && (
            <>
              <span className="text-xs text-muted-foreground">سمت:</span>
              {([["all", "همه"], ["Long", "Long"], ["Short", "Short"]] as const).map(([v, lbl]) => (
                <Chip key={v} label={`فقط ${lbl}`} active={side === v} onClick={reset(() => setSide(v))}>{lbl}</Chip>
              ))}
              <div className="w-px h-5 bg-border mx-1" />
            </>
          )}
          <span className="text-xs text-muted-foreground">نتیجه:</span>
          {([["all", "همه"], ["win", "سود"], ["loss", "زیان"]] as const).map(([v, lbl]) => (
            <Chip key={v} label={`فقط ${lbl}`} active={outcome === v} onClick={reset(() => setOutcome(v))}>{lbl}</Chip>
          ))}
          <div className="w-px h-5 bg-border mx-1" />
          <span className="text-xs text-muted-foreground">مرتب‌سازی:</span>
          <select
            value={sorting[0]?.id ?? "id"}
            onChange={(e) => {
              const id = e.target.value as "id" | "profit" | "size" | "open_time";
              setSorting([{ id, desc: id === "profit" || id === "size" }]);
            }}
            className="px-2 py-1.5 rounded-lg bg-accent text-xs border border-border"
            aria-label="مرتب‌سازی بر اساس"
          >
            <option value="id">تاریخ</option>
            <option value="profit">سود</option>
            <option value="size">حجم</option>
          </select>
        </div>
      </Card>

      <Card className="hidden md:block overflow-hidden">
        <div className="overflow-auto max-h-[60vh]">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-card z-10">
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id} className="border-b border-border text-xs text-muted-foreground">
                  {hg.headers.map((header) => (
                    <th
                      key={header.id}
                      className="text-start p-2 font-medium"
                      style={{ width: header.getSize() }}
                    >
                      {header.isPlaceholder
                        ? null
                        : flexRender(header.column.columnDef.header, header.getContext())}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map((row) => (
                <tr
                  key={row.id}
                  className="border-b border-border/50 cursor-pointer hover:bg-accent/40 transition-colors"
                  onClick={openTrade(row.original.id)}
                >
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="p-2">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))}
              {table.getRowModel().rows.length === 0 && (
                <tr>
                  <td colSpan={COLUMNS.length} className="p-6 text-center text-xs text-muted-foreground">
                    هیچ معامله‌ای با فیلتر فعلی یافت نشد.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="md:hidden space-y-2">
        {table.getRowModel().rows.map((row) => {
          const t = row.original;
          return (
            <Card
              key={t.id}
              className="p-3 cursor-pointer td-card-hover td-press"
              onClick={openTrade(t.id)}
              role="button"
              tabIndex={0}
              aria-label={`معامله شماره ${t.id}`}
              onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setSelectedId(t.id))}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground td-mono">#{toPersianNumerals(t.id)}</span>
                <span style={{ color: sideColor(t) }} className="text-xs">{t.side ?? "—"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{t.open_time}</span>
                <span className="td-mono text-sm font-bold" style={{ color: pnlColor(t.profit) }}>
                  {formatCurrency(t.profit)}
                </span>
              </div>
            </Card>
          );
        })}
        {table.getRowModel().rows.length === 0 && (
          <div className="text-center text-xs text-muted-foreground p-4">
            هیچ معامله‌ای با فیلتر فعلی یافت نشد.
          </div>
        )}
      </div>

      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          صفحه‌ی {toPersianNumerals(safePage)} از {toPersianNumerals(Math.max(1, totalPages))} · {toPersianNumerals(trades.length)} معامله
        </span>
        <div className="flex items-center gap-2">
          <button onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className={PAGE_BTN} aria-label="صفحه‌ی قبل">
            <ArrowRight size={14} className="td-flip-rtl" />
          </button>
          <button onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className={PAGE_BTN} aria-label="صفحه‌ی بعد">
            <ArrowLeft size={14} className="td-flip-rtl" />
          </button>
        </div>
      </div>

      <Drawer open={selectedTrade !== null} onOpenChange={(o) => !o && setSelectedId(null)}>
        <DrawerContent>
          <DrawerHeader>
            <DrawerTitle>جزئیات معامله #{selectedTrade ? toPersianNumerals(selectedTrade.id) : ""}</DrawerTitle>
            <DrawerDescription>اطلاعات کامل معامله‌ی انتخاب‌شده</DrawerDescription>
          </DrawerHeader>
          {selectedTrade && (
            <div className="px-4 pb-6 space-y-2">
              {([
                ["زمان باز کردن", selectedTrade.open_time],
                ["سمت", selectedTrade.side ?? "—"],
                ["حجم", toPersianNumerals(selectedTrade.size.toFixed(2))],
                ["سود/زیان", formatCurrency(selectedTrade.profit), pnlColor(selectedTrade.profit)],
                ["ساعت", `${toPersianNumerals(selectedTrade.hour)}:۰۰`],
                ["روز هفته", selectedTrade.weekday],
                ["تاریخ", selectedTrade.date],
              ] as const).map(([label, value, color]) => (
                <div key={label} className="flex items-center justify-between p-3 rounded-lg bg-accent/40">
                  <span className="text-sm text-muted-foreground">{label}</span>
                  <span className="td-mono text-sm font-semibold" style={color ? { color } : undefined}>{value}</span>
                </div>
              ))}
            </div>
          )}
        </DrawerContent>
      </Drawer>
    </div>
  );
}
