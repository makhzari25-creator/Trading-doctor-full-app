/**
 * Trading Doctor — Diagnosis View (Evidence Explorer)
 * Phase 4 §16.
 */

"use client";

import { Card } from "@/components/ui/card";
import { SeverityBadge } from "@/components/td/score-gauge";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { Warning, CaretDown, ArrowLeft, Funnel } from "@phosphor-icons/react";
import { useState } from "react";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals, formatCurrency, cn } from "@/lib/utils";

export function DiagnosisView() {
  const navigate = useAppStore((s) => s.navigate);
  const [expandedEvidence, setExpandedEvidence] = useState<number | null>(0);
  const [showAll, setShowAll] = useState(false);
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی تشخیص، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const filteredEvidence = r.evidence.filter((e) => {
    if (severityFilter === "all") return true;
    const labels = ["پایین", "متوسط", "بالا", "بحرانی"];
    return labels[e.severity] === severityFilter;
  });

  const visibleEvidence = showAll ? filteredEvidence : filteredEvidence.slice(0, 3);
  const severityColors = [
    "var(--severity-low)",
    "var(--severity-medium)",
    "var(--severity-high)",
    "var(--severity-critical)",
  ];

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">تشخیص</h1>
        <p className="text-sm text-muted-foreground">چرا موتور این نتیجه را گرفت؟</p>
      </div>

      {/* Primary Diagnosis */}
      <Card
        className="p-4"
        style={{ borderInlineStartWidth: "4px", borderInlineStartColor: "var(--severity-critical)" }}
      >
        <div className="flex items-start gap-3 mb-3">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: "color-mix(in srgb, var(--severity-critical) 15%, transparent)" }}
          >
            <Warning size={20} weight="fill" style={{ color: "var(--severity-critical)" }} />
          </div>
          <div className="flex-1">
            <div className="text-xs text-muted-foreground mb-1">مشکل اصلی</div>
            <h2 className="text-lg font-bold mb-2">{r.diagnosis.primary}</h2>
            <div className="flex items-center gap-2 mb-3">
              <SeverityBadge severity="Critical" size="sm" />
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{r.diagnosis.primary_detail}</p>
          </div>
        </div>
      </Card>

      {/* Secondary Diagnosis */}
      {r.diagnosis.secondary && (
        <Card
          className="p-4"
          style={{ borderInlineStartWidth: "4px", borderInlineStartColor: "var(--severity-high)" }}
        >
          <div className="flex items-start gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
              style={{ backgroundColor: "color-mix(in srgb, var(--severity-high) 15%, transparent)" }}
            >
              <Warning size={20} weight="fill" style={{ color: "var(--severity-high)" }} />
            </div>
            <div className="flex-1">
              <div className="text-xs text-muted-foreground mb-1">مشکل ثانویه</div>
              <h3 className="text-base font-bold mb-2">{r.diagnosis.secondary}</h3>
              <SeverityBadge severity="High" size="sm" />
              <p className="text-sm text-muted-foreground leading-relaxed mt-2">
                {r.diagnosis.secondary_detail}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Evidence Section */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            شواهد
            <span className="px-1.5 py-0.5 rounded text-xs bg-accent text-muted-foreground">
              {toPersianNumerals(r.evidence.length)}
            </span>
          </h2>
        </div>

        {/* Filter pills */}
        <div className="flex items-center gap-1.5 mb-3 overflow-x-auto pb-1">
          <Funnel size={14} className="text-muted-foreground shrink-0" />
          {["همه", "بحرانی", "بالا", "متوسط", "پایین"].map((label) => (
            <button
              key={label}
              onClick={() => setSeverityFilter(label)}
              className={cn(
                "px-2.5 py-1 rounded-full text-xs whitespace-nowrap transition-colors border",
                severityFilter === label
                  ? "bg-[var(--primary)] text-white border-[var(--primary)]"
                  : "border-border text-muted-foreground hover:bg-accent"
              )}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Evidence Cards */}
        <div className="space-y-2">
          {visibleEvidence.map((ev, idx) => {
            const isExpanded = expandedEvidence === idx;
            const color = severityColors[ev.severity] || "var(--severity-medium)";
            return (
              <Card
                key={idx}
                className="overflow-hidden cursor-pointer transition-all td-card-hover"
                style={{ borderInlineStartWidth: "3px", borderInlineStartColor: color }}
                onClick={() => setExpandedEvidence(isExpanded ? null : idx)}
              >
                <div className="p-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <Warning size={16} weight="fill" style={{ color }} className="shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{ev.label}</div>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
                        <span className="td-mono">{toPersianNumerals(ev.frequency)} رویداد</span>
                        <span>·</span>
                        <span className="td-mono" style={{ color: "var(--profit-negative)" }}>
                          {formatCurrency(ev.financial_impact, false)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <SeverityBadge severity={ev.severity} size="sm" />
                    <CaretDown
                      size={14}
                      className={`text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`}
                    />
                  </div>
                </div>
                {isExpanded && (
                  <div className="px-3 pb-3 space-y-2 border-t border-border pt-2 fade-in">
                    <p className="text-sm text-muted-foreground leading-relaxed">{ev.description}</p>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">اولویت</div>
                        <div className="flex items-center gap-1.5">
                          <div className="flex-1 h-1.5 rounded-full bg-accent overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{ width: `${ev.priority_score}%`, backgroundColor: color }}
                            />
                          </div>
                          <span className="td-mono text-xs font-bold">{toPersianNumerals(ev.priority_score)}</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">اطمینان</div>
                        <div className="flex items-center gap-1.5">
                          <div className="flex-1 h-1.5 rounded-full bg-accent overflow-hidden">
                            <div
                              className="h-full rounded-full bg-[var(--primary)]"
                              style={{ width: `${ev.confidence}%` }}
                            />
                          </div>
                          <span className="td-mono text-xs font-bold">{toPersianNumerals(ev.confidence)}٪</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate("trade-explorer");
                      }}
                      className="text-xs text-[var(--primary)] hover:underline flex items-center gap-1"
                    >
                      مشاهده‌ی معاملات مرتبط
                      <ArrowLeft size={12} className="td-flip-rtl" />
                    </button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {!showAll && filteredEvidence.length > 3 && (
          <button
            onClick={() => setShowAll(true)}
            className="w-full mt-2 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent/50 rounded-lg transition-colors border border-dashed border-border"
          >
            نمایش همه‌ی شواهد ({toPersianNumerals(filteredEvidence.length - 3)} مورد بیشتر)
          </button>
        )}
      </div>

      <button
        onClick={() => navigate("coaching")}
        className="w-full py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2 td-press"
      >
        برنامه‌ی اقدام را ببین
        <ArrowLeft size={14} className="td-flip-rtl" />
      </button>
    </div>
  );
}
