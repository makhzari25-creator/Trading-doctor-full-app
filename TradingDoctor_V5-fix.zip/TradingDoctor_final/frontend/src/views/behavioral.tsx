/**
 * Trading Doctor — Behavioral Analysis View
 * 5 ContextBlockCards with expand/collapse, severity borders, What-If, radar chart.
 * Phase 4 §11.
 */

"use client";

import { Card } from "@/components/ui/card";
import { ScoreGauge, SeverityBadge } from "@/components/td/score-gauge";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { Warning, CheckCircle, CaretDown, ArrowLeft } from "@phosphor-icons/react";
import { useState } from "react";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals, formatCurrency, severityColor } from "@/lib/utils";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";

export function BehavioralView() {
  const navigate = useAppStore((s) => s.navigate);
  const [expandedKey, setExpandedKey] = useState<string | null>("revenge_score");
  const [whatIfOpen, setWhatIfOpen] = useState(false);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی تحلیل رفتاری، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const criticalCount = r.behavior_analysis.context_rows.filter(
    (c) => c.severity === "Critical" || c.severity === "High"
  ).length;

  const radarData = r.behavior_analysis.context_rows.map((c) => ({
    subject: c.label,
    value: c.score,
  }));

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">تحلیل رفتاری</h1>
        <p className="text-sm text-muted-foreground">
          {toPersianNumerals(criticalCount)} رفتار نیاز به توجه دارد
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-3">
          {r.behavior_analysis.context_rows.map((ctx) => {
            const isExpanded = expandedKey === ctx.key;
            const color = severityColor(ctx.severity);
            return (
              <Card
                key={ctx.key}
                className="overflow-hidden transition-all cursor-pointer td-card-hover"
                style={{ borderInlineStartWidth: "4px", borderInlineStartColor: color }}
                onClick={() => setExpandedKey(isExpanded ? null : ctx.key)}
              >
                <div className="p-4 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {ctx.severity === "Low" ? (
                      <CheckCircle size={20} weight="fill" style={{ color }} />
                    ) : (
                      <Warning size={20} weight="fill" style={{ color }} />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{ctx.label}</div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="td-mono text-xs text-muted-foreground">
                          امتیاز: {toPersianNumerals(ctx.score)}٪
                        </span>
                        <SeverityBadge severity={ctx.severity} size="sm" />
                      </div>
                    </div>
                  </div>
                  <CaretDown
                    size={16}
                    className={`text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`}
                  />
                </div>
                {isExpanded && (
                  <div className="px-4 pb-4 space-y-3 border-t border-border pt-3 fade-in">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-accent/30 rounded-lg p-2">
                        <div className="text-xs text-muted-foreground">ضرر</div>
                        <div className="td-mono font-bold text-sm" style={{ color: "var(--profit-negative)" }}>
                          {formatCurrency(ctx.dollars_lost, false)}
                        </div>
                      </div>
                      <div className="bg-accent/30 rounded-lg p-2">
                        <div className="text-xs text-muted-foreground">٪ از سود کل</div>
                        <div className="td-mono font-bold text-sm">{toPersianNumerals(ctx.pct_of_total_profit)}٪</div>
                      </div>
                      <div className="bg-accent/30 rounded-lg p-2">
                        <div className="text-xs text-muted-foreground">رویدادها</div>
                        <div className="td-mono font-bold text-sm">{toPersianNumerals(ctx.event_count)}</div>
                      </div>
                      <div className="bg-accent/30 rounded-lg p-2">
                        <div className="text-xs text-muted-foreground">میانگین/رویداد</div>
                        <div className="td-mono font-bold text-sm">
                          {ctx.event_count > 0
                            ? `$${toPersianNumerals(Math.round(ctx.dollars_lost / ctx.event_count))}`
                            : "—"}
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{ctx.insight}</p>

                    {ctx.key === "revenge_score" && (
                      <div className="rounded-lg border border-border p-3 bg-accent/20">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setWhatIfOpen(!whatIfOpen);
                          }}
                          className="flex items-center justify-between w-full text-sm font-medium"
                        >
                          <span>شبیه‌سازی What-If</span>
                          <CaretDown size={14} className={`transition-transform ${whatIfOpen ? "rotate-180" : ""}`} />
                        </button>
                        {whatIfOpen && (
                          <div className="mt-2 text-sm text-muted-foreground space-y-1 fade-in">
                            <p>اگر معامله‌ی انتقامی را اصلاح می‌کردید:</p>
                            <div className="flex justify-between">
                              <span>سود فعلی:</span>
                              <span className="td-mono">+$۱٬۲۴۰</span>
                            </div>
                            <div className="flex justify-between">
                              <span>سود شبیه‌سازی‌شده:</span>
                              <span className="td-mono font-bold" style={{ color: "var(--profit-positive)" }}>
                                +$۳٬۰۸۰
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>تفاوت:</span>
                              <span className="td-mono font-bold" style={{ color: "var(--profit-positive)" }}>
                                +$۱٬۸۴۰ (۱۴۹٪)
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate("diagnosis");
                      }}
                      className="text-xs text-[var(--primary)] hover:underline flex items-center gap-1"
                    >
                      شواهد این رفتار
                      <ArrowLeft size={12} className="td-flip-rtl" />
                    </button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {/* Radar chart — desktop */}
        <div className="hidden lg:block">
          <Card className="p-4 sticky top-20">
            <h3 className="text-sm font-semibold mb-3">مقایسه‌ی امتیازها</h3>
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="var(--border)" />
                <PolarAngleAxis
                  dataKey="subject"
                  tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                />
                <PolarRadiusAxis
                  domain={[0, 100]}
                  tick={{ fill: "var(--muted-foreground)", fontSize: 10 }}
                />
                <Radar
                  dataKey="value"
                  stroke="var(--chart-1)"
                  fill="var(--chart-1)"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </div>
    </div>
  );
}
