/**
 * Trading Doctor — دی‌ان‌ای معامله‌گر View
 * Archetype hero, psychology narrative, supporting evidence, CTA to diagnosis.
 */

"use client";

import { Card } from "@/components/ui/card";
import { SeverityBadge } from "@/components/td/severity-badge";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals, cn } from "@/lib/utils";
import { Dna, ArrowLeft } from "@phosphor-icons/react";

const SEVERITY_COLOR = [
  "var(--severity-low)",
  "var(--severity-medium)",
  "var(--severity-high)",
  "var(--severity-critical)",
];

export function TraderDnaView() {
  const navigate = useAppStore((s) => s.navigate);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی دی‌ان‌ای معامله‌گر، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const dna = r.psychology.dna;
  const paragraphs = r.psychology.narrative.split("\n\n");
  const topEvidence = r.evidence.slice(0, 3);

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">دی‌ان‌ای معامله‌گر</h1>
        <p className="text-sm text-muted-foreground">من چه نوع معامله‌گری هستم؟</p>
      </div>

      {/* Hero archetype card */}
      <Card
        className="relative overflow-hidden p-5 td-card-hover"
        style={{
          borderInlineStartWidth: "4px",
          borderInlineStartColor: "var(--primary)",
        }}
      >
        <div className="flex items-start gap-4">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center shrink-0"
            style={{
              backgroundColor:
                "color-mix(in srgb, var(--primary) 15%, transparent)",
            }}
            aria-hidden="true"
          >
            <Dna size={36} weight="duotone" className="text-[var(--primary)]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-muted-foreground mb-1">آرچیتایپ شما</div>
            <h2 className="text-xl font-bold mb-2">{dna.archetype}</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {toPersianNumerals(r.executive_summary.summary_text)}
            </p>
            <div className="flex flex-wrap gap-1.5 mt-3">
              <span className="text-xs px-2 py-1 rounded-md bg-accent">
                الگوی غالب: {dna.dominant_pattern}
              </span>
              <span className="text-xs px-2 py-1 rounded-md bg-accent">
                اشتهای ریسک: {dna.risk_appetite}
              </span>
              <span className="text-xs px-2 py-1 rounded-md bg-accent">
                سطح انضباط: {dna.discipline_level}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Psychology narrative */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Dna size={18} className="text-[var(--primary)]" />
          <h3 className="text-sm font-semibold">روایت رفتاری</h3>
        </div>
        <div className="space-y-3">
          {paragraphs.map((p, i) => (
            <p key={i} className="text-sm leading-relaxed text-muted-foreground">
              {toPersianNumerals(p)}
            </p>
          ))}
        </div>
      </Card>

      {/* Supporting evidence */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-2">
          شواهد پشتیبان
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {topEvidence.map((ev) => {
            const color = SEVERITY_COLOR[ev.severity] || SEVERITY_COLOR[1];
            return (
              <Card
                key={ev.type}
                className={cn("p-4 td-card-hover td-press cursor-pointer")}
                style={{
                  borderInlineStartWidth: "3px",
                  borderInlineStartColor: color,
                }}
                onClick={() => navigate("diagnosis")}
                role="button"
                tabIndex={0}
                aria-label={`شواهد: ${ev.label}، ${ev.financial_impact_fmt}`}
                onKeyDown={(e) =>
                  (e.key === "Enter" || e.key === " ") &&
                  (e.preventDefault(), navigate("diagnosis"))
                }
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold">{ev.label}</span>
                  <SeverityBadge severity={ev.severity} size="sm" />
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed mb-2 line-clamp-2">
                  {ev.description}
                </p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">
                    {toPersianNumerals(ev.frequency)} رویداد
                  </span>
                  <span
                    className="td-mono font-semibold"
                    style={{ color: "var(--profit-negative)" }}
                  >
                    {ev.financial_impact_fmt}
                  </span>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* CTA */}
      <button
        onClick={() => navigate("diagnosis")}
        className="w-full py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] text-sm font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2 td-press"
        aria-label="مشاهده‌ی تشخیص کامل"
      >
        مشاهده‌ی تشخیص کامل
        <ArrowLeft size={16} className="td-flip-rtl" />
      </button>
    </div>
  );
}
