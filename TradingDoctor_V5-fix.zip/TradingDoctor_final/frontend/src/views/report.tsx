/**
 * Trading Doctor — گزارش View
 * Ready card with download actions, 7 expandable section previews, metadata.
 */

"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { downloadReportHtml, downloadReportPdf } from "@/lib/api";
import { toPersianNumerals } from "@/lib/utils";
import { CheckCircle, FilePdf, FileHtml, Printer, CaretDown } from "@phosphor-icons/react";
import { toast } from "sonner";
import type { AnalysisReport } from "@/lib/types";

type Report = AnalysisReport;

interface Section {
  id: string;
  title: string;
  excerpt: string;
  content: (r: Report) => string;
}

const SECTIONS: Section[] = [
  {
    id: "executive",
    title: "خلاصه‌ی اجرایی",
    excerpt: "نمای کلی از وضعیت معاملاتی و تشخیص اصلی",
    content: (r) => r.executive_summary.summary_text,
  },
  {
    id: "performance",
    title: "عملکرد",
    excerpt: "سود خالص، Profit Factor، وین‌ریت و آمار کلیدی",
    content: (r) =>
      `سود خالص: ${r.performance.net_profit_fmt} | Profit Factor: ${r.performance.profit_factor} | وین‌ریت: ${r.statistics.win_rate_pct}٪ | میانگین سود: ${r.performance.avg_win_fmt} | میانگین زیان: ${r.performance.avg_loss_fmt} | بیشترین افت: ${r.risk.max_drawdown_fmt}`,
  },
  {
    id: "behavioral",
    title: "تحلیل رفتاری",
    excerpt: "۵ بعد رفتاری معاملاتی و امتیاز هرکدام",
    content: (r) =>
      r.behavior_analysis.context_rows
        .map((c) => `${c.label}: ${c.score} از ۱۰۰ — ${c.insight}`)
        .join("\n"),
  },
  {
    id: "diagnosis",
    title: "تشخیص",
    excerpt: "تشخیص اصلی و فرعی به همراه جزئیات",
    content: (r) =>
      `تشخیص اصلی: ${r.diagnosis.primary}\n${r.diagnosis.primary_detail ?? ""}\n\nتشخیص ثانویه: ${r.diagnosis.secondary ?? "—"}\n${r.diagnosis.secondary_detail ?? ""}`,
  },
  {
    id: "coaching",
    title: "کوچینگ",
    excerpt: "برنامه‌ی اقدام و توصیه‌های هوش مصنوعی",
    content: (r) =>
      r.recommendations
        .map((rec) => `${rec.priority}. ${rec.issue}: ${rec.action}`)
        .join("\n"),
  },
  {
    id: "evidence",
    title: "شواهد",
    excerpt: "شواهد رفتاری با اولویت‌بندی",
    content: (r) =>
      r.evidence
        .map((e) => `${e.label} — شدت ${e.severity}، ${e.frequency} رویداد، ${e.financial_impact_fmt}`)
        .join("\n"),
  },
  {
    id: "appendix",
    title: "ضمیمه",
    excerpt: "هشدارهای کیفیت داده و متادیتای تولید",
    content: (r) => r.appendix.data_quality_warnings.join("\n"),
  },
];

function triggerBrowserDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function ReportView() {
  const navigate = useAppStore((s) => s.navigate);
  const analysisId = useAppStore((s) => s.currentAnalysisId);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();
  const [openId, setOpenId] = useState<string | null>("executive");
  const [downloading, setDownloading] = useState<"pdf" | "html" | "print" | null>(null);

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای دریافت گزارش، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const handleDownload = async (type: "pdf" | "html" | "print") => {
    if (!analysisId) return;
    const labels = { pdf: "PDF", html: "HTML", print: "پرینت" };
    setDownloading(type);
    try {
      if (type === "pdf") {
        const blob = await downloadReportPdf(analysisId);
        triggerBrowserDownload(blob, `trading-doctor-report-${analysisId}.pdf`);
      } else if (type === "html") {
        const html = await downloadReportHtml(analysisId);
        triggerBrowserDownload(new Blob([html], { type: "text/html" }), `trading-doctor-report-${analysisId}.html`);
      } else if (type === "print" && typeof window !== "undefined") {
        window.print();
      }
      toast.success(`گزارش ${labels[type]} آماده شد`);
    } catch {
      toast.error(`تولید گزارش ${labels[type]} ناموفق بود`, {
        description: "لطفاً دوباره تلاش کن.",
      });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">گزارش</h1>
        <p className="text-sm text-muted-foreground">گزارش قابل‌دانلود بده</p>
      </div>

      {/* Ready card */}
      <Card className="p-5">
        <div className="flex items-center gap-3 mb-4">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
            style={{
              backgroundColor: "color-mix(in srgb, var(--severity-low) 15%, transparent)",
            }}
            aria-hidden="true"
          >
            <CheckCircle size={22} weight="fill" style={{ color: "var(--severity-low)" }} />
          </div>
          <div className="min-w-0">
            <h2 className="text-base font-semibold">گزارش آماده است</h2>
            <p className="text-xs text-muted-foreground">
              {toPersianNumerals(r.statistics.total_trades)} معامله · {r.meta.engine_version}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={() => handleDownload("pdf")}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] text-sm font-medium hover:opacity-90 transition-opacity td-press"
            aria-label="دانلود PDF"
          >
            <FilePdf size={16} weight="fill" />
            دانلود PDF
          </button>
          <button
            onClick={() => handleDownload("html")}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors td-press"
            aria-label="دانلود HTML"
          >
            <FileHtml size={16} weight="fill" />
            دانلود HTML
          </button>
          <button
            onClick={() => handleDownload("print")}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors td-press"
            aria-label="پرینت گزارش"
          >
            <Printer size={16} weight="fill" />
            پرینت
          </button>
        </div>
      </Card>

      {/* 7 section accordions */}
      <div className="space-y-2">
        {SECTIONS.map((s) => {
          const open = openId === s.id;
          return (
            <Card key={s.id} className="overflow-hidden">
              <button
                onClick={() => setOpenId(open ? null : s.id)}
                className="w-full flex items-center justify-between gap-3 p-3 hover:bg-accent/40 transition-colors text-start"
                aria-expanded={open}
                aria-controls={`section-${s.id}`}
                aria-label={`${open ? "بستن" : "باز کردن"} بخش ${s.title}`}
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold">{s.title}</div>
                  <div className="text-xs text-muted-foreground truncate">{s.excerpt}</div>
                </div>
                <CaretDown
                  size={16}
                  className={`text-muted-foreground transition-transform shrink-0 ${open ? "rotate-180" : ""}`}
                  aria-hidden="true"
                />
              </button>
              {open && (
                <div
                  id={`section-${s.id}`}
                  className="px-3 pb-3 pt-1 border-t border-border"
                >
                  <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                    {toPersianNumerals(s.content(r))}
                  </p>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* Metadata */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3">متادیتا</h3>
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <div className="text-muted-foreground">عنوان گزارش</div>
            <div className="font-medium mt-0.5">{r.meta.report_title}</div>
          </div>
          <div>
            <div className="text-muted-foreground">زمان تولید</div>
            <div className="td-mono font-medium mt-0.5">{r.meta.generated_at}</div>
          </div>
          <div>
            <div className="text-muted-foreground">نسخه‌ی موتور</div>
            <div className="font-medium mt-0.5">{r.meta.engine_version}</div>
          </div>
          <div>
            <div className="text-muted-foreground">تعداد معاملات</div>
            <div className="td-mono font-medium mt-0.5">
              {toPersianNumerals(r.meta.total_trades)}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
