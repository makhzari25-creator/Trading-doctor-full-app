/**
 * Trading Doctor — روند تغییرات View
 * Score-over-time line chart + comparison table of past analyses.
 * EmptyState when fewer than 2 analyses exist.
 */

"use client";

import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useHistory } from "@/lib/hooks/use-history";
import { toPersianNumerals, formatDate } from "@/lib/utils";
import { TrendUp, ArrowLeft } from "@phosphor-icons/react";
import {
  Line,
  LineChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const tooltipStyle = {
  backgroundColor: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "8px",
  fontSize: "12px",
} as const;

export function TrendsView() {
  const navigate = useAppStore((s) => s.navigate);
  const setAnalysisId = useAppStore((s) => s.setAnalysisId);
  const { items: history, isLoading, error, refetch } = useHistory();

  if (isLoading) return <PageSkeleton />;
  if (error) {
    return (
      <div className="fade-up">
        <ErrorState description={error} onRetry={refetch} />
      </div>
    );
  }

  if (history.length < 2) {
    return (
      <div className="fade-up">
        <EmptyState
          icon={TrendUp}
          title="هنوز روندی برای نمایش وجود ندارد"
          description="برای دیدن روند، حداقل ۲ تحلیل لازم است. اولین فایل خود را آپلود کنید."
          ctaLabel="آپلود فایل معاملات"
          onCta={() => navigate("upload")}
        />
      </div>
    );
  }

  const chronological = [...history].reverse();
  const data = chronological.map((h) => ({
    name: h.filename.replace(/\.[a-zA-Z0-9]+$/, ""),
    score: h.overall_score,
    date: formatDate(h.created_at),
  }));

  const scores = history.map((h) => h.overall_score);
  const min = Math.min(...scores);
  const max = Math.max(...scores);
  const delta = scores[0] - scores[scores.length - 1];

  const openAnalysis = (analysisId: string) => {
    setAnalysisId(analysisId);
    navigate("dashboard");
  };

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">روند تغییرات</h1>
        <p className="text-sm text-muted-foreground">آیا در حال بهبود هستم؟</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="p-3">
          <div className="text-xs text-muted-foreground">بالاترین امتیاز</div>
          <div className="td-mono font-bold text-lg" style={{ color: "var(--profit-positive)" }}>
            {toPersianNumerals(max)}
          </div>
        </Card>
        <Card className="p-3">
          <div className="text-xs text-muted-foreground">پایین‌ترین امتیاز</div>
          <div className="td-mono font-bold text-lg" style={{ color: "var(--profit-negative)" }}>
            {toPersianNumerals(min)}
          </div>
        </Card>
        <Card className="p-3">
          <div className="text-xs text-muted-foreground">تغییر کلی</div>
          <div
            className="td-mono font-bold text-lg"
            style={{ color: delta >= 0 ? "var(--profit-positive)" : "var(--profit-negative)" }}
          >
            {delta >= 0 ? "+" : ""}
            {toPersianNumerals(delta)}
          </div>
        </Card>
      </div>

      {/* Line chart */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-1">
          <TrendUp size={18} className="text-[var(--primary)]" />
          <h3 className="text-sm font-semibold">روند امتیاز انضباط</h3>
        </div>
        <p className="text-xs text-muted-foreground mb-3">تغییر امتیاز کلی در تحلیل‌های قبلی</p>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis
              dataKey="name"
              tick={{ fill: "var(--muted-foreground)", fontSize: 10 }}
              reversed
            />
            <YAxis
              domain={[0, 100]}
              tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
              orientation="right"
            />
            <Tooltip contentStyle={tooltipStyle} />
            <Line
              type="monotone"
              dataKey="score"
              stroke="var(--chart-1)"
              strokeWidth={2}
              dot={{ fill: "var(--chart-1)", r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Comparison table */}
      <Card className="overflow-hidden">
        <div className="p-3 border-b border-border">
          <h3 className="text-sm font-semibold">مقایسه‌ی تحلیل‌های گذشته</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-xs text-muted-foreground">
                <th className="text-start p-2 font-medium">فایل</th>
                <th className="text-start p-2 font-medium">تاریخ</th>
                <th className="text-start p-2 font-medium">معاملات</th>
                <th className="text-start p-2 font-medium">امتیاز</th>
                <th className="text-start p-2 font-medium">تشخیص</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr
                  key={h.analysis_id}
                  className="border-b border-border/50 cursor-pointer hover:bg-accent/40 transition-colors"
                  onClick={() => openAnalysis(h.analysis_id)}
                  role="button"
                  tabIndex={0}
                  aria-label={`باز کردن تحلیل ${h.filename}`}
                  onKeyDown={(e) =>
                    (e.key === "Enter" || e.key === " ") &&
                    (e.preventDefault(), openAnalysis(h.analysis_id))
                  }
                >
                  <td className="p-2 text-xs">{h.filename}</td>
                  <td className="p-2 text-xs text-muted-foreground">{formatDate(h.created_at)}</td>
                  <td className="p-2 td-mono text-xs">{toPersianNumerals(h.total_trades)}</td>
                  <td className="p-2 td-mono text-xs font-bold">{toPersianNumerals(h.overall_score)}</td>
                  <td className="p-2 text-xs text-muted-foreground">{h.primary_diagnosis}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <button
        onClick={() => navigate("upload")}
        className="w-full py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] text-sm font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2 td-press"
        aria-label="آپلود فایل جدید"
      >
        آپلود فایل جدید
        <ArrowLeft size={16} className="td-flip-rtl" />
      </button>
    </div>
  );
}
