/**
 * Trading Doctor — Coaching View (AI Coach)
 * Phase 4 §13.
 */

"use client";

import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { Lightbulb, CaretDown, Check, ArrowLeft, Info, FileText } from "@phosphor-icons/react";
import { useState } from "react";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals } from "@/lib/utils";

const PRIORITY_COLORS: Record<string, string> = {
  P1: "var(--severity-critical)",
  P2: "var(--severity-high)",
  P3: "var(--severity-medium)",
  P4: "var(--severity-medium)",
  P5: "var(--severity-low)",
};

export function CoachingView() {
  const navigate = useAppStore((s) => s.navigate);
  const [expandedRec, setExpandedRec] = useState<number | null>(0);
  const [showAll, setShowAll] = useState(false);
  const [doneStates, setDoneStates] = useState<Record<number, boolean>>({});
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی برنامه‌ی مربی‌گری، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const visibleRecs = showAll ? r.recommendations : r.recommendations.slice(0, 3);

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">برنامه‌ی اقدام</h1>
        <p className="text-sm text-muted-foreground">
          {toPersianNumerals(r.recommendations.length)} گام برای این هفته
        </p>
      </div>

      {/* Recommendation Cards */}
      <div className="space-y-2">
        {visibleRecs.map((rec, idx) => {
          const isExpanded = expandedRec === idx;
          const isDone = doneStates[idx];
          const color = PRIORITY_COLORS[rec.priority] || "var(--severity-medium)";
          return (
            <Card
              key={idx}
              className={`overflow-hidden transition-all ${isDone ? "opacity-60" : ""}`}
              style={{ borderInlineStartWidth: "3px", borderInlineStartColor: color }}
            >
              <div className="p-3">
                <div className="flex items-start gap-3">
                  <span
                    className="shrink-0 px-2 py-0.5 rounded text-xs font-bold td-mono"
                    style={{ color, backgroundColor: `color-mix(in srgb, ${color} 15%, transparent)` }}
                  >
                    {rec.priority}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-muted-foreground mb-1">{rec.issue}</div>
                    <p className={`text-sm font-medium leading-relaxed ${isDone ? "line-through" : ""}`}>
                      {rec.action}
                    </p>
                  </div>
                  <button
                    onClick={() => setExpandedRec(isExpanded ? null : idx)}
                    className="shrink-0 p-1 rounded hover:bg-accent transition-colors"
                    aria-label="نمایش دلیل"
                  >
                    <CaretDown
                      size={16}
                      className={`text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`}
                    />
                  </button>
                </div>
                {isExpanded && rec.rationale && (
                  <div className="mt-3 pt-3 border-t border-border text-sm text-muted-foreground leading-relaxed fade-in">
                    <div className="text-xs font-semibold text-foreground mb-1">چرا؟</div>
                    {rec.rationale}
                  </div>
                )}
                <div className="mt-3 flex items-center justify-between">
                  <button
                    onClick={() => setDoneStates({ ...doneStates, [idx]: !isDone })}
                    className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <span
                      className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${
                        isDone
                          ? "bg-[var(--severity-low)] border-[var(--severity-low)]"
                          : "border-border"
                      }`}
                    >
                      {isDone && <Check size={12} weight="bold" className="text-white spring-bounce" />}
                    </span>
                    {isDone ? "انجام شد" : "علامت‌گذاری به‌عنوان انجام شده"}
                  </button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {!showAll && r.recommendations.length > 3 && (
        <button
          onClick={() => setShowAll(true)}
          className="w-full py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent/50 rounded-lg transition-colors border border-dashed border-border"
        >
          نمایش گام‌های بیشتر ({toPersianNumerals(r.recommendations.length - 3)} مورد)
        </button>
      )}

      {/* AI Coaching Narrative */}
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: "color-mix(in srgb, var(--cta) 15%, transparent)" }}
          >
            <Lightbulb size={18} weight="fill" style={{ color: "var(--cta)" }} />
          </div>
          <h3 className="text-sm font-semibold flex-1">روانشناسی این برنامه</h3>
          <span className="px-2 py-0.5 rounded text-xs bg-accent text-muted-foreground">
            توضیح الگوریتمی
          </span>
        </div>
        <div className="space-y-3">
          {r.ai_coaching.explainable_ai.split("\n\n").map((para, i) => (
            <p key={i} className="text-sm leading-relaxed text-muted-foreground">
              {para}
            </p>
          ))}
        </div>
      </Card>

      {/* Reality Check */}
      <Card className="p-4 bg-accent/20">
        <div className="flex items-center gap-2 mb-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: "color-mix(in srgb, var(--primary) 15%, transparent)" }}
          >
            <Info size={18} style={{ color: "var(--primary)" }} />
          </div>
          <h3 className="text-sm font-semibold">واقعیت‌بینی</h3>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">{r.ai_coaching.reality_check}</p>
      </Card>

      {/* CTA */}
      <button
        onClick={() => navigate("report")}
        className="w-full py-3 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors flex items-center justify-center gap-2 td-press"
      >
        <FileText size={16} />
        گزارش کامل را دانلود کن
        <ArrowLeft size={14} className="td-flip-rtl" />
      </button>
    </div>
  );
}
