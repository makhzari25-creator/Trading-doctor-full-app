/**
 * Trading Doctor — تاریخچه View
 * List of past analyses with ScoreGauge, ⋯ menu (Open/PDF/Delete), upload CTA.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { ScoreGauge } from "@/components/td/score-gauge";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useHistory } from "@/lib/hooks/use-history";
import { deleteAnalysis, downloadReportPdf, ApiError } from "@/lib/api";
import { toPersianNumerals, formatDate } from "@/lib/utils";
import {
  ClockCounterClockwise,
  DotsThree,
  Trash,
  FilePdf,
  UploadSimple,
} from "@phosphor-icons/react";
import { toast } from "sonner";

export function HistoryView() {
  const navigate = useAppStore((s) => s.navigate);
  const setAnalysisId = useAppStore((s) => s.setAnalysisId);
  const { items, isLoading, error, refetch } = useHistory();
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpenId(null);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  if (isLoading) return <PageSkeleton />;
  if (error) {
    return (
      <div className="fade-up">
        <ErrorState description={error} onRetry={refetch} />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="fade-up">
        <EmptyState
          icon={ClockCounterClockwise}
          title="هنوز تحلیلی انجام نداده‌ید"
          description="اولین فایل معاملات خود را آپلود کنید تا تحلیل‌ها در اینجا ذخیره شوند."
          ctaLabel="آپلود فایل"
          onCta={() => navigate("upload")}
        />
      </div>
    );
  }

  const openAnalysis = (analysisId: string) => {
    setAnalysisId(analysisId);
    navigate("dashboard");
  };

  const handleDelete = async (id: string) => {
    setMenuOpenId(null);
    setPendingDeleteId(id);
    try {
      await deleteAnalysis(id);
      toast.success("تحلیل حذف شد");
      refetch();
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "حذف تحلیل ناموفق بود";
      toast.error(message);
    } finally {
      setPendingDeleteId(null);
    }
  };

  const handlePdf = async (id: string, filename: string) => {
    setMenuOpenId(null);
    try {
      const blob = await downloadReportPdf(id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${filename.replace(/\.[a-zA-Z0-9]+$/, "")}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success(`گزارش PDF برای ${filename} آماده شد`);
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "تولید PDF ناموفق بود";
      toast.error(message);
    }
  };

  return (
    <div className="space-y-4 fade-up">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold mb-1">تاریخچه</h1>
          <p className="text-sm text-muted-foreground">قبلاً چه تحلیل کرده‌ام؟</p>
        </div>
        <button
          onClick={() => navigate("upload")}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] text-sm font-medium hover:opacity-90 transition-opacity td-press"
          aria-label="آپلود فایل جدید"
        >
          <UploadSimple size={16} />
          <span className="hidden sm:inline">آپلود</span>
        </button>
      </div>

      <div className="space-y-2">
        {items.map((h) => {
          const open = menuOpenId === h.analysis_id;
          const deleting = pendingDeleteId === h.analysis_id;
          return (
            <Card
              key={h.analysis_id}
              className="p-3 cursor-pointer td-card-hover td-press relative"
              style={deleting ? { opacity: 0.5, pointerEvents: "none" } : undefined}
              onClick={() => openAnalysis(h.analysis_id)}
              role="button"
              tabIndex={0}
              aria-label={`تحلیل ${h.filename}، امتیاز ${h.overall_score}`}
              onKeyDown={(e) =>
                (e.key === "Enter" || e.key === " ") &&
                (e.preventDefault(), openAnalysis(h.analysis_id))
              }
            >
              <div className="flex items-center gap-3">
                <ScoreGauge
                  value={h.overall_score}
                  size={48}
                  strokeWidth={4}
                  animate={false}
                />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold truncate">{h.filename}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {formatDate(h.created_at)} · {toPersianNumerals(h.total_trades)} معامله
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5 truncate">
                    تشخیص: {h.primary_diagnosis}
                  </div>
                </div>
                <div
                  className="relative"
                  ref={open ? menuRef : undefined}
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpenId(open ? null : h.analysis_id);
                    }}
                    className="p-2 rounded-lg hover:bg-accent transition-colors"
                    aria-label="منوی اقدامات تحلیل"
                    aria-haspopup="true"
                    aria-expanded={open}
                  >
                    <DotsThree size={20} weight="bold" />
                  </button>
                  {open && (
                    <div
                      className="absolute end-0 top-full mt-1 z-20 w-40 rounded-lg border border-border bg-popover shadow-lg py-1 fade-in"
                      onClick={(e) => e.stopPropagation()}
                      role="menu"
                    >
                      <button
                        role="menuitem"
                        onClick={() => {
                          setMenuOpenId(null);
                          openAnalysis(h.analysis_id);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-start hover:bg-accent transition-colors"
                      >
                        <ClockCounterClockwise size={14} />
                        باز کردن
                      </button>
                      <button
                        role="menuitem"
                        onClick={() => handlePdf(h.analysis_id, h.filename)}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-start hover:bg-accent transition-colors"
                      >
                        <FilePdf size={14} weight="fill" />
                        دانلود PDF
                      </button>
                      <button
                        role="menuitem"
                        onClick={() => handleDelete(h.analysis_id)}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-start hover:bg-accent transition-colors"
                        style={{ color: "var(--severity-critical)" }}
                      >
                        <Trash size={14} />
                        حذف
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
