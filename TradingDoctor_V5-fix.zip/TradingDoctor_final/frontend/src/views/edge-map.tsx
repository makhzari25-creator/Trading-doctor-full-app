/**
 * Trading Doctor — نقشه‌ی نقاط قوت View
 * Best/worst hours & weekdays, strategies, long vs short comparison.
 * Cards navigate to charts.
 */

"use client";

import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals, formatCurrency } from "@/lib/utils";
import { MapPin, CheckCircle, Warning, ArrowLeft } from "@phosphor-icons/react";
import type { EdgeMapEntry, SideComparison } from "@/lib/types";

function edgeClick(navigate: (v: "charts") => void) {
  return (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      navigate("charts");
    }
  };
}

// Real (non-mock) trading histories can legitimately lack a best/worst
// entry for a given dimension (e.g. fewer than 5 trades in every hour
// bucket — see ScoreEngine._edge_map's MIN_SAMPLE=5 rule on the
// backend). This fallback keeps the existing JSX (which was written
// against always-populated mock data, using `!` assertions) from
// crashing at runtime while staying visually honest ("—" instead of a
// fabricated number).
const EDGE_FALLBACK: Required<EdgeMapEntry> = {
  hour: 0,
  day: "—",
  avg_pnl: 0,
  total_pnl: 0,
  win_rate_pct: 0,
  name: "—",
};
const SIDE_FALLBACK: SideComparison = { count: 0, win_rate: 0, avg_pnl: 0, total_pnl: 0 };

export function EdgeMapView() {
  const navigate = useAppStore((s) => s.navigate);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی نقشه‌ی نقاط قوت، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return <ErrorState description={error || "دریافت گزارش تحلیل ناموفق بود."} onRetry={refetch} />;
  }

  const emRaw = r.appendix.edge_map_raw;
  const em = {
    best_hour: emRaw.best_hour ?? EDGE_FALLBACK,
    worst_hour: emRaw.worst_hour ?? EDGE_FALLBACK,
    best_weekday: emRaw.best_weekday ?? EDGE_FALLBACK,
    worst_weekday: emRaw.worst_weekday ?? EDGE_FALLBACK,
    best_strategy: emRaw.best_strategy ?? EDGE_FALLBACK,
    worst_strategy: emRaw.worst_strategy ?? EDGE_FALLBACK,
  };
  const side = emRaw.side_comparison ?? { long: SIDE_FALLBACK, short: SIDE_FALLBACK };

  const sideRow = (label: string, s: SideComparison) => (
    <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg bg-accent/40">
      <div>
        <div className="text-sm font-semibold">{label}</div>
        <div className="text-xs text-muted-foreground">
          {toPersianNumerals(s.count)} معامله
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-center">
          <div className="text-[10px] text-muted-foreground">وین‌ریت</div>
          <div className="td-mono font-semibold">{toPersianNumerals(s.win_rate)}٪</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-muted-foreground">میانگین</div>
          <div
            className="td-mono font-semibold"
            style={{
              color:
                s.avg_pnl >= 0 ? "var(--profit-positive)" : "var(--profit-negative)",
            }}
          >
            {formatCurrency(s.avg_pnl)}
          </div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-muted-foreground">کل</div>
          <div
            className="td-mono font-bold"
            style={{
              color:
                s.total_pnl >= 0
                  ? "var(--profit-positive)"
                  : "var(--profit-negative)",
            }}
          >
            {formatCurrency(s.total_pnl)}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">نقشه‌ی نقاط قوت</h1>
        <p className="text-sm text-muted-foreground">کِی و کجا بهترین/بدترین هستم؟</p>
      </div>

      {/* Best/Worst cards */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-1">
          <MapPin size={14} /> زمان‌های طلایی و ضعیف
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              good: true,
              label: "بهترین ساعت",
              title: `ساعت ${toPersianNumerals(em.best_hour!.hour!)}`,
              metric: formatCurrency(em.best_hour!.avg_pnl!),
              sub: "میانگین سود هر معامله",
            },
            {
              good: false,
              label: "بدترین ساعت",
              title: `ساعت ${toPersianNumerals(em.worst_hour!.hour!)}`,
              metric: formatCurrency(em.worst_hour!.avg_pnl!),
              sub: "میانگین زیان هر معامله",
            },
            {
              good: true,
              label: "بهترین روز",
              title: em.best_weekday!.day!,
              metric: formatCurrency(em.best_weekday!.total_pnl!),
              sub: "کل سود روز",
            },
            {
              good: false,
              label: "بدترین روز",
              title: em.worst_weekday!.day!,
              metric: formatCurrency(em.worst_weekday!.total_pnl!),
              sub: "کل زیان روز",
            },
          ].map((c) => {
            const color = c.good
              ? "var(--profit-positive)"
              : "var(--profit-negative)";
            const Icon = c.good ? CheckCircle : Warning;
            return (
              <Card
                key={c.label}
                className="p-4 td-card-hover td-press cursor-pointer"
                style={{ borderInlineStartWidth: "3px", borderInlineStartColor: color }}
                onClick={() => navigate("charts")}
                role="button"
                tabIndex={0}
                aria-label={`${c.label}: ${c.title}, ${c.metric}`}
                onKeyDown={edgeClick(navigate)}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Icon size={16} weight="fill" style={{ color }} />
                  <span className="text-xs text-muted-foreground">{c.label}</span>
                </div>
                <div className="text-sm font-semibold mb-1">{c.title}</div>
                <div className="td-mono text-lg font-bold" style={{ color }}>
                  {c.metric}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{c.sub}</div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Strategy cards */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-2">استراتژی‌ها</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Card
            className="p-4 td-card-hover td-press cursor-pointer"
            style={{
              borderInlineStartWidth: "3px",
              borderInlineStartColor: "var(--profit-positive)",
            }}
            onClick={() => navigate("charts")}
            role="button"
            tabIndex={0}
            aria-label={`بهترین استراتژی: ${em.best_strategy!.name}`}
            onKeyDown={edgeClick(navigate)}
          >
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle size={16} weight="fill" style={{ color: "var(--profit-positive)" }} />
              <span className="text-xs text-muted-foreground">بهترین استراتژی</span>
            </div>
            <div className="text-sm font-semibold mb-2">{em.best_strategy!.name}</div>
            <div className="flex items-center gap-4">
              <div>
                <div className="text-xs text-muted-foreground">میانگین سود</div>
                <div className="td-mono font-bold" style={{ color: "var(--profit-positive)" }}>
                  {formatCurrency(em.best_strategy!.avg_pnl!)}
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">وین‌ریت</div>
                <div className="td-mono font-semibold">
                  {toPersianNumerals(em.best_strategy!.win_rate_pct!)}٪
                </div>
              </div>
            </div>
          </Card>
          <Card
            className="p-4 td-card-hover td-press cursor-pointer"
            style={{
              borderInlineStartWidth: "3px",
              borderInlineStartColor: "var(--profit-negative)",
            }}
            onClick={() => navigate("charts")}
            role="button"
            tabIndex={0}
            aria-label={`بدترین استراتژی: ${em.worst_strategy!.name}`}
            onKeyDown={edgeClick(navigate)}
          >
            <div className="flex items-center gap-2 mb-2">
              <Warning size={16} weight="fill" style={{ color: "var(--profit-negative)" }} />
              <span className="text-xs text-muted-foreground">بدترین استراتژی</span>
            </div>
            <div className="text-sm font-semibold mb-2">{em.worst_strategy!.name}</div>
            <div className="flex items-center gap-4">
              <div>
                <div className="text-xs text-muted-foreground">میانگین زیان</div>
                <div className="td-mono font-bold" style={{ color: "var(--profit-negative)" }}>
                  {formatCurrency(em.worst_strategy!.avg_pnl!)}
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">وین‌ریت</div>
                <div className="td-mono font-semibold">
                  {toPersianNumerals(em.worst_strategy!.win_rate_pct!)}٪
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Side comparison */}
      <Card className="p-4">
        <h3 className="text-sm font-semibold mb-3">مقایسه‌ی Long و Short</h3>
        <div className="space-y-2">
          {sideRow("Long (خرید)", side.long)}
          {sideRow("Short (فروش)", side.short)}
        </div>
      </Card>

      <button
        onClick={() => navigate("charts")}
        className="w-full py-3 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors flex items-center justify-center gap-2 td-press"
        aria-label="مشاهده‌ی نمودارها"
      >
        مشاهده‌ی نمودارها
        <ArrowLeft size={14} className="td-flip-rtl" />
      </button>
    </div>
  );
}
