/**
 * Trading Doctor — تنظیمات View
 * Full implementation will be built in Phase 6 (page by page).
 * This is a functional placeholder.
 */

"use client";

import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/td/empty-states";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals } from "@/lib/utils";

export function SettingsView() {
  const navigate = useAppStore((s) => s.navigate);
  const { data: r, noAnalysisSelected } = useAnalysisReport();

  return (
    <div className="space-y-4 fade-up">
      <div>
        <h1 className="text-2xl font-bold mb-1">تنظیمات</h1>
        <p className="text-sm text-muted-foreground">شخصی‌سازی رابط کاربری</p>
      </div>
      <Card className="p-6">
        <p className="text-sm text-muted-foreground mb-3">
          این صفحه در حال پیاده‌سازی است.
        </p>
        {noAnalysisSelected || !r ? (
          <EmptyState
            title="تحلیلی انتخاب نشده"
            description="برای دیدن نمونه‌ی اطلاعات، ابتدا یک تحلیل انجام بده."
            ctaLabel="آپلود فایل معاملات"
            onCta={() => navigate("upload")}
          />
        ) : (
          <>
            <p className="text-sm text-muted-foreground mb-3">
              امتیاز کلی تحلیل فعلی: {toPersianNumerals(r.overall_score.value)}/۱۰۰
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              تشخیص اصلی: {r.diagnosis.primary}
            </p>
            <button
              onClick={() => navigate("dashboard")}
              className="px-4 py-2 rounded-lg bg-[var(--primary)] text-white text-sm font-medium hover:opacity-90 transition-opacity"
            >
              بازگشت به داشبورد
            </button>
          </>
        )}
      </Card>
    </div>
  );
}
