/**
 * Trading Doctor — Landing Page View
 *
 * The public-facing entry point. Communicates the value proposition in 5 seconds,
 * shows trust signals, explains how it works, and converts visitors into uploaders.
 *
 * Phase 4 §3 (Landing Page), Phase 3 Design System.
 *
 * @phase Phase 1 build
 * @engine-dependency None (static page, links to /upload and /dashboard)
 */

"use client";

import { Card } from "@/components/ui/card";
import { useAppStore } from "@/lib/store/app-store";
import {
  UploadSimple,
  Gear,
  ChartBar,
  ArrowLeft,
  CheckCircle,
  Gauge,
  Translate,
  Sun,
  Moon,
} from "@phosphor-icons/react";
import { useThemeStore } from "@/lib/store/theme-store";
import { useEffect } from "react";

export function LandingView() {
  const navigate = useAppStore((s) => s.navigate);
  const setAnalysisId = useAppStore((s) => s.setAnalysisId);
  const { theme, setTheme, language, setLanguage } = useThemeStore();

  // Ensure theme + lang are applied on landing (since no AppShell here)
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.classList.toggle("light", theme === "light");
    root.lang = language;
    root.dir = language === "fa" ? "rtl" : "ltr";
  }, [theme, language]);

  const handleStartAnalysis = () => {
    navigate("upload");
  };

  const handleViewSample = () => {
    // Load sample analysis and navigate to dashboard
    setAnalysisId("sample-analysis-001");
    navigate("dashboard");
  };

  const trustBadges = [
    "بدون نیاز به ثبت‌نام",
    "خروجی PDF حرفه‌ای",
    "RTL-native",
    "۲۲ تست پاس شده",
  ];

  const howItWorks = [
    {
      icon: UploadSimple,
      step: "۱",
      title: "آپلود فایل",
      desc: "هر فرمت بروکر (CSV, XLSX, HTM, JSON)",
    },
    {
      icon: Gear,
      step: "۲",
      title: "تحلیل رفتاری",
      desc: "۵ امتیاز رفتاری + شواهد + دلار",
    },
    {
      icon: ChartBar,
      step: "۳",
      title: "برنامه‌ی اقدام",
      desc: "توصیه‌های قابل‌اجرا + دانلود PDF",
    },
  ];

  const sampleStats = [
    { label: "امتیاز کلی", value: "۶۷/۱۰۰", color: "var(--severity-medium)" },
    { label: "سود خالص", value: "+$۱٬۲۴۰", color: "var(--profit-positive)" },
    { label: "وین‌ریت", value: "۵۲٪" },
    { label: "Profit Factor", value: "۱.۳" },
  ];

  const features = [
    "۵ امتیاز رفتاری (انتقام، بیش‌معامله، ریسک، صبر، انضباط)",
    "تشخیص اصلی + شواهد با دلار",
    "برنامه‌ی اقدام اولویت‌بندی‌شده",
    "نقشه‌ی نقاط قوت و ضعف",
    "خروجی PDF حرفه‌ای",
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* ===== Top Bar (minimal, transparent) ===== */}
      <header className="absolute top-0 inset-x-0 z-20 flex items-center justify-between px-4 py-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-[var(--primary)] flex items-center justify-center">
            <Gauge size={24} weight="fill" className="text-white" />
          </div>
          <span className="font-bold text-lg">Trading Doctor</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            className="p-2 rounded-lg hover:bg-accent/50 transition-colors"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="تغییر تم"
          >
            {theme === "dark" ? (
              <Sun size={18} className="text-foreground" />
            ) : (
              <Moon size={18} className="text-foreground" />
            )}
          </button>
          <button
            className="p-2 rounded-lg hover:bg-accent/50 transition-colors text-xs font-semibold text-foreground"
            onClick={() => setLanguage(language === "fa" ? "en" : "fa")}
            aria-label="تغییر زبان"
          >
            <Translate size={18} />
          </button>
        </div>
      </header>

      {/* ===== Hero Section ===== */}
      <section className="relative overflow-hidden px-4 pt-24 pb-12 md:pt-32 md:pb-20">
        {/* Ambient background blobs */}
        <div className="absolute inset-0 overflow-hidden -z-10" aria-hidden="true">
          <div
            className="absolute top-0 start-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
            style={{ backgroundColor: "var(--primary)" }}
          />
          <div
            className="absolute bottom-0 end-1/4 w-96 h-96 rounded-full blur-3xl opacity-5"
            style={{ backgroundColor: "var(--cta)" }}
          />
        </div>

        <div className="max-w-4xl mx-auto text-center">
          {/* Headline */}
          <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight fade-up">
            معامله‌گر بهتر شو،
            <br />
            <span className="text-[var(--primary)]">نه فقط سود more</span>
          </h1>

          {/* Subheadline */}
          <p
            className="text-base md:text-lg text-muted-foreground mb-8 max-w-xl mx-auto leading-relaxed fade-up"
            style={{ animationDelay: "100ms" }}
          >
            تحلیل رفتاری معاملات شما با شواهد و دلار. کشف کنید کدام رفتار شما را ضرر
            می‌دهد و چه کار باید بکنید.
          </p>

          {/* CTAs */}
          <div
            className="flex flex-col sm:flex-row gap-3 justify-center mb-8 fade-up"
            style={{ animationDelay: "200ms" }}
          >
            <button
              onClick={handleStartAnalysis}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] font-semibold hover:opacity-90 transition-opacity shadow-lg"
            >
              <UploadSimple size={18} weight="bold" />
              تحلیل معاملاتم را شروع کن
            </button>
            <button
              onClick={handleViewSample}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-lg border border-border font-medium hover:bg-accent transition-colors"
            >
              مشاهده‌ی نمونه گزارش
              <ArrowLeft size={16} className="rtl:rotate-180" />
            </button>
          </div>

          {/* Trust badges */}
          <div
            className="flex flex-wrap items-center justify-center gap-3 text-xs text-muted-foreground fade-up"
            style={{ animationDelay: "300ms" }}
          >
            {trustBadges.map((badge, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <CheckCircle
                  size={14}
                  weight="fill"
                  className="text-[var(--severity-low)]"
                />
                {badge}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== How It Works Section ===== */}
      <section className="px-4 py-12 border-t border-border">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">چطور کار می‌کند</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {howItWorks.map((item, i) => {
              const Icon = item.icon;
              return (
                <Card
                  key={i}
                  className="p-6 text-center fade-up"
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center mx-auto mb-4">
                    <Icon size={24} className="text-[var(--primary)]" />
                  </div>
                  <div className="text-xs text-muted-foreground mb-1">
                    گام {item.step}
                  </div>
                  <h3 className="font-semibold mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== Sample Preview Section ===== */}
      <section className="px-4 py-12 border-t border-border">
        <div className="max-w-4xl mx-auto">
          <Card className="p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              {/* Left: description + features */}
              <div>
                <h3 className="text-xl font-bold mb-3">
                  گزارش نمونه را ببینید
                </h3>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                  قبل از آپلود فایل خود، یک تحلیل کامل را مرور کنید. ببینید دقیقاً
                  چه اطلاعاتی دریافت می‌کنید:
                </p>
                <ul className="space-y-2 text-sm">
                  {features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle
                        size={16}
                        weight="fill"
                        className="text-[var(--severity-low)] shrink-0 mt-0.5"
                      />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  onClick={handleViewSample}
                  className="mt-6 flex items-center gap-2 px-4 py-2 rounded-lg bg-[var(--primary)] text-white text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  مشاهده‌ی گزارش نمونه
                  <ArrowLeft size={14} className="rtl:rotate-180" />
                </button>
              </div>

              {/* Right: sample stats preview */}
              <div className="bg-accent/30 rounded-xl p-4 border border-border">
                <div className="grid grid-cols-2 gap-2">
                  {sampleStats.map((stat, i) => (
                    <div
                      key={i}
                      className="bg-card rounded-lg p-3 border border-border"
                    >
                      <div className="text-xs text-muted-foreground mb-1">
                        {stat.label}
                      </div>
                      <div
                        className="td-mono font-bold text-lg"
                        style={
                          stat.color ? { color: stat.color } : undefined
                        }
                      >
                        {stat.value}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div className="bg-card rounded-lg p-3 border border-border">
                    <div className="text-xs text-muted-foreground mb-1">
                      Max Drawdown
                    </div>
                    <div
                      className="td-mono font-bold text-lg"
                      style={{ color: "var(--profit-negative)" }}
                    >
                      -$۸۹۰
                    </div>
                  </div>
                  <div className="bg-card rounded-lg p-3 border border-border">
                    <div className="text-xs text-muted-foreground mb-1">
                      تشخیص اصلی
                    </div>
                    <div className="font-bold text-xs mt-1">
                      معامله‌ی انتقامی
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* ===== Final CTA Section ===== */}
      <section className="px-4 py-12 border-t border-border">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-3">آماده‌اید شروع کنید؟</h2>
          <p className="text-sm text-muted-foreground mb-6">
            ۶۰ ثانیه تا اولین تشخیص رفتاری
          </p>
          <button
            onClick={handleStartAnalysis}
            className="inline-flex items-center gap-2 px-8 py-3 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] font-semibold hover:opacity-90 transition-opacity shadow-lg"
          >
            <UploadSimple size={18} weight="bold" />
            تحلیل معاملاتم را شروع کن
          </button>
        </div>
      </section>

      {/* ===== Footer ===== */}
      <footer className="px-4 py-8 border-t border-border">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[var(--primary)] flex items-center justify-center">
              <Gauge size={14} weight="fill" className="text-white" />
            </div>
            <span>Trading Doctor V23 — Phase 4</span>
          </div>
          <div>© ۱۴۰۴ Trading Doctor. تمام حقوق محفوظ است.</div>
        </div>
      </footer>
    </div>
  );
}
