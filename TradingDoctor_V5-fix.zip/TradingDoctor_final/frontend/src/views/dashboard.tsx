/**
 * Trading Doctor — Dashboard View (The Emotional Center)
 *
 * 4 cards above the fold on 375 × 667:
 * 1. Overall Health — ScoreGauge
 * 2. Biggest Leak — top evidence with $ impact
 * 3. Biggest Strength — first strength
 * 4. Immediate Next Action — top recommendation
 *
 * Phase 4 §7, Phase 1 hard constraint #2.
 */

"use client";

import { ScoreGauge, SeverityBadge, StatCard } from "@/components/td/score-gauge";
import { Card } from "@/components/ui/card";
import { EmptyState, ErrorState, PageSkeleton } from "@/components/td/empty-states";
import {
  Warning,
  CheckCircle,
  ArrowLeft,
  Lightbulb,
  Info,
  CaretDown,
} from "@phosphor-icons/react";
import { useState } from "react";
import { useAppStore } from "@/lib/store/app-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import {
  toPersianNumerals,
  formatCurrency,
  severityToLevel,
} from "@/lib/utils";

export function DashboardView() {
  const navigate = useAppStore((s) => s.navigate);
  const [warningsOpen, setWarningsOpen] = useState(false);
  const { data: r, isLoading, error, noAnalysisSelected, refetch } = useAnalysisReport();

  if (noAnalysisSelected) {
    return (
      <EmptyState
        title="هنوز تحلیلی انجام نشده"
        description="برای مشاهده‌ی داشبورد، ابتدا یک فایل معاملات آپلود و تحلیل کن."
        ctaLabel="آپلود فایل معاملات"
        onCta={() => navigate("upload")}
      />
    );
  }
  if (isLoading) return <PageSkeleton />;
  if (error || !r) {
    return (
      <ErrorState
        description={error || "دریافت گزارش تحلیل ناموفق بود."}
        onRetry={refetch}
      />
    );
  }

  const biggestLeak = r.evidence[0];
  const biggestStrength = r.strengths[0] || "بهترین ساعت: ۱۴:۰۰";
  const nextAction = r.recommendations[0];

  return (
    <div className="space-y-4">
      {/* Mobile page title */}
      <div className="md:hidden">
        <h1 className="text-xl font-bold">داشبورد</h1>
        <p className="text-sm text-muted-foreground">
          {toPersianNumerals(r.statistics.total_trades)} معامله · تولید‌شده در {r.meta.generated_at}
        </p>
      </div>

      {/* ===== 4 Emotional-Center Cards — ABOVE THE FOLD on 375×667 ===== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {/* Card 1: Overall Health — 140px mobile */}
        <Card
          className="relative overflow-hidden p-4 cursor-pointer td-card-hover hover:border-[var(--primary)] td-press"
          onClick={() => navigate("behavioral")}
          role="button"
          tabIndex={0}
          aria-label={`وضعیت کلی: ${r.overall_score.value} از ۱۰۰، متوسط. کلیک برای جزئیات رفتاری`}
          onKeyDown={(e) => e.key === "Enter" && navigate("behavioral")}
        >
          <div
            className="absolute top-0 inset-x-0 h-1"
            style={{ backgroundColor: "var(--severity-medium)" }}
          />
          <div className="flex flex-col items-center text-center pt-1">
            <div className="text-xs text-muted-foreground mb-2">وضعیت کلی</div>
            <ScoreGauge value={r.overall_score.value} size={80} strokeWidth={6} />
            <div className="mt-2 text-sm font-medium">انضباط: متوسط</div>
          </div>
        </Card>

        {/* Card 2: Biggest Leak — 120px mobile */}
        <Card
          className="relative overflow-hidden p-4 cursor-pointer td-card-hover td-press"
          style={{
            borderInlineStartWidth: "4px",
            borderInlineStartColor: "var(--severity-critical)",
          }}
          onClick={() => navigate("diagnosis")}
          role="button"
          tabIndex={0}
          aria-label={`بزرگ‌ترین نقطه‌ضعف: ${biggestLeak.label}، ${biggestLeak.financial_impact_fmt} ضرر`}
          onKeyDown={(e) => e.key === "Enter" && navigate("diagnosis")}
        >
          <div className="flex items-start gap-2 mb-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{
                backgroundColor:
                  "color-mix(in srgb, var(--severity-critical) 15%, transparent)",
              }}
            >
              <Warning
                size={18}
                weight="fill"
                style={{ color: "var(--severity-critical)" }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">بزرگ‌ترین نقطه‌ضعف</div>
              <div className="text-sm font-semibold truncate">{biggestLeak.label}</div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span
              className="td-mono font-bold text-lg"
              style={{ color: "var(--profit-negative)" }}
            >
              {biggestLeak.financial_impact_fmt}
            </span>
            <SeverityBadge severity={severityToLevel(biggestLeak.severity)} size="sm" />
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {toPersianNumerals(biggestLeak.frequency)} رویداد
          </div>
        </Card>

        {/* Card 3: Biggest Strength — 120px mobile */}
        <Card
          className="relative overflow-hidden p-4 cursor-pointer td-card-hover td-press"
          style={{
            borderInlineStartWidth: "4px",
            borderInlineStartColor: "var(--severity-low)",
          }}
          onClick={() => navigate("edge-map")}
          role="button"
          tabIndex={0}
          aria-label="بزرگ‌ترین نقطه‌قوت: بهترین ساعت ۱۴:۰۰"
          onKeyDown={(e) => e.key === "Enter" && navigate("edge-map")}
        >
          <div className="flex items-start gap-2 mb-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{
                backgroundColor:
                  "color-mix(in srgb, var(--severity-low) 15%, transparent)",
              }}
            >
              <CheckCircle
                size={18}
                weight="fill"
                style={{ color: "var(--severity-low)" }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">بزرگ‌ترین نقطه‌قوت</div>
              <div className="text-sm font-semibold truncate">
                {biggestStrength.split(":")[0]}
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span
              className="td-mono font-bold text-lg"
              style={{ color: "var(--profit-positive)" }}
            >
              +${toPersianNumerals(12)}/معامله
            </span>
            <span className="text-xs text-muted-foreground">ساعت ۱۴:۰۰</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">بهترین بازه‌ی معاملاتی</div>
        </Card>

        {/* Card 4: Immediate Next Action — 110px mobile */}
        <Card
          className="relative overflow-hidden p-4 cursor-pointer td-card-hover td-press"
          style={{
            borderInlineStartWidth: "4px",
            borderInlineStartColor: "var(--cta)",
          }}
          onClick={() => navigate("coaching")}
          role="button"
          tabIndex={0}
          aria-label="گام بعدی: اقدام فوری"
          onKeyDown={(e) => e.key === "Enter" && navigate("coaching")}
        >
          <div className="flex items-start gap-2 mb-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{ backgroundColor: "color-mix(in srgb, var(--cta) 15%, transparent)" }}
            >
              <Lightbulb size={18} weight="fill" style={{ color: "var(--cta)" }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground">گام بعدی</div>
              <div className="text-sm font-semibold">اقدام فوری</div>
            </div>
          </div>
          <p className="text-xs leading-relaxed mb-2 line-clamp-2">{nextAction.action}</p>
          <div className="flex items-center gap-1 text-xs text-[var(--cta)] font-medium">
            مشاهده برنامه‌ی کامل
            <ArrowLeft size={12} className="td-flip-rtl" />
          </div>
        </Card>
      </div>

      {/* ===== Performance Strip ===== */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-2">
          عملکرد کلی معاملات
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          <StatCard
            label="سود خالص"
            value={formatCurrency(r.performance.net_profit)}
            trend="up"
            onClick={() => navigate("charts")}
          />
          <StatCard
            label="وین‌ریت"
            value={`${toPersianNumerals(r.statistics.win_rate_pct.toFixed(1))}٪`}
            onClick={() => navigate("charts")}
          />
          <StatCard
            label="Profit Factor"
            value={toPersianNumerals(r.performance.profit_factor.toFixed(1))}
            onClick={() => navigate("charts")}
          />
          <StatCard
            label="Max Drawdown"
            value={formatCurrency(r.risk.max_drawdown)}
            trend="down"
            onClick={() => navigate("charts")}
          />
          <StatCard
            label="تعداد معاملات"
            value={toPersianNumerals(r.statistics.total_trades)}
            onClick={() => navigate("trade-explorer")}
          />
          <StatCard
            label="میانگین سود"
            value={formatCurrency(r.performance.avg_win)}
            trend="up"
            onClick={() => navigate("charts")}
          />
        </div>
      </div>

      {/* ===== Biggest Leak + What-If Callouts ===== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <Card className="p-4">
          <div className="flex items-start gap-2 mb-2">
            <Warning
              size={18}
              weight="fill"
              style={{ color: "var(--severity-critical)" }}
            />
            <h3 className="text-sm font-semibold flex-1">بزرگ‌ترین نشتی</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
            {biggestLeak.description}
          </p>
          <button
            onClick={() => navigate("diagnosis")}
            className="text-xs text-[var(--primary)] hover:underline flex items-center gap-1"
          >
            شواهد کامل را ببین
            <ArrowLeft size={12} className="td-flip-rtl" />
          </button>
        </Card>

        <Card
          className="p-4"
          style={{
            borderInlineStartWidth: "3px",
            borderInlineStartColor: "var(--severity-low)",
          }}
        >
          <div className="flex items-start gap-2 mb-2">
            <Info size={18} style={{ color: "var(--severity-low)" }} />
            <h3 className="text-sm font-semibold flex-1">
              اگر این رفتار را اصلاح می‌کردید...
            </h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
            سود خالص شما از{" "}
            <span className="td-mono text-foreground">
              {formatCurrency(r.performance.net_profit)}
            </span>{" "}
            به{" "}
            <span
              className="td-mono font-bold"
              style={{ color: "var(--profit-positive)" }}
            >
              +${toPersianNumerals(3080)}
            </span>{" "}
            افزایش می‌یافت —{" "}
            <span className="td-mono font-bold">{toPersianNumerals(149)}٪</span> بیشتر.
          </p>
          <button
            onClick={() => navigate("behavioral")}
            className="text-xs text-[var(--primary)] hover:underline flex items-center gap-1"
          >
            جزئیات بیشتر
            <ArrowLeft size={12} className="td-flip-rtl" />
          </button>
        </Card>
      </div>

      {/* ===== Quick Jump Tiles ===== */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-2">ورود سریع</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
          {[
            { view: "behavioral" as const, label: "تحلیل رفتاری", preview: "۳ رفتار نیاز به توجه" },
            { view: "diagnosis" as const, label: "تشخیص", preview: "مشکل اصلی + شواهد" },
            { view: "coaching" as const, label: "برنامه‌ی اقدام", preview: "۳ گام برای این هفته" },
            { view: "edge-map" as const, label: "نقشه‌ی نقاط قوت", preview: "بهترین ساعت: ۱۴:۰۰" },
          ].map((tile, i) => (
            <Card
              key={tile.view}
              className={`p-3 cursor-pointer td-card-hover hover:border-[var(--primary)] hover:bg-accent/50 fade-up stagger-${i + 1}`}
              onClick={() => navigate(tile.view)}
              role="button"
              tabIndex={0}
              aria-label={tile.label}
              onKeyDown={(e) => e.key === "Enter" && navigate(tile.view)}
            >
              <div className="text-sm font-semibold mb-1 group-hover:text-[var(--primary)]">
                {tile.label}
              </div>
              <div className="text-xs text-muted-foreground">{tile.preview}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* ===== Data Quality Warnings (collapsible) ===== */}
      {r.appendix.data_quality_warnings.length > 0 && (
        <Card className="overflow-hidden">
          <button
            onClick={() => setWarningsOpen(!warningsOpen)}
            className="w-full flex items-center justify-between p-3 hover:bg-accent/50 transition-colors"
            aria-expanded={warningsOpen}
          >
            <div className="flex items-center gap-2">
              <Warning
                size={16}
                weight="fill"
                style={{ color: "var(--severity-medium)" }}
              />
              <span className="text-sm font-medium">
                {toPersianNumerals(r.appendix.data_quality_warnings.length)} هشدار کیفیت داده
              </span>
            </div>
            <CaretDown
              size={16}
              className={`text-muted-foreground transition-transform ${warningsOpen ? "rotate-180" : ""}`}
            />
          </button>
          {warningsOpen && (
            <div className="px-3 pb-3 space-y-1.5 border-t border-border pt-2">
              {r.appendix.data_quality_warnings.map((w, i) => (
                <div
                  key={i}
                  className="flex items-start gap-2 text-xs text-muted-foreground"
                >
                  <span style={{ color: "var(--severity-medium)" }} className="mt-0.5">
                    •
                  </span>
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
