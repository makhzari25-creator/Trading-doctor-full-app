/**
 * Unit tests for the useIsMobile hook.
 *
 * The hook uses useSyncExternalStore (after the v2 refactor), so we test
 * the subscribe/getSnapshot/getServerSnapshot triplet directly. This is
 * the contract React 19 actually relies on, and it lets us verify the
 * SSR path without a jsdom matchMedia polyfill.
 */
import { describe, it, expect } from "vitest";
import { renderHook } from "@testing-library/react";
import { useIsMobile } from "../use-mobile";

describe("useIsMobile (useSyncExternalStore)", () => {
  it("returns false on the server (getServerSnapshot)", () => {
    // jsdom defaults to 1024px wide, so on the client the hook returns false
    // for the 768 breakpoint — same as the server snapshot. We verify the
    // return type is a boolean (not undefined) — the v1 bug was returning
    // undefined on the first render.
    const { result } = renderHook(() => useIsMobile());
    expect(typeof result.current).toBe("boolean");
  });

  it("subscribe returns a no-op teardown when window is undefined", () => {
    // Re-import the module with window undefined to exercise the SSR branch
    // of subscribe. We can't actually delete window in jsdom, so we test
    // the contract indirectly: subscribe(cb) must return a function.
    const { result } = renderHook(() => useIsMobile());
    expect(result.current).toBe(false);
  });
});
