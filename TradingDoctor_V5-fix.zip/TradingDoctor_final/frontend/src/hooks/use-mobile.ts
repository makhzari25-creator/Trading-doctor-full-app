import * as React from "react"

const MOBILE_BREAKPOINT = 768

/**
 * subscribe() + getSnapshot() + getServerSnapshot() — the canonical
 * useSyncExternalStore pattern. No setState-in-effect, no hydration mismatch,
 * and the snapshot is read from a single source of truth (the matchMedia query).
 */
function subscribe(callback: () => void): () => void {
  if (typeof window === "undefined") return () => {}
  const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
  mql.addEventListener("change", callback)
  return () => mql.removeEventListener("change", callback)
}

function getSnapshot(): boolean {
  if (typeof window === "undefined") return false
  return window.innerWidth < MOBILE_BREAKPOINT
}

function getServerSnapshot(): boolean {
  // Mobile-first design assumption: server render treats unknown viewport as desktop.
  return false
}

export function useIsMobile(): boolean {
  return React.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
}
