/**
 * Trading Doctor — Root Layout
 *
 * - Vazirmatn (Persian + Latin) + Fira Code (mono) via next/font
 * - dir="rtl", lang="fa" (Persian-first)
 * - dark class on <html> (dark theme default)
 * - Toaster + Sonner for notifications
 *
 * Phase 5 §3, §10, §11.
 */

import type { Metadata } from "next";
import { Vazirmatn, Fira_Code } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { Providers } from "@/components/providers/providers";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
  weight: ["300", "400", "500", "600", "700"],
});

const firaCode = Fira_Code({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Trading Doctor — تحلیل رفتار معاملاتی",
  description:
    "پلتفرم هوشمند تحلیل رفتار معاملاتی. شواهد، تشخیص، و برنامه‌ی اقدام برای معامله‌گران.",
  keywords: ["Trading Doctor", "تحلیل معاملات", "رفتار معاملاتی", "ترید"],
  authors: [{ name: "Trading Doctor" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning className="dark">
      <body
        className={`${vazirmatn.variable} ${firaCode.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
          <SonnerToaster position="top-left" richColors closeButton />
        </Providers>
      </body>
    </html>
  );
}
