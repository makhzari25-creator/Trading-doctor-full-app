/**
 * Trading Doctor — Main Page (SPA Router with Auth)
 */

"use client";

import { useEffect } from "react";
import { useAppStore } from "@/lib/store/app-store";
import { useAuthStore } from "@/lib/store/auth-store";
import { AppShell } from "@/components/td/app-shell";
import { LandingView } from "@/views/landing";
import { UploadView } from "@/views/upload";
import { DashboardView } from "@/views/dashboard";
import { BehavioralView } from "@/views/behavioral";
import { DiagnosisView } from "@/views/diagnosis";
import { CoachingView } from "@/views/coaching";
import { TraderDnaView } from "@/views/trader-dna";
import { EdgeMapView } from "@/views/edge-map";
import { ChartsView } from "@/views/charts";
import { TradeExplorerView } from "@/views/trade-explorer";
import { TrendsView } from "@/views/trends";
import { ReportView } from "@/views/report";
import { HistoryView } from "@/views/history";
import { SettingsView } from "@/views/settings";
import { PageSkeleton } from "@/components/td/empty-states";
import { LoginView, RegisterView, ForgotPasswordView, ResetPasswordView, VerifyEmailView, ProfileView, SecurityView } from "@/views/auth";

const AUTH_VIEWS = new Set(["login", "register", "forgot-password", "reset-password", "verify-email"]);
const PROTECTED_VIEWS = new Set(["dashboard", "behavioral", "diagnosis", "coaching", "trader-dna", "edge-map", "charts", "trade-explorer", "report", "profile", "security"]);

export default function Home() {
  const currentView = useAppStore((s) => s.currentView);
  const hasAnalysis = useAppStore((s) => s.hasAnalysis);
  const navigate = useAppStore((s) => s.navigate);
  const setAnalysisId = useAppStore((s) => s.setAnalysisId);
  const { isAuthenticated, isLoading: authLoading, user, setUser, setLoading } = useAuthStore();

  // Check session on app load
  useEffect(() => {
    const checkSession = async () => {
      try {
        // [v4] /api/v1/auth/session proxies to FastAPI GET /me with the
        // httpOnly access cookie. Returns { user: {...} } or { user: null }.
        const response = await fetch("/api/v1/auth/session");
        const data = await response.json();
        if (data.user) setUser(data.user);
        else setLoading(false);
      } catch { setLoading(false); }
    };
    checkSession();
  }, [setUser, setLoading]);

  // Auth views — no AppShell
  if (AUTH_VIEWS.has(currentView)) {
    if (currentView === "login") return <LoginView />;
    if (currentView === "register") return <RegisterView />;
    if (currentView === "forgot-password") return <ForgotPasswordView />;
    if (currentView === "reset-password") return <ResetPasswordView />;
    if (currentView === "verify-email") return <VerifyEmailView />;
  }

  // Landing — no AppShell, no auth required
  if (currentView === "landing") return <LandingView />;

  // Protected views — redirect to login if not authenticated
  if (PROTECTED_VIEWS.has(currentView) && !isAuthenticated && !authLoading) {
    navigate("login");
    return <PageSkeleton />;
  }

  const analysisRequired = ["dashboard", "behavioral", "diagnosis", "coaching", "trader-dna", "edge-map", "charts", "trade-explorer", "report"];
  const showUploadFallback = analysisRequired.includes(currentView) && !hasAnalysis;

  return (
    <AppShell>
      {currentView === "upload" && (
        <UploadView onViewChange={navigate} onAnalysisComplete={(id) => { setAnalysisId(id); navigate("dashboard"); }} />
      )}
      {currentView === "dashboard" && !showUploadFallback && <DashboardView />}
      {currentView === "behavioral" && !showUploadFallback && <BehavioralView />}
      {currentView === "diagnosis" && !showUploadFallback && <DiagnosisView />}
      {currentView === "coaching" && !showUploadFallback && <CoachingView />}
      {currentView === "trader-dna" && !showUploadFallback && <TraderDnaView />}
      {currentView === "edge-map" && !showUploadFallback && <EdgeMapView />}
      {currentView === "charts" && !showUploadFallback && <ChartsView />}
      {currentView === "trade-explorer" && !showUploadFallback && <TradeExplorerView />}
      {currentView === "trends" && <TrendsView />}
      {currentView === "report" && !showUploadFallback && <ReportView />}
      {currentView === "history" && <HistoryView />}
      {currentView === "settings" && <SettingsView />}
      {currentView === "profile" && isAuthenticated && <ProfileView />}
      {currentView === "security" && isAuthenticated && <SecurityView />}
      {showUploadFallback && (
        <UploadView onViewChange={navigate} onAnalysisComplete={(id) => { setAnalysisId(id); navigate("dashboard"); }} />
      )}
    </AppShell>
  );
}
