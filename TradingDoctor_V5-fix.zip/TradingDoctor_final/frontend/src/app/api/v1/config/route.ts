/**
 * GET /api/v1/config — proxies to the V23 backend's public config
 * endpoint and adapts its field names to the `AppConfig` shape already
 * defined in lib/types.ts (the backend's ConfigResponse uses slightly
 * different field names: max_upload_size_mb vs max_upload_size_bytes,
 * supported_file_types vs allowed_file_types, etc.). The adapter lives
 * here only — lib/types.ts is left untouched.
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";

interface BackendConfigResponse {
  max_upload_size_mb: number;
  supported_file_types: string[];
  available_llm_providers: string[];
  auth_enabled: boolean;
  rate_limit_enabled: boolean;
  rate_limit_requests_per_minute: number;
  api_version: string;
}

export async function GET() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), BACKEND_REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(`${BACKEND_API_URL}/config`, {
      signal: controller.signal,
      cache: "no-store",
    });
    if (!res.ok) {
      return NextResponse.json(
        { error: { code: "backend_error", message: `HTTP ${res.status}` } },
        { status: res.status }
      );
    }
    const backend = (await res.json()) as BackendConfigResponse;
    return NextResponse.json({
      max_upload_size_bytes: backend.max_upload_size_mb * 1024 * 1024,
      allowed_file_types: backend.supported_file_types,
      llm_providers: backend.available_llm_providers,
      auth_enabled: backend.auth_enabled,
      rate_limit_enabled: backend.rate_limit_enabled,
      rate_limit_rpm: backend.rate_limit_requests_per_minute,
    });
  } catch {
    return NextResponse.json(
      { error: { code: "backend_unreachable", message: "اتصال به سرور تحلیل برقرار نشد." } },
      { status: 502 }
    );
  } finally {
    clearTimeout(timer);
  }
}
