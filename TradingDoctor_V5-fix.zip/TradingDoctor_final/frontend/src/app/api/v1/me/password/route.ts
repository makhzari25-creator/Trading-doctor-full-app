/**
 * POST /api/v1/me/password — change the current user's password.
 *
 * Proxies to the V23 backend's POST /me/password. The backend validates
 * the current password, updates to the new one, and invalidates all
 * existing tokens (forcing the user to log in again on all devices).
 *
 * The request body must be JSON: { current_password, new_password }.
 */
import { proxyJson } from "@/lib/server/backend-proxy";
import { clearAuthCookies } from "@/lib/server/auth-cookies";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const body = await request.text();
  const response = await proxyJson("/me/password", { method: "POST", body });
  // On success (204), the backend invalidated all tokens — clear cookies
  // so the client is forced to log in again.
  if (response.status === 204) {
    await clearAuthCookies();
    return new NextResponse(null, { status: 204 });
  }
  return response;
}
