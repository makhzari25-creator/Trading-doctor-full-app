/**
 * GET    /api/v1/me           — get current user's profile
 * PATCH  /api/v1/me           — update profile (full_name, locale)
 * DELETE /api/v1/me           — soft-delete account (recoverable for 30 days)
 *
 * All three proxy to the V23 backend's /me endpoint with the access token
 * from the httpOnly cookie. The backend is the single source of truth for
 * user data — the frontend no longer has its own User table.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET() {
  return proxyJson("/me", { method: "GET" });
}

export async function PATCH(request: Request) {
  const body = await request.text();
  return proxyJson("/me", { method: "PATCH", body });
}

export async function DELETE() {
  return proxyJson("/me", { method: "DELETE" });
}
