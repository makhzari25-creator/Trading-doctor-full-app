/**
 * GET /api/v1/me/activity — recent security events for the current user
 * (last 20 logins, password changes, etc.).
 *
 * Proxies to the V23 backend's GET /me/activity with the access token.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET() {
  return proxyJson("/me/activity", { method: "GET" });
}
