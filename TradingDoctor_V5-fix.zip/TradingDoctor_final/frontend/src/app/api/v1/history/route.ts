/**
 * GET /api/v1/history — proxies to the V23 backend's paginated
 * analysis-history endpoint (used by the trends + history views).
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  return proxyJson("/history", { method: "GET", searchParams });
}
