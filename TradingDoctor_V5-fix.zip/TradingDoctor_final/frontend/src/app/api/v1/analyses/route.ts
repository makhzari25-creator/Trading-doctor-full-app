/**
 * POST /api/v1/analyses — proxies to the V23 backend's analysis
 * endpoint (runs the full Behavior → Score → Coaching pipeline on a
 * previously uploaded file, or dispatches a Celery job if the backend
 * has TRADING_DOCTOR_USE_CELERY=true).
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function POST(request: Request) {
  const body = await request.text();
  return proxyJson("/analyses", { method: "POST", body });
}
