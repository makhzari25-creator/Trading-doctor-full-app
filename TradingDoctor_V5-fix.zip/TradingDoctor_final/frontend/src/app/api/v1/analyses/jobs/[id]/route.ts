/**
 * GET /api/v1/analyses/jobs/{id} — proxies to the V23 backend's async
 * job status endpoint (only relevant when the backend runs with
 * TRADING_DOCTOR_USE_CELERY=true; POST /analyses returns 202 + job_id
 * in that mode instead of the analysis directly).
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyJson(`/analyses/jobs/${id}`, { method: "GET" });
}
