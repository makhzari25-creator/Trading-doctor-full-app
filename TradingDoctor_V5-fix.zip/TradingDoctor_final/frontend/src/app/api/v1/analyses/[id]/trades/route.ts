/**
 * GET /api/v1/analyses/{id}/trades — proxies to the V23 backend's raw
 * trades-list endpoint. Returns paginated trade rows with optional
 * side (Long/Short) and outcome (win/loss) filters.
 *
 * [v2] NEW route — previously this endpoint didn't exist on the backend
 * and the frontend's Trade Explorer view used mockTrades. Now the backend
 * returns real per-trade data extracted from doctor.df (the same
 * DataFrame the V23 engine analyzed), and the frontend renders it with
 * @tanstack/react-table.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const url = new URL(request.url);
  const search = url.searchParams.toString();
  const path = search
    ? `/analyses/${id}/trades?${search}`
    : `/analyses/${id}/trades`;
  return proxyJson(path, { method: "GET" });
}
