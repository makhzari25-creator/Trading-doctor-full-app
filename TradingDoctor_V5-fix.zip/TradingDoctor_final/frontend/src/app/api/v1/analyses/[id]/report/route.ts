/**
 * GET /api/v1/analyses/{id}/report — proxies to the V23 backend's
 * structured JSON report endpoint. This is the endpoint that feeds
 * `AnalysisReport` (lib/types.ts), which every analysis-result view
 * (dashboard, behavioral, diagnosis, coaching, trader-dna, edge-map,
 * charts, report) consumes via the `useAnalysisReport()` hook.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyJson(`/analyses/${id}/report`, { method: "GET" });
}
