/**
 * GET /api/v1/analyses/{id}/report.html — proxies the rendered HTML
 * report from the V23 backend (used by lib/api/index.ts::downloadReportHtml).
 */
import { proxyText } from "@/lib/server/backend-proxy";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyText(`/analyses/${id}/report.html`);
}
