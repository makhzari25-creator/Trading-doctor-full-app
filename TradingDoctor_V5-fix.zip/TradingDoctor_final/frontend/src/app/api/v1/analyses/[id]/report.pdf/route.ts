/**
 * GET /api/v1/analyses/{id}/report.pdf — proxies the rendered PDF
 * report from the V23 backend (used by lib/api/index.ts::downloadReportPdf).
 */
import { proxyBinary } from "@/lib/server/backend-proxy";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyBinary(`/analyses/${id}/report.pdf`);
}
