/**
 * GET /api/v1/analyses/{id} — proxies to the V23 backend's analysis
 * summary endpoint.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyJson(`/analyses/${id}`, { method: "GET" });
}
