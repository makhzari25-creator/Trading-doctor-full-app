/**
 * GET /api/v1/health — proxies to the V23 FastAPI backend's public
 * liveness endpoint. No auth required (matches backend behavior).
 */
import { proxyPublicJson } from "@/lib/server/backend-proxy";

export async function GET() {
  return proxyPublicJson("/health");
}
