/**
 * POST /api/v1/auth/register — proxies to the V23 backend's /auth/register.
 *
 * Forwards the email/password/full_name to the backend. The backend creates
 * the user (and optionally sends a verification email). We do NOT auto-login
 * the user here — they must explicitly log in after verifying their email
 * (if verification is required) or directly (if not).
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";

export async function POST(request: Request) {
  let body: { email?: string; password?: string; full_name?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: { code: "invalid_request", message: "بدنه‌ی درخواست معتبر نیست." } },
      { status: 400 },
    );
  }

  if (!body.email || !body.password) {
    return NextResponse.json(
      { error: { code: "validation_error", message: "ایمیل و رمز عبور الزامی است." } },
      { status: 422 },
    );
  }

  try {
    const res = await fetch(`${BACKEND_API_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: body.email,
        password: body.password,
        full_name: body.full_name,
      }),
      cache: "no-store",
      signal: AbortSignal.timeout(BACKEND_REQUEST_TIMEOUT_MS),
    });
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      { error: { code: "backend_unreachable", message: "اتصال به سرور تحلیل برقرار نشد." } },
      { status: 502 },
    );
  }
}
