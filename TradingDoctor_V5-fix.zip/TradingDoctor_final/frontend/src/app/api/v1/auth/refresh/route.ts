/**
 * POST /api/v1/auth/refresh — refreshes the access token using the
 * refresh-token cookie.
 *
 * Called by apiClient (lib/api/client.ts) when a request returns 401, or
 * proactively before the access token expires. Rotates both cookies on
 * success (refresh-token rotation is enforced by the backend).
 */
import { NextResponse } from "next/server";
import { refreshBackendTokens } from "@/lib/server/backend-auth-bridge";
import { setAuthCookies, clearAuthCookies } from "@/lib/server/auth-cookies";

export async function POST() {
  const tokens = await refreshBackendTokens();
  if (!tokens) {
    await clearAuthCookies();
    return NextResponse.json(
      { error: { code: "refresh_failed", message: "نشست شما منقضی شده. لطفاً دوباره وارد شوید." } },
      { status: 401 },
    );
  }
  await setAuthCookies(tokens);
  return NextResponse.json({ ok: true });
}
