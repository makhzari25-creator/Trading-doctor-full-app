/**
 * POST /api/v1/auth/login — proxies to the V23 backend's /auth/login.
 *
 * [v4] This is the primary login endpoint. The frontend no longer has its
 * own user database; FastAPI is the single source of truth. On success,
 * the backend returns { user, tokens: { access_token, refresh_token, ... } }
 * — we store the tokens in httpOnly cookies (td-access, td-refresh) and
 * return the user profile to the client for in-memory caching.
 *
 * The client (views/auth/index.tsx) calls this endpoint, receives the
 * user profile, and stores it in useAuthStore (NOT the tokens — those
 * stay in cookies only).
 */
import { NextResponse } from "next/server";
import { loginBackend, BackendBridgeError } from "@/lib/server/backend-auth-bridge";
import { setAuthCookies } from "@/lib/server/auth-cookies";

export async function POST(request: Request) {
  let body: { email?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: { code: "invalid_request", message: "بدنه‌ی درخواست معتبر نیست." } },
      { status: 400 },
    );
  }

  if (!body.email || !body.password) {
    return NextResponse.json(
      { error: { code: "validation_error", message: "ایمیل و رمز عبور الزامی است." } },
      { status: 422 },
    );
  }

  try {
    const { tokens, user } = await loginBackend(body.email, body.password);
    await setAuthCookies(tokens);
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.full_name,
        role: user.status ?? "user",
        image: null,
        emailVerified: !!user.email_verified_at,
      },
    });
  } catch (err) {
    const message =
      err instanceof BackendBridgeError
        ? err.message
        : "اتصال به سرور تحلیل برقرار نشد.";
    return NextResponse.json(
      { error: { code: "login_failed", message } },
      { status: 401 },
    );
  }
}
