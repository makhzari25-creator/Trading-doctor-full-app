/**
 * POST /api/v1/auth/password-reset/request — proxies to the V23 backend's
 * /auth/password-reset/request. Forwards the email; the backend sends a
 * password-reset email if the user exists.
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";

export async function POST(request: Request) {
  let body: { email?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: { code: "invalid_request", message: "بدنه‌ی درخواست معتبر نیست." } },
      { status: 400 },
    );
  }

  try {
    const res = await fetch(`${BACKEND_API_URL}/auth/password-reset/request`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: body.email }),
      cache: "no-store",
      signal: AbortSignal.timeout(BACKEND_REQUEST_TIMEOUT_MS),
    });
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      { error: { code: "backend_unreachable", message: "اتصال به سرور تحلیل برقرار نشد." } },
      { status: 502 },
    );
  }
}
