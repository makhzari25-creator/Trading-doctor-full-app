/**
 * GET /api/v1/auth/session — returns the current user's profile.
 *
 * Called by `app/page.tsx` on mount to populate useAuthStore. Reads the
 * access-token cookie and calls FastAPI `GET /me`. If the token is missing
 * or invalid, returns `{ user: null }` (NOT a 401 — the page renders the
 * landing/login view based on this null).
 */
import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/server/session";

export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ user: null });
  }
  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role ?? "user",
      image: user.image ?? null,
      emailVerified: !!user.email_verified,
    },
  });
}
