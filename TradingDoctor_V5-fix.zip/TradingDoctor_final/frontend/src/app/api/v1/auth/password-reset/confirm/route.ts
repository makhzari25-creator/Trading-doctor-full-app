/**
 * POST /api/v1/auth/password-reset/confirm — proxies to the V23 backend's
 * /auth/password-reset/confirm. Forwards the reset token + new password;
 * the backend validates the token and updates the password.
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";

export async function POST(request: Request) {
  let body: { token?: string; new_password?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: { code: "invalid_request", message: "بدنه‌ی درخواست معتبر نیست." } },
      { status: 400 },
    );
  }

  try {
    const res = await fetch(`${BACKEND_API_URL}/auth/password-reset/confirm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: body.token, new_password: body.new_password }),
      cache: "no-store",
      signal: AbortSignal.timeout(BACKEND_REQUEST_TIMEOUT_MS),
    });
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      { error: { code: "backend_unreachable", message: "اتصال به سرور تحلیل برقرار نشد." } },
      { status: 502 },
    );
  }
}
