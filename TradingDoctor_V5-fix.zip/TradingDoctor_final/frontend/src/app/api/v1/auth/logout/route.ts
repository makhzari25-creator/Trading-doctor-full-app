/**
 * POST /api/v1/auth/logout — proxies to the V23 backend's /auth/logout.
 *
 * Calls the backend with the refresh token to invalidate it (so it can't
 * be reused even if stolen), then clears both auth cookies on the response.
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";
import { getAccessToken, getRefreshToken } from "@/lib/server/session";
import { clearAuthCookies } from "@/lib/server/auth-cookies";

export async function POST() {
  const accessToken = await getAccessToken();
  const refreshToken = await getRefreshToken();

  // Best-effort: tell the backend to invalidate the refresh token. If this
  // call fails (e.g. token already expired, backend unreachable), we still
  // clear the cookies client-side — the user is effectively logged out
  // either way.
  if (accessToken && refreshToken) {
    try {
      await fetch(`${BACKEND_API_URL}/auth/logout`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ refresh_token: refreshToken }),
        cache: "no-store",
        signal: AbortSignal.timeout(BACKEND_REQUEST_TIMEOUT_MS),
      });
    } catch {
      // Ignore — we'll clear cookies anyway.
    }
  }

  await clearAuthCookies();
  return NextResponse.json({ ok: true });
}
