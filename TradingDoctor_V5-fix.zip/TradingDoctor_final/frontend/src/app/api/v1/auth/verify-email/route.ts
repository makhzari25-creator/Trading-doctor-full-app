/**
 * POST /api/v1/auth/verify-email — proxies to the V23 backend's
 * /auth/verify-email. Forwards the verification token; the backend marks
 * the user's email as verified.
 */
import { NextResponse } from "next/server";
import { BACKEND_API_URL, BACKEND_REQUEST_TIMEOUT_MS } from "@/lib/server/backend-config";

export async function POST(request: Request) {
  let body: { token?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: { code: "invalid_request", message: "بدنه‌ی درخواست معتبر نیست." } },
      { status: 400 },
    );
  }

  try {
    const res = await fetch(`${BACKEND_API_URL}/auth/verify-email`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: body.token }),
      cache: "no-store",
      signal: AbortSignal.timeout(BACKEND_REQUEST_TIMEOUT_MS),
    });
    const data = await res.json().catch(() => null);
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      { error: { code: "backend_unreachable", message: "اتصال به سرور تحلیل برقرار نشد." } },
      { status: 502 },
    );
  }
}
