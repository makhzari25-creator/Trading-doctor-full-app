/**
 * DELETE /api/v1/workspace/analyses/{id} — proxies to the V23 backend's
 * workspace router (soft-delete an analysis). Used by the history view's
 * delete action.
 */
import { proxyJson } from "@/lib/server/backend-proxy";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  return proxyJson(`/workspace/analyses/${id}`, { method: "DELETE" });
}
