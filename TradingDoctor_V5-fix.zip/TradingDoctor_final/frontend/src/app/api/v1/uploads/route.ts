/**
 * POST /api/v1/uploads — proxies the multipart file upload to the V23
 * backend (POST /api/v1/uploads), attaching the bridged backend JWT.
 */
import { proxyUpload } from "@/lib/server/backend-proxy";

export async function POST(request: Request) {
  return proxyUpload(request, "/uploads");
}
