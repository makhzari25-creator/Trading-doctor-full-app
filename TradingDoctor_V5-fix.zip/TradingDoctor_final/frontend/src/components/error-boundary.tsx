"use client";
import React from "react";
import { AlertTriangle } from "lucide-react";

interface State { hasError: boolean; message: string }

/**
 * Global error boundary. Per this project's established rule since
 * Phase 1 ("never show a raw traceback to an end user"), this shows a
 * clear, non-technical message and logs the real error to the console
 * for debugging — never the bare stack trace in the rendered UI.
 */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error("Trading Doctor UI error boundary caught:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-[200px] flex-col items-center justify-center gap-3 rounded-[var(--td-radius-md)] border border-negative-solid bg-[var(--td-negative-soft-bg)] p-8 text-center">
          <AlertTriangle className="text-negative" size={32} />
          <div className="font-semibold text-text">مشکلی در نمایش این بخش پیش آمد</div>
          <div className="text-sm text-text-muted">لطفاً صفحه را رفرش کنید یا دوباره تلاش کنید.</div>
        </div>
      );
    }
    return this.props.children;
  }
}
