/**
 * Trading Doctor — FilePill Component
 *
 * Shows a selected file with name, size, and remove button.
 * Used in the Upload flow after a file is selected.
 *
 * Phase 3 §39.2 (FilePill composite), §27 (Badges variant).
 */

"use client";

import { Card } from "@/components/ui/card";
import { FileText, X } from "@phosphor-icons/react";
import { formatFileSize } from "@/lib/utils";

interface FilePillProps {
  filename: string;
  sizeBytes: number;
  onRemove: () => void;
  /** Show upload progress (0-100). If undefined, no progress bar. */
  progress?: number;
  /** Additional className */
  className?: string;
}

export function FilePill({
  filename,
  sizeBytes,
  onRemove,
  progress,
  className,
}: FilePillProps) {
  return (
    <Card className={`p-3 flex items-center gap-3 ${className ?? ""}`}>
      {/* File icon */}
      <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[var(--primary)]/10 shrink-0">
        <FileText size={20} className="text-[var(--primary)]" />
      </div>

      {/* File info */}
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium truncate">{filename}</div>
        <div className="text-xs text-muted-foreground td-mono">
          {formatFileSize(sizeBytes)}
        </div>

        {/* Progress bar (during upload) */}
        {progress !== undefined && (
          <div className="mt-1.5 h-1 rounded-full bg-accent overflow-hidden">
            <div
              className="h-full rounded-full bg-[var(--primary)] transition-all duration-200"
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuetext={`${progress}٪ آپلود شده`}
            />
          </div>
        )}
      </div>

      {/* Remove button */}
      <button
        onClick={onRemove}
        className="p-1.5 rounded hover:bg-accent transition-colors shrink-0"
        aria-label="حذف فایل"
      >
        <X size={16} />
      </button>
    </Card>
  );
}
