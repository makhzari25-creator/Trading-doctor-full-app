/**
 * Trading Doctor — Empty States, Error States, Skeletons
 *
 * Universal patterns for loading, empty, and error conditions.
 * Every state is actionable — never just "no data" or "error".
 *
 * Phase 3 §34 (Skeletons), §35 (Empty States), §36 (Error States).
 */

"use client";

import { cn } from "@/lib/utils";
import { MagnifyingGlass, XCircle, ArrowClockwise, type Icon } from "@phosphor-icons/react";
import type { ReactNode } from "react";

/* ============================================================================
   Empty State
   ============================================================================ */

interface EmptyStateProps {
  icon?: Icon;
  title: string;
  description?: string;
  ctaLabel?: string;
  onCta?: () => void;
  children?: ReactNode;
  className?: string;
}

export function EmptyState({
  icon: Icon = MagnifyingGlass,
  title,
  description,
  ctaLabel,
  onCta,
  children,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center text-center py-12 px-4 fade-up",
        className
      )}
    >
      <div
        className="w-24 h-24 mb-4 rounded-2xl flex items-center justify-center"
        style={{
          backgroundColor:
            "color-mix(in srgb, var(--primary) 10%, transparent)",
        }}
      >
        <Icon size={40} weight="duotone" className="text-[var(--primary)]" />
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      {description && (
        <p className="text-sm text-muted-foreground max-w-sm mb-4 leading-relaxed">
          {description}
        </p>
      )}
      {children}
      {ctaLabel && onCta && (
        <button
          onClick={onCta}
          className="mt-2 px-4 py-2 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] text-sm font-medium hover:opacity-90 transition-opacity"
        >
          {ctaLabel}
        </button>
      )}
    </div>
  );
}

/* ============================================================================
   Error State
   ============================================================================ */

interface ErrorStateProps {
  title?: string;
  description?: string;
  onRetry?: () => void;
  retryLabel?: string;
  className?: string;
}

export function ErrorState({
  title = "خطایی رخ داد",
  description = "لطفاً دوباره تلاش کنید.",
  onRetry,
  retryLabel = "تلاش مجدد",
  className,
}: ErrorStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center text-center py-12 px-4",
        className
      )}
    >
      <div
        className="w-16 h-16 mb-4 rounded-full flex items-center justify-center"
        style={{
          backgroundColor:
            "color-mix(in srgb, var(--severity-critical) 15%, transparent)",
        }}
      >
        <XCircle
          size={32}
          weight="fill"
          className="text-[var(--severity-critical)]"
        />
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-sm mb-4 leading-relaxed">
        {description}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-sm font-medium hover:bg-accent transition-colors"
        >
          <ArrowClockwise size={14} />
          {retryLabel}
        </button>
      )}
    </div>
  );
}

/* ============================================================================
   Skeleton Card
   ============================================================================ */

interface SkeletonCardProps {
  className?: string;
  lines?: number;
}

export function SkeletonCard({ className, lines = 3 }: SkeletonCardProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-border bg-card p-4",
        className
      )}
    >
      <div className="space-y-2">
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className="skeleton-pulse rounded bg-accent"
            style={{
              height: i === 0 ? "16px" : "12px",
              width: i === 0 ? "40%" : i === lines - 1 ? "60%" : "100%",
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
   Page Skeleton
   ============================================================================ */

export function PageSkeleton() {
  return (
    <div className="space-y-4 p-4 md:p-6">
      <div className="space-y-2">
        <div className="skeleton-pulse h-8 w-48 rounded bg-accent" />
        <div className="skeleton-pulse h-4 w-32 rounded bg-accent" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
      <SkeletonCard lines={5} />
    </div>
  );
}
