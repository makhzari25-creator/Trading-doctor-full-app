/**
 * Trading Doctor — App Shell
 *
 * Layout wrapper for all app views:
 * - TopBar: logo, analysis badge, theme/lang toggles, Cmd+K hint
 * - Sidebar: 12 nav items (desktop ≥md), off-canvas drawer (mobile)
 * - BottomTabBar: 5 items (mobile only)
 * - Breadcrumb: current page location
 *
 * Phase 3 §11.5, Phase 4 §3.5, Phase 5 §4.
 */

"use client";

import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { NAV_ITEMS, BOTTOM_TAB_ITEMS, MORE_SHEET_ITEMS } from "@/lib/utils/constants";
import { useAppStore } from "@/lib/store/app-store";
import { useThemeStore } from "@/lib/store/theme-store";
import { useAuthStore } from "@/lib/store/auth-store";
import { useAnalysisReport } from "@/lib/hooks/use-analysis-report";
import { toPersianNumerals } from "@/lib/utils";
import {
  List,
  X,
  Sun,
  Moon,
  Translate,
  MagnifyingGlass,
  UploadSimple,
  Gauge,
  CaretDown,
} from "@phosphor-icons/react";

interface AppShellProps {
  children: ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const {
    currentView,
    navigate,
    mobileNavOpen,
    setMobileNavOpen,
    toggleMobileNav,
    commandPaletteOpen,
    toggleCommandPalette,
    hasAnalysis,
  } = useAppStore();

  const { theme, language, setTheme, setLanguage } = useThemeStore();
  const { isAuthenticated, user } = useAuthStore();
  const { data: activeReport } = useAnalysisReport();

  // Apply theme class to <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.classList.remove("light");
    } else if (theme === "light") {
      root.classList.add("light");
      root.classList.remove("dark");
    }
  }, [theme]);

  // Apply language/dir to <html>
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "fa" ? "rtl" : "ltr";
  }, [language]);

  // Keyboard shortcut: Cmd/Ctrl+K
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        toggleCommandPalette();
      }
      if (e.key === "Escape") {
        setMobileNavOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [toggleCommandPalette, setMobileNavOpen]);

  const currentItem = NAV_ITEMS.find((item) => item.id === currentView);

  const handleThemeToggle = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const handleLangToggle = () => {
    setLanguage(language === "fa" ? "en" : "fa");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* ===== Top Bar ===== */}
      <header className="sticky top-0 z-40 flex items-center justify-between h-14 px-4 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        {/* Start (RTL: right) — logo + mobile menu */}
        <div className="flex items-center gap-3">
          <button
            className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
            onClick={toggleMobileNav}
            aria-label="باز کردن منو"
          >
            <List size={20} weight="bold" />
          </button>
          <button
            onClick={() => navigate(hasAnalysis ? "dashboard" : "landing")}
            className="flex items-center gap-2"
            aria-label="Trading Doctor — خانه"
          >
            <div className="w-8 h-8 rounded-lg bg-[var(--primary)] flex items-center justify-center">
              <Gauge size={18} weight="fill" className="text-white" />
            </div>
            <span className="font-bold text-sm hidden sm:inline">
              Trading Doctor
            </span>
          </button>
        </div>

        {/* Center — analysis badge */}
        {hasAnalysis && activeReport && (
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-card text-xs">
            <span className="td-mono">
              {toPersianNumerals(activeReport.statistics.total_trades)}
            </span>
            <span className="text-muted-foreground">معامله</span>
          </div>
        )}

        {/* End (RTL: left) — actions */}
        <div className="flex items-center gap-1">
          <button
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-accent transition-colors text-xs text-muted-foreground"
            onClick={toggleCommandPalette}
            aria-label="جستجوی دستور (Cmd+K)"
          >
            <MagnifyingGlass size={14} />
            <kbd className="td-mono text-[10px] px-1 py-0.5 rounded border border-border">
              ⌘K
            </kbd>
          </button>
          <button
            className="p-2 rounded-lg hover:bg-accent transition-colors"
            onClick={handleThemeToggle}
            aria-label="تغییر تم"
          >
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            className="p-2 rounded-lg hover:bg-accent transition-colors text-xs font-semibold"
            onClick={handleLangToggle}
            aria-label="تغییر زبان"
          >
            {language === "fa" ? "EN" : "فا"}
          </button>
          {isAuthenticated && user ? (
            <button
              onClick={() => navigate("profile")}
              className="flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-accent transition-colors"
              aria-label="پروفایل"
            >
              <div className="w-7 h-7 rounded-full bg-[var(--primary)]/10 flex items-center justify-center text-xs font-bold text-[var(--primary)]">
                {user.name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
              </div>
              <span className="hidden md:inline text-sm font-medium max-w-[100px] truncate">
                {user.name || user.email.split("@")[0]}
              </span>
            </button>
          ) : (
            <button
              onClick={() => navigate("login")}
              className="px-3 py-1.5 rounded-lg bg-[var(--primary)] text-white text-sm font-medium hover:opacity-90 transition-opacity"
            >
              ورود
            </button>
          )}
        </div>
      </header>

      <div className="flex flex-1">
        {/* ===== Sidebar (desktop) ===== */}
        <aside className="hidden md:flex w-[240px] flex-col border-border border-l rtl:border-l-0 rtl:border-r bg-sidebar">
          {/* Upload CTA */}
          <div className="p-3">
            <button
              onClick={() => navigate("upload")}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 transition-opacity font-medium text-sm"
            >
              <UploadSimple size={18} weight="bold" />
              آپلود فایل جدید
            </button>
          </div>

          {/* Nav items */}
          <nav
            className="flex-1 overflow-y-auto px-3 pb-3 space-y-1"
            aria-label="اصلی"
          >
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = currentView === item.id;
              const isDisabled = item.requiresAnalysis && !hasAnalysis;
              return (
                <button
                  key={item.id}
                  onClick={() => !isDisabled && navigate(item.id)}
                  disabled={isDisabled}
                  title={item.question}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm group",
                    active
                      ? "bg-[var(--sidebar-accent)] text-[var(--sidebar-accent-foreground)] font-medium"
                      : "text-muted-foreground hover:bg-[var(--sidebar-accent)]/50 hover:text-foreground",
                    isDisabled && "opacity-40 cursor-not-allowed"
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  <Icon
                    size={20}
                    weight={active ? "fill" : "regular"}
                    className={active ? "text-[var(--primary)]" : ""}
                  />
                  <span className="flex-1 text-start">{item.label}</span>
                  {active && (
                    <span className="w-1 h-5 rounded-full bg-[var(--primary)]" />
                  )}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* ===== Mobile Nav Drawer ===== */}
        {mobileNavOpen && (
          <div className="md:hidden fixed inset-0 z-50 flex">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileNavOpen(false)}
              aria-hidden="true"
            />
            <aside className="relative w-[280px] max-w-[80vw] flex flex-col bg-sidebar border-l rtl:border-l-0 rtl:border-r border-border">
              {/* Drawer header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <span className="font-bold text-sm">منو</span>
                <button
                  className="p-1.5 rounded-lg hover:bg-accent"
                  onClick={() => setMobileNavOpen(false)}
                  aria-label="بستن منو"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Upload CTA */}
              <div className="p-3">
                <button
                  onClick={() => navigate("upload")}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg bg-[var(--cta)] text-[var(--cta-foreground)] hover:opacity-90 transition-opacity font-medium text-sm"
                >
                  <UploadSimple size={18} weight="bold" />
                  آپلود فایل جدید
                </button>
              </div>

              {/* Nav items */}
              <nav
                className="flex-1 overflow-y-auto px-3 pb-3 space-y-1"
                aria-label="اصلی"
              >
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const active = currentView === item.id;
                  const isDisabled = item.requiresAnalysis && !hasAnalysis;
                  return (
                    <button
                      key={item.id}
                      onClick={() => !isDisabled && navigate(item.id)}
                      disabled={isDisabled}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm",
                        active
                          ? "bg-[var(--sidebar-accent)] text-foreground font-medium"
                          : "text-muted-foreground hover:bg-[var(--sidebar-accent)]/50",
                        isDisabled && "opacity-40 cursor-not-allowed"
                      )}
                    >
                      <Icon
                        size={20}
                        weight={active ? "fill" : "regular"}
                        className={active ? "text-[var(--primary)]" : ""}
                      />
                      {item.label}
                    </button>
                  );
                })}
              </nav>
            </aside>
          </div>
        )}

        {/* ===== Main Content ===== */}
        <main className="flex-1 overflow-x-hidden pb-20 md:pb-0">
          {/* Breadcrumb */}
          {currentView !== "landing" && currentView !== "upload" && (
            <div className="flex items-center gap-2 px-4 md:px-6 py-3 border-b border-border text-xs text-muted-foreground">
              <button
                onClick={() => hasAnalysis && navigate("dashboard")}
                className="hover:text-foreground transition-colors"
              >
                داشبورد
              </button>
              <span aria-hidden="true">›</span>
              <span className="text-foreground">{currentItem?.label}</span>
            </div>
          )}
          <div className="p-4 md:p-6 lg:p-8 max-w-[1280px] mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* ===== Bottom Tab Bar (mobile only) ===== */}
      <nav
        className="md:hidden fixed bottom-0 inset-x-0 z-40 flex items-center justify-around h-16 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 px-2"
        aria-label="ناوبری موبایل"
      >
        {BOTTOM_TAB_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = currentView === item.id;
          const isDisabled = item.requiresAnalysis && !hasAnalysis;
          return (
            <button
              key={item.id}
              onClick={() => !isDisabled && navigate(item.id)}
              disabled={isDisabled}
              className={cn(
                "flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg transition-colors flex-1 max-w-[64px]",
                active ? "text-[var(--primary)]" : "text-muted-foreground",
                isDisabled && "opacity-40"
              )}
              aria-current={active ? "page" : undefined}
              aria-label={item.label}
            >
              <Icon size={22} weight={active ? "fill" : "regular"} />
              <span className="text-[10px] leading-none">{item.label}</span>
            </button>
          );
        })}
        {/* More button */}
        <button
          onClick={() => setMobileNavOpen(true)}
          className="flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg transition-colors flex-1 max-w-[64px] text-muted-foreground"
          aria-label="بیشتر"
        >
          <CaretDown size={22} />
          <span className="text-[10px] leading-none">بیشتر</span>
        </button>
      </nav>

      {/* ===== Command Palette (Cmd+K) — Placeholder ===== */}
      {/* Full implementation in a later phase. For now, a simple dialog. */}
      {commandPaletteOpen && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4"
          onClick={() => toggleCommandPalette()}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-2xl bg-card border border-border rounded-xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 p-4 border-b border-border">
              <MagnifyingGlass size={20} className="text-muted-foreground" />
              <input
                type="text"
                placeholder="جستجو در صفحات، تحلیل‌ها، و اقدامات..."
                className="flex-1 bg-transparent outline-none text-sm"
                autoFocus
              />
              <kbd className="td-mono text-[10px] px-1.5 py-0.5 rounded border border-border text-muted-foreground">
                ESC
              </kbd>
            </div>
            <div className="max-h-[60vh] overflow-y-auto p-2">
              {NAV_ITEMS.filter((item) => !item.requiresAnalysis || hasAnalysis).map(
                (item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        navigate(item.id);
                        toggleCommandPalette();
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-accent transition-colors text-sm text-start"
                    >
                      <Icon size={18} className="text-muted-foreground" />
                      <div className="flex-1">
                        <div className="font-medium">{item.label}</div>
                        <div className="text-xs text-muted-foreground">
                          {item.question}
                        </div>
                      </div>
                    </button>
                  );
                }
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
