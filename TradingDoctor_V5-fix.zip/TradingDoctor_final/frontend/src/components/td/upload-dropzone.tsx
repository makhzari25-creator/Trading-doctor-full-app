/**
 * Trading Doctor — UploadDropzone Component
 *
 * Reusable drag-and-drop file upload zone with client-side validation.
 * Supports both drag-drop (desktop) and click-to-browse (mobile + desktop).
 *
 * Phase 3 §39.2 (UploadDropzone composite), §21 (Inputs file variant).
 * Phase 4 §5 (CSV Upload).
 */

"use client";

import { useState, useRef, type DragEvent, type ChangeEvent } from "react";
import { cn, formatFileSize, toPersianNumerals } from "@/lib/utils";
import { UploadSimple } from "@phosphor-icons/react";

interface UploadDropzoneProps {
  /** Called when a valid file is selected */
  onFileSelect: (file: File) => void;
  /** Called when validation fails */
  onError: (message: string) => void;
  /** Allowed file extensions (without dot) */
  allowedExtensions?: readonly string[];
  /** Maximum file size in bytes */
  maxSizeBytes?: number;
  /** Additional className */
  className?: string;
  /** Disabled state */
  disabled?: boolean;
}

const DEFAULT_EXTENSIONS = [
  "csv",
  "xlsx",
  "xls",
  "htm",
  "html",
  "json",
  "log",
  "txt",
] as const;

const DEFAULT_MAX_SIZE = 25 * 1024 * 1024; // 25 MB

export function UploadDropzone({
  onFileSelect,
  onError,
  allowedExtensions = DEFAULT_EXTENSIONS,
  maxSizeBytes = DEFAULT_MAX_SIZE,
  className,
  disabled = false,
}: UploadDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    // Size check
    if (file.size > maxSizeBytes) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
      const maxMB = (maxSizeBytes / (1024 * 1024)).toFixed(0);
      return `حجم فایل ${toPersianNumerals(sizeMB)} مگابایت است؛ حداکثر مجاز ${toPersianNumerals(maxMB)} مگابایت`;
    }

    // Extension check
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!ext || !allowedExtensions.includes(ext as never)) {
      return `فرمت .${ext} پشتیبانی نمی‌شود`;
    }

    return null;
  };

  const handleFile = (file: File) => {
    const error = validateFile(file);
    if (error) {
      onError(error);
      return;
    }
    onFileSelect(file);
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;

    const dropped = e.dataTransfer.files[0];
    if (dropped) handleFile(dropped);
  };

  const handleClick = () => {
    if (!disabled) inputRef.current?.click();
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) handleFile(selected);
    // Reset input so the same file can be selected again
    e.target.value = "";
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleClick}
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-label="آپلود فایل معاملات"
      aria-disabled={disabled}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleClick();
        }
      }}
      className={cn(
        "relative border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer",
        isDragging
          ? "border-[var(--cta)] bg-[var(--cta)]/5"
          : "border-border hover:border-[var(--primary)] hover:bg-accent/30",
        disabled && "opacity-40 cursor-not-allowed",
        className
      )}
      style={{ minHeight: "200px" }}
    >
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        accept={allowedExtensions.map((ext) => `.${ext}`).join(",")}
        onChange={handleChange}
        disabled={disabled}
        aria-hidden="true"
      />
      <UploadSimple
        size={40}
        weight="duotone"
        className="mx-auto mb-3 text-muted-foreground"
      />
      <p className="text-sm font-medium mb-1">
        برای انتخاب فایل ضربه بزنید
      </p>
      <p className="text-xs text-muted-foreground hidden sm:block">
        یا فایل را اینجا بکشید
      </p>
      <p className="text-xs text-muted-foreground mt-2">
        {allowedExtensions.join(" · ").toUpperCase()} — حداکثر{" "}
        {toPersianNumerals(maxSizeBytes / (1024 * 1024))} مگابایت
      </p>
    </div>
  );
}
