/**
 * Trading Doctor — ProgressStepper Component
 *
 * Multi-stage progress indicator for the Analysis Progress flow.
 * Shows 6 conceptual stages with honest state (pulsing dots, not fake checkmarks).
 *
 * Phase 3 §33 (Progress stepper variant), §39.2 (ProgressStepper composite).
 * Phase 4 §6 (Analysis Progress), Phase 2 §2.4 (smart time estimation).
 */

"use client";

import { cn, toPersianNumerals } from "@/lib/utils";
import { Check } from "@phosphor-icons/react";

export interface ProgressStage {
  id: number;
  label: string;
  icon?: string;
}

interface ProgressStepperProps {
  stages: ProgressStage[];
  /** Current stage index (0-based). If -1, all complete. */
  currentStage: number;
  /** Whether all stages are complete */
  allComplete: boolean;
  /** Layout: vertical on mobile, horizontal on desktop */
  orientation?: "vertical" | "horizontal";
  className?: string;
}

const DEFAULT_STAGES: ProgressStage[] = [
  { id: 1, label: "خواندن و نرمال‌سازی فایل" },
  { id: 2, label: "اعتبارسنجی داده" },
  { id: 3, label: "تحلیل رفتار" },
  { id: 4, label: "محاسبه‌ی امتیازها و Impact دلاری" },
  { id: 5, label: "تشخیص مشکل اصلی" },
  { id: 6, label: "ساخت برنامه‌ی اقدام" },
];

export function ProgressStepper({
  stages = DEFAULT_STAGES,
  currentStage,
  allComplete,
  orientation = "vertical",
  className,
}: ProgressStepperProps) {
  const isVertical = orientation === "vertical";

  return (
    <ol
      className={cn(
        "space-y-3",
        isVertical ? "flex flex-col" : "flex flex-row items-start gap-2",
        className
      )}
      aria-label="مراحل تحلیل"
    >
      {stages.map((stage, idx) => {
        const isComplete = allComplete || idx < currentStage;
        const isCurrent = !allComplete && idx === currentStage;
        const isUpcoming = !allComplete && idx > currentStage;

        return (
          <li
            key={stage.id}
            className={cn(
              "flex items-center gap-3",
              !isVertical && "flex-col items-center text-center flex-1"
            )}
          >
            {/* Stage indicator */}
            <div className="shrink-0 relative">
              {isComplete ? (
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center transition-all"
                  style={{
                    backgroundColor: "var(--severity-low)",
                  }}
                >
                  <Check size={14} weight="bold" className="text-white" />
                </div>
              ) : isCurrent ? (
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center skeleton-pulse"
                  style={{
                    backgroundColor: "color-mix(in srgb, var(--primary) 20%, transparent)",
                    border: "2px solid var(--primary)",
                  }}
                >
                  <span className="w-2 h-2 rounded-full bg-[var(--primary)]" />
                </div>
              ) : (
                <div className="w-7 h-7 rounded-full border-2 border-border flex items-center justify-center">
                  <span className="text-xs text-muted-foreground td-mono">
                    {toPersianNumerals(stage.id)}
                  </span>
                </div>
              )}

              {/* Connector line (horizontal only) */}
              {!isVertical && idx < stages.length - 1 && (
                <div
                  className="absolute top-3.5 left-full w-full h-0.5"
                  style={{
                    backgroundColor: isComplete ? "var(--severity-low)" : "var(--border)",
                  }}
                />
              )}
            </div>

            {/* Stage label */}
            <div className={cn(isVertical ? "flex-1" : "mt-1")}>
              <span
                className={cn(
                  "text-sm transition-colors",
                  isComplete && "text-foreground",
                  isCurrent && "text-foreground font-medium",
                  isUpcoming && "text-muted-foreground"
                )}
              >
                {stage.label}
              </span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export { DEFAULT_STAGES as ANALYSIS_STAGES };
