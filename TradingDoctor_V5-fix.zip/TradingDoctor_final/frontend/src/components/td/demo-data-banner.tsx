/**
 * DemoDataBanner — a high-visibility, accessible banner that marks a UI
 * section as using illustrative / sample data instead of real backend data.
 *
 * Replaces the previous low-contrast muted-foreground inline note that was
 * easy for end users to miss. The banner uses the design system's `warning`
 * token (amber/yellow) for visibility while remaining non-blocking.
 *
 * Used by:
 *   - views/charts.tsx (4 time-series charts)
 *   - views/trade-explorer.tsx (raw trade list table)
 */
"use client";

import { AlertTriangle } from "lucide-react";

export interface DemoDataBannerProps {
  /** Short title shown in bold. */
  title?: string;
  /** Longer explanation of *what* is mocked and *why*. */
  reason: string;
  /** Optional technical footnote about how to enable the real endpoint. */
  technicalNote?: string;
  className?: string;
}

export function DemoDataBanner({
  title = "داده‌ی نمایشی",
  reason,
  technicalNote,
  className = "",
}: DemoDataBannerProps) {
  return (
    <div
      role="status"
      aria-live="polite"
      className={`flex items-start gap-3 rounded-[var(--td-radius-md)] border border-warning/40 bg-[var(--td-warning-soft-bg, rgba(245,158,11,0.08))] p-3 text-xs text-text ${className}`}
    >
      <AlertTriangle
        size={16}
        className="mt-0.5 shrink-0 text-warning"
        aria-hidden="true"
      />
      <div className="flex flex-col gap-1">
        <span className="font-semibold text-warning">{title}</span>
        <span className="leading-relaxed text-text-muted">{reason}</span>
        {technicalNote ? (
          <span className="mt-1 font-mono text-[10px] leading-relaxed text-text-muted/80">
            {technicalNote}
          </span>
        ) : null}
      </div>
    </div>
  );
}
