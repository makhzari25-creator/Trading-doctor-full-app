/**
 * Trading Doctor — StatCard Component
 *
 * Single metric display: label + mono value + optional trend color.
 * Used in Dashboard performance strip, Overview, Performance, Risk, Edge Map.
 *
 * Phase 3 §39.2 (StatCard composite), §20 (Card stat variant).
 */

"use client";

import { Card } from "@/components/ui/card";
import { cn, profitTrend } from "@/lib/utils";
import type { ReactNode } from "react";

interface StatCardProps {
  label: string;
  value: string | number;
  /** Trend indicator. "up" = green, "down" = red, "neutral" = default */
  trend?: "up" | "down" | "neutral";
  /** Optional sub-value (e.g., unit, percentage) */
  subValue?: string;
  /** Click handler (makes the card interactive) */
  onClick?: () => void;
  /** Additional className */
  className?: string;
  /** Optional icon */
  icon?: ReactNode;
}

const TREND_COLORS: Record<string, string> = {
  up: "var(--profit-positive)",
  down: "var(--profit-negative)",
  neutral: "",
};

export function StatCard({
  label,
  value,
  trend,
  subValue,
  onClick,
  className,
  icon,
}: StatCardProps) {
  const trendColor = trend ? TREND_COLORS[trend] : "";

  return (
    <Card
      className={cn(
        "p-3 transition-all",
        onClick &&
          "cursor-pointer hover:bg-accent hover:border-[var(--primary)] hover:shadow-md",
        className
      )}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
      aria-label={onClick ? `${label}: ${value}` : undefined}
    >
      <div className="flex items-center gap-1.5 mb-1">
        {icon && <span className="text-muted-foreground">{icon}</span>}
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
      <div
        className={cn("td-mono font-semibold text-lg leading-tight", trend && !trendColor && "")}
        style={trendColor ? { color: trendColor } : undefined}
      >
        {value}
      </div>
      {subValue && (
        <div className="text-xs text-muted-foreground mt-0.5">{subValue}</div>
      )}
    </Card>
  );
}
