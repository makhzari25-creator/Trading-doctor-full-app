/**
 * Unit tests for the DemoDataBanner component.
 *
 * Verifies the three core behaviours:
 *  1. The banner renders with the user-supplied title + reason text.
 *  2. The optional technicalNote is shown only when provided.
 * 3. The banner exposes role="status" / aria-live="polite" so screen
 *    readers announce it on navigation.
 */
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { DemoDataBanner } from "../demo-data-banner";

describe("DemoDataBanner", () => {
  it("renders title and reason", () => {
    render(
      <DemoDataBanner
        title="داده‌ی نمایشی"
        reason="این نمودار از داده‌ی نمونه استفاده می‌کند."
      />,
    );
    expect(screen.getByText("داده‌ی نمایشی")).toBeInTheDocument();
    expect(
      screen.getByText("این نمودار از داده‌ی نمونه استفاده می‌کند."),
    ).toBeInTheDocument();
  });

  it("hides technicalNote when not provided", () => {
    const { container } = render(
      <DemoDataBanner reason="only reason" />,
    );
    expect(container.querySelector("font-mono")).toBeNull();
  });

  it("shows technicalNote when provided", () => {
    render(
      <DemoDataBanner
        reason="r"
        technicalNote="GET /analyses/{id}/trades"
      />,
    );
    expect(
      screen.getByText("GET /analyses/{id}/trades"),
    ).toBeInTheDocument();
  });

  it("is announced to screen readers via role=status + aria-live=polite", () => {
    const { container } = render(<DemoDataBanner reason="r" />);
    const banner = container.querySelector('[role="status"]');
    expect(banner).not.toBeNull();
    expect(banner?.getAttribute("aria-live")).toBe("polite");
  });
});
