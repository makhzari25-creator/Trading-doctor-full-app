/**
 * Trading Doctor — SeverityBadge Component
 *
 * Displays severity level (Low/Medium/High/Critical) with color + text + icon.
 * Color is NEVER the only signal — always paired with Persian text label.
 *
 * Phase 3 §27 (Badges severity variant), §5.1 (Severity colors).
 */

"use client";

import { cn } from "@/lib/utils";
import { severityToLevel, severityLabel, severityColor, severityBg } from "@/lib/utils";
import type { Severity, SeverityLevel } from "@/lib/types";

interface SeverityBadgeProps {
  severity: Severity | SeverityLevel;
  size?: "sm" | "md";
  className?: string;
}

export function SeverityBadge({
  severity,
  size = "md",
  className,
}: SeverityBadgeProps) {
  const level = severityToLevel(severity);
  const label = severityLabel(level);
  const color = severityColor(level);
  const bg = severityBg(level);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded font-medium",
        size === "sm" ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-xs",
        className
      )}
      style={{ color, backgroundColor: bg }}
      role="status"
      aria-label={`شدت: ${label}`}
    >
      <span
        className="inline-block w-1.5 h-1.5 rounded-full"
        style={{ backgroundColor: color }}
        aria-hidden="true"
      />
      {label}
    </span>
  );
}
