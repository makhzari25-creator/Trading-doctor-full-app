/**
 * Trading Doctor — ScoreGauge Component
 *
 * Radial gauge for 0–100 scores with severity-colored arc.
 * Animates from 0 to value on mount (frozen if prefers-reduced-motion).
 *
 * Phase 3 §39.2 (ScoreGauge composite), §33 (Progress circular-determinate).
 */

"use client";

import { cn, scoreToSeverityLevel } from "@/lib/utils";

// Re-export sibling components for convenient barrel import
export { SeverityBadge } from "./severity-badge";
export { StatCard } from "./stat-card";

interface ScoreGaugeProps {
  /** Score value 0–100 */
  value: number;
  /** Diameter in pixels */
  size?: number;
  /** Stroke width in pixels */
  strokeWidth?: number;
  /** Show "/ ۱۰۰" label below the number */
  showMax?: boolean;
  /** Optional label below the gauge */
  label?: string;
  /** Additional className */
  className?: string;
  /** Disable entrance animation */
  animate?: boolean;
}

const SEVERITY_COLORS: Record<number, string> = {
  0: "var(--severity-low)",
  1: "var(--severity-medium)",
  2: "var(--severity-high)",
  3: "var(--severity-critical)",
};

export function ScoreGauge({
  value,
  size = 96,
  strokeWidth = 8,
  showMax = false,
  label,
  className,
  animate = true,
}: ScoreGaugeProps) {
  const clampedValue = Math.max(0, Math.min(100, value));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clampedValue / 100) * circumference;
  const severityLevel = scoreToSeverityLevel(clampedValue);
  const color = SEVERITY_COLORS[severityLevel];

  return (
    <div
      className={cn(
        "relative inline-flex flex-col items-center justify-center",
        className
      )}
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        className="transform -rotate-90"
        role="img"
        aria-label={`امتیاز: ${clampedValue} از ۱۰۰`}
      >
        {/* Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--muted)"
          strokeWidth={strokeWidth}
          opacity={0.3}
        />
        {/* Progress arc — starts at 0, CSS animates to target */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{
            transition: animate
              ? "stroke-dashoffset 0.6s cubic-bezier(0.16, 1, 0.3, 1)"
              : "none",
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className="td-mono font-bold leading-none"
          style={{ fontSize: size * 0.22 }}
        >
          {clampedValue}
        </span>
        {showMax && (
          <span className="text-[10px] text-muted-foreground mt-0.5">/ ۱۰۰</span>
        )}
        {label && (
          <span className="text-[10px] text-muted-foreground mt-0.5 px-2 text-center leading-tight">
            {label}
          </span>
        )}
      </div>
    </div>
  );
}
