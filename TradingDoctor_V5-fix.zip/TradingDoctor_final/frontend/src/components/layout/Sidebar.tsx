"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, History, Stethoscope } from "lucide-react";
import clsx from "clsx";

const NAV_ITEMS = [
  { href: "/", label: "آپلود و تحلیل جدید", icon: Stethoscope },
  { href: "/dashboard", label: "داشبورد", icon: LayoutDashboard },
  { href: "/history", label: "تاریخچه", icon: History },
];

export function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="flex h-screen w-60 flex-col border-e border-border bg-surface p-4">
      <div className="mb-6 flex items-center gap-2 px-2">
        <span className="text-xl">🩺</span>
        <span className="font-bold text-text">Trading Doctor</span>
      </div>
      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={clsx(
                "flex items-center gap-2 rounded-[var(--td-radius-sm)] px-3 py-2 text-sm transition-colors",
                active
                  ? "border-s-2 border-accent bg-accent-muted text-accent font-medium"
                  : "text-text-muted hover:bg-surface-3"
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
