"use client";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";
import * as React from "react";

/**
 * Mount-detection via useSyncExternalStore — no setState-in-effect.
 * Server snapshot returns false (placeholder); client snapshot returns true
 * once hydration completes. Same visual behaviour as the previous mounted-flag,
 * but compliant with React 19's strict effect rules.
 */
function subscribeNoop(cb: () => void): () => void {
  // No external store to subscribe to — we just need a stable "true" after hydration.
  // Re-rendering on any window focus isn't useful for this component, so unsubscribe immediately.
  return () => {};
}
function getClientMounted(): boolean {
  return true;
}
function getServerMounted(): boolean {
  return false;
}

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const mounted = React.useSyncExternalStore(
    subscribeNoop,
    getClientMounted,
    getServerMounted,
  );
  if (!mounted) return <div className="h-9 w-9" />; // avoid hydration flash

  return (
    <button
      aria-label="تغییر حالت روشن/تیره"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="flex h-9 w-9 items-center justify-center rounded-[var(--td-radius-sm)] text-text-muted transition-colors hover:bg-surface-3"
    >
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
