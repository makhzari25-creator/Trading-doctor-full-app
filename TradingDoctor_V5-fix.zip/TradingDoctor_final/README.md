# Trading Doctor V23

> Persian-language behavioral trading-analysis SaaS platform.
> Production-ready backend (242 tests) + complete Next.js frontend.

## Quick Start

### Backend
```bash
cd backend/
cp .env.example .env  # Set secrets
docker compose -f ../docker/docker-compose.dev.yml up -d
docker compose -f ../docker/docker-compose.dev.yml exec api alembic upgrade head
curl http://localhost:8000/api/v1/health
```

### Frontend
```bash
cd frontend/
bun install  # or npm install
bun run dev  # http://localhost:3000
```

### Tests
```bash
cd backend/
pytest tests/ -v
```

## Structure
- `backend/` — Python FastAPI + V23 Engine (141 files, 242 tests)
- `frontend/` — Next.js full project (174 files, 14 views)
- `docs/` — All documentation (65 files)
- `docker/` — Docker configurations
- `deploy/` — nginx + postgres configs
- `scripts/` — Backup + utility scripts
- `.github/` — CI/CD pipeline

## Documentation
- `docs/TradingDoctor_Master_Project_Report.md` — Comprehensive report
- `docs/Merge_Decision_Log.md` — Merge decisions
- `docs/backend/` — Backend-specific docs
- `docs/frontend/` — Frontend design docs + screenshots

## Production Readiness: 92/100 — APPROVED
