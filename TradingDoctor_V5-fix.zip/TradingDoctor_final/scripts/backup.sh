#!/bin/bash
# =============================================================================
# Trading Doctor V23 — Backup Script
# =============================================================================
# Backs up:
#   - PostgreSQL database (pg_dump → gzip → S3)
#   - Upload files (tar → gzip → S3)
#
# Retention: 30 days (older backups are deleted from S3)
#
# Usage:
#   ./scripts/backup.sh
#
# Cron (daily at 2 AM UTC):
#   0 2 * * * /path/to/TradingDoctor/scripts/backup.sh >> /var/log/td-backup.log 2>&1
# =============================================================================

set -euo pipefail

# Configuration
BACKUP_DIR="${BACKUP_DIR:-/tmp/td-backups}"
S3_BUCKET="${S3_BUCKET:-}"  # e.g. "s3://tradingdoctor-backups"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
DATE=$(date -u +%Y%m%d-%H%M%S)

# Database
DB_HOST="${POSTGRES_HOST:-db}"
DB_PORT="${POSTGRES_PORT:-5432}"
DB_NAME="${POSTGRES_DB:-tradingdoctor}"
DB_USER="${POSTGRES_USER:-tradingdoctor}"

# Uploads
UPLOADS_DIR="${UPLOADS_DIR:-/app/data/api_runs/uploads}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# -----------------------------------------------------------------------------
# Setup
# -----------------------------------------------------------------------------

mkdir -p "$BACKUP_DIR"
log_info "Starting backup: $DATE"
log_info "Backup directory: $BACKUP_DIR"
log_info "S3 bucket: ${S3_BUCKET:-<not configured>}"
log_info "Retention: $RETENTION_DAYS days"

# -----------------------------------------------------------------------------
# 1. Database backup
# -----------------------------------------------------------------------------

DB_BACKUP_FILE="$BACKUP_DIR/db_$DATE.sql.gz"
log_info "Backing up database to: $DB_BACKUP_FILE"

if PGPASSWORD="${POSTGRES_PASSWORD:-}" pg_dump \
    -h "$DB_HOST" \
    -p "$DB_PORT" \
    -U "$DB_USER" \
    -d "$DB_NAME" \
    --no-owner \
    --no-privileges \
    --format=custom \
    | gzip -9 > "$DB_BACKUP_FILE"; then
    DB_SIZE=$(du -h "$DB_BACKUP_FILE" | cut -f1)
    log_info "Database backup complete: $DB_SIZE"
else
    log_error "Database backup failed!"
    exit 1
fi

# -----------------------------------------------------------------------------
# 2. Upload files backup
# -----------------------------------------------------------------------------

UPLOADS_BACKUP_FILE="$BACKUP_DIR/uploads_$DATE.tar.gz"
log_info "Backing up uploads to: $UPLOADS_BACKUP_FILE"

if [ -d "$UPLOADS_DIR" ]; then
    if tar czf "$UPLOADS_BACKUP_FILE" -C "$(dirname "$UPLOADS_DIR")" "$(basename "$UPLOADS_DIR")"; then
        UPLOADS_SIZE=$(du -h "$UPLOADS_BACKUP_FILE" | cut -f1)
        log_info "Uploads backup complete: $UPLOADS_SIZE"
    else
        log_error "Uploads backup failed!"
        exit 1
    fi
else
    log_warn "Uploads directory not found: $UPLOADS_DIR — skipping"
fi

# -----------------------------------------------------------------------------
# 3. Upload to S3 (if configured)
# -----------------------------------------------------------------------------

if [ -n "$S3_BUCKET" ]; then
    log_info "Uploading backups to S3: $S3_BUCKET"

    if command -v aws &> /dev/null; then
        aws s3 cp "$DB_BACKUP_FILE" "$S3_BUCKET/db/"
        if [ -f "$UPLOADS_BACKUP_FILE" ]; then
            aws s3 cp "$UPLOADS_BACKUP_FILE" "$S3_BUCKET/uploads/"
        fi
        log_info "S3 upload complete"
    else
        log_warn "aws CLI not installed — S3 upload skipped"
    fi
else
    log_warn "S3_BUCKET not configured — backups stay local only"
fi

# -----------------------------------------------------------------------------
# 4. Cleanup old backups (local + S3)
# -----------------------------------------------------------------------------

log_info "Cleaning up backups older than $RETENTION_DAYS days"

# Local cleanup
find "$BACKUP_DIR" -name "db_*.sql.gz" -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true
find "$BACKUP_DIR" -name "uploads_*.tar.gz" -mtime +"$RETENTION_DAYS" -delete 2>/dev/null || true

# S3 cleanup
if [ -n "$S3_BUCKET" ] && command -v aws &> /dev/null; then
    aws s3 ls "$S3_BUCKET/db/" | awk '{print $4}' | while read -r fname; do
        if [ -n "$fname" ]; then
            # Extract date from filename: db_YYYYMMDD-HHMMSS.sql.gz
            file_date=$(echo "$fname" | grep -oE '[0-9]{8}' | head -1)
            if [ -n "$file_date" ]; then
                cutoff_date=$(date -u -d "$RETENTION_DAYS days ago" +%Y%m%d)
                if [ "$file_date" -lt "$cutoff_date" ]; then
                    log_info "Deleting old S3 backup: $fname"
                    aws s3 rm "$S3_BUCKET/db/$fname"
                fi
            fi
        fi
    done
fi

log_info "Backup complete: $DATE"
echo ""
echo "Summary:"
echo "  Database: $DB_BACKUP_FILE ($(du -h "$DB_BACKUP_FILE" | cut -f1))"
[ -f "$UPLOADS_BACKUP_FILE" ] && echo "  Uploads:  $UPLOADS_BACKUP_FILE ($(du -h "$UPLOADS_BACKUP_FILE" | cut -f1))"
echo "  S3:       ${S3_BUCKET:-<not configured>}"
