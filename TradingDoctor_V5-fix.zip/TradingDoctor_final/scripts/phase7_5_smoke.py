"""Phase 7.5 smoke test — verify new infrastructure works end-to-end.

Run: python scripts/phase7_5_smoke.py
"""
import os
import sys

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient


def main() -> int:
    # Import here so sys.path adjustment takes effect
    from api.main import app

    client = TestClient(app)

    print("\n=== Phase 7.5 Smoke Test ===\n")

    # 1. Liveness
    r = client.get("/api/v1/health")
    assert r.status_code == 200, f"health failed: {r.status_code} {r.text}"
    body = r.json()
    assert body["status"] == "ok"
    assert body["engine_ready"] is True
    print(f"[OK] GET /api/v1/health            status={body['status']} engine_ready={body['engine_ready']}")

    # 2. Readiness (DB + Redis checks; both should be 'true' in no-DB mode)
    r = client.get("/api/v1/health/ready")
    assert r.status_code == 200, f"health/ready failed: {r.status_code} {r.text}"
    body = r.json()
    print(f"[OK] GET /api/v1/health/ready      status={body['status']} "
          f"engine={body['engine_ready']} db={body['db_ready']} redis={body['redis_ready']}")

    # 3. Metrics endpoint
    r = client.get("/metrics")
    assert r.status_code == 200, f"metrics failed: {r.status_code} {r.text}"
    assert "http_requests_total" in r.text or "python_info" in r.text
    print(f"[OK] GET /metrics                  bytes={len(r.content)}")

    # 4. Root endpoint (should include env)
    r = client.get("/")
    assert r.status_code == 200
    body = r.json()
    print(f"[OK] GET /                         service={body['service']!r} env={body['env']!r}")

    # 5. Verify /docs is accessible in dev mode
    r = client.get("/docs")
    assert r.status_code == 200
    print(f"[OK] GET /docs                     status={r.status_code} (dev mode)")

    # 6. Verify config endpoint (no secrets)
    r = client.get("/api/v1/config")
    assert r.status_code == 200
    body = r.json()
    assert "max_upload_size_mb" in body
    print(f"[OK] GET /api/v1/config            max_upload={body['max_upload_size_mb']}MB "
          f"auth_enabled={body['auth_enabled']}")

    # 7. Verify request_id header is present
    r = client.get("/api/v1/health")
    assert "x-request-id" in r.headers, "X-Request-ID header missing"
    print(f"[OK] X-Request-ID header           value={r.headers['x-request-id']!r}")

    print("\n=== All Phase 7.5 smoke tests passed ===\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
