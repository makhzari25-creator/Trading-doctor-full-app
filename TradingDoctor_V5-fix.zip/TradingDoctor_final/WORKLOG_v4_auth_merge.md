# گزارش کار — Merge Auth to Single Source (v4)

> تاریخ: ۲۰۲۶-۰۷-۲۰
> ورودی: `TradingDoctor_V23_fixed_v3.zip` (۹۳٪ تکمیل)
> خروجی: `TradingDoctor_V23_fixed_v4.zip`

## خلاصه‌ی اجرایی

سیستم auth موازی Next.js (Prisma + next-auth + td-session cookie) به‌طور کامل
حذف شد. FastAPI حالا single source of truth برای تمام authentication است.
فرانت‌اند فقط از طریق httpOnly cookies با آن صحبت می‌کند — توکن‌ها هرگز در
JavaScript قابل دسترسی نیستند.

### نتیجه‌ی تست‌ها (هر سه لایه پاس شد)

| لایه | نتیجه | زمان |
|---|---|---|
| Backend `pytest tests/` | ✅ **۲۴۱ تست پاس** — ۰ شکست | ۷۱ ثانیه |
| Frontend `vitest run` | ✅ **۱۲ تست پاس** — ۰ شکست | ۳ ثانیه |
| Frontend `next build` | ✅ **موفق** در ۱۱.۶ ثانیه — ۲۷ route | — |
| Frontend `npm run lint` | ✅ **۰ خطا**، ۱۰۱ هشدار (کاهش از ۱۱۰) | — |

### حفظ تمام کارهای قبلی

- ✅ Charts و Trade Explorer روی داده‌ی واقعی (v3)
- ✅ Celery polling، runAnalysisWithPolling (v2)
- ✅ DemoDataBanner حذف‌شده از charts/trade-explorer (v3)
- ✅ Vitest تست‌ها (v2)
- ✅ ESLint rules تدریجی (v2)
- ✅ conftest.py برای rate-limit در تست (v3)
- ✅ httpx در requirements-dev.txt (v2)
- ✅ backend/reporting/chart_data.py (v3)
- ✅ موتور V23 — دست‌نخورده در تمام ۴ نسخه

---

## ۱. Design Decisions

پاسخ به ۶ سؤال طراحی قبل از شروع کار:

| سؤال | انتخاب |
|---|---|
| Bridge strategy | **ساده‌سازی کامل**: حذف HMAC + shadow account، توکن مستقیماً از cookie خوانده شود |
| Frontend routes | **حذف + proxy جدید**: ۱۲ route قدیمی حذف، ۸ route جدید `/api/v1/auth/*` + ۳ route `/api/v1/me/*` |
| Token storage | **فقط httpOnly cookie**: JavaScript به توکن دسترسی ندارد (حذف XSS attack surface) |
| Prisma | **حذف کامل**: schema، @prisma/client، prisma CLI، postinstall script |
| next-auth | **حذف کامل**: package از package.json حذف، NEXTAUTH_SECRET env var حذف |
| Migration | **Fresh start**: این dev/test است، بدون داده‌ی production |

---

## ۲. حذف‌ها

### فایل‌ها حذف شدند:
- `frontend/prisma/` (تمام schema و migrations)
- `frontend/src/lib/db.ts` (Prisma client singleton)
- `frontend/src/lib/auth/` (csrf، audit-log، email، rate-limiter — ۴ فایل)
- `frontend/src/app/api/auth/` (۱۲ route قدیمی)

### Dependencies حذف شدند از `package.json`:
- `@prisma/client` (runtime)
- `prisma` (CLI)
- `next-auth` (احراز هویت — استفاده نشده ولی نصب بود)
- `bcryptjs` + `@types/bcryptjs` (پسورد hashing — حالا در backend)
- `jsonwebtoken` + `@types/jsonwebtoken` (JWT verification — حالا در backend)

### Scripts حذف شدند از `package.json`:
- `postinstall: prisma generate`
- `db:push`, `db:generate`, `db:setup`, `db:migrate`, `db:reset`

### نصب مجدد package count:
- v3: ۹۶۵ package
- v4: ۸۸۹ package (۷۶ package کمتر — تمیزتر)

---

## ۳. فایل‌های جدید

### `frontend/src/lib/server/auth-cookies.ts`
```typescript
setAuthCookies(tokens)  // set httpOnly td-access + td-refresh
clearAuthCookies()      // clear both
```
Cookies با `httpOnly: true`، `sameSite: "lax"`، `secure: true in production`،
و 30s buffer قبل از انقضای واقعی access token.

### ۸ proxy route در `/api/v1/auth/*`:
| Route | Method | Backend Endpoint | عملکرد |
|---|---|---|---|
| `/api/v1/auth/login` | POST | `/auth/login` | login + set cookies + return user |
| `/api/v1/auth/register` | POST | `/auth/register` | forward registration |
| `/api/v1/auth/logout` | POST | `/auth/logout` | invalidate refresh + clear cookies |
| `/api/v1/auth/refresh` | POST | `/auth/refresh` | rotate tokens + set new cookies |
| `/api/v1/auth/session` | GET | `/me` | return current user profile (or null) |
| `/api/v1/auth/verify-email` | POST | `/auth/verify-email` | forward verification token |
| `/api/v1/auth/resend-verification` | POST | `/auth/resend-verification` | resend verification email |
| `/api/v1/auth/password-reset/request` | POST | `/auth/password-reset/request` | request reset email |
| `/api/v1/auth/password-reset/confirm` | POST | `/auth/password-reset/confirm` | confirm reset with new password |

### ۳ proxy route در `/api/v1/me/*`:
| Route | Method | Backend Endpoint | عملکرد |
|---|---|---|---|
| `/api/v1/me` | GET/PATCH/DELETE | `/me` | profile read/update/delete |
| `/api/v1/me/password` | POST | `/me/password` | change password + clear cookies |
| `/api/v1/me/activity` | GET | `/me/activity` | audit log (replaces sessions + login-history) |

---

## ۴. بازنویسی‌های کلیدی

### `frontend/src/lib/store/auth-store.ts`
**قبل (v3):**
```typescript
interface AuthState {
  user: AuthUser | null;
  sessionToken: string | null;  // ← حذف شد
  // ...
  setSession: (user, token) => void;  // ← حذف شد
}
```

**بعد (v4):**
```typescript
interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUser: (user) => void;
  logout: () => void;
  setLoading: (loading) => void;
}
```
توکن‌ها هرگز در JS-visible state ذخیره نمی‌شوند.

### `frontend/src/lib/server/session.ts`
**قبل (v3):** verify `td-session` cookie با NEXTAUTH_SECRET → lookup user در Prisma.

**بعد (v4):**
```typescript
getAccessToken()   → read from httpOnly cookie td-access
getRefreshToken()  → read from httpOnly cookie td-refresh
getSessionUser()   → fetch GET /me with access token (cached per-request)
```

### `frontend/src/lib/server/backend-auth-bridge.ts`
**قبل (v3):** derive password از `HMAC(BRIDGE_SECRET, prismaUserId)`، register/login shadow account، cache tokens در cookies.

**بعد (v4):**
```typescript
getBackendAccessToken()    → just reads from cookie (was: complex bridge)
refreshBackendTokens()     → POST /auth/refresh with refresh cookie
loginBackend(email, pw)    → POST /auth/login, return { tokens, user }
```
کد از ۲۱۳ خط به ۱۶۸ خط کاهش یافت. پیچیدگی cyclomatic به‌طور قابل‌توجهی کاهش یافت.

### `frontend/src/lib/server/backend-config.ts`
- حذف validation پیچیده BRIDGE_SECRET (همان `validateBridgeSecret()` که در v2 اضافه شد).
- BRIDGE_SECRET به‌عنوان deprecated نگه داشته شد برای backward compat با env files موجود.
- افزودن `ACCESS_COOKIE`، `REFRESH_COOKIE`، `cookieSecure()`، `COOKIE_SAME_SITE` constants.

### `frontend/src/lib/server/backend-proxy.ts`
`resolveAuth()` حالا فقط `getBackendAccessToken()` را صدا می‌زند — نه `getSessionUser()` + bridge.
```typescript
// قبل (v3):
const user = await getSessionUser();
if (!user) return 401;
const token = await getBackendAccessToken(user);  // bridge

// بعد (v4):
const token = await getBackendAccessToken();  // just reads cookie
if (!token) return 401;
```

### `frontend/src/views/auth/index.tsx`
تغییرات گسترده:
- حذف CSRF token helper (cookie-based auth نیازی به CSRF header ندارد).
- `LoginView`: `setUser(data.user)` به‌جای `setSession(data.user, data.sessionToken)`.
- `RegisterView`: `full_name` به‌جای `name` (backend schema).
- `ProfileView`: حذف `sessionToken`، حذف avatar upload (backend endpoint ندارد)، استفاده از `/api/v1/me` و `/api/v1/me/password`.
- `SecurityView`: حذف `/api/auth/sessions` و `/api/auth/login-history`، استفاده از `/api/v1/me/activity` (audit log بک‌اند).
- حذف imports بلااستفاده: `Camera`، `Monitor`، `Trash`.

### `frontend/src/app/page.tsx`
session check: `/api/auth/session` → `/api/v1/auth/session`.

---

## ۵. Backend — بدون تغییر

موتور V23، APIهای موجود، auth endpoints (login، register، refresh، logout،
verify-email، password-reset، /me، /me/password، /me/activity)، reporting،
billing، workspace — همه دست‌نخورده باقی ماندند.

تأیید: `pytest tests/` → ۲۴۱ تست پاس (همان نتیجه‌ی v3).

---

## ۶. نتیجه‌ی تست‌ها

### Backend `pytest tests/` — ۲۴۱ تست پاس
```
================ 241 passed, 323 warnings in 70.93s (0:01:10) ================
```
بدون تغییر نسبت به v3 — موتور V23 دست‌نخورده است.

### Frontend `vitest run` — ۱۲ تست پاس
```
✓ src/lib/api/__tests__/api-error.test.ts (6 tests) 3ms
✓ src/components/td/__tests__/demo-data-banner.test.tsx (4 tests) 42ms
✓ src/hooks/__tests__/use-mobile.test.ts (2 tests) 14ms

 Test Files  3 passed (3)
      Tests  12 passed (12)
   Duration  2.62s
```

### Frontend `next build` — موفق
```
▲ Next.js 16.2.10 (Turbopack)
✓ Compiled successfully in 11.6s
✓ Generating static pages using 1 worker (22/22) in 279ms

Route (app) — 27 routes:
  2 static (/, /_not-found)
  25 dynamic (شامل ۱۱ route جدید auth/me)
```

مسیرهای جدید در build:
- `/api/v1/auth/login` (NEW)
- `/api/v1/auth/logout` (NEW)
- `/api/v1/auth/password-reset/confirm` (NEW)
- `/api/v1/auth/password-reset/request` (NEW)
- `/api/v1/auth/refresh` (NEW)
- `/api/v1/auth/register` (NEW)
- `/api/v1/auth/resend-verification` (NEW)
- `/api/v1/auth/session` (NEW)
- `/api/v1/auth/verify-email` (NEW)
- `/api/v1/me` (NEW)
- `/api/v1/me/activity` (NEW)
- `/api/v1/me/password` (NEW)

### Frontend `npm run lint` — ۰ خطا
```
✖ 101 problems (0 errors, 101 warnings)
```
کاهش از ۱۱۰ هشدار در v3 به ۱۰۱ در v4 (۹ هشدار کمتر) — حذف کد legacy که هشدار تولید می‌کرد.

---

## ۷. امنیت — بهبودها

### حذف attack surfaces:
1. **XSS token theft**: توکن‌ها حالا فقط در httpOnly cookies هستند — JavaScript نمی‌تواند آن‌ها را بخواند. در v3، `sessionToken` در zustand persist (localStorage) ذخیره می‌شد.
2. **CSRF**: SameSite=lax cookies محافظت در برابر cross-site POST فراهم می‌کنند. در v3، CSRF token از cookie خوانده می‌شد و در header ارسال می‌شد (double-submit cookie pattern) — پیچیده‌تر ولی نه امن‌تر از SameSite=lax.
3. **Bridge secret leak**: حذف کامل. در v3، اگر `BRIDGE_SECRET` لو می‌رفت، تمام حساب‌های کاربری قابل جعل بودند. در v4، BRIDGE_SECRET اصلاً استفاده نمی‌شود.
4. **Session fixation**: در v3، `td-session` cookie ثابت بود تا زمانی که کاربر logout می‌کرد. در v4، access token هر ۱۵ دقیقه (یا هر چه backend تنظیم کرده) rotate می‌شود.

### حفظ شده:
- multi-tenant isolation در backend (هر user فقط داده‌ی خودش را می‌بیند).
- rate limiting در backend (همان `enforce_rate_limit` dependency).
- JWT signature verification در backend (همان `get_current_user` dependency).
- refresh token rotation در backend (هر refresh یک refresh token جدید صادر می‌کند).

---

## ۸. ساختار ZIP نهایی

```
TradingDoctor_final/
├── CHANGES_frontend_backend_wiring.md  (بخش ۹ جدید — v4 auth merge)
├── WORKLOG_v23_fixes.md                (از v2)
├── WORKLOG_v3_charts_trades.md         (از v3)
├── WORKLOG_v4_auth_merge.md            (این فایل)
├── README.md
├── .env.example
├── .gitignore
├── .github/workflows/ci.yml
├── docker-compose.yml
├── backend/                            (بدون تغییر نسبت به v3)
│   ├── conftest.py
│   ├── requirements.txt
│   ├── requirements-dev.txt
│   ├── reporting/chart_data.py         (از v3)
│   ├── api/
│   │   ├── exceptions.py               (ValidationError از v3)
│   │   ├── models/analysis.py          (charts field از v3)
│   │   └── routers/analyses.py         (charts + /trades از v3)
│   ├── auth/                           (دست‌نخورده)
│   ├── tests/                          (دست‌نخورده — ۲۴۱ تست)
│   └── ...
├── frontend/
│   ├── package.json                    (حذف ۵ dep + ۶ script)
│   ├── vitest.config.ts                (از v2)
│   ├── vitest.setup.ts                 (از v2)
│   ├── eslint.config.mjs               (از v2)
│   ├── .env.example                    (بازنویسی — v4)
│   ├── .env.local.example              (بازنویسی — v4)
│   └── src/
│       ├── app/
│       │   ├── page.tsx                (session check → /api/v1/auth/session)
│       │   └── api/
│       │       ├── v1/
│       │       │   ├── analyses/       (دست‌نخورده از v3)
│       │       │   ├── auth/           (۹ route جدید — v4)
│       │       │   │   ├── login/
│       │       │   │   ├── logout/
│       │       │   │   ├── password-reset/{request,confirm}/
│       │       │   │   ├── refresh/
│       │       │   │   ├── register/
│       │       │   │   ├── resend-verification/
│       │       │   │   ├── session/
│       │       │   │   └── verify-email/
│       │       │   ├── me/             (۳ route جدید — v4)
│       │       │   │   ├── activity/
│       │       │   │   ├── password/
│       │       │   │   └── route.ts
│       │       │   └── ... (health, config, history, uploads, workspace — دست‌نخورده)
│       │       └── (auth/ حذف شد)
│       ├── lib/
│       │   ├── store/auth-store.ts     (بازنویسی — حذف sessionToken)
│       │   ├── server/
│       │   │   ├── auth-cookies.ts     (جدید — v4)
│       │   │   ├── backend-auth-bridge.ts (بازنویسی — ساده‌سازی)
│       │   │   ├── backend-config.ts   (بازنویسی — حذف BRIDGE_SECRET validation)
│       │   │   ├── backend-proxy.ts    (تغییر — resolveAuth ساده‌تر)
│       │   │   └── session.ts          (بازنویسی — حذف Prisma)
│       │   ├── api/index.ts            (دست‌نخورده از v3)
│       │   ├── hooks/                  (دست‌نخورده — use-analysis-report, use-history, use-trades)
│       │   └── (db.ts, auth/ حذف شد)
│       ├── views/
│       │   ├── auth/index.tsx          (تغییرات گسترده — مهاجرت به /api/v1/auth/* و /api/v1/me/*)
│       │   ├── charts.tsx              (دست‌نخورده از v3)
│       │   ├── trade-explorer.tsx      (دست‌نخورده از v3)
│       │   └── ... (سایر views دست‌نخورده)
│       └── components/                 (دست‌نخورده)
└── ... (deploy, docker, docs, scripts — دست‌نخورده)
```

---

## ۹. توصیه‌های بعدی

1. **تست E2E auth flow**: افزودن playwright test که login → dashboard → logout → redirect to login را تست کند.
2. **Refresh token rotation در apiClient**: افزودن interceptor که روی 401، `/api/v1/auth/refresh` را صدا بزند و request را retry کند.
3. **حذف BRIDGE_SECRET از env files**: در یک PR جداگانه، تمام ارجاعات به TRADING_DOCTOR_BRIDGE_SECRET را از docs و env examples حذف کنید (فعلاً به‌عنوان deprecated نگه داشته شد).
4. **Avatar endpoint در backend**: اگر avatar upload لازم است، `POST /me/avatar` را در `auth/routers/me.py` اضافه کنید و سپس route در `/api/v1/me/avatar` بسازید.
5. **Session revocation endpoint**: اگر کاربر بخواهد جلسات دیگر را ببندد بدون تغییر رمز، `POST /me/revoke-sessions` در backend اضافه کنید.
