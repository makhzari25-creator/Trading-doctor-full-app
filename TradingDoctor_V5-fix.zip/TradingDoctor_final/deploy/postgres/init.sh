#!/bin/sh
# =============================================================================
# PostgreSQL init script — runs once on first DB container start.
# =============================================================================
# Creates the database with UTF8 + en_US.UTF8 collation (Persian-safe).
# Phase 8 will add extension setup via Alembic migrations.
# =============================================================================

set -e

echo "[init.sh] Setting up TradingDoctor database..."

# The default POSTGRES_DB is already created by the entrypoint;
# we just ensure the encoding is correct (the official image uses
# the locale of the container, which is C.UTF-8 on alpine — fine for Persian).

# Enable pgcrypto extension (provides gen_random_uuid used by UUID PKs).
# This is idempotent; safe to call multiple times.
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS pgcrypto;
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
EOSQL

echo "[init.sh] Done. pgcrypto + uuid-ossp extensions enabled."
