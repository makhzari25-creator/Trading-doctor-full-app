# Developer Guide

Day-to-day workflows for someone actively working in this codebase.

## Running the test suite

```bash
pytest tests/ -q                    # everything (48 tests)
pytest tests/test_pipeline.py -v    # just Phase 1 engine smoke tests
pytest tests/test_api.py -v         # just Phase 3 API tests
```

The suite is organized by phase/concern, not by mirroring the source
tree exactly:

| File | Covers |
|---|---|
| `test_pipeline.py` | End-to-end smoke test: file → full analysis, no LLM |
| `test_validation.py` | Every fatal/non-fatal data-validation path |
| `test_file_loader.py` | Format parsing edge cases (empty file, bad delimiter, corrupt Excel/JSON) |
| `test_sequence_analysis.py` | Proves the vectorized streak logic is bit-identical to the original loop (100 randomized trials + explicit edge cases) |
| `test_reporting.py` | All 15 HTML sections present, PDF validity, edge-case datasets (single trade, all-wins, etc.) |
| `test_api.py` | Full HTTP flow, error envelopes, auth, rate limiting, store eviction, static "no business logic in API" check |

## Adding a new behavioral signal to the engine

This is the most consequential kind of change — it affects every
consumer simultaneously (see `docs/01_ARCHITECTURE.md`'s worked example).

1. Implement the raw detection in `engines/behavior_engine.py` (or reuse
   `utils/sequence_analysis.py` if it's a streak/mask pattern — don't
   hand-roll another loop; see `CHANGELOG_V23.md` for why that was
   consolidated).
2. If it should surface with $ context, add a `ContextBlock` in
   `engines/score_engine.py::ScoreEngine`.
3. If it should generate user-facing evidence, add an `EvidenceType` and
   a builder method in `engines/evidence_engine.py`.
4. If it should influence the diagnosis, update
   `engines/diagnosis_engine.py::DiagnosisEngine.diagnose()`.
5. Add a test proving the new score/evidence is produced correctly —
   ideally with a hand-constructed DataFrame where you know the expected
   output, not just "it doesn't crash."
6. **Do not** add any rendering/formatting logic in the same change —
   `reporting/` and `api/` pick up new engine output automatically as
   long as it's in `FullResult`/`coach`; touching those layers for a pure
   engine change is a sign the boundary is being crossed.

## Adding a new report section

1. Add the data to `reporting/data_context.py::build_report_context()` —
   read-only extraction from `FullResult`/`coach`, no new computation.
2. Add `templates/partials/_your_section.html` and an
   `{% include %}` line in `templates/report.html`.
3. Add the equivalent block to `reporting/pdf_report.py::render_pdf_report()`
   — remember to wrap any Persian text in `_rtl()` (see the large comment
   block at the top of that file for why, and `_b()` for bold fragments).
4. Update the section-ID list in `tests/test_reporting.py` and the count
   assertion in `tests/test_api.py::test_full_flow_upload_analyze_report_history`.
5. If it's a new chart, add it to `reporting/charts.py` — return raw PNG
   bytes, call it from `build_all_charts()` so both renderers get it
   automatically. Keep it inside the `_MPL_LOCK` in `build_all_charts` if
   you add a new call site (matplotlib.pyplot's global state isn't
   thread-safe — see the comment there).

## Adding a new REST endpoint

1. Add/extend a Pydantic model in `api/models/`.
2. Add the route in the relevant `api/routers/*.py` file (or create a new
   router + register it in `api/main.py`).
3. Route handlers should call `api/services/store.py` (or `core.service`/
   `reporting` directly for stateless operations) — never an engine class
   directly. `tests/test_api.py::test_no_business_logic_duplicated_in_api_layer`
   will fail the build if you do.
4. If the work is CPU-bound (calls into the engine or reporting), wrap it
   in `starlette.concurrency.run_in_threadpool` so the event loop stays
   responsive — see `api/routers/analyses.py` for the pattern.
5. Add `dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)]`
   at the router level unless the endpoint is meant to be public (like
   `health`/`config`).
6. Raise an `APIError` subclass from `api/exceptions.py` for expected
   error conditions (or add a new subclass) — don't return ad-hoc
   `JSONResponse`s, or the unified error envelope breaks.
7. Add a test in `tests/test_api.py` covering both the success path and
   at least one error path.

## Working with LLM providers

`llm/provider.py::get_llm(name)` is the only factory function consumers
should call. Adding a fourth provider: implement `BaseLLMProvider`'s
`chat()` method in a new file under `llm/`, register it in
`get_llm()`'s branch, add its API key/model env vars to `config.py`. The
provider must never be called anywhere except `engines/coaching_engine.py`
— if you find yourself calling an LLM provider from `reporting/` or
`api/`, stop; that's a sign the "AI is coaching-only, never analytical"
boundary is being violated (see `docs/01_ARCHITECTURE.md`).

## Debugging a discrepancy between the UI, PDF, and API for the same file

Given the shared-source-of-truth architecture, this *shouldn't* happen —
if it does, it's a high-priority bug, not a display quirk. Diagnostic
steps:

1. Confirm all three are actually looking at the same `FullResult`
   (same `analysis_id` / same uploaded file, not a stale cached one —
   check `pages/08_Report.py`'s session-state cache key, and the API
   store's `analysis_id`).
2. Check `reporting/data_context.py` for anything computed there
   (strengths/weaknesses bucketing, formatted strings) rather than read
   directly from the engine — a bug in that presentational logic is the
   most likely source of a real discrepancy, since it's the one place
   values get reshaped before display.
3. Run `tests/test_reporting.py::test_html_and_pdf_share_identical_headline_numbers`
   locally against the specific input file to isolate HTML vs. PDF vs.
   engine.

## Style/tooling notes

- No formatter/linter is currently enforced in CI (there is no CI
  pipeline yet — see `docs/13_FUTURE_EXTENSIONS.md`). Match the
  surrounding file's style; see `docs/10_CODING_STANDARDS.md`.
- Persian comments are used throughout for explanations aimed at the
  original maintainers; English is used for section headers, docstrings
  intended as an external reference, and all identifier names. New
  contributions can use either for comments — consistency within a file
  matters more than a global rule.
