# Trading Doctor API — Documentation (Phase 3)

Base URL: `http://<host>:<port>/api/v1`
Interactive docs: `/docs` (Swagger UI), `/redoc` (ReDoc), `/openapi.json` (raw spec)

## Architecture

```
api/
├── main.py            FastAPI app factory: middleware, centralized exception
│                        handlers, router mounting, CORS
├── config.py            API-only settings (auth, rate limits, upload size,
│                        store bounds, CORS) — separate from engine config.py
├── dependencies.py        Shared dependencies: auth (verify_api_key), rate
│                        limiting (enforce_rate_limit), store access
├── exceptions.py           APIError hierarchy — declarative status_code +
│                        error_code per exception type
├── models/                  Pydantic request/response schemas
│   ├── common.py              ErrorResponse, HealthResponse, ConfigResponse
│   ├── uploads.py              UploadResponse
│   └── analysis.py              AnalysisRequest/Summary/Report, History*
├── services/
│   └── store.py                In-memory, thread-safe, size-bounded store.
│                              The ONLY module that calls the analytical
│                              engine (core.service.analyze_dataframe)
└── routers/
    ├── health.py, config.py     Public, unauthenticated, unrated
    └── uploads.py, analyses.py, reports.py, history.py
                                  Authenticated + rate-limited
```

**The analytical engine is untouched and independent.** Every router calls
`core.service.analyze_dataframe` (Phase 1) or `reporting.generate_*_report`
(Phase 2) exactly as `main.py`/`pages/*.py` already do — no scoring,
diagnosis, or validation logic is duplicated or reimplemented in `api/`.
This is enforced by an automated test
(`test_no_business_logic_duplicated_in_api_layer`) that fails the build if
any `api/` file imports an engine class directly.

## Versioning

URL path versioning: `/api/v1/...`. A future breaking change ships as
`/api/v2/...` alongside v1 — routers are self-contained modules, so this is
additive, not a rewrite.

## Authentication

Disabled by default (`AUTH_ENABLED = len(API_KEYS) > 0`). Set
`TRADING_DOCTOR_API_KEYS=key1,key2` to enable — no code change needed.

When enabled, send `X-API-Key: <key>` on every request to `uploads`,
`analyses`, `reports`, and `history` endpoints. `health` and `config` are
always public (standard practice for liveness probes / pre-flight checks).
Missing/invalid key → `401` in the standard error envelope (see below).

The scheme is registered as a proper OpenAPI `apiKey` security scheme
(visible as the "Authorize" button in `/docs`), not just an undocumented
header.

## Rate limiting

In-memory sliding-window limiter, default 60 requests/minute per client
(keyed by `X-API-Key` if present, else client IP). Configurable via
`TRADING_DOCTOR_API_RATE_LIMIT_RPM`. Exceeding it returns `429` in the
standard error envelope. `health`/`config` are exempt.

*Scaling note:* the default limiter is a single-process in-memory
structure — correct for one instance, not shared across replicas. The
limiter is accessed through one function (`enforce_rate_limit`), so
swapping in a Redis-backed limiter for multi-instance deployment touches
one file, not every route.

## Async execution

Endpoints are `async def`, but the actual analysis and report generation
are CPU-bound (pandas/numpy/matplotlib), not I/O-bound. Blocking the event
loop with them would stall *every other* concurrent request (health checks
included). All CPU-bound engine/reporting calls run via
`starlette.concurrency.run_in_threadpool`, so the event loop stays free.

**What this does and does not give you** (verified empirically, not
assumed): it keeps the server *responsive* — a `GET /health` fired while a
heavy analysis is in flight still returns in single-digit milliseconds
instead of queuing behind the analysis. It does **not** make multiple
concurrent CPU-bound analyses run faster in parallel — Python's GIL
prevents true CPU parallelism across threads regardless of the machine's
core count, and on a single-core host, concurrent threaded CPU work can
even be *slower* than sequential due to thread-switching overhead (both
measured directly on this deployment target: 4 concurrent 40k-row analyses
took 2.06s wall-clock vs. 1.19s run sequentially — a 0.58x "speedup").

For real horizontal scaling of CPU-bound analysis throughput, run multiple
worker **processes** (the standard FastAPI/uvicorn production pattern:
`uvicorn api.main:app --workers 4`, or Gunicorn with uvicorn workers) —
each process has its own GIL, so this is where actual parallelism comes
from, not from `async`/threading within one process. This is orthogonal to
everything else in this document; no code changes needed to add it.

## Standard error envelope

Every error response — from FastAPI's own request validation, from the
engine (`DataValidationError`, `UnsupportedFileError`), from the reporting
module (`ReportRenderError`), or unexpected server errors — is normalized
to the same shape:

```json
{
  "error": {
    "code": "not_found",
    "message": "تحلیلی با شناسه‌ی «...» یافت نشد.",
    "details": {}
  }
}
```

No raw Python traceback is ever returned to a client; full tracebacks are
logged server-side only (`utils/logger.py`, consistent with Phase 1/2).

## Logging

Every request is logged with a short request ID (also returned as the
`X-Request-ID` response header), method, path, status code, and duration —
useful for correlating a client-reported issue with server logs.

## Endpoints

### `GET /api/v1/health`
Liveness/readiness probe. No auth, no rate limit.
```json
{"status": "ok", "version": "1.0.0", "engine_ready": true, "timestamp": "..."}
```

### `GET /api/v1/config`
Non-secret configuration a client needs before uploading (max size, allowed
types, available LLM providers, whether auth/rate-limiting are on). Never
includes API keys or disk paths.

### `POST /api/v1/uploads`
Multipart file upload (`file` field). Stores the file; does **not** run
analysis. Returns `201` + `upload_id`. `413` if over the size limit.

### `POST /api/v1/analyses`
Body: `{"upload_id": "...", "llm_provider": "none"}` (`llm_provider` one of
`gemini`/`openai`/`claude`/`none`; API defaults to `none` deliberately, so
an external LLM call — cost/latency — only happens on explicit request).
Runs the full Phase-1 engine pipeline in a thread pool. Returns `201` +
an `AnalysisSummary`. `404` if `upload_id` doesn't exist; `422` if the
file's *content* fails Phase-1 validation (no recognizable trading data).

### `GET /api/v1/analyses/{analysis_id}`
Same `AnalysisSummary` shape, for polling/retrieval later. `404` if unknown
or evicted (see Store limits, below).

### `GET /api/v1/analyses/{analysis_id}/report`
Full structured JSON report — the same `data_context.py` object that
Phase 2's HTML/PDF renderers consume, minus the embedded chart images
(lighter for programmatic consumption). Guaranteed to match the HTML/PDF
numbers exactly, since all three read the same underlying object.

### `GET /api/v1/analyses/{analysis_id}/report.html`
Full self-contained HTML report (Phase 2, byte-for-byte the same renderer
used by the Streamlit app and CLI).

### `GET /api/v1/analyses/{analysis_id}/report.pdf`
Full PDF report (Phase 2 reportlab renderer, correct Persian text
rendering). Returned as `application/pdf` with a `Content-Disposition`
attachment header.

### `GET /api/v1/history?page=1&page_size=20`
Paginated list of past analyses, newest first. `page_size` capped at 100.

## Store limits (operational, not business logic)

The in-memory store is bounded to prevent unbounded memory/disk growth on
a long-running server:
- `TRADING_DOCTOR_API_MAX_ANALYSES` (default 500) — oldest analysis
  records (which hold a full DataFrame + result in memory) are evicted
  once this is exceeded.
- `TRADING_DOCTOR_API_MAX_UPLOADS` (default 1000) — oldest raw upload
  files on disk are deleted once this is exceeded.

This is a real, tested behavior (`test_store_eviction_bounds_memory`), not
just a config knob — found and fixed during this phase's self-review.

## Configuration reference (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_KEYS` | *(empty → auth disabled)* | Comma-separated valid API keys |
| `TRADING_DOCTOR_API_RATE_LIMIT_ENABLED` | `true` | Toggle rate limiting |
| `TRADING_DOCTOR_API_RATE_LIMIT_RPM` | `60` | Requests/minute/client |
| `TRADING_DOCTOR_API_MAX_UPLOAD_MB` | `25` | Max upload size |
| `TRADING_DOCTOR_API_MAX_ANALYSES` | `500` | In-memory analysis record cap |
| `TRADING_DOCTOR_API_MAX_UPLOADS` | `1000` | On-disk upload file cap |
| `TRADING_DOCTOR_API_CORS_ORIGINS` | `*` | Comma-separated allowed origins |
| `TRADING_DOCTOR_API_HISTORY_PAGE_SIZE` | `20` | Default page size |

Engine-level variables (`GEMINI_API_KEY`, `TRADING_DOCTOR_LLM_*`, etc.) are
unchanged from Phase 1 — the API layer doesn't introduce new engine config.

## Running it

```bash
pip install -r requirements.txt
uvicorn api.main:app --host 0.0.0.0 --port 8000
# Swagger UI: http://localhost:8000/docs
```

## Example: full flow with curl

```bash
UPLOAD_ID=$(curl -s -X POST http://localhost:8000/api/v1/uploads \
  -F "file=@trades.csv" | python3 -c "import json,sys;print(json.load(sys.stdin)['upload_id'])")

ANALYSIS_ID=$(curl -s -X POST http://localhost:8000/api/v1/analyses \
  -H "Content-Type: application/json" \
  -d "{\"upload_id\":\"$UPLOAD_ID\",\"llm_provider\":\"none\"}" \
  | python3 -c "import json,sys;print(json.load(sys.stdin)['analysis_id'])")

curl http://localhost:8000/api/v1/analyses/$ANALYSIS_ID/report
curl http://localhost:8000/api/v1/analyses/$ANALYSIS_ID/report.pdf -o report.pdf
```

## Known limitations / future extension points

- **Store is in-process memory + local disk.** Restarting the process
  loses analysis history (raw uploads persist on disk but aren't
  reattached). For multi-instance/production deployment, swap
  `api/services/store.py`'s backing dict for Redis (sessions) and/or
  Postgres (permanent history) — every consumer goes through this one
  class, so no router or Pydantic model needs to change.
- **Rate limiter is per-process.** Fine for one instance; needs a shared
  backend (Redis) for horizontally-scaled deployments — same one-file
  swap point (`api/dependencies.py`).
- **Auth is a single shared-secret API key, not per-user tokens/OAuth.**
  Sufficient for service-to-service or trusted-frontend use; a real
  multi-tenant product would want JWT/OAuth2, which fits into the same
  `Depends()` pattern already in place.
- **No async job queue.** `POST /analyses` runs synchronously (in a
  thread pool) and returns the completed result — appropriate given the
  engine's actual performance (~1s even at 25,000 trades, measured in
  Phase 2). A truly async job-polling model (`202 Accepted` + `GET` for
  status) would be worth adding if very large files or slow LLM calls
  become common.
