# Coding Standards

These are the conventions this codebase actually follows (verifiable in
the source), not an aspirational style guide. Match them.

## Language: comments vs. identifiers

- **All identifiers (function/class/variable names) are English.**
- **Comments and docstrings are predominantly Persian**, aimed at the
  original maintainers, especially where they explain *why* something
  non-obvious was done (e.g. `# [AUDIT FIX] ...` comments throughout the
  codebase explain a specific bug that was found and fixed — these are
  historically valuable, don't delete them when refactoring nearby code).
- New contributions may comment in either language; consistency *within
  a file* matters more than a global rule. English is preferred for
  anything meant to be a durable external reference (this `docs/` folder,
  `API_DOCUMENTATION.md`).

## Error handling

- **Never let a raw Python traceback reach an end user** — not in the
  Streamlit UI, not in CLI stdout, not in an HTTP response. Catch
  specific exceptions, log the full traceback via `utils.logger.get_logger`,
  show a clear, translated, non-technical message externally. This is the
  single most consistently enforced rule in the codebase — see
  `api/exceptions.py`'s `handle_unexpected_error`,
  `reporting/*.py`'s `ReportRenderError` wrapping, and every `try/except`
  in `main.py`/`app.py`.
- Raise specific exception types, not bare `Exception`. Each layer has
  its own vocabulary: `utils.validation.DataValidationError` (data
  content), `utils.file_loader.UnsupportedFileError` (format),
  `reporting.ReportRenderError` (rendering), `api.exceptions.APIError`
  subclasses (HTTP-mapped). Adding a new failure mode almost always means
  adding a new specific exception class, not reusing an unrelated one.
- Never swallow an exception silently (`except Exception: pass`). If a
  failure is genuinely recoverable and shouldn't block the whole
  operation (e.g. one evidence builder failing shouldn't kill the whole
  analysis), catch it narrowly, `log.warning(..., exc_info=True)`, and
  continue — see `engines/evidence_engine.py`'s per-builder exception
  handling for the pattern.

## Validation

- Validate **at the boundary**, not deep inside business logic.
  `utils.validation.validate_and_normalize` runs once, right after file
  loading, before any engine touches the data. Pydantic models validate
  API request shape at the router boundary, before a handler body runs.
- Prefer collecting non-fatal issues as warnings (surfaced to the user)
  over silently dropping/mutating data. See
  `utils.validation.DataValidationError` vs. the non-fatal warnings list
  it also returns — both exist, and using the right one matters (a
  missing Profit column is fatal; a few duplicate rows are a warning).

## Logging

- Always via `utils.logger.get_logger(__name__)` — never `print()` in
  library code (CLI user-facing output in `main.py` is the one
  legitimate exception — that's an intentional UI, not debug output).
- Log levels: `INFO` for normal lifecycle events (analysis started/
  finished, report rendered), `WARNING` for recoverable issues (LLM
  unavailable, evidence builder failed), `ERROR` with `exc_info=True` for
  anything that resulted in a user-facing failure.
- **Never log secrets** (API keys) or full user data (raw trade contents,
  full LLM prompts/responses) — log metadata about them instead (provider
  name, prompt message count, response length). See
  `engines/coaching_engine.py`'s LLM logging for the pattern.

## Testing

- Every bug fix gets a regression test in the same change, named so a
  future reader understands *why* it exists, not just what it asserts —
  see `tests/test_reporting.py`'s and `tests/test_api.py`'s docstrings
  for the pattern (many literally say "regression test — real bug found
  during self-review").
- Prefer testing behavior through the public entry point
  (`core.service.analyze_dataframe`, `reporting.generate_html_report`,
  FastAPI's `TestClient`) over reaching into engine internals — this
  catches integration issues the unit-level view would miss (several real
  bugs in this project were only caught this way; see
  `CHANGELOG_V23_PHASE2.md` and the Phase 2/3 self-reviews).
- When optimizing/refactoring numeric logic (e.g. vectorizing a loop),
  prove equivalence with a randomized-trial test against the original
  implementation before deleting it — see
  `tests/test_sequence_analysis.py` for the template (100 random trials
  + explicit edge cases).

## Architectural boundaries (see `docs/01_ARCHITECTURE.md` for the "why")

- `reporting/` and `api/` never compute a score, threshold, or diagnosis
  — they only read `FullResult`/`coach` and reformat it. If you're
  writing something that looks like `if metric > threshold` in either
  package, stop and check whether that logic belongs in an engine.
- `api/` only touches the engine through `api/services/store.py`.
- LLM providers are only invoked from `engines/coaching_engine.py`.
- Shared logic used by more than one engine goes in `utils/`, not
  copy-pasted — `utils/sequence_analysis.py` exists specifically because
  the alternative (three copies of the same loop) caused a real bug risk;
  see `CHANGELOG_V23.md`.

## Performance

- Prefer vectorized pandas/numpy operations over explicit Python loops
  for anything that runs per-row — not a blanket rule ("premature
  optimization"), but this codebase specifically had real duplicated
  Python loops consolidated into one vectorized, tested implementation
  (`utils/sequence_analysis.py`) because it was both a maintainability
  and performance problem. If you're about to write a `for i in
  range(len(df))` loop, check whether `utils/sequence_analysis.py`
  already solves your problem, or whether it should be extended to.
- Chart/report generation should scale to realistic large inputs (tens of
  thousands of trades) without pagination-breaking output size — verified
  in Phase 2 up to 25,000 rows in ~1 second. If adding a new chart or
  table, avoid anything whose output size grows unbounded with row count
  (e.g. a per-trade table) — cap it or aggregate, per the Technical
  Appendix's documented "summary, not a per-trade dump" design decision.

## What NOT to do (real mistakes found and fixed in this codebase — don't repeat them)

- Don't reassign a shared module-level singleton directly in a test
  without `monkeypatch.setattr` — it won't be restored, and will leak
  into later tests (a real bug found in this project's own Phase 3 test
  suite).
- Don't catch `FileNotFoundError` broadly across two unrelated failure
  modes (missing input file vs. missing output directory) — catch each
  specifically, or the error message will blame the wrong thing (a real
  bug found in `main.py`'s CLI export flags).
- Don't assume a font supports every character you're rendering — verify
  glyph coverage, especially for non-Latin scripts (a real, severe bug in
  the PDF renderer — see `reporting/pdf_report.py`'s module docstring).
