# Deployment Guide

This covers deploying the REST API (`api/`) as the primary production
surface. The Streamlit app is typically deployed separately (e.g.
Streamlit Community Cloud, or as its own container) and isn't the focus
here since it has no non-standard deployment requirements — `streamlit run
app.py` on whatever host runs it.

## Production launch command

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8000 --workers 4
```

**Why `--workers 4` matters — read this before deploying.** The API's
async endpoints correctly keep the event loop responsive under load (a
health check stays fast even while a heavy analysis runs — verified
empirically, see the Phase 3 self-review), but Python's GIL means a
*single process* cannot run multiple CPU-bound analyses in true parallel,
no matter how many threads it uses. Measured directly: 4 concurrent
40,000-row analyses in one process took *longer* wall-clock than running
them one at a time (2.06s vs. 1.19s — a 0.58x "speedup"). Real throughput
scaling comes from multiple **processes** (`--workers N`, or Gunicorn with
uvicorn workers), each with its own GIL. This is standard FastAPI/uvicorn
practice, not specific to this app — but it matters more here than in a
typical I/O-bound API because this one does real CPU work per request.

## What multi-worker deployment changes (read before scaling out)

`api/services/store.py` (analysis history) and `api/dependencies.py`
(rate limiter) are both **in-process, in-memory** by design for Phase 3.
With `--workers N > 1`, each worker process gets its **own independent**
copy of both:

- A client's `GET /api/v1/analyses/{id}` might hit a different worker than
  the one that ran `POST /api/v1/analyses` and 404 even though the
  analysis exists (on another worker).
- Rate limits apply per-worker, not globally — a client could get up to
  `N × limit` requests/minute across all workers combined.

**This is a known, documented limitation** (see
`API_DOCUMENTATION.md` → "Known limitations" and
`docs/13_FUTURE_EXTENSIONS.md`), not an oversight. If you need multi-worker
deployment with correct shared state, the fix is localized:

1. Swap `api/services/store.py`'s backing dict for Redis (short-lived
   session data) or Postgres (permanent history) — every router already
   goes through this one class, so no router or Pydantic model changes.
2. Swap the rate limiter in `api/dependencies.py` for a Redis-backed
   sliding window — same single-file swap point.

Until that's done, either run a single worker, or accept the
per-worker-state caveat (fine for many real deployments — e.g. if a
load balancer uses sticky sessions, or if slightly-generous rate limits
across workers are acceptable).

## Environment variables required in production

At minimum, set:

```bash
export TRADING_DOCTOR_API_KEYS="prod-key-1,prod-key-2"   # enables auth
export TRADING_DOCTOR_API_CORS_ORIGINS="https://your-frontend.example.com"
```

Without `TRADING_DOCTOR_API_KEYS` set, the API runs with **auth
disabled** — fine for local development, not for a public deployment. See
`docs/05_CONFIGURATION.md` for the complete variable reference, including
LLM keys if AI coaching text is wanted.

## Reverse proxy / load balancer considerations

The rate limiter keys unauthenticated requests by `request.client.host`.
Behind a reverse proxy or load balancer that doesn't forward the real
client IP (no `X-Forwarded-For` handling), this can bucket *all* users
behind the proxy as one client. If deploying behind nginx/ALB/etc.,
either configure the proxy to preserve the real client IP, or require API
keys (`TRADING_DOCTOR_API_KEYS`) so the limiter keys by key instead of IP.

## Health checks

`GET /api/v1/health` is unauthenticated and unrated by design — safe to
use as a Kubernetes liveness/readiness probe or load-balancer health
check without needing credentials or worrying about it consuming a
client's rate-limit budget.

## Data persistence and cleanup

- Uploaded files are written to `api/config.API_DATA_DIR/uploads/` and
  bounded by `TRADING_DOCTOR_API_MAX_UPLOADS` (oldest deleted on overflow).
- Analysis records (including the full trade DataFrame) are held in
  memory, bounded by `TRADING_DOCTOR_API_MAX_ANALYSES`.
- **Restarting the process loses all analysis history** (uploads persist
  on disk but aren't reattached to any analysis). This is expected given
  the in-memory store — see the store-swap note above if persistent
  history across restarts is required.
- No TTL-based cleanup exists yet, only count-based bounds — a very old
  but under-the-cap record stays indefinitely. Documented in
  `docs/13_FUTURE_EXTENSIONS.md`.

## Logging in production

`utils/logger.py` writes to both console (stderr) and a rotating file
(`reports/trading_doctor.log`, 5MB × 3 backups). In a containerized
deployment, prefer capturing stderr via your container platform's log
driver — the file handler is a best-effort convenience for local/VM
deployments and is skipped silently if the `reports/` directory isn't
writable (won't crash the app either way).

Set verbosity via `TRADING_DOCTOR_LOG_LEVEL` (`DEBUG`/`INFO`/`WARNING`/
`ERROR`, default `INFO`).

## Deploying behind HTTPS

Nothing in this codebase terminates TLS — put it behind a reverse proxy
(nginx, Caddy, a cloud load balancer) that does. No application-level
changes needed.

## Container deployment (Dockerfile not included — here's the shape)

There's no `Dockerfile` in this repository yet (see
`docs/13_FUTURE_EXTENSIONS.md`). A minimal one would look like:

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "api.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
```

No system packages (like `wkhtmltopdf`) are needed in the image — this
was a deliberate Phase 2 design goal (see `CHANGELOG_V23_PHASE2.md`),
specifically so a minimal Python base image is sufficient.
