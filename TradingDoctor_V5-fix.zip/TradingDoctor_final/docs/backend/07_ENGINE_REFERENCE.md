# Engine Reference

Every important class and function in the analytical core, the reporting
module, and the API layer. This is the ground-truth reference — generated
from and cross-checked against the actual source (not written from memory
alone), so signatures here should match the code exactly. If they ever
drift, the code is correct and this file needs updating.

Convention used below: **what it does** / **who calls it** / **what it
must never do**. That third point matters most in this codebase — see
`docs/01_ARCHITECTURE.md`.

---

## `core/service.py` — the single entry point

### `analyze_dataframe(df: pd.DataFrame, llm_provider: str = "gemini") -> (doctor, result, coach)`

The one function every consumer (Streamlit, CLI, API) calls to run the
complete pipeline. Internally: validates the DataFrame
(`utils.validation.validate_and_normalize`), builds a `BehaviorEngine`,
runs `ScoreEngine.run()` to get a `FullResult`, then
`CoachingEngine.generate()` for the `coach` dict. Attaches
`doctor.data_quality_warnings` (non-fatal warnings from validation) for
consumers to surface. Never call the engines directly — always through
this function, so validation and warning-collection can't accidentally be
skipped by a new consumer.

### `analyze_file(file, filename: str = None, llm_provider: str = "gemini") -> (doctor, result, coach)`

Same as above, but takes a raw file (path, or file-like object — e.g. a
Streamlit `UploadedFile` or an API `UploadFile`'s stream) and loads it
first via `utils.file_loader.load_any_file`. This is what `main.py`
(CLI) and `api/services/store.py` call; `pages/*.py` (Streamlit) and
tests call `analyze_dataframe` directly when they already have a
DataFrame.

---

## `engines/behavior_engine.py` — raw behavioral scores

### `class BehaviorResult`
Plain data container: `behavior_profile` (dict — revenge trade count,
main problem label), `scores` (dict of the 5 named scores below),
`detected_patterns` (list of human-readable pattern strings),
`explanations` (dict), `what_if` (dict — revenge-trading simulation).

### `class BehaviorEngine`
> "موتور تحلیل رفتار معاملاتی" — the core behavioral scoring engine.

- **`__init__(self, df: pd.DataFrame)`** — stores the DataFrame via the
  `df` property (see below).
- **`df` (property, getter/setter)** — setting `.df` automatically calls
  `invalidate_cache()`. This exists because several score methods are
  expensive to recompute; the cache is keyed to the exact DataFrame
  currently assigned.
- **`invalidate_cache(self)`** — clears cached scores. Called
  automatically by the `df` setter; you should never need to call it
  directly unless you're mutating the DataFrame in place (avoid doing
  that — reassign `.df` instead, so the cache stays consistent).
- **`revenge_analysis(self)`** — detects revenge trading: ≥2 consecutive
  losses, immediately followed by another loss with an escalated size
  (>1.05× the previous trade). Vectorized via
  `utils.sequence_analysis.consecutive_streak`/`size_increased_mask` —
  **do not** reimplement this loop; three other places in the codebase
  used to have their own copy and it was a real, fixed maintainability
  bug (see `CHANGELOG_V23.md`).
- **`overtrading_score(self) -> float`** — fraction of days with more
  than 5 trades.
- **`risk_taking_score(self) -> float`** — fraction of trades with size
  >1.5× the average.
- **`patience_score(self) -> float`** — based on time gaps between
  trades (quick re-entries after a loss/win signal impatience/FOMO).
- **`discipline_score(self) -> float`** — the composite "Overall Trading
  Score" shown everywhere in the UI/reports: 40% revenge + 25%
  overtrading + 15% patience + 20% risk-taking (inverted — higher
  discipline is better, unlike the other four scores where higher is
  worse). **This is the single most externally-visible number in the
  product** — see it live as "Overall Trading Score" in every report
  section.
- **`build_behavior_engine(self) -> BehaviorResult`** — runs everything
  above and packages the result. Called once per analysis by
  `ScoreEngine.run()` — never call the individual score methods directly
  from outside this engine; go through `build_behavior_engine()` (or
  `core.service.analyze_dataframe`, one level up) so scores stay
  internally consistent with each other.

**Must never do**: read `config.py`'s "future use" threshold constants
(`OVERTRADING_TRADES_PER_DAY`, `RISK_SIZE_MULTIPLIER`,
`PATIENCE_QUICK_REENTRY_MINUTES`) — as documented in
`docs/05_CONFIGURATION.md`, these aren't wired in; the literal values
above are hardcoded. Don't assume changing the config constant changes
behavior here without also updating this file.

---

## `engines/score_engine.py` — adds $ context and trends

### `class ContextBlock`
Plain data container attached to each behavioral score: `score`,
`severity` (`Low`/`Medium`/`High`/`Critical`), `event_count`,
`dollars_lost`, `pct_of_total_profit`, `insight` (human-readable
sentence). This is what `reporting/data_context.py` iterates over to
build the "Behavior Analysis" report table and the Strengths/Weaknesses
bucketing.

### `class ScoreEngine`
> Enriches each `BehaviorEngine` score with real financial context.

- **`__init__(self, doctor: BehaviorEngine)`**
- **`run(self)`** — the full pipeline for one analysis: builds
  `BehaviorResult`, wraps each score in a `ContextBlock`, computes
  `performance` (win rate, profit factor, drawdown, streaks — see
  `AnalysisSummary`/report "Trade Statistics"/"Performance Metrics"
  sections), computes `edge_map` (best/worst hour, weekday, strategy),
  and returns a `FullResult` (defined in `engines/report_engine.py`).
  **This is the function `core.service.analyze_dataframe` calls** — the
  true top-level entry point into the analytical engine.

### `class TrendEngine`
> Historical trend of behavioral scores over time — separate from
> `ScoreEngine`, which is a single-snapshot analysis.

- **`__init__(self, raw_df: pd.DataFrame)`**
- **`compute(self, granularity: str = "week", mode: str = "independent") -> List[dict]`**
  — time-ordered list of `{period, scores...}` dicts. `granularity` is
  `"week"` or `"month"`. Used by `pages/09_Trends.py`; not currently
  exposed via the REST API (see `docs/13_FUTURE_EXTENSIONS.md`).
- **`compute_both_granularities(self, mode: str = "independent") -> dict`**
  — convenience wrapper returning both weekly and monthly trends in one
  call.

---

## `engines/evidence_engine.py` — explainable, prioritized findings

### `class EvidenceType(Enum)`
The fixed vocabulary of evidence kinds (e.g. `REVENGE`, `OVERTRADING`,
`STREAK`, `DRAWDOWN` — see the file for the complete set). Serialized to
its `.value` (a plain string) before being handed to any consumer — this
was a real bug fix in Phase 1 (the raw Enum member used to leak into the
UI as literally `"EvidenceType.REVENGE"`; see `CHANGELOG_V23.md` bug #2).

### `class Evidence`
Plain data container: `type` (an `EvidenceType`), `description`,
`severity`, `frequency`, `financial_impact`, `probability`, `confidence`,
`priority_score`. This is the atomic unit `DiagnosisEngine` and
`CoachingEngine` reason over.

### `class EvidenceEngine`
> Turns `ScoreEngine`'s output into a prioritized, explainable evidence
> list — the bridge between "raw numbers" and "a human-readable finding."

- **`__init__(self, doctor, context, performance, edge_map=None)`**
- **`get_top(self, n=8)`** — returns the `n` highest-`priority_score`
  pieces of evidence. `CoachingEngine` calls this with the default `n=8`
  to build `coach["key_evidence"]` — this is *why* the report's "Key
  Evidence" section is capped at 8 regardless of how many trades were
  analyzed (a deliberate scaling decision, see `CHANGELOG_V23_PHASE2.md`
  §on Technical Appendix scope).

Internally uses `utils.sequence_analysis.sequential_masks` for
streak/mask detection — same rule as `BehaviorEngine`: don't hand-roll
this logic again.
## `engines/diagnosis_engine.py`

### `class DiagnosisEngine`
- **`diagnose(self, evidence: List[Evidence], behavior: BehaviorResult, performance: dict) -> dict`**
  — picks the primary and (if warranted) secondary diagnosis from the
  evidence list, returns `{primary, primary_detail, secondary,
  secondary_detail, confidence_level}`. Called once by
  `CoachingEngine.generate()`. Pure function of its inputs — no state, no
  I/O, easy to unit-test with a hand-built evidence list.

## `engines/psychology_engine.py`

### `class PsychologyEngine`
- **`generate(self, evidence: List[Evidence], context: dict) -> dict`**
  — produces the qualitative "Trader DNA" profile: 6 traits (risk,
  emotion, patience, confidence, recovery, consistency — each
  `Low`/`Medium`/`High`/`Weak`/`Strong`) plus an `archetype` label (e.g.
  "معامله‌گر با کیفیت تصمیم‌گیری ناپایدار"). This is the *only* source of
  `coach["trader_dna"]`, consumed by `pages/06_Trader_DNA.py`, the report
  "Trader Profile"/"Psychological Findings" sections, and
  `reporting/charts.py::trader_dna_radar_chart()`.

## `engines/coaching_engine.py` — the orchestrator

### `class CoachingEngine`
> The final layer: evidence → diagnosis → Trader DNA → action plan +
> LLM-generated explanation. This is what turns "a pile of engine output"
> into the `coach` dict every consumer actually renders.

- **`__init__(self, doctor, llm_provider: str = None)`** — resolves the
  LLM provider via `llm.provider.get_llm()`; if resolution fails (no key
  configured, network error), logs a warning and continues with
  `self.llm = None` — this is the graceful-degradation path described in
  `docs/01_ARCHITECTURE.md`.
- **`generate(self, result: FullResult) -> dict`** — runs
  `EvidenceEngine.get_top(8)` → `DiagnosisEngine.diagnose()` →
  `PsychologyEngine.generate()`, builds the action plan (top 5 evidence
  items → issue/action/priority), and — only if `self.llm` is set — calls
  the LLM to produce `explainable_ai` (a coaching paragraph). Returns
  `{trader_dna, diagnosis, key_evidence, action_plan, explainable_ai,
  reality_check}`. **This exact dict shape is what `reporting/` and
  `api/models/analysis.py` both depend on** — if you add a key here,
  it's automatically available to both; if you rename one, you'll break
  both (search for the key name across `reporting/` and `api/` before
  renaming).

**Must never do**: let the LLM's response influence `trader_dna`,
`diagnosis`, `key_evidence`, or `action_plan` — those are all computed
*before* the LLM is called and passed to it only as context for
`explainable_ai`'s wording. If a future change makes the LLM call happen
earlier in this method or feed back into scoring, that's a violation of
the "AI is coaching-only" architectural rule.

## `engines/report_engine.py`

### `class FullResult`
Plain data container, the return type of `ScoreEngine.run()`:
`behavior` (`BehaviorResult`), `context` (dict of `ContextBlock`),
`performance` (dict), `edge_map` (dict), `summary` (str). This is the
object that flows into *everything downstream* — `reporting/`, `api/`,
`pages/*.py` all type-hint against this.

### `class ReportEngine`
> Formats `FullResult` + `coach` as **plain text** — this is the CLI's
> report, not the HTML/PDF renderer (those live in `reporting/`, added in
> Phase 2, and don't use this class at all).

- **`__init__(self, result: FullResult, coach: Optional[dict] = None)`**
- **`to_text(self) -> str`** / **`print_report(self) -> None`** — used by
  `main.py` for CLI output, and by `pages/08_Report.py` for the "download
  TXT" button.
- **`to_dict(self) -> dict`** — structured dict form; not currently used
  by the REST API (which builds its own JSON shape via
  `reporting/data_context.py` instead, for richer structure — see
  `docs/09_MODULE_INTERACTION.md`).

## `engines/risk_engine.py` — standalone facade, not yet wired into the UI

### `class RiskEngine`
> An independent, risk-focused view over `BehaviorEngine`'s data — a
> clean facade, not dead code (it has its own passing test), but **no
> router or Streamlit page currently calls it**. Documented here so its
> existence isn't mistaken for an oversight; see
> `docs/13_FUTURE_EXTENSIONS.md` for wiring it in.

- **`__init__(self, df_or_engine)`** — accepts either a raw DataFrame or
  an existing `BehaviorEngine` instance.
- **`revenge_analysis(self) -> Tuple[float, int]`** — score + event count.
- **`risk_taking_score(self) -> float`**
- **`position_sizing_stats(self) -> dict`** — basic volume statistics,
  for monitoring unconscious size creep over time.
- **`what_if_no_revenge(self) -> dict`** — simulation: what if revenge
  trades hadn't escalated in size?
- **`risk_report(self) -> dict`** — the complete risk report, meant for
  consumption by `ReportEngine` or `CoachingEngine` (not currently wired
  into either).

---

## `utils/` — shared, engine-adjacent utilities

### `utils/file_loader.py`
- **`class UnsupportedFileError(Exception)`** — raised when no loading
  strategy succeeds (unknown format, corrupt file, empty file).
- **`load_any_file(file, filename=None) -> pd.DataFrame`** — the single
  entry point for turning a path or file-like object into a raw
  DataFrame. Tries format-specific parsers in order (CSV with common
  delimiters tried before delimiter auto-sniffing — a deliberate
  ordering fix from Phase 1, see `CHANGELOG_V23.md` bug #3). Does **not**
  validate trading-data content — that's `utils/validation.py`'s job.

### `utils/column_mapper.py`
- **`class ColumnMapper`**
  - **`normalize(cls, df: pd.DataFrame) -> pd.DataFrame`** (classmethod)
    — maps arbitrary broker column names to the standard schema
    (`Open Time`, `Profit`, `Size`, plus derived `hour`/`date` columns)
    via exact-alias matching first, then fuzzy matching. Called by
    `utils.validation.validate_and_normalize`.

### `utils/validation.py`
- **`class DataValidationError(Exception)`** — fatal: analysis cannot
  proceed (e.g. no recognizable Profit/Size/Open Time column at all).
  Mapped to HTTP 422 by the API layer, shown as a clear CLI/Streamlit
  message elsewhere — never a raw traceback.
- **`validate_and_normalize(df) -> (pd.DataFrame, List[str])`** — the
  single validation entry point, called by `core.service`. Returns the
  normalized DataFrame plus a list of **non-fatal** warning strings
  (duplicate rows, invalid dates, zero/negative sizes) — these become
  `doctor.data_quality_warnings`, surfaced in both the Streamlit UI and
  CLI output.

### `utils/sequence_analysis.py`
The shared, vectorized streak/mask module — see
`docs/01_ARCHITECTURE.md` and `CHANGELOG_V23.md` for why this exists
(previously duplicated by hand in three engines).
- **`consecutive_streak(mask: np.ndarray) -> np.ndarray`** — for each
  position, the length of the run of `True` values ending there.
- **`size_increased_mask(size: np.ndarray, threshold=1.05) -> np.ndarray`**
- **`revenge_mask_from_df(df) -> np.ndarray`** — used by `ScoreEngine`.
- **`sequential_masks(df, quick_reentry_minutes=15) -> Optional[dict]`**
  — the richer combined output used by `EvidenceEngine`.

**If you touch this file**: `tests/test_sequence_analysis.py` proves
bit-identical output against the original hand-rolled loop across 300
randomized trials — re-run it after any change, and extend it rather
than replace it if you add a new pattern.

### `utils/logger.py`
- **`get_logger(name="trading_doctor") -> logging.Logger`** — the only
  way any module in this codebase should obtain a logger. Configures
  console + rotating file output once (idempotent), namespaces every
  logger under `"trading_doctor.*"`.

---

## `llm/` — pluggable coaching-only LLM layer

### `llm/provider.py`
- **`class BaseLLMProvider(ABC)`** — `chat(self, messages: List[Dict[str, str]]) -> str`,
  where each message is `{"role": "system"|"user"|"assistant", "content": str}`
  (OpenAI-style message format, used uniformly across all three providers
  regardless of each API's native format — translation happens inside
  each provider implementation).
- **`get_llm(provider_name: str) -> BaseLLMProvider`** — factory;
  `CoachingEngine.__init__` is the only caller in the entire codebase.

### `llm/gemini.py`, `llm/openai.py`, `llm/claude.py`
Each: `class *Provider(BaseLLMProvider)` with `__init__(self)` (reads its
API key/model from `config.py`) and `chat(self, messages) -> str`
(translates the uniform message list to that provider's native request
format, makes the HTTP call, returns plain text).

### `llm/prompts.py`
- **`build_coaching_prompt(summary, primary, secondary, evidence_text) -> List[dict]`**
  — the *only* prompt-construction function in the codebase. Builds
  system/user messages for the coaching explanation. If you're tempted to
  add a second prompt-building function elsewhere for a "quick LLM call,"
  put it here instead — this file is the intended single place to audit
  everything ever sent to an LLM.
## Reporting & API Modules

Covers `reporting/` (Phase 2) and `api/`
(Phase 3) — the two presentation layers described in
`docs/01_ARCHITECTURE.md`. Neither performs analytical computation; see
`docs/01_ARCHITECTURE.md` for what that boundary means concretely.

## `reporting/data_context.py`

### `build_report_context(result: FullResult, coach: dict, doctor=None, report_title=...) -> dict`
**The single shared context builder** — both `html_report.py` and
`pdf_report.py` call this and nothing else for data. Returns one flat
dict with keys `meta`, `executive_summary`, `overall_score`, `diagnosis`,
`trader_profile`, `strengths`, `weaknesses`, `behavior_analysis`,
`psychology`, `evidence`, `statistics`, `performance`, `risk`,
`recommendations`, `ai_coaching`, `appendix` — one per report section.
This is the only place in `reporting/` that does anything beyond direct
formatting: `strengths`/`weaknesses` are built by re-bucketing existing
`ContextBlock.severity` labels and `edge_map` best/worst entries (plus one
industry-standard threshold, Profit Factor ≥ 1.0) — documented in the
module's own docstring as intentionally *not* a new scoring formula.

## `reporting/charts.py`

Eight chart functions, each `(...) -> bytes` (raw PNG), all built with
matplotlib's `Agg` (headless) backend:
`equity_curve_chart`, `drawdown_chart`, `win_loss_pie_chart`,
`pnl_distribution_histogram`, `hourly_pnl_bar_chart`,
`weekday_pnl_bar_chart`, `behavior_scores_bar_chart`,
`trader_dna_radar_chart`. Every one degrades gracefully to a
"not enough data" placeholder image instead of raising, on empty/missing
input — never crashes a report over one bad chart.

### `build_all_charts(df, behavior_scores, trader_dna) -> Dict[str, bytes]`
Calls all eight and returns them keyed by name. **This is the function
both renderers actually call** — wrapped in a module-level
`threading.Lock()` (`_MPL_LOCK`) because `matplotlib.pyplot`'s global
figure-state isn't officially thread-safe, and a Streamlit/API server can
run concurrent sessions in one process. If you add a ninth chart function,
call it from inside this function so it's covered by the lock too.

## `reporting/html_report.py`

### `class ReportRenderError(Exception)`
Raised by both `render_html_report` and `render_pdf_report` on any
failure (bad context, chart generation failure, template error) — with a
clear message, never a bare traceback. Caught explicitly by
`pages/08_Report.py`, `main.py`'s `--export-html`/`--export-pdf` flags,
and `api/routers/reports.py`.

### `render_html_report(result, coach, doctor=None, report_title=...) -> str`
Renders `templates/report.html` (Jinja2, `StrictUndefined` — a missing
context key fails loudly at render time instead of silently producing a
blank section) with charts embedded as base64 data URIs. Returns one
self-contained HTML string (no external file dependencies) — this is
what's downloaded, emailed, or returned by the API's `.html` endpoint.

## `reporting/pdf_report.py`

### `render_pdf_report(result, coach, doctor=None, report_title=...) -> bytes`
Builds the PDF directly with reportlab's Platypus layout — an
*independent* layout implementation from the HTML template (reportlab
can't consume HTML/CSS), but reading the exact same
`build_report_context()` output and the exact same chart PNG bytes, so
content never drifts between formats even though layout code does.

Handles a real, non-obvious problem: reportlab's default font
(Helvetica) has zero Persian/Arabic glyph coverage, and reportlab performs
neither letter-shaping nor right-to-left reordering automatically. This
module registers the bundled Vazirmatn font
(`reporting/fonts/Vazirmatn-{Regular,Bold}.ttf`) and applies
`arabic_reshaper` + `python-bidi` to every text fragment via two internal
helpers worth knowing if you touch this file:
- `_rtl(text)` — reshape + bidi-reorder + strip any character not in the
  font's actual glyph coverage (a general safety filter, not a hardcoded
  emoji blacklist — protects against any future unsupported character).
- `_b(text)` — same, wrapped in reportlab's `<b>` markup. **Apply `_rtl`/`_b`
  to individual text fragments before composing markup, never to an
  already-composed string containing `<b>` tags** — bidi reordering a tag
  along with its text corrupts the markup. See the large comment block at
  the top of this file for the full story (this was a real, severe bug
  found via QA in Phase 2 — Persian text rendered as blank tofu boxes).

---

## `api/exceptions.py` — the error vocabulary

### `class APIError(Exception)`
Base class; every subclass declares its `status_code` and `error_code`
as class attributes, so raising the right subclass automatically produces
the right HTTP status and the right `"code"` field in the unified error
envelope (see `API_DOCUMENTATION.md`). Subclasses: `NotFoundError` →
`UploadNotFoundError`/`AnalysisNotFoundError`, `InvalidFileError`,
`DataInvalidError`, `FileTooLargeError`, `ReportGenerationError`,
`UnauthorizedError`, `RateLimitedError`. Add a new subclass here rather
than returning an ad-hoc `JSONResponse` from a router.

## `api/dependencies.py`

### `verify_api_key(x_api_key=Security(_api_key_header)) -> Optional[str]`
No-op (returns `None`) when `api_config.AUTH_ENABLED` is `False`
(default). When enabled, raises `UnauthorizedError` on a missing/invalid
key. Registered via `fastapi.security.APIKeyHeader` + `Security()`
specifically so it shows up as a real OpenAPI security scheme (Swagger's
"Authorize" button) — a bare `Header()` parameter, tried first, does not.

### `class _SlidingWindowRateLimiter` / `enforce_rate_limit(request) -> None`
In-memory, per-process sliding-window limiter, keyed by `X-API-Key` if
present else `request.client.host`. Raises `RateLimitedError` (→ 429)
over the limit. **Per-process** — see `docs/04_DEPLOYMENT.md` for what
this means with `--workers > 1`.

### `get_store() -> AnalysisStore`
Returns the module-level singleton store instance — the one every router
depends on via `Depends(get_store)`.

## `api/services/store.py` — the only api/ module allowed to call the engine

### `class AnalysisStore`
Thread-safe (one `threading.Lock`), in-memory + on-disk. Size-bounded
(`STORE_MAX_ANALYSES`/`STORE_MAX_UPLOADS`, LRU eviction) — this bound was
added after a real unbounded-growth bug found during self-review (see the
Phase 3 self-review).
- **`save_upload(filename, raw_bytes) -> UploadRecord`** — writes to disk
  under `api_config.API_DATA_DIR/uploads/`, evicts oldest on overflow.
- **`get_upload(upload_id) -> UploadRecord`** — raises `UploadNotFoundError`.
- **`run_analysis(upload_id, llm_provider="none") -> AnalysisRecord`** —
  **the only method in the entire `api/` package that calls
  `core.service.analyze_file`/`analyze_dataframe`.** Explicitly commented
  in the source as a critical boundary. If you ever need engine output
  from a new endpoint, call this method (or add a new method here) —
  never import an engine class into a router.
- **`get_analysis(analysis_id) -> AnalysisRecord`** — raises `AnalysisNotFoundError`.
- **`list_history(page, page_size) -> (List[AnalysisRecord], int)`** —
  paginated, newest-first.

## `api/routers/` — thin HTTP handlers

Every handler follows the same shape: validate via its Pydantic model
(automatic), call one `AnalysisStore` method (offloaded to a thread pool
via `run_in_threadpool` if it touches the engine/reporting), map the
result to a response model. None contain conditional business logic —
if you find yourself writing an `if`/`else` based on trading data in a
router, that logic belongs in an engine instead.

| File | Endpoint(s) |
|---|---|
| `health.py` | `GET /health` — liveness, unauthenticated |
| `config.py` | `GET /config` — non-secret settings, unauthenticated |
| `uploads.py` | `POST /uploads` |
| `analyses.py` | `POST /analyses`, `GET /analyses/{id}`, `GET /analyses/{id}/report` |
| `reports.py` | `GET /analyses/{id}/report.html`, `GET /analyses/{id}/report.pdf` |
| `history.py` | `GET /history` |

Full request/response shapes: `API_DOCUMENTATION.md`.

## `api/main.py`

App factory + cross-cutting middleware/handlers:
- **`log_requests(request, call_next)`** — middleware assigning each
  request a short correlation ID (`X-Request-ID` response header),
  logging method/path/status/duration.
- **`handle_api_error`**, **`handle_unsupported_file`**,
  **`handle_data_validation_error`**, **`handle_request_validation_error`**,
  **`handle_report_render_error`**, **`handle_unexpected_error`** — the
  centralized exception handlers producing the one unified error envelope
  documented in `API_DOCUMENTATION.md`. `handle_unexpected_error` is the
  catch-all: logs the full traceback server-side, returns a generic safe
  message — verified by
  `tests/test_api.py::test_unexpected_exception_never_leaks_traceback`.
