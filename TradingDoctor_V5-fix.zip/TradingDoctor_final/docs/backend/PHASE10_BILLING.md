# Phase 10 — Subscription & Billing System

> Transform Trading Doctor into a revenue-generating SaaS with plans, Stripe
> integration, usage tracking, and tier-based feature gating.

This document describes the architectural changes, new modules, and operational
considerations introduced in Phase 10.

---

## 1. What Changed

### Before (Phase 9)
- All users had equal access to all features
- No payment integration
- No usage limits
- No subscription state

### After (Phase 10)
- Three subscription tiers: Free / Pro ($19/mo) / Premium ($49/mo)
- Stripe integration (checkout, customer portal, webhooks)
- Usage tracking (analysis runs, upload bytes, LLM calls, report downloads)
- Tier-based feature gating (PDF export, AI coaching, history search, etc.)
- Per-user storage quota + monthly analysis limits
- Auto-assign free plan on registration
- Webhook-driven subscription lifecycle (single source of truth: Stripe)

### Non-Breaking Changes
Phase 10 is **additive** — no existing API contracts changed. The new
`/billing/*` endpoints are added; existing `/uploads`, `/analyses`, etc.
now enforce tier limits but their response shapes are unchanged.

---

## 2. New Modules

### `billing/` package

```
billing/
├── __init__.py
├── config.py                          # Stripe keys, trial days, provider selection
├── models.py                          # ORM: Plan, Subscription, Invoice, UsageEvent
├── schemas.py                         # Pydantic: PlanResponse, CheckoutRequest, etc.
├── dependencies.py                    # get_user_plan, require_tier, require_feature
├── exceptions.py                      # (uses auth.exceptions.TierRequiredError)
├── services/
│   ├── __init__.py
│   ├── plans.py                       # Plan definitions + seeding + lookup
│   ├── stripe_provider.py             # Stripe SDK adapter (lazy-loaded)
│   ├── subscriptions.py               # Subscription lifecycle + webhook upserts
│   ├── usage.py                       # Usage recording + tier enforcement
│   └── invoices.py                    # (future — invoice PDF generation)
└── routers/
    ├── __init__.py
    ├── billing.py                     # User-facing billing endpoints
    └── webhooks.py                    # Stripe webhook receiver (no auth)
```

### Database migration

`alembic/versions/0004_phase10_billing.py` creates 4 new tables:

| Table | Purpose |
|---|---|
| `plans` | Catalog of subscription plans (seeded at deploy time) |
| `subscriptions` | A user's current subscription state (+ Stripe IDs) |
| `invoices` | One per billing period (mirrors Stripe invoices) |
| `usage_events` | Append-only log of metered usage (analysis runs, uploads, LLM calls) |

### Updated existing files

| File | Change |
|---|---|
| `api/main.py` | Registers billing + webhook routers; validates billing config at startup; auto-seeds plans |
| `api/routers/uploads.py` | Enforces tier upload size + storage quota; records usage event |
| `api/routers/analyses.py` | Enforces monthly analysis limit; records usage event |
| `auth/routers/register.py` | Auto-assigns free plan on registration (best-effort) |
| `db/models.py` | Imports `billing.models` for Alembic autogenerate |

---

## 3. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  User-Facing Billing Endpoints (require auth)               │
│                                                              │
│  GET    /billing/plans              → list public plans      │
│  GET    /billing/subscription       → current sub details    │
│  GET    /billing/current-plan       → compact plan info      │
│  GET    /billing/usage              → usage + limits          │
│  POST   /billing/checkout           → Stripe Checkout Session│
│  POST   /billing/portal             → Stripe Customer Portal │
│  POST   /billing/cancel             → cancel subscription    │
│  GET    /billing/invoices           → invoice history        │
│  GET    /billing/invoices/{id}      → single invoice detail  │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Webhook Receiver (NO auth — signature verification only)   │
│                                                              │
│  POST   /billing/webhooks/stripe                            │
│    ↑ verifies Stripe-Signature header                       │
│    ↑ dispatches to event handlers (idempotent upserts)      │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Tier Enforcement (Depends(get_user_plan))                  │
│                                                              │
│  POST /uploads    → check_upload_allowed(plan, size)        │
│  POST /analyses   → check_analysis_allowed(plan) → 402 if over │
│  Future: AI coaching → require_feature("ai_coaching")       │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Billing Services                                           │
│                                                              │
│  PlansService              SubscriptionService              │
│    seed_plans()              ensure_free_subscription()     │
│    get_plan_by_tier()        create_checkout_session()      │
│    list_public_plans()       cancel_subscription()          │
│    plan_to_dict()            upsert_subscription_from_stripe()│
│                                                              │
│  UsageService               StripeProvider                  │
│    record_analysis_run()     create_customer()              │
│    record_upload_bytes()     create_checkout_session()      │
│    get_monthly_usage()       create_billing_portal_session()│
│    check_analysis_allowed()  cancel_subscription()          │
│    check_upload_allowed()    verify_webhook_signature()     │
│    check_llm_call_allowed()                                 │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  ⚠️  Stripe (external) — single source of truth for paid    │
│  Local DB mirrors Stripe via webhooks; never the reverse.   │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. Subscription Lifecycle

### Sign-up flow

1. User clicks "Upgrade to Pro" → `POST /billing/checkout`
2. Backend creates Stripe Checkout Session (no local DB change yet)
3. User completes payment on Stripe
4. Stripe sends `checkout.session.completed` webhook → logged
5. Stripe sends `customer.subscription.created` webhook
6. Webhook handler calls `upsert_subscription_from_stripe()`
7. Local DB now reflects the new Pro subscription

### Cancellation flow

1. User clicks "Cancel" → `POST /billing/cancel`
2. Backend calls Stripe to cancel at period end
3. Stripe sends `customer.subscription.updated` webhook
4. Webhook handler updates local `canceled_at` field
5. At period end, Stripe sends `customer.subscription.deleted` webhook
6. Webhook handler sets `status=canceled`

### Why webhook-driven?

The local DB **never** initiates subscription state changes for paid plans.
It only **mirrors** Stripe's state. This avoids:
- Race conditions (Stripe is the source of truth)
- Drift between local and Stripe state
- Lost updates if the backend is down during a payment

For the **free** tier (no Stripe subscription), the local DB is the source
of truth — `ensure_free_subscription()` creates it directly.

---

## 5. Usage Tracking

Usage is recorded in an **append-only** `usage_events` table. Each event has:
- `user_id`, `event_type`, `quantity`, `billing_period` ("YYYY-MM")
- `resource_id` (e.g. analysis_id), `details` (JSON)

Monthly totals are computed by **aggregation**, not by a running counter.
This ensures:
- Audit trail of every usage event
- Recomputable if limits change
- No drift between counter and reality

### Event types

| Event | Recorded when | Quantity |
|---|---|---|
| `analysis_run` | Successful `POST /analyses` | 1 |
| `upload_bytes` | Successful `POST /uploads` | file size in bytes |
| `llm_call` | Analysis with LLM provider ≠ "none" | 1 |
| `report_download` | `GET /analyses/{id}/report.{html,pdf}` (future) | 1 |

### Tier enforcement

| Check | Free | Pro | Premium |
|---|---|---|---|
| Analyses per month | 5 | 100 | unlimited |
| Max upload size | 5 MB | 25 MB | 100 MB |
| Total storage per month | 50 MB | 1 GB | 10 GB |
| LLM calls per month | 0 | 50 | unlimited |
| PDF export | ✅ | ✅ | ✅ |
| AI coaching | ❌ | ✅ | ✅ |
| History search | ❌ | ✅ | ✅ |
| Favorites | ✅ | ✅ | ✅ |
| Priority support | ❌ | ❌ | ✅ |

---

## 6. Webhook Security

The webhook endpoint (`POST /billing/webhooks/stripe`) is **NOT** behind
`verify_api_key` or `get_current_user`. Authentication is via **Stripe
webhook signature verification ONLY**:

1. Read the **raw body** (not parsed JSON — signature is over the bytes)
2. Extract `Stripe-Signature` header (`t=...,v1=...`)
3. Call `stripe.Webhook.construct_event()` with the secret + tolerance
4. If verification fails → 400 (don't process)
5. If verification succeeds → dispatch to event handler

### Why no API key?

Stripe doesn't know our API key. The webhook is initiated by Stripe, not
by us. Signature verification is the standard way to authenticate webhooks.

### Idempotency

All webhook handlers are **idempotent** — they use `upsert_*_from_stripe()`
which finds-or-creates by `stripe_*_id`. If Stripe retries a webhook (which
it does for any non-2xx response), the second delivery is a no-op.

### Unhandled events

Unknown event types return **200** (not 400) so Stripe doesn't retry them.
We log them for visibility but don't process.

---

## 7. Plan Seeding

Plans are seeded at application startup via `seed_plans()` in the lifespan
handler. The seed is **idempotent** — existing plans are not modified.

To change a plan's price or limits:
1. Update `PLAN_DEFINITIONS` in `billing/services/plans.py`
2. Deploy — the seed will skip existing plans (no update)
3. To force an update, write a one-off Alembic migration

To add a new plan tier:
1. Add the tier to `PlanTier` enum (in `billing/models.py`)
2. Add the definition to `PLAN_DEFINITIONS`
3. Run `alembic upgrade head` (the new tier's row will be seeded on next startup)

**Never** change the `tier` enum value of an existing plan — existing
subscriptions would be orphaned.

---

## 8. Configuration

Required env vars for production:

| Variable | Purpose |
|---|---|
| `STRIPE_SECRET_KEY` | Stripe API secret key (`sk_live_...` in prod) |
| `STRIPE_PUBLISHABLE_KEY` | Stripe publishable key (for frontend) |
| `STRIPE_WEBHOOK_SECRET` | Webhook signing secret (`whsec_...`) |
| `STRIPE_MODE` | `test` or `live` |
| `STRIPE_PRICE_ID_PRO_MONTHLY` | Stripe price ID for Pro monthly |
| `STRIPE_PRICE_ID_PREMIUM_MONTHLY` | Stripe price ID for Premium monthly |

Optional:

| Variable | Default | Purpose |
|---|---|---|
| `TRIAL_DAYS_DEFAULT` | 14 | Trial period for paid plans (0 = no trial) |
| `AUTO_ASSIGN_FREE_PLAN` | true | Auto-assign free plan on registration |
| `STRIPE_WEBHOOK_TOLERANCE` | 300 | Reject webhooks older than N seconds |
| `PAYMENT_PROVIDER` | stripe | Future: `paddle`, `lemonsqueezy` |

Config validation runs at startup. In production, missing keys are logged
as errors.

---

## 9. Test Coverage

`tests/test_phase10_billing.py` — 36 tests across 8 test classes:

| Class | Tests | Coverage |
|---|---|---|
| `TestPlans` | 4 | Seeding, idempotency, listing, serialization |
| `TestSubscriptions` | 5 | Auto-assign free, idempotency, plan lookup, Stripe upsert |
| `TestUsageTracking` | 4 | Record events, aggregation, LLM call tracking |
| `TestTierEnforcement` | 6 | Analysis limit, upload size, storage quota, LLM gating |
| `TestFeatureFlags` | 3 | Per-tier feature flags |
| `TestBillingConfig` | 3 | Validation of Stripe keys |
| `TestWebhookSecurity` | 3 | Missing/malformed/invalid signature rejection |
| `TestBillingEndpoints` | 6 | List plans, current plan, usage, subscription, checkout, auth required |
| `TestAutoAssignFreePlan` | 1 | Registration auto-assigns free plan |
| `TestEngineImmutability` | 1 | billing/ never imports engines/ |

Total: **214 tests passing** (178 from prior phases + 36 new Phase 10).

---

## 10. Known Limitations + Future Work

| Item | Phase | Notes |
|---|---|---|
| Invoice PDF generation | future | Reuse Phase 2's reportlab + Vazirmatn font |
| Proration on plan change | future | Stripe handles proration; we just mirror the result |
| Coupon/discount codes | future | Stripe supports them; we'd expose via checkout |
| Annual billing discount | future | Add `STRIPE_PRICE_ID_PRO_YEARLY` etc. |
| Usage-based billing (metered) | future | Currently all plans are flat-rate; metered would use Stripe's usage records API |
| Webhook retry dashboard | future | Surface failed webhook deliveries to admin |
| Tax handling | future | Stripe Tax integration for EU/UK VAT |
