# Folder Structure

```
TradingDoctor/
├── main.py                    CLI entry point
├── app.py                     Streamlit entry point (multipage app root)
├── config.py                  Engine-level configuration (LLM keys/models,
│                               behavioral thresholds, safe env-var parsing)
├── requirements.txt            All dependencies for every phase (core,
│                               reporting, API) — see docs/03_INSTALLATION.md
├── API_DOCUMENTATION.md         Full REST API reference (Phase 3 deliverable)
├── CHANGELOG_V23.md              Phase 1 changelog (engine stabilization)
├── CHANGELOG_V23_PHASE2.md        Phase 2 changelog (reporting module)
├── README.md                       Original project README
│
├── core/
│   └── service.py              analyze_dataframe() / analyze_file() —
│                                 the ONE function every consumer calls to
│                                 run the full analytical pipeline
│
├── engines/                     The analytical core (Phase 1). See
│   │                             docs/07_ENGINE_REFERENCE.md for full detail.
│   ├── behavior_engine.py         Raw behavioral scores (revenge, overtrading,
│   │                               risk-taking, patience, discipline)
│   ├── score_engine.py             Enriches scores with $ context; ScoreEngine
│   │                               (current snapshot) + TrendEngine (history)
│   ├── evidence_engine.py           Extracts prioritized, explainable Evidence
│   │                               objects (severity, frequency, $ impact)
│   ├── diagnosis_engine.py           Picks primary/secondary diagnosis from evidence
│   ├── psychology_engine.py           Qualitative Trader DNA profile (archetype)
│   ├── coaching_engine.py             Orchestrator: evidence → diagnosis → DNA →
│   │                               action plan + LLM-generated coaching text
│   ├── report_engine.py               FullResult dataclass + text/dict report
│   │                               (used by CLI; NOT the HTML/PDF renderer)
│   └── risk_engine.py                 Standalone risk-focused facade (used by
│                                     tests; not yet wired into the UI — see
│                                     docs/13_FUTURE_EXTENSIONS.md)
│
├── utils/                         Shared, engine-adjacent utilities
│   ├── file_loader.py               Reads any input format (csv/xlsx/xls/
│   │                               htm/html/log/json/txt) into a DataFrame
│   ├── column_mapper.py              Maps arbitrary broker column names to
│   │                               the standard schema (Open Time/Profit/Size)
│   ├── validation.py                  Validates trading-data *content*
│   │                               (DataValidationError, quality warnings)
│   ├── sequence_analysis.py            Shared vectorized streak/mask helpers
│   │                               (used by 3 different engines — see
│   │                               CHANGELOG_V23.md for why this exists)
│   └── logger.py                       Central logging configuration
│
├── llm/                             Pluggable LLM coaching layer
│   ├── provider.py                    BaseLLMProvider ABC + get_llm() factory
│   ├── gemini.py, openai.py, claude.py  One provider implementation each
│   └── prompts.py                      Prompt templates (coaching only —
│                                     never analytical)
│
├── reporting/                        HTML/PDF reporting module (Phase 2)
│   ├── data_context.py                 Shared context builder — the ONLY
│   │                               place that reorganizes engine output
│   │                               for display (e.g. strengths/weaknesses)
│   ├── charts.py                        8 matplotlib chart generators,
│   │                               shared by both renderers, thread-safe
│   ├── html_report.py                    Jinja2 → self-contained HTML
│   ├── pdf_report.py                      reportlab → PDF (with bundled
│   │                               Vazirmatn font for correct Persian text)
│   └── fonts/                              Vazirmatn-Regular.ttf, -Bold.ttf,
│                                         OFL.txt (license)
│
├── templates/                          Jinja2 templates for the HTML report
│   ├── report.html                       Base layout
│   └── partials/                          One file per report section (15)
│       └── _style.css                       Shared CSS (dark/light aware)
│
├── api/                                  REST API (Phase 3)
│   ├── main.py                             FastAPI app factory, middleware,
│   │                                   centralized exception handlers
│   ├── config.py                            API-only settings (auth, rate
│   │                                   limits, upload size, CORS) —
│   │                                   deliberately separate from config.py
│   ├── dependencies.py                        Auth + rate-limit dependencies
│   ├── exceptions.py                            APIError hierarchy
│   ├── models/                                    Pydantic schemas
│   │   ├── common.py, uploads.py, analysis.py
│   ├── services/
│   │   └── store.py                                 The ONLY api/ module that
│   │                                             calls the engine directly
│   └── routers/
│       ├── health.py, config.py                       Public, unauthenticated
│       └── uploads.py, analyses.py, reports.py, history.py
│                                                     Authenticated + rate-limited
│
├── pages/                                  Streamlit multipage UI
│   ├── 01_Dashboard.py … 09_Trends.py         One file per screen
│
├── tests/                                    pytest suite (48 tests total)
│   ├── test_pipeline.py                         Phase 1 smoke tests
│   ├── test_validation.py, test_file_loader.py,
│   │   test_sequence_analysis.py                Phase 1 unit tests
│   ├── test_reporting.py                          Phase 2 tests
│   └── test_api.py                                  Phase 3 tests (includes
│                                                 the static "no business
│                                                 logic in API layer" check)
│
├── docs/                                       You are here.
│
├── data/                                         Runtime data dir (gitkeep)
└── reports/                                       Log output dir (gitkeep)
```

## Where to look for X

| I want to... | Look in |
|---|---|
| Change how a behavioral score is calculated | `engines/behavior_engine.py` |
| Change what counts as a diagnosis | `engines/diagnosis_engine.py` |
| Change the wording of the AI coaching text | `llm/prompts.py` (never the score) |
| Add a new report section | `templates/partials/` + `reporting/data_context.py` |
| Add a new REST endpoint | `api/routers/` + a Pydantic model in `api/models/` |
| Change file-upload validation rules | `utils/file_loader.py` (format) or `utils/validation.py` (content) |
| Change a Streamlit page's layout | `pages/0N_Name.py` |
| Change logging behavior | `utils/logger.py` |
| Change rate limits or auth | `api/config.py`, `api/dependencies.py` |
