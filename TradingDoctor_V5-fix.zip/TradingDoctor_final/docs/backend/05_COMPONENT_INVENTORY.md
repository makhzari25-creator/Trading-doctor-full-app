# Component Inventory — Trading Doctor V23

One row per component. **Verified** means the `data-testid` selector was
confirmed against Streamlit 1.59.0's actual rendered DOM via a headless
Playwright probe during this phase (not assumed from documentation or
naming convention) — see the methodology note at the bottom.

| Component | Native or Custom | Selector(s) | Verified | Min. Streamlit version needed | Used on |
|---|---|---|---|---|---|
| Buttons | Native, restyled | `stBaseButton-primary`, `stBaseButton-secondary` | ✅ direct probe | 1.30 (current pin OK) | All pages |
| Text input / Selectbox | Native, restyled | `stTextInputRootElement`, `stSelectbox`, `stWidgetLabel` | ✅ direct probe | 1.30 (OK) | (none currently — defined for future forms) |
| Tables | Native, restyled (container only — see constraint) | `stDataFrame` | ✅ direct probe | 1.30 (OK) | Edge Map, Trends |
| Cards | Custom | `.td-card` | n/a (new) | 1.30 (OK — pure HTML/CSS) | New shared component |
| KPI Widgets | Custom (hybrid) | `.td-kpi` | n/a (new) | 1.30 (OK) | Dashboard (replaces raw `st.metric` rows) |
| Charts | Native (Plotly/matplotlib), palette contract only | n/a (chart config, not DOM) | n/a | 1.30 (OK) | Charts page, all report charts |
| Sidebar / Nav | Native, restyled + new active-state | `stSidebar`, `stSidebarContent`, `stSidebarNavLink[aria-current="page"]` | ✅ direct probe — **verified Streamlit natively sets `aria-current="page"` on the active link**, so the active-state fix is pure CSS, no server-side workaround needed (simpler than first assumed — see correction note below) | 1.30 (OK) | app.py |
| Tabs | Native, restyled | `stTabs`, `stTab` | ✅ direct probe | 1.30 (OK) | (none currently — defined for future use) |
| Accordions | Native, restyled | `stExpander`, `stExpanderDetails` | ✅ direct probe | 1.30 (OK) | Diagnosis, Behavioral Analysis |
| Badges & Tags | Custom | `.td-badge` | n/a (new) | 1.30 (OK) | **New** — Dashboard, Behavioral Analysis, Diagnosis (severity display) |
| Alerts | Native, restyled | `stAlertContentError/Warning/Info/Success` | ✅ direct probe | 1.30 (OK) | All pages |
| Toasts | Native | `stToast`, `stToastContainer`, `stToastText` | ✅ direct probe (this phase) | 1.30 (OK — confirmed present in 1.30.0 wheel directly) | Not yet used anywhere — defined for future use |
| Dialogs / Modals | Native | `stDialog` | ✅ direct probe (this phase) | **1.34** (confirmed via version bisection — current `>=1.30` pin does NOT guarantee this) | Not yet used — **action item**, see below |
| Tooltips | Native (`help=` param) | `stTooltipHoverTarget` | ✅ direct probe | 1.30 (OK) | **New usage** — pairs with existing truncated-text pattern |
| Progress | Native, restyled | `stProgress`, `stProgressBarTrack` | ✅ direct probe | 1.30 (OK) | Dashboard |
| Empty states | Custom | `.td-empty-state` | n/a (new) | 1.30 (OK) | **New shared component** — replaces ad hoc per-page handling |
| Loading / Skeleton | Spinner native, skeleton custom | `st.spinner` (native); `.td-skeleton` (custom CSS, not `stSkeleton`) | Spinner: existing; Skeleton: verified `stSkeleton` exists but ONLY from **1.59.0** — too fragile to depend on, custom CSS used instead | 1.30 (OK, since skeleton is custom) | **New** |
| Error / Success states | Composition of Alert + Empty State | — | — | 1.30 (OK) | Convention, not a new component |

## Action items this inventory surfaces (decisions for you, not silently resolved)

1. **`st.dialog` needs a version decision.** If any shared component adopts
   it, `requirements.txt`'s `streamlit>=1.30,<2.0` must become
   `>=1.34,<2.0` at minimum — a real compatibility-range change, not a
   cosmetic one. This phase's implementation (see
   `06_IMPLEMENTATION_NOTES.md`) does **not** use `st.dialog` for exactly
   this reason — deferred, not silently built around the constraint.
2. **Correction, not an open item**: this document's first draft assumed
   the sidebar's active-page link had no stable selector and would need
   a server-side `href`-matching workaround. Direct DOM verification
   (`grep` on real rendered output) found Streamlit natively sets
   `aria-current="page"` on the current page's nav link — the active-
   state style is plain CSS (`[data-testid="stSidebarNavLink"]
   [aria-current="page"]`), implemented as such in `ui/theme.py`. Noted
   here so the earlier, more pessimistic assumption isn't mistaken for
   the final answer if this document is skimmed out of order.
3. **Per-cell table coloring is genuinely not possible via CSS** (canvas-
   rendered grid). Any future page wanting colored profit/loss cells
   needs `pandas.Styler`, a content-level decision for that page, out of
   this phase's shared-component scope.

## Verification methodology (so this table can be re-validated later)

Every "✅ direct probe" row was confirmed by: booting a minimal Streamlit
app exercising the real widget, rendering it with headless Chromium via
Playwright (`page.content()` after a fixed wait for hydration), and
grepping the actual returned DOM for `data-testid="..."` attributes —
not inferred from Streamlit's documentation or source code comments,
both of which can lag behind actual rendered output across versions.
Version-specific claims (`st.dialog` → 1.34.0, `st.skeleton` → 1.59.0,
`st.toast` → present at 1.30.0) were confirmed by downloading each
candidate wheel directly (`pip download streamlit==X.Y.Z --no-deps`) and
inspecting `streamlit/__init__.py` for the relevant attribute — not
changelog-reading, which is how this phase caught its own two version-
number errors before they shipped (see `03_COMPONENTS.md`'s dialog/
skeleton sections for what was originally assumed vs. what was verified).
