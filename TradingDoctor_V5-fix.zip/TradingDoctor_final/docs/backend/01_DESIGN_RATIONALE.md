# Design Rationale — Trading Doctor V23

Every decision below is justified before it appears in the token/component
specs in `02_FOUNDATIONS.md` and `03_COMPONENTS.md`. Read this first — those
documents are the "what," this is the "why."

## Reference products, and specifically what's being borrowed from each

Not "make it look like these" in a vague sense — concrete, specific
patterns:

- **TradingView**: dark-first surface layering for data-dense financial
  screens; monospace numerals for anything tabular/comparative (prices,
  scores, percentages) so digits align visually column-to-column.
- **Linear**: restrained color — accent color is spent on exactly one
  thing (primary actions + the current focus/selection state), never on
  decoration; fast, subtle motion (150-200ms); a single consistent
  8px-based spacing rhythm.
- **Notion**: calm neutral backgrounds with content-first hierarchy;
  icons kept small and monochrome except where color carries real
  meaning.
- **Vercel**: high-contrast dark mode done via layered near-black
  surfaces (not pure black) so elevation is perceivable without heavy
  shadows; crisp 1px borders as the primary separation tool, shadows used
  sparingly for true overlays only (modals, dropdowns).
- **Stripe**: the semantic-color discipline (green literally always
  means "good/success," red always "bad/error," never used for anything
  else) and precise, legible tabular data presentation.
- **Raycast**: keyboard-first affordances (visible focus rings, not an
  accessibility afterthought) and a tight, confident type scale with few
  sizes used very consistently rather than many sizes used loosely.

## Principle 1 — Clarity over decoration

Trading Doctor's core value is telling a trader an uncomfortable truth
about their behavior, backed by numbers. Every design choice is evaluated
against: *does this help the number/finding land faster, or does it
compete with it for attention?* This is why, for example, the icon set
(§Iconography) is monochrome-by-default and color is reserved for
severity/semantic meaning — an app that color-codes decoratively trains
the user to ignore color, which is exactly the channel this product needs
most (severity signaling).

## Principle 2 — Dark-first, light-supported, not dark-only

Traders frequently work in dark, low-light setups (matches TradingView's
own default) — dark is the primary, most-polished mode. But
`reporting/templates/partials/_style.css` already commits to `light` as
the default/print-safe mode for downloadable reports (a deliberate Phase
2 decision — dark PDFs waste ink/look unprofessional in business
contexts), so the live app must support both well, not treat light mode
as an afterthought. **Both modes are first-class**; dark is simply where
the primary design intent is validated first.

## Principle 3 — One brand across app and report (closes a real audit gap)

`00_UI_AUDIT.md` found two disconnected color systems: Streamlit's
default theme (live app) and Phase 2's report CSS tokens. This system's
color palette is a deliberate **superset/evolution** of the Phase 2
tokens (`--accent`, `--positive`, `--negative`, `--warning`, `--radius`,
`--shadow` all carry forward in spirit, refined into fuller scales) —
not a coincidence, a fix. A user should not be able to tell, from color
alone, whether they're looking at the live dashboard or the PDF they
just downloaded from it.

## Principle 4 — Color is meaningful, not decorative (severity as a first-class system)

The audit's single highest-impact finding: severity (`Low`/`Medium`/
`High`/`Critical`) — the concept this entire product exists to
communicate — has zero visual encoding today. This phase treats a
4-step **severity ramp** as a primary design-system citizen, on equal
footing with the semantic positive/negative/warning/info colors, not a
derived afterthought. See `02_FOUNDATIONS.md` §Color System.

## Principle 5 — Numbers are typographically distinct from prose

Financial/behavioral figures (scores, $ amounts, percentages, streak
counts) use a monospace numeral style throughout — tabular figures align
in columns, and a monospace treatment gives "this is data, not
narrative" a typographic signal independent of color. This is a direct,
deliberate borrow from TradingView and matches `reporting/charts.py`'s
existing convention of treating numbers as first-class visual objects
(chart labels, score bars).

## Principle 6 — Motion is fast and quiet, or absent

150-250ms transitions, ease-out, used only for state changes a user
directly caused (hover, focus, expand/collapse) — never ambient/looping
animation, never anything that could distract from reading a diagnosis.
Directly informed by the `ux-guidelines.csv` anti-pattern data reviewed
in the design-system-guide discussion earlier in this project ("harsh
animations" flagged as a negative pattern for calm/trust-oriented
products) and by Linear/Raycast's restraint.

## Principle 7 — Accessible by construction, not by audit

Every color pair in this system is chosen to already satisfy WCAG AA
(4.5:1 body text, 3:1 large text/UI components) — contrast is checked at
token-definition time (§04_ACCESSIBILITY.md), not retrofitted onto
finished screens. Given Trading Doctor already has a strong "never
silently degrade" engineering culture (Phases 1-3), the design system
should hold itself to the same standard.

## Principle 8 — Consistency over local optimization

Explicit instruction for this phase, and good practice regardless: one
spacing scale, one radius scale, one shadow/elevation scale, used
everywhere without page-specific exceptions. A component (badge, card,
button) looks and behaves identically whether it appears on Dashboard or
Edge Map. This is *why* implementation in this phase is scoped to shared
components/theme only, never a page-specific override.

## Key decisions, stated explicitly with their tradeoffs

### Decision: build custom HTML/CSS components rather than rely only on Streamlit's native widgets

Streamlit's native components (`st.metric`, `st.error`, `st.expander`)
are visually fixed — they cannot be restyled to match a custom palette
beyond Streamlit's own theme-color config (which only exposes a handful
of global colors, not a full token system). To achieve badges, severity
pills, KPI cards with the specified elevation/radius system, and a
branded alert style, this system defines custom HTML components rendered
via `st.markdown(..., unsafe_allow_html=True)`, styled by one globally
injected stylesheet.
**Tradeoff accepted**: custom HTML components lose some of Streamlit's
automatic accessibility wiring (e.g., `st.error`'s built-in ARIA live
region behavior) — `04_ACCESSIBILITY.md` specifies the manual ARIA
attributes required to compensate, and native widgets are kept wherever
their default behavior already meets the bar (see the component
inventory's "native vs. custom" column).

### Decision: a real 12-column grid concept, expressed through Streamlit's `st.columns`, not a CSS grid framework

Streamlit doesn't support arbitrary CSS Grid/Flexbox layout of its own
elements — `st.columns(n)` is the only native layout primitive. Rather
than fight the framework, the grid system (`02_FOUNDATIONS.md`
§Grid System) defines standard column-count patterns (4-up KPI row,
3-up card row, 2-up split, full-width) as *usage conventions* on top of
`st.columns`, with the spacing scale controlling gutter via CSS margin
on the injected component wrappers (Streamlit's own column gutter is
fixed and not part of this token system).

### Decision: severity and semantic colors are separate scales, not aliases of each other

`Critical` severity and `negative`/error semantic red happen to look
similar but are conceptually different axes (one measures "how bad is
this behavior pattern," the other means "this action failed/is
wrong") — collapsing them into one token would make a future screen that
needs both (e.g., "this Critical-severity evidence failed to load")
ambiguous. Kept as two related-but-distinct token groups.

## What this phase deliberately does NOT do

- Does not redesign any page's unique content/layout (explicit
  instruction) — only the shared theme and shared component library.
- Does not introduce a JS framework, bundler, or component library
  requiring `npm`/Node — everything is pure CSS + Python-rendered HTML,
  consistent with the rest of this project's "no system dependencies
  beyond `pip install`" discipline (see `CHANGELOG_V23_PHASE2.md`'s
  reportlab-over-wkhtmltopdf precedent).
- Does not attempt to make Streamlit's native widgets pixel-identical to
  the custom components — where a native widget is kept (see inventory),
  it's restyled via CSS targeting Streamlit's stable CSS classes/`data-
  testid` attributes, not replaced.
