# Component Specifications — Trading Doctor V23

Every component below states: **native or custom** (per Rationale's
decision), the exact selector(s) involved (verified against Streamlit
1.59.0's real rendered DOM — see `06_COMPONENT_INVENTORY.md`'s
verification note), and the token references driving its style. No raw
values — everything cites `02_FOUNDATIONS.md`.

## Buttons

**Native** (`st.button`), restyled via CSS targeting the verified
`[data-testid="stBaseButton-primary"]` / `[data-testid="stBaseButton-secondary"]`.

| Property | Primary | Secondary |
|---|---|---|
| Background | `--td-accent` | transparent |
| Border | none | 1px `--td-border-strong` |
| Text | white | `--td-text` |
| Radius | `--td-radius-md` | `--td-radius-md` |
| Padding | `--td-space-2` `--td-space-4` | same |
| Font | `--td-text-base`, weight 600 | weight 500 |
| Hover | `--td-accent-hover`, `--td-elevation-1` | `--td-bg-surface-3` |
| Focus | 2px solid `--td-accent` outline, 2px offset (see `04_ACCESSIBILITY.md`) | same |
| Disabled | 40% opacity, no hover/focus change | same |
| Transition | `background 150ms ease-out, box-shadow 150ms ease-out` | same |

A third, **destructive** variant (not a native Streamlit button type) is
defined via a CSS class hook for future use (e.g. a "delete analysis"
action if `RiskEngine`/history management gets a UI later — see
`docs/13_FUTURE_EXTENSIONS.md`): background `--td-negative-solid`, same
shape rules.

## Form Controls & Input Fields

**Native** (`st.text_input`, `st.selectbox`, `st.number_input`, etc.),
restyled via `[data-testid="stTextInputRootElement"]`,
`[data-testid="stSelectbox"]`, and the shared `[data-testid="stWidgetLabel"]`.

| Property | Value |
|---|---|
| Background | `--td-bg-surface-2` |
| Border | 1px `--td-border` |
| Border (focus) | 1px `--td-accent` + `--td-accent-muted` glow (`box-shadow: 0 0 0 3px var(--td-accent-muted)`) |
| Radius | `--td-radius-md` |
| Text | `--td-text`, `--td-text-base` |
| Placeholder | `--td-text-faint` |
| Label | `--td-text-sm`, weight 500, `--td-text-muted`, `margin-bottom: var(--td-space-1)` |
| Padding | `--td-space-2` `--td-space-3` |
| Error state | border `--td-negative`, helper text below in `--td-negative`, `--td-text-xs` |

## Tables

**Native** (`st.dataframe`), restyled via `[data-testid="stDataFrame"]`
and its header row. Streamlit's table is a virtualized canvas-based grid
(`glide-data-grid`) as of 1.59 — **individual cells cannot be styled via
CSS** (they're painted to a `<canvas>`, not real DOM nodes). This is a
real constraint, not a design choice:

- What CSS **can** style: the table's outer container (border, radius,
  shadow — matches Card treatment below), and the sticky header row
  background/border only.
- What CSS **cannot** style: per-cell colors (e.g., coloring a
  profit/loss cell red/green directly inside `st.dataframe`). Where
  per-cell semantic color matters (e.g., a future "recent trades" table
  showing win/loss), the existing, correct approach is
  `pandas.DataFrame.style` (Styler-based conditional formatting), which
  Streamlit does render — a **content-level** decision for whichever
  page owns that table, not a shared-theme change, and therefore out of
  this phase's scope (Rationale: "does not redesign any page's unique
  content"). Documented here so a future page author knows the
  mechanism exists rather than reaching for custom HTML.

| Property | Value |
|---|---|
| Container border | 1px `--td-border`, `--td-radius-md` |
| Header background | `--td-bg-surface-3` |
| Header text | `--td-text-sm`, weight 600, `--td-text-muted` |

## Cards

**Custom** (no native Streamlit equivalent — audit finding #4). The
foundational shared container for KPI widgets, alert-adjacent grouped
content, and any "boxed" section.

| Property | Value |
|---|---|
| Background | `--td-bg-surface-2` |
| Border | 1px `--td-border` |
| Radius | `--td-radius-md` |
| Padding | `--td-space-5` |
| Shadow (rest) | `--td-elevation-1` |
| Shadow (hover, if interactive) | `--td-elevation-2` |
| Title | `--td-text-md`, weight 600, `margin-bottom: var(--td-space-3)` |

## KPI Widgets

**Hybrid**: built as a Card variant, but the number itself reuses
`st.metric`'s semantics conceptually — implemented as custom HTML so the
severity/semantic color system can apply to the delta indicator (native
`st.metric` delta is fixed red/green and not on this token system).

| Property | Value |
|---|---|
| Container | Card, above |
| Label | `--td-text-sm`, `--td-text-muted`, uppercase, `letter-spacing: 0.03em` |
| Value | `--td-text-2xl` on the primary hero KPI (one per page max), `--td-text-xl` for secondary KPIs in a row, always `--td-text-mono` |
| Delta/trend | `--td-text-sm` weight 600, colored via `--td-positive`/`--td-negative`, small triangle icon (Lucide `arrow-up`/`arrow-down`, 12px) |
| Layout | icon (optional, 20px, `--td-text-muted` unless semantic) + label stacked above value, per Card padding |

This directly targets audit finding #1 (severity has no visual encoding)
when the KPI is a behavioral score — see the Severity Badge spec below
for the paired treatment used together on Dashboard-style score cards.

## Charts Styling

Two independent chart-rendering paths exist (`pages/02_Charts.py`'s
Plotly, and `reporting/charts.py`'s matplotlib) — this phase defines one
shared **palette contract** both must draw from, closing the last
open piece of Principle 3 (brand continuity):

| Series meaning | Token | Hex (mode-appropriate) |
|---|---|---|
| Positive/profit | `--td-positive` | per foundations |
| Negative/loss | `--td-negative` | per foundations |
| Neutral/primary series (e.g. equity line) | `--td-accent` | per foundations |
| Gridlines | `--td-border` at 60% opacity | — |
| Axis labels | `--td-text-muted`, `--td-text-sm`, `--td-text-mono` for numeric ticks | — |

`reporting/charts.py` already uses almost this exact palette
(`_COLOR_POS = "#00A67D"`, `_COLOR_NEG = "#E5484D"`, `_COLOR_NEUTRAL =
"#3B6FD4"` — the light-mode values above, confirmed by direct comparison)
— this phase's contribution is formalizing it as a shared, named contract
and extending it to `pages/02_Charts.py`'s Plotly config, which
currently uses Plotly's own default palette (audit: "Default Plotly
theme, not matched to app palette"). See `06_COMPONENT_INVENTORY.md` for
exactly which Plotly `layout` keys this maps to.

## Navigation, Sidebar, Header, Footer

**Custom CSS over native structure** — `app.py`'s `st.sidebar` block and
`st.page_link` calls stay as the mechanism (multipage navigation is a
Streamlit-native concept, not worth reimplementing), restyled and, per
audit finding #2, given a real active-state indicator.

| Element | Treatment |
|---|---|
| Sidebar background | `--td-bg-surface` (one step off canvas, matches Vercel-style panel separation) |
| Sidebar width | Streamlit default (not overridden — avoids fighting responsive collapse behavior) |
| Nav item (default) | `--td-text-muted`, `--td-text-base`, `--td-space-2` `--td-space-3` padding, `--td-radius-sm` |
| Nav item (hover) | `--td-bg-surface-3` background |
| Nav item (**active/current page**) | `--td-accent-muted` background, `--td-accent` text + left border accent 2px — **new, closes audit finding #2** |
| Header | App title area: `--td-text-lg`, weight 700, `--td-space-5` bottom margin before first content section |
| Footer | (Dashboard's existing footer links) `--td-text-sm`, `--td-text-faint`, top border `1px --td-border`, `--td-space-5` top padding |

## Tabs

**Native** (`st.tabs`), restyled via `[data-testid="stTabs"]` /
`[data-testid="stTab"]`.

| Property | Value |
|---|---|
| Tab (inactive) | `--td-text-muted`, no background |
| Tab (active) | `--td-text`, weight 600, `--td-accent` 2px bottom border |
| Tab (hover) | `--td-text` |
| Underline track | 1px `--td-border`, full width |
| Focus | visible focus ring per `04_ACCESSIBILITY.md` |

## Accordions

**Native** (`st.expander`), restyled via `[data-testid="stExpander"]` /
`[data-testid="stExpanderDetails"]`.

| Property | Value |
|---|---|
| Container | Card treatment (border, radius) but `--td-elevation-0` at rest |
| Header | `--td-text-base` weight 500, `--td-space-3` padding, chevron icon rotates 90° on open (Streamlit native behavior, kept) |
| Header hover | `--td-bg-surface-3` |
| Body | `--td-space-4` padding, top border 1px `--td-border` |
## Badges & Tags

**Custom.** The direct fix for audit finding #1 — this is the most
important new component in this phase.

Two variants, same base shape:

| Property | Value |
|---|---|
| Padding | `--td-space-1` `--td-space-3` |
| Radius | `--td-radius-full` (pill) |
| Font | `--td-text-xs`, weight 600, `letter-spacing: 0.02em` |
| Background | semantic/severity **soft-bg** token (see Foundations) |
| Text | matching **soft-text** token |
| Icon (optional, 12px) | leading, `currentColor` |

- **Severity badge**: text = the severity label itself (`Low`/`Medium`/
  `High`/`Critical`, or the Persian equivalent already used in engine
  output — no relabeling), color = severity ramp.
- **Tag**: same shape, neutral coloring (`--td-bg-surface-3` background,
  `--td-text-muted` text) for non-semantic categorical labels (e.g. a
  future evidence-type tag) — kept visually distinct from severity so
  the two concepts (Rationale's "severity ≠ semantic" decision) never
  look interchangeable.

## Alerts

**Hybrid.** Streamlit's native `st.error`/`st.warning`/`st.info`/
`st.success` are **kept as the mechanism** (audit found their semantic
*usage* already correct) and restyled via the verified selectors
`[data-testid="stAlertContentError"]`, `...Warning`, `...Info`,
`...Success` (each nested inside `[data-testid="stAlertContainer"]`).

| Property | Value |
|---|---|
| Background | matching semantic **soft-bg** token |
| Left accent bar | 3px solid, matching semantic solid color |
| Text | matching semantic **soft-text** token |
| Radius | `--td-radius-md` |
| Icon | Streamlit's native icon is kept (already present, already correctly mapped per alert type) — recolored to match via `currentColor` inheritance |
| Padding | `--td-space-3` `--td-space-4` |

## Toasts

**Native** (`st.toast` — verified present directly in the 1.30.0 wheel,
i.e. safely within this project's pinned `>=1.30` floor; the exact
version it was first introduced wasn't separately checked since 1.30
availability is all that matters here). Not currently used anywhere in
the codebase (audit: no toast usage found) — defined here as the
standard mechanism for the ephemeral-confirmation use case
`docs/13_FUTURE_EXTENSIONS.md` anticipates (e.g., "report copied,"
"analysis saved" once history/persistence exists), restyled via
`[data-testid="stToast"]` using the same Alert token mapping above so a
toast and an inline alert of the same severity look related.

## Dialogs & Modals

**Native** (`st.dialog`, verified via direct version bisection to have
been introduced in Streamlit **1.34.0** — not a round-number guess).
This project's `requirements.txt` pins `streamlit>=1.30,<2.0`, which
**does not guarantee `st.dialog` availability** (confirmed absent in
1.30.0-1.33.x). This is flagged directly in
`06_COMPONENT_INVENTORY.md` as an action item: either bump the minimum
pin to `>=1.34` if modals are adopted, or treat `st.dialog` as
conditionally-used only on pages that need it, with a version-guarded
fallback. Not resolved silently — a real tradeoff for you to confirm
before implementation touches any page that would use it), restyled via
`[data-testid="stDialog"]`.

| Property | Value |
|---|---|
| Overlay | `rgba(0,0,0,0.5)` both modes (dark enough to focus attention regardless of theme) |
| Container | `--td-bg-surface`, `--td-radius-lg`, `--td-elevation-4` |
| Max-width | 560px (matches a comfortable reading measure, not full-bleed) |
| Padding | `--td-space-6` |
| Title | `--td-text-lg`, weight 700 |

## Tooltips

**Native** (`help=` parameter, present on most Streamlit widgets;
renders via `[data-testid="stTooltipHoverTarget"]` — verified selector).
Directly fixes audit finding #5 (truncated diagnosis text with no way to
see the full string): the truncation pattern
(`_primary_text[:25] + "..."`) gets a paired `help=_primary_text` (full
untruncated text) wherever it's used — a **shared-component-level fix**
(the truncation helper itself, not each page's unique content) since
truncation-with-no-fallback is a pattern repeated across multiple pages,
not a one-page bug.

| Property | Value |
|---|---|
| Background | `--td-bg-surface-3` (dark) / `#1E2430` (light — inverted for legibility, matches Notion/Linear's convention of a dark tooltip even in light mode) |
| Text | `--td-text` (dark) / white (light) |
| Radius | `--td-radius-sm` |
| Shadow | `--td-elevation-3` |
| Max-width | 280px, wraps |

## Progress Indicators

**Native** (`st.progress`), restyled via `[data-testid="stProgress"]` /
`[data-testid="stProgressBarTrack"]`.

| Property | Value |
|---|---|
| Track | `--td-bg-surface-3` |
| Fill (default) | `--td-accent` |
| Fill (semantic variant, e.g. a severity-linked progress bar) | matching severity **solid** token — a new usage this system enables (previously every progress bar was accent-blue regardless of what it measured; e.g. Dashboard's discipline-score bar can now go green→red as the score itself does, doubling down on Principle 4) |
| Height | 8px |
| Radius | `--td-radius-full` |

## Empty States

**Custom.** Directly fixes audit finding #7 (ad hoc, inconsistent empty
handling).

| Property | Value |
|---|---|
| Container | centered, `--td-space-7` vertical padding |
| Icon | 48px, `--td-text-faint`, monochrome (Lucide, per Foundations) |
| Title | `--td-text-md`, weight 600, `--td-text-muted` |
| Description | `--td-text-sm`, `--td-text-faint`, max-width 360px, centered |
| Optional action | Secondary button, per Button spec |

Standard copy pattern (Persian, matching existing tone): icon + "داده‌ای
برای نمایش موجود نیست" + one-line context-specific reason, replacing
each page's currently-improvised handling with one shared
`empty_state()` component (see `06_COMPONENT_INVENTORY.md` /
implementation).

## Loading States & Skeleton Loaders

**Spinner: native** (`st.spinner`, present since well before this
project's `>=1.30` pin). **Skeleton: custom**, not native — corrected
after actually checking: `st.skeleton` was verified (by downloading and
inspecting each Streamlit release's `__init__.py` directly, not
guessing) to have been introduced in Streamlit **1.59.0 exactly** — the
single currently-installed version, and *not present* in any earlier
1.3x/1.4x/1.5x release checked (1.30 through 1.58 all lack it). Relying
on it "natively" would make skeleton loaders silently unavailable for
nearly this entire project's stated compatibility range
(`streamlit>=1.30,<2.0`). A plain CSS shimmer `<div>` needs no Streamlit
API at all and is more robust than depending on a one-patch-old feature
— the more conservative, correct choice given the facts, not the
original assumption. Directly fixes audit finding #6 (no loading
indicator when navigating into a chart-heavy page).

| Property | Value |
|---|---|
| Skeleton fill | `--td-bg-surface-3`, animated shimmer gradient sweeping to `--td-bg-surface-2` |
| Animation | 1.5s linear infinite (the one deliberate exception to Principle 6's "no ambient animation" — a loading indicator's entire purpose is showing continued activity, so motion here is functional, not decorative) |
| Spinner | Streamlit native, recolored to `--td-accent` via its verified selector |

*(If the project's minimum pin is ever raised to `>=1.59`, `st.skeleton`
becomes a valid drop-in alternative to the custom shimmer — noted here,
not acted on, since bumping the floor of a dependency range that far is
a decision beyond this design phase's scope.)*

## Error States & Success States

Not a new component — a **usage convention** combining Alert (§Alerts)
+ Empty State layout for full-page failures (e.g., analysis failed to
load), and Badge/inline-Alert for field/row-level errors and
confirmations. Documented here as the explicit mapping so a future page
doesn't invent a fifth pattern:

| Scenario | Component to use |
|---|---|
| Full page can't render (no data, failed analysis) | Empty State, with `--td-negative`-toned icon if it's a genuine error vs. neutral if it's "just no data yet" |
| Inline validation error (a form field) | Form Control error state (§Form Controls) |
| Action confirmation ("saved," "copied") | Toast |
| Persistent page-level status | Alert |
