# Phase 9 — Persistent SaaS Workspace

> Transform the in-memory `AnalysisStore` (Phase 3) into a DB-backed repository
> pattern with per-user isolation. Every user now has their own private
> workspace: uploads, analyses, favorites — all scoped by `user_id`.

This document describes the architectural changes, new modules, and migration
path introduced in Phase 9.

---

## 1. What Changed

### Before (Phase 3 → Phase 8)
- `AnalysisStore` was an in-memory dict with on-disk upload bytes
- No `user_id` scoping — uploads and analyses were global
- Auth was via shared API key (X-API-Key header)
- History was lost on process restart
- Multi-worker deployment broke the in-memory contract

### After (Phase 9)
- DB-backed repository pattern: `Upload`, `Analysis`, `AnalysisReportCache`,
  `Favorite` tables in PostgreSQL (or SQLite for tests)
- Every query filters by `user_id` — multi-tenant isolation is structural
- Auth is JWT-based (`get_current_user` dependency)
- All state survives process restarts
- Multi-worker safe (no in-process state)

### Breaking Changes
- **`POST /uploads`** now requires `Authorization: Bearer <token>` (was X-API-Key)
- **`POST /analyses`** now requires `Authorization: Bearer <token>`
- **`GET /analyses/{id}`** now requires auth + returns 404 if the analysis
  belongs to another user (anti-enumeration: 404 not 403)
- **`GET /history`** now requires auth + returns only the caller's analyses
- **`upload_id`** and **`analysis_id`** are now UUIDs (was hex strings)
- **`X-API-Key`** auth still works for service-to-service, but user-scoped
  endpoints additionally require JWT

---

## 2. New Modules

### `workspace/` package

```
workspace/
├── __init__.py
├── models.py                          # ORM: Upload, Analysis, AnalysisReportCache, Favorite
├── schemas.py                         # Pydantic: UploadItem, AnalysisItem, FavoriteItem, etc.
├── repositories/
│   ├── __init__.py
│   ├── uploads.py                     # create_upload, get_upload_by_id, list_uploads, ...
│   ├── analyses.py                    # run_and_persist_analysis (THE engine call), list_analyses, ...
│   └── favorites.py                   # add_favorite, remove_favorite, is_favorite, ...
├── services/
│   ├── __init__.py
│   ├── storage.py                     # LocalStorageBackend + S3StorageBackend (stub)
│   └── serialization.py               # pickle + zlib compression for engine outputs
└── routers/
    ├── __init__.py
    └── workspace.py                   # /workspace/summary, /workspace/uploads, /workspace/analyses, /workspace/favorites
```

### Database migration

`alembic/versions/0003_phase9_workspace.py` creates 4 new tables:

| Table | Purpose |
|---|---|
| `uploads` | Per-user upload metadata (filename, size, storage_path, content_hash, label) |
| `analyses` | Per-user analysis results (pickled engine outputs + cached scalar fields) |
| `analysis_report_cache` | Cached HTML/PDF renders keyed by `analysis_id` |
| `favorites` | User's starred analyses (unique constraint on user_id + analysis_id) |

### Updated existing files

| File | Change |
|---|---|
| `api/routers/uploads.py` | Now requires `get_current_user`; persists via `create_upload` |
| `api/routers/analyses.py` | Now requires `get_current_user`; runs engine via `run_and_persist_analysis` |
| `api/routers/reports.py` | Now requires `get_current_user`; caches HTML/PDF in DB |
| `api/routers/history.py` | Now requires `get_current_user`; lists user's analyses |
| `api/main.py` | Registers `workspace_router` |
| `api/exceptions.py` | Adds `FavoriteNotFoundError` |
| `db/models.py` | Imports `workspace.models` for Alembic autogenerate |
| `db/base.py` | `get_db` reads `async_session_factory` lazily (enables testing); SQLite URL support |

---

## 3. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  FastAPI Routes (all require get_current_user)              │
│                                                              │
│  POST /uploads               → UploadRepository.create       │
│  POST /analyses              → AnalysisRepository.run_and_persist │
│  GET  /analyses/{id}         → AnalysisRepository.get_by_id  │
│  GET  /analyses/{id}/report  → AnalysisRepository.get_engine_outputs │
│  GET  /analyses/{id}/report.html → cache → render → cache    │
│  GET  /analyses/{id}/report.pdf  → cache → render → cache    │
│  GET  /history               → AnalysisRepository.list       │
│                                                              │
│  GET    /workspace/summary            → KPIs                 │
│  GET    /workspace/uploads            → UploadRepository.list│
│  GET    /workspace/uploads/{id}       → UploadRepository.get │
│  PATCH  /workspace/uploads/{id}       → UploadRepository.rename │
│  DELETE /workspace/uploads/{id}       → UploadRepository.soft_delete │
│  GET    /workspace/analyses           → AnalysisRepository.list (search/sort/filter) │
│  PATCH  /workspace/analyses/{id}      → AnalysisRepository.rename │
│  DELETE /workspace/analyses/{id}      → AnalysisRepository.soft_delete │
│  POST   /workspace/analyses/{id}/favorite  → FavoriteRepository.add │
│  DELETE /workspace/analyses/{id}/favorite  → FavoriteRepository.remove │
│  GET    /workspace/favorites          → FavoriteRepository.list │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Repositories (async, SQLAlchemy 2.0)                       │
│                                                              │
│  UploadRepository          AnalysisRepository               │
│    create_upload             run_and_persist_analysis ◄──┐   │
│    get_upload_by_id          get_analysis_by_id          │   │
│    list_uploads              get_engine_outputs          │   │
│    rename_upload             list_analyses (search/sort)  │   │
│    soft_delete_upload        rename_analysis              │   │
│    count_user_uploads        soft_delete_analysis         │   │
│    total_user_upload_bytes   get_cached_report            │   │
│                              save_cached_report           │   │
│  FavoriteRepository          count_user_analyses          │   │
│    add_favorite              avg_user_score               │   │
│    remove_favorite                                        │   │
│    is_favorite                                            │   │
│    list_favorites                                         │   │
│    count_favorites                                        │   │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Storage + Serialization                                    │
│                                                              │
│  StorageBackend (local | s3)    Serialization               │
│    save(path, data)              serialize_engine_outputs   │
│    load(path)                    deserialize_engine_outputs │
│    delete(path)                  (pickle + zlib)            │
│    exists(path)                                              │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  ⚠️  ENGINE CALL (single integration point) ⚠️              │
│                                                              │
│  workspace.repositories.analyses.run_and_persist_analysis:  │
│    doctor, result, coach = analyze_dataframe(df, llm) ──────┼──┐
│                                                              │  │
│  This is the ONLY call to the frozen V23 engine.            │  │
│  Tested by test_only_engine_call_is_in_analyses_repository. │  │
└─────────────────────────────────────────────────────────────┘  │
                           │                                       │
                           ▼                                       │
                    ┌─────────────┐                                │
                    │  V23 Engine │ ◄──────────────────────────────┘
                    │  (FROZEN)   │
                    └─────────────┘
```

---

## 4. Multi-Tenant Isolation

Every repository method takes `user_id` as its first parameter. There is NO
way to fetch another user's data through the public API:

```python
# UploadRepository
async def get_upload_by_id(db, user_id, upload_id):
    stmt = select(Upload).where(
        Upload.id == upload_id,
        Upload.user_id == user_id,        # ← always filtered
        Upload.deleted_at.is_(None),
    )
```

When a user requests an analysis that doesn't belong to them, the API
returns **404** (not 403). This is intentional anti-enumeration: an attacker
cannot distinguish "doesn't exist" from "belongs to someone else."

### Test coverage

`tests/test_phase9_workspace.py::TestUploadRepository::test_get_upload_isolates_by_user`
and similar tests verify this isolation is enforced for every repository.

---

## 5. Storage Abstraction

File uploads are stored via a pluggable backend:

| Backend | When to use | Status |
|---|---|---|
| `LocalStorageBackend` | Default; dev + single-instance prod | ✅ Implemented |
| `S3StorageBackend` | Multi-instance prod; Phase 11+ | Stub (raises until boto3 installed) |

Switch via `STORAGE_BACKEND=local|s3` env var.

### Path traversal protection

`LocalStorageBackend._resolve(path)` explicitly rejects:
- Absolute paths (`/etc/passwd`)
- Paths that escape the root via `../../`

Tested by `TestStorageBackend::test_local_backend_rejects_path_traversal`.

---

## 6. Engine Output Serialization

The V23 engine produces three outputs:
1. `doctor` — `BehaviorEngine` instance with embedded DataFrame
2. `result` — `FullResult` dataclass
3. `coach` — dict from `CoachingEngine`

These are NOT JSON-serializable without losing the engine contract. We use
**pickle + zlib compression** for DB storage.

### Security

Pickle is safe here because:
- We ONLY store our own engine output
- We never pickle user-controlled structures
- The engine's outputs are deterministic Python objects

The deserialization (`pickle.loads`) only runs on bytes we wrote ourselves.

### Compression

zlib level 6 typically achieves 5-10× compression on engine outputs
(DataFrames compress very well due to repetitive column dtypes).

---

## 7. Report Caching

The first request for `/analyses/{id}/report.html` (or `.pdf`) renders fresh
and caches the bytes in `analysis_report_cache`. Subsequent requests return
the cached bytes without re-running reportlab (which is CPU-heavy).

Cache invalidation:
- Automatic when the analysis is soft-deleted (FK CASCADE)
- Manual: bump `cache_version` in `AnalysisReportCache` model to invalidate
  all caches on next request

---

## 8. Migration Guide

If you have an existing Phase 8 deployment:

1. **Apply the migration:**
   ```bash
   alembic upgrade head
   ```

2. **Update your `.env`:**
   - No new required vars (storage defaults to local)
   - Optional: `STORAGE_BACKEND=local` (explicit)

3. **Update API clients:**
   - All `/uploads`, `/analyses`, `/reports`, `/history` endpoints now
     require `Authorization: Bearer <token>` instead of `X-API-Key`
   - `upload_id` and `analysis_id` are now UUIDs (not hex strings)

4. **Existing data:**
   - Phase 8 had no user-scoped uploads/analyses (in-memory only), so
     there's nothing to migrate. The new tables start empty.

---

## 9. Test Coverage

`tests/test_phase9_workspace.py` — 24 tests covering:
- Storage backend (path traversal, save/load/delete)
- Serialization round-trip + compression
- Upload repository (create, get, list, rename, soft-delete, isolation)
- Analysis repository (run+persist, get, list with search/sort/filter, isolation)
- Favorite repository (add, remove, is_favorite, count, isolation)
- Report cache (miss → hit, isolation)
- Engine immutability (workspace/ never imports engines/; single engine call)

`tests/test_api.py` — rewritten for Phase 9 with 23 tests covering:
- Full flow: upload → analyze → JSON/HTML/PDF report → history (with auth)
- All HTTP error codes (404, 413, 422, 429, 401) under new auth
- Multi-tenant isolation (User A cannot access User B's data)
- Workspace endpoints (summary, list, favorites, rename, delete)
- Rate limiting with auth
- No traceback leakage

Total: **178 tests passing** (48 from Phase 7.5 + 78 from Phase 8 + 24 new
Phase 9 + 28 rewritten Phase 3→9).

---

## 10. Known Limitations + Future Work

| Item | Phase | Notes |
|---|---|---|
| S3 storage backend | 11 | Stub raises NotImplementedError; needs boto3 |
| Async `POST /analyses` (job queue) | 11 | Currently sync via `run_in_threadpool`; fine for single-instance |
| Per-user storage quota | 10 | Will be enforced via subscription tier |
| Report cache TTL | future | Currently infinite until analysis updated; could add LRU |
| Hard delete + file cleanup | 11 | Soft-deleted uploads' files remain on disk until cleanup cron |
| Workspace export (ZIP) | future | Bundle all analyses + reports for download |
