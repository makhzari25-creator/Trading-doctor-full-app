# Troubleshooting Guide

Real issues actually encountered (and fixed) during this project's
development, plus how to recognize and resolve them if they resurface —
e.g. in a fresh environment, after a dependency upgrade, or if a fix is
accidentally reverted.

## Installation / startup

### `ModuleNotFoundError: No module named 'streamlit'` (or `plotly`, `openpyxl`, etc.)
**Cause**: an incomplete `requirements.txt` install, or a stale
`requirements.txt` from before Phase 1 (which originally listed only
`pandas`/`numpy`/`requests` — the app couldn't even start). **Fix**:
`pip install -r requirements.txt` against the current file; verify with
`pip show streamlit plotly reportlab fastapi`.

### App crashes immediately on startup with a `ValueError` from `config.py`
**Cause**: an environment variable meant to be numeric was set to a
non-numeric value (e.g. `TRADING_DOCTOR_LLM_TIMEOUT=abc`). **Should not
happen** as of Phase 1 — `config._safe_int`/`_safe_float` catch this and
log a warning instead of crashing. If you see this, it means a config
value is being parsed with a raw `int()`/`float()` call somewhere instead
of the safe helpers — search for the offending line and fix it to match
the pattern in `config.py`.

## File upload / analysis

### "هیچ ستون مالی (سود/زیان) یا زمانی قابل‌شناسایی در این فایل پیدا نشد"
**Cause**: `utils/column_mapper.py` couldn't match any column to
`Profit`/`Size`/`Open Time` — the file genuinely lacks recognizable
trading data, or uses column names too far from any known broker
convention. **Fix**: check the exact column names the error message lists
(it always shows what it found), and either rename columns to match a
standard export, or extend `ColumnMapper`'s alias/fuzzy-match list.

### CSV loads with garbled/wrong columns
**Cause** (historical, fixed in Phase 1): `utils/file_loader.py` used to
try pandas' delimiter auto-sniffing *before* common explicit delimiters,
which could misdetect a random character as the separator on short/
ambiguous files. **Current behavior**: explicit delimiters (`,`, `;`,
tab, `|`) are tried first; auto-sniff is the last resort. If this
resurfaces, check that ordering hasn't been changed, and see
`tests/test_file_loader.py` for the regression test.

### Analysis "succeeds" but numbers look wrong for a specific broker export
**Cause**: likely a column-mapping mismatch that wasn't fatal (e.g. `Size`
mapped to the wrong column) but also wasn't caught by validation.
**Fix**: check `doctor.data_quality_warnings` first — many near-misses
surface there. If not, trace via `docs/08_DATA_FLOW.md`'s flow #1,
checking `ColumnMapper.normalize()`'s output directly against the raw
file.

## Reporting (HTML/PDF)

### Persian text in the PDF renders as blank boxes (tofu, `■`)
**Cause**: this was a severe, real bug found in Phase 2 — reportlab's
default font (Helvetica) has zero Persian/Arabic glyph coverage.
**Current fix**: the bundled Vazirmatn font
(`reporting/fonts/Vazirmatn-{Regular,Bold}.ttf`) is registered and used
for all PDF text. **If this resurfaces**: check that the `fonts/`
directory was actually packaged/deployed alongside `reporting/` — it's a
binary asset, not a pip dependency, and is easy to accidentally exclude
from a deployment archive or `.gitignore`. Verify with:
```python
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont("Vazirmatn", "reporting/fonts/Vazirmatn-Regular.ttf"))
```
If this raises `TTFError`, the font file is missing or corrupted.

### An emoji or symbol is missing/blank in the PDF (but Persian text is fine)
**Cause**: the same font-coverage issue as above, but for a specific
character rather than the whole script — Vazirmatn has no emoji glyphs.
**Current behavior**: `reporting/pdf_report.py::_rtl()` silently strips
any character not in the font's actual glyph coverage (a general safety
filter, not a hardcoded list) — so this should never crash, only cause a
character to be missing from the PDF (present correctly in the HTML
version, which uses the browser's system fonts). If a specific missing
character matters, either avoid it in PDF-bound text, or bundle a font
with broader coverage.

### HTML report shows `Undefined` or raises a Jinja2 error
**Cause**: `reporting/html_report.py` uses `StrictUndefined` deliberately
— a missing context key fails loudly at render time instead of silently
producing a blank section. This is usually a real bug: either
`reporting/data_context.py::build_report_context()` doesn't populate a
key a template expects, or a template typo'd a key name. **Fix**: the
error message names the exact missing attribute — cross-reference
against `build_report_context()`'s returned dict keys.

### PDF/HTML report generation is slow or times out
**Check dataset size first** — verified to handle 25,000 rows in ~1
second per format (Phase 2 measurement). If much slower, check whether
`reporting/charts.py::_MPL_LOCK` is being held by a stuck/crashed thread
(restart the process), or whether the bottleneck is actually LLM API
latency (`llm_provider != "none"`), not report rendering.

## REST API

### `POST /api/v1/analyses` returns FastAPI's default `{"detail": [...]}` instead of the unified `{"error": {...}}` shape
**Cause** (historical, fixed in Phase 3): `RequestValidationError` wasn't
registered with a custom handler, so FastAPI's built-in one took over.
**Current fix**: `api/main.py::handle_request_validation_error` is
registered explicitly. If this resurfaces after a FastAPI upgrade or a
refactor of `api/main.py`, check that handler registration wasn't
dropped — see `tests/test_api.py::test_request_validation_error_uses_unified_envelope`,
which exists specifically to catch this regression.

### Rate limit or history behaves inconsistently across requests
**Cause**: very likely running with `--workers > 1` — the rate limiter
and analysis store are both per-process, in-memory. **This is a known,
documented limitation**, not a bug to chase — see
`docs/04_DEPLOYMENT.md`'s "What multi-worker deployment changes" section
for the full explanation and the fix (swap to a shared Redis/DB backend).

### `GET /api/v1/analyses/{id}` returns 404 for an analysis you're sure exists
Two possible causes:
1. **Multi-worker deployment** (see above) — the analysis was created on
   a different worker process.
2. **Store eviction** — the store is bounded
   (`TRADING_DOCTOR_API_MAX_ANALYSES`, default 500); the oldest record is
   evicted once the cap is exceeded. Check server logs for `"Evicted old
   analysis (store full)"`.

### Concurrent requests don't seem faster than sequential
**This is expected, not a bug** — see `docs/04_DEPLOYMENT.md`'s detailed
explanation. Python's GIL prevents true CPU parallelism via threading
regardless of core count; `run_in_threadpool` buys event-loop
responsiveness (verified: health checks stay fast under load), not
throughput. Use multiple worker processes for real throughput scaling.

## Tests

### `tests/test_reporting.py` or `tests/test_api.py` fails only in a specific environment
Check font/library availability first (`arabic_reshaper`, `python-bidi`,
`fonttools`, `reportlab` versions) — these are the most environment-
sensitive dependencies in the project (Phase 2's font bug was originally
invisible until PDF text was actually extracted and inspected, not just
"rendered without crashing"). Re-run just the failing test with `-v` for
the specific assertion, and check whether it's one of the "regression
test" functions (docstring will say so) — those exist because a similar-
looking environment produced a real bug before.

### A test passes alone but fails when run with the full suite
Almost certainly shared global state leaking between tests (a real bug
class found in this project's own test suite — see
`docs/10_CODING_STANDARDS.md`'s "what not to do" section). Check for a
`monkeypatch.setattr` that should be used instead of a direct module-
global assignment, and check the `client` fixture in `tests/test_api.py`
resets shared singletons (`_store`, `_rate_limiter`) between tests.
