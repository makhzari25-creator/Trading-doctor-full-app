# Configuration Guide

Configuration is deliberately split into two independent files that never
import from each other:

- **`config.py`** — engine/LLM configuration. Used by `engines/`,
  `core/service.py`, `llm/`. The Streamlit app and CLI read this directly.
- **`api/config.py`** — API-only configuration (auth, rate limiting,
  upload size, CORS). Used only by `api/`.

This split exists because the engine must never know about HTTP concepts
(API keys, rate limits) — see `docs/01_ARCHITECTURE.md`.

Both files parse environment variables through safe helpers
(`config._safe_int`/`_safe_float`) that log a warning and fall back to the
documented default on a malformed value, rather than crashing the whole
process at import time (a real bug found and fixed in Phase 1 — see
`CHANGELOG_V23.md` bug #6).

## Engine configuration (`config.py`)

### LLM provider selection and credentials

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_LLM_PROVIDER` | `gemini` | Default provider: `gemini`/`openai`/`claude`/`none` |
| `GEMINI_API_KEY` | *(none)* | Required if using the Gemini provider |
| `GEMINI_MODEL` | `gemini-2.0-flash` | Gemini model name |
| `OPENAI_API_KEY` | *(none)* | Required if using the OpenAI provider |
| `OPENAI_MODEL` | `gpt-4o-mini` | OpenAI model name |
| `ANTHROPIC_API_KEY` | *(none)* | Required if using the Claude provider |
| `CLAUDE_MODEL` | `claude-sonnet-4-5` | Claude model name |
| `TRADING_DOCTOR_LLM_TIMEOUT` | `30` | HTTP timeout (seconds) for LLM calls |
| `TRADING_DOCTOR_LLM_MAX_TOKENS` | `1000` | Max tokens requested from the LLM |

If no key is set for the selected provider, `CoachingEngine` logs a
warning and falls back to a template-based explanation — this is
intentional graceful degradation, not a failure mode requiring
intervention (see `docs/01_ARCHITECTURE.md` → "LLM coaching layer").
`llm_provider="none"` (used throughout the test suite and CLI examples in
this documentation) skips the LLM call entirely and always uses the
fallback — useful for fast, deterministic local runs.

### Behavioral thresholds — ⚠️ defined but not yet wired up

`config.py` defines three threshold constants, explicitly commented
`"برای استفاده‌ی آینده"` (**"for future use"**) in the source:

| Variable | Default | Intended purpose |
|---|---|---|
| `TRADING_DOCTOR_OVERTRADING_THRESHOLD` | `5` | Trades/day intended to count as overtrading |
| `TRADING_DOCTOR_RISK_SIZE_MULTIPLIER` | `1.5` | Intended size-increase ratio for risk scoring |
| `TRADING_DOCTOR_QUICK_REENTRY_MIN` | `15` | Intended re-entry gap for FOMO detection |

**Verified by grep: none of these three are currently read by any engine.**
The actual thresholds the engine uses today are hardcoded as literal
values directly in `engines/behavior_engine.py` and
`utils/sequence_analysis.py` (e.g. revenge-streak minimum of 2 consecutive
losses, 1.05x size-increase, 15-minute quick-reentry window happens to
match the config default by coincidence, not by being read from it).

**This means setting these three environment variables today has zero
effect on scoring** — a real trap for anyone tuning behavior via
config expecting these to work. If you need to change a threshold, edit
the literal value in the engine file directly (and re-run
`tests/test_sequence_analysis.py` to confirm the vectorized helper still
matches expected behavior). Wiring these constants into the engines that
already define matching literals is a good, low-risk first task for
someone new to the codebase — see `docs/13_FUTURE_EXTENSIONS.md`.

### Logging

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_LOG_LEVEL` | `INFO` | `DEBUG`/`INFO`/`WARNING`/`ERROR` |

## API configuration (`api/config.py`)

### Authentication

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_KEYS` | *(empty → auth disabled)* | Comma-separated valid keys. Setting this is what turns auth on — no separate boolean flag. |

### Rate limiting

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_RATE_LIMIT_ENABLED` | `true` | Toggle rate limiting entirely |
| `TRADING_DOCTOR_API_RATE_LIMIT_RPM` | `60` | Requests/minute/client |

### Upload limits

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_MAX_UPLOAD_MB` | `25` | Max upload size (413 above this) |

### Store bounds (memory/disk leak prevention)

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_MAX_ANALYSES` | `500` | In-memory analysis-record cap (LRU eviction) |
| `TRADING_DOCTOR_API_MAX_UPLOADS` | `1000` | On-disk upload-file cap (LRU eviction) |

These exist specifically because early Phase 3 had no bound at all — a
long-running server would accumulate every analysis (full DataFrame
included) forever. See the Phase 3 self-review for how this was found.

### CORS and pagination

| Variable | Default | Purpose |
|---|---|---|
| `TRADING_DOCTOR_API_CORS_ORIGINS` | `*` | Comma-separated allowed origins |
| `TRADING_DOCTOR_API_HISTORY_PAGE_SIZE` | `20` | Default `/history` page size (max 100) |

## Configuration precedence and safety

- Every value has a sane default; nothing is required to run locally.
- Malformed numeric env vars never crash the process — they log a
  warning and use the default (Phase 1 fix, applies to both config files
  via the shared `_safe_int`/`_safe_float` helpers).
- Secrets (`*_API_KEY`, `TRADING_DOCTOR_API_KEYS`) are never logged, never
  included in the `/api/v1/config` endpoint response, and never appear in
  the OpenAPI schema — verified by an automated test
  (`tests/test_api.py::test_openapi_schema_has_no_leaked_internals`).

## Changing configuration for a new deployment environment

There is no `.env` file loading built in (no `python-dotenv` dependency).
Set variables through your process manager / container orchestrator /
shell profile. If `.env` file support is wanted, see
`docs/13_FUTURE_EXTENSIONS.md`.
