# Trading Doctor V23 — Phase 2 Changelog: Reporting Module

Scope (approved plan, Option 1): production-grade HTML + PDF reporting,
sharing one rendering pipeline, modular and reusable, analytical engine
untouched. Reportlab chosen for PDF (no system-binary dependency),
optional CLI export flags added, Technical Appendix kept summary-only.

## 1. What "repair the rendering pipeline" meant here

Phase 2 is net-new code — there was no pre-existing reporting pipeline
to literally repair (the only prior artifact was a disabled placeholder
button in `pages/08_Report.py`). I read the instruction as: build the
pipeline correctly the first time and prove it, rather than assume it
works. In practice this meant running the real end-to-end pipeline
against 6+ edge-case datasets before considering any part "done" — and
it did catch one real bug (below), which is exactly the kind of thing
this verification step exists to catch.

## 2. Architecture delivered

```
reporting/
├── data_context.py   # ONE shared context builder — both HTML and PDF
│                       read from this, so they can never show different
│                       numbers for the same analysis
├── charts.py          # 8 matplotlib chart generators, return PNG bytes,
│                       shared by both renderers (identical images)
├── html_report.py      # Jinja2 → self-contained HTML (inline CSS,
│                       charts as base64 data URIs, no external files)
├── pdf_report.py        # reportlab Platypus → PDF bytes (pure Python,
│                       independent layout, same data + same chart PNGs)
└── __init__.py           # public API: generate_html_report(),
                          generate_pdf_report(), ReportRenderError

templates/                # the previously-empty, reserved folder — now used
├── report.html
└── partials/              # 15 files, one per requested report section
```

Adding a 16th section later means: one new partial file + one new key
in `data_context.py` + one new `{% include %}` line + one new PDF story
block — no changes to the rendering engine itself. That's the "future
sections without rewriting the renderer" requirement.

## 3. Bug found and fixed during verification

`BehaviorEngine._simulate_what_if()` returns a dict with key `"note"`
when there are zero revenge trades to simulate, but with key
`"disclaimer"` otherwise. The first What-If template draft accessed
`.disclaimer or .note` assuming Python's short-circuit `or` — but with
Jinja2's `StrictUndefined` (intentionally enabled so missing data fails
loudly instead of silently rendering a blank section), the first
missing attribute raises immediately rather than falling through. Found
via the 6-case edge-case suite (specifically the 3-trade, no-revenge
case), fixed with `.get('disclaimer') or .get('note') or ''`, re-verified
across all edge cases afterward.

## 4. Why reportlab over wkhtmltopdf (per your approval)

`wkhtmltopdf` happens to be installed in this environment, but it's a
system binary, not a pip package — most production hosts (slim Docker
images, PaaS platforms) won't have it unless someone installs it at the
OS level, which would make PDF export fail unpredictably at deploy time.
Reportlab is pure Python and installs via `requirements.txt` alone, so
PDF export works wherever the rest of the app works. The tradeoff:
reportlab needs its own layout code (can't reuse the HTML/CSS directly)
— mitigated by having both renderers read the exact same
`data_context.py` output and the exact same chart PNG bytes, so content
never drifts between the two formats even though layout code is
separate (verified by `test_html_and_pdf_share_identical_headline_numbers`).

## 5. No analytical changes

`reporting/` never calls into `BehaviorEngine`, `ScoreEngine`,
`EvidenceEngine`, `DiagnosisEngine`, or `PsychologyEngine` directly —
it only reads the already-computed `FullResult` dataclass and `coach`
dict that `core/service.py` produces (same objects `pages/*.py` already
display). The only "new" numbers anywhere in this module are Strengths/
Weaknesses, and those are a presentational re-bucketing of existing
`severity` labels and `edge_map` best/worst entries already computed by
Phase 1 — plus one industry-standard threshold (Profit Factor ≥ 1.0 =
break-even line), not a new scoring formula. This is documented at the
top of `data_context.py` itself.

Chart math (equity = cumsum(Profit), drawdown = equity − cummax(equity),
hourly/weekday grouping) is identical to what `pages/02_Charts.py`
already computes on-screen — reused, not reinvented.

## 6. Files added

- `reporting/__init__.py`, `data_context.py`, `charts.py`,
  `html_report.py`, `pdf_report.py`
- `templates/report.html` + `templates/partials/_style.css` +
  14 section partials (`_executive_summary`, `_score_overview`,
  `_diagnosis`, `_trader_profile`, `_strengths_weaknesses`,
  `_behavior_analysis`, `_psychology`, `_evidence`, `_statistics`,
  `_performance`, `_risk`, `_charts`, `_recommendations`,
  `_ai_coaching`, `_appendix`)
- `tests/test_reporting.py` — 11 new tests (33 total in the suite now)

## 7. Files modified

- `pages/08_Report.py` — the disabled "PDF (در حال توسعه)" placeholder
  is now a working PDF download; added a working HTML download button
  next to it; both wrapped in try/except showing a clear message on
  failure (never a raw traceback), following the Phase 1 error-handling
  convention. Fixed a stale "V22" label left in the TXT report header
  and page caption while in this file.
- `main.py` — added optional `--export-html PATH` / `--export-pdf PATH`
  flags, reusing the same `reporting/` module (CI/automation parity,
  as you approved).
- `requirements.txt` — added `jinja2`, `reportlab`, `matplotlib`.

## 8. Verification performed

- Full pipeline run against a 150-row realistic dataset: all 15 HTML
  sections present, all 8 charts valid PNGs, PDF valid (`%PDF-` header,
  9 pages).
- 6 edge-case datasets (no time column, single trade, all-wins,
  all-losses, net-zero profit, heavy revenge-trading pattern) — both
  HTML and PDF render without error on every one.
- Visual QA: HTML converted to images and PDF pages converted to images,
  both inspected directly for layout/readability.
- Full Streamlit app booted (`streamlit run app.py`) and confirmed
  HTTP 200 with the new report page wired in.
- `pytest tests/` — 33/33 passing (22 from Phase 1 + 11 new).

## 9. Remaining technical debt / future extension points

- **Dark-mode PDF**: reportlab output is always light-themed (print
  convention); only the HTML report adapts to `prefers-color-scheme`.
  If a dark PDF is ever wanted, `pdf_report.py`'s color constants would
  need a theme parameter.
- **Chart interactivity**: reports use static matplotlib images by
  design (portability for PDF/download); the on-screen Streamlit pages
  keep their existing interactive Plotly charts — these were
  intentionally not unified, since the objectives were about
  export quality, not replacing the live UI.
- **Report branding/logo**: currently text+emoji header; a real logo
  image could be added to both renderers' headers later.
- **i18n**: report text is Persian-only (matching the rest of the app);
  no English variant exists yet.
- **Appendix**: intentionally summary-only, not a per-trade dump (per
  your approval) — a full CSV export remains available separately via
  the existing Trends page.
