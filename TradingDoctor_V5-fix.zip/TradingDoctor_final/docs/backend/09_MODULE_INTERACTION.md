# Module Interaction

While `docs/08_DATA_FLOW.md` traces specific *requests*, this document
shows the static *import/dependency graph* between packages — useful for
answering "can I import X from Y" before writing code, and for spotting
an architectural violation before it's merged.

## Package-level dependency graph

```mermaid
graph TD
    config["config.py"]
    utils["utils/*"]
    llm["llm/*"]
    engines["engines/*"]
    core["core/service.py"]
    reporting["reporting/*"]
    templates["templates/*"]
    api["api/*"]
    pages["pages/*.py + app.py"]
    main["main.py"]
    tests["tests/*"]

    utils --> config
    llm --> config
    engines --> utils
    engines --> llm
    core --> engines
    core --> utils
    reporting --> engines
    reporting --> templates
    api -->|"ONLY via api/services/store.py"| core
    api --> reporting
    api["api/*"] -.->|api/config.py, separate| config
    pages --> core
    pages --> reporting
    main --> core
    main --> reporting
    tests --> everything["all of the above"]

    style engines fill:#fdd,stroke:#900
    style core fill:#fdd,stroke:#900
```

Red = the analytical core. Every arrow into it comes from a small,
specific integration point (`core/service.py`'s two functions,
`api/services/store.py::run_analysis`), never scattered across many
files.

## Rules this graph encodes (and how they're enforced)

| Rule | Enforcement |
|---|---|
| `engines/` never imports `reporting/` or `api/` | Not enforced by a test (would be a circular-import error if violated, since `reporting`/`api` import `engines` — Python would fail at import time) |
| `api/` never imports engine classes directly, only through `store.py` | `tests/test_api.py::test_no_business_logic_duplicated_in_api_layer` (static source-text scan) |
| `reporting/` never recomputes a score | No automated enforcement — a code-review convention, documented in `reporting/data_context.py`'s own module docstring |
| LLM providers (`llm/`) are only called from `engines/coaching_engine.py` | No automated enforcement — see `docs/06_DEVELOPER_GUIDE.md`'s note on debugging this boundary |
| `api/config.py` and `config.py` never import each other | Structural — they're deliberately separate files with no shared import; see `docs/05_CONFIGURATION.md` |

The first two are structurally guaranteed or test-enforced; the latter
two rely on convention and code review. If this project grows a CI
pipeline (see `docs/13_FUTURE_EXTENSIONS.md`), turning "reporting never
recomputes a score" into an automated check (similar to the existing
API-layer test, scanning `reporting/*.py` for score-formula-looking
patterns or direct engine-internal-method calls) would be a good addition.

**One deliberate, narrow exception**: `api/main.py` imports
`FullResult` from `engines/report_engine.py` at module load time (marked
`# noqa: F401` with an inline comment explaining why). This is a boot-time
sanity check that the engine package is importable, not a business-logic
call — `FullResult` is a plain dataclass with no methods, not one of the
five engine classes the static test forbids. Verified directly: `grep`
for actual `get_llm()` calls in the whole codebase returns exactly one
call site, `engines/coaching_engine.py` — the LLM-isolation rule holds.

## Within `engines/`: the internal call graph

```mermaid
graph LR
    BE["BehaviorEngine"] --> SE["ScoreEngine"]
    SE --> EE["EvidenceEngine"]
    EE --> DE["DiagnosisEngine"]
    EE --> PE["PsychologyEngine"]
    DE --> CE["CoachingEngine"]
    PE --> CE
    SE --> CE
    CE --> RE["ReportEngine<br/>(text only)"]
    BE -.->|"facade, not called by SE"| RiskE["RiskEngine"]
```

`ScoreEngine.run()` is the actual orchestration point that produces
`FullResult`; `CoachingEngine.generate()` is called separately (by
`core.service`, not by `ScoreEngine` itself) with that `FullResult` as
input. `RiskEngine` is drawn with a dashed line because — as noted in
`docs/07_ENGINE_REFERENCE.md` — nothing currently calls it in the main
pipeline; it's a tested, working facade waiting to be wired in.

## Within `reporting/`: both renderers share one data source

```mermaid
graph TD
    DC["data_context.py<br/>build_report_context()"]
    CH["charts.py<br/>build_all_charts()"]
    HTML["html_report.py<br/>render_html_report()"]
    PDF["pdf_report.py<br/>render_pdf_report()"]

    DC --> HTML
    DC --> PDF
    CH --> HTML
    CH --> PDF
    HTML --> Jinja["templates/report.html + partials"]
    PDF --> Font["reporting/fonts/Vazirmatn-*.ttf"]
```

This is the concrete structure behind the "HTML and PDF can never show
different numbers" guarantee described in `docs/01_ARCHITECTURE.md` — both
boxes on the right have exactly two incoming arrows, from the same two
boxes on the left.

## Within `api/`: routers never talk to each other

```mermaid
graph TD
    U["routers/uploads.py"] --> Store["services/store.py<br/>AnalysisStore"]
    A["routers/analyses.py"] --> Store
    R["routers/reports.py"] --> Store
    H["routers/history.py"] --> Store
    Store --> service["core.service"]
    R --> reporting["reporting/*"]
    Store --> Models["models/*.py<br/>(response shaping)"]
```

No router imports another router. Shared state (uploads, analyses) only
flows through `AnalysisStore` — this is why the store, not any router, is
the natural place to add caching, swap the backend, or add TTL cleanup
(see `docs/13_FUTURE_EXTENSIONS.md`).
