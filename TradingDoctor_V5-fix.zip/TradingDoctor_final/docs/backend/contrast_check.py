"""Trading Doctor V23 design-system contrast verification script.
Computes WCAG 2.1 relative-luminance contrast ratios directly from the
token hex values in 02_FOUNDATIONS.md. Run this after ANY color token
change before shipping — this is how the two real failures in the first
draft of this system were caught (see 02_FOUNDATIONS.md's note)."""

def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def relative_luminance(rgb):
    def chan(c):
        c = c / 255.0
        return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055) ** 2.4
    r, g, b = (chan(c) for c in rgb)
    return 0.2126*r + 0.7152*g + 0.0722*b

def contrast_ratio(hex1, hex2):
    l1 = relative_luminance(hex_to_rgb(hex1))
    l2 = relative_luminance(hex_to_rgb(hex2))
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)

PAIRS = [
    ("text on bg-canvas (dark)", "#EDEFF2", "#0B0D10", 4.5),
    ("text on bg-canvas (light)", "#1E2430", "#F7F8FA", 4.5),
    ("text-muted on bg-surface-2 (dark)", "#9AA3B0", "#181C22", 4.5),
    ("text-muted on bg-surface-2 (light)", "#5B6472", "#F7F9FC", 4.5),
    ("accent on bg-canvas (dark)", "#6F9BF0", "#0B0D10", 3.0),
    ("accent on bg-surface (light)", "#3B6FD4", "#FFFFFF", 3.0),
    ("white on positive-solid (dark)", "#FFFFFF", "#0F7A56", 4.5),
    ("white on positive-solid (light)", "#FFFFFF", "#00805F", 4.5),
    ("white on negative-solid (dark)", "#FFFFFF", "#B3383C", 4.5),
    ("white on negative-solid (light)", "#FFFFFF", "#C23238", 4.5),
    ("white on warning-solid (dark)", "#FFFFFF", "#7A5A15", 4.5),
    ("white on warning-solid (light)", "#FFFFFF", "#8F6B00", 4.5),
    ("white on severity-high-solid (dark)", "#FFFFFF", "#B3611F", 4.5),
    ("white on severity-high-solid (light)", "#FFFFFF", "#B85A1A", 4.5),
    ("positive-soft-text on white worst-case (light)", "#00734F", "#FFFFFF", 4.5),
    ("warning-soft-text on white worst-case (light)", "#8A6800", "#FFFFFF", 4.5),
    ("severity-high-soft-text on white worst-case (light)", "#A54E12", "#FFFFFF", 4.5),
]

failures = 0
for label, fg, bg, minimum in PAIRS:
    ratio = contrast_ratio(fg, bg)
    status = "PASS" if ratio >= minimum else "FAIL"
    if status == "FAIL":
        failures += 1
    print(f"{status}  {ratio:5.2f}:1  (min {minimum})  {label}")

print()
print(f"{len(PAIRS) - failures}/{len(PAIRS)} pairs pass." + (f"  {failures} FAILURE(S)." if failures else " All pass."))
