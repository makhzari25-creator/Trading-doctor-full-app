# UI Audit — Trading Doctor V23 (Pre-Phase 5A)

Findings from directly reading `app.py` and every file in `pages/` (9
pages), not a general impression. This audit is the basis for every
decision in `01_DESIGN_RATIONALE.md`.

## Current state: zero custom visual design

**Verified**: `grep -rn "unsafe_allow_html\|<style" app.py pages/*.py`
returns nothing. The entire product runs on Streamlit's out-of-the-box
default theme — no custom colors, typography, spacing, or component
styling anywhere. This is the starting point, not a partially-themed
app to patch.

## Component usage inventory (what's actually used today)

| Streamlit primitive | Where | Notes |
|---|---|---|
| `st.metric` | Every page, heavily | The dominant "card" pattern — 4-5 in a `st.columns()` row on Dashboard alone |
| `st.progress` | Dashboard (discipline score bar) | Defensively clamped to `[0,1]` (Phase 1 fix) |
| `st.error` / `st.warning` / `st.info` / `st.success` | All pages, for diagnosis/evidence/status | These are Streamlit's built-in alert components — used correctly semantically, but with zero visual customization |
| `st.expander` | Diagnosis (evidence), Behavioral Analysis (context detail) | Functions as an ad-hoc accordion |
| `st.columns` | Every page | The only layout mechanism used — no grid system, no consistent gutter |
| `st.dataframe` | Edge Map, Trends | Default Streamlit table styling, unthemed |
| `st.page_link` | Sidebar (app.py), Dashboard footer | Plain text + emoji, no active-state indicator for current page |
| `st.divider` | Most pages | Used as the only section-separation mechanism |
| Plotly charts | Charts page | Default Plotly theme, not matched to app palette |
| matplotlib charts | `reporting/charts.py` (PDF/HTML reports only) | Has its own palette (see below) — **not currently shared with the live app** |

## Concrete gaps found (not opinions — things that are objectively missing or inconsistent)

1. **No color-coded severity anywhere in the live app.** `ContextBlock.severity` and `Evidence.severity` are core, recurring concepts (`Low`/`Medium`/`High`/`Critical`) shown on Dashboard, Behavioral Analysis, and Diagnosis — every single instance is plain text (`st.metric`, `st.write`, or baked into an `st.expander` title string). A user scanning the page gets no pre-attentive visual signal for "this is bad" vs "this is fine." This is the single highest-impact gap.
2. **No active-page indicator in the sidebar.** `st.page_link` renders all 9 pages identically regardless of which one is currently open — a basic wayfinding cue missing from every page.
3. **Two unrelated color systems already exist and don't talk to each other.** `reporting/templates/partials/_style.css` (Phase 2) has a real token system (`--accent: #3b6fd4`, `--positive: #00a67d`, `--negative: #e5484d`, dark-mode variant) used only in downloadable HTML/PDF reports. The live Streamlit app uses Streamlit's default theme (Streamlit's own blue, `#FF4B4B` red, etc.) — a user who downloads a PDF report sees different brand colors than the dashboard they just generated it from.
4. **No consistent card/container styling.** Every "section" is `st.subheader()` + content + `st.divider()` — there's no visual grouping (no card background, border, or shadow) to separate, e.g., the "Revenge Trading Warning" block from surrounding content.
5. **Truncation without a tooltip** (Dashboard's diagnosis metric: `_primary_text[:25] + "..."`) — the full text is simply lost, not available on hover.
6. **No loading/skeleton state** beyond the single `st.progress` bar during analysis — page navigation after analysis (e.g., clicking into Charts) has no loading indicator while Plotly renders.
7. **No empty-state design** — pages other than the ones with an explicit `if 'result' not in st.session_state: st.warning(...); st.stop()` guard would show nothing if a sub-condition has no data (e.g., Edge Map when `side_comparison` is empty) — inconsistent, ad hoc per page rather than a shared pattern.
8. **Icon usage is emoji-only** (🩺📊📈📉🔍💡🧬🗺️📄⚠️✅❌🤖🧾), applied inconsistently — some are decorative section markers, some are semantic (⚠️ for warning), with no distinction in weight/size/color.

## What's already good (worth preserving, not replacing)

- **Consistent Persian-first, RTL-correct language** throughout — the new
  design system must not disrupt this; all component specs below are
  written RTL-aware.
- **Phase 2's report CSS token approach** (`--bg`, `--bg-card`, `--text`,
  `--text-muted`, `--border`, `--accent`, `--positive`, `--negative`,
  `--warning`, `--shadow`, `--radius`) is a genuinely good foundation —
  the new system evolves and extends it rather than discarding it, so
  the live app and the downloadable report finally share one identity
  (see Design Rationale §"Brand continuity with Phase 2").
- **Correct semantic use of Streamlit's alert types** (error for primary
  diagnosis, warning for secondary, info for detail) — the *logic* of
  what gets which alert level is sound; only the *visual* layer needs
  work.
- **Defensive clamping and graceful degradation patterns** (Phase 1/2
  work) — nothing in this phase should regress that discipline.

## Consequence for this phase's design system

Because there is no existing visual design to reconcile, this system is
being **defined**, not **migrated**. That removes a whole category of
design-system risk (no legacy inconsistency to bridge) but means every
token and component spec in the documents that follow needs to be
justified from first principles — done in `01_DESIGN_RATIONALE.md`.
