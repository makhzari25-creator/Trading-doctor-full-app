# Design System Foundations — Trading Doctor V23

Every value below is a token — a named, reusable constant. Nothing in
`03_COMPONENTS.md` introduces a new raw color/size value; everything
composes from here. This is the literal source `ui/theme.py`'s CSS is
generated from (see `06_PHASE_5B_IMPLEMENTATION_REPORT.md`).

## Color System

### Neutral scale (surfaces + text) — dark mode (primary)

Layered near-black, not pure black (Vercel-derived — see Rationale
§reference products), so elevation is perceivable through surface color
alone before any shadow is added.

| Token | Value | Use |
|---|---|---|
| `--td-bg-canvas` | `#0B0D10` | App background (behind everything) |
| `--td-bg-surface` | `#12151A` | Page-level containers |
| `--td-bg-surface-2` | `#181C22` | Cards, KPI widgets (one step up from canvas) |
| `--td-bg-surface-3` | `#20252D` | Nested/hover surfaces (e.g. table row hover, popover) |
| `--td-border` | `#262B33` | Default 1px separators |
| `--td-border-strong` | `#333A45` | Emphasized borders (focused input, active tab) |
| `--td-text` | `#EDEFF2` | Primary text |
| `--td-text-muted` | `#9AA3B0` | Secondary text, labels |
| `--td-text-faint` | `#5B6472` | Disabled/tertiary text |

### Neutral scale — light mode

| Token | Value | Use |
|---|---|---|
| `--td-bg-canvas` | `#F7F8FA` | App background |
| `--td-bg-surface` | `#FFFFFF` | Page-level containers |
| `--td-bg-surface-2` | `#F7F9FC` | Cards, KPI widgets |
| `--td-bg-surface-3` | `#EEF1F5` | Nested/hover surfaces |
| `--td-border` | `#E2E6ED` | Default 1px separators |
| `--td-border-strong` | `#C7CEDA` | Emphasized borders |
| `--td-text` | `#1E2430` | Primary text |
| `--td-text-muted` | `#5B6472` | Secondary text, labels |
| `--td-text-faint` | `#8B96A5` | Disabled/tertiary text |

*(These are the exact `--bg`/`--bg-card`/`--text`/`--text-muted`/
`--border` values from `reporting/templates/partials/_style.css`,
carried forward unchanged for light mode — the brand-continuity decision
from the Rationale doc, made concrete.)*

### Brand accent

| Token | Dark | Light | Use |
|---|---|---|---|
| `--td-accent` | `#6F9BF0` | `#3B6FD4` | Primary actions, links, focus rings, active nav |
| `--td-accent-hover` | `#8AAEF3` | `#2F5FC4` | Hover state of accent elements |
| `--td-accent-muted` | `rgba(111,155,240,0.14)` | `rgba(59,111,212,0.10)` | Accent-tinted backgrounds (selected row, active tab background) |

*(Matches `reporting`'s `--accent` exactly, per Principle 3.)*

### Semantic colors (status/action meaning — Stripe-derived discipline: never used decoratively)

Each semantic color has **two forms**, because a single mid-tone value
cannot pass WCAG contrast both as a large-area solid fill (white text on
top) and as a small soft/tinted badge (colored text on a light wash) —
this was discovered by actually computing contrast ratios for the first
draft of this table, not assumed; see the note at the end of this
section.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--td-positive` | `#35C795` | `#00A67D` | Icons, borders, chart lines — not text-on-fill |
| `--td-positive-solid` | `#0F7A56` | `#00805F` | Solid fill + white text (buttons, alert accent bars) |
| `--td-positive-soft-bg` | `#35C795` @ 16% on surface | `#00A67D` @ 14% on surface | Badge/tag background |
| `--td-positive-soft-text` | `#35C795` | `#00734F` | Badge/tag text (light mode uses a darker shade than the "icon" token — see note) |
| `--td-negative` | `#FF6B70` | `#E5484D` | Icons, borders, chart lines |
| `--td-negative-solid` | `#B3383C` | `#C23238` | Solid fill + white text |
| `--td-negative-soft-bg` | `#FF6B70` @ 16% | `#E5484D` @ 14% | Badge/tag background |
| `--td-negative-soft-text` | `#FF6B70` | `#E5484D` | Badge/tag text |
| `--td-warning` | `#E0B13D` | `#B98900` | Icons, borders |
| `--td-warning-solid` | `#7A5A15` | `#8F6B00` | Solid fill + white text |
| `--td-warning-soft-bg` | `#E0B13D` @ 16% | `#B98900` @ 14% | Badge/tag background |
| `--td-warning-soft-text` | `#E0B13D` | `#8A6800` | Badge/tag text |
| `--td-info` | `#6F9BF0` | `#3B6FD4` | Same as accent — intentional, avoids a 5th competing hue |

### Severity ramp — a distinct 4-step scale (Principle 4 / Rationale's "severity ≠ semantic" decision)

This is the system's most important scale — it's what the UI audit found
completely missing. Deliberately visually ordered (green→amber→orange→red)
so severity reads as a *gradient of concern*, not four arbitrary colors.
Same solid/soft split as above, for the same contrast reason.

| Severity | Icon/border | Solid (fill+white text) | Soft bg | Soft text |
|---|---|---|---|---|
| Low (dark/light) | `--td-positive` | `--td-positive-solid` | `--td-positive-soft-bg` | `--td-positive-soft-text` |
| Medium (dark/light) | `--td-warning` | `--td-warning-solid` | `--td-warning-soft-bg` | `--td-warning-soft-text` |
| High — dark | `#F0924A` | `#B3611F` | `#F0924A` @ 16% | `#F0924A` |
| High — light | `#D9691E` | `#B85A1A` | `#D9691E` @ 14% | `#A54E12` |
| Critical (dark/light) | `--td-negative` | `--td-negative-solid` | `--td-negative-soft-bg` | `--td-negative-soft-text` |

**Default treatment for severity/status badges is the soft form**
(tinted background + colored text) — both because it passes contrast
more reliably at small sizes and because it visually matches the
Linear/Notion restraint this system borrows (Rationale §reference
products); the solid form is reserved for buttons and alert accent bars
where the color covers a large enough area to justify full saturation.

### Contrast verification (Principle 7 — checked here, not later)

All pairs below were computed with the WCAG relative-luminance formula
(not estimated) via a small script, specifically because the *first*
version of this table — checked the same way, one iteration earlier —
turned up two real failures (white text directly on the mid-tone
`negative`/`severity-high` values, 2.77:1 and 2.36:1, well under the
4.5:1 AA minimum). That's the reason the solid/soft split above exists
at all: it's a correction, not the original design.

| Pair | Ratio | WCAG |
|---|---|---|
| `--td-text` on `--td-bg-canvas` (dark) | 16.89:1 | AAA |
| `--td-text` on `--td-bg-canvas` (light) | 14.64:1 | AAA |
| `--td-text-muted` on `--td-bg-surface-2` (dark) | 6.71:1 | AA |
| `--td-text-muted` on `--td-bg-surface-2` (light) | 5.67:1 | AA |
| `--td-accent` on `--td-bg-canvas` (dark) | 7.06:1 | AAA |
| `--td-accent` on `--td-bg-surface` (light) | 4.76:1 | AA |
| White on `--td-negative-solid` (dark) | 5.92:1 | AA |
| White on `--td-negative-solid` (light) | 5.52:1 | AA |
| White on `--td-positive-solid` (dark) | 5.33:1 | AA |
| White on `--td-positive-solid` (light) | 4.94:1 | AA |
| White on `--td-warning-solid` (dark) | 6.36:1 | AA |
| White on `--td-warning-solid` (light) | 4.92:1 | AA |
| White on severity-high-solid (dark) | 4.52:1 | AA |
| White on severity-high-solid (light) | 4.65:1 | AA |
| Soft-text on soft-bg, all 4 semantic colors, both modes | 4.10 – 6.24:1 | AA |
| Soft-text on plain surface (worst case, no tint) | 5.17 – 5.92:1 | AA |

Full methodology and the actual verification script's output are in
`04_ACCESSIBILITY_AND_RESPONSIVE.md`.

## Typography Scale

**Font families:**
- UI/body: **Inter** (system-ui fallback stack) — chosen for exceptional
  legibility at small sizes and native RTL/Persian coverage via
  Google Fonts' full Arabic-script subset, avoiding the Phase 2 PDF
  font-coverage bug class entirely (see Rationale — this is a direct
  lesson carried from `reporting/pdf_report.py`'s font saga).
- Numerals/data: **JetBrains Mono** for any figure that's compared
  column-to-column (scores, $ amounts, percentages, streak counts) —
  Principle 5. Notably, this exact font ships in the uploaded
  `ui-ux-pro-max` toolkit's `canvas-fonts/` — reused as a validated,
  well-hinted monospace choice rather than picked arbitrarily.
- Fallback stack: `Inter, "Vazirmatn", -apple-system, "Segoe UI", sans-serif`
  — Vazirmatn included specifically because it's already bundled in
  `reporting/fonts/` for guaranteed Persian coverage if Inter's Arabic
  subset is ever unavailable (offline dev, blocked Google Fonts CDN).

**Scale** (1.25 ratio, Raycast-style — few sizes, used consistently):

| Token | Size | Weight | Line-height | Use |
|---|---|---|---|---|
| `--td-text-xs` | 12px | 500 | 16px | Badges, tags, table meta |
| `--td-text-sm` | 13px | 400 | 20px | Secondary text, captions, labels |
| `--td-text-base` | 14px | 400 | 22px | Body text, table cells (Streamlit's own base is 14px — matched intentionally, not overridden, to avoid fighting native widget metrics) |
| `--td-text-md` | 16px | 500 | 24px | Card titles, form labels |
| `--td-text-lg` | 20px | 600 | 28px | Section headers (`st.subheader` equivalent) |
| `--td-text-xl` | 28px | 700 | 36px | Page titles (`st.title` equivalent) |
| `--td-text-2xl` | 36px | 700 | 44px | Hero KPI numbers (the single most important number on a screen) |
| `--td-text-mono` | inherits size | 500 | inherits | Modifier class, not a size — applied alongside any of the above when rendering a number |

## Spacing System

4px base unit (industry-standard, matches Tailwind's scale referenced
throughout the uploaded style-guide toolkit's `styles.csv`/token docs —
using the same scale means any future translation of that toolkit's
guidance requires no unit conversion).

| Token | Value |
|---|---|
| `--td-space-1` | 4px |
| `--td-space-2` | 8px |
| `--td-space-3` | 12px |
| `--td-space-4` | 16px |
| `--td-space-5` | 24px |
| `--td-space-6` | 32px |
| `--td-space-7` | 48px |
| `--td-space-8` | 64px |

**Usage convention**: `space-2`/`space-3` for internal component padding
(badge padding, button padding), `space-4`/`space-5` between related
elements (card internal sections), `space-6`/`space-7` between unrelated
page sections (replaces bare `st.divider()` as the primary rhythm tool
— dividers become the exception, not the default, per Rationale
Principle 1: a gap communicates separation as clearly as a line, with
less visual noise).

## Border Radius System

| Token | Value | Use |
|---|---|---|
| `--td-radius-sm` | 6px | Badges, tags, small buttons |
| `--td-radius-md` | 10px | Cards, inputs, standard buttons (matches `reporting`'s `--radius: 10px` exactly) |
| `--td-radius-lg` | 14px | Modals, large containers |
| `--td-radius-full` | 999px | Pills (severity badges), avatars |

## Shadows & Elevation System

5 levels, Vercel-derived restraint (Principle: shadows for true overlays,
borders for in-flow separation). Dark-mode shadows are darker/tighter
(a light shadow is invisible on a dark surface — elevation there is
carried primarily by the surface-layer color steps above, shadow is a
secondary reinforcement).

| Token | Dark mode | Light mode | Use |
|---|---|---|---|
| `--td-elevation-0` | none | none | Flat, in-flow content |
| `--td-elevation-1` | `0 1px 2px rgba(0,0,0,0.4)` | `0 1px 2px rgba(20,24,32,0.06)` | Cards at rest |
| `--td-elevation-2` | `0 2px 8px rgba(0,0,0,0.5)` | `0 2px 8px rgba(20,24,32,0.08)` | Card hover, dropdown |
| `--td-elevation-3` | `0 4px 16px rgba(0,0,0,0.55)` | `0 4px 16px rgba(20,24,32,0.10)` | Popover, tooltip |
| `--td-elevation-4` | `0 12px 32px rgba(0,0,0,0.6)` | `0 12px 32px rgba(20,24,32,0.14)` | Modal, dialog |

**Elevation is monotonic**: a component never uses a shadow level higher
than what its layering actually represents (e.g., a badge never gets
`elevation-3` just to "pop" — that's a semantic violation of the scale,
per Principle 8).

## Grid System & Layout Rules

Given Streamlit's `st.columns(n)` constraint (Rationale's grid decision),
the "12-column grid" is expressed as **standard column-count recipes**,
each mapped to a gutter from the spacing scale:

| Pattern | Streamlit call | Gutter | Use |
|---|---|---|---|
| KPI row | `st.columns(4)` or `st.columns(5)` | `--td-space-4` (16px) | Dashboard-style metric rows |
| Card row | `st.columns(3)` | `--td-space-5` (24px) | Mid-density content cards |
| Split | `st.columns(2)` | `--td-space-5` (24px) | Comparison / before-after |
| Full-width | `st.columns(1)` (i.e. no columns) | — | Tables, charts, long-form text |

**Container max-width**: `1440px`, centered, `padding-inline: var(--td-space-6)`
— prevents KPI cards from stretching uncomfortably wide on ultra-wide
monitors while staying full-bleed-feeling on laptops (matches the
"Desktop" breakpoint below).

**Vertical rhythm rule**: every top-level page section (what's currently
an `st.subheader()` block) gets `margin-block: var(--td-space-6)` — this
is the system replacing ad hoc `st.divider()` placement (audit finding
#4) with a consistent, predictable rhythm.

## Responsive Breakpoints

| Breakpoint | Min-width | Target |
|---|---|---|
| `--td-bp-mobile` | 0 | Mobile browser (Streamlit's mobile view — sidebar collapses to a top drawer natively) |
| `--td-bp-tablet` | 768px | Tablet |
| `--td-bp-laptop` | 1024px | Laptop |
| `--td-bp-desktop` | 1440px | Desktop / wide monitor |

Full per-component responsive rules in `04_ACCESSIBILITY_AND_RESPONSIVE.md`
— defined here as the shared breakpoint values every component references,
per Principle 8 (one scale, no page-specific breakpoints).

## Iconography

- **Icon set**: Lucide (MIT-licensed, SVG, matches the "no emojis as
  icons" convention found in the uploaded style-guide toolkit's own
  pre-delivery checklist — a rule worth adopting even though the
  toolkit's stack-specific tooling doesn't apply to Streamlit, per the
  earlier discussion's conclusion that platform-agnostic *philosophy*
  transfers even when code doesn't).
- **Sizes**: 16px (inline with text), 20px (buttons/nav), 24px (section
  headers, empty states).
- **Color**: monochrome `currentColor` by default (inherits text color)
  — color reserved for semantic icons only (e.g., a severity icon next
  to a severity badge uses that severity's color, everything else stays
  neutral). Directly enforces Principle 1.
- **Migration note**: existing emoji usage (🩺📊📈 etc., audit finding
  #8) is **not** removed in this phase (that would touch every page's
  content, violating the "shared components only" scope) — the icon
  system is defined here for new shared components (buttons, alerts,
  nav) and as the documented standard for any future page work. See
  `05_COMPONENT_INVENTORY.md`'s scope column.
