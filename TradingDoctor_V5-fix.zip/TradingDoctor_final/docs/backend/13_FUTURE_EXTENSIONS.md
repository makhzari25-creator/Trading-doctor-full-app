# Future Extension Guide

Every item here is a **documented, intentional** gap — something noted
at the time it was deferred, with the reasoning, not something discovered
by surprise later. Cross-referenced to where it's also mentioned inline.

## Near-term, low-risk

### 1. Wire threshold constants in `config.py` into the engines that already match them
`config.py` defines `OVERTRADING_TRADES_PER_DAY`,
`RISK_SIZE_MULTIPLIER`, `PATIENCE_QUICK_REENTRY_MINUTES` — currently
unused (see `docs/05_CONFIGURATION.md`'s "⚠️ defined but not yet wired
up" section). The literal values in `engines/behavior_engine.py` and
`utils/sequence_analysis.py` happen to match the config defaults today,
so wiring them up is low-risk: replace each hardcoded literal with a read
from `config.py`, then confirm `tests/test_pipeline.py` and
`tests/test_sequence_analysis.py` still pass unchanged (they should,
since the values match). Good first task for someone new to the codebase.

### 2. Wire `RiskEngine` into the UI/API
`engines/risk_engine.py` is a complete, tested facade
(`tests/test_pipeline.py::test_risk_engine_facade`) that nothing in
`pages/` or `api/` currently calls. Adding a "Risk" Streamlit page and/or
a `GET /api/v1/analyses/{id}/risk` endpoint would follow the exact same
pattern as any existing page/endpoint — see `docs/06_DEVELOPER_GUIDE.md`.

### 3. Expose `TrendEngine` via the REST API
`engines/score_engine.py::TrendEngine` powers `pages/09_Trends.py`
(weekly/monthly score history) but has no REST equivalent. Would need a
new Pydantic model (`api/models/`) and router — `TrendEngine` itself
needs no changes.

### 4. `.env` file support
No `python-dotenv` (or similar) dependency exists; configuration is
environment-variable-only (see `docs/05_CONFIGURATION.md`). Low-risk
addition if local-development convenience is wanted — would only touch
`config.py`/`api/config.py`'s top of file.

## Medium-term, requires design decisions

### 5. Shared store backend for multi-worker/multi-instance deployment
`api/services/store.py::AnalysisStore` and
`api/dependencies.py::_SlidingWindowRateLimiter` are both in-process,
in-memory. Documented extensively in `docs/04_DEPLOYMENT.md` and
`API_DOCUMENTATION.md` as the main scaling limitation. The fix is
localized (both are accessed through exactly one class/function each —
see `docs/09_MODULE_INTERACTION.md`'s api/ diagram), but requires
choosing: Redis for the rate limiter (short-lived, low-durability-need
data) and either Redis or Postgres for analysis history (longer-lived;
Postgres if permanent history across restarts matters, Redis if not).

### 6. TTL-based store cleanup
Currently only count-based bounds exist (`STORE_MAX_ANALYSES`/
`STORE_MAX_UPLOADS`, LRU eviction — see `docs/07_ENGINE_REFERENCE.md`).
A very old but under-the-cap record stays forever. Adding a periodic
background sweep (or checking age lazily on access) would close this;
deferred in Phase 3 specifically to avoid introducing a background task
scheduler for what was, at the time, a secondary concern next to the
unbounded-growth bug that *was* fixed.

### 7. Async job queue for very large files or slow LLM calls
`POST /api/v1/analyses` runs synchronously (offloaded to a thread pool,
but the HTTP response waits for completion). Appropriate today — measured
at ~1 second even for 25,000-row files with `llm_provider="none"` — but
would need to become a `202 Accepted` + polling model if inputs grow much
larger, or if a slow external LLM call becomes the bottleneck instead of
the analysis itself. `api/services/store.py::AnalysisRecord` would need a
`status` field (`pending`/`running`/`complete`/`failed`); routers would
change from "compute and return" to "enqueue and return an ID."

### 8. Per-user authentication (JWT/OAuth2) instead of shared API keys
Current auth (`api/dependencies.py::verify_api_key`) is a single shared
secret, appropriate for service-to-service or trusted-frontend use (see
`API_DOCUMENTATION.md`'s "Known limitations"). A real multi-tenant
product would want per-user tokens — fits the same `Depends()` pattern
already established, replacing `verify_api_key`'s body without changing
its call sites in routers.

## Larger, structural

### 9. CI pipeline
No CI configuration exists yet. `pytest tests/ -q` (48 tests) and the
manual verification steps in `docs/11_CONTRIBUTING.md` are currently
run by hand. A CI pipeline should at minimum: run the full test suite,
boot the Streamlit app and the API server and hit a smoke-test request
against each (both have caught real issues in this project that
`TestClient`-only testing missed — see the Phase 3 self-review), and
could additionally automate the "no business logic in reporting/" check
mentioned in `docs/09_MODULE_INTERACTION.md`.

### 10. Containerization
No `Dockerfile` exists yet. `docs/04_DEPLOYMENT.md` includes a minimal
example to start from — deliberately simple, since no system-level
dependencies are required (a direct consequence of the Phase 2 decision
to use reportlab over `wkhtmltopdf`).

### 11. Full-text/semantic history search
`GET /api/v1/history` is a simple paginated list (newest-first). No
filtering by score range, date range, or diagnosis type exists. Would be
a natural `api/models/analysis.py` + `AnalysisStore.list_history()`
extension once a real backend (see #5) makes filtering efficient at
scale — premature against an in-memory store bounded to 500 records.

### 12. Automated visual regression testing for reports
HTML/PDF report quality has so far been verified by rendering to images
and inspecting manually (see the Phase 2 self-review) — real, but not
automated. A snapshot-comparison step (rendering a fixed test dataset and
diffing against a golden image) would catch future visual regressions
without manual QA every time. Would fit naturally into item #9's CI
pipeline once one exists.

## How to propose an addition to this list

If you defer something during a change (rather than fixing it), add it
here in the same PR, following the pattern above: what it is, why it's
deferred (not just "later"), and what the actual fix would touch. A
future contributor should be able to pick any item on this list and know
where to start without re-deriving the context — that's the bar.
