# Trading Doctor V23 — Deployment Guide

> Phase 7.5 deliverable. Covers local development, single-instance production,
> and the path to multi-instance scaling.

This guide walks you through deploying Trading Doctor V23 from a fresh
checkout to a running production instance. The application has three
runtime topologies:

1. **Local development** — Streamlit + FastAPI in one process, SQLite-free,
   in-memory store, no DB required.
2. **Single-instance production** — FastAPI + PostgreSQL + Redis + nginx in
   Docker Compose, on one VPS (recommended for ≤1,000 users).
3. **Multi-instance production** — FastAPI scaled horizontally behind a
   load balancer, with managed Postgres + Redis (Phase 11 target).

---

## 1. Prerequisites

### Local development
- Python 3.11+
- Docker 24+ and Docker Compose v2
- 2 GB RAM minimum (8 GB recommended for full pipeline + LLM)

### Production (single-instance)
- A VPS or cloud VM with:
  - 2+ vCPUs
  - 4+ GB RAM
  - 40+ GB SSD
  - Ubuntu 22.04 / Debian 12 / equivalent Linux
- A domain name with DNS A record pointing to the server IP
- (Optional) An SMTP relay for transactional email (Phase 8)

### Production (multi-instance)
- Managed PostgreSQL 16 (RDS, Cloud SQL, Supabase, Neon)
- Managed Redis (Elasticache, Upstash, Render)
- Container orchestration (Kubernetes, ECS, Nomad, or docker swarm)
- CDN for static assets (Cloudflare, CloudFront)

---

## 2. Quick Start: Local Development with Docker Compose

```bash
# 1. Clone and enter the repo
git clone <your-repo-url> TradingDoctor
cd TradingDoctor

# 2. Copy env template and adjust if needed
cp .env.example .env
# Edit .env: at minimum set POSTGRES_PASSWORD, JWT_SECRET_KEY, JWT_REFRESH_SECRET_KEY

# 3. Start the stack (api + postgres + redis)
docker compose up -d

# 4. Apply database migrations
docker compose exec api alembic upgrade head

# 5. Verify
curl http://localhost:8000/api/v1/health
curl http://localhost:8000/api/v1/health/ready
```

The API is now available at `http://localhost:8000`. Swagger docs at
`http://localhost:8000/docs` (dev only — disabled in production).

---

## 3. Quick Start: Local Development without Docker

For engine work and Streamlit-only deployments:

```bash
# 1. Create venv
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# 2. Install deps
pip install -r requirements.txt

# 3. Run the API
uvicorn api.main:app --reload --port 8000

# (Optional) Run Streamlit in another terminal
streamlit run app.py
```

Without `DATABASE_URL` set, the DB layer is disabled and the app runs in
"no-DB mode" — useful for engine testing. The `/api/v1/health/ready`
endpoint will report `db_ready: true` (because DB is not required) and
the in-memory store continues to function as in Phase 3.

---

## 4. Single-Instance Production Deployment

### 4.1 Provision the server

```bash
# On a fresh Ubuntu 22.04 VPS as root:
apt update && apt upgrade -y
apt install -y docker.io docker-compose-v2 ufw fail2ban

# Secure SSH (disable password auth, change port if desired)
sed -i 's/^#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd

# Firewall: allow SSH, HTTP, HTTPS only
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### 4.2 Deploy the application

```bash
# As a non-root user with docker group access:
mkdir -p ~/td && cd ~/td
git clone <your-repo-url> .
cp .env.example .env.prod

# Generate strong secrets
openssl rand -hex 32  # → JWT_SECRET_KEY
openssl rand -hex 32  # → JWT_REFRESH_SECRET_KEY
openssl rand -hex 24  # → METRICS_AUTH_TOKEN
openssl rand -hex 16  # → REDIS_PASSWORD

# Edit .env.prod with production values (see .env.example for reference)
nano .env.prod
```

**Mandatory production env vars** (see `.env.example` for the full list):

| Variable | Why it matters |
|---|---|
| `TRADING_DOCTOR_ENV=production` | Disables /docs, enables JSON logs, tightens CORS |
| `DATABASE_URL` + `DATABASE_URL_SYNC` | PostgreSQL connection (async + sync for Alembic) |
| `REDIS_URL` | Redis connection for distributed rate limit + cache |
| `JWT_SECRET_KEY` | Signs access tokens — must be ≥32 random chars |
| `JWT_REFRESH_SECRET_KEY` | Signs refresh tokens — different from above |
| `POSTGRES_PASSWORD` | DB password (must match DATABASE_URL) |
| `REDIS_PASSWORD` | Redis password (must match REDIS_URL) |
| `TRADING_DOCTOR_API_CORS_ORIGINS` | Explicit list, no `*` |
| `APP_BASE_URL` + `FRONTEND_BASE_URL` | Used in email links + cookies |
| `GEMINI_API_KEY` (or other LLM) | Required for AI coaching (optional — falls back gracefully) |

### 4.3 First-time setup

```bash
# Pull the latest code
cd ~/td
git pull origin main

# Build and start
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build

# Apply database migrations
docker compose -f docker-compose.prod.yml --env-file .env.prod exec api alembic upgrade head

# Verify health
curl http://localhost:8000/api/v1/health/ready
# Expected: {"status":"ok","engine_ready":true,"db_ready":true,"redis_ready":true,...}
```

### 4.4 TLS certificates

Use Let's Encrypt (free) via certbot. The included nginx config supports
the ACME challenge path.

```bash
# Install certbot on the host
apt install -y certbot

# Obtain certs (replace example.com with your domain)
certbot certonly --standalone -d api.yourdomain.com \
  --non-interactive --agree-tos -m admin@yourdomain.com

# Copy certs to the nginx mount path
mkdir -p ~/td/deploy/nginx/certs
cp /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem ~/td/deploy/nginx/certs/
cp /etc/letsencrypt/live/api.yourdomain.com/privkey.pem  ~/td/deploy/nginx/certs/
chmod 644 ~/td/deploy/nginx/certs/*.pem

# Restart nginx to pick up certs
docker compose -f docker-compose.prod.yml restart nginx
```

Set up auto-renewal:

```bash
# Add to /etc/cron.d/certbot-renew
0 3 * * * root certbot renew --quiet --post-hook "docker compose -f /root/td/docker-compose.prod.yml restart nginx"
```

### 4.5 Verify the deployment

```bash
# 1. HTTPS redirects work
curl -I http://api.yourdomain.com/api/v1/health
# Expected: 301 redirect to https://

# 2. HTTPS endpoint responds
curl https://api.yourdomain.com/api/v1/health
# Expected: {"status":"ok","version":"1.0.0","engine_ready":true,...}

# 3. Readiness probe (DB + Redis)
curl https://api.yourdomain.com/api/v1/health/ready

# 4. Metrics endpoint (requires token if METRICS_AUTH_TOKEN is set)
curl -H "Authorization: Bearer $METRICS_AUTH_TOKEN" https://api.yourdomain.com/metrics

# 5. /docs is disabled in production
curl -o /dev/null -w "%{http_code}" https://api.yourdomain.com/docs
# Expected: 404
```

---

## 5. Operations

### 5.1 Viewing logs

```bash
# All services, last 100 lines
docker compose -f docker-compose.prod.yml logs --tail 100

# Just the API, follow
docker compose -f docker-compose.prod.yml logs -f api

# Structured JSON logs (production) — pipe through jq
docker compose -f docker-compose.prod.yml logs api | jq .

# Application log file (rotated at 5 MB, 3 backups)
docker compose -f docker-compose.prod.yml exec api cat reports/trading_doctor.log | tail -200
```

### 5.2 Running migrations

```bash
# Apply all pending migrations
docker compose -f docker-compose.prod.yml exec api alembic upgrade head

# Check current revision
docker compose -f docker-compose.prod.yml exec api alembic current

# Rollback the last migration (DESTRUCTIVE — use with care)
docker compose -f docker-compose.prod.yml exec api alembic downgrade -1
```

### 5.3 Backups

```bash
# Database backup (daily cron recommended)
docker compose -f docker-compose.prod.yml exec db \
  pg_dump -U $POSTGRES_USER $POSTGRES_DB | gzip > backups/db_$(date +%Y%m%d).sql.gz

# Upload files backup
tar czf backups/uploads_$(date +%Y%m%d).tar.gz \
  ~/td/data/api_runs/uploads/

# Retention: keep last 30 days
find backups/ -mtime +30 -delete
```

Sample backup cron (`/etc/cron.d/td-backup`):

```cron
0 2 * * * root cd /root/td && \
  docker compose -f docker-compose.prod.yml exec -T db \
    pg_dump -U tradingdoctor tradingdoctor | gzip > backups/db_$(date +\%Y\%m\%d).sql.gz && \
  find backups/ -mtime +30 -delete
```

### 5.4 Updating the application

```bash
cd ~/td
git pull origin main
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build
docker compose -f docker-compose.prod.yml exec api alembic upgrade head
```

### 5.5 Restarting services

```bash
docker compose -f docker-compose.prod.yml restart api
docker compose -f docker-compose.prod.yml restart nginx
```

---

## 6. Health Checks & Monitoring

### Built-in endpoints

| Endpoint | Purpose | Auth |
|---|---|---|
| `GET /api/v1/health` | Liveness probe (cheap) | None |
| `GET /api/v1/health/ready` | Readiness probe (DB + Redis check) | None |
| `GET /metrics` | Prometheus metrics | Bearer token if `METRICS_AUTH_TOKEN` set |

### Prometheus metrics

Scrape config example:

```yaml
scrape_configs:
  - job_name: 'tradingdoctor'
    scrape_interval: 15s
    scheme: https
    metrics_path: /metrics
    bearer_token: '<your METRICS_AUTH_TOKEN>'
    static_configs:
      - targets: ['api.yourdomain.com:443']
```

Key metrics:
- `http_requests_total{method, path, status}` — request counter
- `http_request_duration_seconds{method, path}` — latency histogram
- `http_requests_in_progress` — concurrent requests gauge
- `analysis_runs_total{llm_provider, outcome}` — engine runs counter
- `analysis_duration_seconds{llm_provider}` — engine latency histogram

### Sentry error tracking

Set `SENTRY_DSN` in `.env.prod` to enable. Errors and performance traces
are auto-captured. Sample rate configurable via `SENTRY_TRACES_SAMPLE_RATE`.

---

## 7. Multi-Instance Scaling (Phase 11)

For >1,000 active users or >50 concurrent analyses, scale horizontally:

1. **Replace Docker Compose with Kubernetes/ECS/Nomad** for orchestration.
2. **Use managed Postgres** (RDS, Cloud SQL) — single endpoint, automated backups.
3. **Use managed Redis** (Elasticache, Upstash) — single endpoint, HA.
4. **Put a real load balancer** (ALB, Cloudflare) in front of multiple API instances.
5. **Move file uploads to S3** (Phase 9 will add the storage abstraction).
6. **Move long-running analyses to a Celery worker pool** (Phase 11 will add this).
7. **Externalize session state** — JWT + Redis refresh-token store (Phase 8).

The application is designed for this scaling path — the only stateful
components are Postgres (managed) and Redis (managed), both externalized.

---

## 8. Troubleshooting

### Container won't start

```bash
docker compose -f docker-compose.prod.yml logs api | tail -50
```

Common causes:
- Missing env vars (check `.env.prod` has all required vars from `.env.example`)
- Database unreachable (check `DATABASE_URL` syntax, `db` container health)
- Migration failure (`alembic upgrade head` failed — check logs, fix manually, retry)

### 502 Bad Gateway from nginx

The API container isn't responding. Check:
```bash
docker compose -f docker-compose.prod.yml ps  # is api running?
docker compose -f docker-compose.prod.yml logs api | tail -100
```

### Database connection failures

```bash
# Verify DB is reachable from the API container
docker compose -f docker-compose.prod.yml exec api \
  python -c "import asyncio; from db.base import db_health_check; print(asyncio.run(db_health_check()))"

# Check connection pool stats
docker compose -f docker-compose.prod.yml exec db \
  psql -U $POSTGRES_USER $POSTGRES_DB -c "SELECT * FROM pg_stat_activity;"
```

### Migrations out of sync

```bash
# Check current revision
docker compose -f docker-compose.prod.yml exec api alembic current

# If a manual fix is needed, stamp the current state (USE WITH CAUTION)
docker compose -f docker-compose.prod.yml exec api alembic stamp <revision>
```

### Upload fails with 413

Increase `client_max_body_size` in `deploy/nginx/nginx.conf` and
`MAX_UPLOAD_SIZE_BYTES` in `api/config.py` (via `TRADING_DOCTOR_API_MAX_UPLOAD_MB`
env var). Current limits: 25 MB at API, 50 MB at nginx.

---

## 9. Disaster Recovery

### Restore from backup

```bash
# Stop the API to prevent writes during restore
docker compose -f docker-compose.prod.yml stop api

# Restore database
gunzip -c backups/db_20260101.sql.gz | \
  docker compose -f docker-compose.prod.yml exec -T db \
    psql -U $POSTGRES_USER $POSTGRES_DB

# Restore uploads
tar xzf backups/uploads_20260101.tar.gz -C ~/td/

# Restart
docker compose -f docker-compose.prod.yml up -d
```

### RPO / RTO targets (recommended)

- **RPO** (Recovery Point Objective): 24 hours — daily DB + uploads backup.
- **RTO** (Recovery Time Objective): 1 hour — full redeploy from backup.
- For tighter RPO, enable Postgres WAL archiving + continuous backup (RDS automated backups).

---

## 10. Reference: Complete File Inventory (Phase 7.5 additions)

| File | Purpose |
|---|---|
| `.env.example` | All env vars with defaults and descriptions |
| `Dockerfile` | Multi-stage Python 3.11-slim image, non-root user |
| `.dockerignore` | Keeps build context small |
| `docker-compose.yml` | Dev stack (api + db + redis, hot reload) |
| `docker-compose.prod.yml` | Production stack (api + db + redis + nginx + worker) |
| `alembic.ini` + `alembic/` | Migration framework |
| `alembic/env.py` | Reads `DATABASE_URL_SYNC`, autodiscovers models |
| `alembic/versions/0001_phase7_5_baseline.py` | Baseline migration (enables pgcrypto) |
| `db/__init__.py` | Package entry, re-exports key symbols |
| `db/base.py` | Async engine, session factory, `Base`, `get_db` dep |
| `db/models.py` | Mixins: `UUIDPkMixin`, `TimestampMixin`, `SoftDeleteMixin` |
| `db/redis_client.py` | Async Redis client + health check |
| `api/metrics.py` | Prometheus metrics + Sentry init |
| `api/main.py` (updated) | Wires metrics, Sentry, shutdown hooks, prod CORS |
| `api/routers/health.py` (updated) | Adds `/health/ready` with DB + Redis checks |
| `utils/logger.py` (updated) | JSON logging mode for production |
| `deploy/nginx/nginx.conf` | Main nginx config (perf + security) |
| `deploy/nginx/conf.d/default.conf` | HTTPS site + reverse proxy + rate limit |
| `deploy/postgres/init.sh` | DB init script (pgcrypto extension) |
| `docs/DEPLOYMENT.md` | This file |
| `docs/PRODUCTION_CHECKLIST.md` | Pre-launch checklist |
