# Architecture

## Overview

Trading Doctor is a layered system built in three phases, each adding a
new *presentation* of the same underlying analysis — never a new
computation path:

```mermaid
graph TB
    subgraph "Phase 1 — Analytical Core (source of truth)"
        ENG["engines/*<br/>BehaviorEngine, ScoreEngine, EvidenceEngine,<br/>DiagnosisEngine, PsychologyEngine, CoachingEngine,<br/>ReportEngine, RiskEngine"]
        SVC["core/service.py<br/>analyze_dataframe() / analyze_file()"]
        UTIL["utils/*<br/>file_loader, validation, column_mapper,<br/>sequence_analysis, logger"]
        LLM["llm/*<br/>provider abstraction: Gemini/OpenAI/Claude"]
    end

    subgraph "Phase 2 — Reporting (presentation only)"
        REP["reporting/*<br/>data_context, charts, html_report, pdf_report"]
    end

    subgraph "Phase 3 — REST API (presentation only)"
        API["api/*<br/>routers, models, store, auth, rate limiting"]
    end

    subgraph "Consumers"
        WEB["Streamlit app<br/>app.py + pages/*"]
        CLI["CLI<br/>main.py"]
        HTTP["HTTP clients<br/>(any language)"]
    end

    UTIL --> SVC
    LLM --> ENG
    ENG --> SVC
    SVC --> WEB
    SVC --> CLI
    SVC --> API
    ENG --> REP
    REP --> WEB
    REP --> CLI
    REP --> API
    API --> HTTP
```

## The four layers, and why each boundary exists

### 1. Analytical engine (`engines/`, `core/service.py`, `utils/`)

The deterministic core. Given a DataFrame of trades, it produces:
behavioral scores, financial context, evidence, a diagnosis, a
psychological profile, and a coaching narrative. **Nothing above this
layer is allowed to compute a score or threshold** — this is the single
most important architectural rule in the codebase (see `docs/README.md`).

Why: three different consumers (Streamlit, reporting, API) need the exact
same numbers. If each computed independently, they could silently drift
apart — a user could see a different "discipline score" in the PDF report
than on the dashboard. Centralizing computation here makes that class of
bug structurally impossible, not just unlikely.

### 2. LLM coaching layer (`llm/`)

A pluggable provider abstraction (`BaseLLMProvider` → `GeminiProvider` /
`OpenAIProvider` / `ClaudeProvider`, selected by `llm.provider.get_llm()`).

Why it's a separate layer: the LLM **never** produces a score, diagnosis,
or any number used elsewhere in the report. Its only job is turning
already-computed evidence into an encouraging, explainable paragraph
(`CoachingEngine.generate()`'s `explainable_ai` field). If the LLM is
unavailable or misconfigured, `CoachingEngine` catches that and falls back
to a template-based explanation — the rest of the report is unaffected.
This is why "AI Coaching Summary" in the report is always present but
never authoritative.

### 3. Reporting module (`reporting/`)

Takes the engine's output (`FullResult` + the `coach` dict) and renders it
as HTML or PDF. See `docs/09_MODULE_INTERACTION.md` for the exact call
graph. Two independent renderers (Jinja2/HTML, reportlab/PDF) share one
`data_context.py` builder and one `charts.py` chart generator — so the
numbers and images in both formats are always identical, even though the
layout code is separate (HTML can't just be converted to PDF without a
system dependency — see `CHANGELOG_V23_PHASE2.md` for why reportlab was
chosen).

### 4. REST API (`api/`)

An HTTP façade over the same engine + reporting calls the Streamlit app
already makes. `api/services/store.py` is the **only** module in `api/`
that touches the engine directly — every router goes through it. This is
enforced by an automated test
(`tests/test_api.py::test_no_business_logic_duplicated_in_api_layer`)
that fails the build if any file under `api/` imports an engine class.

## Consumers (not architectural layers — just callers)

- **Streamlit app** (`app.py` + `pages/*.py`): the original UI. Uses
  `core.service` directly, stores results in `st.session_state`, and
  (since Phase 2) offers HTML/PDF downloads via `reporting/`.
- **CLI** (`main.py`): a thin script for local/scripted use. Same
  `core.service` call, prints a text report, and (since Phase 2) supports
  `--export-html`/`--export-pdf` flags.
- **HTTP clients**: anything that speaks REST, via `api/`.

None of these consumers contain business logic; they're all
presentation/transport.

## Cross-cutting concerns

- **Logging** (`utils/logger.py`): one shared, idempotent logger
  configuration used by every layer — console + rotating file
  (`reports/trading_doctor.log`). API requests additionally get a
  short correlation ID (`X-Request-ID` header).
- **Validation**: two distinct kinds, not to be confused —
  `utils/validation.py` validates trading-*data content* (does this column
  look like Profit? are there duplicate rows?) and is engine-layer;
  Pydantic models in `api/models/` validate HTTP *request shape* (is
  `llm_provider` one of the four allowed values?) and are API-layer. The
  API layer never re-validates data content — it lets
  `utils.validation.DataValidationError` bubble up and maps it to a 422.
- **Error handling**: every layer follows the same principle established
  in Phase 1 — never expose a raw Python traceback to an end user (UI,
  CLI, or HTTP client); log the full traceback server-side, show a clear,
  translated, non-technical message externally.

## Why this shape, concretely (a worked example)

Suppose a bug is found in the "overtrading" score formula.

1. Fix it in exactly one place: `engines/behavior_engine.py::overtrading_score()`.
2. Every consumer picks it up automatically: Streamlit's dashboard,
   the CLI's printed report, the downloadable HTML/PDF, and every REST API
   response — because all four read `BehaviorResult.scores["overtrading_score"]`
   from the same `ScoreEngine.run()` call, never a locally recomputed value.
3. Contrast with a poorly-layered alternative where the API layer
   reimplemented "days with >5 trades" itself for a slightly different
   JSON shape — that fix would need to be applied (and tested) in two
   places, and the two could silently disagree until someone noticed.

This is the concrete payoff of the "engine is the single source of truth"
rule, not just a design platitude.
