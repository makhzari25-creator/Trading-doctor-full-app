# Accessibility & Responsive Design — Trading Doctor V23

## WCAG-friendly contrast

**Methodology**: every color pair in this system is checked with
`design/contrast_check.py` — the WCAG 2.1 relative-luminance formula,
computed directly, not estimated. Run it after any token change:

```bash
python3 design/contrast_check.py
```

Current result: **17/17 pairs pass** (reproduced below; this is the
actual script output, not a hand-written table — regenerate rather than
hand-edit if a token changes):

```
PASS  16.89:1  (min 4.5)  text on bg-canvas (dark)
PASS  14.64:1  (min 4.5)  text on bg-canvas (light)
PASS   6.71:1  (min 4.5)  text-muted on bg-surface-2 (dark)
PASS   5.67:1  (min 4.5)  text-muted on bg-surface-2 (light)
PASS   7.06:1  (min 3.0)  accent on bg-canvas (dark)
PASS   4.76:1  (min 3.0)  accent on bg-surface (light)
PASS   5.33:1  (min 4.5)  white on positive-solid (dark)
PASS   4.94:1  (min 4.5)  white on positive-solid (light)
PASS   5.92:1  (min 4.5)  white on negative-solid (dark)
PASS   5.52:1  (min 4.5)  white on negative-solid (light)
PASS   6.36:1  (min 4.5)  white on warning-solid (dark)
PASS   4.92:1  (min 4.5)  white on warning-solid (light)
PASS   4.52:1  (min 4.5)  white on severity-high-solid (dark)
PASS   4.65:1  (min 4.5)  white on severity-high-solid (light)
PASS   5.89:1  (min 4.5)  positive-soft-text on white worst-case (light)
PASS   5.17:1  (min 4.5)  warning-soft-text on white worst-case (light)
PASS   5.68:1  (min 4.5)  severity-high-soft-text on white worst-case (light)

17/17 pairs pass. All pass.
```

**This methodology already caught two real failures once** — see
`02_FOUNDATIONS.md`'s note: the first draft used a single mid-tone value
per semantic color for both large-fill and small-badge use, and white
text on two of those mid-tones failed outright (2.77:1 and 2.36:1). The
solid/soft split in the current token set exists *because* this check
was run, not as a design preference. Treat this script as a required
gate, not documentation-after-the-fact, for any future token change.

## Keyboard navigation

- **Tab order** follows native Streamlit DOM order — no custom
  `tabindex` is introduced (avoiding a common source of keyboard-nav
  bugs: manually-ordered tabindex drifting out of sync with visual
  order). All custom components (badges, cards, empty states) are
  **non-interactive by default** (no `tabindex` at all) unless they wrap
  an actual action, in which case they render as a real `<button>` or
  Streamlit-native control — never a `<div onclick>` (which is both a
  keyboard-nav and screen-reader failure mode).
- **Skip-to-content**: not currently present in Streamlit's own chrome
  and out of scope to add via CSS alone (would require injecting a real
  focusable anchor before the sidebar) — flagged as a gap in
  `05_COMPONENT_INVENTORY.md` rather than silently left undocumented.
- **Dialog focus trapping**: `st.dialog` (where used — see version
  caveat in `03_COMPONENTS.md`) handles focus trapping and Escape-to-close
  natively; verified directly (the probe used to confirm the `stDialog`
  selector was closed with a literal `Escape` keypress during testing).

## Focus states

Every interactive element (buttons, inputs, tabs, nav items, links) gets
an explicit, visible focus style — never `outline: none` without a
replacement (a real anti-pattern the `ux-guidelines.csv` data reviewed
earlier in this project explicitly flags, and one this system commits to
avoiding everywhere, not just on primary actions):

```css
:focus-visible {
  outline: 2px solid var(--td-accent);
  outline-offset: 2px;
  border-radius: var(--td-radius-sm);
}
```

`:focus-visible` (not bare `:focus`) is used deliberately — shows the
ring for keyboard navigation, suppresses it for mouse clicks, matching
modern browser convention and avoiding the "focus ring flashes on every
click" complaint that leads teams to disable focus rings entirely (the
actual root cause of the anti-pattern this system is avoiding).

## Screen-reader compatibility

- **Native widgets kept, not replaced**: per the Rationale's explicit
  tradeoff acknowledgment, `st.error`/`st.warning`/`st.info`/`st.success`,
  `st.button`, `st.expander`, `st.tabs`, `st.progress` all retain
  Streamlit's built-in ARIA wiring (role, live-region behavior for
  alerts) — restyling via `data-testid` CSS selectors does not touch
  DOM structure or ARIA attributes, only visual presentation.
- **Custom components need explicit ARIA**, since they're plain
  `<div>`/`<span>` HTML with no framework wiring:
  - Badges/tags: `role="status"` only when the badge communicates a
    live, changing state (e.g., a severity badge tied to the current
    analysis); purely decorative/static badges get no role.
  - Cards: no ARIA needed if non-interactive (just a `<div>` with
    heading structure preserved — an `<h3>`/`<h4>` for the card title,
    not a styled `<span>`, so screen readers still get real heading
    navigation).
  - Empty states: the icon is `aria-hidden="true"` (decorative), the
    title/description are plain text content (already accessible by
    default — no ARIA needed for static text).
  - Skeleton loader: `aria-busy="true"` on the container being replaced,
    `aria-live="polite"` announcing "loading" once, not per shimmer
    frame (avoids the anti-pattern of a screen reader re-announcing an
    animating element repeatedly).
- **Color is never the only signal**: every severity badge shows the
  severity *word* (Low/Medium/High/Critical), not just a colored dot —
  this was true of the spec from the start (Foundations' severity ramp
  table always pairs color with the label), but is worth stating
  explicitly here as the accessibility reason, not just a copy
  preference.

## Responsive Requirements

Breakpoints defined once in `02_FOUNDATIONS.md`, referenced here for
per-component behavior. Streamlit's own responsive behavior (sidebar
auto-collapses to a top drawer below `~768px`, `st.columns` stacks
vertically on narrow viewports) is **native and kept** — this system
layers on top of it, not replacing Streamlit's layout engine (consistent
with the Rationale's grid-system decision).

| Breakpoint | KPI row (`st.columns(4)`) | Cards | Sidebar | Tables |
|---|---|---|---|---|
| Desktop (≥1440px) | 4 across, max container width applies | 3 across | Expanded, persistent | Full columns visible |
| Laptop (1024-1439px) | 4 across, container fluid | 3 across | Expanded, persistent | Full columns visible |
| Tablet (768-1023px) | 2×2 (Streamlit's native column-wrap) | 2 across | Collapsed by default, toggle-open | Horizontal scroll within container border |
| Mobile browser (<768px) | Stacked, 1 per row | 1 across | Streamlit native top drawer | Horizontal scroll, sticky first column not supported (glide-data-grid constraint, same limitation noted in `03_COMPONENTS.md`'s Tables section) |

**Touch targets**: on tablet/mobile, all interactive elements (buttons,
nav items, tab targets) maintain a minimum 44×44px hit area (Apple HIG /
WCAG 2.5.5 target-size guidance) even where the visual element is
smaller — achieved via padding, not inflating the visible element size
(keeps the compact, information-dense look at the sizes it's designed
for, while still meeting the touch-target minimum).

**What's explicitly not attempted**: a genuinely different mobile
*layout* (e.g., a bottom tab bar replacing the sidebar entirely) — that
would be a content/IA change per-page, outside this phase's "shared
components only" scope. Mobile support here means the shared theme and
components degrade gracefully at narrow widths, not a mobile-specific
redesign.
