# Trading Doctor V23 — Production Hardening Changelog

Scope of this pass (per explicit instruction): **full audit, bug fixes,
placeholder removal, validation, logging, error handling, performance,
QA — no new features.** Every analytical engine, formula, and diagnosis
is unchanged. Nothing was rewritten or redesigned.

---

## 1. Real bugs found and fixed

| # | File | Bug | Fix |
|---|------|-----|-----|
| 1 | `app.py` | Sidebar `st.page_link()` pointed to non-existent files (`pages/1_Analysis.py`, `pages/2_Report.py`, `pages/3_Settings.py`) — leftover from an older page structure. Every sidebar link was broken. | Links now point to the 9 real files in `pages/` with correct labels. |
| 2 | `engines/coaching_engine.py` | `key_evidence` stored the raw `EvidenceType` **Enum member**, not its string value. `pages/04_Diagnosis.py` printed it directly in an f-string, showing `"EvidenceType.REVENGE"` instead of `"revenge"` in the UI. | Enum is now serialized to `.value` once, at the source, so every consumer (UI, `ReportEngine`, future API/JSON) gets a clean string. |
| 3 | `utils/file_loader.py` | CSV parser tried `sep=None` (pandas/csv.Sniffer auto-detect) **first**. On short or single-column files, the sniffer sometimes guessed a random character inside the text as the delimiter and silently produced garbage columns, because the only acceptance check was "≥2 columns". | Explicit, common delimiters (`,` `;` `\t` `|`) are now tried first; auto-sniff is only the last-resort fallback. Regression test added. |
| 4 | `pages/03_Behavioral_Analysis.py`, `pages/01_Dashboard.py` | `st.progress(value)` requires `value ∈ [0, 1]`. `pct_of_total_profit` (and `discipline_score/100`) can legitimately exceed 100% in edge cases (e.g. a single behavior's losses exceeding gross profit), which would crash the page with `StreamlitAPIException`. | Values are clamped to `[0, 1]` before being passed to `st.progress()`. |
| 5 | `requirements.txt` | Only listed `pandas`, `numpy`, `requests`. The app itself needs `streamlit`, `plotly`, `statsmodels` (for `trendline="ols"`), `openpyxl`/`xlrd` (Excel), `lxml`/`html5lib` (broker HTML statements). **A fresh `pip install -r requirements.txt` could not even start the app.** | All actually-imported dependencies added with sane version ranges; verified by booting the real app against them. |
| 6 | `config.py` | `int(os.getenv(...))` / `float(os.getenv(...))` executed directly at import time. An invalid environment variable (e.g. `TRADING_DOCTOR_LLM_TIMEOUT=abc`) crashed the **entire application** (CLI and Streamlit) before any error handler could run. | `_safe_int` / `_safe_float` helpers log a warning and fall back to the documented default instead of crashing. |
| 7 | `engines/coaching_engine.py` | LLM-unavailable warning used `print()`, invisible in a Streamlit server's log stream. | Replaced with structured `logging`. |
| 8 | Streamlit app (`app.py`) | Data-quality warnings produced by validation were only ever shown in the CLI (`main.py`), never in the web UI — a Streamlit user had no way to know a column wasn't recognized or dates were invalid. | Same warnings now shown in an expandable `st.expander` after analysis, matching CLI behavior. |

## 2. Duplicated logic consolidated (maintainability + performance)

The "streak of consecutive losses/wins + size-increase" calculation was
hand-implemented as an explicit Python `for` loop **four separate
times**, once each in:
- `engines/behavior_engine.py :: revenge_analysis()`
- `engines/behavior_engine.py :: _simulate_what_if()`
- `engines/score_engine.py :: _revenge_mask()`
- `engines/evidence_engine.py :: _sequential_masks()`

This is a real maintainability risk (any future change to the streak
rule would need to be made identically in 4 places — miss one and the
engines silently disagree) and a real, if modest, performance cost for
larger trade histories.

**Fix:** extracted into a single vectorized module,
`utils/sequence_analysis.py` (`consecutive_streak`, `size_increased_mask`,
`revenge_mask_from_df`, `sequential_masks`), now used by all four call
sites. The vectorized implementation was verified to produce
**bit-identical output** to the old loop across 100 randomized trials
and documented edge cases (`tests/test_sequence_analysis.py`) — the
analytical result is provably unchanged, only the implementation is DRY
and faster.

## 3. Input validation (Step 4)

New module `utils/validation.py`, invoked by `core/service.py` before
any engine runs:

- **Fatal, clearly-messaged errors** (raise `DataValidationError`, never
  a raw traceback): `None`/wrong type input, empty file, fewer than 2
  columns, no recognizable Profit/Size/Open Time column at all (message
  lists the actual columns found, to help the user fix their export).
- **Non-fatal data-quality warnings** (collected, logged, and now shown
  in both CLI and Streamlit, **never silently drop or mutate rows**):
  duplicate rows, unrecognized Profit/Size/Open Time columns, invalid
  date values, zero/negative trade sizes.
- Explicit regression test: a Profit column whose sum happens to be
  exactly 0 (wins and losses cancel out) is correctly **not** flagged as
  "missing," fixing a latent false-positive in the "is this column real"
  check.

`utils/file_loader.py` was hardened alongside this: empty-file checks on
every code path (CSV/XLSX/HTML/JSON), corrupt-Excel and corrupt-JSON now
raise a clear `UnsupportedFileError` instead of an unhandled pandas/JSON
exception.

## 4. Error handling (Step 5)

- `core/service.py`, `main.py`, and `app.py` now form one consistent
  chain: `UnsupportedFileError` and `DataValidationError` are caught
  explicitly and shown as clear, actionable messages; any other
  exception is caught, logged **with full traceback to the log file
  only**, and shown to the user as a short, non-technical message
  (`type(e).__name__` at most — never a raw traceback in the UI or CLI
  stdout).
- `main.py` now uses proper process exit codes (`sys.exit(1)` on
  failure) instead of always returning 0, which matters for any
  CI/automation wrapping the CLI.

## 5. Logging (Step 6)

New `utils/logger.py`: one shared, idempotent logging configuration
(console + rotating file at `reports/trading_doctor.log`, 5 MB × 3
backups). Wired into: `core/service.py` (analysis start/finish +
duration), `utils/file_loader.py` (file load attempts/failures),
`utils/validation.py` (every warning), `engines/coaching_engine.py`
(LLM provider init, request start/success/failure — **metadata only**:
provider name, prompt-message count, response length — never the full
prompt or response text, since that may contain the user's trading data
or generated content), `engines/evidence_engine.py` (a failed evidence
builder is now logged with `exc_info=True` instead of being silently
swallowed), `app.py`/`main.py` (all error paths).

## 6. Performance (Step 7)

Covered above (duplicated-loop consolidation). No analytical results
changed; `TrendEngine`, `ScoreEngine`, and `EvidenceEngine` were
profiled by reading through their DataFrame operations — no other
material bottleneck was found for realistic trade-journal sizes
(hundreds to low tens-of-thousands of rows); the existing `groupby`/
vectorized pandas operations elsewhere were already efficient and were
left untouched per the "don't change what isn't broken" instruction.

## 7. QA / regression tests added

`tests/` grew from 1 file (2 smoke tests) to 4 files (22 tests, all
passing):
- `tests/test_pipeline.py` — original smoke test, unchanged, still green.
- `tests/test_validation.py` — 9 tests covering every fatal/non-fatal
  validation path described above.
- `tests/test_file_loader.py` — 6 tests: empty file, header-only file,
  correct comma/semicolon parsing (regression test for bug #3 above),
  malformed JSON, unknown-extension fallback.
- `tests/test_sequence_analysis.py` — 5 tests proving the new vectorized
  streak logic is numerically identical to the old loop.

Additionally verified manually in this session:
- Full CLI run against a realistic 120-row synthetic trade file —
  correct end-to-end report (Diagnosis, Trader DNA, Action Plan,
  Evidence) with clean string values (bug #2 confirmed fixed).
- Empty file, non-tabular garbage file, and a valid-but-financially-empty
  CSV each correctly rejected with a clear message and no traceback.
- The Streamlit app was actually started (`streamlit run app.py`) and
  confirmed to serve HTTP 200 with no import or runtime errors.

## 8. Engines — audit result (nothing removed)

Every engine listed in the brief was inspected individually:

- `BehaviorEngine`, `ScoreEngine`/`TrendEngine`, `EvidenceEngine`,
  `DiagnosisEngine`, `PsychologyEngine`, `CoachingEngine`,
  `ReportEngine` — all actively wired into the pipeline
  (`core/service.py` → `pages/*.py`), all logic preserved exactly,
  only the fixes described above applied.
- `RiskEngine` — **not removed**. It is a clean, working facade over
  `BehaviorEngine`'s risk/revenge/what-if logic, covered by its own
  passing test (`tests/test_pipeline.py::test_risk_engine_facade`), but
  it is not yet called from `app.py`/`pages/`. Since it is genuinely
  used (by the test suite) and not dead code, and since new features/UI
  wiring were explicitly out of scope for this pass, it was left as-is.
  Recommended for V24: wire it into a dedicated "Risk" page.

## 9. What was intentionally *not* touched

- The disabled "PDF (در حال توسعه)" download button in
  `pages/08_Report.py` — this is an honest, clearly-labeled,
  already-disabled placeholder for a future export format, not a fake
  calculation or misleading stub. Implementing real PDF export is a new
  feature and was explicitly out of scope for this pass.
- All scoring formulas, thresholds, weightings (40/25/15/20% discipline
  blend, revenge/overtrading/risk thresholds, evidence priority
  weighting 35/25/15/25%, etc.) — unchanged, as instructed.
- Full REST API layer, PDF/HTML export upgrade, expanded documentation
  set — out of scope per your instruction to hold new features until
  the existing system is production-ready.

---

## Recommendations for V24+

1. Wire `RiskEngine` into a dedicated UI page now that it has test
   coverage and a clean interface.
2. Real PDF export for `pages/08_Report.py` (currently an honest,
   disabled placeholder).
3. A thin REST API layer over `core/service.py` (the service layer was
   already written with this in mind — see its docstring).
4. Full architecture/deployment documentation set (Step 12 of the
   original brief) once the above are in place.
5. Consider persisting `data_quality_warnings` and run history to a
   lightweight database once multi-user/SaaS deployment is planned —
   `TrendEngine`'s docstring already assumes an append-only trade
   history managed by a future backend.
