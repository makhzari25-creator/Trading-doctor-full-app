# Installation Guide

## Prerequisites

- Python 3.10+ (developed and tested on 3.12)
- pip
- No system binaries required — every dependency (including PDF
  generation) is pure-Python or pip-installable. This was a deliberate
  Phase 2 decision; see `CHANGELOG_V23_PHASE2.md` §4 for why `wkhtmltopdf`
  was rejected in favor of `reportlab`.

## 1. Clone and install dependencies

```bash
git clone <repository-url>
cd TradingDoctor
pip install -r requirements.txt
```

`requirements.txt` is organized by phase with inline comments explaining
why each package is needed — worth skimming once. Notable groups:

- **Core**: `pandas`, `numpy`, `requests`
- **Web UI**: `streamlit`, `plotly`, `statsmodels` (trendlines)
- **File formats**: `openpyxl`, `xlrd`, `lxml`, `html5lib`
- **Reporting** (Phase 2): `jinja2`, `reportlab`, `matplotlib`,
  `arabic-reshaper`, `python-bidi`, `fonttools` (the last three exist
  specifically to render Persian text correctly in PDFs — see
  `CHANGELOG_V23_PHASE2.md` for the bug this fixes)
- **API** (Phase 3): `fastapi`, `uvicorn[standard]`, `python-multipart`
- **Testing**: `pytest`

## 2. Configure environment variables (optional for local use)

Nothing is required to run the app with heuristic-only coaching (no LLM).
To enable AI coaching text, set one of:

```bash
export GEMINI_API_KEY="..."      # default provider
# or
export OPENAI_API_KEY="..."
# or
export ANTHROPIC_API_KEY="..."
```

See `docs/05_CONFIGURATION.md` for the complete variable reference.

## 3. Run it

### Streamlit app (interactive UI)

```bash
streamlit run app.py
```
Opens at `http://localhost:8501`. Upload a trade file, or start with a
sample export.

### CLI (scripted/local use)

```bash
python3 main.py path/to/trades.csv --llm none
# optional report export:
python3 main.py path/to/trades.csv --llm none --export-html report.html --export-pdf report.pdf
```

### REST API

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8000
```
Interactive docs at `http://localhost:8000/docs`. See
`API_DOCUMENTATION.md` for the full endpoint reference and a curl
walkthrough.

## 4. Verify the install

```bash
pytest tests/ -q
```
Expect `48 passed`. If anything fails, see `docs/12_TROUBLESHOOTING.md`
before assuming your environment is fine — a few of these tests
(`test_file_loader.py`, `test_reporting.py`) exist specifically because
similar-looking environments have produced different results before
(encoding defaults, font availability).

## 5. Supported input file formats

`utils/file_loader.py` accepts: `.csv`, `.xlsx`, `.xls`, `.htm`, `.html`,
`.log`, `.json`, `.txt`. Column names don't need to match exactly —
`utils/column_mapper.py` fuzzy-matches common broker export column names
(MT4/MT5/cTrader-style exports and similar) to the standard schema
(`Open Time`, `Profit`, `Size`). If your broker's export isn't recognized,
`utils/validation.py` will say exactly which columns it saw and what it
expected, rather than failing silently.

## Common install issues

See `docs/12_TROUBLESHOOTING.md` for the full list; the most common ones:
- **`ModuleNotFoundError` for `streamlit`/`plotly`/etc.**: you likely
  installed an old/cached `requirements.txt` — Phase 1 found and fixed a
  version where core UI dependencies were missing entirely (see
  `CHANGELOG_V23.md` bug #5).
- **Persian text renders as boxes in the PDF**: this means
  `reporting/fonts/Vazirmatn-Regular.ttf` wasn't packaged/copied — it must
  ship alongside the code, it isn't a pip dependency.
