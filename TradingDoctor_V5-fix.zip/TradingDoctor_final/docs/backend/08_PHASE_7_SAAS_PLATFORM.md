# Phase 7 — SaaS Platform Foundation

## Architecture diagram

```mermaid
graph TB
    subgraph "Frozen — untouched this phase"
        ENG["Analytical engine<br/>engines/*, core/service.py"]
        REP["Reporting engine<br/>reporting/*"]
        API["FastAPI backend (Phase 3)<br/>api/*"]
        ENG --> API
        REP --> API
    end

    subgraph "New this phase — trading-doctor-web"
        UI["React components<br/>components/ui/*"]
        PAGES["Next.js App Router pages<br/>app/page.tsx, app/dashboard, app/history"]
        STORE["Zustand global store<br/>lib/store.ts"]
        CLIENT["API service layer<br/>lib/api-client.ts — the ONLY module<br/>that calls fetch() against the backend"]

        PAGES --> UI
        PAGES --> STORE
        PAGES --> CLIENT
    end

    CLIENT -->|"HTTP/JSON only —<br/>never a direct import"| API

    style ENG fill:#fdd,stroke:#900
    style REP fill:#fdd,stroke:#900
    style API fill:#fdd,stroke:#900
    style CLIENT fill:#dfd,stroke:#090
```

The red boxes are exactly what the phase brief said to freeze — verified
unmodified (see Migration Summary). The single green arrow is the only
sanctioned integration point: `lib/api-client.ts` is the frontend's
equivalent of the backend's own `api/services/store.py` rule from
Phase 3 ("the only module allowed to call the engine directly") — here,
`api-client.ts` is the only module allowed to call the backend at all.
No component, page, or store ever calls `fetch()` itself.

## Folder structure

```
trading-doctor-web/
├── src/
│   ├── app/                        Next.js App Router — one folder per route
│   │   ├── layout.tsx                Root layout: ThemeProvider, Toaster, Sidebar, ErrorBoundary
│   │   ├── globals.css                 Phase 5A design tokens, ported verbatim (see below)
│   │   ├── page.tsx                      Home — upload + run analysis (Step 1-2 of onboarding)
│   │   ├── dashboard/page.tsx              Analysis results (KPIs, evidence, strengths/weaknesses, downloads)
│   │   └── history/page.tsx                  Real, persistent history (Phase 3 backend — not session-only)
│   ├── components/
│   │   ├── ui/                       Design-system primitives: Badge, Card, KpiCard,
│   │   │                             EmptyState, Skeleton, Button — each a direct port
│   │   │                             of ui/components.py's Streamlit equivalent
│   │   ├── layout/                     Sidebar, ThemeToggle
│   │   └── error-boundary.tsx            Global React error boundary
│   └── lib/
│       ├── api-client.ts               The one HTTP integration point (see diagram)
│       ├── types.ts                      TypeScript types mirroring api/models/*.py exactly
│       └── store.ts                        Zustand global state (current analysis only)
├── .env.local                       NEXT_PUBLIC_API_BASE_URL (build-time constant — see
│                                    API Integration Report's "real bug found" section)
├── package.json
├── tsconfig.json
└── next.config.ts
```

**Why this shape**: mirrors the backend's own layering discipline
(`api/routers/` ↔ `app/*/page.tsx`, `api/services/store.py` ↔
`lib/api-client.ts`, `api/models/` ↔ `lib/types.ts`) so a developer who
already knows the FastAPI side recognizes the pattern immediately on the
frontend side, rather than learning a second, unrelated convention.

## Migration summary

| What | Status |
|---|---|
| Analytical engine (`engines/`, `core/service.py`) | **Untouched.** Zero files modified this phase — verified via `git diff`-equivalent (file listing comparison against the Phase 6 delivered state) |
| Reporting engine (`reporting/`) | **Untouched.** |
| FastAPI backend (`api/`) | **Untouched** except a one-line local `.env`/CORS origin note for dev — no source file changed. All 15 Phase 3 API tests still pass. |
| Streamlit app (`app.py`, `pages/*.py`, `ui/*.py`) | **Untouched and still fully functional** — this phase does not delete or disable it. Per the brief, it's no longer the *production* frontend target going forward, but nothing was removed. All 48 backend/Streamlit-adjacent tests still pass. |
| Design system (Phase 5A) | **Ported, not reinvented.** Every hex value in `trading-doctor-web/src/app/globals.css` is copied verbatim from `ui/theme.py`. Verified by direct diff of the token blocks — no drift. |
| Frontend | **New.** Next.js 16 (App Router) + TypeScript + Tailwind v4 + Zustand + next-themes + sonner (toasts) + lucide-react (icons). 3 real, working pages (Home/Upload, Dashboard, History) out of the ~11 Streamlit pages' worth of content — see "What's not yet migrated" below. |

**What's not yet migrated to the new frontend** (stated plainly, not
hidden): Charts, Behavioral Analysis's detail view, Diagnosis's evidence
expander, Coaching's AI chat, Trader DNA's gauges, Edge Map, Trends, and
the session-scoped History/Downloads-center conveniences built in Phase
6 for Streamlit specifically. The `AnalysisReport` type and the real
`getReport()` API call already fetch **all** of this data in one
response (`behavior_analysis`, `evidence`, `risk`, `recommendations`,
`ai_coaching`, `appendix` are all already typed in `lib/types.ts`) — the
data layer is ready; the remaining work is UI composition, not new API
integration. This is genuinely a "foundation" phase, not a full 1:1
port, and calling it complete parity would be inaccurate.

## API integration report

**Every endpoint the frontend calls was verified against the real
router source** (`api/routers/*.py`), not assumed from
`API_DOCUMENTATION.md` alone — `POST /uploads`, `POST /analyses`,
`GET /analyses/{id}/report`, `GET /analyses/{id}/report.html`,
`GET /analyses/{id}/report.pdf`, `GET /history`.

**A real bug was found and fixed during this phase's own verification,
worth describing in full because of what it teaches**: after testing a
custom backend port via `NEXT_PUBLIC_API_BASE_URL=http://localhost:8001
npm run build`, every subsequent test silently kept hitting port 8001
even after reverting the intended port back to 8000 and restarting the
server — five separate end-to-end test attempts failed with what looked
like random flakiness (button clicks "not registering," analyses "not
completing"). Rather than attribute this to unreliable test tooling and
move on, the failures were root-caused with request/response network
logging, which immediately showed the real cause:
`net::ERR_CONNECTION_REFUSED` against port **8001** — a stale production
build. Next.js inlines `NEXT_PUBLIC_*` environment variables into the
compiled JavaScript bundle at **build time**; they are not read from the
environment at `next start` time the way a normal server-side variable
would be. The fix was a clean rebuild (`rm -rf .next && npm run build`)
against the correct `.env.local` value — after which the exact same test
that had failed five times in a row passed cleanly and repeatably. This
is documented here specifically so a future contributor changing the API
base URL doesn't lose the same time re-diagnosing it: **any change to
`NEXT_PUBLIC_API_BASE_URL` requires a full rebuild, not just a
restart.**

**Final, verified, working flow** (this exact sequence, confirmed live
against both real servers together, not mocked):
`POST /uploads` → `POST /analyses` → `GET /analyses/{id}/report` →
render Dashboard → `GET /analyses/{id}/report.html` (fetched, 200,
~464KB) → `GET /analyses/{id}/report.pdf` (fetched, 200, valid `%PDF-`
magic bytes) → navigate to `/history` → confirm the same filename
appears, proving the frontend reads the backend's real, persistent
history store (`api/services/store.py`), not a local mock.

**No direct engine access from the frontend**: verified structurally
(no Python import possible from TypeScript — a hard language boundary,
not just a convention) and confirmed by design: `lib/api-client.ts` is
the only file that constructs a URL against the backend, and every
other file imports from `lib/api-client.ts`, never a raw `fetch`.

## Self-review

### 1-4. Objectives, audit, regressions, tests

Every objective in the "frozen backend" instruction was met — zero
engine/reporting/API source files touched, confirmed by re-running the
full 48-test backend suite (unchanged pass count, same as Phase 6's
final state). Every objective in the "new frontend" list was addressed
at the *foundation* level explicitly requested by this phase's title —
component-based architecture, the ported design system, responsive
layout (Tailwind), dark/light mode (next-themes, verified toggle),
modern routing (App Router), global state (Zustand), an API service
layer, authentication-ready plumbing (`setAPIKey()` mirrors the
backend's `X-API-Key` header, currently a no-op exactly like the
backend's own auth-disabled-by-default state), error boundaries, loading
states, skeleton screens, notifications (`sonner` toasts on both success
and error paths), and a production Next.js folder structure. Automated:
backend's 48 tests, unchanged, still passing. Manual/E2E: the full
upload→analyze→dashboard→download→history flow, tested against real
servers, with the one real bug (stale env-var build) found, root-caused,
and fixed rather than worked around.

### 5-7. Critical review

**Bugs found and fixed this phase**: the stale-build/env-var bug above
(the most significant finding — a genuine "would have shipped broken"
issue if the person deploying it changed the API URL without knowing to
rebuild); a missing `api` import and an un-reactive `useAnalysisStore.getState()`
call introduced while adding the Downloads section to the Dashboard,
caught by TypeScript's build step itself (`npm run build` failing) before
runtime.

**Technical debt** (disclosed, not hidden):
- Only 3 of ~11 Streamlit pages' worth of content has a dedicated React
  view. The data (`AnalysisReport`) already flows end-to-end for
  everything; composing the remaining views (Charts via `recharts`,
  already installed but unused; Evidence; Recommendations; AI Coaching)
  is UI work, not new integration work — a reasonably fast follow-up
  given the foundation, but not done here.
- No automated frontend test suite (no Jest/Playwright test files
  committed for the React app itself) — verification this phase was
  thorough manual/E2E (matching this project's established pattern for
  UI-layer work since Phase 5A) but not codified into a repeatable CI
  check the way the backend's `pytest` suite is.
- Authentication is wired to be ready (`setAPIKey`) but nothing in the
  UI yet calls it — there's no login screen, because the backend itself
  has no user-account concept (Phase 3's auth is a single shared API
  key, not per-user). Building a login UI ahead of the backend
  supporting real users would be UI theater, not a real feature — not
  attempted here for that reason.
- The Next.js dev/production server was tested standalone in this
  sandbox; it was never tested behind a reverse proxy or in an actual
  containerized deployment alongside the FastAPI backend — a real,
  disclosed gap for a genuine "production SaaS platform" claim.

### 8. Completion score, production readiness, shipping recommendation

**82/100 for what this phase actually claims to be — a foundation, not
full parity.**

The frozen backend constraint was fully honored and verified, not just
asserted. The new frontend is genuinely real — built, compiled,
type-checked, and proven end-to-end against the live backend, including
a real bug found through actual debugging rather than dismissed as
flakiness. The score reflects the honestly-scoped gap between "SaaS
platform foundation" (what was asked and what was delivered) and "full
feature-parity replacement for the Streamlit app" (what was not
attempted, and would need another phase). I would ship this specific
foundation as the starting point for further frontend work; I would not
represent it as a complete replacement for the Streamlit app yet, and
this document says so plainly rather than leaving that ambiguous.
