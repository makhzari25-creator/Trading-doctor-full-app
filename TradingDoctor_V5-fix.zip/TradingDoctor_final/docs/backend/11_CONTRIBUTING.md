# Contributing Guide

## Before you start

Read `docs/01_ARCHITECTURE.md` first — specifically the "single source of
truth" rule. Most review feedback on a first contribution to this
codebase is some form of "this belongs in the engine, not here" or vice
versa; internalizing the boundary up front saves a review round-trip.

## Workflow

1. **Understand which layer your change belongs to** — engine
   (`engines/`, `core/`), reporting (`reporting/`, `templates/`), API
   (`api/`), or UI (`pages/`, `app.py`). See
   `docs/02_FOLDER_STRUCTURE.md`'s "Where to look for X" table.
2. **Write the test first, or at least alongside the change** — this
   codebase's history (see every `CHANGELOG_*.md` and the Phase 2/3
   self-reviews) shows that most real bugs were caught by *running* code
   against edge cases, not by reading it. Don't skip actually executing
   your change against a realistic and an edge-case input before
   considering it done.
3. **Run the full suite before submitting**: `pytest tests/ -q` — expect
   `48 passed` (or more, if you added tests, which you should have).
4. **If you touched `engines/` or `utils/`**, also manually verify the
   Streamlit app still boots (`streamlit run app.py`) and the CLI still
   runs end-to-end against a sample file — the test suite is strong but
   not 100% exhaustive of every UI code path.
5. **If you touched `reporting/`**, verify both HTML *and* PDF still
   render, including at least one edge-case dataset (empty, single trade,
   all-wins) — see `tests/test_reporting.py` for the exact edge cases
   this project cares about, and extend that list rather than writing a
   one-off manual check.
6. **If you touched `api/`**, run the API test suite and manually hit the
   changed endpoint(s) with `curl` or the `/docs` Swagger UI at least
   once — `TestClient`-only verification has missed real issues before in
   this project (see the Phase 3 self-review's CORS/concurrency findings,
   which required an actual running server to catch).

## Commit / PR description expectations

Given this project's established documentation style (see any
`CHANGELOG_*.md`), a good PR description states:
- **What changed** (files, in plain language)
- **Why** (what problem it solves, or what was verified broken)
- **How it was verified** (tests added/run, manual checks performed) —
  "should work" is not sufficient; this project's history strongly
  favors "ran X, got Y" over assertions
- **What it does NOT change** — especially relevant for engine work:
  explicitly confirm no scoring/threshold changed if that's the intent

## Code review checklist (what a reviewer should check)

- [ ] Does this stay within its architectural layer? (No score computed
      outside `engines/`; no engine class imported into `api/` outside
      `api/services/store.py`; no LLM call outside
      `engines/coaching_engine.py`.)
- [ ] Are new exceptions specific subclasses, not bare `Exception`?
- [ ] Is there a test? Does it test the actual bug/behavior, not just
      "doesn't crash"?
- [ ] If a threshold/formula changed, is `docs/07_ENGINE_REFERENCE.md`
      (or the relevant section) updated to match?
- [ ] If a new environment variable was added, is it documented in
      `docs/05_CONFIGURATION.md`?
- [ ] If a new dependency was added, is it in `requirements.txt` with a
      comment explaining why (matching the existing style)?
- [ ] No secrets, file paths, or raw tracebacks leak into any
      user-facing string (UI, CLI, HTTP response, or OpenAPI schema).

## Updating documentation alongside code

This `docs/` folder is generated from and cross-checked against the real
source (see the note at the top of `docs/07_ENGINE_REFERENCE.md`) — it is
not meant to drift from the code. If your change alters a documented
signature, threshold, environment variable, or architectural boundary,
update the relevant doc in the same PR. A useful sanity check before
submitting a documentation-affecting change:

```bash
# Re-run the same AST-based inventory used to build docs/07_ENGINE_REFERENCE.md
# and diff against what's documented, to catch drift:
python3 -c "
import ast, os
for root, _, files in os.walk('.'):
    if '__pycache__' in root or '.git' in root: continue
    for f in files:
        if f.endswith('.py'):
            path = os.path.join(root, f)
            ast.parse(open(path, encoding='utf-8').read())  # syntax sanity check
"
```

## Getting help understanding existing code

`docs/07_ENGINE_REFERENCE.md` documents *what* each class/function does
and *who calls it*. For *why* a specific line looks the way it does,
search `CHANGELOG_V23.md` and `CHANGELOG_V23_PHASE2.md` for the relevant
filename or bug description first — a surprising number of "why is this
here" questions are answered by a comment starting with `[AUDIT FIX]` in
the code itself, cross-referenced in one of those changelogs.
