# TradingDoctor V23 — Production Ready

نسخه‌ی ماژولار موتور تحلیل رفتار معاملاتی. V23 نسخه‌ی سخت‌شده (hardened)
V22 است: همان معماری و همان منطق تحلیلی، به‌علاوه‌ی اعتبارسنجی ورودی،
لاگینگ ساختاریافته، مدیریت خطای production-grade، و رفع باگ‌های واقعی
کشف‌شده در ممیزی کامل کد (جزئیات در CHANGELOG.md).

## ساختار پروژه

```
TradingDoctor/
│
├── main.py                   # نقطه‌ی ورود CLI
├── app.py                    # نقطه‌ی ورود Streamlit (صفحه‌ی اصلی + آپلود)
├── config.py                 # تنظیمات مرکزی (کلید LLM، آستانه‌ها، مسیرها) — safe env parsing
│
├── engines/
│   ├── behavior_engine.py     # نرمال‌سازی داده + امتیازهای رفتاری خام (قبلاً TradingDoctorV21_3)
│   ├── risk_engine.py         # واجهه‌ی متمرکز روی ریسک/Revenge/what-if (facade مستقل، تست‌شده)
│   ├── score_engine.py        # ContextBlock مالی + TrendEngine (قبلاً ContextEngine)
│   ├── evidence_engine.py     # استخراج شواهد رفتاری (Evidence/EvidenceType)
│   ├── diagnosis_engine.py    # تشخیص مشکل اصلی/ثانویه از شواهد
│   ├── psychology_engine.py   # پروفایل DNA/روان‌شناختی تریدر (قبلاً TraderDNAEngine)
│   ├── coaching_engine.py     # لایه‌ی نهایی: شواهد→تشخیص→DNA→اکشن‌پلن + توضیح LLM
│   └── report_engine.py       # FullResult + قالب‌بندی گزارش متنی/dict
│
├── llm/
│   ├── provider.py            # BaseLLMProvider + factory (get_llm)
│   ├── gemini.py              # پیاده‌سازی Gemini (auth از طریق هدر، نه URL)
│   ├── openai.py              # پیاده‌سازی OpenAI
│   ├── claude.py              # پیاده‌سازی Anthropic Claude
│   └── prompts.py             # قالب‌های prompt (جدا از منطق موتور)
│
├── utils/
│   ├── column_mapper.py        # نگاشت ستون‌های خام هر بروکر به شِمای استاندارد
│   ├── file_loader.py          # بارگذاری هر فرمت فایل (csv/xlsx/htm/json/log) — سخت‌شده
│   ├── validation.py           # [جدید V23] اعتبارسنجی production-grade داده‌ی آپلودشده
│   ├── sequence_analysis.py    # [جدید V23] محاسبات streak/mask برداری مشترک (DRY)
│   └── logger.py               # [جدید V23] پیکربندی متمرکز لاگینگ (کنسول + فایل چرخشی)
│
├── pages/                     # صفحات Streamlit (Dashboard/Charts/Behavioral/Diagnosis/...)
├── reports/                   # خروجی گزارش‌ها + trading_doctor.log (لاگ چرخشی)
├── templates/                 # قالب‌های گزارش (در صورت نیاز آینده)
├── data/                      # فایل‌های CSV نمونه
└── tests/
    ├── test_pipeline.py        # اسموک‌تست کل خط لوله
    ├── test_file_loader.py     # [جدید V23] تست‌های سخت‌سازی بارگذاری فایل
    ├── test_validation.py      # [جدید V23] تست‌های اعتبارسنجی داده
    └── test_sequence_analysis.py  # [جدید V23] تست معادل‌بودن منطق برداری با حلقه‌ی قدیمی
```

## اجرا

```bash
pip install -r requirements.txt

# CLI
python main.py path/to/trades.csv

# رابط وب (Streamlit)
streamlit run app.py
```

## تنظیم LLM

CoachingEngine به‌صورت پیش‌فرض تلاش می‌کند از Gemini استفاده کند. برای
فعال‌سازی، متغیر محیطی زیر را ست کنید:

```bash
export GEMINI_API_KEY="..."
# یا provider دیگر:
export TRADING_DOCTOR_LLM_PROVIDER=openai
export OPENAI_API_KEY="..."
```

اگر هیچ کلیدی تنظیم نشده باشد، برنامه کرش نمی‌کند — به‌صورت خودکار به
توضیح heuristic (قالب‌محور) قدیمی برمی‌گردد.

## لاگینگ (V23)

همه‌ی رویدادهای مهم (شروع/پایان تحلیل، زمان اجرا، هشدارهای اعتبارسنجی،
خطاهای Engine، درخواست/پاسخ LLM) در دو جا لاگ می‌شوند:
  - کنسول (stderr)
  - فایل چرخشی `reports/trading_doctor.log` (حداکثر ۵ مگابایت × ۳ فایل)

سطح لاگ با متغیر محیطی قابل‌تنظیم است:
```bash
export TRADING_DOCTOR_LOG_LEVEL=DEBUG   # پیش‌فرض: INFO
```

هیچ کلید API یا محتوای کامل prompt/پاسخ LLM هرگز لاگ نمی‌شود — فقط
متادیتا (provider، طول پیام، موفقیت/خطا).

## اعتبارسنجی داده (V23)

پیش از تحلیل، `utils/validation.validate_and_normalize` فایل آپلودشده را
بررسی می‌کند:
  - خطاهای فاجعه‌بار (فایل خالی، بدون ستون مالی/زمانی قابل‌شناسایی) →
    `DataValidationError` با پیام واضح و کاربرپسند.
  - مشکلات جزئی (ردیف تکراری، حجم صفر/منفی، تاریخ نامعتبر) → هرگز باعث
    کرش نمی‌شوند؛ به‌عنوان هشدار جمع‌آوری و روی `doctor.data_quality_warnings`
    در دسترس قرار می‌گیرند (نمایش‌داده‌شده در CLI و قابل‌دسترس در UI).

## نکات سازگاری با نسخه‌ی قبلی (V22)

برای اینکه کد قدیمی که مستقیماً کلاس‌های تک‌فایلی را ایمپورت می‌کرد نشکند،
نام‌های قبلی به‌صورت alias نگه داشته شده‌اند:

- `engines.behavior_engine.TradingDoctorV21_3` == `BehaviorEngine`
- `engines.score_engine.ContextEngine` == `ScoreEngine`
- `engines.psychology_engine.TraderDNAEngine` == `PsychologyEngine`

امضای توابع `analyze_dataframe`/`analyze_file` در `core/service.py`
بدون تغییر مانده (همان `(doctor, result, coach)` را برمی‌گرداند)، فقط
داخلش اعتبارسنجی و لاگینگ اضافه شده — کد مصرف‌کننده‌ی قدیمی نیازی به
تغییر ندارد.

## تست

```bash
python -m pytest tests/ -v
# یا بدون pytest:
python tests/test_pipeline.py
```

۲۲ تست (اسموک‌تست خط لوله + بارگذاری فایل + اعتبارسنجی + معادل‌بودن
منطق برداری) همگی پاس می‌شوند.

## تغییرات کامل V22 → V23

فهرست کامل باگ‌های رفع‌شده، دلایل فنی هر تغییر، و توصیه‌های V24+ در
[`CHANGELOG.md`](./CHANGELOG.md) مستند شده است.

