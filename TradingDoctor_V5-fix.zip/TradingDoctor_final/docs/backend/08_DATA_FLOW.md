# Data Flow

Three concrete, traced request flows — one per consumer — showing exactly
which function calls which, so you can debug "where did this number come
from" by following one of these paths rather than guessing.

## 1. Streamlit: upload → dashboard

```mermaid
sequenceDiagram
    participant User
    participant app.py
    participant file_loader as utils.file_loader
    participant validation as utils.validation
    participant service as core.service
    participant Behavior as BehaviorEngine
    participant Score as ScoreEngine
    participant Coach as CoachingEngine
    participant State as st.session_state

    User->>app.py: uploads file
    app.py->>service: analyze_file(file, llm_provider)
    service->>file_loader: load_any_file(file)
    file_loader-->>service: raw DataFrame
    service->>validation: validate_and_normalize(df)
    validation-->>service: (normalized df, warnings)
    service->>Behavior: BehaviorEngine(df)
    service->>Score: ScoreEngine(doctor).run()
    Score-->>service: FullResult
    service->>Coach: CoachingEngine(doctor).generate(result)
    Coach-->>service: coach dict
    service-->>app.py: (doctor, result, coach)
    app.py->>State: store doctor/result/coach
    app.py-->>User: "Analysis complete" + data-quality warnings
    User->>app.py: navigates to pages/01_Dashboard.py
    Note over app.py: page reads result/coach straight<br/>from st.session_state — no recomputation
```

## 2. REST API: upload → PDF download

```mermaid
sequenceDiagram
    participant Client
    participant Router as api/routers/*
    participant Store as AnalysisStore
    participant service as core.service
    participant Reporting as reporting/*

    Client->>Router: POST /api/v1/uploads (file)
    Router->>Store: save_upload(filename, bytes)
    Store-->>Router: UploadRecord
    Router-->>Client: 201 {upload_id}

    Client->>Router: POST /api/v1/analyses {upload_id}
    Router->>Store: run_analysis(upload_id) [in threadpool]
    Store->>service: analyze_file(...)
    service-->>Store: (doctor, result, coach)
    Store-->>Router: AnalysisRecord
    Router-->>Client: 201 {analysis_id, ...summary}

    Client->>Router: GET /api/v1/analyses/{id}/report.pdf
    Router->>Store: get_analysis(analysis_id)
    Store-->>Router: AnalysisRecord
    Router->>Reporting: render_pdf_report(result, coach, doctor) [in threadpool]
    Reporting-->>Router: PDF bytes
    Router-->>Client: 200 application/pdf
```

Note the two `[in threadpool]` annotations — both are genuinely CPU-bound
(pandas analysis; matplotlib/reportlab rendering) and would block the
event loop for every other concurrent request (including unrelated health
checks) if run inline in the `async def` handler. See
`docs/04_DEPLOYMENT.md` for what this offloading does and doesn't buy you.

## 3. CLI: file → text report + optional export

```mermaid
sequenceDiagram
    participant User
    participant main.py
    participant service as core.service
    participant ReportEngine
    participant Reporting as reporting/*

    User->>main.py: python3 main.py trades.csv --export-pdf out.pdf
    main.py->>service: analyze_file(file_path, llm_provider)
    service-->>main.py: (doctor, result, coach)
    main.py->>ReportEngine: ReportEngine(result, coach).print_report()
    ReportEngine-->>User: text report to stdout
    main.py->>Reporting: generate_pdf_report(result, coach, doctor)
    Reporting-->>main.py: PDF bytes
    main.py-->>User: writes out.pdf
```

Note: the CLI's stdout text report (`ReportEngine`) and its optional PDF
export (`reporting/pdf_report.py`) are two **independent** renderers of
the same `result`/`coach` — this is intentional (see
`docs/07_ENGINE_REFERENCE.md`'s note on `ReportEngine` vs. the Phase 2
reporting module), not duplication to clean up.

## Where the "single source of truth" rule is visible in these diagrams

In all three flows, notice that `result` and `coach` are computed exactly
**once**, at the `core.service` call, and then only ever *read* by
everything downstream (`pages/*.py`, `reporting/*.py`,
`api/models/analysis.py`'s response construction, `ReportEngine`). No
diagram above has a second arrow going back into `BehaviorEngine`,
`ScoreEngine`, `EvidenceEngine`, `DiagnosisEngine`, or `PsychologyEngine`
after the initial `core.service` call. If you're adding a feature and find
yourself needing to call back into an engine a second time for the same
analysis, stop and check whether the data you need should have been part
of `FullResult`/`coach` in the first place.

## Data-quality warnings: a cross-cutting flow worth tracing separately

```mermaid
graph LR
    A["utils.validation.validate_and_normalize()"] -->|"non-fatal warnings"| B["doctor.data_quality_warnings"]
    B --> C["main.py CLI output"]
    B --> D["app.py st.expander"]
    B --> E["reporting/data_context.py appendix.data_quality_warnings"]
    E --> F["HTML/PDF report Technical Appendix"]
```

This is a good second example to trace if you want to confirm you
understand the "compute once, read many times" pattern — the warnings
are generated in exactly one place and fan out to four different display
surfaces without ever being recomputed.
