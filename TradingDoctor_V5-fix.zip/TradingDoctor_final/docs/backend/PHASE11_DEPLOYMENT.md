# Phase 11 — Production Deployment Guide + Ops Runbook

> Complete guide for deploying Trading Doctor V23 to production, operating it
> day-to-day, and responding to incidents.

This document covers everything an on-call engineer needs to know.

---

## 1. Architecture Overview

```
                    ┌─────────────────────────────┐
                    │   Internet (users + Stripe) │
                    └────────────┬────────────────┘
                                 │
                    ┌────────────▼────────────────┐
                    │   nginx (TLS, rate limit)   │
                    │   port 80 → 443 redirect    │
                    └────────────┬────────────────┘
                                 │
                    ┌────────────▼────────────────┐
                    │   FastAPI (uvicorn x N)     │
                    │   port 8000                 │
                    └──┬─────────┬─────────────┬──┘
                       │         │             │
              ┌────────▼──┐ ┌───▼────┐ ┌──────▼──────┐
              │ Postgres  │ │ Redis  │ │  Celery     │
              │  (state)  │ │(cache) │ │  workers    │
              └───────────┘ └────────┘ └──────┬──────┘
                                               │
                                         ┌─────▼─────┐
                                         │  beat     │ (periodic tasks)
                                         └───────────┘
```

### Services

| Service | Container | Purpose | Port |
|---|---|---|---|
| `api` | td-api | FastAPI app (uvicorn x 4 workers) | 8000 (internal) |
| `worker` | td-worker | Celery worker (async analysis + emails) | — |
| `beat` | td-beat | Celery beat scheduler (periodic cleanup) | — |
| `db` | td-db | PostgreSQL 16 | 5432 (internal) |
| `redis` | td-redis | Redis 7 (cache + Celery broker) | 6379 (internal) |
| `nginx` | td-nginx | TLS termination + reverse proxy | 80, 443 |

---

## 2. First-Time Deployment

### 2.1 Provision the server

```bash
# Ubuntu 22.04+ / Debian 12+
apt update && apt upgrade -y
apt install -y docker.io docker-compose-v2 ufw fail2ban curl

# Firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# SSH hardening
sed -i 's/^#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd
```

### 2.2 Deploy the application

```bash
mkdir -p ~/td && cd ~/td
git clone <your-repo-url> .
cp .env.example .env.prod

# Generate secrets
openssl rand -hex 32  # → JWT_SECRET_KEY
openssl rand -hex 32  # → JWT_REFRESH_SECRET_KEY
openssl rand -hex 24  # → METRICS_AUTH_TOKEN
openssl rand -hex 16  # → REDIS_PASSWORD

# Edit .env.prod with production values
nano .env.prod
```

**Mandatory env vars:**

| Variable | Value |
|---|---|
| `TRADING_DOCTOR_ENV` | `production` |
| `DATABASE_URL` | `postgresql+asyncpg://td:PASS@db:5432/td` |
| `DATABASE_URL_SYNC` | `postgresql://td:PASS@db:5432/td` |
| `REDIS_URL` | `redis://:PASS@redis:6379/0` |
| `JWT_SECRET_KEY` | 64-char hex |
| `JWT_REFRESH_SECRET_KEY` | 64-char hex (different) |
| `TRADING_DOCTOR_API_CORS_ORIGINS` | `https://app.yourdomain.com` |
| `STRIPE_SECRET_KEY` | `sk_live_...` |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` |
| `STRIPE_PRICE_ID_PRO_MONTHLY` | `price_...` |
| `EMAIL_BACKEND` | `smtp` or `ses` |
| `TRADING_DOCTOR_USE_CELERY` | `true` |

### 2.3 Start the stack

```bash
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build

# Apply migrations
docker compose -f docker-compose.prod.yml --env-file .env.prod exec api alembic upgrade head

# Verify
curl https://api.yourdomain.com/api/v1/health/ready
# Expected: {"status":"ok","engine_ready":true,"db_ready":true,"redis_ready":true,...}
```

### 2.4 TLS certificates

```bash
apt install -y certbot
certbot certonly --standalone -d api.yourdomain.com \
  --non-interactive --agree-tos -m admin@yourdomain.com

mkdir -p deploy/nginx/certs
cp /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem deploy/nginx/certs/
cp /etc/letsencrypt/live/api.yourdomain.com/privkey.pem  deploy/nginx/certs/

docker compose -f docker-compose.prod.yml restart nginx
```

Auto-renewal cron:
```cron
0 3 * * * root certbot renew --quiet --post-hook "docker compose -f /root/td/docker-compose.prod.yml restart nginx"
```

### 2.5 Configure Stripe webhook

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://api.yourdomain.com/api/v1/billing/webhooks/stripe`
3. Subscribe to events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.finalized`
   - `invoice.paid`
   - `invoice.payment_failed`
4. Copy the signing secret → `STRIPE_WEBHOOK_SECRET` in `.env.prod`
5. Restart: `docker compose -f docker-compose.prod.yml restart api`

---

## 3. Day-to-Day Operations

### 3.1 Viewing logs

```bash
# All services
docker compose -f docker-compose.prod.yml logs --tail 100

# API only (follow)
docker compose -f docker-compose.prod.yml logs -f api

# Worker (Celery tasks)
docker compose -f docker-compose.prod.yml logs -f worker

# Structured JSON logs (pipe through jq)
docker compose -f docker-compose.prod.yml logs api | jq .

# Application log file (rotated)
docker compose -f docker-compose.prod.yml exec api cat reports/trading_doctor.log | tail -200
```

### 3.2 Running migrations

```bash
# Apply pending migrations
docker compose -f docker-compose.prod.yml exec api alembic upgrade head

# Check current revision
docker compose -f docker-compose.prod.yml exec api alembic current

# Rollback last migration (DESTRUCTIVE)
docker compose -f docker-compose.prod.yml exec api alembic downgrade -1
```

### 3.3 Backups

Manual backup:
```bash
./scripts/backup.sh
```

Automated (add to `/etc/cron.d/td-backup`):
```cron
0 2 * * * root cd /root/td && S3_BUCKET=s3://your-backup-bucket ./scripts/backup.sh >> /var/log/td-backup.log 2>&1
```

### 3.4 Updating the application

```bash
cd ~/td
git pull origin main
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build
docker compose -f docker-compose.prod.yml exec api alembic upgrade head
```

### 3.5 Restarting services

```bash
docker compose -f docker-compose.prod.yml restart api
docker compose -f docker-compose.prod.yml restart worker
docker compose -f docker-compose.prod.yml restart nginx
```

---

## 4. Monitoring + Alerting

### 4.1 Health endpoints

| Endpoint | Purpose |
|---|---|
| `GET /api/v1/health` | Liveness (cheap) |
| `GET /api/v1/health/ready` | Readiness (DB + Redis check) |
| `GET /metrics` | Prometheus metrics (Bearer token) |

### 4.2 Prometheus scrape config

```yaml
scrape_configs:
  - job_name: 'tradingdoctor'
    scrape_interval: 15s
    scheme: https
    metrics_path: /metrics
    bearer_token: '<METRICS_AUTH_TOKEN>'
    static_configs:
      - targets: ['api.yourdomain.com:443']
```

### 4.3 Key metrics to alert on

| Metric | Alert threshold |
|---|---|
| `http_requests_total{status=~"5.."}` | >1% of requests for 5 min |
| `http_request_duration_seconds{quantile="0.95"}` | >2s for 5 min |
| `analysis_runs_total{outcome="error"}` | >10% failure rate |
| DB health check | failing for 2 min |
| Redis health check | failing for 2 min |
| Disk usage | >80% |
| Worker queue depth | >100 pending jobs |

### 4.4 Sentry error tracking

Set `SENTRY_DSN` in `.env.prod`. Errors are auto-captured with stack traces.

---

## 5. Incident Response Runbook

### 5.1 API returning 502 Bad Gateway

**Cause:** API container crashed or isn't responding.

**Steps:**
1. Check if container is running: `docker compose -f docker-compose.prod.yml ps`
2. Check logs: `docker compose -f docker-compose.prod.yml logs --tail 100 api`
3. Restart: `docker compose -f docker-compose.prod.yml restart api`
4. If still failing, check DB: `docker compose -f docker-compose.prod.yml exec db pg_isready`

### 5.2 Database connection failures

**Cause:** DB down, connection pool exhausted, or network issue.

**Steps:**
1. Check DB health: `docker compose -f docker-compose.prod.yml exec db pg_isready -U tradingdoctor`
2. Check active connections: `docker compose -f docker-compose.prod.yml exec db psql -U tradingdoctor -c "SELECT count(*) FROM pg_stat_activity;"`
3. If pool exhausted, kill long-running queries:
   ```sql
   SELECT pid, now() - pg_stat_activity.query_start AS duration, query
   FROM pg_stat_activity
   WHERE state = 'active' AND now() - pg_stat_activity.query_start > interval '5 minutes';
   -- Then: SELECT pg_terminate_backend(PID);
   ```
4. Restart API to reset pool: `docker compose -f docker-compose.prod.yml restart api`

### 5.3 Worker not processing jobs

**Cause:** Celery worker crashed, Redis down, or queue backed up.

**Steps:**
1. Check worker status: `docker compose -f docker-compose.prod.yml logs --tail 100 worker`
2. Check Redis: `docker compose -f docker-compose.prod.yml exec redis redis-cli ping`
3. Check queue depth: `docker compose -f docker-compose.prod.yml exec redis redis-cli -n 1 llen celery`
4. Restart worker: `docker compose -f docker-compose.prod.yml restart worker`

### 5.4 Stripe webhooks not being processed

**Cause:** Webhook secret mismatch, nginx blocking, or handler failing.

**Steps:**
1. Check Stripe Dashboard → Webhooks for delivery failures
2. Test locally: `curl -X POST https://api.yourdomain.com/api/v1/billing/webhooks/stripe -H "Stripe-Signature: ..." -d '...'`
3. Check logs: `docker compose -f docker-compose.prod.yml logs api | grep webhook`
4. Verify `STRIPE_WEBHOOK_SECRET` matches Stripe Dashboard

### 5.5 Disk full

**Cause:** Uploads, logs, or DB WAL files filling disk.

**Steps:**
1. Check disk: `df -h`
2. Find large files: `du -sh /var/lib/docker/volumes/* | sort -h | tail -10`
3. Clean up old logs: `docker compose -f docker-compose.prod.yml exec api find reports/ -name "*.log.*" -mtime +7 -delete`
4. Run backup + cleanup: `./scripts/backup.sh` (this triggers cleanup of old soft-deletes)
5. Vacuum DB: `docker compose -f docker-compose.prod.yml exec db psql -U tradingdoctor -c "VACUUM FULL;"`

---

## 6. Backup + Disaster Recovery

### 6.1 RPO / RTO

- **RPO** (Recovery Point Objective): 24 hours — daily DB + uploads backup
- **RTO** (Recovery Time Objective): 1 hour — full redeploy from backup

### 6.2 Restore from backup

```bash
# 1. Stop the API to prevent writes during restore
docker compose -f docker-compose.prod.yml stop api worker beat

# 2. Restore database
gunzip -c /tmp/td-backups/db_20260101-020000.sql.gz | \
  docker compose -f docker-compose.prod.yml exec -T db \
    pg_restore -U tradingdoctor -d tradingdoctor --clean --if-exists

# 3. Restore uploads
tar xzf /tmp/td-backups/uploads_20260101-020000.tar.gz -C /var/lib/docker/volumes/td_uploads/_data/

# 4. Restart
docker compose -f docker-compose.prod.yml up -d
```

### 6.3 Restore from S3

```bash
# Download latest backup
aws s3 cp s3://your-backup-bucket/db/db_20260101-020000.sql.gz /tmp/
aws s3 cp s3://your-backup-bucket/uploads/uploads_20260101-020000.tar.gz /tmp/

# Then follow steps 2-4 above
```

---

## 7. CI/CD Pipeline

The GitHub Actions workflow (`.github/workflows/ci.yml`) runs:

1. **Lint** — ruff + black + engine immutability check
2. **Test** — pytest on Python 3.11 + 3.12
3. **Security** — bandit + pip-audit + secret scan
4. **Build** — Docker image build + smoke test
5. **Deploy** — push to ECR + ECS deploy (only on tagged release)

### Triggering a production deploy

```bash
git tag v1.0.0
git push origin v1.0.0
```

This triggers the deploy job, which:
1. Builds + pushes the Docker image to ECR
2. Updates the ECS task definition
3. Runs `alembic upgrade head` as a one-off task
4. Waits for the new task to be healthy
5. Switches the ALB target group

---

## 8. Celery Worker Operations

### 8.1 Starting a worker manually

```bash
docker compose -f docker-compose.prod.yml exec api \
  celery -A workers.celery_app worker --loglevel=info --concurrency=4
```

### 8.2 Monitoring worker

```bash
# Active tasks
docker compose -f docker-compose.prod.yml exec api \
  celery -A workers.celery_app inspect active

# Registered tasks
docker compose -f docker-compose.prod.yml exec api \
  celery -A workers.celery_app inspect registered

# Stats
docker compose -f docker-compose.prod.yml exec api \
  celery -A workers.celery_app inspect stats
```

### 8.3 Purging the queue

```bash
# Cancel all pending tasks (DESTRUCTIVE)
docker compose -f docker-compose.prod.yml exec api \
  celery -A workers.celery_app purge
```

### 8.4 Beat scheduler

The beat container runs periodic tasks:
- `purge_old_soft_deletes` — daily at 3 AM UTC
- `purge_old_jobs` — daily at 3 AM UTC
- `cleanup_orphan_uploads` — weekly

To modify the schedule, edit `workers/celery_app.py` → `beat_schedule`.

---

## 9. Phase 11 Completion Checklist

- [x] Celery worker + beat configured in docker-compose.prod.yml
- [x] Async `POST /analyses` (202 + job_id) when `TRADING_DOCTOR_USE_CELERY=true`
- [x] `GET /analyses/jobs/{job_id}` status polling endpoint
- [x] AnalysisJob ORM model + migration (`0005_phase11_jobs`)
- [x] Email tasks (verification, reset, welcome, invoice)
- [x] Cleanup tasks (soft-delete purge, orphan upload cleanup)
- [x] CI/CD pipeline (lint → test → security → build → deploy)
- [x] Backup script (DB + uploads + S3 + retention)
- [x] Production deployment guide
- [x] Ops runbook (incident response, monitoring, DR)
- [x] All 214 existing tests still pass
