# Merge Decision Log

## Decisions Made During Repository Integration

### 1. Backend: Z4 (Phase 12 Complete) Supersedes Z1 (Phase 7 Original)

**Decision:** KEEP Z4, ARCHIVE Z1
**Reason:** Z4 is the evolved version of Z1. All 125 files from Z1 are present in Z4 (212 files). Z4 adds 87 new files (auth, billing, workspace, workers, db, alembic) and modifies 11 files (api/main.py, routers, etc.) with Phase 7.5-12 enhancements.

**Files deleted from Z1 (not carried forward):**
| File | Reason |
|---|---|
| `api/services/store.py` | Dead code — Phase 12 audit fix (C2). Replaced by DB-backed repository pattern in Phase 9. Had a second engine call path that violated immutability contract. |
| `reports/trading_doctor.log` | Runtime log file, not source code. Generated at runtime. |

**Files modified in Z4 (11 files):**
| File | Change |
|---|---|
| `api/dependencies.py` | Removed dead `AnalysisStore` + `get_store` (Phase 12 fix C2) |
| `api/exceptions.py` | Added `FavoriteNotFoundError` (Phase 9) |
| `api/main.py` | Added auth/billing/workspace routers, lifespan, Sentry, metrics. Removed engine import (Phase 12 fix C1) |
| `api/routers/analyses.py` | User-scoped + tier enforcement + async Celery support |
| `api/routers/health.py` | Added `/health/ready` with DB+Redis checks |
| `api/routers/history.py` | User-scoped |
| `api/routers/reports.py` | User-scoped + report caching |
| `api/routers/uploads.py` | User-scoped + tier-gated upload |
| `requirements.txt` | Added 20+ dependencies (sqlalchemy, asyncpg, redis, jwt, bcrypt, stripe, celery, etc.) |
| `tests/test_api.py` | Rewritten for Phase 9 (auth + multi-tenant) |
| `utils/logger.py` | Added JSON logging mode for production |

---

### 2. Frontend: Z2 (Full Project) as Primary + Z3 Unique Files Preserved

**Decision:** KEEP Z2 as base, MERGE Z3 unique files
**Reason:** Z2 is more complete (161 files vs 36). Z2 has all 14 views, own auth API routes, Prisma schema, shadcn/ui components, design docs, and screenshots. Z3 is a simpler Phase 7 proof-of-concept with only 3 pages.

**Z3 files preserved (not in Z2):**
| File | Reason |
|---|---|
| `AGENTS.md` | AI assistant configuration — unique to Z3 |
| `CLAUDE.md` | AI assistant configuration — unique to Z3 |
| `.env.local` | Local environment template — unique to Z3 |
| `.env.local.example` | Local env example — unique to Z3 |
| `package-lock.json` | npm lockfile (Z2 uses bun.lock) — preserved for npm users |
| `public/file.svg` | Next.js default asset — unique to Z3 |
| `public/globe.svg` | Next.js default asset — unique to Z3 |
| `public/next.svg` | Next.js default asset — unique to Z3 |
| `public/vercel.svg` | Next.js default asset — unique to Z3 |
| `public/window.svg` | Next.js default asset — unique to Z3 |
| `src/app/favicon.ico` | Favicon — unique to Z3 |
| `src/components/error-boundary.tsx` | Error boundary component — unique to Z3 |
| `src/components/layout/Sidebar.tsx` | Sidebar component — unique to Z3 |
| `src/components/layout/ThemeToggle.tsx` | Theme toggle — unique to Z3 |

**Z3 files NOT preserved (superseded by Z2):**
| File | Reason |
|---|---|
| `src/components/ui/Badge.tsx` | Superseded by Z2's `src/components/ui/badge.tsx` (shadcn/ui, more complete) |
| `src/components/ui/Button.tsx` | Superseded by Z2's `src/components/ui/button.tsx` |
| `src/components/ui/Card.tsx` | Superseded by Z2's `src/components/ui/card.tsx` |
| `src/components/ui/EmptyState.tsx` | Z2 has equivalent in `src/components/td/empty-states.tsx` |
| `src/components/ui/KpiCard.tsx` | Z2 has equivalent in `src/components/td/stat-card.tsx` |
| `src/components/ui/Skeleton.tsx` | Superseded by Z2's `src/components/ui/skeleton.tsx` |
| `src/app/dashboard/page.tsx` | Superseded by Z2's `src/views/dashboard.tsx` (more complete) |
| `src/app/history/page.tsx` | Superseded by Z2's `src/views/history.tsx` (more complete) |
| `src/lib/api-client.ts` | Superseded by Z2's `src/lib/api/client.ts` (more complete) |
| `src/lib/store.ts` | Superseded by Z2's `src/lib/store/` directory (theme, auth, app stores) |

---

### 3. Repository Structure: Monorepo with backend/ and frontend/

**Decision:** Restructure into monorepo
**Reason:** User requested unified structure with `backend/` and `frontend/` subdirectories.

**Files moved (not renamed — path prefix added):**
| Original Location | New Location | Reason |
|---|---|---|
| `TradingDoctor/*` | `backend/*` | Backend code in subdirectory |
| `trading-doctor-full-project/*` | `frontend/*` | Frontend code in subdirectory |
| `backend/.github/` | `.github/` | CI/CD at root level |
| `backend/deploy/` | `deploy/` | Deployment configs at root |
| `backend/scripts/` | `scripts/` | Scripts at root |
| `backend/docs/` | `docs/backend/` | Backend docs in docs subdirectory |
| `backend/design/` | `docs/backend/` (merged) | Design docs merged with backend docs |
| `frontend/download/` | `docs/frontend/` | Frontend docs moved to docs |
| `backend/Dockerfile` | `docker/Dockerfile.backend` | Docker configs consolidated |
| `backend/docker-compose.yml` | `docker/docker-compose.dev.yml` | Renamed for clarity |
| `backend/docker-compose.prod.yml` | `docker/docker-compose.prod.yml` | Moved to docker/ |

**Test path fixes (4 tests):**
| Test File | Fix |
|---|---|
| `tests/test_phase11_workers.py` | Updated 4 path assertions to use `parent.parent.parent` instead of `parent.parent` (accounting for `backend/tests/` → root structure) |

---

### 4. No Code Changes (Behavior Preserved)

**Decision:** No refactoring of business logic
**Reason:** User explicitly stated "در صورت کوچک‌ترین احتمال تغییر رفتار، Refactor انجام نده"

**What was NOT changed:**
- No Python imports modified (all relative paths preserved within backend/)
- No TypeScript imports modified (frontend is self-contained)
- No engine code touched (frozen V23 engine)
- No API contracts changed
- No database schema altered
- No authentication logic modified
- No billing logic modified
- No test logic changed (only file path assertions updated for new structure)

---

### 5. Prisma vs Alembic Conflict

**Decision:** Keep BOTH (no deletion)
**Reason:** Backend uses Alembic/SQLAlchemy (production-ready, 12 tables, 5 migrations). Frontend's full-project has its own Prisma schema. These represent different architectural approaches:
- Backend: FastAPI + SQLAlchemy async + Alembic (Python ecosystem)
- Frontend: Next.js API routes + Prisma (JavaScript ecosystem)

**Resolution:** Both are preserved as-is. The backend's Alembic is the production database layer. The frontend's Prisma schema is preserved in `frontend/prisma/` for reference/future use. No deletion, no modification.

**Architectural note:** In production, the frontend should call the FastAPI backend's API (not its own Prisma routes). The frontend's `src/app/api/auth/*` routes are preserved but should be considered superseded by the backend's `/api/v1/auth/*` endpoints.
