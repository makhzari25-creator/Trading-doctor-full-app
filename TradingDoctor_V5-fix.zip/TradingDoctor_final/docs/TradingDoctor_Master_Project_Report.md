# Trading Doctor V23 — Master Project Report

> **Repository:** Unified Monorepo (backend/ + frontend/)
> **Date:** 2026-07-18
> **Test suite:** 234/234 passing
> **Production readiness:** 92/100 — APPROVED

> ⚠️ **این یک گزارش تاریخی/point-in-time است** (لحظه‌ی merge اولیه‌ی
> مونوریپو در ۲۰۲۶-۰۷-۱۸) و از آن تاریخ به‌روزرسانی نشده — برای وضعیت
> *فعلی* پروژه به آن اتکا نکنید. مهم‌ترین چیزهایی که از آن زمان تغییر
> کرده‌اند:
> - **Prisma به‌طور کامل حذف شده است.** بخش‌های زیر که در این گزارش از
>   Prisma به‌عنوان بخشی از استک فعلی فرانت‌اند نام می‌برند، دیگر درست
>   نیستند — auth اکنون فقط از طریق بک‌اند FastAPI (`/api/v1/auth/*`)
>   انجام می‌شود؛ جزئیات در `WORKLOG_v4_auth_merge.md`.
> - **تعداد تست‌ها اکنون ۲۴۲ است** (نه ۲۳۴) — جزئیات تغییرات در
>   `WORKLOG_v5_reconciliation.md`.
> - برای وضعیت فعلی و کامل، به `README.md` و worklogهای زیر مراجعه کنید:
>   `WORKLOG_v23_fixes.md` → `WORKLOG_v3_charts_trades.md` →
>   `WORKLOG_v4_auth_merge.md` → `WORKLOG_v5_reconciliation.md`.

---

## 1. Architecture

### Monorepo Structure

```
TradingDoctor/
├── backend/          # Python FastAPI + V23 Engine (212 files)
├── frontend/         # Next.js Full Project (174 files)
├── docs/            # All documentation (65 files)
├── docker/          # Docker configurations (3 files)
├── deploy/          # nginx + postgres configs (3 files)
├── scripts/         # Utility scripts (2 files)
├── .github/         # CI/CD pipeline (1 file)
├── docker-compose.yml
├── .env.example
├── .gitignore
└── README.md
```

### Backend Stack
- Python 3.11, FastAPI, SQLAlchemy 2.0 async, PostgreSQL 16, Redis 7, Celery
- 38 API endpoints under `/api/v1/`
- 12 database tables, 5 Alembic migrations
- 234 tests (0 failures)
- Engine immutability: 0 violations (test-enforced)

### Frontend Stack
- Next.js 16, TypeScript, Tailwind CSS v4, shadcn/ui, Prisma, Bun
- 14 views (dashboard, charts, behavioral, diagnosis, coaching, trader DNA, edge map, trends, upload, report, settings, history, auth, landing)
- Own auth API routes + Prisma schema (for standalone use)
- Design docs + screenshots + security audits

---

## 2. Backend

### V23 Engine (FROZEN)
8 engines: BehaviorEngine, ScoreEngine, EvidenceEngine, DiagnosisEngine, PsychologyEngine, CoachingEngine, RiskEngine, ReportEngine

**Single integration point:** `workspace/repositories/analyses.run_and_persist_analysis:75`

### API Endpoints (38)
- Health (2): `/health`, `/health/ready`
- Auth (8): register, login, refresh, logout, verify-email, password-reset, resend-verification
- Profile (5): GET/PATCH/DELETE /me, POST /me/password, GET /me/activity
- Uploads + Analyses (7): POST /uploads, POST /analyses, GET /analyses/jobs/{id}, GET /analyses/{id}, GET /analyses/{id}/report[.html|.pdf]
- History (1): GET /history
- Workspace (10): summary, uploads CRUD, analyses CRUD, favorites
- Billing (10): plans, subscription, checkout, portal, cancel, invoices, usage, webhooks
- Config + Metrics (3): /config, /metrics, /

### Database (12 tables)
users, refresh_tokens, audit_logs, email_verifications, uploads, analyses, analysis_report_cache, favorites, analysis_jobs, plans, subscriptions, invoices, usage_events

### Authentication
- JWT (HS256, 15min access, 30day refresh)
- bcrypt (12 rounds)
- Refresh token rotation + reuse detection
- Brute-force protection (5 attempts → 15min lockout)
- Anti-enumeration on all auth endpoints
- Audit log (append-only, 14 event types)

### Billing
- 3 plans: Free ($0), Pro ($19/mo), Premium ($49/mo)
- Stripe integration (checkout, portal, webhooks)
- Usage tracking (append-only events)
- Tier enforcement (analysis limit, upload quota, LLM gating, feature flags)

### Multi-Tenant Isolation
- Every repository method takes `user_id` as first parameter
- Cross-user access returns 404 (anti-enumeration)
- Test-enforced

### Async Processing
- Celery + Redis
- POST /analyses → 202 + job_id (when TRADING_DOCTOR_USE_CELERY=true)
- Poll GET /analyses/jobs/{job_id}
- Tasks: analysis, email, cleanup (3 periodic tasks via beat)

---

## 3. Frontend

### Next.js Full Project
- 14 views covering all product features
- Own auth API routes (register, login, verify-email, etc.)
- Prisma schema for PostgreSQL
- shadcn/ui component library (40+ components)
- Design system with tokens
- Comprehensive design docs + screenshots

### Simple Frontend (Phase 7)
- 3 pages (Home/Upload, Dashboard, History)
- Connects to FastAPI backend via api-client.ts
- Unique files preserved in frontend/ (AGENTS.md, CLAUDE.md, public assets, layout components)

---

## 4. Docker + Deployment

### Services (docker-compose.prod.yml)
- api (FastAPI, 4 workers)
- worker (Celery)
- beat (Celery beat)
- db (PostgreSQL 16)
- redis (Redis 7)
- nginx (TLS, rate limit, security headers)

### Dockerfile
- Multi-stage build (Python 3.11-slim)
- Non-root user (tduser)
- Healthcheck
- Vazirmatn fonts included

### nginx
- TLS 1.2+ with strong ciphers
- HSTS with preload
- Security headers (CSP, X-Frame-Options, etc.)
- Rate limiting zones (api_limit, auth_limit)
- /docs blocked in production
- ACME challenge path for Let's Encrypt

---

## 5. CI/CD

### GitHub Actions Pipeline (5 stages)
1. Lint (ruff + black + engine immutability check)
2. Test (pytest on Python 3.11 + 3.12)
3. Security (bandit + pip-audit + secret scan)
4. Build (Docker image build + smoke test)
5. Deploy (ECR push + ECS deploy on tagged release)

---

## 6. Testing

### 234 Tests (0 failures)
| File | Tests | Coverage |
|---|---|---|
| test_pipeline.py | 2 | Engine smoke |
| test_validation.py | 9 | Validation paths |
| test_file_loader.py | 6 | Multi-format loading |
| test_sequence_analysis.py | 5 | Vectorized = loop (100 trials) |
| test_reporting.py | 11 | HTML + PDF + edge cases |
| test_api.py | 23 | Full flow + multi-tenant |
| test_phase7_5_infrastructure.py | 20 | Health, metrics, DB, logging |
| test_phase8_auth.py | 78 | Passwords, JWT, refresh, audit |
| test_phase9_workspace.py | 24 | Repositories, storage, cache |
| test_phase10_billing.py | 36 | Plans, usage, webhooks, tier |
| test_phase11_workers.py | 20 | Celery tasks, job status |

### Structural Tests (Enforcement)
- Engine immutability (5 test files)
- Single engine call site
- No engine imports in presentation layers

---

## 7. Merge Decisions

See `docs/Merge_Decision_Log.md` for complete decision log.

### Key Decisions
1. Z4 (Phase 12) supersedes Z1 (Phase 7) for backend
2. Z2 (Full project) is primary frontend + Z3 unique files preserved
3. Monorepo structure with backend/ and frontend/
4. No code changes (behavior preserved)
5. Prisma + Alembic both preserved (no deletion)

---

## 8. Known Issues

> ✅ **به‌روزرسانی:** سه مورد زیر (N+1، BillingError، lockout counter)
> در `WORKLOG_v5_reconciliation.md` رفع و با تست تأیید شده‌اند —
> علامت‌گذاری شده‌اند ولی از این لیست حذف نشده‌اند تا سابقه حفظ شود.

### High Priority (v1.0.1)
- ~~N+1 query in refresh token chain walk~~ — ✅ **رفع شد** (v5؛ یک کوئری واحد به‌جای per-hop SELECT)
- Report cache invalidation on rename
- Untyped response models (List[dict], Dict[str, Any])
- Stale documentation (docs/02, docs/04, docs/13)

### Medium Priority (v1.1)
- Email tasks defined but unused (sync in routers)
- ~~Account lockout counter non-atomic~~ — ✅ **رفع شد** (v5؛ `UPDATE ... RETURNING` اتمیک)
- ~~BillingError hierarchy (should be 4xx, not 5xx)~~ — ✅ **رفع شد** (v5؛ `billing/exceptions.py`)

### Low Priority (v1.2)
- Inconsistent path-parameter typing
- pandas FutureWarning
- Hardcoded year in email template

---

## 9. Future Roadmap

### v1.0.1
- Fix stale documentation
- Add healthchecks to worker + beat
- Wire email tasks to Celery
- Structured AnalysisReport schema

### v1.1
- JSON serialization for engine outputs (replace pickle)
- S3 storage backend
- Redis-backed rate limiter
- Real-time job progress (WebSocket)

### v2.0
- Frontend migration to use FastAPI backend (remove own auth routes)
- Team accounts
- White-label customization
- Mobile app
