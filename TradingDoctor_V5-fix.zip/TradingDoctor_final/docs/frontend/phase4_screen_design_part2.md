# Trading Doctor — Phase 4 Screen Design Specification, Part 2 (Expanded Screens)

**Author:** Senior Product Designer
**Status:** For approval — gate for Phase 5 (Implementation Kickoff)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Builds on:** Phase 1 IA (approved) · Phase 2 Visual Design + UX Architecture v1.2 (approved) · Phase 3 Design System v1.1 (approved) · Phase 4 Screen Design Part 1 (approved)
**Reference tier:** Linear · Stripe · Vercel · TradingView
**Document version:** v1.0 (companion to `phase4_screen_design.md`)

> **Purpose of this document:**
> Phase 4 Part 1 (`phase4_screen_design.md`) specified all 20 screens. This Part 2 **expands the 9 remaining screens** to match — and exceed — the detail level of the core screens (Dashboard, Upload, Behavioral Analysis, Trade Explorer, Report Center). Each screen here gets full mobile/tablet/desktop ASCII layouts, exact Phase 3 component references, complete interaction/hover/micro-interaction tables, all states, accessibility, and edge cases.
>
> **Screens expanded in this document (9):**
> 1. Psychology Analysis (Trader DNA)
> 2. Overview
> 3. Performance Analysis
> 4. Risk Analysis
> 5. Evidence Explorer
> 6. Trade Detail
> 7. Profile (future-ready)
> 8. Subscription (future-ready)
> 9. Notifications (future-ready)
>
> **Phase 1 hard constraints (carried — non-negotiable):**
> 1. Mobile-first & responsive by design.
> 2. Dashboard = emotional center (4 cards above fold on 375 × 667).
> 3. Clarity > Complexity · Actionability > Information Density · Premium SaaS > Feature Quantity.
> 4. Persian-first RTL · dark-default + light-supported · engine untouched.

---

## Table of Contents

1. Psychology Analysis (Trader DNA) — Expanded
2. Overview — Expanded
3. Performance Analysis — Expanded
4. Risk Analysis — Expanded
5. Evidence Explorer — Expanded
6. Trade Detail — Expanded
7. Profile (future-ready) — Expanded
8. Subscription (future-ready) — Expanded
9. Notifications (future-ready) — Expanded
10. Cross-Screen Edge Case Patterns
11. Updated Changes Summary

---

## 1. Psychology Analysis (Trader DNA) — Expanded

### Purpose
Psychological archetype profile with narrative and supporting evidence. Answers "What kind of trader am I?" — the identity-defining screen that turns data into self-awareness.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — consumes:
- `trader_profile` (a.k.a. `psychology.dna`) — the archetype dict
- `psychology.narrative` — the explanatory text
- `evidence[]` — top-8 prioritized evidence (filter to top 3 supporting the archetype)
- `behavior_analysis.scores` — for the supporting radar chart

### Phase status
Phase 1 build (maps to Phase 2 §3.9 Trader DNA).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  روانشناسی        [⌘K][☀][فا/EN] │
├─────────────────────────────────────┤
│  دی‌ان‌ای معامله‌گر                    │ ← --text-h1 24px, --space-6 from top bar
│  شما چه نوع معامله‌گری هستید؟         │ ← --text-body-sm, --fg-secondary
│                                      │
│  ┌─────────────────────────────┐    │ ← ArchetypeHeroCard (full-width)
│  │         ┌─────────┐          │    │   --bg-elevated, --elevation-2
│  │         │  [DNA   │          │    │   --radius-2xl, --space-8 padding
│  │         │   48px] │          │    │   centered content
│  │         └─────────┘          │    │
│  │                              │    │
│  │    معامله‌گر انتقامی            │    │ ← --text-data-xl 28px mono, bold
│  │    Revenge Trader             │    │   --fg-primary, centered
│  │                              │    │
│  │  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  │    │ ← subtle divider, --border-subtle
│  │                              │    │
│  │  این پروفایل بر اساس           │    │ ← --text-body-sm, --fg-secondary
│  │  مهم‌ترین شواهد رفتاری شما      │    │   centered, max-width 280px
│  │  تعیین شده است.                 │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-6 gap
│  ──── روایت روانشناختی ────          │ ← section header, --text-h3, --space-6
│  ┌─────────────────────────────┐    │ ← NarrativeCard
│  │ پروفایل رفتاری غالب:          │    │   --bg-elevated, --elevation-2
│  │ «معامله‌گر انتقامی».           │    │   --radius-xl, --space-6 padding
│  │                              │    │   max-width 640px (narrow for readability)
│  │ این آرچیتایپ بر اساس مهم‌ترین   │    │
│  │ شاهد رفتاری شناسایی‌شده در      │    │ ← --text-body 16px, line-height 1.6
│  │ تاریخچه‌ی معاملاتی شما تعیین     │    │
│  │ شده است (نه یک آستانه‌ی ثابت).  │    │
│  │                              │    │
│  │ معامله‌گران انتقامی پس از یک    │    │
│  │ باخت، تمایل به ورود سریع به     │    │
│  │ معامله‌ی بعدی با حجم بزرگ‌تر     │    │
│  │ دارند. این رفتار اغلب ناخودآگاه │    │
│  │ است و می‌تواند ضررهای قابل‌توجهی │    │
│  │ ایجاد کند...                   │    │
│  │                              │    │
│  │ (۳–۵ پاراگراف متن کامل)         │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-6 gap
│  ──── شواهد پشتیبان (۳) ───ـ         │ ← section header
│  ┌─────────────────────────────┐    │ ← EvidenceCard (compact) #1
│  │ [⚠] معامله‌ی انتقامی            │    │   severity-bordered (--severity-high)
│  │ ۱۲ رویداد · ۱٬۸۴۰ دلار ضرر      │    │   --bg-elevated, --elevation-2
│  │ اولویت: ۹۲/۱۰۰                │    │   --radius-lg, --space-4 padding
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #2
│  │ [○] بیش‌معامله‌گری               │    │   severity-bordered (--severity-medium)
│  │ ۸ رویداد · ۴۲۰ دلار ضرر         │    │
│  │ اولویت: ۶۸/۱۰۰                │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #3
│  │ [○] ریسک‌پذیری در حجم           │    │
│  │ ۵ رویداد · ۲۱۰ دلار ضرر         │    │
│  │ اولویت: ۵۵/۱۰۰                │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-6 gap
│  ───ـ امتیازهای رفتاری ───ـ          │ ← section header
│  ┌─────────────────────────────┐    │ ← ScoreRadarCard (compact mobile version)
│  │ [Mini Radar Chart 200×200]   │    │   5-axis radar, static on mobile
│  │  انتقام ۴۵٪ · بیش‌معامله ۳۰٪   │    │   legend below
│  │  ریسک ۲۵٪ · صبر ۸۰٪           │    │
│  │  انضباط ۶۷٪                   │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-6 gap
│  [🔍 مشاهده تشخیص کامل →]             │ ← secondary CTA, full-width
│  [📄 گزارش کامل را دانلود کن]         │ ← ghost CTA, full-width
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← 64px bottom tab bar + safe area
```

**Tablet (768–1023px):**
```
┌──────────────────────────────────────────────────────┐
│ [Logo] [📊 analysis badge]        [⌘K][☀][فا][👤]      │
├──────────────────────────────────────────────────────┤
│  [Sidebar icon-rail 72px]  │  Content area            │
│  [Gauge]                   │  دی‌ان‌ای معامله‌گر         │
│  [Bar]                     │                          │
│  [Stetho]                  │  ┌──────────────────────┐ │
│  [Light]                   │  │ ArchetypeHeroCard    │ │ ← centered, max-width 480px
│  [DNA]  ← active           │  │ [DNA 48px]           │ │
│  [Map]                     │  │ معامله‌گر انتقامی     │ │
│  [Chart]                   │  │ Revenge Trader       │ │
│  [Table]                   │  └──────────────────────┘ │
│  [Trend]                   │                          │
│  [File]                    │  ┌────روایت────┐ ┌─شواهد─┐│
│  [Clock]                   │  │             │ │       ││
│  [Gear]                    │  │ Narrative   │ │ 3 Ev  ││ ← 2-column: narrative left,
│                            │  │ Card        │ │ Cards  ││   evidence right (sticky)
│                            │  │ (narrow     │ │       ││
│                            │  │  640px)     │ │       ││
│                            │  └─────────────┘ └───────┘│
│                            │                          │
│                            │  [Mini Radar Chart]       │
│                            │  [CTAs]                   │
└──────────────────────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [Logo] Trading Doctor  [📊 trades_jan.csv · 1,245 trades · 2024-01-15]  │
│                                          [⌘K] [☀] [فا] [👤] [📄 Report]  │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌──────────┐                                                            │
│  │ Sidebar  │  Dashboard › Trader DNA                                    │
│  │ 240px    │                                                            │
│  │          │  ┌──────────────────────────────────────────────────────┐  │
│  │ [Gauge]  │  │                    [DNA helix decoration]              │  │
│  │ [Bar]    │  │                                                        │  │
│  │ [Stetho] │  │                    [DNA 48px icon]                     │  │
│  │ [Light]  │  │                                                        │  │
│  │ [DNA]←act│  │              معامله‌گر انتقامی                          │  │ ← ArchetypeHeroCard
│  │ [Map]    │  │              Revenge Trader                             │  │   large, centered
│  │ [Chart]  │  │                                                        │  │   --radius-2xl
│  │ [Table]  │  │   این پروفایل بر اساس مهم‌ترین شواهد رفتاری شما...      │  │
│  │ [Trend]  │  │                                                        │  │
│  │ [File]   │  └──────────────────────────────────────────────────────┘  │
│  │ [Clock]  │                                                            │
│  │ [Gear]   │  ┌────────────────────────────┐  ┌────────────────────┐   │
│  │          │  │ روایت روانشناختی             │  │ شواهد پشتیبان (۳)   │   │ ← 2-column
│  │          │  │                            │  │                    │   │   narrative left (640px)
│  │          │  │ پروفایل رفتاری غالب:        │  │ [EvidenceCard #1]  │   │   evidence right (sticky)
│  │          │  │ «معامله‌گر انتقامی»...        │  │ [EvidenceCard #2]  │   │
│  │          │  │                            │  │ [EvidenceCard #3]  │   │
│  │          │  │ (۳–۵ پاراگراف)              │  │                    │   │
│  │          │  │                            │  │ ┌────────────────┐ │   │
│  │          │  │                            │  │ │ Mini Radar     │ │   │
│  │          │  │                            │  │ │ 5-axis scores  │ │   │
│  │          │  │                            │  │ └────────────────┘ │   │
│  │          │  └────────────────────────────┘  └────────────────────┘   │
│  │          │                                                            │
│  │          │  [🔍 مشاهده تشخیص کامل →]  [📄 گزارش کامل را دانلود کن]     │
│  └──────────┘                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Archetype label** (`--text-data-xl`, mono, centered) — the one-word identity answer. This is the first thing the eye lands on.
2. **DNA icon** (48px, `--accent-primary`) — visual anchor above the label.
3. **Narrative** (`--text-body`, narrow 640px container) — the explanation, readable not scannable.
4. **Supporting evidence** (3 compact EvidenceCards) — the proof, scannable.
5. **Mini radar chart** — visual comparison of all 5 scores.
6. **CTAs** — drill to diagnosis or download report.

### Component Placement (exact Phase 3 components)

| Position | Component (Phase 3 ref) | Content |
|---|---|---|
| Top bar | TopBar (custom, Phase 2 §11) | Logo + analysis badge + theme/lang/account |
| Page header | Breadcrumbs (§32) + H1 (`--text-h1`) | "Dashboard › Trader DNA" + "دی‌ان‌ای معامله‌گر" |
| Hero | ArchetypeHeroCard (composite, §39.2 pattern) | DNA icon + archetype label + summary |
| Narrative | Card (default variant, §20) + Typography | `psychology.narrative` text, narrow container |
| Evidence | EvidenceCard (composite, §39.2) ×3 compact | Top 3 evidence by priority_score |
| Radar | Chart (radar variant, §25) | 5-axis behavioral scores |
| CTAs | Button (secondary, §19) + Button (ghost, §19) | "مشاهده تشخیص کامل" + "دانلود گزارش" |
| Mobile nav | BottomTabBar (custom) + Drawer | 5 tabs + More sheet |

### Cards

| Card | Variant (§20) | Border | Padding | Content | Engine source |
|---|---|---|---|---|---|
| ArchetypeHeroCard | elevated | none (decorative DNA helix on desktop) | `--space-8` | DNA icon (48px `--icon-lg`), archetype (`--text-data-xl` mono), summary (`--text-body-sm`) | `trader_profile.archetype` |
| NarrativeCard | default | `--border-subtle` | `--space-6` | 3–5 paragraphs (`--text-body`, line-height 1.6, max-width 640px) | `psychology.narrative` |
| EvidenceCard ×3 | severity-bordered | `--severity-*` (4px inline-start) | `--space-4` | Type icon, label, frequency, $ impact, priority score | `evidence[0..2]` |
| ScoreRadarCard | default | `--border-subtle` | `--space-5` | Mini radar chart (200×200 mobile, 240×240 desktop) + legend | `behavior_analysis.scores` |

### Tables
None.

### Charts
- **Mini Radar Chart** (Recharts `<RadarChart>`): 5 axes (Revenge, Overtrading, Risk-Taking, Patience, Discipline). `--chart-primary` (`#3B82F6` dark / `#1E40AF` light) with 20% fill. Static on mobile (no animation), animated grow-from-center on desktop (500ms `--ease-out`, frozen if reduced-motion). Legend below: 5 items, `--text-caption`, color swatch + label + value.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch `GET /analyses/{id}/report`. Show skeletons. On arrival, staggered fade-up. |
| 2 | Click ArchetypeHeroCard icon (desktop) | Tooltip appears: «این آرچیتایپ بر اساس قوی‌ترین شواهد رفتاری شما نام‌گذاری شده است» |
| 3 | Click EvidenceCard | Expand to show full description + confidence + «مشاهده‌ی معاملات مرتبط» CTA |
| 4 | Click «مشاهده‌ی معاملات مرتبط» (expanded evidence) | Navigate to `/trades/[id]?evidence={type}` |
| 5 | Hover radar chart axis (desktop) | Tooltip with that score's value + severity |
| 6 | Click «مشاهده تشخیص کامل» | Navigate to `/diagnosis/[id]` |
| 7 | Click «گزارش کامل را دانلود کن» | Navigate to `/report/[id]` |
| 8 | Click analysis badge (top bar) | Drawer opens with History list (recent 5) |
| 9 | Click theme toggle | Instant theme switch |
| 10 | Click language toggle | Instant language switch (fa/en) |
| 11 | Mobile: tap bottom tab bar item | Navigate to that page |
| 12 | Mobile: swipe edge | Open nav drawer |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| ArchetypeHeroCard | `--elevation-2` | (non-interactive, but subtle icon glow: `--accent-primary` at 0→20% opacity behind icon) | 200ms `--ease-out` |
| EvidenceCards | `--elevation-2`, `--border-subtle` | `--elevation-3`, border brightens to severity color, cursor pointer | 200ms `--ease-out` |
| Radar chart axes | default stroke | highlight (stroke width 2→3px, `--accent-primary`) | 200ms |
| «مشاهده تشخیص کامل» button | `--fg-secondary`, ghost | `--accent-primary`, underline, arrow slides right 4px | 200ms |
| «دانلود گزارش» button | `--fg-secondary`, ghost | `--accent-primary` | 200ms |
| Analysis badge | `--bg-elevated` | `--bg-hover` | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Hero | Narrative | Evidence | Radar |
|---|---|---|---|---|---|
| `< sm` (375px) | Single column, stacked | Full-width, centered | Full-width, narrow text | Stacked cards | Below evidence, 200×200 |
| `sm` to `< md` (640–767px) | Same as mobile | Same | Same | Same | Same |
| `md` to `< lg` (768–1023px) | 2-column below hero | Centered, max-width 480px | Left column (640px) | Right column (sticky) | Below evidence |
| `≥ lg` (1024px+) | 2-column, DNA helix decoration on hero | Large, centered, max-width 720px | Left (640px) | Right (sticky), 240×240 radar | In right column |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → content staggered fade-up (hero first, narrative 200ms after, evidence 100ms staggered) | 400ms total | `--ease-out` |
| Hero icon entrance | Scale 0.8 → 1 + fade, subtle overshoot | 400ms | `--ease-spring` |
| Archetype label entrance | Fade-up, 200ms after icon | 300ms | `--ease-out` |
| Narrative paragraphs | Fade-in staggered 100ms as user scrolls into view | 200ms per paragraph | `--ease-out` |
| Evidence cards | Staggered fade-up, 100ms per card | 300ms total | `--ease-out` |
| Radar chart (desktop) | Polygon grows from center | 500ms | `--ease-out` |
| Evidence card expand | Height auto + content fade | 250ms | `--ease-out` |
| Icon hover (desktop) | Glow opacity 0 → 0.2 | 200ms | `--ease-out` |
| CTA arrow hover | TranslateX 0 → 4px | 200ms | `--ease-out` |
| Reduced motion | All animations ≤1ms, instant render | — | — |

### States

**Loading:**
- ArchetypeHeroCard: large skeleton block (48px icon placeholder + 28px text placeholder).
- NarrativeCard: 5 skeleton paragraph lines (varying widths for realism).
- EvidenceCards: 3 skeleton cards with icon/label/stats placeholders.
- Radar chart: skeleton circle with axis lines.
- Pulse animation 1.5s (frozen if reduced-motion → static grey blocks).

**Empty (archetype is "N/A" or empty):**
- ArchetypeHeroCard shows: «پروفایل هنوز تعیین نشده» (`--text-h3`, `--fg-secondary`).
- Description: «با داده‌ی بیشتر، موتور می‌تواند پروفایل رفتاری شما را شناسایی کند.»
- CTA: «تحلیل دوباره با داده‌ی بیشتر» → `/upload`.
- NarrativeCard hidden. EvidenceCards hidden. Radar chart hidden.

**Empty (narrative is empty):**
- Hide NarrativeCard entirely. Don't show empty card.
- Hero + evidence + radar still show.

**Empty (evidence is empty):**
- Hide evidence section.
- Hero + narrative + radar still show.

**Error (fetch failed):**
- Error State component (§36) replaces entire content area.
- Headline: «تحلیل بارگذاری نشد»
- Description: «لطفاً دوباره تلاش کنید.»
- CTA: «تلاش مجدد» (re-fetch) + «بازگشت به تاریخچه» (navigate to /history).

**Error (404 analysis not found):**
- Error State: «تحلیل یافت نشد» + «بازگشت به تاریخچه».

**Success:**
- User reads narrative, scans evidence, clicks CTA to Diagnosis. The navigation is the success.

### Accessibility

| Aspect | Implementation |
|---|---|
| Heading structure | `<h1>` page title, `<h2>` archetype label, `<h3>` section headers, `<p>` narrative |
| ArchetypeHeroCard | `<section aria-label="پروفایل معامله‌گر">`. Icon `aria-hidden="true"` (decorative). |
| Narrative | Semantic `<p>` tags. `<article>` wrapper. |
| EvidenceCards | `role="button"`, `aria-expanded="true/false"`, `aria-label` with full context (e.g., «معامله‌ی انتقامی، ۱۲ رویداد، ۱۸۴۰ دلار ضرر. کلیک برای جزئیات.») |
| Radar chart | `role="img"`, `aria-label="نمودار رادار امتیازهای رفتاری: انتقام ۴۵ درصد، بیش‌معامله ۳۰ درصد...»`. Visually-hidden `<table>` with raw data. |
| Keyboard | Tab through: CTA → CTA → evidence cards. Enter/Space to expand evidence. |
| Focus ring | 3px `--ring-focus`, 2px offset, on every focusable element. |
| Screen reader | Announces archetype on page load. Evidence cards announce expanded/collapsed state. |

### Edge Cases

| Edge case | Handling |
|---|---|
| Archetype label very long (e.g., "Compulsive Overtrader With Revenge Tendencies") | Truncate with ellipsis on mobile (`--text-data-lg` instead of `--text-data-xl`), full on desktop. Tooltip with full label. |
| Narrative is very long (>5 paragraphs) | Show first 3 paragraphs, «ادامه مطلب» button reveals rest. |
| Narrative is very short (<2 paragraphs) | Show as-is, no truncation. |
| Evidence has <3 items | Show what exists (1 or 2 cards). No placeholder. |
| All 5 scores are "Low" severity | Radar chart still shows (small polygon). Hero archetype might be "Disciplined Operator" or similar. |
| `trader_profile` dict is empty | Fall back to empty state above. |

---

## 2. Overview — Expanded

### Purpose
Comprehensive metrics overview — the "full dashboard" for users who want all the numbers at once. Sits between the emotional Dashboard (4 cards) and the dedicated deep-dive pages. This is the screen for users who want to see everything before drilling in.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — consumes:
- `executive_summary` — `summary_text`, `overall_score`, `primary_diagnosis`, `archetype`
- `performance` — `net_profit`, `profit_factor`, `avg_win`, `avg_loss`, `reward_risk_ratio`
- `statistics` — `total_trades`, `win_rate_pct`, `max_win_streak`, `max_loss_streak`
- `risk` — `max_drawdown`, `risk_taking_score`, `revenge_score`, `what_if_no_revenge`
- `behavior_analysis.scores` — all 5 behavioral scores
- `appendix.performance_raw` — raw performance dict for extended metrics
- `strengths[]`, `weaknesses[]` — auto-classified lists

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs only).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  نمای کلی            [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  نمای کلی عملکرد                      │ ← --text-h1 24px
│  trades_jan.csv · ۱٬۲۴۵ معامله        │ ← --text-body-sm, --fg-secondary
│                                      │
│  ───ـ خلاصه‌ی اجرایی ───ـ             │ ← --text-h3 section header
│  ┌─────────────────────────────┐    │ ← ExecutiveSummaryCard
│  │ ┌─────────────────────────┐ │    │   --bg-elevated, --elevation-2
│  │ │  امتیاز کلی              │ │    │   --radius-xl, --space-5 padding
│  │ │  ۶۷/۱۰۰                  │ │    │   severity-bordered (--severity-medium)
│  │ │  [━━━━━━━━━━░░░░] متوسط   │ │    │
│  │ └─────────────────────────┘ │    │
│  │                              │    │
│  │ تشخیص اصلی: معامله‌ی انتقامی  │    │ ← --text-body, --fg-primary
│  │ آرچیتایپ: Revenge Trader     │    │ ← --text-body-sm, --fg-secondary
│  │                              │    │
│  │ (۲ خط خلاصه‌ی متن)             │    │ ← --text-body-sm, --fg-secondary
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ عملکرد مالی ───ـ               │ ← section header
│  ┌──────┐ ┌──────┐ ┌──────┐         │ ← StatCard grid (2×3 on mobile)
│  │سود   │ │وین‌ریت│ │PF    │         │   each: --bg-elevated, --elevation-2
│  │خالص  │ │      │ │      │         │   --radius-lg, --space-3 padding
│  │+$1.2K│ │۵۲٪   │ │۱.۳   │         │   label (--text-caption, --fg-secondary)
│  │سبز   │ │      │ │      │         │   value (--text-data, mono, colored)
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │MaxDD │ │معامله│ │avgWin│         │
│  │-$890 │ │۱۲۴۵  │ │+$24  │         │
│  │قرمز  │ │      │ │سبز   │         │
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐                   │
│  │avgLos│ │R:R   │                   │
│  │-$18  │ │۱.۳:۱ │                   │
│  │قرمز  │ │      │                   │
│  └──────┘ └──────┘                   │
│                                      │ ← --space-4 gap
│  ───ـ امتیازهای رفتاری ───ـ           │ ← section header
│  ┌─────────────────────────────┐    │ ← BehavioralScoresCard
│  │ ┌─────────────────────────┐ │    │   --bg-elevated, --elevation-2
│  │ │ [⬛] انضباط    ۶۷/۱۰۰   │ │    │   --radius-xl, --space-5 padding
│  │ │ [━] متوسط                │ │    │
│  │ ├─────────────────────────┤ │    │   5 ScoreRows, each:
│  │ │ [⬛] انتقام     ۴۵٪      │ │    │   - label (--text-body-sm)
│  │ │ [━] بالا                  │ │    │   - mini ScoreGauge (40px)
│  │ ├─────────────────────────┤ │    │   - value (--text-data-sm, mono)
│  │ │ [⬛] بیش‌معامله  ۳۰٪      │ │    │   - severity badge
│  │ │ [━] متوسط                │ │    │   - chevron (→)
│  │ ├─────────────────────────┤ │    │
│  │ │ [⬛] ریسک‌پذیری ۲۵٪      │ │    │
│  │ │ [━] متوسط                │ │    │
│  │ ├─────────────────────────┤ │    │
│  │ │ [⬛] صبر       ۸۰٪      │ │    │
│  │ │ [━] پایین                 │ │    │
│  │ └─────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ ریسک ───ـ                      │ ← section header
│  ┌─────────────────────────────┐    │ ← RiskSummaryCard
│  │ Max Drawdown     -$890      │    │   severity-bordered (--severity-medium)
│  │ Risk-Taking Score ۲۵٪       │    │   --bg-elevated, --elevation-2
│  │ Revenge Score    ۴۵٪        │    │   --radius-xl, --space-5 padding
│  │ What-If: +$1,840 اگر اصلاح  │    │
│  │ [مشاهده تحلیل ریسک →]        │    │ ← CTA
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ نقاط قوت و ضعف ───ـ            │ ← section header
│  ┌─────────────────────────────┐    │ ← StrengthsWeaknessesCard
│  │ ✓ نقاط قوت                   │    │   --bg-elevated, --elevation-2
│  │ • بهترین ساعت: ۱۴:۰۰          │    │   --radius-xl, --space-5 padding
│  │ • Profit Factor بالای ۱       │    │
│  │ • انضباط در محدوده‌ی سالم     │    │
│  │                              │    │
│  │ ⚠ نقاط ضعف                   │    │
│  │ • معامله‌ی انتقامی            │    │
│  │ • بیش‌معامله‌گری               │    │
│  │ • ضعیف‌ترین ساعت: ۰۳:۰۰       │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ ورود به جزئیات ───ـ            │ ← section header
│  [📊 تحلیل رفتاری →]                  │ ← secondary CTA
│  [⚠ تحلیل ریسک →]                    │
│  [📈 تحلیل عملکرد →]                  │
│  [🔍 تشخیص کامل →]                    │
│  [💡 برنامه‌ی اقدام →]                 │
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← bottom tab bar
```

**Tablet (768–1023px):**
```
┌──────────────────────────────────────────────────────┐
│ [Logo] [📊 badge]              [⌘K][☀][فا][👤]        │
├──────────────────────────────────────────────────────┤
│ [icon-rail 72px] │  Content (2-column)                │
│                  │                                    │
│                  │  ┌──────────┐ ┌──────────┐         │
│                  │  │ Executive│ │ Risk     │         │ ← 2-column grid
│                  │  │ Summary  │ │ Summary  │         │
│                  │  └──────────┘ └──────────┘         │
│                  │  ┌────────────────────────┐        │
│                  │  │ Financial Performance  │        │ ← full-width
│                  │  │ (1×6 stat row)         │        │
│                  │  └────────────────────────┘        │
│                  │  ┌──────────┐ ┌──────────┐         │
│                  │  │Behavioral│ │Str/Wknss │         │
│                  │  │ Scores   │ │          │         │
│                  │  └──────────┘ └──────────┘         │
│                  │  ┌────────────────────────┐        │
│                  │  │ Drill-down CTAs (1×4)  │        │
│                  │  └────────────────────────┘        │
└──────────────────────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [Logo] Trading Doctor  [📊 trades_jan.csv · 1,245 trades · 2024-01-15]  │
│                                          [⌘K] [☀] [فا] [👤] [📄 Report]  │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌──────────┐                                                            │
│  │ Sidebar  │  Dashboard › Overview                                      │
│  │ 240px    │                                                            │
│  │          │  ┌──────────────────────────────────────────────────────┐  │
│  │ [Gauge]  │  │ Executive Summary Card (full-width)                    │  │
│  │ [Bar]    │  │  امتیاز: ۶۷/۱۰۰ | تشخیص: معامله‌ی انتقامی | Revenge    │  │
│  │ [Stetho] │  └──────────────────────────────────────────────────────┘  │
│  │ [Light]  │                                                            │
│  │ [DNA]    │  ┌──────────────────────────────────────────────────────┐  │
│  │ [Map]    │  │ Financial Performance (1×6 stat row)                   │  │
│  │ [Chart]  │  │ [+$1.2K] [52%] [1.3] [-$890] [1245] [+$24] [-$18]      │  │
│  │ [Table]  │  └──────────────────────────────────────────────────────┘  │
│  │ [Trend]  │                                                            │
│  │ [File]   │  ┌─────────────────────┐  ┌─────────────────────┐          │
│  │ [Clock]  │  │ Behavioral Scores   │  │ Risk Summary        │          │ ← 2-column
│  │ [Gear]   │  │ 5 ScoreRows +       │  │ MaxDD, scores,      │          │
│  │          │  │ mini radar (240px)  │  │ what-if             │          │
│  │          │  │                     │  │                     │          │
│  │          │  │ [Radar Chart]       │  │ [See Risk Analysis] │          │
│  │          │  └─────────────────────┘  └─────────────────────┘          │
│  │          │                                                            │
│  │          │  ┌──────────────────────────────────────────────────────┐  │
│  │          │  │ Strengths & Weaknesses (2-column inside)              │  │
│  │          │  │ ✓ Strengths              ⚠ Weaknesses                 │  │
│  │          │  │ • Best hour 14:00        • Revenge trading            │  │
│  │          │  │ • PF above 1             • Overtrading                │  │
│  │          │  └──────────────────────────────────────────────────────┘  │
│  │          │                                                            │
│  │          │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐              │
│  │          │  │Behavior│ │Risk    │ │Perform.│ │Diagnose│              │ ← drill-down tiles
│  │          │  └────────┘ └────────┘ └────────┘ └────────┘              │
│  └──────────┘                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Executive Summary card** — the headline (overall score + diagnosis + archetype).
2. **Financial Performance strip** — 6 key metrics at a glance.
3. **Behavioral Scores** — 5 scores with mini radar.
4. **Risk Summary** — risk metrics + what-if.
5. **Strengths & Weaknesses** — auto-classified lists.
6. **Drill-down CTAs** — navigation to dedicated pages.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|
| Top bar | TopBar | Logo + analysis badge + theme/lang/account |
| Page header | Breadcrumbs + H1 | "Dashboard › Overview" + "نمای کلی عملکرد" |
| Executive Summary | Card (severity-bordered, §20) + ScoreGauge (§39.2) | Overall score + diagnosis + archetype + summary text |
| Financial Performance | StatCard (§39.2) ×6-8 | net_profit, win_rate, PF, max_drawdown, total_trades, avg_win, avg_loss, R:R |
| Behavioral Scores | Card (default) + ScoreGauge (mini) ×5 + Chart (radar) | 5 ScoreRows + mini radar chart |
| Risk Summary | Card (severity-bordered) + StatCard ×3 | max_drawdown, risk_taking_score, revenge_score, what-if |
| Strengths/Weaknesses | Card (default) + Typography | Two-column lists with check/warning icons |
| Drill-down CTAs | Button (secondary) ×5 | Links to /behavioral, /risk, /performance, /diagnosis, /coaching |

### Cards

| Card | Variant | Border | Padding | Content | Engine source |
|---|---|---|---|---|---|
| ExecutiveSummaryCard | severity-bordered | `--severity-*` based on overall_score | `--space-5` | ScoreGauge + diagnosis + archetype + summary | `executive_summary`, `overall_score` |
| StatCards ×6-8 | stat | none | `--space-3` | label + mono value + trend color | `performance`, `statistics` |
| BehavioralScoresCard | default | `--border-subtle` | `--space-5` | 5 ScoreRows + mini radar | `behavior_analysis.scores` |
| RiskSummaryCard | severity-bordered | `--severity-medium` | `--space-5` | 3 stat rows + what-if + CTA | `risk` |
| StrengthsWeaknessesCard | default | `--border-subtle` | `--space-5` | 2-column lists | `strengths[]`, `weaknesses[]` |

### Tables
None (data is in cards/charts).

### Charts
- **Mini Radar Chart** (Recharts `<RadarChart>`): 5 axes, `--chart-primary` with 20% fill. 200×200 (mobile) / 240×240 (desktop). Animated grow-from-center 500ms `--ease-out` (frozen if reduced-motion). Visually-hidden data table for a11y.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch report. Show skeletons. Staggered fade-up on arrival. |
| 2 | Click ExecutiveSummaryCard | Navigate to `/dashboard/[id]` (back to emotional center) |
| 3 | Click any StatCard | Navigate to `/performance/[id]` |
| 4 | Click any ScoreRow | Navigate to `/behavioral/[id]` (scrolled to that score) |
| 5 | Click radar chart axis (desktop) | Tooltip with score value + severity |
| 6 | Click RiskSummaryCard | Navigate to `/risk/[id]` |
| 7 | Click «مشاهده تحلیل ریسک» CTA | Navigate to `/risk/[id]` |
| 8 | Click drill-down CTA buttons | Navigate to respective pages |
| 9 | Hover StatCard (desktop) | Subtle bg tint |
| 10 | Click analysis badge | History drawer |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| ExecutiveSummaryCard | `--elevation-2` | `--elevation-3`, cursor pointer | 200ms |
| StatCards | `--bg-elevated` | `--bg-hover`, cursor pointer | 200ms |
| ScoreRows | transparent | `--bg-hover`, chevron slides in | 200ms |
| RiskSummaryCard | `--elevation-2` | `--elevation-3`, cursor pointer | 200ms |
| Radar axes | default stroke | highlight (width 2→3px) | 200ms |
| Drill-down CTAs | `--fg-secondary`, ghost | `--accent-primary`, arrow slides | 200ms |
| Strengths/Weaknesses items | `--fg-primary` | (non-interactive, no hover) | — |

### Responsive Behavior

| Breakpoint | Layout | StatCards | Scores | Drill-downs |
|---|---|---|---|---|
| `< sm` (375px) | Single column, stacked | 2×3 grid | Single column rows | Stacked full-width |
| `sm` to `< md` | Same as mobile | 2×4 grid | Same | Same |
| `md` to `< lg` (768px) | 2-column grid | 1×6 row | + mini radar | 1×4 row |
| `≥ lg` (1024px+) | 2-column dashboard, max-width 1280px | 1×6 row | 2-column (scores + radar) | 1×4 tiles |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered content fade-up (exec summary first, stats 80ms staggered, scores 100ms after) | 500ms total | `--ease-out` |
| ScoreGauges fill | Animate 0 → value | 600ms | `--ease-out` |
| Radar chart | Grow from center | 500ms | `--ease-out` |
| StatCards | Staggered fade-up, 80ms per card | 400ms total | `--ease-out` |
| Card hover | Elevation lift + bg tint | 200ms | `--ease-out` |
| Row hover | Chevron slide-in | 200ms | `--ease-out` |
| CTA arrow | TranslateX 0 → 4px | 200ms | `--ease-out` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading:**
- ExecutiveSummaryCard: skeleton (score gauge placeholder + text lines).
- StatCards: 6-8 skeleton cards with pulsing value placeholders.
- BehavioralScoresCard: skeleton rows.
- Radar chart: skeleton circle.
- RiskSummaryCard: skeleton.
- StrengthsWeaknesses: skeleton lines.

**Empty (no analysis):**
- Redirect to `/upload` with toast «ابتدا یک فایل آپلود کنید».

**Error (fetch failed):**
- Error State (§36): «تحلیل بارگذاری نشد» + retry + «بازگشت به تاریخچه».

**Partial data:**
- If `strengths[]` is only the fallback string → show «نقطه‌ی قوت برجسته‌ای شناسایی نشد».
- If `weaknesses[]` is only the fallback string → show «نقطه‌ی ضعف قابل‌توجهی شناسایی نشد».
- If `risk.what_if_no_revenge` is empty → hide what-if row.

**Success:**
- User scans all metrics, clicks a drill-down to explore a specific area.

### Accessibility

| Aspect | Implementation |
|---|---|
| Heading structure | `<h1>` page title, `<h2>` section headers, `<h3>` card titles |
| ExecutiveSummaryCard | `role="button"` (clickable), `aria-label` with full summary |
| ScoreGauges | `role="img"`, `aria-label` with value + severity |
| StatCards | `role="button"` if clickable, `aria-label` with label + value |
| Radar chart | `role="img"`, `aria-label` with all 5 scores. Visually-hidden `<table>`. |
| Keyboard | Tab through interactive cards. Enter to navigate. |
| Focus ring | 3px `--ring-focus` on all focusable |

### Edge Cases

| Edge case | Handling |
|---|---|
| `performance.profit_factor` is 0 or null | Show «N/A» instead of 0 |
| `performance.net_profit` is exactly 0 | Show `$0` in `--profit-neutral` (grey), not green/red |
| `statistics.win_rate_pct` is 100% | Show `۱۰۰٪` in `--profit-positive` |
| `statistics.total_trades` is <10 | Show warning badge: «داده‌ی کم — نتایج با احتیاط بررسی شود» |
| All 5 scores are "Low" | All rows green, radar polygon large. Executive summary shows «انضباط بالا». |
| All 5 scores are "Critical" | All rows red, radar polygon tiny. Executive summary shows «نیاز به توجه فوری». |

---

## 3. Performance Analysis — Expanded

### Purpose
Deep-dive into financial performance metrics — net profit, profit factor, win rate, drawdown, win/loss streaks, reward/risk ratio. The screen for users who want to understand the *financial* story, separate from the behavioral story.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — consumes:
- `performance` — `net_profit`, `net_profit_fmt`, `profit_factor`, `avg_win`, `avg_win_fmt`, `avg_loss`, `avg_loss_fmt`, `reward_risk_ratio`
- `statistics` — `total_trades`, `win_rate_pct`, `max_win_streak`, `max_loss_streak`
- `risk.max_drawdown`, `risk.max_drawdown_fmt`
- `appendix.performance_raw` — full raw performance dict (may include equity curve data, trade-by-trade P&L for chart rendering)

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs only).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  تحلیل عملکرد        [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تحلیل عملکرد                        │ ← --text-h1
│  همه‌ی معیارهای مالی در یک نگاه        │ ← --text-body-sm, --fg-secondary
│                                      │
│  ───ـ معیارهای کلیدی ───ـ             │ ← section header
│  ┌──────┐ ┌──────┐ ┌──────┐         │ ← StatCard grid 2×4
│  │سود   │ │وین‌ریت│ │PF    │         │
│  │خالص  │ │      │ │      │         │
│  │+$1.2K│ │۵۲.۳٪ │ │۱.۳   │         │
│  │▲ سبز │ │      │ │      │         │
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │avgWin│ │avgLos│ │R:R   │         │
│  │+$24  │ │-$18  │ │۱.۳:۱ │         │
│  │سبز   │ │قرمز  │ │      │         │
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐                   │
│  │MaxDD │ │معامله│                   │
│  │-$890 │ │۱۲۴۵  │                   │
│  │قرمز  │ │      │                   │
│  └──────┘ └──────┘                   │
│                                      │ ← --space-4 gap
│  ───ـ منحنی سرمایه ───ـ              │ ← section header
│  ┌─────────────────────────────┐    │ ← ChartCard
│  │ منحنی سرمایه (Equity Curve)  │    │   --bg-elevated, --elevation-2
│  │ роста حساب در طول زمان        │    │   --radius-xl, --space-5 padding
│  │                              │    │
│  │ ╱─────────────────────╲      │    │ ← AreaChart (Recharts)
│  │                        ╲     │    │   --chart-primary fill, gradient
│  │  ╱──╲      ╱──╲         ╲    │    │   x-axis: trade number/date
│  │      ╲────╯    ╲────╲    ╲   │    │   y-axis: cumulative profit $
│  │                        ╲──╯   │    │
│  │ 1K  5K  10K  15K  20K  1.2K   │    │
│  │                              │    │
│  │ 💡 سود خالص: +$1,240 در 1245  │    │ ← KeyInsightCallout
│  │    معامله                    │    │   --bg-surface, --radius-md
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ دراودان (Drawdown) ───ـ        │ ← section header
│  ┌─────────────────────────────┐    │ ← ChartCard
│  │ دراودان زیر خط صفر            │    │
│  │                              │    │
│  │ 0──────────────────────      │    │ ← AreaChart (negative, red)
│  │  ╲                          │    │   --chart-negative fill
│  │   ╲──╲      ╲               │    │   x-axis: trade number
│  │        ╲────╲ ╲──╲          │    │   y-axis: drawdown (negative $)
│  │              ╲    ╲         │    │
│  │               -$890 (max)   │    │
│  │                              │    │
│  │ 💡 بزرگ‌ترین افت: -$890 در     │    │ ← KeyInsightCallout
│  │    معامله‌ی ۸۵۰ام             │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ توزیع سود/زیان ───ـ            │ ← section header
│  ┌─────────────────────────────┐    │ ← ChartCard
│  │ توزیع سود و زیان معاملات      │    │
│  │                              │    │
│  │     ▌▌  ▌  ▌▌                │    │ ← Histogram (Recharts)
│  │  ▌  ▌▌▌▌▌▌▌▌▌▌  ▌            │    │   green bars (wins, right)
│  │  ▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌           │    │   red bars (losses, left)
│  │  -50  -25  0  +25  +50       │    │   x-axis: P&L range
│  │                              │    │   y-axis: count
│  │ 💡 میانگین سود (+$24) کمی    │    │ ← KeyInsightCallout
│  │    بزرگ‌تر از میانگین ضرر (-$18) │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ رشته‌های برد/باخت ───ـ          │ ← section header
│  ┌─────────────────────────────┐    │ ← ChartCard
│  │ رشته‌های متوالی برد و باخت     │    │
│  │                              │    │
│  │ Max Win Streak:  ۷ معامله    │    │ ← StatRow
│  │ Max Loss Streak: ۵ معامله    │    │
│  │                              │    │
│  │  ▌▌▌▌▌▌▌          (green)    │    │ ← BarChart (Recharts)
│  │  ▌▌▌▌▌            (red)      │    │   green = win streaks
│  │                              │    │   red = loss streaks
│  │ 💡 رشته‌ی ۵ باخت متوالی نشان  │    │ ← KeyInsightCallout
│  │    می‌دهد مدیریت ریسک مهم است  │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ داده‌ی خام ───ـ                 │ ← section header
│  [🔍 مشاهده معاملات خام →]            │ ← secondary CTA → /trades/[id]
│  [📄 دانلود گزارش کامل →]            │ ← ghost CTA → /report/[id]
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← bottom tab bar
```

**Tablet (768–1023px):**
2-column layout:
- Left column: Key metrics (1×6 row) + Equity Curve + Drawdown.
- Right column: P&L Distribution + Streaks + Raw data CTAs.

**Desktop (≥1024px):**
2-column with sidebar:
- Left (60%): Key metrics (1×8 row) + Equity Curve (large) + Drawdown.
- Right (40%): P&L Distribution + Streaks + Key insights summary + CTAs.
- Charts larger (400px tall vs 280px mobile).

### Visual Hierarchy
1. **Key metrics grid** — the headline numbers (8 stats).
2. **Equity Curve** — the most important chart (how the account grew).
3. **Drawdown** — the risk story.
4. **P&L Distribution** — win/loss shape.
5. **Streaks** — behavioral pattern in financial terms.
6. **Key insight callouts** — engine-derived insights per chart.
7. **Raw data + report CTAs** — drill-downs.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|
| Top bar | TopBar | Standard |
| Page header | Breadcrumbs + H1 | "Dashboard › Performance Analysis" |
| Key metrics | StatCard (§39.2) ×8 | net_profit, win_rate, PF, avg_win, avg_loss, R:R, max_drawdown, total_trades |
| Equity Curve | Chart (area variant, §25) + Card (§20) | Cumulative profit over time |
| Drawdown | Chart (area negative) + Card | Drawdown over time |
| P&L Distribution | Chart (histogram/bar) + Card | Distribution of trade P&L |
| Streaks | Chart (bar green/red) + Card + StatRow ×2 | Max win/loss streaks + visual |
| Key insights | Card (default) with icon + text | Engine-derived insight per chart |
| CTAs | Button (secondary) + Button (ghost) | "مشاهده معاملات خام" + "دانلود گزارش" |

### Cards

| Card | Variant | Content | Engine source |
|---|---|---|---|
| StatCards ×8 | stat | label + mono value + trend color | `performance`, `statistics` |
| EquityCurveCard | default (chart card) | title + caption + AreaChart + KeyInsightCallout | `appendix.performance_raw` |
| DrawdownCard | default (chart card) | title + caption + negative AreaChart + KeyInsightCallout | `appendix.performance_raw` |
| PnLDistributionCard | default (chart card) | title + caption + Histogram + KeyInsightCallout | `appendix.performance_raw` |
| StreaksCard | default (chart card) | 2 StatRows + BarChart + KeyInsightCallout | `statistics.max_win_streak`, `max_loss_streak` |
| KeyInsightCallout | default (inline) | icon + insight text | Derived from chart data |

### Tables
None (raw data lives in Trade Explorer).

### Charts

| Chart | Type | Library | Color | Question | Data source |
|---|---|---|---|---|---|
| Equity Curve | Area (gradient fill) | Recharts `<AreaChart>` | `--chart-primary` | "How did my account grow?" | `appendix.performance_raw` (cumulative sum of Profit) |
| Drawdown | Area (negative) | Recharts `<AreaChart>` | `--chart-negative` | "What was my worst period?" | `appendix.performance_raw` (cummax - cumsum) |
| P&L Distribution | Histogram (bar) | Recharts `<BarChart>` | `--chart-positive` / `--chart-negative` | "Are wins bigger than losses?" | `appendix.performance_raw` (Profit histogram) |
| Win/Loss Streaks | Bar (green/red) | Recharts `<BarChart>` | `--chart-positive` / `--chart-negative` | "How long are my streaks?" | `statistics` + computed from raw |

**Chart styling (per Phase 3 §13):**
- Grid: 1px dashed `--chart-grid`, subtle.
- Axes: `--chart-axis` color, `--text-caption` size, mono font for numbers.
- Data points: hidden by default, 4px circle on hover/tap.
- Tooltips: `--elevation-4`, `--bg-elevated`, `--text-body-sm`, mono numbers, 100ms fade.
- Legend: below chart, `--text-caption`, color swatch + label.
- Entrance animation: 400ms grow-from-baseline `--ease-out` (frozen if reduced-motion).
- RTL: x-axis reversed (earliest right, latest left).

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch report. Show chart skeletons. Staggered chart render on arrival. |
| 2 | Hover/tap data point (any chart) | Tooltip appears: exact value + trade number/date. 100ms fade. |
| 3 | Pinch (mobile) on Equity/Drawdown | Zoom into time range. |
| 4 | Double-tap | Reset zoom. |
| 5 | Click KeyInsightCallout | Highlight relevant data point on chart (pulse animation). |
| 6 | Click «مشاهده معاملات خام» | Navigate to `/trades/[id]` |
| 7 | Click «دانلود گزارش کامل» | Navigate to `/report/[id]` |
| 8 | Click StatCard | Navigate to `/trades/[id]` (raw data for that metric) |
| 9 | Click analysis badge | History drawer |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| StatCards | `--bg-elevated` | `--bg-hover`, cursor pointer | 200ms |
| Chart cards | `--elevation-2` | (non-interactive, no elevation change) | — |
| Chart data points | hidden | 4px circle, `--accent-primary` | 100ms |
| Tooltips | hidden | fade-in, `--elevation-4` | 100ms |
| KeyInsightCallout | `--bg-surface` | `--bg-hover` (subtle) | 200ms |
| CTAs | `--fg-secondary` | `--accent-primary`, arrow slides | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Charts | StatCards |
|---|---|---|---|
| `< sm` (375px) | Single column, stacked | 280px tall, full-width | 2×4 grid |
| `sm` to `< md` | Same as mobile | 300px tall | 2×4 grid |
| `md` to `< lg` (768px) | 2-column | 320px tall | 1×8 row |
| `≥ lg` (1024px+) | 2-column, max-width 1280px | 400px tall | 1×8 row |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Chart skeletons → staggered chart grow animation | 400ms per chart, 100ms stagger | `--ease-out` |
| Equity Curve entrance | Area grows from baseline (left to right) | 400ms | `--ease-out` |
| Drawdown entrance | Area grows downward from zero line | 400ms | `--ease-out` |
| Histogram entrance | Bars grow from baseline, staggered 20ms | 400ms total | `--ease-out` |
| Streaks entrance | Bars grow, green first then red | 400ms | `--ease-out` |
| Tooltip | Fade-in on hover, fade-out on leave | 100ms | `--ease-out` |
| KeyInsightCallout pulse | Subtle bg pulse once on first render | 600ms | `--ease-in-out` |
| Pinch zoom | Smooth zoom into time range | 200ms | `--ease-out` |
| Reduced motion | All charts instant render, no grow | — | — |

### States

**Loading:**
- Each chart card: skeleton (axes visible + pulsing placeholder area).
- StatCards: skeleton values.
- Pulse 1.5s (frozen if reduced-motion).

**Empty (insufficient data for specific chart):**
- «داده‌ی کافی برای این نمودار نیست» inside chart area.
- Suggestion: «نمودار دیگری را امتحان کنید».

**Empty (no analysis):**
- Redirect to `/upload`.

**Error (chart render fail):**
- «نمودار قابل رسم نیست» inside chart area.
- Fallback: «مشاهده‌ی داده‌ی خام» link → `/trades/[id]`.

**Error (fetch failed):**
- Error State (§36): «تحلیل بارگذاری نشد» + retry.

**Success:**
- User identifies a pattern (e.g., "my losses cluster after wins") or clicks through to raw data.

### Accessibility

| Aspect | Implementation |
|---|---|
| Each chart | `role="img"`, `aria-label` summarizing data (e.g., «منحنی سرمایه از معامله‌ی ۱ تا ۱۲۴۵، از ۰ دلار به ۱۲۴۰ دلار») |
| Data tables | Visually-hidden `<table>` with raw data per chart |
| Tooltips | `aria-live="polite"` on tooltip container |
| Color + style | Line style (solid/dashed) + shape markers supplement color |
| StatCards | `role="button"` if clickable, `aria-label` with label + value |
| Keyboard | Tab to chart, Enter for tooltip focus |
| Focus ring | 3px `--ring-focus` on interactive elements |

### Edge Cases

| Edge case | Handling |
|---|---|
| `net_profit` is negative | Show in `--profit-negative` (red). StatCard trend arrow ▼. |
| `profit_factor` < 1 | Show in `--profit-negative` (red). KeyInsight: «Profit Factor زیر ۱ یعنی کلی ضرر بیشتر از سود». |
| `profit_factor` is exactly 0 | Show «N/A» (no winning trades). |
| `win_rate_pct` is 0% | Show `۰٪` in red. KeyInsight: «هیچ معامله‌ی سوددهی نداشته‌اید». |
| `win_rate_pct` is 100% | Show `۱۰۰٪` in green. KeyInsight: «همه‌ی معاملات سودده بوده‌اند». |
| `max_drawdown` is 0 | Show `$0` in `--profit-neutral`. KeyInsight: «هیچ افت قابل‌توجهی نداشته‌اید». |
| Equity curve is flat (no profit/loss) | Show flat line. KeyInsight: «عملکرد ثابت — نه سود نه ضرر». |
| <10 trades | Show warning badge on page: «داده‌ی کم — نمودارها ممکن است گمراه‌کننده باشند». |
| >10,000 trades | Downsample equity curve (show every Nth point). Tooltip shows exact value. |

---

## 4. Risk Analysis — Expanded

### Purpose
Deep-dive into risk metrics — max drawdown, revenge score, risk-taking score, what-if simulations. The screen that answers "how much risk am I taking, and what would happen if I fixed it?"

### Engine dependency
`GET /api/v1/analyses/{id}/report` — consumes:
- `risk.max_drawdown`, `risk.max_drawdown_fmt`
- `risk.risk_taking_score`
- `risk.revenge_score`
- `risk.what_if_no_revenge` — what-if simulation dict
- `behavior_analysis.scores` — `risk_taking_score`, `revenge_score`
- `behavior_analysis.context_rows` — ContextBlocks for revenge and risk_taking (with `dollars_lost`, `event_count`, `severity`, `insight`)
- `behavior_analysis.what_if` — full what-if dict
- `recommendations[]` — filtered to risk-related (Revenge, Risk, Drawdown types)

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs only).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  تحلیل ریسک          [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تحلیل ریسک                          │ ← --text-h1
│  ریسک‌های رفتاری و مالی شما            │ ← --text-body-sm, --fg-secondary
│                                      │
│  ───ـ بزرگ‌ترین ریسک ───ـ              │ ← section header
│  ┌─────────────────────────────┐    │ ← BiggestRiskCard
│  │ ┌─── severity border (red) ──┐│    │   severity-bordered (--severity-critical)
│  │ │ [⚠ icon 32px]              ││    │   --bg-elevated, --elevation-2
│  │ │                             ││    │   --radius-xl, --space-5 padding
│  │ │ معامله‌ی انتقامی              ││    │
│  │ │ (Revenge Trading)           ││    │ ← --text-h3, --fg-primary
│  │ │                             ││    │
│  │ │ امتیاز: ۴۵٪                 ││    │ ← --text-data, mono
│  │ │ شدت: [بحرانی]                ││    │ ← SeverityBadge
│  │ │                             ││    │
│  │ │ ضرر: ۱٬۸۴۰ دلار              ││    │ ← --text-data, mono, red
│  │ │ ۱۲ رویداد در ۱٬۲۴۵ معامله     ││    │ ← --text-body-sm
│  │ │ ۱۵۳ دلار میانگین/رویداد       ││    │
│  │ │                             ││    │
│  │ │ Insight: بعد از ۲+ باخت،     ││    │ ← --text-body-sm, --fg-secondary
│  │ │ حجم را افزایش می‌دهید...       ││    │   2-3 lines
│  │ │                             ││    │
│  │ │ [🔍 شواهد کامل →]             ││    │ ← secondary CTA → /diagnosis
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ شبیه‌سازی What-If ───ـ          │ ← section header
│  ┌─────────────────────────────┐    │ ← WhatIfCard (collapsible)
│  │ [💡 icon] اگر این رفتار را    │    │   --bg-elevated, --elevation-2
│  │ اصلاح می‌کردید...              │    │   --radius-xl, --space-5 padding
│  │                              │    │   amber accent border
│  │ [▾ نمایش شبیه‌سازی]             │    │ ← expand button
│  └─────────────────────────────┘    │
│  (expanded content):                 │
│  ┌─────────────────────────────┐    │
│  │ اگر معامله‌ی انتقامی را       │    │
│  │ اصلاح می‌کردید:               │    │
│  │                              │    │
│  │ سود خالص فعلی: +$1,240       │    │ ← StatRow
│  │ سود شبیه‌سازی‌شده: +$3,080     │    │ ← StatRow (green, bold)
│  │ تفاوت: +$1,840 (۱۴۹٪ بیشتر)   │    │ ← StatRow (highlight)
│  │                              │    │
│  │ 💡 این یعنی ۶۰٪ از سود        │    │ ← KeyInsight
│  │    بالقوه‌ی شما توسط این       │    │
│  │    رفتار هدر می‌رود.           │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ امتیازهای ریسک ───ـ             │ ← section header
│  ┌─────────────────────────────┐    │ ← RiskScoresCard
│  │ ┌─────────────────────────┐ │    │   --bg-elevated, --elevation-2
│  │ │ [⬛] انتقام     ۴۵٪      │ │    │   --radius-xl, --space-5 padding
│  │ │ [━━━━━━━━━━░░░░] بحرانی   │ │    │   2 ScoreRows
│  │ ├─────────────────────────┤ │    │   each: label + ScoreGauge(40px)
│  │ │ [⬛] ریسک‌پذیری ۲۵٪      │ │    │   + value + severity badge
│  │ │ [━━━━━━░░░░░░░░] متوسط    │ │    │   + chevron
│  │ └─────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ دراودان مالی ───ـ               │ ← section header
│  ┌─────────────────────────────┐    │ ← DrawdownCard
│  │ Max Drawdown                 │    │   --bg-elevated, --elevation-2
│  │                              │    │   --radius-xl, --space-5 padding
│  │ ┌──────────┐ ┌──────────┐   │    │
│  │ │ Max DD   │ │قلاب دراودان│   │    │ ← 2 StatCards
│  │ │ -$890    │ │  ۱۴٪     │   │    │   (max_drawdown, drawdown_pct)
│  │ │ قرمز     │ │          │   │    │
│  │ └──────────┘ └──────────┘   │    │
│  │                              │    │
│  │ [Drawdown Chart]             │    │ ← AreaChart (negative, red)
│  │ 0────────────                │    │   200px tall (mobile)
│  │  ╲                           │    │
│  │   ╲──╲      ╲                │    │
│  │        ╲────╲ ╲──╲           │    │
│  │              ╲    ╲          │    │
│  │               -$890 (max)    │    │
│  │                              │    │
│  │ 💡 بزرگ‌ترین افت در روز ۱۴     │    │ ← KeyInsightCallout
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ توصیه‌های ریسک ───ـ             │ ← section header
│  ┌─────────────────────────────┐    │ ← RecommendationCard #1
│  │ [P1] معامله‌ی انتقامی          │    │   severity-bordered (--severity-critical)
│  │ بعد از هر باخت، ۳۰ دقیقه      │    │   --bg-elevated, --elevation-2
│  │ استراحت کن.                   │    │   --radius-lg, --space-4 padding
│  │ [▾ نمایش دلیل]                 │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← RecommendationCard #2
│  │ [P2] ریسک‌پذیری در حجم         │    │   severity-bordered (--severity-high)
│  │ برای هر معامله حداکثر حجم      │    │
│  │ ثابت تعیین کن.                 │    │
│  │ [▾ نمایش دلیل]                 │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← RecommendationCard #3
│  │ [P3] دراودان                  │    │   severity-bordered (--severity-medium)
│  │ قانون توقف‌ضرر روزانه تعیین کن │    │
│  │ (۵٪ افت).                     │    │
│  │ [▾ نمایش دلیل]                 │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  [💡 مشاهده برنامه‌ی کامل →]          │ ← secondary CTA → /coaching
│  [🔍 مشاهده شواهد کامل →]            │ ← secondary CTA → /diagnosis
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← bottom tab bar
```

**Tablet (768–1023px):**
2-column:
- Left: Biggest Risk + What-If + Risk Scores.
- Right: Drawdown + Recommendations + CTAs.

**Desktop (≥1024px):**
2-column with sidebar, larger chart, recommendations in 3-column grid.

### Visual Hierarchy
1. **Biggest Risk card** — the headline (severity-colored, impossible to miss).
2. **What-If simulation** — the "what could be" story (collapsible).
3. **Risk Scores** — the 2 risk-related behavioral scores.
4. **Drawdown chart** — the financial risk visualization.
5. **Recommendations** — actionable next steps (3 cards).
6. **CTAs** — drill to full coaching/diagnosis.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|
| Top bar | TopBar | Standard |
| Page header | Breadcrumbs + H1 | "Dashboard › Risk Analysis" |
| Biggest Risk | Card (severity-bordered, §20) + SeverityBadge (§39.2) | Top evidence (revenge or risk_taking, whichever has higher $ impact) |
| What-If | Card (default, collapsible) + StatRow ×3 + KeyInsight | `risk.what_if_no_revenge` or `behavior_analysis.what_if` |
| Risk Scores | Card (default) + ScoreGauge (mini) ×2 + SeverityBadge ×2 | `risk_taking_score`, `revenge_score` |
| Drawdown | Card (default) + StatCard ×2 + Chart (area negative) | `risk.max_drawdown` + chart |
| Recommendations | RecommendationCard (§39.2) ×3 | Filtered from `recommendations[]` |
| CTAs | Button (secondary) ×2 | "مشاهده برنامه‌ی کامل" + "مشاهده شواهد کامل" |

### Cards

| Card | Variant | Border | Content | Engine source |
|---|---|---|---|---|
| BiggestRiskCard | severity-bordered | `--severity-critical` or `--severity-high` | icon + label + score + severity + $ impact + event count + insight + CTA | `evidence[0]` or `behavior_analysis.context_rows["revenge_score"]` |
| WhatIfCard | default | `--accent-cta` (amber, 4px inline-start) | collapsible: header always, body (3 StatRows + KeyInsight) on expand | `risk.what_if_no_revenge` |
| RiskScoresCard | default | `--border-subtle` | 2 ScoreRows with mini ScoreGauges | `behavior_analysis.scores` |
| DrawdownCard | default | `--border-subtle` | 2 StatCards + AreaChart + KeyInsight | `risk.max_drawdown` + `appendix.performance_raw` |
| RecommendationCards ×3 | severity-bordered | `--severity-*` per priority | priority chip + issue + action + expand rationale | `recommendations[]` filtered to risk types |

### Tables
None.

### Charts
- **Drawdown Chart** (Recharts `<AreaChart>`): negative area, `--chart-negative` fill. 200px tall (mobile) / 300px (desktop). Shows drawdown over time. Max drawdown point annotated with marker. Entrance: area grows downward from zero line, 400ms `--ease-out` (frozen if reduced-motion). Tooltip on hover/tap: trade number + drawdown value. RTL: x-axis reversed.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch report. Show skeletons. Staggered entrance. |
| 2 | Click BiggestRiskCard | Navigate to `/diagnosis/[id]` (scrolled to that evidence) |
| 3 | Click «شواهد کامل» CTA | Navigate to `/diagnosis/[id]` |
| 4 | Click What-If expand button | Toggle expand/collapse. Chevron rotates 180°. |
| 5 | Click Risk Score row | Navigate to `/behavioral/[id]` (scrolled to that score) |
| 6 | Hover/tap drawdown chart | Tooltip: trade number + drawdown value |
| 7 | Click RecommendationCard | Expand rationale |
| 8 | Click «مشاهده برنامه‌ی کامل» | Navigate to `/coaching/[id]` |
| 9 | Click «مشاهده شواهد کامل» | Navigate to `/diagnosis/[id]` |
| 10 | Click analysis badge | History drawer |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| BiggestRiskCard | `--elevation-2` | `--elevation-3`, border brightens, cursor pointer | 200ms |
| What-If expand button | `--bg-elevated` | `--bg-hover`, chevron rotates | 200ms |
| Risk Score rows | transparent | `--bg-hover`, chevron slides in | 200ms |
| Drawdown chart data points | hidden | 4px circle, `--chart-negative` | 100ms |
| RecommendationCards | `--elevation-2` | `--elevation-3`, border brightens | 200ms |
| CTAs | `--fg-secondary` | `--accent-primary`, arrow slides | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Biggest Risk | What-If | Drawdown chart | Recommendations |
|---|---|---|---|---|---|
| `< sm` (375px) | Single column, stacked | Full-width | Full-width, collapsible | 200px tall | Stacked |
| `sm` to `< md` | Same as mobile | Same | Same | 220px | Same |
| `md` to `< lg` (768px) | 2-column | Left | Left | Right, 280px | Right |
| `≥ lg` (1024px+) | 2-column, max-width 1280px | Left, larger | Left | Right, 300px | 3-column grid |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered content (biggest risk first, what-if 200ms after, scores 100ms after, drawdown 200ms after, recommendations staggered) | 600ms total | `--ease-out` |
| BiggestRiskCard entrance | Fade-up + severity border slides in from inline-start | 400ms | `--ease-out` |
| What-If expand | Height auto + content fade. Chevron rotates 180°. | 250ms | `--ease-out` |
| ScoreGauges fill | Animate 0 → value, staggered 150ms | 600ms | `--ease-out` |
| Drawdown chart | Area grows downward from zero | 400ms | `--ease-out` |
| RecommendationCards | Staggered fade-up, 100ms per card | 300ms | `--ease-out` |
| Card hover | Elevation lift + border brighten | 200ms | `--ease-out` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading:**
- BiggestRiskCard: skeleton (icon + label + score + stats placeholders).
- WhatIfCard: skeleton header.
- RiskScoresCard: skeleton rows.
- DrawdownCard: skeleton chart.
- RecommendationCards: 3 skeleton cards.

**Empty (no risk data):**
- «داده‌ی ریسک موجود نیست» + CTA to Dashboard.

**Empty (what_if_no_revenge is empty):**
- Hide WhatIfCard entirely.

**Empty (recommendations empty for risk types):**
- Hide recommendations section. Show only CTAs.

**Error (fetch failed):**
- Error State (§36): «تحلیل بارگذاری نشد» + retry.

**Success:**
- User understands their biggest risk, expands What-If, clicks through to action plan.

### Accessibility

| Aspect | Implementation |
|---|---|
| BiggestRiskCard | `role="button"` (clickable), `aria-label` with full context |
| What-If accordion | `aria-expanded="true/false"` |
| ScoreGauges | `role="img"`, `aria-label` with value + severity |
| Drawdown chart | `role="img"`, `aria-label` summarizing. Visually-hidden `<table>`. |
| RecommendationCards | `role="button"`, `aria-expanded` |
| Severity badges | Text + icon (not color alone) |
| Keyboard | Tab through cards. Enter to expand/navigate. |

### Edge Cases

| Edge case | Handling |
|---|---|
| `risk.what_if_no_revenge` shows $0 savings | Show «اگر این رفتار را اصلاح می‌کردید، تفاوت قابل‌توجهی نداشتید.» Hide stat rows. |
| `revenge_score` is 0 (no revenge trading) | BiggestRiskCard falls back to risk_taking or next evidence. What-If hidden. |
| `max_drawdown` is 0 | DrawdownCard shows `$0` in `--profit-neutral`. KeyInsight: «هیچ افت قابل‌توجهی نداشته‌اید». |
| `max_drawdown` is very large (>50% of initial capital) | Show warning badge: «افت بحرانی — مدیریت ریسک فوری». |
| Both risk scores are "Low" | Green scores. BiggestRiskCard falls back to next evidence (overtrading, patience). |
| All recommendations are non-risk types | Hide recommendations section. Show only CTAs. |

---

## 5. Evidence Explorer — Expanded

### Purpose
Explore the prioritized evidence behind the diagnosis. Understand *why* the engine concluded what it concluded. This is the "show me the proof" screen.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — consumes:
- `diagnosis` — `primary`, `secondary`, `primary_detail`, (and any other keys)
- `evidence[]` — top-8 prioritized evidence, each with: `type`, `label`, `description`, `severity` (0-3), `frequency`, `financial_impact`, `financial_impact_fmt`, `priority_score`, `confidence`

### Phase status
Phase 1 build (maps to Phase 2 §3.7 Diagnosis).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  تشخیص               [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تشخیص                               │ ← --text-h1
│  چرا موتور این نتیجه را گرفت؟         │ ← --text-body-sm, --fg-secondary
│                                      │
│  ───ـ مشکل اصلی ───ـ                  │ ← section header
│  ┌─────────────────────────────┐    │ ← PrimaryDiagnosisCard
│  │ ┌── severity border (red) ──┐│    │   severity-bordered (--severity-critical)
│  │ │ [⚠ icon 24px]              ││    │   --bg-elevated, --elevation-2
│  │ │                             ││    │   --radius-xl, --space-5 padding
│  │ │ مشکل اصلی                   ││    │ ← --text-caption, --fg-secondary
│  │ │                             ││    │
│  │ │ معامله‌ی انتقامی پس از       ││    │ ← --text-h3, bold, --fg-primary
│  │ │ باخت‌های پیاپی                ││    │
│  │ │ (Revenge Trading after      ││    │
│  │ │  consecutive losses)        ││    │
│  │ │                             ││    │
│  │ │ [بحرانی]                     ││    │ ← SeverityBadge
│  │ │                             ││    │
│  │ │ (۳–۴ lines detail text from ││    │ ← --text-body, --fg-secondary
│  │ │  diagnosis.primary_detail)  ││    │
│  │ │                             ││    │
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ مشکل ثانویه ───ـ               │ ← section header (if secondary exists)
│  ┌─────────────────────────────┐    │ ← SecondaryDiagnosisCard
│  │ ┌── severity border (orange)┐│    │   severity-bordered (--severity-high)
│  │ │ [○ icon 24px]              ││    │   smaller than primary
│  │ │ مشکل ثانویه                 ││    │
│  │ │ بیش‌معامله‌گری در روزهای پر   ││    │ ← --text-h3
│  │ │ [بالا]                       ││    │ ← SeverityBadge
│  │ │ (۱–۲ lines detail)           ││    │
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ شواهد (۸) ───ـ                 │ ← section header + count badge
│  ┌─────────────────────────────┐    │ ← FilterBar (collapsible on mobile)
│  │ فیلتر بر اساس شدت:            │    │   --bg-elevated, --radius-lg
│  │ [همه] [بحرانی] [بالا] [متوسط]  │    │   SegmentedControl (severity filter)
│  │ [پایین]                       │    │
│  │                              │    │
│  │ مرتب‌سازی: [اولویت ▾]          │    │ ← Dropdown
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #1 (top priority)
│  │ ┌── severity border (red) ──┐│    │   severity-bordered (--severity-critical)
│  │ │ [⚠] معامله‌ی انتقامی         ││    │   --bg-elevated, --elevation-2
│  │ │ (Revenge Trading)          ││    │   --radius-lg, --space-4 padding
│  │ │                             ││    │
│  │ │ [بحرانی]                     ││    │ ← SeverityBadge
│  │ │                             ││    │
│  │ │ ۱۲ رویداد · ۱٬۸۴۰ دلار ضرر   ││    │ ← --text-body-sm, mono numbers
│  │ │ اولویت: ۹۲/۱۰۰              ││    │ ← --text-caption
│  │ │ اطمینان: ۸۵٪                ││    │
│  │ │                             ││    │
│  │ │ [▾ نمایش توضیح]              ││    │ ← expand button
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #2
│  │ ┌── severity border (orange)┐│    │   severity-bordered (--severity-high)
│  │ │ [○] بیش‌معامله‌گری            ││    │
│  │ │ (Overtrading)              ││    │
│  │ │ [بالا]                       ││    │
│  │ │ ۸ رویداد · ۴۲۰ دلار ضرر      ││    │
│  │ │ اولویت: ۶۸/۱۰۰              ││    │
│  │ │ اطمینان: ۷۲٪                ││    │
│  │ │ [▾ نمایش توضیح]              ││    │
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #3
│  │ ┌── severity border (amber)─┐│    │   severity-bordered (--severity-medium)
│  │ │ [○] ریسک‌پذیری در حجم        ││    │
│  │ │ (Risk Taking)              ││    │
│  │ │ [متوسط]                     ││    │
│  │ │ ۵ رویداد · ۲۱۰ دلار ضرر      ││    │
│  │ │ اولویت: ۵۵/۱۰۰              ││    │
│  │ │ اطمینان: ۶۵٪                ││    │
│  │ │ [▾ نمایش توضیح]              ││    │
│  │ └─────────────────────────────┘│    │
│  └─────────────────────────────┘    │
│                                      │
│  [نمایش همه‌ی شواهد (۵ بیشتر)]        │ ← show more button
│                                      │
│  (expanded EvidenceCard content):    │
│  ┌─────────────────────────────┐    │
│  │ توضیح کامل:                   │    │ ← --text-body-sm
│  │ بعد از هر باخت، حجم معامله‌ی   │    │   2-3 sentences
│  │ بعدی را افزایش می‌دهید...       │    │
│  │                              │    │
│  │ اطمینان: ۸۵٪                  │    │ ← confidence bar
│  │ [━━━━━━━━━━░░]                │    │
│  │                              │    │
│  │ [🔍 مشاهده‌ی معاملات مرتبط →]   │    │ ← CTA → /trades/[id]?evidence=revenge
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  [💡 برنامه‌ی اقدام را ببین →]        │ ← primary CTA → /coaching
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← bottom tab bar
```

**Tablet (768–1023px):**
2-column:
- Left: Primary + Secondary diagnosis cards (sticky).
- Right: Filter + Evidence list (scrollable).

**Desktop (≥1024px):**
2-column with sidebar:
- Left (40%): Primary + Secondary diagnosis (sticky).
- Right (60%): Filter + Evidence list with priority sparkline column.

### Visual Hierarchy
1. **Primary diagnosis card** — the headline answer.
2. **Secondary diagnosis** — if exists.
3. **Filter bar** — controls for evidence exploration.
4. **Evidence cards (top 3)** — the proof, ordered by priority.
5. **Show more** — reveal remaining 5.
6. **CTA** — drill to action plan.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|---|
| Top bar | TopBar | Standard |
| Page header | Breadcrumbs + H1 | "Dashboard › Diagnosis" |
| Primary Diagnosis | Card (severity-bordered, §20) + SeverityBadge (§39.2) | `diagnosis.primary` + `primary_detail` |
| Secondary Diagnosis | Card (severity-bordered, smaller) | `diagnosis.secondary` (if exists) |
| Filter Bar | FilterBar (composite, §39.2) — SegmentedControl + Dropdown | Severity filter + sort |
| Evidence List | EvidenceCard (composite, §39.2) ×3 (default) + ×5 (show more) | `evidence[0..7]` |
| Show More | Button (ghost, §19) | Reveal remaining evidence |
| CTA | Button (secondary) | "برنامه‌ی اقدام را ببین" → /coaching |

### Cards

| Card | Variant | Border | Content | Engine source |
|---|---|---|---|---|
| PrimaryDiagnosisCard | severity-bordered | `--severity-critical` or `--severity-high` | «مشکل اصلی» label + diagnosis text + severity badge + detail | `diagnosis.primary`, `primary_detail` |
| SecondaryDiagnosisCard | severity-bordered | `--severity-high` or `--severity-medium` | «مشکل ثانویه» label + diagnosis text + severity badge + brief detail | `diagnosis.secondary` |
| EvidenceCards ×3-8 | severity-bordered | `--severity-*` per evidence severity | type icon + label + severity badge + frequency + $ impact + priority + confidence + expand | `evidence[0..7]` |

### Tables
None (evidence is in cards, not table).

### Charts
None (priority/confidence are shown as progress bars within EvidenceCards, not separate charts).

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch report. Show skeletons. Staggered entrance. |
| 2 | Click PrimaryDiagnosisCard | Smooth-scroll to top evidence for this diagnosis |
| 3 | Click severity filter pill | Filter evidence list by severity. Cross-fade 200ms. |
| 4 | Change sort dropdown | Re-sort evidence list (client-side). Cross-fade. |
| 5 | Tap EvidenceCard | Expand description + confidence bar + «مشاهده‌ی معاملات مرتبط» CTA |
| 6 | Click «مشاهده‌ی معاملات مرتبط» | Navigate to `/trades/[id]?evidence={type}` |
| 7 | Click «نمایش همه‌ی شواهد» | Reveal remaining 5 cards, staggered 80ms |
| 8 | Click «نمایش کمتر» | Collapse back to top 3 |
| 9 | Click «برنامه‌ی اقدام را ببین» | Navigate to `/coaching/[id]` |
| 10 | Click analysis badge | History drawer |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| PrimaryDiagnosisCard | `--elevation-2` | `--elevation-3` (non-clickable on mobile, clickable on desktop) | 200ms |
| SecondaryDiagnosisCard | `--elevation-2` | `--elevation-3` | 200ms |
| EvidenceCards | `--elevation-2` | `--elevation-3`, border brightens, cursor pointer | 200ms |
| Filter pills | `--bg-elevated` | `--bg-hover`, active `--accent-primary` at 12% | 200ms |
| Sort dropdown | `--bg-surface` | `--bg-hover` | 200ms |
| Show more button | `--bg-elevated` | `--bg-hover` | 200ms |
| CTA | `--fg-secondary` | `--accent-primary`, arrow slides | 200ms |
| «مشاهده‌ی معاملات مرتبط» link | `--fg-secondary` | `--accent-primary` | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Diagnoses | Evidence | Filter |
|---|---|---|---|---|
| `< sm` (375px) | Single column, stacked | Stacked | Stacked, top 3 + show more | Collapsed into «فیلترها» button → bottom sheet |
| `sm` to `< md` | Same as mobile | Same | Same | Same |
| `md` to `< lg` (768px) | 2-column | Left (sticky) | Right (scrollable) | Inline at top of right column |
| `≥ lg` (1024px+) | 2-column, max-width 1280px | Left (sticky) | Right, all 8 visible with priority sparkline | Inline |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered (diagnoses first, evidence 80ms staggered) | 500ms total | `--ease-out` |
| Diagnosis cards entrance | Severity border slides in from inline-start. Text fade-up 200ms after. | 400ms | `--ease-out` |
| Evidence cards staggered | Fade-up, 80ms per card | 400ms total | `--ease-out` |
| Expand evidence | Height auto + content fade. Chevron rotates 180°. | 250ms | `--ease-out` |
| Filter pill active | Bg transition. Evidence list cross-fade. | 200ms | `--ease-out` |
| Sort change | Evidence list cross-fade. | 200ms | `--ease-out` |
| Show more | Additional cards slide-down + fade, staggered 80ms | 400ms total | `--ease-out` |
| Show less | Cards slide-up + fade | 200ms | `--ease-in` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading:**
- Diagnosis cards: skeleton (icon + label + text lines).
- Evidence: 3 skeleton cards with icon/label/stats placeholders.

**Empty (evidence is empty):**
- Hide evidence section entirely.
- PrimaryDiagnosisCard shows: «الگوی رفتاری برجسته‌ای شناسایی نشد» + CTA to Dashboard.
- Filter bar hidden. Show more hidden.

**Empty (no secondary diagnosis):**
- Hide SecondaryDiagnosisCard. No empty state.

**Empty (primary diagnosis is "N/A"):**
- PrimaryDiagnosisCard shows: «تشخیص اصلی در دسترس نیست» + CTA to Dashboard.
- Evidence section still shows if evidence exists.

**Error (fetch failed):**
- Error State (§36): «تحلیل بارگذاری نشد» + retry.

**Success:**
- User reads diagnosis, scans evidence, clicks CTA to Coaching.

### Accessibility

| Aspect | Implementation |
|---|---|
| Diagnosis cards | `role="region"`, `aria-labelledby` pointing to the label |
| EvidenceCards | `role="button"`, `aria-expanded="true/false"`, `aria-label` with full context |
| Filter pills | `role="radiogroup"` + `role="radio"` + `aria-checked` |
| Sort dropdown | `role="listbox"` (native or custom) |
| Severity badges | Text + icon (not color alone) |
| Confidence bar | `role="progressbar"`, `aria-valuenow`, `aria-valuetext` |
| Show more | `aria-expanded`, `aria-controls` pointing to evidence list |
| Keyboard | Tab through pills, dropdown, cards. Enter to activate. |
| Focus ring | 3px `--ring-focus` |

### Edge Cases

| Edge case | Handling |
|---|---|
| `evidence[]` has <3 items | Show what exists (1 or 2). Hide "show more" button. |
| `evidence[]` has exactly 3 items | Show all 3. Hide "show more" button. |
| `evidence[]` has >3 but <8 items | Show top 3, "show more" reveals the rest. |
| All evidence is same severity | Filter still works (other pills show empty state). |
| `diagnosis.primary_detail` is empty | Hide detail section in PrimaryDiagnosisCard. |
| `evidence[i].confidence` is 0 | Show «اطمینان: ۰٪» with empty bar. |
| `evidence[i].financial_impact` is 0 | Show «۰ دلار» in `--profit-neutral`. |
| Filter returns no results | «هیچ شاهدی با این شدت یافت نشد» + «پاک کردن فیلتر» CTA. |

---

## 6. Trade Detail — Expanded

### Purpose
Full-screen view of a single trade. Reached from Trade Explorer (drawer on desktop, bottom sheet on mobile) or via deep link `/trades/[id]/[tradeId]`. For users who want to inspect every detail of one trade and understand its behavioral context.

### Engine dependency
`GET /api/v1/analyses/{id}/trades?trade_id={tradeId}` (single trade row from the new endpoint, Phase 2 §5.1).
Also `GET /api/v1/analyses/{id}/report` for behavioral context (if trade matches a pattern).

### Phase status
Enhanced deep-dive (full-screen view in addition to drawer pattern from Phase 2 §3.12).

### Layout

**Mobile (375 × 667) — bottom sheet:**
```
┌─────────────────────────────────────┐ ← (Trade Explorer visible, dimmed)
│ (trades list, dimmed behind scrim)   │
├─────────────────────────────────────┤ ← bottom sheet, slid up
│ ───  (drag handle, 36px)            │ ← swipe down to dismiss
│  معامله‌ی #۱۲۴۵                       │ ← --text-h2
│  ۲۰۲۴-۰۱-۱۵ ۱۴:۳۰:۴۵                 │ ← --text-body-sm, --fg-secondary, mono
│                                      │
│  ┌─────────────────────────────┐    │ ← DetailsCard
│  │ ┌─── Field-Value Pairs ────┐ │    │   --bg-elevated, --elevation-2
│  │ │                          │ │    │   --radius-xl, --space-5 padding
│  │ │ جهت (Side)       Long    │ │    │   <dl> <dt> <dd> structure
│  │ │ حجم (Size)       0.5 lot │ │    │   label: --text-caption, --fg-secondary
│  │ │ ────────────────────────│ │    │   value: --text-body, mono, --fg-primary
│  │ │ سود (Profit)     +$12.50 │ │    │   profit: --text-data, mono, green
│  │ │ ────────────────────────│ │    │
│  │ │ ساعت (Hour)       ۱۴     │ │    │
│  │ │ روز هفته (Weekday) Monday│ │    │
│  │ │ تاریخ (Date)    ۱۴۰۴/۱۰/۲۵│ │    │ ← Shamsi date in Persian UI
│  │ │ ────────────────────────│ │    │
│  │ │ (any other normalized    │ │    │
│  │ │  columns present in df)  │ │    │
│  │ └──────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ زمینه‌ی رفتاری ───ـ             │ ← section header (if trade matches pattern)
│  ┌─────────────────────────────┐    │ ← BehavioralContextCard
│  │ ┌── severity border ───────┐ │    │   severity-bordered (--severity-high)
│  │ │ [⚠] الگوی معامله‌ی انتقامی  │ │    │   --bg-elevated, --elevation-2
│  │ │                             │ │    │   --radius-lg, --space-4 padding
│  │ │ این معامله بخشی از الگوی    │ │    │
│  │ │ «معامله‌ی انتقامی» است.      │ │    │ ← --text-body-sm
│  │ │                             │ │    │
│  │ │ حجم این معامله (۰.۵) ۶۷٪    │ │    │
│  │ │ بزرگ‌تر از میانگین شما (۰.۳) │ │    │
│  │ │ است و بعد از ۲ باخت آمده.   │ │    │
│  │ │                             │ │    │
│  │ │ [🔍 شاهد کامل →]             │ │    │ ← CTA → /diagnosis
│  │ └─────────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ معاملات مجاور ───ـ              │ ← section header (desktop only, hidden mobile)
│  (hidden on mobile)                  │
│                                      │
│  [بستن]                              │ ← full-width ghost button
└─────────────────────────────────────┘
```

**Tablet (768–1023px) — drawer from side:**
```
┌──────────────────────────────────────────────────────┐
│ (Trade Explorer, dimmed)                              │
├──────────────────────────────────────────────────────┤
│ ┌────────────────────────────────┐                   │ ← drawer, slid in from side
│ │ [✕ بستن]                        │                   │   max-width 480px
│ │                                │                   │   full height
│ │  معامله‌ی #۱۲۴۵                  │                   │
│ │  ۲۰۲۴-۰۱-۱۵ ۱۴:۳۰:۴۵            │                   │
│ │                                │                   │
│ │  ┌────────────────────────┐    │                   │
│ │  │ DetailsCard             │    │                   │
│ │  │ (field-value pairs)     │    │                   │
│ │  └────────────────────────┘    │                   │
│ │                                │                   │
│ │  ┌────────────────────────┐    │                   │
│ │  │ BehavioralContextCard   │    │                   │
│ │  └────────────────────────┘    │                   │
│ │                                │                   │
│ │  ┌────────────────────────┐    │                   │
│ │  │ AdjacentTradesCard      │    │                   │ ← adjacent trades visible
│ │  │ #1244 -8.20  15:00      │    │                   │   on tablet/desktop
│ │  │ #1245 +12.50 14:30 ←    │    │                   │
│ │  │ #1246 -5.00  16:45      │    │                   │
│ │  └────────────────────────┘    │                   │
│ └────────────────────────────────┘                   │
└──────────────────────────────────────────────────────┘
```

**Desktop (≥1024px) — dedicated route:**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [Logo] Trading Doctor  [📊 trades_jan.csv · 1,245 trades · 2024-01-15]  │
│                                          [⌘K] [☀] [فا] [👤] [📄 Report]  │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌──────────┐                                                            │
│  │ Sidebar  │  [← بازگشت به کاوش معاملات]   معامله‌ی #۱۲۴۵                 │
│  │ 240px    │                                                            │
│  │          │  ┌────────────────────────────┐  ┌────────────────────────┐│
│  │ [Gauge]  │  │ جزئیات معامله               │  │ زمینه‌ی رفتاری           ││ ← 2-column
│  │ [Bar]    │  │ (DetailsCard)              │  │ (BehavioralContextCard)││
│  │ [Stetho] │  │                            │  │                        ││
│  │ [Light]  │  │ Open Time: 2024-01-15 14:30│  │ [⚠] الگوی معامله‌ی      ││
│  │ [DNA]    │  │ Side: Long                 │  │     انتقامی             ││
│  │ [Map]    │  │ Size: 0.5 lot              │  │                        ││
│  │ [Chart]  │  │ Profit: +$12.50            │  │ این معامله بخشی از     ││
│  │ [Table]← │  │ Hour: 14                   │  │ الگوی «معامله‌ی انتقامی»││
│  │ [Trend]  │  │ Weekday: Monday            │  │ است.                   ││
│  │ [File]   │  │ Date: 1404/10/25           │  │                        ││
│  │ [Clock]  │  │                            │  │ حجم ۶۷٪ بزرگ‌تر از      ││
│  │ [Gear]   │  │ (any other columns)        │  │ میانگین، بعد از ۲ باخت. ││
│  │          │  │                            │  │                        ││
│  │          │  └────────────────────────────┘  │ [🔍 شاهد کامل →]        ││
│  │          │                                  └────────────────────────┘│
│  │          │                                                            │
│  │          │  ┌────────────────────────────────────────────────────────┐│
│  │          │  │ معاملات مجاور (AdjacentTradesCard)                      ││ ← full-width below
│  │          │  │ ┌──────────────────────────────────────────────────┐  ││
│  │          │  │ │ #      | Time   | Side  | Size  | Profit         │  ││ ← mini table
│  │          │  │ │--------|--------|-------|-------|----------------|  ││
│  │          │  │ │ 1244   | 15:00  | Short | 0.3   | -$8.20         │  ││
│  │          │  │ │ 1245   | 14:30  | Long  | 0.5   | +$12.50  ←     │  ││ ← current highlighted
│  │          │  │ │ 1246   | 16:45  | Long  | 0.8   | +$24.00        │  ││
│  │          │  │ └──────────────────────────────────────────────────┘  ││
│  │          │  └────────────────────────────────────────────────────────┘│
│  └──────────┘                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Trade header** — trade number + timestamp (orients the user).
2. **Details card** — all trade fields in a definition list.
3. **Behavioral context card** — if this trade matches an engine pattern (the "why this trade matters" story).
4. **Adjacent trades** — for context (what happened before/after).
5. **Close/back** — dismiss.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|---|
| Mobile: bottom sheet | Dialog (sheet variant, §26) | Full-screen bottom sheet |
| Tablet: drawer | Dialog (drawer variant, §26) | Side drawer, max-width 480px |
| Desktop: dedicated route | Standard page layout | 2-column + adjacent trades |
| Header | Breadcrumbs + H2 | "Trades › Trade #1245" |
| Details | Card (default, §20) + Typography (`<dl>`) | All trade fields |
| Behavioral Context | Card (severity-bordered) + Button (secondary) | Pattern match info + CTA |
| Adjacent Trades | Card (default) + Table (dense, §22) | 3-5 surrounding trades |
| Close (mobile) | Button (ghost) | "بستن" |
| Back (desktop) | Button (ghost) + Breadcrumbs | "بازگشت به کاوش معاملات" |

### Cards

| Card | Variant | Border | Content | Engine source |
|---|---|---|---|---|
| DetailsCard | default | `--border-subtle` | `<dl>` of all trade fields (Open Time, Side, Size, Profit, Hour, Weekday, Date, + any others) | `/trades?trade_id={id}` |
| BehavioralContextCard | severity-bordered | `--severity-*` (if matches pattern) | Pattern name + explanation + CTA to /diagnosis | Computed client-side: trade matches pattern if (e.g.) it follows 2+ losses with size increase |
| AdjacentTradesCard | default | `--border-subtle` | Mini table of 3-5 adjacent trades. Current trade highlighted. | `/trades` with range query |

### Tables
- **Adjacent Trades Table** (desktop only, dense variant §22): Columns: # | Time | Side | Size | Profit. Current trade row highlighted with `--accent-primary` at 8% bg. Row click navigates to that trade's detail. Sortable: no (fixed order by trade number).

### Charts
None.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page/drawer mount | Fetch single trade + behavioral context. Show skeletons. |
| 2 | Click «شاهد کامل» | Navigate to `/diagnosis/[id]?evidence={pattern_type}` |
| 3 | Click adjacent trade row (desktop) | Navigate to that trade's detail `/trades/[id]/[tradeId]` |
| 4 | Click «بستن» (mobile) | Dismiss bottom sheet. Slide-down + fade. |
| 5 | Swipe down (mobile) | Dismiss bottom sheet. |
| 6 | Esc (desktop/tablet drawer) | Close drawer. |
| 7 | Click back link (desktop) | Navigate to `/trades/[id]` |
| 8 | Click scrim (mobile/tablet) | Dismiss. |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| Adjacent trade rows | `--bg-elevated` | `--bg-hover`, cursor pointer | 150ms |
| «شاهد کامل» link | `--fg-secondary` | `--accent-primary` | 200ms |
| Back link | `--fg-secondary` | `--accent-primary` | 200ms |
| Close button (mobile) | `--fg-secondary` | `--severity-critical` | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Adjacent Trades |
|---|---|---|
| `< sm` (375px) | Bottom sheet, full-screen, single column | Hidden (not enough space) |
| `sm` to `< md` | Same as mobile, wider | Hidden |
| `md` to `< lg` (768px) | Drawer from side, max-width 480px | Visible in drawer |
| `≥ lg` (1024px+) | Full dedicated route, 2-column + adjacent trades, max-width 1280px | Full-width below columns |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Bottom sheet entrance (mobile) | Slide-up + fade. Scrim fade-in. | 250ms | `--ease-out` |
| Drawer entrance (tablet) | Slide-in from side. Scrim fade-in. | 250ms | `--ease-out` |
| Page entrance (desktop) | Fade-in. | 200ms | `--ease-out` |
| Details field rows | Staggered fade-in, 50ms per row | 300ms total | `--ease-out` |
| BehavioralContextCard | Fade-in after details, 200ms delay | 300ms | `--ease-out` |
| Adjacent trades | Fade-in, 200ms | 200ms | `--ease-out` |
| Dismiss (mobile) | Slide-down + fade. Scrim fade-out. | 200ms | `--ease-in` |
| Dismiss (tablet) | Slide-out. Scrim fade-out. | 200ms | `--ease-in` |
| Reduced motion | All ≤1ms, instant appear/disappear | — | — |

### States

**Loading:**
- DetailsCard: skeleton field rows (5-7 placeholder lines).
- BehavioralContextCard: skeleton (if context expected).
- AdjacentTrades: skeleton rows.

**Empty (trade not found):**
- «معامله‌یافت نشد» + back CTA to `/trades/[id]`.

**Empty (no behavioral context — trade doesn't match any pattern):**
- Hide BehavioralContextCard. Show only DetailsCard (+ AdjacentTrades on desktop).

**Error (fetch failed):**
- Error State (§36): «بارگذاری ناموفق بود» + retry.

**Success:**
- User inspects the trade, understands its context, clicks through to evidence or back.

### Accessibility

| Aspect | Implementation |
|---|---|
| Bottom sheet / drawer | `role="dialog"`, `aria-modal="true"`, `aria-labelledby` pointing to trade header |
| Focus trap | Focus cycles within dialog. Returns to trigger on close. |
| Field list | `<dl>` / `<dt>` / `<dd>` semantics |
| Adjacent trades table | `<table>`, `<th scope>`, current row `aria-current="true"` |
| Esc | Closes dialog (desktop/tablet) |
| Scrim click | Dismisses |
| Screen reader | Announces "معامله‌ی ۱۲۴۵ باز شد" on open. Field labels and values announced. |

### Edge Cases

| Edge case | Handling |
|---|---|
| Trade is first in dataset (no previous) | AdjacentTrades shows only next 2-3. |
| Trade is last in dataset (no next) | AdjacentTrades shows only previous 2-3. |
| Trade has only 1 trade in dataset | AdjacentTrades hidden. |
| Trade Profit is exactly 0 | Show `$0` in `--profit-neutral` (grey). |
| Trade Size is 0 | Show `0` with warning: «حجم صفر — ممکن است داده‌ی ناقص باشد». |
| Multiple patterns match this trade | Show multiple BehavioralContextCards (stacked). |
| Pattern matching can't be computed (missing columns) | Hide BehavioralContextCard. Don't show error. |

---

## 7. Profile (future-ready) — Expanded

### Purpose
User profile management — name, email, avatar, password change, 2FA, default preferences. Phase 1 ships Anonymous-only; this screen is fully specified for feature-flag activation when auth is enabled.

### Engine dependency
Future: `GET /api/v1/auth/me` (current user), `PATCH /api/v1/auth/me` (update profile), `POST /api/v1/auth/change-password`, `POST /api/v1/auth/2fa/setup`, `POST /api/v1/auth/2fa/verify`, `POST /api/v1/auth/avatar` (upload).

### Phase status
Future-ready (Phase 1 ships without auth; this screen activates when auth is enabled).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [← بازگشت به تنظیمات]                 │
├─────────────────────────────────────┤
│  پروفایل                             │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │ ← AvatarCard
│  │         ┌─────────┐          │    │   --bg-elevated, --elevation-2
│  │         │ Avatar  │          │    │   --radius-xl, --space-6 padding
│  │         │ 80px    │          │    │   centered content
│  │         │ (image  │          │    │
│  │         │  or     │          │    │
│  │         │ initials│          │    │
│  │         │ )       │          │    │
│  │         └─────────┘          │    │
│  │                              │    │
│  │       [تغییر عکس]             │    │ ← ghost link
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ اطلاعات شخصی ───ـ              │ ← section header
│  ┌─────────────────────────────┐    │ ← PersonalInfoCard
│  │                              │    │   --bg-elevated, --elevation-2
│  │ نام                          │    │   --radius-xl, --space-5 padding
│  │ ┌──────────────────────────┐ │    │
│  │ │ Arman                    │ │    │ ← TextField
│  │ └──────────────────────────┘ │    │
│  │                              │    │
│  │ ایمیل                        │    │
│  │ ┌──────────────────────────┐ │    │
│  │ │ arman@example.com        │ │    │ ← TextField (disabled, verified)
│  │ └──────────────────────────┘ │    │
│  │ ✓ تأیید شده                  │    │ ← success badge
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ امنیت ───ـ                      │ ← section header
│  ┌─────────────────────────────┐    │ ← SecurityCard
│  │ [🔑 تغییر رمز عبور         →]│    │ ← link row
│  │ ─────────────────────────── │    │
│  │ احراز هویت دو مرحله‌ای (2FA)   │    │
│  │ [○────] خاموش                │    │ ← Toggle (off)
│  │                              │    │
│  │ [📱 جلسات فعال (۳)]           │    │ ← link row
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ ترجیحات ───ـ                    │ ← section header
│  ┌─────────────────────────────┐    │ ← PreferencesCard
│  │ ارائه‌دهنده‌ی پیش‌فرض هوش مصنوعی  │    │   --bg-elevated, --elevation-2
│  │ [هیچ] [Gemini] [OpenAI] [Claude]│   │   --radius-xl, --space-5 padding
│  │                              │    │   SegmentedControl
│  │ ─────────────────────────── │    │
│  │ تم پیش‌فرض                    │    │
│  │ [روشن] [تیره] [سیستم]         │    │ ← SegmentedControl
│  │                              │    │
│  │ ─────────────────────────── │    │
│  │ زبان پیش‌فرض                   │    │
│  │ [فارسی] [English]             │    │ ← SegmentedControl
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  [ذخیره تغییرات]                     │ ← primary CTA, full-width
└─────────────────────────────────────┘
```

**Tablet (768–1023px):**
2-column:
- Left: Avatar + Personal Info.
- Right: Security + Preferences + Save CTA.

**Desktop (≥1024px):**
2-column with sidebar, max-width 1024px:
- Left (50%): Avatar + Personal Info.
- Right (50%): Security + Preferences + Save CTA.

### Visual Hierarchy
1. **Avatar** — identity, immediately recognizable.
2. **Personal info** — name (editable), email (locked, verified).
3. **Security** — password, 2FA, active sessions.
4. **Preferences** — default LLM, theme, language.
5. **Save CTA** — persist changes.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|---|
| Top bar | TopBar (back link variant) | "بازگشت به تنظیمات" |
| Page header | H1 | "پروفایل" |
| Avatar | Card (default, §20) + Avatar (custom, 80px circle) | Image or initials |
| Personal Info | Card (default) + TextField (§21) ×2 | name (editable), email (disabled) |
| Security | Card (default) + Button (ghost, link variant) + Toggle (custom) | password link, 2FA toggle, sessions link |
| Preferences | Card (default) + SegmentedControl (Tabs §24) ×3 | default LLM, theme, language |
| Save CTA | Button (primary, §19) | "ذخیره تغییرات" |

### Cards

| Card | Variant | Content | Future API |
|---|---|---|---|
| AvatarCard | default | Avatar (80px) + change link | `POST /auth/avatar` |
| PersonalInfoCard | default | name TextField + email TextField (disabled) | `PATCH /auth/me` |
| SecurityCard | default | password link + 2FA toggle + sessions link | `POST /auth/change-password`, `POST /auth/2fa/*` |
| PreferencesCard | default | 3 SegmentedControls (LLM, theme, language) | `PATCH /auth/me` (preferences) |

### Tables
None.

### Charts
None.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch `GET /auth/me`. Show skeletons. Populate fields. |
| 2 | Click «تغییر عکس» | File picker opens. Select image → upload spinner → avatar updates. |
| 3 | Edit name field | Inline edit. Validate on blur (non-empty). |
| 4 | Click «تغییر رمز عبور» | Modal opens: old password + new password + confirm. Submit → `POST /auth/change-password`. |
| 5 | Toggle 2FA on | Setup flow: QR code modal → scan → enter code → verify → 2FA enabled. |
| 6 | Toggle 2FA off | Confirmation modal → enter password → 2FA disabled. |
| 7 | Click «جلسات فعال» | Navigate to `/settings/sessions` (future). |
| 8 | Change default LLM | SegmentedControl updates. Saved on «ذخیره تغییرات». |
| 9 | Change default theme | SegmentedControl updates. Instant theme switch (preview). Saved on «ذخیره». |
| 10 | Change default language | SegmentedControl updates. Instant language switch (preview). Saved on «ذخیره». |
| 11 | Click «ذخیره تغییرات» | Button loading. `PATCH /auth/me`. On success → toast «تغییرات ذخیره شد». On error → inline error. |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| Avatar change link | `--fg-secondary` | `--accent-primary` | 200ms |
| Security link rows | `--bg-elevated` | `--bg-hover`, arrow slides | 200ms |
| 2FA toggle | `--bg-surface` | `--bg-hover` | 200ms |
| SegmentedControl options | `--bg-surface` | `--bg-hover`, active `--accent-primary` at 12% | 200ms |
| Save CTA | `--accent-cta` | `--accent-cta-hover`, scale 1.02 | 200ms |
| TextField (name) | `--border-strong` | `--accent-primary` (on focus) | 200ms |

### Responsive Behavior

| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: avatar+info left, security+preferences+save right |
| `≥ lg` (1024px+) | 2-column, max-width 1024px, centered |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered card fade-up | 400ms | `--ease-out` |
| Avatar upload | Spinner during upload. Fade transition on new avatar. | 300ms | `--ease-out` |
| Name field edit | Border transition on focus | 200ms | `--ease-out` |
| 2FA toggle on | Toggle slides. QR modal scale-up. | 250ms | `--ease-out` |
| 2FA toggle off | Toggle slides. Confirmation modal scale-up. | 250ms | `--ease-out` |
| SegmentedControl change | Bg transition | 200ms | `--ease-out` |
| Save CTA press | Scale 0.97 | 100ms | `--ease-out` |
| Save loading | Spinner replaces text | — | — |
| Save success | Toast slides in from top | 250ms | `--ease-out` |
| Save error | Form shake (translateX 0 → -8 → 8 → -4 → 0) | 300ms | `--ease-in-out` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading (fetch profile):**
- Avatar: skeleton circle.
- Fields: skeleton TextFields.
- Preferences: skeleton SegmentedControls.

**Saving:**
- Save CTA: spinner + «در حال ذخیره...».
- All fields disabled.

**Error (fetch):**
- Error State (§36): «بارگذاری پروفایل ناموفق بود» + retry.

**Error (save):**
- Inline error on the field that failed (e.g., name too short).
- Form shake animation.

**Error (avatar upload):**
- Toast «آپلود عکس ناموفق بود. دوباره تلاش کنید.»
- Avatar reverts to previous.

**Error (2FA setup):**
- Modal: «کد نادرست است. دوباره تلاش کنید.»
- QR code remains, code field clears.

**Success (save):**
- Toast «تغییرات ذخیره شد» (3s).

**Success (avatar upload):**
- Avatar fades to new image. Toast «عکس پروفایل به‌روزرسانی شد».

**Success (2FA enabled):**
- Modal: «احراز هویت دو مرحله‌ای فعال شد». Toggle shows on.

### Accessibility

| Aspect | Implementation |
|---|---|
| All fields | `<label>` associated via `for`/`id` |
| Avatar | `alt` text with user name |
| Toggles | `role="switch"`, `aria-checked` |
| SegmentedControls | `role="radiogroup"` + `role="radio"` + `aria-checked` |
| Password modal | `role="dialog"`, `aria-modal="true"`, focus trap |
| 2FA modal | Same |
| Save button | `aria-busy="true"` when saving |
| Error messages | `aria-live="polite"`, `aria-invalid="true"` on field |
| Keyboard | Tab through all fields. Enter submits. Esc closes modals. |

### Edge Cases

| Edge case | Handling |
|---|---|
| User has no avatar (new account) | Show initials (first letter of name/email) in `--accent-primary` circle. |
| Email not verified | Show «✗ تأیید نشده» warning badge + «ارسال مجدد ایمیل تأیید» link. |
| Name is empty | Show placeholder «نام شما». Validation on save: «نام نمی‌تواند خالی باشد». |
| 2FA already enabled | Toggle shows on. «خاموش کردن» requires password re-entry. |
| Avatar file too large (>2MB) | Inline error: «حجم عکس بیش از ۲ مگابایت است». |
| Avatar format unsupported | Inline error: «فرمت پشتیبانی نمی‌شود. JPG یا PNG استفاده کنید.» |
| Network error during save | Toast «ذخیره ناموفق بود. تغییرات شما حفظ شد — دوباره تلاش کنید.» Changes remain in form. |

---

## 8. Subscription (future-ready) — Expanded

### Purpose
View current plan, compare tiers, upgrade/downgrade, manage billing. Phase 1 ships without billing; this screen is fully specified for feature-flag activation.

### Engine dependency
Future: `GET /api/v1/subscription` (current plan + usage), `POST /api/v1/subscription/checkout` (Stripe checkout session), `GET /api/v1/subscription/invoices` (billing history), `POST /api/v1/subscription/cancel`.

### Phase status
Future-ready (Phase 1 ships without billing; this screen activates when subscription tiers are enabled).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [← بازگشت به تنظیمات]                 │
├─────────────────────────────────────┤
│  اشتراک                              │ ← --text-h1
│                                      │
│  ───ـ طرح فعلی ───ـ                   │ ← section header
│  ┌─────────────────────────────┐    │ ← CurrentPlanCard
│  │ ┌── accent border (blue) ──┐ │    │   severity-bordered (--accent-primary)
│  │ │                           │ │    │   --bg-elevated, --elevation-2
│  │ │ طرح فعلی: Pro              │ │    │   --radius-xl, --space-5 padding
│  │ │                           │ │    │
│  │ │ ┌─────────────────────┐  │ │    │
│  │ │ │ ۵ از ۱۰۰ تحلیل       │  │ │    │ ← usage bar
│  │ │ │ [━━░░░░░░░░░░░░░░░░] │  │ │    │   5% filled
│  │ │ │ استفاده شده این ماه   │  │ │    │
│  │ │ └─────────────────────┘  │ │    │
│  │ │                           │ │    │
│  │ │ تمدید بعدی: ۱۴۰۴/۰۵/۲۰    │ │    │ ← --text-body-sm
│  │ │ ($۱۹/ماه)                 │ │    │
│  │ │                           │ │    │
│  │ │ [💳 مدیریت روش پرداخت]     │ │    │ ← ghost link
│  │ │ [📄 فاکتورها]              │ │    │ ← ghost link
│  │ │ [لغو اشتراک]              │ │    │ ← destructive ghost link
│  │ └───────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│                                      │ ← --space-4 gap
│  ───ـ مقایسه طرح‌ها ───ـ              │ ← section header
│  ┌─────────────────────────────┐    │ ← PlanCard (Free)
│  │ رایگان                        │    │   --bg-elevated, --elevation-2
│  │ $۰/ماه                        │    │   --radius-xl, --space-5 padding
│  │                              │    │
│  │ ✓ ۵ تحلیل در ماه               │    │ ← feature list
│  │ ✓ تاریخچه‌ی محدود (۵ تحلیل)     │    │
│  │ ✓ دسترسی به Dashboard         │    │
│  │ ✗ PDF واترمارک‌دار              │    │
│  │ ✗ Trends                      │    │
│  │ ✗ Trade Explorer              │    │
│  │                              │    │
│  │ [طرح پایین‌تر]                 │    │ ← disabled (current is higher)
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Pro, current)
│  │ ┌── accent border ────────┐ │    │   highlighted
│  │ │ Pro           [طرح فعلی] │ │    │   --accent-primary border
│  │ │ $۱۹/ماه                  │ │    │
│  │ │                          │ │    │
│  │ │ ✓ تحلیل نامحدود            │ │    │
│  │ │ ✓ تاریخچه‌ی نامحدود          │ │    │
│  │ │ ✓ PDF بدون واترمارک         │ │    │
│  │ │ ✓ Trends                   │ │    │
│  │ │ ✓ Trade Explorer           │ │    │
│  │ │ ✗ فضای مربی                 │ │    │
│  │ │ ✗ SSO                      │ │    │
│  │ └──────────────────────────┘ │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Mentor)
│  │ Mentor                        │    │
│  │ $۴۹/ماه                       │    │
│  │                              │    │
│  │ ✓ همه‌ی امکانات Pro             │    │
│  │ ✓ فضای چند دانش‌جو (تا ۲۰ نفر)  │    │
│  │ ✓ حاشیه‌نویسی روی تحلیل‌ها       │    │
│  │ ✓ اولویت پشتیبانی             │    │
│  │ ✗ SSO                        │    │
│  │                              │    │
│  │ [ارتقا به Mentor →]           │    │ ← primary CTA
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Enterprise)
│  │ Enterprise                    │    │
│  │ تماس بگیرید                    │    │
│  │                              │    │
│  │ ✓ همه‌ی امکانات Mentor           │    │
│  │ ✓ SSO (SAML/OAuth)           │    │
│  │ ✓ تیم دشبورد                  │    │
│  │ ✓ API access                 │    │
│  │ ✓ مدیر اختصاصی                │    │
│  │ ✓ SLA                        │    │
│  │                              │    │
│  │ [تماس با فروش →]              │    │ ← secondary CTA
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ سوالات متداول ───ـ              │ ← section header
│  [▾ آیا می‌توانم هر زمان لغو کنم؟]     │ ← accordion item
│  [▾ آیا پرداخت سالیانه تخفیف دارد؟]   │
│  [▾ روش‌های پرداخت چیست؟]              │
└─────────────────────────────────────┘
```

**Tablet (768–1023px):**
2×2 grid for plan cards. Current plan card spans full width on top.

**Desktop (≥1024px):**
4-column comparison table. Each plan is a column. Feature matrix rows below.

### Visual Hierarchy
1. **Current plan card** — status (what am I paying for?).
2. **Plan comparison cards** — the 4 tiers.
3. **Feature matrix (desktop)** — detailed comparison.
4. **FAQ** — common questions.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|---|
| Top bar | TopBar (back link variant) | "بازگشت به تنظیمات" |
| Page header | H1 | "اشتراک" |
| Current Plan | Card (severity-bordered with `--accent-primary`) + Progress Indicator (§33) | Plan name + usage bar + renewal + manage links |
| Plan Cards ×4 | Card (default) + Button (§19) | Plan name + price + feature list + CTA |
| Feature Matrix (desktop) | Table (§22) | Features × Plans comparison |
| FAQ | Card (default) + Accordion (custom) | 3-5 expandable questions |

### Cards

| Card | Variant | Border | Content | Future API |
|---|---|---|---|---|
| CurrentPlanCard | severity-bordered | `--accent-primary` | Plan name + usage ProgressIndicator + renewal date + 3 manage links | `GET /subscription` |
| PlanCard (Free) | default | `--border-subtle` | «رایگان» + $0/mo + 6 features (3✓ 3✗) + disabled CTA | — |
| PlanCard (Pro) | default + accent | `--accent-primary` (current) | «Pro» + $19/mo + 7 features + «طرح فعلی» badge | — |
| PlanCard (Mentor) | default | `--border-subtle` | «Mentor» + $49/mo + 6 features + «ارتقا» CTA | `POST /subscription/checkout` |
| PlanCard (Enterprise) | default | `--border-subtle` | «Enterprise» + «تماس بگیرید» + 6 features + «تماس» CTA | Mailto/contact form |
| FAQ items | default | `--border-subtle` | Question (expandable) + answer | — |

### Tables
- **Feature Matrix (desktop only):** Comparison table. Rows: ~15 features. Columns: Free / Pro / Mentor / Enterprise. Cells: ✓ or ✗ or «تا ۲۰ نفر» (limited). Header row sticky. Current plan column highlighted with `--accent-primary` at 8% bg.

### Charts
None.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch `GET /subscription`. Show skeletons. Populate current plan + usage. |
| 2 | Click «ارتقا به Mentor» | Navigate to `/checkout?plan=mentor` (future Stripe checkout). |
| 3 | Click «تماس با فروش» | Open mailto or contact form modal. |
| 4 | Click «مدیریت روش پرداخت» | Navigate to Stripe billing portal (external). |
| 5 | Click «فاکتورها» | Navigate to `/settings/invoices` (future). |
| 6 | Click «لغو اشتراک» | Confirmation modal (no dark patterns): «اشتراک شما تا پایان دوره فعال می‌ماند. پس از آن به طرح رایگان باز می‌گردید.» → «تأیید» / «انصراف». |
| 7 | Click FAQ question | Expand/collapse answer. |
| 8 | Hover plan card (desktop) | Subtle elevation lift. |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| PlanCards | `--elevation-2` | `--elevation-3` | 200ms |
| Current plan card | `--elevation-2` + accent border | (non-interactive) | — |
| «ارتقا» CTA | `--accent-cta` | `--accent-cta-hover`, scale 1.02 | 200ms |
| «تماس با فروش» CTA | `--fg-secondary`, ghost | `--accent-primary` | 200ms |
| Manage links | `--fg-secondary` | `--accent-primary` | 200ms |
| «لغو اشتراک» link | `--fg-secondary` | `--severity-critical` | 200ms |
| FAQ questions | `--bg-elevated` | `--bg-hover`, chevron rotates | 200ms |
| Feature matrix rows (desktop) | `--bg-elevated` | `--bg-hover` | 150ms |

### Responsive Behavior

| Breakpoint | Layout | Plan Cards | Feature Matrix |
|---|---|---|---|
| `< sm` (375px) | Single column, stacked | Stacked | Hidden (use card feature lists) |
| `sm` to `< md` | 2×2 grid | 2×2 grid | Hidden |
| `md` to `< lg` (768px) | Current plan on top, 4-column row below | 4-column row | Visible |
| `≥ lg` (1024px+) | Full desktop, max-width 1280px | 4-column + feature matrix | Full table |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered plan card fade-up, 100ms per card | 500ms total | `--ease-out` |
| Current plan highlight | Border glow pulse once | 600ms | `--ease-in-out` |
| Usage bar fill | Animate 0 → current usage % | 800ms | `--ease-out` |
| CTA press | Scale 0.97 | 100ms | `--ease-out` |
| Cancel confirmation modal | Scale-up 0.95 → 1 | 200ms | `--ease-out` |
| FAQ expand | Height auto + content fade. Chevron rotates 180°. | 250ms | `--ease-out` |
| Plan card hover (desktop) | Elevation lift | 200ms | `--ease-out` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading (fetch subscription):**
- CurrentPlanCard: skeleton (plan name + usage bar + links).
- PlanCards: skeleton cards.

**Empty (user on Free tier):**
- CurrentPlanCard shows: «طرح رایگان» + «۰ از ۵ تحلیل استفاده شده» + «ارتقا به Pro» CTA.
- No cancel link (Free can't be cancelled).

**Error (fetch):**
- Error State (§36): «بارگذاری اشتراک ناموفق بود» + retry.

**Error (checkout fail):**
- Toast: «انتقال به درگاه پرداخت ناموفق بود. دوباره تلاش کنید.»

**Error (cancel fail):**
- Toast: «لغو ناموفق بود. دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.»

**Success (upgrade):**
- Toast: «ارتقا به Mentor انجام شد» + redirect to Dashboard.
- CurrentPlanCard updates to new plan.

**Success (cancel):**
- Toast: «اشتراک شما در پایان دوره لغو می‌شود».
- CurrentPlanCard shows: «لغو شده — تا ۱۴۰۴/۰۵/۲۰ فعال است».

### Accessibility

| Aspect | Implementation |
|---|---|
| Plan cards | `<h3>` for plan name, `<ul>` for feature list |
| Feature icons | `aria-hidden="true"` (checkmarks/X are decorative; text conveys meaning) |
| CTAs | Descriptive `aria-label` (e.g., «ارتقا به طرح Mentor») |
| Cancel confirmation | `role="alertdialog"` |
| Usage bar | `role="progressbar"`, `aria-valuenow`, `aria-valuetext` («۵ از ۱۰۰ تحلیل استفاده شده») |
| FAQ | `role="region"`, questions `role="button"`, `aria-expanded` |
| Feature matrix (desktop) | `<table>`, `<th scope>`, `<caption>` |
| Keyboard | Tab through plan cards, CTAs, FAQ. Enter to activate. |

### Edge Cases

| Edge case | Handling |
|---|---|
| User on Free tier, 5/5 analyses used | Usage bar 100% red. «سقف ماهانه رسید. برای تحلیل بیشتر، ارتقا دهید.» |
| User on annual billing | Show «$۱۹۰/سال» instead of «$۱۹/ماه». Renewal date shows annual. |
| User in trial period | CurrentPlanCard shows: «Pro — دوره‌ی آزمایشی (۷ روز باقی‌مانده)» + countdown. |
| User's subscription expired | CurrentPlanCard shows: «اشتراک منقضی شد» + «به‌روزرسانی روش پرداخت» CTA. |
| Enterprise user (custom pricing) | Hide plan comparison. Show: «طرح Enterprise اختصاصی شما» + account manager contact. |
| Currency mismatch (user in Iran) | Show prices in Toman with note: «قیمت‌ها به‌صورت تقریبی و به تومان نمایش داده شده‌اند.» |
| Payment method expired | Warning badge on CurrentPlanCard: «روش پرداخت شما منقضی شده است» + update link. |

---

## 9. Notifications (future-ready) — Expanded

### Purpose
Notification center — in-app alerts for analysis completion, billing events, feature announcements, system messages. The single place to see "what happened while I was away."

### Engine dependency
Future: `GET /api/v1/notifications?page=&page_size=`, `PATCH /api/v1/notifications/{id}/read`, `PATCH /api/v1/notifications/read-all`, `DELETE /api/v1/notifications/{id}`.

### Phase status
Future-ready (Phase 1 ships without notifications; this screen activates when notification system is enabled).

### Layout

**Mobile (375 × 667):**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰]  اعلان‌ها              [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  اعلان‌ها                             │ ← --text-h1
│  [علامت‌گذاری همه به‌عنوان خوانده‌شده]   │ ← ghost link, right-aligned
│                                      │
│  ───ـ فیلتر ───ـ                      │ ← section header
│  [همه (۱۲)] [خوانده‌نشده (۳)] [تحلیل]   │ ← filter pills, horizontal scroll
│  [صورتحساب] [سیستم]                   │
│                                      │
│  ───ـ امروز ────                      │ ← time group header
│  ┌─────────────────────────────┐    │ ← NotificationCard (unread)
│  │ ● [✓] تحلیل کامل شد           │    │   blue dot (unread) on inline-start
│  │ trades_jan.csv آماده است.     │    │   tinted bg (--bg-surface)
│  │ ۵ دقیقه پیش                    │    │   --bg-elevated, --elevation-2
│  │                              │    │   --radius-lg, --space-4 padding
│  │ [مشاهده تحلیل →]              │    │ ← CTA → /dashboard/[id]
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← NotificationCard (read)
│  │   [💳] فاکتور جدید             │    │   no dot (read)
│  │   فاکتور خرداد آماده است.      │    │   normal bg (--bg-elevated)
│  │   ۲ ساعت پیش                   │    │
│  │   [مشاهده فاکتور →]            │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ این هفته ───ـ                  │ ← time group header
│  ┌─────────────────────────────┐    │ ← NotificationCard (read)
│  │   [✨] ویژگی جدید               │    │
│  │   حالا می‌توانید معاملات خام     │    │
│  │   را در Trade Explorer ببینید.│    │
│  │   ۲ روز پیش                     │    │
│  │   [مشاهده →]                   │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← NotificationCard (unread)
│  │ ● [⚠] هشدار کیفیت داده         │    │
│  │   ۳ هشدار در تحلیل اخیر شما    │    │
│  │   ۳ روز پیش                     │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ قدیمی‌تر ───ـ                   │ ← time group header
│  [نمایش قدیمی‌تر (۸ مورد)]            │ ← load more button
│                                      │
│  (empty state if no notifications):  │
│  ┌─────────────────────────────┐    │
│  │      [illustration 120px]    │    │ ← empty-notification.svg
│  │                              │    │
│  │     اعلانی موجود نیست         │    │
│  │  اعلان‌های شما اینجا نمایش     │    │
│  │  داده می‌شوند.                 │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
│ [📊][📉][🔍][💡][📄]                │ ← bottom tab bar
```

**Tablet (768–1023px):**
Same layout, max-width 640px centered. Optional: filter sidebar on left.

**Desktop (≥1024px):**
2-column:
- Left (25%): Filter sidebar (All / Unread / Analysis / Billing / System) + settings link.
- Right (75%): Notification list, max-width 640px.

### Visual Hierarchy
1. **Page title + mark all read** — controls.
2. **Filter pills** — narrow the view.
3. **Time-grouped notification cards** — the content (newest first).
4. **Load more** — pagination.

### Component Placement

| Position | Component (Phase 3 ref) | Content |
|---|---|---|---|
| Top bar | TopBar | Standard |
| Page header | H1 + Button (ghost, link variant) | "اعلان‌ها" + "علامت‌گذاری همه" |
| Filter | SegmentedControl (Tabs §24, pill variant) or pills | All / Unread / Analysis / Billing / System |
| Notification list | NotificationCard (custom, built from Card §20) ×N | Grouped by time (Today / This week / Older) |
| Load more | Button (ghost) | "نمایش قدیمی‌تر" |
| Empty state | Empty State (§35) | Illustration + headline + description |
| Filter sidebar (desktop) | Card (default) + SegmentedControl | Filter options |

### Cards

| Card | Variant | Content | Future API |
|---|---|---|---|
| NotificationCard (unread) | default, tinted bg | Blue dot (inline-start) + icon + title + description + timestamp + optional CTA | `PATCH /notifications/{id}/read` |
| NotificationCard (read) | default, normal bg | (no dot) + icon + title + description + timestamp + optional CTA | — |
| Filter sidebar (desktop) | default | SegmentedControl with 5 filter options + «تنظیمات اعلان» link | — |

### Tables
None.

### Charts
None.

### Interactions

| # | Trigger | Response |
|---|---|---|
| 1 | Page mount | Fetch `GET /notifications`. Show skeletons. Populate list. |
| 2 | Click notification card | Mark as read (`PATCH /notifications/{id}/read`). Navigate to target (if CTA exists). |
| 3 | Click CTA in notification | Mark as read + navigate to target. |
| 4 | Click «علامت‌گذاری همه» | `PATCH /notifications/read-all`. All cards transition to read state. |
| 5 | Click filter pill | Filter list by type. Cross-fade 200ms. |
| 6 | Swipe left (mobile) on notification | Reveal delete action. Tap delete → `DELETE /notifications/{id}`. Card slides out. |
| 7 | Click «نمایش قدیمی‌تر» | Fetch next page. Append to list. |
| 8 | Hover notification (desktop) | Subtle elevation lift. |
| 9 | Click «تنظیمات اعلان» (desktop sidebar) | Navigate to `/settings/notifications` (future). |

### Hover States

| Element | Default | Hover | Transition |
|---|---|---|---|
| NotificationCards | `--elevation-2` | `--elevation-3`, cursor pointer | 200ms |
| «علامت‌گذاری همه» link | `--fg-secondary` | `--accent-primary` | 200ms |
| Filter pills | `--bg-elevated` | `--bg-hover`, active `--accent-primary` at 12% | 200ms |
| CTA in notification | `--fg-secondary` | `--accent-primary` | 200ms |
| Load more button | `--bg-elevated` | `--bg-hover` | 200ms |
| Delete action (swipe-revealed) | `--severity-critical` | brighter red | 200ms |

### Responsive Behavior

| Breakpoint | Layout | Filter |
|---|---|---|
| `< sm` (375px) | Single column, horizontal scroll filter pills | Pills |
| `sm` to `< md` | Same as mobile | Pills |
| `md` to `< lg` (768px) | Single column, max-width 640px centered | Optional sidebar |
| `≥ lg` (1024px+) | 2-column: filter sidebar (25%) + list (75%) | Sidebar |

### Micro-interactions

| Trigger | Response | Duration | Easing |
|---|---|---|---|
| Page mount | Skeleton → staggered notification card fade-up, 50ms per card | 400ms total | `--ease-out` |
| New notification appears (real-time) | Slide-in from top + fade | 250ms | `--ease-out` |
| Mark as read | Bg transition (tinted → normal), blue dot fades out | 300ms | `--ease-out` |
| Mark all read | All cards transition simultaneously | 300ms | `--ease-out` |
| Swipe to dismiss (mobile) | Card slides out left + fade | 200ms | `--ease-in` |
| «نمایش قدیمی‌تر» | Additional cards slide-down + fade, staggered 50ms | 300ms | `--ease-out` |
| Filter change | List cross-fade | 200ms | `--ease-out` |
| Card hover (desktop) | Elevation lift | 200ms | `--ease-out` |
| Reduced motion | All ≤1ms | — | — |

### States

**Loading (fetch notifications):**
- 5 skeleton notification cards (icon + title + description + timestamp placeholders).

**Empty (no notifications):**
- `empty-notification.svg` illustration (120×120, geometric line style).
- Headline: «اعلانی موجود نیست» (`--text-h3`).
- Description: «اعلان‌های شما اینجا نمایش داده می‌شوند.» (`--text-body-sm`, `--fg-secondary`).

**Empty (filter returns no results):**
- «هیچ اعلانی با این فیلتر یافت نشد» + «پاک کردن فیلتر» CTA.

**Error (fetch):**
- Error State (§36): «بارگذاری اعلان‌ها ناموفق بود» + retry.

**Error (mark as read failed):**
- Card reverts to unread state. Toast: «خطا — دوباره تلاش کنید».

**Success (mark as read):**
- Card transitions to read state (bg + dot fade).

**Success (mark all read):**
- All cards transition. Toast: «همه علامت‌گذاری شدند».

**Success (delete):**
- Card slides out. Toast: «اعلان حذف شد».

### Accessibility

| Aspect | Implementation |
|---|---|
| Notification list | `<ul>` with `<li role="listitem">` |
| NotificationCards | `role="button"` (clickable), `aria-label` with full context |
| Unread indicator | `aria-label="خوانده‌نشده"` on the blue dot |
| Filter pills | `role="radiogroup"` + `role="radio"` + `aria-checked` |
| «علامت‌گذاری همه» | `aria-label="علامت‌گذاری همه به‌عنوان خوانده‌شده"` |
| Timestamp | `<time>` element with `datetime` attribute |
| Delete (swipe) | `aria-label="حذف اعلان"` on delete button |
| Keyboard | Tab through notifications. Enter to open. Delete key to dismiss (desktop). |
| Live region | Optional: `aria-live="polite"` on list container for real-time notifications. |

### Edge Cases

| Edge case | Handling |
|---|---|
| 100+ notifications | Paginate (20 per page). «نمایش قدیمی‌تر» loads next page. |
| All notifications unread | «علامت‌گذاری همه» prominent. Filter defaults to «خوانده‌نشده». |
| Notification target no longer exists (e.g., analysis deleted) | Click shows toast: «این تحلیل دیگر موجود نیست». Card remains. |
| Notification with no CTA | Just title + description + timestamp. No click action (or click marks as read only). |
| Real-time notification (WebSocket push) | Slide-in from top. Blue dot. If page is open, auto-mark as read after 5s. |
| User has notifications disabled (settings) | Show banner: «اعلان‌ها غیرفعال هستند. برای فعال‌سازی، به تنظیمات بروید.» + link. |
| Very long notification title | Truncate with ellipsis. Tooltip with full title. |
| Notification icon missing (unknown type) | Fallback to `Info` (Phosphor) icon. |

---

## 10. Cross-Screen Edge Case Patterns

Patterns that apply across the 9 expanded screens, documented once for consistency.

### 10.1 Data missing (partial API response)

| Scenario | Handling |
|---|---|
| A field is `null` or `undefined` in the API response | Show «N/A» in `--fg-muted`. Never show `null` or `undefined` to the user. |
| An entire section is missing (e.g., `psychology.narrative` is empty) | Hide that section/card entirely. Don't show an empty card. |
| `evidence[]` is empty but `diagnosis` exists | Hide evidence section. Show diagnosis only. |
| `recommendations[]` is empty | Hide Coaching CTA. Show «برنامه‌ی اقدام در دسترس نیست» if user navigates to /coaching. |

### 10.2 Extreme values

| Scenario | Handling |
|---|---|
| `net_profit` is extremely large (>$1M) | Format with K/M suffixes: «+$1.2M». Tooltip shows full value. |
| `net_profit` is extremely negative (-$1M) | Format: «-$1.2M». Red. |
| `win_rate_pct` is exactly 0% or 100% | Show with emphasis. KeyInsight callout explains significance. |
| `max_drawdown` is >50% of starting capital | Warning badge: «افت بحرانی». |
| A behavioral score is 100 (max) | ScoreGauge shows full arc. Severity: Critical. |
| `total_trades` is <10 | Warning badge on page: «داده‌ی کم — نتایج با احتیاط». |
| `total_trades` is >10,000 | Downsample charts. Note: «نمودار با نمونه‌گیری نمایش داده شده». |

### 10.3 Network and sync issues

| Scenario | Handling |
|---|---|
| Network drops during page load | Error State with retry. «اتصال برقرار نشد». |
| Network drops during interaction (e.g., mark as read) | Toast: «خطا — دوباره تلاش کنید». UI reverts to previous state. |
| API returns 429 (rate limited) | «تعداد درخواست‌ها بیش از حد. X ثانیه دیگر تلاش کنید.» + countdown. |
| API returns 500 | «خطای داخلی سرور. لطفاً بعداً تلاش کنید.» + retry. |
| API returns 404 (analysis not found) | «تحلیل یافت نشد» + «بازگشت به تاریخچه». |
| Stale data (user re-analyzes, new result differs) | Refresh current page. Toast: «تحلیل به‌روزرسانی شد». |

### 10.4 RTL-specific edge cases

| Scenario | Handling |
|---|---|
| Mixed-direction text (Persian + English code/numbers) | Use `<bdi>` tags. Persian RTL, English/numbers LTR within RTL flow. |
| Chart x-axis in RTL | Reversed (earliest right, latest left). Recharts `reversed` prop. |
| Severity border on `border-inline-start` | Automatically on right in RTL, left in LTR. |
| Icons that imply direction (arrows, chevrons) | Mirror in RTL via `transform: scaleX(-1)`. |
| Modal/drawer slide direction | Drawer from right in RTL, left in LTR. |
| Pagination «Previous» / «Next» | Swap positions in RTL. Arrows mirror. |

### 10.5 Accessibility edge cases

| Scenario | Handling |
|---|---|
| Screen reader user on a chart | `aria-label` summarizes. Visually-hidden `<table>` provides raw data. |
| Keyboard-only user navigating cards | Tab reaches each card. Enter activates. Esc closes. |
| User with `prefers-reduced-motion` | All animations ≤1ms. Skeletons static. Charts instant. Page still fully functional. |
| User with `prefers-contrast: high` | (Future) Increase contrast on borders and text. |
| User on a very small viewport (320px, older phones) | Layout still works — 4 cards may require minimal scrolling, but content is accessible. |
| User on a very large viewport (2560px, 4K) | Content max-width 1280px/1536px, centered. No stretching. |

---

## 11. Updated Changes Summary

### 11.1 What this document delivers (v1.0, Part 2)

| # | Screen | Section | Detail level |
|---|---|---|---|
| 1 | Psychology Analysis (Trader DNA) — Expanded | §1 | Full mobile/tablet/desktop ASCII, 12 interactions, 6 hover states, 10 micro-interactions, all states, edge cases |
| 2 | Overview — Expanded | §2 | Full layouts, 10 interactions, 7 hover states, 8 micro-interactions, all states, edge cases |
| 3 | Performance Analysis — Expanded | §3 | Full layouts, 4 charts specified, 9 interactions, edge cases for extreme values |
| 4 | Risk Analysis — Expanded | §4 | Full layouts, What-If simulation, drawdown chart, 10 interactions, edge cases |
| 5 | Evidence Explorer — Expanded | §5 | Full layouts, filter/sort, 10 interactions, 8 evidence cards, edge cases |
| 6 | Trade Detail — Expanded | §6 | Full layouts (bottom sheet/drawer/route), adjacent trades, 8 interactions, edge cases |
| 7 | Profile (future-ready) — Expanded | §7 | Full layouts, avatar upload, 2FA, 11 interactions, all states, edge cases |
| 8 | Subscription (future-ready) — Expanded | §8 | Full layouts, 4-tier comparison, feature matrix, FAQ, 8 interactions, edge cases |
| 9 | Notifications (future-ready) — Expanded | §9 | Full layouts, filter, time-grouped cards, swipe-to-dismiss, 9 interactions, edge cases |
| 10 | Cross-Screen Edge Case Patterns | §10 | 5 categories: data missing, extreme values, network issues, RTL, accessibility |

### 11.2 Detail level achieved

Each of the 9 expanded screens now includes:
- ✅ **Full mobile (375px) ASCII layout** — every component, every position.
- ✅ **Tablet (768px) layout** — 2-column where applicable.
- ✅ **Desktop (≥1024px) layout** — full sidebar + multi-column.
- ✅ **Visual Hierarchy** — numbered list, 5-6 items.
- ✅ **Component Placement** — table referencing exact Phase 3 components (§19–§36, §39.2 composites).
- ✅ **Cards** — table with variant, border, padding, content, engine source.
- ✅ **Tables** — column specs where applicable.
- ✅ **Charts** — type, library, color, question, data source where applicable.
- ✅ **Interactions** — numbered table, 8-12 interactions per screen.
- ✅ **Hover States** — table with element, default, hover, transition.
- ✅ **Responsive Behavior** — 4-breakpoint table.
- ✅ **Micro-interactions** — table with trigger, response, duration, easing.
- ✅ **States** — Loading, Empty (multiple variants), Error (multiple scenarios), Success.
- ✅ **Accessibility** — ARIA roles, keyboard, screen reader, focus management.
- ✅ **Edge Cases** — 5-8 per screen (data missing, extreme values, partial data, etc.).

### 11.3 What did NOT change

- **Phase 1 hard constraints** — all preserved (Dashboard emotional center, mobile-first, Persian-first RTL, engine untouched).
- **Phase 2 architecture** — fully preserved. These screens consume existing engine outputs.
- **Phase 3 design system** — fully respected. All components referenced by exact Phase 3 §number.
- **Phase 4 Part 1** (`phase4_screen_design.md`) — unchanged. This Part 2 expands the 9 remaining screens; Part 1's 20-screen structure stands.
- **V23 analytical engine** — completely untouched. No invented analytics. The 4 enhanced deep-dive screens (Overview, Performance, Risk, Trade Detail) consume existing `data_context.py` outputs.
- **Trade Explorer API addition** — preserved (Phase 2 §5.1, serialization-only, no engine changes).

### 11.4 Engine dependency verification

All 9 expanded screens consume **only existing V23 API outputs**:

| Screen | API endpoint | data_context fields | New? |
|---|---|---|---|
| Psychology Analysis | `GET /analyses/{id}/report` | `trader_profile`, `psychology`, `evidence`, `behavior_analysis.scores` | No (existing) |
| Overview | `GET /analyses/{id}/report` | `executive_summary`, `performance`, `statistics`, `risk`, `behavior_analysis`, `strengths`, `weaknesses` | No (existing) |
| Performance Analysis | `GET /analyses/{id}/report` | `performance`, `statistics`, `risk.max_drawdown`, `appendix.performance_raw` | No (existing) |
| Risk Analysis | `GET /analyses/{id}/report` | `risk`, `behavior_analysis.scores`, `behavior_analysis.what_if`, `behavior_analysis.context_rows`, `recommendations` | No (existing) |
| Evidence Explorer | `GET /analyses/{id}/report` | `diagnosis`, `evidence` | No (existing) |
| Trade Detail | `GET /analyses/{id}/trades?trade_id={id}` | Single trade row | **Yes** (Phase 2 §5.1, already flagged, serialization-only) |
| Profile | Future: `GET /auth/me`, `PATCH /auth/me` | User profile | Future (not in V23) |
| Subscription | Future: `GET /subscription`, `POST /subscription/checkout` | Subscription data | Future (not in V23) |
| Notifications | Future: `GET /notifications`, `PATCH /notifications/{id}/read` | Notification data | Future (not in V23) |

**Zero engine changes. Zero invented analytics. All Phase 1 build screens use existing V23 outputs. Future-ready screens use future APIs (additive, not engine).**

### 11.5 Compatibility statement

This v1.0 Part 2 document is **fully compatible** with:
- Phase 1 Product Strategy (approved).
- Phase 2 Visual Design + UX Architecture v1.2 (approved).
- Phase 3 Design System v1.1 (approved).
- Phase 4 Screen Design Part 1 (`phase4_screen_design.md`, approved).
- V23 analytical engine (untouched).

### 11.6 Phase 5 readiness

With Part 1 (20 screens) + Part 2 (9 expanded screens), the design specification is **complete and implementation-ready**. Phase 5 (Implementation Kickoff) can begin with:
1. Token system (Phase 3 §40.2).
2. Typography (Phase 3 §40.6 step 2).
3. Primitives + Layout + Feedback + Composite components (Phase 3 §40.6 steps 3-6).
4. **Dashboard first** (Phase 3 §40.6 step 7, highest priority — verify 375 × 667 fit).
5. Remaining 19 screens per Part 1 + Part 2 specs.
6. Pre-Phase-4 Validation Checklist (Phase 3 §43, 80+ items) as acceptance criteria.

---

**Document version:** v1.0 (Part 2, companion to `phase4_screen_design.md`)
**Status:** For approval — gate for Phase 5 (Implementation Kickoff)
**Awaiting approval before Phase 5.**
