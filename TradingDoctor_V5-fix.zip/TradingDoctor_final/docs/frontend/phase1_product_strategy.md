# Trading Doctor — Phase 1 Product Strategy Document

**Author:** Senior Product Designer / UX Architect
**Status:** For approval — gate for Phase 2 (UX/Visual Design)
**Engine baseline:** Trading Doctor V23 Phase 4 (analytical engine is fixed; this document consumes only existing capabilities)
**Design methodology reference:** UI/UX Pro Max Skill Pack v2.6.2

> **Hard constraint reminder (carried from project brief):**
> The analytical engine is production-ready and must not be redesigned.
> Every feature listed in this document is mapped 1:1 to an existing V23
> capability (engine output, REST endpoint, or reporting module). No new
> analytics are invented. Where a feature is marked *future-ready*, it is
> a UX/permission surface only — it does not require engine work.

---

## 1. Product Vision

Trading Doctor is being transformed from an engineering-grade Streamlit tool into a **premium SaaS web application** that serves one mission: **turn raw trade history into behavioral self-awareness**.

The vision is not "another backtesting platform" and not "another broker dashboard." Trading Doctor occupies a specific, currently under-served position in the trading-software landscape: it is the **clinical diagnostician of trading behavior**. A trader can already see *what* they made or lost anywhere — their broker shows P&L. Trading Doctor tells them *why*: which repeated behavioral pattern is silently draining their account, in dollars, with evidence, and what to do about it this week.

The product vision is to make this diagnosis **accessible to every trader in under 60 seconds** — from file upload to a clear, non-judgmental, evidence-backed answer to the question *"am I losing because of my strategy, or because of me?"* — and to do so with the polish and trust signals of a premium fintech SaaS, not the aesthetic of an internal tool.

The web application is the **primary surface**; the analytical engine and REST API are unchanged infrastructure that this surface consumes.

---

## 2. Product Goals

### User goals (what success looks like for the trader)

1. **Time-to-diagnosis under 60 seconds** from landing on the home page to seeing a primary behavioral diagnosis.
2. **Clarity over completeness** — the trader leaves the Dashboard understanding one actionable insight, not ten ambiguous metrics.
3. **Trust through evidence** — every claim ("you have revenge trading") is paired with frequency and dollar impact, never asserted.
4. **A concrete next step** — every analysis ends with a prioritized action plan, not just a description of the problem.
5. **Portability** — the trader can export a professional PDF report for their journal, mentor, or prop firm evaluator within two clicks.
6. **Habitual re-use** — the trader returns monthly to re-analyze and see whether their scores are trending in the right direction.

### Business goals (what success looks like for the product)

1. **Conversion clarity** — a first-time visitor understands the value proposition without scrolling past the hero section.
2. **Premium positioning** — visual and interaction quality signals "this is a serious tool worth paying for," distinct from free online calculators.
3. **Retention through value, not lock-in** — users return because the diagnosis is useful, not because their data is held hostage. Every analysis is exportable.
4. **Future monetization readiness** — the IA, permissions model, and module structure are designed so that paid tiers, multi-portfolios, and mentor/enterprise seats can be added without restructuring the application.
5. **Persian-first market leadership** — RTL-native experience for the Iranian/Persian-speaking trading community, a market currently served only by LTR-translated tools.

---

## 3. User Personas

### Persona 1 — Arman, the Disciplined Retail Trader (Primary)

- **Profile:** 28, Tehran, 18 months trading forex (MT5) and crypto futures (Binance). Technical analysis is solid; P&L is negative.
- **Goal:** Understand *why* he loses when his strategy backtests fine.
- **Behavior:** Trades evenings, keeps a spreadsheet journal (inconsistent), watches YouTube coaches.
- **Pain:** Brokers show P&L but not behavior. He suspects revenge trading but can't prove it.
- **Success with Trading Doctor:** Uploads MT5 CSV → sees Discipline Score 47/100, Primary Diagnosis "Revenge Trading after consecutive losses" with $1,840 impact → reads action plan → exports PDF → sticks on his monitor.
- **Sensitivity:** Persian-native, prefers RTL. Skeptical of "AI coaching" fluff — wants evidence.

### Persona 2 — Saghar, the Prop Firm Challenger

- **Profile:** 31, trying to pass funded-account challenges. Has failed 4 challenges in 6 months.
- **Goal:** Identify the recurring behavioral leak that blows her challenges.
- **Behavior:** Trades 1–2 challenges per month, has detailed MT5 history for each.
- **Pain:** Each failure feels different in the moment, but she suspects a pattern.
- **Success with Trading Doctor:** Runs analyses on each challenge's history → Trends page shows her `overtrading_score` spikes in week 2 of every challenge → diagnosis becomes actionable.
- **Sensitivity:** Needs exportable PDF to discuss with her evaluator. Cares about longitudinal comparison.

### Persona 3 — Kourosh, the Trading Mentor

- **Profile:** 41, full-time mentor with 12 students. Currently reviews student CSVs manually.
- **Goal:** Speed up student diagnosis; provide objective evidence for his feedback.
- **Behavior:** Weekly 1:1 sessions; needs each student's report ready before the session.
- **Pain:** Manual review takes ~30 minutes per student per week.
- **Success with Trading Doctor:** Uploads each student's CSV → generates PDF → reviews Dashboard in 2 minutes → focuses session on the diagnosed leak.
- **Sensitivity:** Needs history (multiple analyses per student). Future: multi-student workspace. (Future-ready permission tier.)

### Persona 4 — Neda, the Casual Self-Improver

- **Profile:** 35, swing-trades stocks occasionally, treats it as a side hobby.
- **Goal:** Quarterly "health check" on her trading behavior.
- **Behavior:** Low frequency, high retention potential if reports are valuable.
- **Pain:** Most tools assume active daily trading; she feels out of place.
- **Success with Trading Doctor:** Quarterly upload → Dashboard gives her one clear thing to work on → returns next quarter to see if it improved.
- **Sensitivity:** Dislikes jargon. Needs the report to feel approachable, not clinical.

### Persona 5 — Reza, the Trading Firm Risk Manager (Future)

- **Profile:** 38, runs a 6-trader prop desk. Needs behavioral oversight.
- **Goal:** Spot which traders are developing revenge/overtrading patterns before they blow.
- **Behavior:** Weekly review meetings; needs aggregated view.
- **Pain:** No behavioral layer on top of P&L reporting.
- **Success with Trading Doctor:** (Future enterprise tier) Team dashboard, audit trail, per-trader trend.
- **Sensitivity:** Audit, SSO, role-based access. (Future-ready permission tier — not Phase 1.)

---

## 4. Primary User Journey

The dominant path: **upload → analyze → understand → act**.

| Step | Screen | User action | System response | Engine touchpoint |
|---|---|---|---|---|
| 1 | Home / Landing | Reads value proposition, sees sample report | Page renders with hero + sample + CTA | None (static) |
| 2 | Home / Landing | Clicks "Analyze my trades" | Navigates to Upload | None |
| 3 | Upload | Drags CSV (or any broker format) | Auto-detects format, shows trade count + date range preview | `utils/file_loader` (via `POST /uploads`) |
| 4 | Upload | Selects LLM provider (default: none) | Provider stored for this analysis | `GET /config` returns allowed providers |
| 5 | Upload | Clicks "Run analysis" | Progress with stage labels: Loading → Validating → Analyzing behavior → Computing scores → Generating diagnosis → Building coaching plan | `POST /analyses` → full pipeline |
| 6 | Dashboard | Lands on post-analysis home | Shows 5 headline cards: Discipline Score, Primary Diagnosis, Archetype, Net Profit, Revenge Risk | `GET /analyses/{id}/report` |
| 7 | Behavioral Analysis | Drills into per-score breakdown | Shows 5 scores with severity, $ impact, insight, what-if | Same report, `behavior_analysis` section |
| 8 | Diagnosis | Reads primary + secondary diagnosis with evidence | Shows prioritized evidence list | Same report, `diagnosis` + `evidence` |
| 9 | Coaching | Reads action plan + AI coaching narrative | Shows prioritized recommendations | Same report, `recommendations` + `ai_coaching` |
| 10 | Report (optional) | Clicks "Download PDF" | Self-contained PDF downloads | `GET /analyses/{id}/report.pdf` |
| 11 | Return visit (next month) | Opens History → re-analyzes → visits Trends | Shows score evolution over time | `GET /history`, then `Trends` view across multiple analyses |

**Critical moment:** Step 6 — the Dashboard is the "moment of truth." If the trader doesn't see their situation clearly within 5 seconds of landing here, the rest of the journey is compromised.

---

## 5. Secondary User Journeys

### Journey B — Returning user re-opens a past analysis
1. Land on Home → already has analyses in History
2. Top bar shows "Recent analyses" dropdown → picks one
3. Lands directly on Dashboard for that analysis
4. Drill-down as in primary journey

### Journey C — Report-only user (mentor/evaluator flow)
1. Land on Home → straight to Upload
2. Upload → Run analysis → skip drill-down
3. Go straight to Report → download PDF
4. Leave (or repeat with another file)

### Journey D — Longitudinal self-comparison (Saghar)
1. Land on Home → Upload challenge #4 history
2. Run analysis → Dashboard
3. Visit Trends → see score evolution across challenges #1–4
4. Identify which score spikes at the same point each challenge

### Journey E — Curious first-time visitor (conversion)
1. Land on Home → unsure if tool is worth using
2. Click "See a sample report"
3. Browse a fully-rendered demo analysis (read-only)
4. Decide to upload own data

### Journey F — Mentor batch flow (Kourosh, future-ready)
1. Log in (future auth)
2. Open mentor workspace (future permission tier)
3. See list of students with their latest analysis
4. Open student's analysis → review Dashboard → download PDF for session

---

## 6. Complete Feature Inventory (mapped to V23 backend capabilities)

> Every feature below is mapped to its concrete backend source. **If it is not in this list, it does not exist in V23 and must not appear in the UI.**

### 6.1 Ingestion & validation

| Feature | Backend source |
|---|---|
| Multi-format file upload (csv, xlsx, xls, htm, html, json, log, txt) | `utils/file_loader.load_any_file` via `POST /api/v1/uploads` |
| Auto column mapping for arbitrary broker formats (MT4/MT5/Binance/Bybit/…) | `utils/column_mapper.ColumnMapper.normalize` |
| Catastrophic-content rejection with clear user message (empty file, no financial/time column) | `utils.validation.DataValidationError` → 422 |
| Non-blocking data-quality warnings (duplicates, zero/negative volume, bad dates) | `doctor.data_quality_warnings` (surfaced in `appendix`) |
| File size enforcement (default 25MB) | `api/config.MAX_UPLOAD_SIZE_BYTES` → 413 |
| LLM provider selection (none / gemini / openai / claude) | `POST /api/v1/analyses` body field `llm_provider` |

### 6.2 Analysis & scoring (deterministic, engine-computed)

| Feature | Backend source |
|---|---|
| 5 behavioral scores: `revenge_score`, `overtrading_score`, `risk_taking_score`, `patience_score`, `discipline_score` (composite 0–100) | `engines/behavior_engine.BehaviorEngine` |
| Per-score `ContextBlock`: `score`, `severity` (Low/Medium/High/Critical), `dollars_lost`, `pct_of_total_profit`, `avg_per_event`, `event_count`, `insight` | `engines/score_engine.ScoreEngine` → `behavior_analysis.context_rows` |
| Detected behavioral patterns list | `behavior_analysis.detected_patterns` |
| What-if simulations (e.g., "if revenge fixed, you'd save $X") | `behavior_analysis.what_if`, `risk.what_if_no_revenge` |

### 6.3 Performance metrics (engine-computed)

| Feature | Backend source |
|---|---|
| `net_profit`, `profit_factor`, `win_rate_pct`, `avg_win`, `avg_loss`, `reward_risk_ratio`, `max_drawdown`, `max_win_streak`, `max_loss_streak`, `total_trades` | `performance` + `statistics` + `risk` sections of the report context |

### 6.4 Edge map (engine-computed)

| Feature | Backend source |
|---|---|
| Best/worst trading hour (avg P&L per hour) | `appendix.edge_map_raw.best_hour`, `worst_hour` |
| Best/worst weekday (total P&L per weekday) | `appendix.edge_map_raw.best_weekday`, `worst_weekday` |
| Best/worst strategy (avg P&L + win rate) | `appendix.edge_map_raw.best_strategy`, `worst_strategy` |
| Long vs Short side comparison | `appendix.edge_map_raw.side_comparison` |

### 6.5 Diagnosis & psychology (engine-computed)

| Feature | Backend source |
|---|---|
| Primary diagnosis (one-line behavioral label) | `diagnosis.primary` |
| Secondary diagnosis | `diagnosis.secondary` |
| Primary diagnosis detail (explanatory text) | `diagnosis.primary_detail` |
| Trader DNA archetype | `trader_profile.archetype` (`psychology.dna`) |
| Psychology narrative | `psychology.narrative` |

### 6.6 Evidence (engine-computed, prioritized)

| Feature | Backend source |
|---|---|
| Top-8 prioritized evidence list with `type`, `description`, `severity`, `frequency`, `financial_impact`, `priority_score`, `confidence` | `evidence[]` (built from `EvidenceEngine.get_top(8)`) |

### 6.7 Coaching & action plan

| Feature | Backend source |
|---|---|
| Prioritized action plan (`priority`, `issue`, `action`) — one recommendation per evidence type | `recommendations[]` (from `CoachingEngine._ACTIONS`) |
| AI coaching narrative (LLM-generated if provider set, heuristic fallback if not) | `ai_coaching.explainable_ai` |
| Reality check text | `ai_coaching.reality_check` |

### 6.8 Strengths & weaknesses (display-only reclassification)

| Feature | Backend source |
|---|---|
| Auto-classified strengths list (severity Low + profitable edges + PF≥1) | `strengths[]` (built in `data_context._build_strengths_weaknesses`) |
| Auto-classified weaknesses list (severity High/Critical + unprofitable edges + PF<1) | `weaknesses[]` |

### 6.9 Reports & export

| Feature | Backend source |
|---|---|
| Structured JSON report (full context, no embedded chart bytes) | `GET /api/v1/analyses/{id}/report` |
| Self-contained HTML report (CSS + charts inline) | `GET /api/v1/analyses/{id}/report.html` |
| PDF report (reportlab, Vazirmatn for Persian, byte-identical numbers to HTML) | `GET /api/v1/analyses/{id}/report.pdf` |

### 6.10 History & longitudinal view

| Feature | Backend source |
|---|---|
| Paginated list of past analyses (filename, total_trades, overall_score, primary_diagnosis, created_at) | `GET /api/v1/history?page=&page_size=` |
| Score trend over time across multiple analyses | `engines/score_engine.TrendEngine` (consumed by Trends page) |

### 6.11 Operational

| Feature | Backend source |
|---|---|
| Liveness/readiness probe | `GET /api/v1/health` |
| Pre-flight config (max upload size, allowed types, LLM providers, auth/rate-limit flags) | `GET /api/v1/config` |

### 6.12 Explicitly NOT supported by V23 (must not appear as features)

- No backtesting engine
- No strategy optimizer
- No real-time trade feeds or broker OAuth
- No trade-by-trade manual annotations / journaling
- No social/community features
- No alerts or notifications
- No multi-user / team workspaces (future-ready only)
- No user-configurable thresholds (engine is fixed)
- No predictive ML models (deterministic engine + optional LLM coaching text only)
- No side-by-side A/B comparison of two datasets (Trends is single-series over time, not two-series compare)

---

## 7. Information Architecture

The IA mirrors the structure of the engine's own output — each major engine surface gets a corresponding consumption surface in the app. This is deliberate: it keeps the UI's mental model identical to the engine's mental model, so users and developers can talk about the same thing with the same vocabulary.

```
Trading Doctor
│
├── Public layer (no analysis required)
│   ├── Home / Landing         — value proposition + sample + CTA
│   └── Sample Report          — read-only demo analysis
│
├── App layer (analysis required, except Upload & History)
│   │
│   ├── Entry surfaces
│   │   ├── Upload             — ingest + validate + run
│   │   └── History            — list + reopen past analyses
│   │
│   ├── Understand layer (Tier 1)
│   │   ├── Dashboard          — composite view, the "moment of truth"
│   │   ├── Behavioral Analysis— per-score breakdown
│   │   └── Diagnosis          — primary/secondary + evidence
│   │
│   ├── Improve layer (Tier 1)
│   │   └── Coaching           — action plan + AI narrative
│   │
│   ├── Explore layer (Tier 2)
│   │   ├── Trader DNA         — psychological archetype
│   │   ├── Edge Map           — when/where leaks happen
│   │   ├── Charts             — visual deep-dive
│   │   └── Trends             — longitudinal score evolution
│   │
│   └── Act layer
│       └── Report             — export HTML / PDF
│
└── Future-ready (auth-gated, not Phase 1)
    ├── Settings               — account, theme, language, LLM default
    ├── Mentor Workspace       — multi-student view (Mentor tier)
    └── Team Dashboard         — aggregated trader view (Enterprise tier)
```

### IA principles

1. **One question per page** — each page answers a single, named question.
2. **Layered depth** — Understand → Improve → Explore → Act. Users can stop at any layer and still leave with value.
3. **Engine-output parity** — every engine output section has exactly one matching page. No page invents content; no engine output is hidden.
4. **Public vs. App separation** — public surfaces (Home, Sample) never require an analysis; app surfaces (except Upload/History) require one. The boundary is enforced by the UI (empty states redirect to Upload).

---

## 8. Navigation Structure

### Primary navigation: left sidebar (RTL-aware, collapsible)

The sidebar is the spine of the app. It is organized by user intent (Understand → Improve → Explore → Act), not by engine module name. Each item is labeled with the user's question, not the engine's term.

| Position | Nav item | User question it answers | Icon (SVG, not emoji) |
|---|---|---|---|
| Top | Upload (CTA, always visible) | "Analyze new trades" | Upload arrow |
| 1 | Dashboard | "How am I doing overall?" | Gauge |
| 2 | Behavioral Analysis | "Which behaviors are costing me?" | Bars |
| 3 | Diagnosis | "What's my main leak?" | Stethoscope |
| 4 | Coaching | "What do I do about it?" | Lightbulb |
| 5 | Trader DNA | "What kind of trader am I?" | DNA helix |
| 6 | Edge Map | "When/where am I best and worst?" | Map pin |
| 7 | Charts | "Show me the visuals" | Line chart |
| 8 | Trends | "Am I improving over time?" | Trend arrow |
| 9 | Report | "Give me a downloadable report" | Document |
| 10 | History | "What have I analyzed before?" | Clock |
| Bottom | Settings (future) | "Configure my account" | Gear |

### Top bar

- **Left (RTL: right):** Trading Doctor logo + wordmark
- **Center:** Current analysis badge — filename + trade count + created-at (clickable to switch via History)
- **Right (RTL: left):** Theme toggle · Language toggle (fa/en) · Account menu (future)

### Empty-state behavior

When no analysis is loaded, all nav items except Upload and History redirect to Upload with a clear empty-state message. This prevents dead-end browsing.

### Mobile

Sidebar collapses to a bottom tab bar with the top 5 items (Dashboard, Behavioral, Diagnosis, Coaching, Report); the rest accessible via a "More" sheet. Upload remains a persistent FAB.

---

## 9. Page Hierarchy

Pages are tiered by depth and dependency. The hierarchy also defines the **default drill-down path** the user is nudged along.

```
Tier 0 — Public
  Home / Landing
  Sample Report

Tier 1 — Entry (no analysis required to be useful, but produce analyses)
  Upload          → produces Analysis
  History         → consumes past Analyses

Tier 2 — Primary consumption (require an Analysis in context)
  Dashboard       → entry view; the 5-second answer
  Behavioral Analysis → drill from Dashboard
  Diagnosis       → drill from Dashboard or Behavioral
  Coaching        → drill from Diagnosis or Dashboard

Tier 3 — Deep dive (require an Analysis in context, used by engaged users)
  Trader DNA      → drill from Diagnosis
  Edge Map        → drill from Behavioral or Dashboard
  Charts          → drill from Dashboard or Behavioral
  Trends          → requires 2+ Analyses; drill from Dashboard or History

Tier 4 — Action
  Report          → produces downloadable HTML/PDF

Tier 5 — Future-ready (Phase 1 stub or hidden)
  Settings
  Mentor Workspace
  Team Dashboard
```

### Hierarchy rules

- **Tier 2 pages never link upward to Tier 1** except via the sidebar. The user is always free to leave, but the page content never pushes them away from the analysis.
- **Tier 3 pages always offer a "back to Dashboard" or "back to related Tier 2" CTA** so the user never feels lost in depth.
- **Tier 4 (Report)** is reachable from any Tier 2/3 page via a persistent top-bar action — exporting is always one click away.

---

## 10. Dashboard Structure

The Dashboard is the most important page in the product. It must answer *"how am I doing, and what should I focus on?"* in a single screen, without scrolling on a standard laptop viewport.

### Above the fold (the 5-second answer)

A 5-card header row, ordered left-to-right (RTL: right-to-left) by importance:

| # | Card | Content | Visual treatment |
|---|---|---|---|
| 1 | **Discipline Score** | Large 0–100 gauge with severity color (Low/Med/High/Critical) | Radial gauge, 96px numeral |
| 2 | **Primary Diagnosis** | One-line label + severity badge | Bold text, color-coded left border (RTL: right) |
| 3 | **Trader Archetype** | Single-word archetype (e.g., "Revenge Trader", "Disciplined Operator") | Pill-shaped label |
| 4 | **Net Profit** | Formatted $ value with up/down indicator | Mono font, green/red |
| 5 | **Revenge Risk** | Percentage + High/Medium/Low indicator | Mini bar with marker |

### Below the fold (the 30-second drill-down)

1. **Performance strip** — 6 small stat cards: Win Rate, Profit Factor, Max Drawdown, Total Trades, Avg Win, Avg Loss.
2. **"Your biggest leak" callout** — top evidence item with type, frequency, $ impact. CTA: "See diagnosis →"
3. **"What you'd save if you fixed it" callout** — what-if highlight (e.g., "$1,840 over this period"). CTA: "See action plan →"
4. **Quick-jump tiles** — 4 cards linking to Behavioral, Diagnosis, Coaching, Edge Map. Each tile shows a one-line preview of what's there (e.g., "3 behaviors need attention").
5. **Data quality warnings** (collapsible, only if warnings exist) — non-blocking, transparent disclosure of any data issues found during validation.

### What the Dashboard does NOT show

- No raw trade table (that's an Appendix concern, available in the Report)
- No charts (those live on the Charts page; Dashboard is numbers + 1 callout)
- No full evidence list (that's Diagnosis)
- No full action plan (that's Coaching)

The Dashboard's job is **triage**, not depth.

---

## 11. User Permissions (future-ready)

Phase 1 ships without authentication (matching the current API's default). However, the IA, navigation, and page structure are designed so that adding permission tiers later requires **zero restructuring** — only role-gating existing items.

### Permission model (future)

| Tier | Price | Capabilities | UX surface |
|---|---|---|---|
| **Anonymous** | Free | Upload + analyze + view in-app; no history persistence; rate-limited | All public + Upload + single in-session analysis |
| **Registered (Free)** | Free | Above + history persistence (max 5 analyses) + PDF download (watermarked) | + History page |
| **Pro** | Paid | Above + unlimited history + unwatermarked PDF + Trends + multiple portfolios | + Trends (fully featured) |
| **Mentor** | Paid | Above + multi-student workspace + per-student history + annotation | + Mentor Workspace |
| **Enterprise** | Custom | Above + SSO + team dashboard + audit trail + API access | + Team Dashboard + Settings (admin) |

### Future-ready UX rules

1. **No Tier-1 nav item is ever hidden behind auth.** Upload, Dashboard, Behavioral, Diagnosis, Coaching — always available. This preserves the "try before you sign up" funnel.
2. **Tier-2 items (Trader DNA, Edge Map, Charts, Trends, Report) appear in nav from day one**, but Trends and Report show an upgrade prompt for Anonymous users instead of being hidden. Hidden items create anxiety; visible-but-gated items create aspiration.
3. **Settings, Mentor Workspace, Team Dashboard** are hidden until the user's role unlocks them.
4. **Role badges** appear in the account menu, not on every page — premium status is signaled through capability, not chrome.

### Why this matters for Phase 1

Every page built in Phase 1 must be designed to work in the Anonymous tier (no user-specific state) AND in the Pro tier (with history and cross-analysis features). The component interfaces should accept an optional `analysisId` and an optional `userId` from day one, even if `userId` is always null in Phase 1.

---

## 12. Module Relationships

```
                     ┌──────────────┐
                     │   Upload     │  produces
                     │              │ ─────────► Analysis (in session)
                     └──────────────┘
                                                  │
                                                  ▼
                                          ┌──────────────┐
                                          │  Dashboard   │  entry view
                                          └──────────────┘
                                                  │
              ┌─────────────────┬─────────────────┼─────────────────┬─────────────────┐
              ▼                 ▼                 ▼                 ▼                 ▼
      ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
      │ Behavioral   │  │  Diagnosis   │  │   Coaching   │  │   Edge Map   │  │  Trader DNA  │
      │  Analysis    │  │              │  │              │  │              │  │              │
      └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
              │                 │                 │                 │                 │
              │  evidence       │  archetype      │  plan from      │  where          │  narrative
              │  feeds          │  from           │  diagnosis      │  leaks          │  from
              │  diagnosis      │  evidence       │                 │  happen         │  evidence
              ▼                 ▼                 ▼                 ▼                 ▼
                       all converge in the user's understanding
                                       │
                                       ▼
                               ┌──────────────┐
                               │    Report    │  exports composite view
                               └──────────────┘
                                       ▲
                                       │
                               ┌──────────────┐
                               │   History    │  lists all past Analyses
                               └──────────────┘
                                       │
                                       │  2+ Analyses required
                                       ▼
                               ┌──────────────┐
                               │    Trends    │  longitudinal view
                               └──────────────┘
```

### Relationship rules

1. **Upload is the only producer of Analyses.** Every other page consumes one.
2. **Dashboard is the entry point to every other consumption page.** No consumption page is reachable only via another consumption page — the Dashboard always provides a path.
3. **Diagnosis depends on Behavioral evidence** (in the engine: `DiagnosisEngine` reads from `EvidenceEngine`, which reads from behavioral scores). The UI preserves this by linking Diagnosis → Behavioral for "see the evidence behind this diagnosis."
4. **Coaching depends on Diagnosis** (in the engine: `CoachingEngine` produces an action plan keyed by evidence type, which is the same evidence behind the diagnosis). The UI links Coaching → Diagnosis for "why this action?"
5. **Trader DNA and Edge Map are independent deep-dives** — they answer different questions ("who am I" vs "when am I best") and can be browsed in any order.
6. **Report aggregates everything** — it has no original content; it composes from all upstream pages.
7. **Trends requires History** — without 2+ past Analyses, Trends shows an empty state with CTA to upload more.

---

## 13. Content Hierarchy

Within every page, content follows a **strict inverted-pyramid** structure:

| Level | Content | Purpose |
|---|---|---|
| 1 | **Headline answer** (1 line) | The single most important takeaway |
| 2 | **Key number** (1 large figure) | Quantification of the answer |
| 3 | **Brief explanation** (2–3 sentences) | Why this number, what it means |
| 4 | **Visual** (chart or visual breakdown) | Evidence for the number |
| 5 | **Detailed breakdown** (table or list) | Granular view for engaged users |
| 6 | **Action / next step** (CTA) | What to do with this information |

### Per-page instantiation

| Page | Headline | Key number | Visual | Detail | CTA |
|---|---|---|---|---|---|
| Dashboard | "Your discipline is X/100" | Discipline gauge | 5 cards + perf strip | Biggest-leak callout | "See diagnosis" |
| Behavioral | "3 behaviors are costing you $X" | Per-score table | Severity bars | Per-score ContextBlocks | "See evidence" |
| Diagnosis | "Primary leak: Revenge Trading" | Severity badge | Evidence list | Top-8 evidence rows | "See action plan" |
| Coaching | "3 actions to take this week" | Action list | Priority chips | Per-action rationale | "Download plan" |
| Trader DNA | "You are a Revenge Trader" | Archetype pill | DNA radar | Narrative + evidence | "See diagnosis" |
| Edge Map | "You trade best at 14:00, worst at 03:00" | Best/worst cards | Hour/weekday heatmap | Side comparison table | "Adjust your schedule" |
| Charts | "Your equity curve" | Equity chart | 6–8 charts | Per-chart explanation | "Download report" |
| Trends | "Your discipline is improving" | Score-over-time chart | Per-score trend lines | Comparison table | "Re-analyze now" |
| Report | "Your full report is ready" | Download buttons | Section preview | Section list | "Download PDF" |

---

## 14. Progressive Disclosure Strategy

Information is revealed in 4 layers, matching the user's growing engagement:

| Layer | Question answered | Where | Who reaches it |
|---|---|---|---|
| **L1 — Composite** | "How am I doing overall?" | Dashboard | Every user, every visit |
| **L2 — Per-dimension** | "Which behaviors are costing me?" | Behavioral, Diagnosis, Coaching | Engaged users (most) |
| **L3 — Cross-cut** | "When/where/who am I?" | Edge Map, Trader DNA, Charts | Curious users |
| **L4 — Longitudinal & raw** | "Am I improving? What's the full data?" | Trends, Report, Appendix | Power users, mentors |

### Disclosure tactics

1. **Dashboard shows 1 number per topic, never the underlying breakdown.** Clicking the card drills into L2.
2. **Evidence lists show top 3 by default, "show all" reveals the remaining 5.** The engine returns top 8; the UI defaults to 3.
3. **Action plans show top 3 by priority, "show more" reveals the rest.** Same pattern.
4. **What-if simulations are collapsed under "What if you fixed this?"** — they require a deliberate click, because they are speculative and shouldn't be confused with real numbers.
5. **Data quality warnings are collapsed by default** — they're transparent when needed but don't dominate the experience.
6. **Appendix-level raw data (performance_raw, edge_map_raw) lives in the Report PDF and a "raw data" expandable on Dashboard, never on consumption pages.**
7. **Charts page is its own destination.** Charts are not sprinkled across every page; they are concentrated where users expect depth.

---

## 15. Cognitive Load Reduction Strategy

Trading analytics is inherently dense. Reducing cognitive load is the single most important UX job.

### Principles

1. **One question per page.** Each page answers a single named question (see §13). No page tries to do two things.
2. **Numbers always paired with meaning.** A bare "67" is meaningless. "67/100 — Medium severity" is meaningful. Every number on every page shows its unit, its scale, and its severity label.
3. **Severity color coding is consistent across the entire app.** Low = green, Medium = amber, High = orange, Critical = red. The same color never means two things; the same severity never has two colors.
4. **No jargon without explanation.** First use of "Revenge Trading," "Profit Factor," "Max Drawdown," etc. includes an inline tooltip (Persian + English). Subsequent uses don't.
5. **Comparison anchors where they exist.** "Your discipline: 67/100. Industry typical: 70–80 for profitable traders." Anchors are only shown when the engine supports them (e.g., Profit Factor ≥ 1 is a real industry anchor; "average trader discipline" is not, and won't be invented).
6. **Charts only when they add information a table can't.** No decorative charts. Each chart on the Charts page answers a specific question that's hard to answer from numbers alone (e.g., equity curve shape, drawdown depth, hourly P&L heatmap).
7. **Long content collapsible.** Evidence lists, action plans, data quality warnings, raw data — all collapse by default, expand on demand.
8. **Action plans capped at 5 visible.** Top 5 by priority. The rest accessible via "show more." Cognitive science: humans can hold ~5 items in working memory.
9. **Empty states explain what to do next.** Never just "No data." Always "No data — here's what to do" with a CTA.
10. **Loading states show progress with stage labels.** "Validating data… Computing scores… Generating diagnosis…" — not indeterminate spinners. The user knows the system is working on something specific.
11. **Errors are actionable, never just reported.** "Invalid file" → "We couldn't find a Profit column in your file. Make sure your broker export includes profit/loss data. See supported formats →"
12. **Repeated patterns.** Every score, every evidence item, every recommendation uses the same card layout, the same severity colors, the same CTA style. Once the user learns the pattern on one page, they've learned it on all pages.

---

## 16. SaaS UX Principles to Follow Throughout the Project

These principles are the constitution for every design and implementation decision in subsequent phases.

1. **Time-to-value under 60 seconds.** From landing to diagnosis. Every extra step must justify itself.
2. **Show, don't tell.** Sample report on Home before asking for upload. Concrete over abstract.
3. **Transparent pricing (future).** No "contact sales" for lower tiers. No hidden limits.
4. **Data ownership.** Users can delete their analyses. Data never leaves without explicit consent. Export is always available.
5. **Forgiving by default.** Validation warnings don't block. Errors are actionable. No "are you sure?" guilt on delete.
6. **Premium feel.** Generous whitespace, considered typography (Fira Sans + Fira Code per design system), smooth 150–300ms transitions, no layout shift on load. Premium design signals premium product.
7. **Persian-first, RTL-native.** Not a bolted-on translation. Layouts designed RTL-first, then mirrored for LTR. Vazirmatn font for Persian text rendering (matches the existing PDF engine).
8. **Exportability.** Every result can leave the system as PDF or JSON. No lock-in.
9. **Keyboard-friendly.** Power users can navigate without a mouse. Tab order matches visual order. Visible focus states.
10. **Performance is UX.** The engine returns in ~1s even at 25k trades; the UI must feel as fast. Skeletons, not spinners. Optimistic UI where safe.
11. **Trust through explainability.** Every claim ("you have revenge trading") backed by evidence (frequency, $ impact). No assertion without proof.
12. **Honest about limits.** Engine says "no strong pattern detected" when that's the truth. The UI never manufactures a diagnosis to fill space.
13. **No dark patterns.** No guilt on cancel, no hidden unsubscribe, no pre-checked upsells.
14. **Accessibility is non-negotiable.** WCAG AA. Keyboard navigation. Screen-reader labels. `prefers-reduced-motion` respected. Touch targets ≥ 44×44pt. Contrast ≥ 4.5:1 body / 3:1 secondary.
15. **No emojis as structural icons.** Per UI/UX Pro Max skill. SVG icons only (Phosphor preferred, Heroicons fallback). The current Streamlit app's emoji nav is a known violation that the new app fixes.
16. **Token-driven theming.** Semantic color tokens per light/dark theme. No hardcoded per-screen hex values.
17. **Consistent spacing rhythm.** 4/8dp scale across component, section, and page levels.
18. **Progressive enhancement.** Core content readable without JavaScript. Interactions layer on top.

---

## 17. Page List (Final Inventory)

Every page that will exist in the application, with its purpose, tier, engine dependency, and Phase 1 status.

### Tier 0 — Public

#### 1. Home / Landing
- **Purpose:** Communicate the value proposition in 5 seconds. Show a sample report. Convert visitor → uploader.
- **Engine dependency:** None (static content + link to Sample Report).
- **Phase 1 status:** Build.

#### 2. Sample Report
- **Purpose:** Read-only, fully-rendered demo analysis (a real analysis of a synthetic dataset) so visitors can see exactly what they'll get before uploading.
- **Engine dependency:** One pre-computed analysis, rendered via the existing HTML report renderer.
- **Phase 1 status:** Build.

### Tier 1 — Entry

#### 3. Upload
- **Purpose:** Drag-drop file ingest, format auto-detection, validation feedback, LLM provider selection, run analysis with staged progress.
- **Engine dependency:** `POST /uploads`, `GET /config`, `POST /analyses`, `utils/file_loader`, `utils/validation`.
- **Phase 1 status:** Build.

#### 4. History
- **Purpose:** Paginated list of past analyses with filename, trade count, discipline score, primary diagnosis, date. Click to reopen. Delete (with confirm).
- **Engine dependency:** `GET /history?page=&page_size=`.
- **Phase 1 status:** Build (without auth, scope = session; with future auth, scope = user).

### Tier 2 — Primary consumption

#### 5. Dashboard
- **Purpose:** Post-analysis home. 5 headline cards (Discipline Score, Primary Diagnosis, Archetype, Net Profit, Revenge Risk) + performance strip + biggest-leak callout + what-if callout + quick-jump tiles + data-quality warnings (collapsible).
- **Engine dependency:** `GET /analyses/{id}/report` — `executive_summary`, `overall_score`, `diagnosis`, `trader_profile`, `performance`, `risk`, `behavior_analysis.scores`, `appendix.data_quality_warnings`.
- **Phase 1 status:** Build.

#### 6. Behavioral Analysis
- **Purpose:** Per-score breakdown of all 5 behavioral scores (revenge, overtrading, risk-taking, patience, discipline) with severity, $ impact, % of profit, event count, insight text, and what-if simulations.
- **Engine dependency:** `behavior_analysis.context_rows[]`, `behavior_analysis.detected_patterns`, `behavior_analysis.what_if`, `risk.what_if_no_revenge`.
- **Phase 1 status:** Build.

#### 7. Diagnosis
- **Purpose:** Primary + secondary diagnosis with explanatory detail and the prioritized top-8 evidence list (type, severity, frequency, $ impact, priority score, confidence).
- **Engine dependency:** `diagnosis`, `evidence[]`.
- **Phase 1 status:** Build.

#### 8. Coaching
- **Purpose:** Prioritized action plan (top 3 visible by default, "show more" for rest) + AI coaching narrative (`explainable_ai`) + reality check text.
- **Engine dependency:** `recommendations[]`, `ai_coaching.explainable_ai`, `ai_coaching.reality_check`.
- **Phase 1 status:** Build.

### Tier 3 — Deep dive

#### 9. Trader DNA
- **Purpose:** Psychological archetype profile with narrative explanation and the supporting evidence.
- **Engine dependency:** `trader_profile` (a.k.a. `psychology.dna`), `psychology.narrative`.
- **Phase 1 status:** Build.

#### 10. Edge Map
- **Purpose:** Best/worst trading hour, best/worst weekday, best/worst strategy, long-vs-short side comparison.
- **Engine dependency:** `appendix.edge_map_raw` (best_hour, worst_hour, best_weekday, worst_weekday, best_strategy, worst_strategy, side_comparison).
- **Phase 1 status:** Build.

#### 11. Charts
- **Purpose:** Visual deep-dive — equity curve, drawdown, P&L distribution, hourly heatmap, weekday breakdown, win/loss streaks. Each chart answers a specific question; no decorative charts.
- **Engine dependency:** Same report context; chart data derived from `performance`, `statistics`, and the normalized DataFrame's `Open Time`/`Profit`/`hour` columns (already computed by the engine).
- **Phase 1 status:** Build. (Chart visualizations will be implemented in the frontend using a chart library — e.g., Recharts or Chart.js — consuming the JSON report. No engine-side chart rendering for the web app; the existing `reporting/charts.py` PNG generator continues to serve the PDF/HTML report.)

#### 12. Trends
- **Purpose:** Longitudinal view of how the user's 5 behavioral scores + key performance metrics evolved across their past analyses. Requires 2+ analyses; otherwise empty state with CTA to upload more.
- **Engine dependency:** `engines/score_engine.TrendEngine` (already in V23) + `GET /history` to enumerate past analyses.
- **Phase 1 status:** Build.

### Tier 4 — Action

#### 13. Report
- **Purpose:** Generate, preview, and download the HTML and PDF reports. Shows a section-by-section preview (Executive Summary, Performance, Behavioral, Diagnosis, Coaching, Evidence, Appendix) with download buttons.
- **Engine dependency:** `GET /analyses/{id}/report.html`, `GET /analyses/{id}/report.pdf`, `GET /analyses/{id}/report` (for preview).
- **Phase 1 status:** Build.

### Tier 5 — Future-ready (Phase 1: stub or hidden)

#### 14. Settings
- **Purpose:** Account, theme, language, LLM provider default, API key (for power users).
- **Engine dependency:** None in Phase 1 (no auth). Future: user preferences stored server-side.
- **Phase 1 status:** Stub only — accessible from account menu, shows "coming soon" + theme/language toggle (which works client-side without auth).

#### 15. Mentor Workspace (future)
- **Purpose:** Multi-student view for mentors. List of students with their latest analysis, click to open. Annotation layer.
- **Engine dependency:** Future: requires multi-user auth + per-user scoping (not in V23 API today).
- **Phase 1 status:** Not built. IA reserved.

#### 16. Team Dashboard (future)
- **Purpose:** Aggregated view of multiple traders for risk managers / firm leads.
- **Engine dependency:** Future: requires multi-user auth + aggregation API (not in V23 today).
- **Phase 1 status:** Not built. IA reserved.

---

## Summary

This Phase 1 strategy transforms Trading Doctor from a Streamlit engineering tool into a premium SaaS web application **without touching the analytical engine**. Every feature is mapped 1:1 to an existing V23 capability. Every page answers a single named question. Every layer of depth is opt-in. The information architecture mirrors the engine's own output structure, so the UI's mental model matches the engine's mental model — and any future V24 engine work drops cleanly into the existing IA without restructuring the app.

**Awaiting approval before proceeding to Phase 2 (UX/Visual Design).**
