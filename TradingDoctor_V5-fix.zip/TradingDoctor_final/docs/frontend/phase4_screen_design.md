# Trading Doctor — Phase 4 Screen Design Specification

**Author:** Senior Product Designer
**Status:** For approval — gate for Phase 5 (Implementation Kickoff)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Builds on:** Phase 1 IA (approved) · Phase 2 Visual Design + UX Architecture v1.2 (approved) · Phase 3 Design System v1.1 (approved)
**Reference tier:** Linear · Stripe · Vercel · TradingView
**Document version:** v1.0

> **Phase 1 hard constraints (carried — non-negotiable):**
> 1. Mobile-first & responsive by design.
> 2. Dashboard = emotional center (4 cards above fold on 375 × 667).
> 3. Clarity > Complexity · Actionability > Information Density · Premium SaaS > Feature Quantity.
> 4. Persian-first RTL · dark-default + light-supported · engine untouched.

> **IA reconciliation note (read first):**
> Phase 1–3 approved 14 build pages + Settings stub. Phase 4 requests 20 screens. The 6 additional screens are reconciled as follows:
> - **Authentication, Profile, Subscription, Notifications** — designed as **future-ready screens** (Phase 1 §11 permission tiers). They are fully specified here so Phase 5 implementation can ship them behind a feature flag, but Phase 1 Anonymous tier ships without them. This matches Phase 2 §2.2 (Auth) and §2.11 (Subscription) which were already documented as future-ready.
> - **Overview, Performance Analysis, Risk Analysis** — designed as **dedicated deep-dive pages** that consume existing engine outputs (`performance`, `risk`, `statistics`, `appendix.performance_raw` from `data_context.py`). These do NOT invent analytics — they surface engine data already computed but previously grouped under Dashboard/Report. They sit at Tier 3 (Deep Dive) in the page hierarchy.
> - **Trade Detail** — designed as a **full-screen view** reached from Trade Explorer (in addition to the drawer/bottom-sheet pattern from Phase 2 §3.12). On mobile it's a bottom sheet; on desktop, a dedicated route `/trades/[analysisId]/[tradeId]` for deep-linking and sharing.
>
> **Net result:** 20 screens specified. 14 are Phase 1 build (matching approved IA). 6 are future-ready or enhanced deep-dives. **No engine changes. No invented analytics. No Phase 1 hard constraint violations.**

---

## Table of Contents

**Part A — Conventions**
1. Screen Design Conventions
2. IA Reconciliation & Screen Map

**Part B — Public Screens**
3. Landing Page
4. Authentication (future-ready)

**Part C — Entry & Progress Screens**
5. CSV Upload
6. Analysis Progress

**Part D — The Emotional Center**
7. Dashboard

**Part E — Analysis Deep-Dive Screens**
8. Overview
9. Performance Analysis
10. Risk Analysis
11. Behavior Analysis
12. Psychology Analysis

**Part F — Coaching & Action Screens**
13. AI Coach

**Part G — Trade Exploration Screens**
14. Trade Explorer
15. Trade Detail

**Part H — Evidence & Report Screens**
16. Evidence Explorer
17. Report Center

**Part I — Management Screens**
18. History
19. Settings
20. Profile (future-ready)
21. Subscription (future-ready)
22. Notifications (future-ready)

**Part J — Cross-Screen Patterns & Phase 5 Prep**
23. Cross-Screen Interaction Patterns
24. Phase 5 Implementation Kickoff
25. Changes Summary

---

# Part A — Conventions

---

## 1. Screen Design Conventions

Every screen in this document follows a consistent specification structure:

| Section | Content |
|---|---|
| **Purpose** | One sentence: what this screen is for. |
| **Engine dependency** | Which V23 API endpoint / data_context fields this screen consumes. |
| **Phase status** | Phase 1 build / future-ready / enhanced deep-dive. |
| **Layout** | Mobile (375px) → Tablet (768px) → Desktop (≥1024px) structure. |
| **Visual Hierarchy** | What the user sees first, second, third. |
| **Component Placement** | Detailed placement of every component. |
| **Cards** | Card types used, their content, and arrangement. |
| **Tables** | Table structure if applicable. |
| **Charts** | Chart types if applicable. |
| **Interactions** | All interactive elements and their behavior. |
| **Hover States** | Desktop hover behaviors. |
| **Responsive Behavior** | How the layout adapts across breakpoints. |
| **Micro-interactions** | Small animations and feedback (durations, easings per Phase 3 §14). |
| **States** | Loading / Empty / Error / Success states. |
| **Accessibility** | ARIA, keyboard, screen reader specifics. |

### Design tokens applied throughout

All screens consume the Phase 3 Design System v1.1 token manifest:
- **Colors:** `--bg-base`, `--bg-elevated`, `--bg-surface`, `--fg-primary`, `--fg-secondary`, `--fg-muted`, `--accent-primary`, `--accent-cta`, `--severity-*`, `--profit-*` (Phase 3 §4–§5).
- **Typography:** `--text-h1` through `--text-caption`, `--text-data-*` for mono numerics (Phase 3 §6).
- **Spacing:** `--space-1` through `--space-24` on 4/8dp rhythm (Phase 3 §8).
- **Radius:** `--radius-sm` (4px) for badges, `--radius-md` (8px) for buttons/inputs, `--radius-lg` (12px) mobile cards, `--radius-xl` (16px) desktop cards (Phase 3 §9).
- **Elevation:** `--elevation-0` through `--elevation-5` (Phase 3 §10).
- **Motion:** `--duration-fast` (100ms), `--duration-normal` (200ms), `--duration-moderate` (300ms), `--ease-out` (Expo.out) for entrances (Phase 3 §14).
- **Icons:** Phosphor Icons, `--icon-sm` (20px) for inline, `--icon-md` (24px) for nav, `--icon-lg` (32px) for sections (Phase 3 §11). **No emojis as structural icons.**

### Premium SaaS quality bar

Every screen must feel like Linear / Stripe / Vercel / TradingView. That means:
- **Generous whitespace** — never crowd. If a screen feels dense, it's wrong.
- **Restrained color** — neutral base + 2 accents (blue + amber). Severity colors only where severity exists.
- **Mono numerics** — every number in `--font-mono` for scannability and column alignment.
- **Subtle motion** — 150–300ms micro-interactions, Expo.out, never decorative.
- **Honest states** — skeletons match final shapes; errors are actionable; empty states guide forward.
- **Token-driven** — zero hardcoded values. Every color, space, radius from tokens.

---

## 2. IA Reconciliation & Screen Map

### 2.1 Screen-to-IA mapping

| # | Screen (Phase 4) | Maps to (Phase 1–3) | Tier | Phase status | Route |
|---|---|---|---|---|---|
| 1 | Landing Page | Home / Landing | Public | Phase 1 build | `/` |
| 2 | Authentication | Auth Flow (Phase 2 §2.2) | Public (future) | Future-ready | `/signin`, `/signup` |
| 3 | Dashboard | Dashboard (emotional center) | Primary | Phase 1 build | `/dashboard/[id]` |
| 4 | CSV Upload | Upload | Entry | Phase 1 build | `/upload` |
| 5 | Analysis Progress | Analysis Progress | Entry | Phase 1 build | `/upload` (in-flow) |
| 6 | Overview | NEW — comprehensive metrics view | Deep dive | Enhanced deep-dive | `/overview/[id]` |
| 7 | Performance Analysis | NEW — performance deep-dive | Deep dive | Enhanced deep-dive | `/performance/[id]` |
| 8 | Risk Analysis | NEW — risk deep-dive | Deep dive | Enhanced deep-dive | `/risk/[id]` |
| 9 | Behavior Analysis | Behavioral Analysis | Primary | Phase 1 build | `/behavioral/[id]` |
| 10 | Psychology Analysis | Trader DNA | Deep dive | Phase 1 build | `/trader-dna/[id]` |
| 11 | AI Coach | Coaching | Primary | Phase 1 build | `/coaching/[id]` |
| 12 | Trade Explorer | Trade Explorer | Deep dive | Phase 1 build | `/trades/[id]` |
| 13 | Trade Detail | NEW — full-screen trade view | Deep dive | Enhanced deep-dive | `/trades/[id]/[tradeId]` |
| 14 | Evidence Explorer | Diagnosis | Primary | Phase 1 build | `/diagnosis/[id]` |
| 15 | Report Center | Report | Action | Phase 1 build | `/report/[id]` |
| 16 | History | History | Entry | Phase 1 build | `/history` |
| 17 | Settings | Settings | Future | Phase 1 stub | `/settings` |
| 18 | Profile | NEW — user profile | Future | Future-ready | `/settings/profile` |
| 19 | Subscription | Subscription (Phase 2 §2.11) | Future | Future-ready | `/settings/subscription` |
| 20 | Notifications | NEW — notification center | Future | Future-ready | `/notifications` |

### 2.2 Engine dependency summary

| Screen | API endpoint | data_context fields consumed |
|---|---|---|
| Dashboard | `GET /analyses/{id}/report` | `executive_summary`, `overall_score`, `diagnosis`, `trader_profile`, `performance`, `risk`, `behavior_analysis.scores`, `appendix.data_quality_warnings` |
| Overview | `GET /analyses/{id}/report` | `performance`, `statistics`, `behavior_analysis.scores`, `appendix.performance_raw` |
| Performance Analysis | `GET /analyses/{id}/report` | `performance`, `statistics`, `appendix.performance_raw` |
| Risk Analysis | `GET /analyses/{id}/report` | `risk`, `behavior_analysis.scores`, `behavior_analysis.what_if`, `behavior_analysis.context_rows` (revenge, risk_taking) |
| Behavior Analysis | `GET /analyses/{id}/report` | `behavior_analysis` (scores, context_rows, detected_patterns, what_if) |
| Psychology Analysis | `GET /analyses/{id}/report` | `trader_profile`, `psychology` (dna, narrative), `evidence` |
| AI Coach | `GET /analyses/{id}/report` | `recommendations`, `ai_coaching` (explainable_ai, reality_check) |
| Trade Explorer | `GET /analyses/{id}/trades` (NEW endpoint, Phase 2 §5.1) | `record.doctor.df` serialized |
| Trade Detail | `GET /analyses/{id}/trades?trade_id={id}` | Single trade row |
| Evidence Explorer | `GET /analyses/{id}/report` | `diagnosis`, `evidence` |
| Report Center | `GET /analyses/{id}/report`, `/report.html`, `/report.pdf` | Full context |
| History | `GET /history?page=&page_size=` | History items |

**No screen computes scores, thresholds, or diagnoses client-side. Every number comes from the engine.**

---

# Part B — Public Screens

---

## 3. Landing Page

### Purpose
Communicate Trading Doctor's value proposition in 5 seconds. Convert visitors into uploaders.

### Engine dependency
None (static page). Links to `/upload` and `/sample`.

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [Logo]              [⌘K] [☀] [فا/EN] │ ← transparent top bar, 56px
├─────────────────────────────────────┤
│                                      │
│        [Hero illustration 240px]     │
│                                      │
│   معامله‌گر بهتر شو،                  │ ← --text-hero 32px
│   نه فقط سود more                    │
│                                      │
│   تحلیل رفتاری معاملات شما            │ ← --text-body 16px
│   با شواهد و دلار.                    │
│                                      │
│   [▶ تحلیل معاملاتم را شروع کن]       │ ← primary CTA, amber, full-width
│   [  گزارش نمونه ببین  ]              │ ← secondary, ghost
│                                      │
├─────────────────────────────────────┤
│   [✓ ۲۲ تست پاس شده]                 │ ← trust strip
│   [✓ بدون نیاز به ثبت‌نام]            │
│   [✓ خروجی PDF حرفه‌ای]               │
├─────────────────────────────────────┤
│   چطور کار می‌کند                     │ ← --text-h2 20px
│   ┌─────────────────────────────┐   │
│   │ [⬆] ۱. آپلود فایل            │   │ ← HowItWorks card
│   │    هر فرمت بروکر              │   │
│   └─────────────────────────────┘   │
│   ┌─────────────────────────────┐   │
│   │ [⚙] ۲. تحلیل رفتاری          │   │
│   │    ۵ امتیاز + شواهد           │   │
│   └─────────────────────────────┘   │
│   ┌─────────────────────────────┐   │
│   │ [→] ۳. برنامه‌ی اقدام         │   │
│   │    قابل دانلود PDF            │   │
│   └─────────────────────────────┘   │
├─────────────────────────────────────┤
│   [▶ تحلیل معاملاتم را شروع کن]       │ ← final CTA
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [Logo] Trading Doctor                              [⌘K] [☀] [فا/EN] [Sign in] │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│   ┌──────────────────────────────┐  ┌────────────────────────────────┐    │
│   │                              │  │                                  │    │
│   │  معامله‌گر بهتر شو،            │  │   [Hero illustration 240×240]   │    │
│   │  نه فقط سود more              │  │   candlesticks → waveform        │    │
│   │                              │  │                                  │    │
│   │  تحلیل رفتاری معاملات شما      │  └────────────────────────────────┘    │
│   │  با شواهد و دلار.              │                                        │
│   │                              │                                        │
│   │  [▶ تحلیل معاملاتم را شروع کن] │                                        │
│   │  [  گزارش نمونه ببین  ]        │                                        │
│   │                              │                                        │
│   └──────────────────────────────┘                                        │
│                                                                            │
│   [✓ ۲۲ تست پاس شده] [✓ بدون ثبت‌نام] [✓ PDF حرفه‌ای] [✓ RTL-native]      │
│                                                                            │
│   چطور کار می‌کند                                                          │
│   ┌────────────┐  ┌────────────┐  ┌────────────┐                          │
│   │ [⬆]        │  │ [⚙]        │  │ [→]        │                          │
│   │ آپلود      │  │ تحلیل      │  │ اقدام      │                          │
│   │ هر فرمت    │  │ ۵ امتیاز   │  │ PDF        │                          │
│   └────────────┘  └────────────┘  └────────────┘                          │
│                                                                            │
│   ┌────────────────────────────────────────────────────────────────────┐  │
│   │ [Sample report preview]           [See full report →]               │  │
│   └────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│   [▶ تحلیل معاملاتم را شروع کن]                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Hero headline** (`--text-hero`, `--fg-primary`) — first thing the eye lands on.
2. **Hero CTA** (amber `--accent-cta`) — the one action we want.
3. **Trust strip** (badges, `--fg-secondary`) — reduces friction.
4. **HowItWorks** (3 cards) — explains the flow.
5. **Sample preview** (desktop only) — shows the destination.
6. **Final CTA** — repeat the primary action.

### Component Placement
- **Top bar:** Logo (32px mark + wordmark) at start (RTL: right). Theme toggle + language toggle + Command Palette hint at end (RTL: left). Transparent over hero, solid (`--bg-elevated`, `--elevation-1`) after scroll.
- **Hero:** Centered on mobile, 2-column on desktop (text left, illustration right in LTR; reversed in RTL).
- **CTAs:** Stacked full-width on mobile, inline on desktop.
- **Trust strip:** Horizontal row, wraps on mobile.
- **HowItWorks:** Vertical stack on mobile, 3-column grid on desktop.

### Cards
- **HowItWorks cards** (×3): `--bg-elevated`, `--elevation-2`, `--radius-lg` (mobile) / `--radius-xl` (desktop), `--space-6` padding. Each: Phosphor icon (`--icon-lg`) in `--accent-primary` circle, title (`--text-h3`), one-line description (`--text-body-sm`, `--fg-secondary`).
- **Sample preview card** (desktop only): `--bg-elevated`, `--elevation-2`, `--radius-xl`, contains a screenshot/thumbnail of the Dashboard + "See full report →" link.

### Tables
None.

### Charts
None (static page).

### Interactions
- **Primary CTA click** → navigate to `/upload` (200ms page transition).
- **Secondary CTA click** → navigate to `/sample`.
- **Top bar appears on scroll** (after 80px scroll, 200ms fade-in).
- **Smooth scroll** between sections (400ms, `--ease-in-out`, instant if reduced-motion).
- **Sign in link** (desktop, future-ready) → `/signin`.

### Hover States
- **Primary CTA:** bg `--accent-cta` → `--accent-cta-hover`, slight scale 1.02, 200ms `--ease-out`.
- **Secondary CTA:** text `--fg-secondary` → `--accent-primary`, underline appears, 200ms.
- **HowItWorks cards:** No hover (non-interactive). Optional: subtle `--elevation-2` → `--elevation-3` lift on desktop, 200ms.
- **Sample preview link:** text → `--accent-primary`, arrow slides right 4px, 200ms.
- **Sign in link:** text → `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, full-width CTAs, vertical HowItWorks, no sample preview |
| `sm` to `< md` (640–767px) | Same as mobile, slightly larger hero |
| `md` to `< lg` (768–1023px) | 2-column hero, 3-column HowItWorks, sample preview appears |
| `≥ lg` (1024px+) | Full desktop layout, max-width 1536px (`--container-wide`), centered |

### Micro-interactions
- **Hero entrance:** headline fades up (400ms, `--ease-out`, stagger 100ms between headline, subhead, CTAs). Frozen if reduced-motion.
- **Hero illustration:** subtle float animation (translateY 0 → -8px → 0, 4s infinite, `--ease-in-out`). Frozen if reduced-motion.
- **Trust badges:** staggered fade-in (100ms per badge) after hero.
- **HowItWorks cards:** staggered fade-up (100ms per card) on scroll into view.
- **CTA press:** scale 0.97, 100ms.
- **Ambient background (desktop):** 2–3 blurred accent blobs (`--accent-primary` at 8% opacity, blur 80px), slowly oscillating (20s, infinite). Frozen if reduced-motion.

### States
- **Loading:** N/A (static page). Skeleton of hero text during JS hydration (prevents blank flash).
- **Empty:** N/A.
- **Error:** If sample preview image fails → hide preview, show text-only description.
- **Success:** User clicks CTA → navigates to `/upload`.

### Accessibility
- H1 = hero headline (one per page).
- All CTAs are `<button>` or `<a>` with descriptive `aria-label`.
- Color contrast ≥ 4.5:1 (verified Phase 3 §5.5).
- Skip-to-content link at top.
- Smooth scroll → instant jump if reduced-motion.
- Hero illustration: `aria-hidden="true"` (decorative).
- Trust badges: `<ul>` with `<li>` for semantic list.

---

## 4. Authentication (future-ready)

### Purpose
Let users sign up / sign in to access Registered/Pro/Mentor/Enterprise tiers. Phase 1 ships Anonymous-only; this screen is fully specified for feature-flag activation.

### Engine dependency
Future: `POST /api/v1/auth/signup`, `POST /api/v1/auth/signin` (not in V23 API today; additive future endpoints).

### Phase status
Future-ready.

### Layout

**Mobile (375px) — Sign In:**
```
┌─────────────────────────────────────┐
│ [← بازگشت به خانه]                    │ ← back link, 56px top bar
├─────────────────────────────────────┤
│                                      │
│         [Logo 48px]                  │
│      Trading Doctor                  │ ← --text-h2
│                                      │
│   ورود به حساب                        │ ← --text-h3
│                                      │
│   ┌─────────────────────────────┐   │
│   │ ایمیل                        │   │ ← TextField
│   │ you@example.com              │   │
│   └─────────────────────────────┘   │
│   ┌─────────────────────────────┐   │
│   │ رمز عبور              [👁]   │   │ ← TextField password + show/hide
│   │ ••••••••                     │   │
│   └─────────────────────────────┘   │
│                                      │
│           رمز عبور را فراموش کرده‌اید؟  │ ← link, right-aligned
│                                      │
│   [▶ ورود]                           │ ← primary CTA, full-width
│                                      │
│   ─────── یا ───────                 │ ← divider
│                                      │
│   [G  ادامه با گوگل]                  │ ← OAuth button
│   [  ادامه با گیت‌هاب]                │ ← OAuth button
│                                      │
│   حساب ندارید؟ ثبت‌نام کنید            │ ← link to /signup
│                                      │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column split:
- **Left (50%):** Brand panel — `--bg-base` with ambient accent blobs, Logo + tagline + 3 feature bullets.
- **Right (50%):** Auth form — `--bg-elevated`, centered, max-width 480px.

### Visual Hierarchy
1. **Logo + brand name** — orient the user.
2. **Form heading** ("ورود به حساب" / "Sign in").
3. **Form fields** — email, password.
4. **Primary CTA** ("ورود").
5. **OAuth alternatives** — for users who prefer Google/GitHub.
6. **Switch link** — "حساب ندارید؟ ثبت‌نام کنید".

### Component Placement
- **Back link:** Top-start, `--text-caption`, `--fg-secondary`.
- **Logo + brand:** Centered, `--space-12` from top.
- **Form:** Centered, max-width 480px on desktop, full-width on mobile.
- **Fields:** Stacked, `--space-4` gap.
- **Forgot password link:** Right-aligned (RTL: left-aligned), `--text-caption`, below password field.
- **Primary CTA:** Full-width, `--space-4` below fields.
- **Divider:** "یا" (or) centered, horizontal line `--border-subtle`.
- **OAuth buttons:** Stacked, full-width, `--accent-primary` outline.
- **Switch link:** Centered, bottom of form.

### Cards
- **Brand panel (desktop only):** Full-height left column, `--bg-base`, contains Logo (48px), tagline (`--text-h2`), 3 feature bullets (Phosphor check icon + text). Ambient background blobs.
- **Form card (desktop):** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-8` padding, max-width 480px, centered vertically.

### Tables
None.

### Charts
None.

### Interactions
- **Email field:** validate on blur (email format). If invalid → inline error `--severity-critical` border + message.
- **Password field:** show/hide toggle (eye icon). Validate on blur (≥8 chars).
- **Sign in click:** button enters loading state (spinner + «در حال ورود...»). POST to `/api/v1/auth/signin`. On success → session cookie, redirect to `/dashboard` or return-to URL. On error → inline error "ایمیل یا رمز عبور نادرست است" (deliberately generic).
- **Forgot password click** → navigate to `/forgot-password`.
- **OAuth click** → redirect to OAuth provider. On return → session created, redirect to Dashboard.
- **Switch link click** → navigate to `/signup`.
- **Back link click** → navigate to `/`.

### Hover States
- **Back link:** `--fg-secondary` → `--accent-primary`, 200ms.
- **Forgot password link:** `--fg-secondary` → `--accent-primary`, underline, 200ms.
- **Primary CTA:** `--accent-cta` → `--accent-cta-hover`, scale 1.02, 200ms.
- **OAuth buttons:** border `--border-strong` → `--accent-primary`, bg `--bg-elevated` → `--bg-hover`, 200ms.
- **Switch link:** `--fg-secondary` → `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, no brand panel, full-width form |
| `sm` to `< md` | Same as mobile, max-width 480px centered |
| `≥ md` (768px+) | 2-column split: brand panel (50%) + form (50%) |

### Micro-interactions
- **Logo fade-in:** 300ms `--ease-out` on mount.
- **Form fields staggered fade-up:** 100ms per field, 300ms total.
- **Password show/hide:** icon cross-fade (eye → eye-slash), 150ms.
- **Button press:** scale 0.97, 100ms.
- **Error shake:** on failed sign-in, form card shakes horizontally (translateX 0 → -8 → 8 → -4 → 0, 300ms). Frozen if reduced-motion.
- **Success → redirect:** 200ms fade-out before navigation.

### States
- **Loading (submit):** Button spinner + «در حال ورود...», all fields disabled.
- **Empty (no input):** CTA disabled.
- **Error (invalid email):** Inline error below email field, `--severity-critical` border.
- **Error (wrong credentials):** Inline error at top of form, form shake.
- **Error (OAuth fail):** Toast «ورود با گوگل ناموفق بود — لطفاً با ایمیل وارد شوید».
- **Error (rate limited):** «تلاش‌های زیادی. X ثانیه دیگر تلاش کنید.» + countdown.
- **Success:** Session created, toast «خوش آمدید», redirect to Dashboard.

### Accessibility
- All fields have `<label>` (visible).
- Password field: `aria-describedby` linking to requirements hint.
- Error messages: `aria-live="polite"`, `aria-invalid="true"` on field.
- OAuth buttons: `aria-label="ورود با گوگل"`.
- Focus trap inside form. First field autofocus.
- Keyboard: Tab through fields, Enter submits.

---

# Part C — Entry & Progress Screens

---

## 5. CSV Upload

### Purpose
Ingest a trade history file, validate it, prepare for analysis.

### Engine dependency
`POST /api/v1/uploads` (multipart), `GET /api/v1/config` (allowed formats, max size, LLM providers).

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  آپلود              [☀] [فا/EN]  │ ← top bar, 56px
├─────────────────────────────────────┤
│  آپلود فایل معاملات                  │ ← --text-h1 24px
│  هر فرمت بروکر را آپلود کنید          │ ← --text-body-sm, --fg-secondary
│                                      │
│  ┌─────────────────────────────┐    │
│  │                              │    │
│  │       [⬆ icon 48px]          │    │ ← UploadDropzone, dashed border
│  │                              │    │   200px tall
│  │  برای انتخاب فایل ضربه بزنید  │    │
│  │                              │    │
│  │  CSV · XLSX · HTM · JSON     │    │
│  │  حداکثر ۲۵ مگابایت            │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← FilePill (after file selected)
│  │ [📄] trades_jan.csv  2.3MB [✕] │    │
│  └─────────────────────────────┘    │
│                                      │
│  ارائه‌دهنده‌ی هوش مصنوعی              │ ← --text-caption
│  [بدون هوش مصنوعی] [Gemini] [OpenAI] │ ← SegmentedControl, horizontal scroll
│                                      │
│  ℹ هوش مصنوعی فقط روایت coaching     │ ← info text, --fg-muted
│    را غنی‌تر می‌کند.                   │
│                                      │
│  [▶ شروع تحلیل]                      │ ← primary CTA, full-width (disabled until file)
│                                      │
│  [مشاهده فرمت‌های پشتیبانی‌شده]        │ ← ghost link
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column layout:
- **Left (60%):** Dropzone + FilePill + LLM selector + CTA.
- **Right (40%):** "What happens next" explainer card + sample CSV format preview.

### Visual Hierarchy
1. **Page title** — orient the user.
2. **Dropzone** — the primary interaction target.
3. **FilePill** (after selection) — confirmation.
4. **LLM selector** — optional configuration.
5. **Primary CTA** — the action.
6. **Help link** — secondary.

### Component Placement
- **Top bar:** Hamburger (mobile) / Sidebar (desktop) + page title + theme + language.
- **Page header:** `--space-6` below top bar.
- **Dropzone:** Full-width (mobile) / 60% width (desktop), `--space-6` below header.
- **FilePill:** `--space-4` below dropzone (only after file selected).
- **LLM selector:** `--space-6` below FilePill.
- **Info text:** `--space-2` below selector.
- **CTA:** `--space-6` below info, full-width (mobile) / 60% width (desktop).
- **Help link:** `--space-3` below CTA, centered.

### Cards
- **UploadDropzone:** Dashed border (`--border-strong`, 2px dashed), `--bg-surface`, `--radius-lg`, 200px tall (mobile) / 240px (desktop). Centered content: upload icon (`--icon-lg`, `--fg-secondary`), instruction text, format hints.
- **FilePill:** `--bg-elevated`, `--elevation-2`, `--radius-md`, `--space-3` padding. Contains: file icon, filename (truncated, `--text-body-sm`), size (`--text-caption`, `--fg-muted`), remove button (X icon).
- **Explainer card (desktop):** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Contains: "What happens next" heading, 3-step list (Upload → Analyze → View Dashboard), sample CSV format preview (mono text in `--bg-surface` block).

### Tables
None.

### Charts
None.

### Interactions
- **Dropzone click** → native file picker opens.
- **Dropzone drag-over (desktop)** → border becomes solid `--accent-cta`, bg tints `--accent-cta` at 8% opacity, 150ms.
- **File selected** → client-side validation (size ≤ 25MB, extension in allow-list). If valid → FilePill appears, CTA enables. If invalid → inline error.
- **FilePill remove (X)** → file deselected, FilePill disappears, CTA disables.
- **LLM selector change** → update state, tooltip on each option explains tradeoff.
- **CTA click** → button loading state, `POST /uploads`, FilePill shows progress bar. On success → transition to Analysis Progress.
- **Help link click** → modal opens with supported formats table.

### Hover States
- **Dropzone (desktop):** border `--border-strong` → `--accent-primary`, bg `--bg-surface` → `--bg-hover`, 200ms.
- **FilePill remove:** X icon `--fg-muted` → `--severity-critical`, 200ms.
- **LLM options:** `--bg-surface` → `--bg-hover`, border appears, 200ms.
- **CTA:** `--accent-cta` → `--accent-cta-hover`, scale 1.02, 200ms.
- **Help link:** `--fg-secondary` → `--accent-primary`, underline, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, full-width dropzone, horizontal-scroll LLM selector |
| `sm` to `< md` | Same as mobile, wider dropzone |
| `≥ md` (768px+) | 2-column: dropzone+form (60%) + explainer (40%) |

### Micro-interactions
- **Dropzone entrance:** fade-up 300ms `--ease-out`.
- **FilePill entrance:** slide-down + fade, 200ms.
- **FilePill exit:** slide-up + fade, 150ms.
- **CTA enable (when file selected):** disabled grey → amber, scale 0.98 → 1, 200ms.
- **Upload progress:** FilePill progress bar fills 0 → 100%, 200ms `--ease-out`.
- **Drag-over (desktop):** border dash → solid, bg tint, 150ms.
- **First-time tooltip:** on first visit, points to dropzone: «فایل خروجی بروکر خود را اینجا بکشید». Dismissable.

### States
- **Empty (initial):** Dropzone + disabled CTA.
- **File selected (valid):** FilePill + enabled CTA.
- **File invalid (size):** Inline error «حجم فایل ۳۲ مگابایت است؛ حداکثر مجاز ۲۵ مگابایت».
- **File invalid (format):** Inline error «فرمت .zip پشتیبانی نمی‌شود».
- **Uploading:** CTA spinner + «در حال آپلود...», FilePill progress bar.
- **Upload error (413):** Inline error (shouldn't happen, client-side check).
- **Upload error (422):** Engine message inline + «فرمت‌های پشتیبانی‌شده» link.
- **Upload error (network):** «اتصال برقرار نشد» + retry.
- **Success:** Automatic transition to Analysis Progress (no toast — the transition is the feedback).

### Accessibility
- Dropzone: `tabindex="0"`, `role="button"`, `aria-label="آپلود فایل معاملات"`. Enter/Space triggers file picker.
- LLM selector: `radiogroup` + `radio` semantics, `aria-checked`.
- FilePill remove: `aria-label="حذف فایل"`.
- Error messages: `aria-live="polite"`, `aria-describedby` on dropzone.
- CTA: `aria-busy="true"` when uploading.

---

## 6. Analysis Progress

### Purpose
Communicate analysis is running. Set honest, LLM-aware expectations. Transition to Dashboard.

### Engine dependency
`POST /api/v1/analyses` with `{upload_id, llm_provider}` (synchronous, blocks until done).

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [Logo]                    [✕ انصراف]  │ ← top bar, 56px
├─────────────────────────────────────┤
│                                      │
│       [⚙ icon 48px, rotating]        │ ← animated indicator
│                                      │
│   در حال تحلیل معاملات شما            │ ← --text-h1 24px
│   trades_jan.csv · ۱٬۲۴۵ معامله       │ ← --text-body-sm, --fg-secondary
│                                      │
│   ┌─────────────────────────────┐   │
│   │ ۱. خواندن و نرمال‌سازی فایل  •  │   │ ← StageList, vertical
│   │ ۲. اعتبارسنجی داده           •  │   │   pulsing dots
│   │ ۳. تحلیل رفتار               •  │   │
│   │ ۴. محاسبه‌ی امتیازها         •  │   │
│   │ ۵. تشخیص مشکل اصلی           •  │   │
│   │ ۶. ساخت برنامه‌ی اقدام       •  │   │
│   └─────────────────────────────┘   │
│                                      │
│   ████████████████████████░░░░░░     │ ← indeterminate progress bar
│                                      │
│   معمولاً کمتر از ۱۰ ثانیه طول می‌کشد  │ ← smart estimate (LLM-aware)
│   ۰:۰۳ گذشته                         │ ← elapsed counter, mono
│                                      │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
Same content, centered, max-width 640px. Stages in horizontal row with connector line.

### Visual Hierarchy
1. **Animated indicator** (rotating gear or pulsing logo) — confirms something is happening.
2. **Page title + subtitle** — what's being analyzed.
3. **Stage list** — what the engine is doing (conceptual).
4. **Progress bar** — indeterminate, conveys "working."
5. **Time estimate + elapsed** — sets expectations.

### Component Placement
- **Top bar:** Logo at start, Cancel button at end.
- **Indicator:** Centered, `--space-12` from top.
- **Title + subtitle:** Centered, `--space-6` below indicator.
- **Stage list:** Centered, max-width 480px, `--space-8` below title. Vertical on mobile, horizontal on desktop.
- **Progress bar:** Full-width (mobile) / max-width 480px (desktop), `--space-6` below stages.
- **Estimate + elapsed:** Centered, `--space-4` below progress bar.

### Cards
- **StageList card:** `--bg-elevated`, `--elevation-2`, `--radius-lg`/`--radius-xl`, `--space-6` padding. Contains 6 stages, each with: number circle, stage name, pulsing dot.

### Tables
None.

### Charts
None.

### Interactions
- **Cancel click** → confirmation modal «انصراف از تحلیل؟». On confirm → return to Upload with file preserved.
- **On mount** → fire `POST /analyses`. Start elapsed counter.
- **On `201` response** → staggered checkmark animation (60ms per stage), progress bar fills to 100%, toast «تحلیل کامل شد», 800ms delay, navigate to Dashboard.
- **On elapsed > estimate** → soft reassurance appears: «کمی بیشتر از حد انتظار طول می‌کشد — هنوز در حال تحلیل است».

### Hover States
- **Cancel button:** `--fg-secondary` → `--severity-critical`, 200ms.
- **Stages:** No hover (non-interactive). Optional: tooltip on hover (desktop) explaining each stage.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Vertical stage list, full-width progress bar |
| `sm` to `< md` | Same as mobile |
| `≥ md` (768px+) | Horizontal stage list with connector line, max-width 640px centered |

### Micro-interactions
- **Indicator:** continuous rotation (8s linear infinite) or pulse (opacity 0.5 → 1 → 0.5, 1.5s). Frozen if reduced-motion → static icon.
- **Stage dots:** subtle pulse (opacity 0.6 → 1 → 0.6, 2s, staggered). Frozen if reduced-motion → static dots.
- **Progress bar:** indeterminate animated stripe (translateX -100% → 100%, 1.5s linear infinite). Frozen if reduced-motion → static 50% bar.
- **Elapsed counter:** updates every second, mono font.
- **Success transition:** all stage dots flip to green checkmarks (✓) in staggered 60ms sequence, progress bar fills 0 → 100% in 400ms, toast slides in, 800ms delay, fade-out, navigate.
- **Page entrance:** fade-in 200ms.

### States
- **Running (default):** Pulsing dots, indeterminate bar, elapsed counting.
- **Soft reassurance (elapsed > estimate):** Additional line below estimate.
- **Success:** All checkmarks, full bar, toast.
- **Error (422):** Error card «داده‌ی فایل معتبر نیست: {engine message}» + «بازگشت به آپلود».
- **Error (500):** «خطای داخلی سرور» + retry.
- **Error (timeout 60s/90s):** «تحلیل بیش از حد طول کشید» + retry.
- **Error (429):** «تعداد درخواست‌ها بیش از حد» + countdown + auto-retry.

### Accessibility
- Stage list: `<ol>` with `aria-label="مراحل تحلیل"`.
- Progress bar: `role="progressbar"`, `aria-valuetext="در حال تحلیل"`.
- Elapsed counter: `aria-live="off"` (don't announce every second).
- Estimate: `aria-live="polite"` (announced once).
- Soft reassurance: `aria-live="polite"`.
- Error card: `aria-live="assertive"`.
- Cancel: `aria-label="انصراف از تحلیل"`.

---

# Part D — The Emotional Center

---

## 7. Dashboard

### Purpose
The post-analysis home. Deliver the 4 emotional answers in 5 seconds. Provide drill-down paths. **This is the emotional center of the product — the single most important screen.**

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `executive_summary`, `overall_score`, `diagnosis`, `trader_profile`, `performance`, `risk`, `behavior_analysis.scores`, `appendix.data_quality_warnings`, `evidence`, `recommendations`.

### Phase status
Phase 1 build. **Highest priority screen (Phase 3 §40.6).**

### Layout

**Mobile (375 × 667) — CRITICAL: 4 cards above fold:**
```
┌─────────────────────────────────────┐ ← 56px top bar
│ [☰] [📊 analysis badge]   [⌘K][☀][فا] │
├─────────────────────────────────────┤ ← fold target: 594px from top
│  ┌─────────────────────────────┐    │
│  │ ۱. وضعیت کلی (Overall Health)│    │ ← 140px card
│  │                              │    │
│  │       ۶۷ / ۱۰۰               │    │ ← ScoreGauge, 96px numeral, mono
│  │   ━━━━━━━━━━━━━━━━━━━━━     │    │   severity arc
│  │   انضباط: متوسط               │    │ ← severity word
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← 16px gap
│  │ ۲. بزرگ‌ترین نقطه‌ضعف          │    │ ← 120px card
│  │ [⚠] معامله‌ی انتقامی (Revenge)│    │   severity-colored border
│  │ ۱٬۸۴۰ دلار ضرر · شدت: بالا    │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← 16px gap
│  │ ۳. بزرگ‌ترین نقطه‌قوت          │    │ ← 120px card
│  │ [✓] بهترین ساعت: ۱۴:۰۰        │    │   green border
│  │ میانگین سود: ۱۲ دلار/معامله   │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← 16px gap
│  │ ۴. گام بعدی                   │    │ ← 110px card
│  │ بعد از هر باخت، ۳۰ دقیقه      │    │   amber accent
│  │ استراحت کن.                   │    │
│  │ [مشاهده برنامه‌ی کامل →]       │    │
│  └─────────────────────────────┘    │
├─────────────────────────────────────┤ ← FOLD (73px buffer to 667px)
│  ─────── Performance Strip ───────  │
│  [Win Rate] [PF] [MaxDD] [Trades]   │ ← 2×3 grid, 6 StatCards
│  [Avg Win]  [Avg Loss]              │
│  ─────── Quick Jumps ───────────    │
│  ┌────────┐ ┌────────┐              │ ← 2×2 grid
│  │Behavior│ │Diagnose│              │
│  └────────┘ └────────┘              │
│  ┌────────┐ ┌────────┐              │
│  │Coaching│ │EdgeMap │              │
│  └────────┘ └────────┘              │
│  ─── Data Quality Warnings ───     │ ← collapsible, only if warnings
│  [⚠ ۳ هشدار کیفیت داده ▾]            │
├─────────────────────────────────────┤
│ [📊][📉][🔍][💡][📄]                │ ← 64px bottom tab bar + safe area
└─────────────────────────────────────┘
```

**Tablet (768–1023px):**
```
┌──────────────────────────────────────────────────────┐
│ [Logo] [📊 analysis badge]        [⌘K][☀][فا][👤]      │
├──────────────────────────────────────────────────────┤
│  ┌──────────────────────────┐  ┌──────────────────┐  │
│  │ ۱. Overall Health         │  │ ۳. Biggest        │  │
│  │    [gauge 96px]           │  │    Strength       │  │
│  │    ۶۷/۱۰۰ · متوسط          │  │    [✓] best 14:00 │  │
│  ├──────────────────────────┤  ├──────────────────┤  │
│  │ ۲. Biggest Leak           │  │ ۴. Next Action    │  │
│  │    [⚠] Revenge $1,840     │  │    [→] rest 30min │  │
│  └──────────────────────────┘  └──────────────────┘  │
│  ─────── Performance Strip (3×2) ───────             │
│  ...                                                   │
└──────────────────────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [Logo] Trading Doctor  [📊 trades_jan.csv · 1,245 trades · 2024-01-15]  │
│                                          [⌘K] [☀] [فا] [👤] [📄 Report]  │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐                  │
│  │ ۱.Overall │  │ ۲.Biggest│  │ ۳.Biggest│  │ ۴.Next   │                  │
│  │  Health   │  │  Leak    │  │  Strength│  │  Action  │                  │
│  │ [gauge]   │  │ [⚠][$$]  │  │ [✓][stat]│  │ [→][CTA] │                  │
│  │ ۶۷/۱۰۰    │  │ Revenge  │  │ Best 14:00│  │ Rest 30m │                  │
│  │ متوسط     │  │ $1,840   │  │ +$12/tr  │  │ → Coach  │                  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘                  │
│                                                                          │
│  ─────── Performance Strip (1×6) ───────                                 │
│  [Win 52%] [PF 1.3] [MaxDD -$890] [Trades 1,245] [AvgWin +$24] [AvgLoss -$18] │
│                                                                          │
│  ┌─────────────────────────────┐  ┌─────────────────────────────┐        │
│  │ Biggest Leak Drill-down      │  │ What-If Simulation           │        │
│  │ Revenge trading after 2+     │  │ If you fixed revenge,        │        │
│  │ losses, increasing size...   │  │ you'd have made +$1,840      │        │
│  │ [See evidence →]             │  │ [See details →]              │        │
│  └─────────────────────────────┘  └─────────────────────────────┘        │
│                                                                          │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐                             │
│  │Behavior│ │Diagnose│ │Coaching│ │EdgeMap │  ← Quick Jump Tiles         │
│  │3 issues│ │Primary │ │3 steps │ │14:00   │                             │
│  └────────┘ └────────┘ └────────┘ └────────┘                             │
│                                                                          │
│  [⚠ 3 data quality warnings ▾]  (collapsible)                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **4 emotional-center cards** (above fold on ALL breakpoints) — the 5-second answer.
2. **Performance strip** — quick numbers for context.
3. **Biggest-leak + what-if callouts** — drill-down hooks.
4. **Quick-jump tiles** — navigation to deep-dives.
5. **Data quality warnings** — transparent but collapsed.

### Component Placement

**The 4 emotional-center cards (CRITICAL — must fit above fold on 375 × 667):**

| Card | Height | Content | Source |
|---|---|---|---|
| **Overall Health** | 140px | ScoreGauge (96px numeral, 0–100, severity arc), severity word | `overall_score.value`, `overall_score.severity` |
| **Biggest Leak** | 120px | Phosphor `Warning` icon, label, $ impact, severity badge | `evidence[0]` (top by priority_score) |
| **Biggest Strength** | 120px | Phosphor `CheckCircle` icon, label, supporting metric | `strengths[0]` |
| **Immediate Next Action** | 110px | Verb-led sentence (truncated ~80 chars), CTA → /coaching | `recommendations[0].action` |

**Total above-fold content:** 140 + 120 + 120 + 110 + (3 × 16px gaps) = 538px. With 56px top bar = 594px. iPhone SE viewport 667px. **Buffer: 73px. ✓ All 4 visible without scrolling.**

**Below-fold content:**
- **Performance strip:** 6 StatCards in 2×3 grid (mobile) / 1×6 row (desktop). Each: label (`--text-caption`), value (`--text-data`, mono). Sources: `performance.net_profit`, `performance.profit_factor`, `statistics.win_rate_pct`, `performance.max_drawdown`, `statistics.total_trades`, `performance.avg_win`, `performance.avg_loss`.
- **Biggest-leak callout:** Card with full evidence description + «شواهد کامل را ببین» CTA → /diagnosis.
- **What-if callout:** Card with simulation text + «جزئیات بیشتر» CTA → /behavioral.
- **Quick-jump tiles (×4):** Interactive cards, each: icon, page name, one-line preview. Navigate to /behavioral, /diagnosis, /coaching, /edge-map.
- **Data quality warnings:** Collapsible accordion, only if `appendix.data_quality_warnings` is non-empty.

### Cards

| Card | Variant | Border | Content |
|---|---|---|---|
| Overall Health | stat (interactive) | severity-colored | ScoreGauge + severity word |
| Biggest Leak | severity-bordered | `--severity-high` or `--severity-critical` (4px inline-start) | icon + label + $ + badge |
| Biggest Strength | severity-bordered | `--severity-low` (green, 4px inline-start) | icon + label + metric |
| Immediate Next Action | default (interactive) | `--accent-cta` (amber, 4px inline-start) | verb sentence + CTA |
| StatCards (×6) | stat | none | label + mono value |
| Biggest-leak callout | default | `--border-subtle` | description + CTA |
| What-if callout | default | `--border-subtle` | simulation text + CTA |
| Quick-jump tiles (×4) | interactive | `--border-subtle` → `--accent-primary` on hover | icon + name + preview |

### Tables
None on Dashboard (tables live on Trade Explorer, History, Evidence Explorer).

### Charts
None on Dashboard (charts live on Charts page). ScoreGauge is a progress indicator, not a chart.

### Interactions
- **Click Overall Health card** → `/behavioral/[id]`.
- **Click Biggest Leak card** → `/diagnosis/[id]` (scrolled to that evidence).
- **Click Biggest Strength card** → `/edge-map/[id]`.
- **Click Immediate Next Action CTA** → `/coaching/[id]`.
- **Click analysis badge (top bar)** → drawer with History list (recent 5) + «مشاهده‌ی همه».
- **Click «دانلود گزارش» (top bar, desktop)** → `/report/[id]`.
- **Click quick-jump tile** → navigate to that page.
- **Click data quality warnings** → expand/collapse accordion.
- **Click theme toggle** → instant theme switch.
- **Click language toggle** → instant language switch.
- **Mobile: click bottom tab bar item** → navigate.

### Hover States
- **4 emotional-center cards (desktop):** `--elevation-2` → `--elevation-3`, border `--border-subtle` → `--accent-primary`, cursor pointer, 200ms `--ease-out`.
- **StatCards:** No hover (non-interactive). Optional: subtle bg `--bg-hover` on desktop.
- **Quick-jump tiles:** `--elevation-2` → `--elevation-3`, icon `--fg-secondary` → `--accent-primary`, 200ms.
- **Analysis badge:** bg `--bg-elevated` → `--bg-hover`, 200ms.
- **Download report button:** `--fg-secondary` → `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | 4-card layout | Performance strip | Quick-jumps |
|---|---|---|---|
| `< sm` (375px) | Vertical stack (140+120+120+110px) | 2×3 grid | 2×2 grid |
| `sm` to `< md` | Vertical stack | 2×3 grid | 2×2 grid |
| `md` to `< lg` (768px) | 2×2 grid (Health+Leak / Strength+Action) | 3×2 grid | 1×4 row |
| `≥ lg` (1024px+) | 1×4 row (equal width, ~280px tall) | 1×6 row | 1×4 row |

**375px math verification:** 140+120+120+110 + 3×16 gaps = 538px + 56px top bar = 594px. Viewport 667px. Buffer 73px. **All 4 cards above fold. ✓**

### Micro-interactions
- **4 cards staggered entrance:** fade-up, 100ms per card, 400ms total, `--ease-out`. Frozen if reduced-motion.
- **ScoreGauge fill:** arc animates 0 → value, 600ms `--ease-out`. Frozen if reduced-motion → instant fill.
- **Severity badges:** subtle pulse once on first render (opacity 0.8 → 1 → 0.8, 600ms) to draw the eye. Frozen if reduced-motion.
- **Card hover (desktop):** elevation lift 200ms, border color 200ms.
- **Card press:** scale 0.98, 100ms.
- **Quick-jump tile hover:** icon color transition 200ms, elevation 200ms.
- **Accordion expand:** height auto + content fade, 250ms `--ease-out`.
- **Bottom tab bar (mobile):** active item has subtle indicator bar (2px, `--accent-primary`) that slides between items on navigation, 200ms.

### States
- **Loading (report fetching):** 4 skeleton cards in the same layout (matching heights: 140/120/120/110px). Skeleton performance strip. Skeleton quick-jumps. Pulse animation (frozen if reduced-motion).
- **Empty (no analysis ID):** redirect to `/upload` with toast «ابتدا یک فایل آپلود کنید».
- **Error (fetch failed):** Error card replaces 4 cards: «تحلیل بارگذاری نشد» + retry + «بازگشت به تاریخچه».
- **Partial data (evidence empty):** Biggest Leak card shows «الگوی رفتاری برجسته‌ای شناسایی نشد» + CTA to Behavioral.
- **Partial data (strengths only fallback):** Biggest Strength shows «نقطه‌ی قوت برجسته‌ای شناسایی نشد» + CTA to Edge Map.
- **Partial data (recommendations empty):** Next Action shows «برنامه‌ی اقدام در دسترس نیست» + CTA to Coaching.
- **Success:** User clicks a card → navigates to detail page.

### Accessibility
- Each card is `<button>` or `<a>` with descriptive `aria-label` (e.g., «وضعیت کلی: ۶۷ از ۱۰۰، متوسط. کلیک برای جزئیات رفتاری»).
- ScoreGauge: `role="img"`, `aria-label` with value + severity.
- Severity badges: text label (not color alone).
- Data quality warnings accordion: `aria-expanded`.
- Skip-to-content link.
- Bottom tab bar: `role="tablist"`, each item `role="tab"` with `aria-selected`.
- Analysis badge: `aria-label` with filename + trade count + date.

---

# Part E — Analysis Deep-Dive Screens

---

## 8. Overview

### Purpose
Comprehensive metrics overview — the "full dashboard" for users who want all the numbers at once. Sits between the emotional Dashboard (4 cards) and the dedicated deep-dive pages.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `performance`, `statistics`, `behavior_analysis.scores`, `appendix.performance_raw`, `risk`, `executive_summary`.

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  نمای کلی            [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  نمای کلی عملکرد                      │ ← --text-h1
│  trades_jan.csv · ۱٬۲۴۵ معامله        │
│                                      │
│  ──── خلاصه‌ی اجرایی ────              │
│  ┌─────────────────────────────┐    │
│  │ امتیاز کلی: ۶۷/۱۰۰ (متوسط)   │    │ ← ExecutiveSummary card
│  │ تشخیص اصلی: معامله‌ی انتقامی  │    │
│  │ آرچیتایپ: Revenge Trader     │    │
│  └─────────────────────────────┘    │
│                                      │
│  ──── عملکرد مالی ────                │
│  ┌──────┐ ┌──────┐ ┌──────┐         │ ← 2×3 grid of StatCards
│  │سود   │ │وین‌ریت│ │PF    │         │
│  │خالص  │ │      │ │      │         │
│  │+$1,2K│ │۵۲٪   │ │۱.۳   │         │
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │MaxDD │ │معامله│ │avgWin│         │
│  │-$890 │ │۱۲۴۵  │ │+$24  │         │
│  └──────┘ └──────┘ └──────┘         │
│                                      │
│  ───ـ امتیازهای رفتاری ───ـ           │
│  ┌─────────────────────────────┐    │
│  │ [Gauge] انضباط    ۶۷/۱۰۰    │    │ ← 5 ScoreRows
│  │ [Bar]   انتقام     ۴۵٪      │    │
│  │ [Bar]   بیش‌معامله  ۳۰٪      │    │
│  │ [Bar]   ریسک‌پذیری ۲۵٪      │    │
│  │ [Bar]   صبر       ۸۰٪      │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ ریسک ───ـ                      │
│  ┌─────────────────────────────┐    │
│  │ Max Drawdown: -$890          │    │
│  │ Risk-Taking Score: 25%       │    │
│  │ Revenge Score: 45%           │    │
│  │ What-If: +$1,840 if fixed    │    │
│  └─────────────────────────────┘    │
│                                      │
│  [مشاهده تحلیل رفتاری →]              │
│  [مشاهده تحلیل ریسک →]                │
│  [مشاهده تحلیل عملکرد →]              │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
3-column dashboard layout. Left: Executive Summary + Performance. Center: Behavioral Scores. Right: Risk + CTAs.

### Visual Hierarchy
1. **Executive Summary card** — the headline.
2. **Financial Performance grid** — the numbers.
3. **Behavioral Scores list** — the 5 scores.
4. **Risk summary** — risk metrics.
5. **Drill-down CTAs** — links to dedicated pages.

### Component Placement
- **Page header:** Title + analysis subtitle + breadcrumb.
- **Executive Summary card:** Top, full-width.
- **Financial Performance grid:** Below summary, 2×3 (mobile) / 1×6 (desktop).
- **Behavioral Scores:** Below performance, single card with 5 ScoreRows.
- **Risk summary:** Below scores.
- **Drill-down CTAs:** Bottom, 3 links to /performance, /risk, /behavioral.

### Cards
- **ExecutiveSummary card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Contains: overall score (large mono + severity), primary diagnosis, archetype.
- **StatCards (×6):** Same as Dashboard performance strip.
- **Behavioral Scores card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`. Contains 5 ScoreRows: label + ScoreGauge (mini) + value.
- **Risk summary card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`. Contains: max drawdown, risk-taking score, revenge score, what-if highlight.

### Tables
None.

### Charts
- **Mini ScoreGauges (×5):** Small radial gauges (48px) for each behavioral score. Not full charts — progress indicators.

### Interactions
- **Click any score row** → `/behavioral/[id]` (scrolled to that score).
- **Click performance stat** → `/performance/[id]`.
- **Click risk summary** → `/risk/[id]`.
- **Click CTA buttons** → navigate to respective pages.

### Hover States
- **StatCards:** bg `--bg-elevated` → `--bg-hover`, cursor pointer, 200ms.
- **ScoreRows:** bg → `--bg-hover`, chevron appears, 200ms.
- **Risk summary rows:** same.
- **CTA buttons:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked sections, 2×3 stat grid |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: summary+perf left, scores+risk right |
| `≥ lg` (1024px+) | 3-column dashboard, max-width 1280px |

### Micro-interactions
- **StatCards staggered entrance:** 80ms per card, fade-up, `--ease-out`.
- **ScoreGauges fill:** animate 0 → value, 600ms, staggered 100ms.
- **Card hover:** elevation lift, bg tint, 200ms.
- **Row hover:** chevron slide-in, 200ms.

### States
- **Loading:** Skeleton cards matching layout.
- **Empty:** If no analysis → redirect to /upload.
- **Error:** Standard error card + retry.
- **Success:** User drills into a specific area.

### Accessibility
- All interactive rows: `role="button"`, `aria-label` with full context.
- ScoreGauges: `role="img"`, `aria-label`.
- Headings: `<h1>` page title, `<h2>` section titles.
- Keyboard: Tab through interactive elements, Enter to activate.

---

## 9. Performance Analysis

### Purpose
Deep-dive into financial performance metrics — net profit, profit factor, win rate, drawdown, win/loss streaks, reward/risk ratio.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `performance`, `statistics`, `appendix.performance_raw`.

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تحلیل عملکرد        [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تحلیل عملکرد                        │ ← --text-h1
│ 胸闷همه‌ی معیارهای مالی در یک نگاه     │
│                                      │
│  ──── معیارهای کلیدی ────             │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │سود   │ │وین‌ریت│ │PF    │         │
│  │خالص  │ │      │ │      │         │
│  │+$1.2K│ │۵۲٪   │ │۱.۳   │         │
│  └──────┘ └──────┘ └──────┘         │
│  ┌──────┐ ┌──────┐ ┌──────┐         │
│  │avgWin│ │avgLos│ │R:R   │         │
│  │+$24  │ │-$18  │ │۱.۳:۱ │         │
│  └──────┘ └──────┘ └──────┘         │
│                                      │
│  ───ـ منحنی سرمایه ───ـ              │
│  ┌─────────────────────────────┐    │
│  │ [Equity Curve chart]         │    │ ← AreaChart
│  │  growing with drawdowns      │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ دراودان ───ـ                    │
│  ┌─────────────────────────────┐    │
│  │ [Drawdown chart]             │    │ ← AreaChart (negative)
│  │  max: -$890 on day 14        │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ توزیع سود/زیان ───ـ            │
│  ┌─────────────────────────────┐    │
│  │ [P&L Distribution histogram] │    │ ← Histogram
│  │  green bars (wins) right     │    │
│  │  red bars (losses) left      │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ رشته‌های برد/باخت ───ـ          │
│  ┌─────────────────────────────┐    │
│  │ Max Win Streak: 7            │    │
│  │ Max Loss Streak: 5           │    │
│  │ [Streaks bar chart]          │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ داده‌ی خام ───ـ                  │
│  [مشاهده معاملات خام →]               │ ← link to Trade Explorer
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column layout. Left: Key metrics + Equity Curve + Drawdown. Right: P&L Distribution + Streaks + Raw data link.

### Visual Hierarchy
1. **Key metrics grid** — the headline numbers.
2. **Equity Curve** — the most important chart (how the account grew).
3. **Drawdown** — the risk story.
4. **P&L Distribution** — win/loss shape.
5. **Streaks** — behavioral pattern.
6. **Raw data link** — for verification.

### Component Placement
- **Page header:** Title + subtitle + breadcrumb.
- **Key metrics:** 2×3 grid (mobile) / 1×6 (desktop), top of page.
- **Equity Curve:** Full-width chart card, below metrics.
- **Drawdown:** Full-width chart card, below equity.
- **P&L Distribution:** Full-width (mobile) / right column (desktop).
- **Streaks:** Below distribution.
- **Raw data link:** Bottom.

### Cards
- **StatCards (×6):** net_profit, win_rate_pct, profit_factor, avg_win, avg_loss, reward_risk_ratio. Each: label + mono value + trend indicator (up/down arrow if applicable).
- **Chart cards (×4):** Equity Curve, Drawdown, P&L Distribution, Streaks. Each: `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Contains: chart title, caption, chart, key insight callout.

### Tables
None (raw data lives in Trade Explorer).

### Charts
| Chart | Type | Library | Question |
|---|---|---|---|
| Equity Curve | Area (gradient fill) | Recharts | "How did my account grow?" |
| Drawdown | Area (negative, red) | Recharts | "What was my worst period?" |
| P&L Distribution | Histogram (green/red) | Recharts | "Are wins bigger than losses?" |
| Win/Loss Streaks | Bar (green/red) | Recharts | "How long are my streaks?" |

### Interactions
- **Chart hover/tap** → tooltip with exact value + date.
- **Pinch (mobile)** → zoom (equity, drawdown only).
- **Double-tap** → reset zoom.
- **Click key insight** → highlight relevant data point on chart.
- **Click «مشاهده معاملات خام»** → `/trades/[id]`.

### Hover States
- **StatCards:** bg → `--bg-hover`, 200ms.
- **Chart cards:** No hover (non-interactive). Tooltip appears on data point hover.
- **Raw data link:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked charts, 2×3 metric grid |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: metrics+equity+drawdown left, distribution+streaks right |
| `≥ lg` (1024px+) | 2-column, larger charts, max-width 1280px |

### Micro-interactions
- **Chart entrance:** bars/lines grow from baseline, 400ms `--ease-out`, staggered 100ms between charts. Frozen if reduced-motion → instant render.
- **Tooltip:** fade-in 100ms on hover, fade-out 100ms on leave.
- **StatCards:** staggered fade-up, 80ms per card.
- **Key insight callout:** subtle bg pulse once on first render.

### States
- **Loading:** Chart skeletons (axes + pulsing placeholder area).
- **Empty (insufficient data):** «داده‌ی کافی برای این نمودار نیست» + suggest another chart.
- **Error (chart render fail):** «نمودار قابل رسم نیست» + «مشاهده‌ی داده‌ی خام» fallback link.
- **Success:** User identifies a pattern or clicks through to raw data.

### Accessibility
- Each chart: `aria-label` summarizing data + visually-hidden `<table>` alternative.
- Tooltip: `aria-live="polite"`.
- Color + line style differentiate series (not color alone).
- Keyboard: Tab to chart, Enter for tooltip.

---

## 10. Risk Analysis

### Purpose
Deep-dive into risk metrics — max drawdown, revenge score, risk-taking score, what-if simulations.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `risk`, `behavior_analysis.scores`, `behavior_analysis.what_if`, `behavior_analysis.context_rows` (revenge, risk_taking).

### Phase status
Enhanced deep-dive (new page, consumes existing engine outputs).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تحلیل ریسک          [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تحلیل ریسک                          │ ← --text-h1
│  ریسک‌های رفتاری و مالی شما            │
│                                      │
│  ──── بزرگ‌ترین ریسک ───ـ              │
│  ┌─────────────────────────────┐    │ ← severity-bordered card (Critical/High)
│  │ [⚠] معامله‌ی انتقامی          │    │
│  │ امتیاز: ۴۵٪ · شدت: بالا       │    │
│  │ ۱٬۸۴۰ دلار ضرر                │    │
│  │ ۱۲ رویداد در ۱٬۲۴۵ معامله     │    │
│  │ [شواهد کامل →]                │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ شبیه‌سازی What-If ───ـ          │
│  ┌─────────────────────────────┐    │
│  │ اگر معامله‌ی انتقامی را       │    │ ← WhatIf card (collapsible)
│  │ اصلاح می‌کردید...              │    │
│  │  [▼ نمایش شبیه‌سازی]           │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ امتیازهای ریسک ───ـ             │
│  ┌─────────────────────────────┐    │
│  │ [Gauge] انتقام     ۴۵٪ (بالا)│    │
│  │ [Gauge] ریسک‌پذیری ۲۵٪ (متوسط)│    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ دراودان مالی ───ـ               │
│  ┌─────────────────────────────┐    │
│  │ Max Drawdown: -$890          │    │
│  │ [Drawdown chart]             │    │
│  │ بزرگ‌ترین افت در روز ۱۴        │    │
│  └─────────────────────────────┘    │
│                                      │
│  ──── توصیه‌های ریسک ───ـ             │
│  ┌─────────────────────────────┐    │
│  │ [P1] بعد از هر باخت، ۳۰ دقیقه │    │ ← RecommendationCards
│  │      استراحت کن               │    │
│  │ [P2] حداکثر حجم ثابت تعیین کن │    │
│  └─────────────────────────────┘    │
│                                      │
│  [مشاهده برنامه‌ی کامل →]              │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: Biggest risk + What-If + Risk scores. Right: Drawdown + Recommendations.

### Visual Hierarchy
1. **Biggest risk card** — the headline (severity-colored).
2. **What-If simulation** — the "what could be" story.
3. **Risk scores** — the 2 risk-related behavioral scores.
4. **Drawdown** — the financial risk visualization.
5. **Recommendations** — actionable next steps.

### Component Placement
- **Page header:** Title + subtitle + breadcrumb.
- **Biggest risk card:** Top, full-width, severity-bordered.
- **What-If card:** Below biggest risk, collapsible.
- **Risk scores:** Below What-If, 2 ScoreGauges.
- **Drawdown chart:** Below scores (mobile) / right column (desktop).
- **Recommendations:** Below drawdown, 2 cards.
- **CTA:** Bottom, link to /coaching.

### Cards
- **Biggest risk card:** `severity-bordered` (`--severity-high` or `--severity-critical`), `--bg-elevated`, `--elevation-2`, `--radius-xl`. Contains: warning icon, risk label, score, severity, $ impact, event count, CTA.
- **What-If card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`. Collapsible: header always visible, body (simulation details) on expand.
- **Risk score cards (×2):** Each with ScoreGauge + label + severity.
- **Drawdown card:** Chart card with drawdown area chart + key insight.
- **Recommendation cards (×2):** Priority-chipped, severity-bordered.

### Tables
None.

### Charts
- **Drawdown chart:** Area chart (negative, red). Shows drawdown over time. Max drawdown annotated.

### Interactions
- **Click biggest risk card** → `/diagnosis/[id]` (scrolled to that evidence).
- **Expand What-If** → reveal simulation details (e.g., «اگر معامله‌ی انتقامی را اصلاح می‌کردید، ۱٬۸۴۰ دلار بیشتر سود می‌کردید. این معادل ۱۵۰٪ از سود خالص فعلی شماست.»).
- **Click risk score** → `/behavioral/[id]` (scrolled to that score).
- **Hover drawdown chart** → tooltip with date + drawdown value.
- **Click recommendation** → expand rationale.
- **Click CTA** → `/coaching/[id]`.

### Hover States
- **Biggest risk card:** `--elevation-2` → `--elevation-3`, 200ms.
- **What-If expand button:** bg → `--bg-hover`, chevron rotates, 200ms.
- **Risk score cards:** bg → `--bg-hover`, 200ms.
- **Recommendation cards:** `--elevation-2` → `--elevation-3`, 200ms.
- **CTA:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: risk+whatif+scores left, drawdown+recommendations right |
| `≥ lg` (1024px+) | 2-column, larger charts, max-width 1280px |

### Micro-interactions
- **Biggest risk card entrance:** fade-up + severity border slides in from inline-start, 400ms.
- **What-If expand:** height auto + content fade, 250ms `--ease-out`. Chevron rotates 180°, 200ms.
- **ScoreGauges fill:** animate 0 → value, 600ms, staggered 150ms.
- **Drawdown chart:** area grows from baseline, 400ms.
- **Recommendation cards:** staggered fade-up, 100ms per card.

### States
- **Loading:** Skeleton cards + chart skeleton.
- **Empty (no risk data):** «داده‌ی ریسک موجود نیست» + CTA to Dashboard.
- **Error:** Standard error card + retry.
- **Success:** User understands their biggest risk and clicks through to action plan.

### Accessibility
- Severity badges: text + icon (not color alone).
- What-If accordion: `aria-expanded`.
- ScoreGauges: `role="img"`, `aria-label`.
- Chart: `aria-label` + visually-hidden table.

---

## 11. Behavior Analysis

### Purpose
Per-score breakdown of 5 behavioral scores with severity, $ impact, % of profit, event count, insight, what-if.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `behavior_analysis` (scores, context_rows, detected_patterns, what_if).

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تحلیل رفتاری        [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تحلیل رفتاری                        │ ← --text-h1
│  ۳ رفتار نیاز به توجه دارد           │ ← summary line
│                                      │
│  ┌─────────────────────────────┐    │ ← ContextBlockCard (Critical, expanded)
│  │ [⚠] معامله‌ی انتقامی          │    │   severity-bordered
│  │ امتیاز: ۴۵٪ · شدت: بالا       │    │
│  │ ───────────────────────────  │    │
│  │ ضرر: ۱٬۸۴۰ دلار               │    │
│  │ ۱۲٪ از سود کل                 │    │
│  │ ۱۲ رویداد · ۱۵۳ دلار/رویداد   │    │
│  │ ───────────────────────────  │    │
│  │ Insight: بعد از ۲+ باخت،      │    │
│  │ حجم را افزایش می‌دهید...        │    │
│  │ ───────────────────────────  │    │
│  │ [What-If ▾]                   │    │ ← collapsible
│  │ [شواهد این رفتار →]            │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← ContextBlockCard (High, expanded)
│  │ [⚠] بیش‌معامله‌گری             │    │
│  │ امتیاز: ۳۰٪ · شدت: متوسط       │    │
│  │ ... (collapsed by default)    │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← ContextBlockCard (Medium, collapsed)
│  │ [○] ریسک‌پذیری در حجم         │    │
│  │ امتیاز: ۲۵٪ · شدت: متوسط       │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← ContextBlockCard (Low)
│  │ [✓] صبر و فاصله‌ی زمانی       │    │   green border
│  │ امتیاز: ۸۰٪ · شدت: پایین       │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │
│  │ [✓] انضباط کلی                │    │ ← Overall discipline
│  │ امتیاز: ۶۷/۱۰۰ · متوسط         │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: 5 ContextBlockCards stacked. Right: Radar chart (5-axis) showing all scores visually + legend.

### Visual Hierarchy
1. **Summary line** — "3 behaviors need attention."
2. **ContextBlockCards ordered by severity** — Critical → Low.
3. **Per-card: score + severity + $ impact + insight + what-if.**
4. **Radar chart (desktop)** — visual comparison of all 5 scores.

### Component Placement
- **Page header:** Title + summary + breadcrumb.
- **ContextBlockCards:** Stacked vertically, ordered by severity (Critical first, Low last), then by $ impact.
- **Radar chart (desktop):** Right rail, sticky, shows all 5 scores.

### Cards
- **ContextBlockCard (×5):** `severity-bordered` (`--severity-*` based on score), `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-5` padding. Contains:
  - Header: icon (severity-colored), behavior label, score, severity badge.
  - Body (expanded for Critical/High, collapsed for Medium/Low): 4 mini-stats ($ impact, % of profit, event count, avg per event), insight text, what-if callout (collapsible), CTA.
- **Overall discipline card:** Separate card at bottom, shows composite `discipline_score`.

### Tables
None.

### Charts
- **Radar chart (desktop only):** 5-axis radar showing all behavioral scores. `--chart-primary` with 20% fill. Sticky in right rail.

### Interactions
- **Tap card** → toggle expand/collapse (accordion on mobile, independent on desktop).
- **Expand What-If** → reveal simulation.
- **Click «شواهد این رفتار»** → `/diagnosis/[id]?behavior={type}`.
- **Hover score (desktop)** → tooltip with severity thresholds (Low <25, Medium 25–49, High 50–74, Critical 75+).
- **Hover radar chart axis** → tooltip with that score's details.

### Hover States
- **ContextBlockCards:** `--elevation-2` → `--elevation-3`, border brightens, 200ms.
- **What-If expand:** chevron rotates, bg `--bg-hover`, 200ms.
- **CTA:** `--fg-secondary` → `--accent-primary`, 200ms.
- **Radar chart axes:** highlight on hover, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, accordion cards, no radar chart |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: cards left, radar chart right (sticky) |
| `≥ lg` (1024px+) | 2-column, larger cards, max-width 1280px |

### Micro-interactions
- **Cards staggered entrance:** fade-up, 100ms per card, `--ease-out`.
- **Expand/collapse:** height auto + content fade, 250ms `--ease-out`.
- **What-If expand:** height auto + fade, 250ms. Chevron rotates 180°.
- **ScoreGauges (mini):** fill 0 → value, 400ms, staggered.
- **Radar chart:** polygon grows from center, 500ms `--ease-out`.
- **Severity border:** slides in from inline-start on entrance, 400ms.

### States
- **Loading:** 5 skeleton cards with pulse.
- **Empty (no behavioral data):** «داده‌ی رفتاری موجود نیست» + CTA to Dashboard.
- **Error:** Standard error card + retry.
- **Success:** User expands a card, reads insight, clicks through to evidence.

### Accessibility
- Cards: `role="button"`, `aria-expanded`.
- Severity badges: text + icon.
- ScoreGauges: `role="img"`, `aria-label`.
- What-If: `aria-live="polite"` when expanded.
- Radar chart: `aria-label` + visually-hidden data table.
- Keyboard: Tab to card, Enter/Space to expand.

---

## 12. Psychology Analysis

### Purpose
Psychological archetype profile with narrative and supporting evidence. Answers "What kind of trader am I?"

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `trader_profile`, `psychology` (dna, narrative), `evidence`.

### Phase status
Phase 1 build (maps to Trader DNA).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  روانشناسی معامله‌گر  [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  دی‌ان‌ای معامله‌گر                    │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │ ← ArchetypeHeroCard
│  │                              │    │   full-width, centered
│  │       [DNA icon 48px]        │    │
│  │                              │    │
│  │   معامله‌گر انتقامی            │    │ ← --text-data-xl, mono, centered
│  │   Revenge Trader              │    │
│  │                              │    │
│  │ این پروفایل بر اساس           │    │ ← --text-body-sm, --fg-secondary
│  │ مهم‌ترین شواهد رفتاری شما      │    │
│  │ تعیین شده است.                 │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ روایت روانشناختی ───ـ          │
│  ┌─────────────────────────────┐    │ ← NarrativeCard
│  │ پروفایل رفتاری غالب:          │    │   narrow container (640px)
│  │ «معامله‌گر انتقامی»...          │    │
│  │                              │    │
│  │ این آرچیتایپ بر اساس           │    │
│  │ مهم‌ترین شاهد رفتاری...         │    │
│  │                              │    │
│  │ (۳–۵ پاراگراف متن)             │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ شواهد پشتیبان ───ـ             │
│  ┌─────────────────────────────┐    │ ← EvidenceCard (compact, ×3)
│  │ [⚠] Revenge Trading           │    │
│  │ ۱۲ رویداد · ۱٬۸۴۰ دلار         │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ [○] Overtrading               │    │
│  │ ۸ رویداد · ۴۲۰ دلار            │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ [○] Risk Taking                │    │
│  │ ۵ رویداد · ۲۱۰ دلار            │    │
│  └─────────────────────────────┘    │
│                                      │
│  [مشاهده تشخیص کامل →]                │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: ArchetypeHeroCard + NarrativeCard. Right: Supporting evidence (sticky) + DNA helix decoration.

### Visual Hierarchy
1. **Archetype label** — the one-word answer ("Revenge Trader").
2. **Narrative** — the explanation.
3. **Supporting evidence** — the proof.
4. **CTA** — drill to full diagnosis.

### Component Placement
- **Page header:** Title + breadcrumb.
- **ArchetypeHeroCard:** Top, full-width, centered content.
- **NarrativeCard:** Below hero, narrow container (640px) for readability.
- **Supporting evidence:** Below narrative, 3 compact EvidenceCards.
- **CTA:** Bottom, link to /diagnosis.

### Cards
- **ArchetypeHeroCard:** `--bg-elevated`, `--elevation-2`, `--radius-2xl`, `--space-8` padding, centered. Contains: large DNA icon (`--icon-xl`), archetype label (`--text-data-xl`, mono), one-line summary (`--text-body-sm`, `--fg-secondary`).
- **NarrativeCard:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding, max-width 640px. Contains: `psychology.narrative` text (3–5 paragraphs, `--text-body`, 1.6 line-height).
- **EvidenceCards (×3, compact):** `severity-bordered`, `--bg-elevated`, `--elevation-2`, `--radius-lg`. Each: type icon, label, frequency, $ impact.

### Tables
None.

### Charts
None (radar chart lives on Behavioral Analysis).

### Interactions
- **Click archetype icon** → tooltip explaining the archetype name.
- **Click evidence card** → expand to show description + confidence.
- **Click CTA** → `/diagnosis/[id]`.

### Hover States
- **ArchetypeHeroCard:** No hover (non-interactive). Optional: subtle glow on the icon (`--accent-primary` at 20% opacity), 200ms.
- **EvidenceCards:** `--elevation-2` → `--elevation-3`, 200ms.
- **CTA:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, full-width cards |
| `sm` to `< md` | Same as mobile, max-width 640px centered |
| `md` to `< lg` (768px) | 2-column: hero+narrative left, evidence right (sticky) |
| `≥ lg` (1024px+) | 2-column, DNA helix decoration on hero, max-width 1280px |

### Micro-interactions
- **Hero entrance:** icon scale 0.8 → 1 + fade, 400ms `--ease-spring` (subtle overshoot). Archetype label fade-up 200ms after icon.
- **Narrative:** paragraphs fade-in staggered 100ms as user scrolls into view.
- **Evidence cards:** staggered fade-up, 100ms per card.
- **Icon glow (desktop hover):** opacity 0 → 0.2, 200ms.
- **CTA arrow:** slides right 4px on hover, 200ms.

### States
- **Loading:** Skeleton hero (large text placeholder) + skeleton paragraphs.
- **Empty (archetype is "N/A"):** «پروفایل هنوز تعیین نشده» + CTA to re-analyze with more data.
- **Error:** Standard error card + retry.
- **Success:** User reads narrative and clicks CTA to Diagnosis.

### Accessibility
- Hero card: `<h2>` for archetype.
- Narrative: semantic `<p>` tags with appropriate heading levels.
- Evidence cards: `role="button"`, `aria-expanded`.
- Icon: `aria-hidden="true"` (decorative).

---

# Part F — Coaching & Action Screens

---

## 13. AI Coach

### Purpose
Deliver the prioritized action plan + AI-generated coaching narrative + reality check. Turn insight into action.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `recommendations`, `ai_coaching` (explainable_ai, reality_check).

### Phase status
Phase 1 build (maps to Coaching).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  برنامه‌ی اقدام        [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  برنامه‌ی اقدام                       │ ← --text-h1
│  ۳ گام برای این هفته                  │ ← subtitle
│                                      │
│  ┌─────────────────────────────┐    │ ← RecommendationCard P1
│  │ [P1] معامله‌ی انتقامی          │    │   severity-bordered (Critical)
│  │ بعد از هر باخت، ۳۰ دقیقه      │    │
│  │ استراحت کن.                   │    │
│  │ [▾ نمایش دلیل]                 │    │ ← expand for rationale
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← RecommendationCard P2
│  │ [P2] بیش‌معامله‌گری             │    │
│  │ برای خودت سقف روزانه‌ی تعداد   │    │
│  │ معامله تعیین کن (۵ معامله).    │    │
│  │ [▾ نمایش دلیل]                 │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← RecommendationCard P3
│  │ [P3] ریسک‌پذیری                │    │
│  │ برای هر معامله حداکثر حجم      │    │
│  │ ثابت تعیین کن.                 │    │
│  │ [▾ نمایش دلیل]                 │    │
│  └─────────────────────────────┘    │
│                                      │
│  [نمایش گام‌های بیشتر (۵)]            │ ← show more
│                                      │
│  ───ـ روانشناسی این برنامه ───ـ      │
│  ┌─────────────────────────────┐    │ ← AICoachingCard
│  │ [💡] روانشناسی این برنامه     │    │
│  │ [توضیح الگوریتمی]              │    │ ← badge (or "AI-generated")
│  │                              │    │
│  │ (long-form text, narrow       │    │
│  │  container, 1.6 line-height)  │    │
│  │                              │    │
│  │ ℹ این توضیح توسط الگوریتم     │    │ ← tooltip
│  │   تولید شده است.               │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ واقعیت‌بینی ───ـ                │
│  ┌─────────────────────────────┐    │ ← RealityCheckCard
│  │ [ℹ] واقعیت‌بینی                │    │
│  │                              │    │
│  │ (grounded, non-judgmental     │    │
│  │  text)                        │    │
│  └─────────────────────────────┘    │
│                                      │
│  [📄 گزارش کامل را دانلود کن]         │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: Top-3 RecommendationCards + show more. Right: AICoachingCard + RealityCheckCard (sticky).

### Visual Hierarchy
1. **Top-3 RecommendationCards** — the actionable steps.
2. **AI Coaching narrative** — the "why" behind the plan.
3. **Reality check** — grounded perspective.
4. **Download CTA** — export.

### Component Placement
- **Page header:** Title + subtitle + breadcrumb.
- **RecommendationCards (×3):** Stacked, ordered by priority (P1, P2, P3).
- **Show more button:** Below top-3.
- **AICoachingCard:** Below recommendations (mobile) / right column (desktop).
- **RealityCheckCard:** Below AI coaching.
- **Download CTA:** Bottom.

### Cards
- **RecommendationCard (×3, +5 more on expand):** `severity-bordered` (P1 = Critical border, P2 = High, P3 = Medium), `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-5` padding. Contains: priority chip (P1/P2/P3), issue label, action text (verb-led), expand for rationale, «انجام شد» toggle.
- **AICoachingCard:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding, max-width 640px. Contains: lightbulb icon, header, badge (algorithmic/AI), narrative text.
- **RealityCheckCard:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Visually distinct (different bg tint: `--bg-surface`). Contains: info icon, header, text.

### Tables
None.

### Charts
None.

### Interactions
- **Tap recommendation card** → expand rationale (2–3 sentences explaining why, tied to evidence).
- **«انجام شد» toggle** → strikethrough + green check + `localStorage` update. Visual feedback only (Phase 1).
- **«نمایش گام‌های بیشتر»** → reveal remaining 5 recommendations with staggered animation. Button text → «نمایش کمتر».
- **Click AI coaching badge** → tooltip explaining algorithmic vs AI.
- **Click download CTA** → `/report/[id]`.

### Hover States
- **RecommendationCards:** `--elevation-2` → `--elevation-3`, border brightens, 200ms.
- **«انجام شد» toggle:** bg `--bg-surface` → `--bg-hover`, 200ms. On toggle: green check appears with spring.
- **Show more button:** bg `--bg-elevated` → `--bg-hover`, 200ms.
- **AI coaching badge:** bg tint, 200ms. Tooltip appears.
- **Download CTA:** `--accent-cta` → `--accent-cta-hover`, scale 1.02, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked cards |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: recommendations left, AI+reality right (sticky) |
| `≥ lg` (1024px+) | 2-column, top-3 in 3-column grid, max-width 1280px |

### Micro-interactions
- **Recommendation cards staggered entrance:** fade-up, 100ms per card, `--ease-out`.
- **Expand rationale:** height auto + content fade, 250ms `--ease-out`.
- **«انجام شد» toggle:** checkmark pops in with `--ease-spring` (scale 0 → 1.2 → 1, 300ms). Strikethrough fades in 200ms. Card gets subtle green tint.
- **Show more:** additional cards slide-down + fade, staggered 80ms.
- **AI coaching text:** paragraphs fade-in staggered 100ms on scroll into view.

### States
- **Loading:** 3 skeleton recommendation cards + skeleton text block.
- **Empty (recommendations empty):** «برنامه‌ی اقدام در دسترس نیست» + CTA to Dashboard.
- **Empty (AI coaching empty):** Hide AICoachingCard entirely.
- **Error:** Standard error card + retry.
- **Success:** User marks a recommendation as done → green check + optional subtle toast «انجام شد».

### Accessibility
- Recommendation cards: `role="button"`, `aria-expanded`.
- Priority chip: `aria-label="اولویت ۱"`.
- «انجام شد» toggle: `role="switch"`, `aria-checked`.
- AI badge: `aria-label` + tooltip `aria-describedby`.
- Long-form text: semantic `<p>` tags.

---

# Part G — Trade Exploration Screens

---

## 14. Trade Explorer

### Purpose
Browse normalized trade-level data. Filter, sort, inspect individual trades. Verify engine findings.

### Engine dependency
`GET /api/v1/analyses/{id}/trades` (NEW endpoint, Phase 2 §5.1 — serialization-only, no engine changes).

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  کاوش معاملات        [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  کاوش معاملات                        │ ← --text-h1
│  ۱٬۲۴۵ معامله                         │
│                                      │
│  ┌─────────────────────────────┐    │ ← AggregateStatsBar
│  │ نمایش: ۸۷ معامله              │    │
│  │ [P&L] [Win%] [AvgSize] [Max] │    │ ← 4 mini-stats
│  └─────────────────────────────┘    │
│                                      │
│  [🔍 فیلترها]  [Sort: تاریخ ▾]       │ ← filter button + sort dropdown
│                                      │
│  ┌─────────────────────────────┐    │ ← TradeCard (mobile card list)
│  │ ۲۰۲۴-۰۱-۱۵ ۱۴:۳۰  [Long]     │    │
│  │ Size: 0.5                    │    │
│  │ +$12.50                      │    │ ← profit (green, large mono)
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ ۲۰۲۴-۰۱-۱۵ ۱۵:۰۰  [Short]    │    │
│  │ Size: 0.3                    │    │
│  │ -$8.20                       │    │ ← loss (red)
│  └─────────────────────────────┘    │
│  ...                                 │
│                                      │
│  ┌─────────────────────────────┐    │ ← Filter bottom sheet (when open)
│  │ فیلترها                       │    │
│  │ بازه‌ی تاریخ: [from] [to]      │    │
│  │ جهت: [همه] [Long] [Short]     │    │
│  │ نتیجه: [همه] [سودده] [زیان‌ده] │    │
│  │ حجم: [min] [max]              │    │
│  │ [اعمال] [پاک کردن]            │    │
│  └─────────────────────────────┘    │
│                                      │
│  «مورد ۱–۵۰ از ۸۷»  [قبلی] [بعدی]    │ ← compact pagination
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [☰] کاوش معاملات                                              [⌘K][☀][فا] │
├──────────────────────────────────────────────────────────────────────────┤
│  کاوش معاملات                                                             │
│  ۱٬۲۴۵ معامله                                                              │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │ نمایش: ۸۷ معامله | P&L: +$1,240 | Win: 62% | AvgSize: 0.45 | Max: +$45│  │ ← AggregateStatsBar
│  └────────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  [Date range: from to] [Side: All▾] [Outcome: All▾] [Size: min max]      │ ← FilterBar (inline)
│  [اعمال فیلترها]  [پاک کردن]    Sort: [تاریخ ▾]    [خروجی CSV]           │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │ #  | Open Time        | Side  | Size  | Profit   | Hour | Weekday │  │ ← DataTable (dense)
│  |----|-------------------|-------|-------|----------|------|---------|  │
│  │ 1  | 2024-01-15 14:30  | Long  | 0.5   | +$12.50  | 14   | Mon     │  │
│  │ 2  | 2024-01-15 15:00  | Short | 0.3   | -$8.20   | 15   | Mon     │  │
│  │ 3  | 2024-01-15 16:45  | Long  | 0.8   | +$24.00  | 16   | Mon     │  │
│  │ ...                                                                │  │
│  └────────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  «مورد ۱–۵۰ از ۸۷»  [← قبلی]  1 2 3 4 5  [بعدی →]  | صفحه: [50▾]        │ ← pagination
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Aggregate stats bar** — context for the current view.
2. **Filter bar** — controls.
3. **Trade table/cards** — the data.
4. **Pagination** — navigation.

### Component Placement
- **Page header:** Title + trade count + breadcrumb.
- **AggregateStatsBar:** Below header, full-width. Shows filtered count + 4 mini-stats.
- **FilterBar:** Below stats. Desktop: inline. Mobile: collapsed into «فیلترها» button → bottom sheet.
- **DataTable (desktop) / CardList (mobile):** Below filters, full-width.
- **Pagination:** Below table, centered.

### Cards
- **AggregateStatsBar:** `--bg-elevated`, `--elevation-1`, `--radius-lg`, `--space-3` padding. Horizontal row: filtered count + 4 mini-stats (label + mono value).
- **TradeCards (mobile, ×50 per page):** `--bg-elevated`, `--elevation-2`, `--radius-lg`, `--space-3` padding. Each: date+time (top), side badge, size, profit (large, colored mono).
- **Filter bottom sheet (mobile):** Full-width bottom sheet, `--bg-elevated`, `--elevation-5`, `--radius-xl`. Contains: date range picker, side SegmentedControl, outcome SegmentedControl, size range inputs, Apply + Clear buttons.

### Tables
- **DataTable (desktop, dense variant):** Columns: # | Open Time | Side | Size | Profit | Hour | Weekday. Sortable headers. Profit column: mono, green/red. Pagination: 50/100/200 per page.

### Charts
None (charts live on Performance Analysis page).

### Interactions
- **Click «فیلترها» (mobile)** → bottom sheet opens.
- **Apply filters** → server-side filter via query params, table refreshes, AggregateStatsBar updates.
- **Clear filters** → reset to default, table refreshes.
- **Sort dropdown change** → server-side sort, table refreshes.
- **Click sortable header (desktop)** → toggle sort asc/desc.
- **Click trade row (desktop) / card (mobile)** → Trade Detail drawer (desktop) / bottom sheet (mobile) opens.
- **Click «خروجی CSV»** → download current filtered set as CSV (client-side).
- **Pagination** → fetch next/previous page.
- **Long-press trade card (mobile)** → context menu (open, export single, etc.).

### Hover States
- **Trade rows (desktop):** bg `--bg-elevated` → `--bg-hover`, cursor pointer, 150ms.
- **Sortable headers:** bg `--bg-elevated` → `--bg-hover`, sort icon appears, 150ms.
- **Filter buttons:** bg `--bg-elevated` → `--bg-hover`, 200ms.
- **Pagination buttons:** bg → `--bg-hover`, 200ms. Active page: `--accent-primary` bg.
- **CSV export button:** `--accent-primary` border brightens, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Card list, filters in bottom sheet, compact pagination |
| `sm` to `< md` | Same as mobile, wider cards |
| `md` to `< lg` (768px) | Table appears, filters inline, full pagination |
| `≥ lg` (1024px+) | Full desktop table, all controls inline, max-width 1280px |

### Micro-interactions
- **Table row hover:** bg transition, 150ms.
- **Sort indicator:** chevron rotates asc/desc, 200ms.
- **Filter bottom sheet:** slide-up + fade, 250ms `--ease-out`. Swipe-down to dismiss.
- **Trade detail drawer:** slide-in from side (desktop) / bottom (mobile), 250ms.
- **CSV export:** button spinner during generation, toast on completion.
- **Pagination:** fade transition between pages, 200ms.
- **AggregateStatsBar:** numbers count up from previous value, 400ms `--ease-out` (when filters change).

### States
- **Loading:** Table skeleton (10 row placeholders). AggregateStatsBar skeleton.
- **Empty (no trades match filter):** `empty-trades.svg` illustration + «هیچ معامله‌ای با این فیلترها یافت نشد» + «پاک کردن فیلترها» CTA.
- **Empty (no trades at all):** «داده‌ی معامله‌ای موجود نیست» + CTA to Dashboard.
- **Error (fetch):** Standard error card + retry.
- **Error (404):** «تحلیل یافت نشد» + CTA to History.
- **Success:** User finds a trade, opens detail, confirms or refutes engine finding.

### Accessibility
- Table: `<table>`, `<thead>`, `<tbody>`, `<th scope>`.
- Sortable headers: `<button>`, `aria-sort`.
- Filter bottom sheet: `role="dialog"`, `aria-modal="true"`, focus trap.
- Pagination: `aria-label="صفحه‌بندی"`, current page `aria-current="page"`.
- Trade cards (mobile): `<button>` for navigation.
- CSV export: `aria-label="خروجی CSV"`.

---

## 15. Trade Detail

### Purpose
Full-screen view of a single trade. Reached from Trade Explorer (drawer on desktop, bottom sheet on mobile) or via deep link `/trades/[id]/[tradeId]`.

### Engine dependency
`GET /api/v1/analyses/{id}/trades?trade_id={tradeId}` (single trade row).

### Phase status
Enhanced deep-dive (full-screen view in addition to drawer pattern).

### Layout

**Mobile (375px) — bottom sheet:**
```
┌─────────────────────────────────────┐
│ (Trade Explorer, dimmed)             │
├─────────────────────────────────────┤
│ ───  (drag handle)                  │ ← swipe down to dismiss
│  معامله‌ی #۱۲۴۵                       │ ← --text-h2
│  ۲۰۲۴-۰۱-۱۵ ۱۴:۳۰:۴۵                 │
│                                      │
│  ┌─────────────────────────────┐    │
│  │ جهت: Long                    │    │ ← field rows
│  │ حجم: 0.5 lot                 │    │
│  │ سود: +$12.50                 │    │ ← profit (green, large mono)
│  │ ساعت: ۱۴                     │    │
│  │ روز هفته: Monday             │    │
│  │ تاریخ: ۱۴۰۴/۱۰/۲۵             │    │
│  │ (any other normalized cols)  │    │
│  └─────────────────────────────┘    │
│                                      │
│  ──── زمینه‌ی رفتاری ───ـ             │
│  ┌─────────────────────────────┐    │
│  │ این معامله بخشی از الگوی      │    │ ← behavioral context
│  │ «معامله‌ی انتقامی» است.        │    │   (if trade matches a pattern)
│  │ [شاهد کامل →]                 │    │
│  └─────────────────────────────┘    │
│                                      │
│  [بستن]                              │
└─────────────────────────────────────┘
```

**Desktop (≥1024px) — dedicated route / drawer:**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [← بازگشت به کاوش معاملات]                              معامله‌ی #۱۲۴۵      │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌────────────────────────────┐  ┌────────────────────────────┐          │
│  │ جزئیات معامله               │  │ زمینه‌ی رفتاری              │          │
│  │                            │  │                            │          │
│  │ Open Time: 2024-01-15 14:30│  │ این معامله بخشی از الگوی    │          │
│  │ Side: Long                 │  │ «معامله‌ی انتقامی» است.      │          │
│  │ Size: 0.5 lot              │  │                            │          │
│  │ Profit: +$12.50            │  │ (contextual evidence)      │          │
│  │ Hour: 14                   │  │                            │          │
│  │ Weekday: Monday            │  │ [شاهد کامل →]               │          │
│  │ Date: 1404/10/25           │  │                            │          │
│  │                            │  │                            │          │
│  └────────────────────────────┘  └────────────────────────────┘          │
│                                                                          │
│  ┌────────────────────────────┐                                          │
│  │ معاملات مجاور               │  ← adjacent trades for context          │
│  │ #1244 -8.20  15:00 Short   │                                          │
│  │ #1245 +12.50 14:30 Long ←  │                                          │
│  │ #1246 -5.00  16:45 Long    │                                          │
│  └────────────────────────────┘                                          │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Trade header** — trade number + timestamp.
2. **Trade details** — all fields.
3. **Behavioral context** — if this trade matches an engine pattern.
4. **Adjacent trades** — for context (desktop).

### Component Placement
- **Header:** Back link + trade number.
- **Details card:** Left column (desktop) / full-width (mobile). All trade fields.
- **Behavioral context card:** Right column (desktop) / below details (mobile). Only shown if trade matches a pattern.
- **Adjacent trades:** Below (desktop only). Shows 2–3 trades before and after for context.

### Cards
- **Details card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Field-value pairs in a definition list.
- **Behavioral context card:** `severity-bordered` (if matches pattern), `--bg-elevated`, `--elevation-2`, `--radius-xl`. Contains: pattern name, explanation, CTA to evidence.
- **Adjacent trades card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`. Mini table of 3–5 adjacent trades. Current trade highlighted.

### Tables
- **Adjacent trades (desktop):** Mini table: # | Time | Side | Profit. Current trade row highlighted with `--accent-primary` at 8% bg.

### Charts
None.

### Interactions
- **Click «شاهد کامل»** → `/diagnosis/[id]?evidence={type}`.
- **Click adjacent trade row** → navigate to that trade's detail.
- **Click «بستن» (mobile)** → dismiss bottom sheet.
- **Swipe down (mobile)** → dismiss.
- **Esc** → close (drawer/desktop).
- **Click back link** → `/trades/[id]`.

### Hover States
- **Adjacent trade rows:** bg `--bg-elevated` → `--bg-hover`, cursor pointer, 150ms.
- **«شاهد کامل» link:** `--fg-secondary` → `--accent-primary`, 200ms.
- **Back link:** `--fg-secondary` → `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Bottom sheet, full-screen, single column |
| `sm` to `< md` | Same as mobile, wider |
| `md` to `< lg` (768px) | Drawer from side, 2-column |
| `≥ lg` (1024px+) | Full dedicated route, 2-column + adjacent trades, max-width 1280px |

### Micro-interactions
- **Bottom sheet entrance (mobile):** slide-up + fade, 250ms `--ease-out`.
- **Drawer entrance (desktop tablet):** slide-in from side, 250ms.
- **Field rows:** staggered fade-in, 50ms per row.
- **Behavioral context card (if present):** fade-in after details, 200ms delay.
- **Adjacent trades:** fade-in, 200ms.
- **Dismiss:** slide-down (mobile) / slide-out (desktop), 200ms `--ease-in`.

### States
- **Loading:** Skeleton field rows.
- **Empty (trade not found):** «معامله‌یافت نشد» + back CTA.
- **Error:** Standard error card + retry.
- **Success:** User inspects the trade and understands its context.

### Accessibility
- Bottom sheet / drawer: `role="dialog"`, `aria-modal="true"`, focus trap.
- Field list: `<dl>` / `<dt>` / `<dd>` semantics.
- Adjacent trades: `<table>` with `<th scope>`.
- Esc closes. Focus returns to trigger on close.

---

# Part H — Evidence & Report Screens

---

## 16. Evidence Explorer

### Purpose
Explore the prioritized evidence behind the diagnosis. Understand *why* the engine concluded what it concluded.

### Engine dependency
`GET /api/v1/analyses/{id}/report` — `diagnosis`, `evidence`.

### Phase status
Phase 1 build (maps to Diagnosis).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تشخیص               [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تشخیص                               │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │ ← PrimaryDiagnosisCard
│  │ مشکل اصلی                     │    │   severity-bordered (Critical)
│  │                              │    │
│  │ معامله‌ی انتقامی پس از         │    │ ← --text-h3, bold
│  │ باخت‌های پیاپی                  │    │
│  │ [بحرانی]                      │    │ ← severity badge
│  │                              │    │
│  │ (۳–۴ lines detail text)       │    │
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │ ← SecondaryDiagnosisCard (if exists)
│  │ مشکل ثانویه                   │    │
│  │ بیش‌معامله‌گری در روزهای پر     │    │
│  │ [بالا]                        │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ شواهد (۸) ───ـ                 │
│  [همه] [بحرانی] [بالا] [متوسط]       │ ← severity filter pills
│                                      │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #1 (top priority)
│  │ [⚠] Revenge Trading           │    │   severity-bordered
│  │ ۱۲ رویداد · ۱٬۸۴۰ دلار         │    │
│  │ اولویت: ۹۲ · اطمینان: ۸۵٪      │    │
│  │ [▾ نمایش توضیح]                │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #2
│  │ [○] Overtrading               │    │
│  │ ۸ رویداد · ۴۲۰ دلار            │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← EvidenceCard #3
│  │ [○] Risk Taking                │    │
│  │ ۵ رویداد · ۲۱۰ دلار            │    │
│  └─────────────────────────────┘    │
│                                      │
│  [نمایش همه‌ی شواهد (۵ بیشتر)]        │
│                                      │
│  [💡 برنامه‌ی اقدام را ببین]           │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: Primary + Secondary diagnosis cards. Right: Evidence list (scrollable, sticky header with filter).

### Visual Hierarchy
1. **Primary diagnosis** — the headline.
2. **Secondary diagnosis** — if exists.
3. **Evidence list** — the proof.
4. **CTA** — drill to action plan.

### Component Placement
- **Page header:** Title + breadcrumb.
- **PrimaryDiagnosisCard:** Top, full-width, severity-bordered.
- **SecondaryDiagnosisCard:** Below primary (if exists).
- **Evidence section:** Below diagnoses. Section header + filter pills + EvidenceCards.
- **Show more button:** Below top-3 evidence.
- **CTA:** Bottom, link to /coaching.

### Cards
- **PrimaryDiagnosisCard:** `severity-bordered` (`--severity-critical` or `--severity-high`), `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Contains: «مشکل اصلی» label, diagnosis text (`--text-h3`), severity badge, detail text.
- **SecondaryDiagnosisCard:** Similar but smaller, `--severity-high` or `--severity-medium` border.
- **EvidenceCards (×3 default, +5 on show more):** `severity-bordered`, `--bg-elevated`, `--elevation-2`, `--radius-lg`. Each: type icon, label, severity badge, frequency, $ impact, priority score, confidence, expand for description.

### Tables
None.

### Charts
None.

### Interactions
- **Click severity filter pill** → filter evidence list by severity.
- **Tap evidence card** → expand description + confidence explanation.
- **Click «مشاهده‌ی معاملات مرتبط» (on expanded evidence)** → `/trades/[id]?evidence={type}`.
- **Click primary diagnosis** → smooth-scroll to top evidence for this diagnosis.
- **«نمایش همه‌ی شواهد»** → reveal remaining 5 cards.
- **Click CTA** → `/coaching/[id]`.

### Hover States
- **Diagnosis cards:** `--elevation-2` → `--elevation-3`, 200ms.
- **EvidenceCards:** `--elevation-2` → `--elevation-3`, border brightens, 200ms.
- **Filter pills:** bg `--bg-elevated` → `--bg-hover`, active pill `--accent-primary` at 12%, 200ms.
- **Show more:** bg → `--bg-hover`, 200ms.
- **CTA:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: diagnoses left, evidence right (sticky header) |
| `≥ lg` (1024px+) | 2-column, evidence shows all 8 with priority sparkline column, max-width 1280px |

### Micro-interactions
- **Diagnosis cards entrance:** severity border slides in from inline-start, 400ms. Text fade-up, 200ms after border.
- **Evidence cards staggered:** fade-up, 80ms per card.
- **Expand evidence:** height auto + content fade, 250ms.
- **Filter pill active:** bg transition, 200ms. Evidence list cross-fade, 200ms.
- **Show more:** additional cards slide-down + fade, staggered 80ms.

### States
- **Loading:** Skeleton diagnosis cards + 3 evidence skeletons.
- **Empty (evidence empty):** Hide evidence section. Diagnosis card shows «الگوی رفتاری برجسته‌ای شناسایی نشد» + CTA to Dashboard.
- **Empty (no secondary diagnosis):** Hide secondary card.
- **Error:** Standard error card + retry.
- **Success:** User reads diagnosis + scans evidence → clicks CTA to Coaching.

### Accessibility
- Diagnosis cards: `role="region"`, `aria-labelledby`.
- Evidence cards: `role="button"`, `aria-expanded`.
- Filter pills: `role="toolbar"` or `radiogroup`.
- Severity badges: text + icon.
- Confidence/priority: `aria-label` on progress bars.

---

## 17. Report Center

### Purpose
Generate, preview, and download HTML and PDF reports.

### Engine dependency
`GET /api/v1/analyses/{id}/report`, `GET /api/v1/analyses/{id}/report.html`, `GET /api/v1/analyses/{id}/report.pdf`.

### Phase status
Phase 1 build (maps to Report).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  گزارش                [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  گزارش                               │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │ ← ReadyCard
│  │ [✓] گزارش شما آماده است       │    │
│  │                              │    │
│  │ [📄 دانلود PDF]               │    │ ← primary CTA, full-width
│  │ [📄 دانلود HTML]              │    │ ← secondary, full-width
│  │ [🖨 چاپ]                       │    │ ← ghost
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ بخش‌های گزارش ───ـ              │
│  [خلاصه‌ی اجرایی] [عملکرد] [رفتاری]    │ ← horizontal scroll pills
│  [تشخیص] [coaching] [شواهد] [ضمیمه]  │
│                                      │
│  ┌─────────────────────────────┐    │ ← SectionPreviewCard (Executive Summary, expanded)
│  │ خلاصه‌ی اجرایی                 │    │
│  │ امتیاز کلی: ۶۷/۱۰۰...         │    │
│  │ [▾ بستن]                      │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← SectionPreviewCard (Performance, collapsed)
│  │ عملکرد                        │    │
│  │ سود خالص +$1,240...           │    │
│  │ [▸ نمایش]                     │    │
│  └─────────────────────────────┘    │
│  ...                                 │
│                                      │
│  ───ـ هشدارهای کیفیت داده ───ـ       │
│  [⚠ ۳ هشدار]                        │
│                                      │
│  ───ـ متاداده ───ـ                   │
│  تولید: ۲۰۲۴-۰۱-۱۵ ۱۴:۳۰            │
│  نسخه‌ی موتور: V23 Phase 4           │
│  تعداد معاملات: ۱٬۲۴۵                │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: Section navigator (sticky rail). Right: Section previews (full content, multiple expanded).

### Visual Hierarchy
1. **Ready card + download buttons** — the primary action.
2. **Section navigator** — jump to sections.
3. **Section previews** — in-app browsing.
4. **Metadata** — context.

### Component Placement
- **Page header:** Title + breadcrumb.
- **ReadyCard:** Top, full-width. Contains success message + 3 download buttons.
- **Section navigator:** Below ready card. Mobile: horizontal pills. Desktop: sticky left rail.
- **Section previews:** Below navigator. 7 cards (Executive Summary, Performance, Behavioral, Diagnosis, Coaching, Evidence, Appendix).
- **Data quality warnings:** Below previews (if any).
- **Metadata:** Bottom.

### Cards
- **ReadyCard:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Contains: success icon, message, 3 download buttons (PDF primary, HTML secondary, Print ghost).
- **SectionPreviewCards (×7):** `--bg-elevated`, `--elevation-2`, `--radius-lg`. Each: section title, 2-line excerpt, expand/collapse for full content. Executive Summary expanded by default; others collapsed.
- **Metadata card:** `--bg-surface`, `--radius-lg`, `--space-4` padding. Generated-at, engine version, total trades.

### Tables
- **Appendix section** (when expanded): Raw performance data in a table. Edge map raw data.

### Charts
None in Report Center (charts are in the PDF/HTML report itself, not previewed here).

### Interactions
- **Click «دانلود PDF»** → button loading state, `GET /report.pdf`, browser download, toast «گزارش PDF دانلود شد».
- **Click «دانلود HTML»** → same, `GET /report.html`.
- **Click «چاپ»** → browser print dialog.
- **Click section navigator pill/rail item** → smooth scroll + auto-expand that section.
- **Tap section card** → expand/collapse (accordion on mobile, independent on desktop).
- **Click data quality warnings** → expand.

### Hover States
- **Download buttons:** PDF: `--accent-cta` → `--accent-cta-hover`. HTML: border `--border-strong` → `--accent-primary`. Print: `--fg-secondary` → `--accent-primary`. All 200ms.
- **Section navigator items:** bg `--bg-elevated` → `--bg-hover`, 150ms.
- **Section cards (header):** bg → `--bg-hover`, chevron rotates on expand, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, horizontal section pills, accordion cards |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: navigator rail left, previews right |
| `≥ lg` (1024px+) | 2-column, full content in previews (multiple expanded), max-width 1280px |

### Micro-interactions
- **ReadyCard entrance:** fade-up + check icon pops in with `--ease-spring`, 400ms.
- **Download button press:** scale 0.97, 100ms. Loading: spinner replaces icon.
- **Download success:** toast slides in from top, 250ms.
- **Section expand:** height auto + content fade, 250ms `--ease-out`. Chevron rotates 180°, 200ms.
- **Section navigator active:** pill bg transitions, 200ms. Smooth scroll, 400ms `--ease-in-out` (instant if reduced-motion).

### States
- **Loading:** Skeleton of section cards.
- **Download in progress:** Button loading state (spinner + «در حال آماده‌سازی...»).
- **Download complete:** Toast «گزارش دانلود شد».
- **Error (PDF fail):** «تولید PDF ناموفق بود» + retry + «گزارش HTML را امتحان کنید».
- **Error (HTML fail):** Same with PDF fallback.
- **Error (404):** «تحلیل یافت نشد» + CTA to History.
- **Success:** User downloads report.

### Accessibility
- Download buttons: descriptive `aria-label`.
- Section navigator: `<nav>`, `aria-label="بخش‌های گزارش"`.
- Section cards: `role="button"`, `aria-expanded`.
- Print button: `aria-label="چاپ گزارش"`.
- Download toast: `aria-live="polite"`.

---

# Part I — Management Screens

---

## 18. History

### Purpose
Paginated list of past analyses. Click to reopen. Delete with confirm.

### Engine dependency
`GET /api/v1/history?page=&page_size=`.

### Phase status
Phase 1 build.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تاریخچه              [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تاریخچه‌ی تحلیل‌ها                    │ ← --text-h1
│  ۴۷ تحلیل                             │
│                                      │
│  [همه] [این ماه] [۳ ماه اخیر]          │ ← time filter pills
│  [Sort: جدیدترین ▾]                   │ ← sort dropdown
│                                      │
│  ┌─────────────────────────────┐    │ ← HistoryItemCard
│  │ trades_jan.csv                │    │
│  │ ۱۴۰۴/۰۴/۲۰ · ۱٬۲۴۵ معامله      │    │
│  │ [gauge 67/100] متوسط           │    │
│  │ تشخیص: معامله‌ی انتقامی         │    │
│  │                          [⋯]  │    │ ← more menu
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ trades_feb.csv                │    │
│  │ ...                           │    │
│  └─────────────────────────────┘    │
│  ...                                 │
│                                      │
│  [بیشتر (۲۷ مورد باقی‌مانده)]          │ ← load more button
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
```
┌──────────────────────────────────────────────────────────────────────────┐
│ [☰] تاریخچه                                                    [⌘K][☀][فا] │
├──────────────────────────────────────────────────────────────────────────┤
│  تاریخچه‌ی تحلیل‌ها                                                         │
│  ۴۷ تحلیل                                                                  │
│                                                                          │
│  [همه] [این ماه] [۳ ماه اخیر]  Sort: [جدیدترین ▾]  Page size: [20▾]      │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │ Date       | Filename        | Trades | Score | Diagnosis    | ⋯  │  │ ← DataTable
│  |------------|-----------------|--------|-------|--------------|----|  │
│  │ 1404/04/20 | trades_jan.csv  | 1,245  | 67    | Revenge...   | ⋯  │  │
│  │ 1404/03/15 | trades_feb.csv  | 890    | 72    | Overtrading  | ⋯  │  │
│  │ ...                                                                │  │
│  └────────────────────────────────────────────────────────────────────┘  │
│                                                                          │
│  «مورد ۱–۲۰ از ۴۷»  [← قبلی]  1 2 3  [بعدی →]                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### Visual Hierarchy
1. **Page title + count** — context.
2. **Filter/sort bar** — controls.
3. **History items (cards/table)** — the data.
4. **Pagination** — navigation.

### Component Placement
- **Page header:** Title + count + breadcrumb.
- **Filter/sort bar:** Below header. Time filter pills + sort dropdown + page size (desktop).
- **HistoryItemCards (mobile) / DataTable (desktop):** Below filters.
- **Pagination:** Below list. Mobile: «بیشتر» button. Desktop: page numbers.

### Cards
- **HistoryItemCards (mobile, ×20 per page):** `--bg-elevated`, `--elevation-2`, `--radius-lg`, `--space-4` padding. Each: filename (truncated), date + trade count, mini ScoreGauge + severity, primary diagnosis (truncated), ⋯ menu.
- **DataTable (desktop, comfortable variant):** Columns: Date | Filename | Trades | Score | Diagnosis | Actions. Sortable headers. Score column: mini gauge + value. Row hover highlights.

### Tables
- **DataTable (desktop):** As above. Row click navigates to Dashboard. ⋯ menu per row.

### Charts
None.

### Interactions
- **Click history item (row/card)** → `/dashboard/[analysisId]`.
- **Click ⋯ menu** → options: «باز کردن», «دانلود PDF», «دانلود HTML», «حذف».
- **Click «دانلود PDF»** → trigger `GET /analyses/{id}/report.pdf` directly.
- **Click «حذف»** → confirmation modal «این تحلیل برای همیشه حذف می‌شود. ادامه می‌دهید؟» → «حذف کن» / «انصراف». On delete → toast «تحلیل حذف شد» + list updates.
- **Long-press card (mobile)** → context menu (same as ⋯).
- **Time filter change** → re-fetch.
- **Sort change** → client-side sort.
- **Pagination** → fetch next page.
- **«بیشتر» button (mobile)** → load next page, append to list.

### Hover States
- **HistoryItemCards:** `--elevation-2` → `--elevation-3`, 200ms.
- **Table rows (desktop):** bg `--bg-elevated` → `--bg-hover`, 150ms.
- **⋯ menu button:** bg → `--bg-hover`, 200ms.
- **Filter pills:** bg → `--bg-hover`, active `--accent-primary` at 12%, 200ms.
- **Pagination buttons:** bg → `--bg-hover`, active `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Card list, «بیشتر» button, no page numbers |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | DataTable appears, full pagination |
| `≥ lg` (1024px+) | Full desktop table, page size selector, max-width 1280px |

### Micro-interactions
- **Cards staggered entrance:** fade-up, 50ms per card (max 10 cards staggered).
- **Card hover:** elevation lift, 200ms.
- **⋯ menu:** fade-in + slide-down, 150ms.
- **Delete confirmation:** modal scale-up 0.95 → 1, 200ms `--ease-out`.
- **Delete success:** card slide-out + fade, 200ms. Toast slides in.
- **Pagination:** fade transition between pages, 200ms.

### States
- **Loading:** 5 skeleton cards.
- **Empty (no analyses):** `empty-history.svg` illustration + «هنوز تحالیزی انجام نداده‌اید» + «شروع تحلیل» CTA.
- **Error (fetch):** Standard error card + retry.
- **Error (delete):** Toast «حذف ناموفق بود. دوباره تلاش کنید».
- **Success:** User finds analysis, re-opens it.

### Accessibility
- Table: `<table>`, `<th scope>`.
- Sortable headers: `<button>`, `aria-sort`.
- Cards (mobile): `<button>` for navigation.
- ⋯ menu: `aria-label="اقدامات"`, `aria-haspopup="menu"`.
- Delete confirmation: `role="alertdialog"`.
- Pagination: `aria-label="صفحه‌بندی"`.

---

## 19. Settings

### Purpose
Customize appearance, language. Future-ready for account, billing, API keys, offline cache.

### Engine dependency
None (client-side in Phase 1). Future: user preferences API.

### Phase status
Phase 1 stub (functional: theme, language, density, reset; future: account, API keys, notifications, subscription, mentor workspace).

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  تنظیمات              [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  تنظیمات                              │ ← --text-h1
│                                      │
│  ───ـ ظاهر ───ـ                       │
│  ┌─────────────────────────────┐    │
│  │ تم                            │    │
│  │ [روشن] [تیره] [سیستم]         │    │ ← SegmentedControl
│  │                              │    │
│  │ تراکم                         │    │
│  │ [راحت] [فشرده]                │    │ ← SegmentedControl (visual only Phase 1)
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ زبان ───ـ                       │
│  ┌─────────────────────────────┐    │
│  │ زبان رابط کاربری               │    │
│  │ [فارسی] [English]             │    │ ← SegmentedControl
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ درباره ───ـ                     │
│  ┌─────────────────────────────┐    │
│  │ نسخه‌ی وب: ۱.۰.۰              │    │
│  │ نسخه‌ی موتور: V23 Phase 4     │    │
│  │ [مشاهده مستندات →]            │    │
│  │                              │    │
│  │ [🗑 پاک کردن همه‌ی داده‌ها]     │    │ ← destructive
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ آینده ───ـ                      │
│  ┌─────────────────────────────┐    │
│  │ [👤 حساب کاربری]       [به‌زودی] │    │ ← disabled
│  │ [🔑 کلیدهای API]       [به‌زودی] │    │
│  │ [🔔 اعلان‌ها]           [به‌زودی] │    │
│  │ [💳 اشتراک]            [به‌زودی] │    │
│  │ [🧑‍🏫 فضای مربی]        [به‌زودی] │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
Same content, single column, max-width 640px, centered.

### Visual Hierarchy
1. **Appearance section** — theme + density (most used).
2. **Language section** — language toggle.
3. **About section** — version info + reset.
4. **Future sections** — visible but disabled (no anxiety about missing features).

### Component Placement
- **Page header:** Title + breadcrumb.
- **Sections:** Stacked, single column, max-width 640px centered. Each section: `--space-8` gap.

### Cards
- **Section cards (×4):** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Each: section title (`--text-h3`), content (SegmentedControls, info, buttons).
- **Future section items (×5):** List items, disabled. Each: icon, label, «به‌زودی» badge.

### Tables
None.

### Charts
None.

### Interactions
- **Theme toggle** → instant theme switch, persisted in `localStorage('td_theme')`.
- **Density toggle** → visual only Phase 1 (affects spacing tokens — future: full implementation).
- **Language toggle** → instant language switch, persisted in `localStorage('td_lang')`.
- **Click «مشاهده مستندات»** → open docs (future).
- **Click «پاک کردن همه‌ی داده‌ها»** → confirmation modal → clears `localStorage` → toast «داده‌ها پاک شدند» → page reloads with defaults.
- **Click future section item** → tooltip «این بخش به‌زودی فعال می‌شود».

### Hover States
- **SegmentedControl options:** bg `--bg-surface` → `--bg-hover`, 200ms. Active: `--accent-primary` at 12%.
- **Docs link:** `--fg-secondary` → `--accent-primary`, 200ms.
- **Reset button:** `--severity-critical` border brightens, 200ms.
- **Future items:** bg `--bg-elevated` → `--bg-hover` (but `cursor-not-allowed`), 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, full-width |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | Single column, max-width 640px centered |
| `≥ lg` (1024px+) | Same, max-width 640px |

### Micro-interactions
- **Theme toggle:** instant switch (no transition — prevents flash). Theme tokens swap globally.
- **Language toggle:** instant text direction swap. 200ms fade on text content.
- **SegmentedControl active:** bg transition, 200ms.
- **Reset confirmation:** modal scale-up, 200ms.
- **Reset success:** toast + page fade-out + reload, 300ms.

### States
- **Loading:** N/A (Settings is client-side, instant).
- **Empty:** N/A.
- **Error:** N/A (Phase 1).
- **Success:** Theme/language change is instant — the change itself is the success feedback.

### Accessibility
- SegmentedControls: `role="radiogroup"` + `role="radio"` + `aria-checked`.
- Reset button: `aria-label="پاک کردن همه‌ی داده‌های محلی"`.
- Confirmation modal: `role="alertdialog"`.
- Future items: `aria-disabled="true"` + explanatory `aria-label`.

---

## 20. Profile (future-ready)

### Purpose
User profile management — name, email, avatar, password change. Phase 1 ships Anonymous-only; this screen is fully specified for feature-flag activation.

### Engine dependency
Future: `GET /api/v1/auth/me`, `PATCH /api/v1/auth/me`.

### Phase status
Future-ready.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [← بازگشت به تنظیمات]                 │
├─────────────────────────────────────┤
│  پروفایل                             │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │
│  │       [Avatar 80px]          │    │ ← avatar (initials or image)
│  │       [تغییر عکس]             │    │ ← change avatar link
│  └─────────────────────────────┘    │
│                                      │
│  ┌─────────────────────────────┐    │
│  │ نام                           │    │
│  │ [Arman]                       │    │ ← TextField
│  │                              │    │
│  │ ایمیل                         │    │
│  │ [arman@example.com]           │    │ ← TextField (disabled, verified)
│  │ ✓ تأیید شده                    │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ امنیت ───ـ                      │
│  ┌─────────────────────────────┐    │
│  │ [تغییر رمز عبور →]             │    │ ← link to /settings/security
│  │ [فعال‌سازی احراز هویت دو مرحله‌ای]│    │ ← toggle
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ ترجیحات ───ـ                    │
│  ┌─────────────────────────────┐    │
│  │ ارائه‌دهنده‌ی پیش‌فرض هوش مصنوعی  │    │
│  │ [هیچ] [Gemini] [OpenAI] [Claude]│   │
│  └─────────────────────────────┘    │
│                                      │
│  [ذخیره تغییرات]                     │ ← primary CTA
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
2-column. Left: Avatar + personal info. Right: Security + Preferences.

### Visual Hierarchy
1. **Avatar** — identity.
2. **Personal info** — name, email.
3. **Security** — password, 2FA.
4. **Preferences** — default LLM provider.
5. **Save CTA** — persist changes.

### Component Placement
- **Page header:** Back link + title.
- **Avatar card:** Top, centered.
- **Personal info card:** Below avatar.
- **Security card:** Below personal info.
- **Preferences card:** Below security.
- **Save CTA:** Bottom, full-width (mobile) / right-aligned (desktop).

### Cards
- **Avatar card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding, centered. Avatar (80px circle), change link.
- **Info card:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. TextFields for name, email.
- **Security card:** Similar. Links/toggles for password, 2FA.
- **Preferences card:** Similar. SegmentedControl for default LLM.

### Tables
None.

### Charts
None.

### Interactions
- **Click «تغییر عکس»** → file picker for avatar upload.
- **Edit name** → inline edit, validate on blur.
- **Click «تغییر رمز عبور»** → modal with old password + new password + confirm.
- **Toggle 2FA** → setup flow (QR code, verify code).
- **Change default LLM** → SegmentedControl.
- **Click «ذخیره تغییرات»** → button loading, PATCH request, toast «تغییرات ذخیره شد».

### Hover States
- **Avatar change link:** `--fg-secondary` → `--accent-primary`, 200ms.
- **Security links:** `--fg-secondary` → `--accent-primary`, arrow slides, 200ms.
- **Save CTA:** `--accent-cta` → `--accent-cta-hover`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, stacked |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | 2-column: avatar+info left, security+preferences right |
| `≥ lg` (1024px+) | 2-column, max-width 1024px |

### Micro-interactions
- **Avatar upload:** spinner during upload, fade transition on success.
- **Inline edit:** field border transitions, 200ms.
- **Save:** button spinner, toast slide-in, 250ms.

### States
- **Loading (fetch profile):** Skeleton fields.
- **Saving:** Button spinner + «در حال ذخیره...».
- **Error (fetch):** Standard error card + retry.
- **Error (save):** Inline error on field.
- **Success:** Toast «تغییرات ذخیره شد».

### Accessibility
- All fields: `<label>`.
- Avatar: `alt` text with user name.
- Toggles: `role="switch"`, `aria-checked`.
- 2FA modal: `role="dialog"`, focus trap.

---

## 21. Subscription (future-ready)

### Purpose
View current plan, compare tiers, upgrade/downgrade, manage billing.

### Engine dependency
Future: `GET /api/v1/subscription`, `POST /api/v1/subscription/checkout`.

### Phase status
Future-ready.

### Layout

**Mobile (375px) — Current Plan:**
```
┌─────────────────────────────────────┐
│ [← بازگشت به تنظیمات]                 │
├─────────────────────────────────────┤
│  اشتراک                              │ ← --text-h1
│                                      │
│  ┌─────────────────────────────┐    │ ← CurrentPlanCard
│  │ طرح فعلی: Pro                 │    │
│  │ ۵ از ۱۰۰ تحلیل استفاده شده    │    │
│  │ تمدید: ۱۴۰۴/۰۵/۲۰              │    │
│  │ [مدیریت روش پرداخت]            │    │
│  │ [لغو اشتراک]                   │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ مقایسه طرح‌ها ───ـ              │
│  ┌─────────────────────────────┐    │ ← PlanCard (Free)
│  │ رایگان                        │    │
│  │ $۰/ماه                        │    │
│  │ ✓ ۵ تحلیل در ماه               │    │
│  │ ✓ تاریخچه‌ی محدود               │    │
│  │ ✗ PDF واترمارک‌دار              │    │
│  │ [طرح فعلی]                    │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Pro, current)
│  │ Pro                           │    │
│  │ $۱۹/ماه                       │    │
│  │ ✓ تحلیل نامحدود                │    │
│  │ ✓ تاریخچه‌ی نامحدود             │    │
│  │ ✓ PDF بدون واترمارک            │    │
│  │ ✓ Trends                      │    │
│  │ [طرح فعلی]                    │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Mentor)
│  │ Mentor                        │    │
│  │ $۴۹/ماه                       │    │
│  │ ✓ همه‌ی امکانات Pro             │    │
│  │ ✓ فضای چند دانش‌جو              │    │
│  │ ✓ حاشیه‌نویسی                   │    │
│  │ [ارتقا →]                     │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← PlanCard (Enterprise)
│  │ Enterprise                    │    │
│  │ تماس بگیرید                    │    │
│  │ ✓ همه‌ی امکانات Mentor           │    │
│  │ ✓ SSO                         │    │
│  │ ✓ تیم دشبورد                   │    │
│  │ [تماس با فروش →]              │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
4-column comparison table. Each plan is a column. Feature matrix rows.

### Visual Hierarchy
1. **Current plan card** — status.
2. **Plan comparison** — the 4 tiers.
3. **Feature matrix** — what's included.

### Component Placement
- **Page header:** Back link + title.
- **CurrentPlanCard:** Top, full-width.
- **PlanCards (×4):** Stacked (mobile) / 4-column row (desktop).
- **Feature matrix (desktop):** Below plan cards, detailed comparison.

### Cards
- **CurrentPlanCard:** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Plan name, usage, renewal date, manage/cancel links.
- **PlanCards (×4):** `--bg-elevated`, `--elevation-2`, `--radius-xl`, `--space-6` padding. Current plan: `--accent-primary` border highlight. Each: plan name, price, feature list (check/x icons), CTA button.

### Tables
- **Feature matrix (desktop):** Comparison table. Rows: features. Columns: plans. Cells: check/x.

### Charts
None.

### Interactions
- **Click «ارتقا» on a plan** → checkout flow (`/checkout?plan={tier}`).
- **Click «مدیریت روش پرداخت»** → billing portal.
- **Click «لغو اشتراک»** → confirmation modal (no dark patterns) → downgrade at end of period.
- **Click «تماس با فروش» (Enterprise)** → mailto or contact form.

### Hover States
- **PlanCards:** `--elevation-2` → `--elevation-3`, 200ms.
- **CTA buttons:** `--accent-cta` → `--accent-cta-hover`, 200ms.
- **Manage/cancel links:** `--fg-secondary` → `--accent-primary` / `--severity-critical`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Stacked plan cards |
| `sm` to `< md` | 2×2 grid |
| `md` to `< lg` (768px) | 4-column row, no feature matrix |
| `≥ lg` (1024px+) | 4-column + feature matrix table, max-width 1280px |

### Micro-interactions
- **Plan cards entrance:** staggered fade-up, 100ms per card.
- **Current plan highlight:** border glow pulse once, 600ms.
- **CTA press:** scale 0.97, 100ms.
- **Cancel confirmation:** modal scale-up, 200ms.

### States
- **Loading:** Skeleton plan cards.
- **Error (fetch):** Standard error card + retry.
- **Success:** User upgrades → toast «ارتقا به Pro انجام شد» + redirect to Dashboard.

### Accessibility
- Plan cards: semantic structure with `<h3>` for plan name.
- Feature list: `<ul>` with `<li>`, icons `aria-hidden`.
- CTAs: descriptive `aria-label`.
- Cancel confirmation: `role="alertdialog"`.

---

## 22. Notifications (future-ready)

### Purpose
Notification center — in-app alerts for analysis completion, billing events, feature announcements.

### Engine dependency
Future: `GET /api/v1/notifications`, `PATCH /api/v1/notifications/{id}/read`.

### Phase status
Future-ready.

### Layout

**Mobile (375px):**
```
┌─────────────────────────────────────┐
│ [☰]  اعلان‌ها              [⌘K][☀][فا]  │
├─────────────────────────────────────┤
│  اعلان‌ها                             │ ← --text-h1
│  [علامت‌گذاری همه به‌عنوان خوانده‌شده]   │ ← mark all read link
│                                      │
│  ┌─────────────────────────────┐    │ ← NotificationCard (unread)
│  │ [✓] تحلیل کامل شد             │    │   bg tinted (unread)
│  │ trades_jan.csv آماده است.     │    │
│  │ ۵ دقیقه پیش                    │    │
│  │ [مشاهده →]                     │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │ ← NotificationCard (read)
│  │ [💳] فاکتور جدید               │    │   bg normal
│  │ فاکتور خرداد آماده است.        │    │
│  │ ۲ روز پیش                      │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ [✨] ویژگی جدید                │    │
│  │ حالا می‌توانید...               │    │
│  │ ۱ هفته پیش                     │    │
│  └─────────────────────────────┘    │
│                                      │
│  ───ـ قدیمی‌تر ───ـ                   │
│  (collapsed older notifications)     │
└─────────────────────────────────────┘
```

**Desktop (≥1024px):**
Same layout, max-width 640px centered. Optional: filter sidebar (All / Unread / Billing / System).

### Visual Hierarchy
1. **Page title + mark all read** — controls.
2. **Notification cards (newest first)** — the content.
3. **Older section (collapsed)** — archive.

### Component Placement
- **Page header:** Title + mark-all-read link.
- **Filter (desktop):** Left rail or top pills.
- **NotificationCards:** Stacked, newest first. Unread: tinted bg + dot indicator.
- **Older section:** Collapsed, «نمایش قدیمی‌تر» button.

### Cards
- **NotificationCards:** `--bg-elevated` (read) or `--bg-surface` (unread, tinted), `--elevation-2`, `--radius-lg`, `--space-4` padding. Each: icon, title, description, timestamp, optional CTA. Unread: blue dot on inline-start.

### Tables
None.

### Charts
None.

### Interactions
- **Click notification** → mark as read + navigate to relevant page (e.g., analysis completion → Dashboard).
- **Click «علامت‌گذاری همه به‌عنوان خوانده‌شده»** → mark all read, cards transition to read state.
- **Click CTA in notification** → navigate to target.
- **Swipe left (mobile) on notification** → dismiss/archive.
- **«نمایش قدیمی‌تر»** → reveal older notifications.

### Hover States
- **NotificationCards:** `--elevation-2` → `--elevation-3`, 200ms.
- **Mark all read link:** `--fg-secondary` → `--accent-primary`, 200ms.
- **CTA in notification:** `--fg-secondary` → `--accent-primary`, 200ms.

### Responsive Behavior
| Breakpoint | Layout |
|---|---|
| `< sm` (375px) | Single column, swipe to dismiss |
| `sm` to `< md` | Same as mobile |
| `md` to `< lg` (768px) | Optional filter sidebar |
| `≥ lg` (1024px+) | Filter sidebar + max-width 640px content |

### Micro-interactions
- **New notification appears:** slide-in from top + fade, 250ms.
- **Mark as read:** bg transition (tinted → normal), dot fades out, 300ms.
- **Swipe to dismiss (mobile):** card slides out + fade, 200ms.
- **«نمایش قدیمی‌تر»:** additional cards slide-down + fade, staggered 80ms.

### States
- **Loading:** 5 skeleton notification cards.
- **Empty (no notifications):** Illustration + «اعلانی موجود نیست».
- **Error:** Standard error card + retry.
- **Success:** User reads notifications, marks as read.

### Accessibility
- Notification cards: `role="listitem"` in `<ul>`.
- Unread indicator: `aria-label="خوانده‌نشده"`.
- Mark all read: `aria-label="علامت‌گذاری همه به‌عنوان خوانده‌شده"`.
- Timestamp: `<time>` element with `datetime`.

---

# Part J — Cross-Screen Patterns & Phase 5 Prep

---

## 23. Cross-Screen Interaction Patterns

Patterns that apply across multiple screens, documented once here for consistency.

### 23.1 Page transition (all navigations)
- **Trigger:** User clicks nav item, card, or CTA.
- **Response:** Overlay slide-down (400ms) → content swap → overlay slide-up (400ms), `--ease-in-out`. Total 500ms.
- **Reduced-motion:** Instant swap, no overlay.
- **Loading state:** If destination data fetch outlasts overlay, show lightweight loading indicator.

### 23.2 Data fetching (all analysis pages)
- **Pattern:** Server Component fetches via BFF Route Handler → V23 API. Skeleton shown during fetch. Content fades in on arrival.
- **Skeleton:** Matches final layout shape exactly (no layout shift). Pulse animation (frozen if reduced-motion).
- **Error:** Error card replaces content + retry button.
- **Success:** Skeleton fade-out (100ms) + content fade-in (200ms).

### 23.3 Card hover (interactive cards on all screens)
- **Default:** `--elevation-2`, `--border-subtle`.
- **Hover:** `--elevation-3`, border `--accent-primary` (or severity color for severity-bordered), cursor pointer.
- **Transition:** 200ms `--ease-out`.
- **Press:** scale 0.98, 100ms.

### 23.4 Severity indicators (all screens with engine data)
- **Color:** `--severity-low` (green), `--severity-medium` (amber), `--severity-high` (orange), `--severity-critical` (red).
- **Always paired with:** text label («بحرانی», «بالا», «متوسط», «پایین») + icon (CheckCircle, Warning, WarningOctagon, XCircle).
- **Never color alone.**

### 23.5 Number display (all screens with data)
- **Font:** `--font-mono` (Fira Code).
- **Numerals:** Latin (0123456789) in mono data fields, Persian (۰۱۲۳۴۵۶۷۸۹) in prose.
- **Currency:** `$` prefix, thousand separators, 2 decimals for small amounts, 0 decimals for large.
- **Percentages:** 1 decimal (e.g., `۵۲.۳٪`).
- **Dates:** Shamsi (`۱۴۰۴/۰۴/۲۰`) in Persian UI, Gregorian (`2025-07-11`) in English UI.

### 23.6 Empty states (all screens)
- **Pattern:** Illustration (120×120 SVG) + headline (`--text-h3`) + description (`--text-body-sm`) + CTA (primary button).
- **Tone:** Calm, non-judgmental. «هنوز تحلیلی انجام نداده‌اید» (not «خطا: داده‌ای موجود نیست»).
- **CTA:** Always actionable — guides user forward.

### 23.7 Error states (all screens)
- **Pattern:** Icon + headline + description + retry/alternative CTA.
- **Tone:** Specific, actionable, non-judgmental.
- **Color:** `--severity-critical` for icon, `--fg-primary` for text.
- **Recovery:** Always provide a path forward (retry, go back, alternative).

### 23.8 Loading states (all screens)
- **Skeleton:** Matches final shape. Pulse 1.5s (frozen if reduced-motion).
- **Button loading:** Spinner + verb-led text («در حال آپلود...», «در حال ذخیره...»).
- **Page loading:** Full-page skeleton of page structure.
- **Inline loading:** Just the refreshing component shows skeleton; rest of page stays interactive.

---

## 24. Phase 5 Implementation Kickoff

### 24.1 Implementation order (from Phase 3 §40.6, reinforced)

1. **Token system** (`tokens.json`, CSS variables, Tailwind config, TS constants).
2. **Typography** (next/font: Vazirmatn + Fira Code + Fira Sans).
3. **Primitives**: Button, Input, Badge, Icon, Tooltip.
4. **Layout**: Card, Container, Grid, Sidebar, TopBar, BottomTabBar.
5. **Feedback**: Toast, Skeleton, EmptyState, ErrorState, ProgressIndicator.
6. **Composite**: ScoreGauge, SeverityBadge, EvidenceCard, RecommendationCard, ContextBlockCard, StatCard.
7. **🔴 Dashboard (HIGHEST PRIORITY PAGE)** — build the 4 emotional-center cards. Verify 375 × 667 fit immediately.
8. **Upload + Analysis Progress** — entry flow.
9. **Remaining Tier 2 pages**: Behavioral, Diagnosis, Coaching.
10. **Tier 3 pages**: Trader DNA, Edge Map, Charts, Trade Explorer (+ trades API), Trends, Overview, Performance Analysis, Risk Analysis, Trade Detail.
11. **Tier 4**: Report Center.
12. **Settings stub.**
13. **Public pages**: Landing, Sample Report.
14. **Future-ready screens** (behind feature flag): Authentication, Profile, Subscription, Notifications.

### 24.2 Acceptance criteria

Phase 5 implementation is complete when:
- All 20 screens in this document are implemented and match the specs.
- The Pre-Phase-4 Validation Checklist (Phase 3 §43) passes — all 80+ items.
- The Phase 2 §9 Pre-Phase-3 Validation Checklist passes — all 83 items.
- Dashboard 4 emotional-center cards fit above fold on 375 × 667 (V-DASH-1).
- All screens tested at 375 / 768 / 1024 / 1280 / 1536px.
- RTL verified independently.
- WCAG AA verified (axe-core + manual).
- Lighthouse performance ≥ 90 on mobile.

### 24.3 What this document does NOT specify (Phase 5+ scope)

- **Implementation code** — this document is design-only. Phase 5 writes the code.
- **API implementation details** — Phase 2 §5.1 specifies the Trade Explorer endpoint; V23 API documentation covers the rest.
- **Content/copywriting** — Persian/English copy finalized during implementation.
- **Illustration assets** — filenames specified (§12.3); actual SVGs created during implementation.
- **Brand assets** — logo refinement, if any, separate from this scope.

---

## 25. Changes Summary

### 25.1 What this document delivers (v1.0)

| # | Deliverable | Screens |
|---|---|---|
| 1 | Landing Page — full premium SaaS landing | §3 |
| 2 | Authentication — sign in/up, future-ready | §4 |
| 3 | Dashboard — emotional center, 4 cards above fold on 375px | §7 |
| 4 | CSV Upload — multi-format ingest | §5 |
| 5 | Analysis Progress — honest, LLM-aware progress | §6 |
| 6 | Overview — comprehensive metrics view | §8 |
| 7 | Performance Analysis — financial deep-dive | §9 |
| 8 | Risk Analysis — risk deep-dive | §10 |
| 9 | Behavior Analysis — 5 behavioral scores | §11 |
| 10 | Psychology Analysis — Trader DNA archetype | §12 |
| 11 | AI Coach — action plan + AI narrative | §13 |
| 12 | Trade Explorer — trade-level data browsing | §14 |
| 13 | Trade Detail — full-screen trade view | §15 |
| 14 | Evidence Explorer — diagnosis + evidence | §16 |
| 15 | Report Center — HTML/PDF download + preview | §17 |
| 16 | History — paginated past analyses | §18 |
| 17 | Settings — theme, language, future-ready | §19 |
| 18 | Profile — user profile (future-ready) | §20 |
| 19 | Subscription — plan comparison (future-ready) | §21 |
| 20 | Notifications — notification center (future-ready) | §22 |

### 25.2 IA reconciliation (6 additional screens)

| Screen | Status | Engine impact |
|---|---|---|
| Authentication | Future-ready (Phase 2 §2.2) | None (future API endpoints) |
| Overview | Enhanced deep-dive | None (consumes existing `performance`, `statistics`, `scores`) |
| Performance Analysis | Enhanced deep-dive | None (consumes existing `performance`, `statistics`, `appendix.performance_raw`) |
| Risk Analysis | Enhanced deep-dive | None (consumes existing `risk`, `behavior_analysis`) |
| Trade Detail | Enhanced deep-dive | None (single trade from `/trades` endpoint) |
| Profile | Future-ready | None (future API) |
| Subscription | Future-ready (Phase 2 §2.11) | None (future API) |
| Notifications | Future-ready | None (future API) |

**No engine changes. No invented analytics. All new screens consume existing V23 outputs.**

### 25.3 Hard constraints preserved

- ✅ **Dashboard emotional center:** 4 cards above fold on 375 × 667 (verified math: 538px content + 56px top bar = 594px, 73px buffer).
- ✅ **Mobile-first:** Every screen designed mobile-first, enhanced for tablet/desktop.
- ✅ **Persian-first RTL:** All screens use logical CSS properties, Vazirmatn + Fira Code, Shamsi calendar, Persian numerals in prose.
- ✅ **Engine untouched:** All screens consume V23 API outputs. Only addition is the already-flagged `GET /analyses/{id}/trades` (Phase 2 §5.1, serialization-only).
- ✅ **Clarity > Complexity:** One primary action per screen, progressive disclosure, top-3 defaults.
- ✅ **Actionability > Information Density:** Every screen ends with a clear next step.
- ✅ **Premium SaaS quality:** Linear/Stripe/Vercel/TradingView-tier polish — generous whitespace, restrained color, mono numerics, subtle motion, honest states.

### 25.4 Compatibility

This v1.0 screen design is **fully compatible** with:
- Phase 1 Product Strategy (approved).
- Phase 2 Visual Design + UX Architecture v1.2 (approved).
- Phase 3 Design System v1.1 (approved).
- V23 analytical engine (untouched).

---

**Document version:** v1.0
**Status:** For approval — gate for Phase 5 (Implementation Kickoff)
**Awaiting approval before Phase 5.**
