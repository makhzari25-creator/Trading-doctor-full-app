# Trading Doctor — Phase 2 UX Architecture & User Flows (v1.2 — Final Polish)

**Author:** Senior UX Architect
**Status:** For approval — gate for Phase 3 (Implementation)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Builds on:** Phase 1 IA (approved) · Phase 2 Visual Design System (approved)
**Design lens:** Every UX decision must reduce cognitive load.
**Document version:** v1.2 — see §12 (Final Changes Summary) for delta vs v1.1. Prior changes in §11 (v1.0 → v1.1).

> **Three Phase 1 refinements (carried as hard constraints — non-negotiable):**
> 1. Mobile-first & responsive by design — every flow designed simultaneously for Desktop / Tablet / Mobile.
> 2. Dashboard = emotional center — Overall Health · Biggest Leak · Biggest Strength · Immediate Next Action visible without scrolling on every breakpoint including 375 × 667.
> 3. Clarity > Complexity · Actionability > Information Density · Premium SaaS > Feature Quantity.

> **One API-layer flag (Trade Explorer — clarified in v1.1):**
> The V23 API exposes aggregate analysis but not trade-level rows. The `AnalysisRecord` in `api/services/store.py` already preserves `record.doctor.df` (the normalized DataFrame), so a single new endpoint `GET /api/v1/analyses/{id}/trades` can expose it with **zero engine changes** — this is API-layer serialization only, consistent with the existing pattern (same shape as `/report` endpoint). This is the only addition flagged by this document; it does not touch the analytical engine. See §2.8 and §5.1 for full specification.

> **Cross-reference system (since v1.1):**
> This document is one of three Phase 2 deliverables. A consolidated cross-reference map is provided in §8 (Master Phase 2 UX Specification — Cross-Reference System) to keep Phase 1, Visual Design, and this Architecture document in lockstep during Phase 3 implementation.

---

## 0. Phase 2 Master Specification Note (NEW in v1.2)

**Recommendation:** For Phase 3 (Implementation), the two Phase 2 documents — `phase2_ux_visual_design.md` ("how it looks") and `phase2_ux_architecture.md` (this document; "how it behaves") — should be **merged or heavily cross-linked into a single Master UX Specification** before engineering begins.

**Rationale:**
- Phase 3 engineers will need to reference both documents constantly. Switching between two files (Visual Design for tokens/components, Architecture for flows/states) introduces friction and risk of inconsistency.
- A single Master UX Spec — with a shared table of contents, unified terminology glossary, and one page-spec-per-page (combining visual + UX attributes) — eliminates ambiguity about which document is authoritative for any given decision.
- The cross-reference map in §8 of this document already maps every topic to its source; merging is a mechanical consolidation, not new design work.

**Suggested Master UX Spec structure:**
1. Design System (from Visual Design §2–§8: tokens, typography, spacing, icons, components, motion)
2. Accessibility & RTL (from Visual Design §9–§10)
3. Responsive Strategy (from Visual Design §11)
4. User Flows (from this document §2)
5. Per-Page Specifications (merge Visual Design §12 visual specs + this document §3 UX specs into one table per page)
6. Cross-Cutting Patterns (from this document §4)
7. Keyboard & Offline (from this document §6–§7)
8. API Integration (from this document §5)
9. Pre-Phase-3 Validation Checklist (from this document §9)

**Action:** Before Phase 3 kickoff, produce `phase2_master_ux_specification.md` by merging the two documents per the structure above. Keep the originals as archived references. This is a documentation task, not a design task — no new decisions needed.

**If merging is not feasible:** At minimum, add bidirectional hyperlinks between the two documents at every shared topic (use the §8 cross-reference map as the link table), and ensure both documents carry the same version number and change log.

---

## 1. UX Architecture Principles

Every flow and page in this document is filtered through six principles, in priority order.

### 1.1 Cognitive load reduction is the primary lens
A trading analyst's brain is already full — market data, indicators, positions, emotions. Trading Doctor must not add to that load. Every screen, every flow, every interaction is evaluated against: *does this make the user think?* If yes, redesign.

### 1.2 One question, one answer, one action per screen
Every page answers one named question (Phase 1 §13). Every screen offers one primary action. Secondary actions exist but never compete visually. The user always knows: *what am I looking at, and what should I do next?*

### 1.3 Progressive disclosure as default
Show the composite answer first. Reveal detail on demand. Never front-load complexity. The Dashboard shows 4 cards; the breakdown lives one click deeper. Evidence shows top 3; the rest behind "show more." What-if simulations collapsed by default.

### 1.4 Error prevention over error recovery
Better to prevent an error than to handle one. File validation before upload. Confirmation on destructive actions. Disabled CTAs until prerequisites are met. When errors do occur, they're actionable — never just reported.

### 1.5 Honesty about system state
No fake progress. No spinners pretending to work. If the API is synchronous (V23's `POST /analyses` blocks until done), the UI shows an honest "Analyzing…" state with the conceptual stages listed — it does not fake stage-by-stage transitions it can't detect. Time estimates are **smart** (LLM-aware) and honestly bounded (see §2.4). Trust is hard to rebuild once broken.

### 1.6 Mobile is the design floor, not the ceiling
Every flow is designed for 375px first. If a flow works on mobile, it works everywhere. The reverse is not true. Mobile constraints force clarity — a 375px viewport cannot lie about importance.

---

## 2. Complete User Flows

Twelve end-to-end flows. Each is specified as: **trigger → steps → decision points → success → error recovery**. Mobile-first notation: where steps differ by breakpoint, mobile is the base.

---

### 2.1 Onboarding Flow

**Purpose:** Turn a first-time visitor into someone who has run their first analysis and seen their Dashboard. No auth required (Phase 1).

**Trigger:** User lands on `/` (Home).

**Steps:**

1. **Land on Home.** User sees hero headline, subhead, two CTAs: «تحلیل معاملاتم را شروع کن» (primary, amber) and «گزارش نمونه ببین» (secondary, ghost).
2. **Decision point: which CTA?**
   - *Path A — "Analyze my trades" (primary path, ~70% of users):* → jump to Upload Flow (§2.3).
   - *Path B — "See sample report" (curiosity path, ~30%):* → navigate to `/sample`.
3. **Path B detail — Sample Report:**
   - User browses a fully-rendered demo analysis (read-only).
   - Scrolls through sections (Executive Summary → Performance → Behavioral → Diagnosis → Coaching → Evidence → Appendix).
   - Sees sticky bottom CTA: «این تحلیل را روی داده‌ی خودم انجام بدهم».
   - Clicks CTA → navigate to `/upload`.
4. **First-time hint overlays (one-time, dismissable):**
   - On first visit to Dashboard, a non-blocking tooltip points to the 4 emotional-center cards: «این ۴ کارت پاسخ سوالات اصلی شماست».
   - On first visit to Upload, a tooltip points to the dropzone: «فایل خروجی بروکر خود را اینجا بکشید».
   - Tooltips dismissed by tap-anywhere or "فهمیدم" button.
   - Dismissal state stored in `localStorage` (`td_onboarding_v1: { dashboard: true, upload: true, ... }`).
5. **Success:** User completes first analysis and lands on Dashboard. Onboarding complete.

**Error recovery:**
- If user lands on an internal page directly (e.g., shared link to `/dashboard/abc`), and no analysis context exists, redirect to Home with a soft toast: «برای شروع، ابتدا یک فایل آپلود کنید».

**Mobile considerations:**
- Hero is full-viewport on mobile (no above-the-fold competition).
- Tooltips appear as bottom sheets on mobile (not floating popovers) for readability.
- Sticky CTAs are thumb-reachable (bottom of screen).

**Cognitive load tactics:**
- Two CTAs only (not five). Reduces choice paralysis.
- Sample report lets users see the destination before committing effort.
- Tooltips are one-time — don't nag returning users.

---

### 2.2 Authentication Flow (Future-Ready — Phase 1 ships without auth)

**Purpose:** Designed for the future Registered/Pro/Mentor/Enterprise tiers (Phase 1 §11). Phase 1 ships Anonymous-only; this flow is documented so Phase 3+ implementation is a flip of a feature flag, not a redesign.

**Phase 1 behavior:** No auth UI visible. Settings page shows "Account (coming soon)" disabled section. API runs with `AUTH_ENABLED=false`.

**Future flow (when enabled):**

1. **Sign up** (`/signup`):
   - Fields: email, password, confirm password.
   - Optional: OAuth (Google, GitHub) — one-click buttons.
   - Validation: email format, password ≥8 chars with mixed case + number.
   - On submit: POST to `/api/v1/auth/signup` (future endpoint).
   - Success: send verification email, show "Check your inbox" screen.
   - Error: inline field-level errors (no generic "something went wrong").
2. **Email verification:**
   - User clicks link in email → `/verify?token=...`.
   - On success: session created, redirect to Dashboard (or onboarding if first time).
   - On error (expired/invalid token): "Resend email" CTA.
3. **Sign in** (`/signin`):
   - Fields: email, password.
   - "Forgot password?" link → `/forgot-password`.
   - On submit: POST `/api/v1/auth/signin`.
   - Success: session cookie set, redirect to Dashboard.
   - Error: "Invalid email or password" (deliberately generic — don't reveal which is wrong).
4. **Forgot password** (`/forgot-password`):
   - Field: email.
   - On submit: always show "If that email exists, we've sent a reset link" (don't reveal whether email is registered).
5. **Password reset** (`/reset-password?token=...`):
   - Fields: new password, confirm.
   - On success: redirect to sign-in with toast "Password reset — please sign in".
6. **Session management:**
   - Session cookie (httpOnly, secure, sameSite=lax).
   - Idle timeout: 30 days (sliding).
   - On session expiry: redirect to sign-in with return-to URL.
7. **Sign out:**
   - Account menu → "Sign out" → POST `/api/v1/auth/signout` → redirect to Home.
8. **Role-based access:**
   - After sign-in, user's role determines accessible features (Phase 1 §11).
   - Tier-2 items (Trends, Report) that were upgrade-gated for Anonymous become available.
   - Mentor/Enterprise tiers unlock Mentor Workspace / Team Dashboard.

**Error recovery:**
- All auth errors use inline field-level messages, never modal popups.
- Rate-limited sign-in attempts (5 per minute per IP) — show "Too many attempts, try again in X seconds."
- OAuth failure: fall back to email/password with toast "Google sign-in failed — please use email."

**Mobile considerations:**
- Auth forms are single-column, full-width inputs, large touch targets.
- Password fields have show/hide toggle (eye icon).
- OAuth buttons stacked above the email/password form, not below (mobile convention).

**Cognitive load tactics:**
- No "confirm email" interstitial after sign-up that blocks the user — they can browse anonymously while waiting for email.
- Forgot-password always returns the same message (no information leakage).
- Sign-in errors are generic (security > helpfulness here).

---

### 2.3 Upload Flow

**Purpose:** Ingest a trade history file, validate it, prepare for analysis.

**Trigger:** User clicks "Analyze my trades" on Home, or "Upload" in nav, or any CTA pointing to `/upload`.

**Steps:**

1. **Land on Upload page.**
   - Dropzone visible (dashed border, 200px tall on mobile, 240px on desktop).
   - Allowed formats text below: «پشتیبانی: CSV, XLSX, HTM, HTML, JSON, LOG, TXT — حداکثر ۲۵ مگابایت».
   - LLM provider `SegmentedControl` below dropzone (default: «بدون هوش مصنوعی»).
   - Primary CTA «شروع تحلیل» disabled (greyed) until valid file selected.
2. **Select file — two paths:**
   - *Path A — Drag & drop (desktop):* User drags file onto dropzone. Dropzone border becomes solid amber, background tints. On drop, file is registered.
   - *Path B — Click to browse (mobile + desktop):* User taps dropzone. Native file picker opens. User selects file. File is registered.
3. **Client-side validation (instant, before upload):**
   - File size ≤ 25MB? If no → inline error: «حجم فایل ۳۲ مگابایت است؛ حداکثر مجاز ۲۵ مگابایت». CTA stays disabled.
   - File extension in allowed list? If no → inline error: «فرمت .zip پشتیبانی نمی‌شود». CTA stays disabled.
   - If valid → show `FilePill` (filename, size, remove-X button). CTA «شروع تحلیل» becomes active (amber).
4. **Decision point: LLM provider.**
   - User can change default «بدون هوش مصنوعی» to Gemini/OpenAI/Claude.
   - Tooltip on each option explains tradeoff: «بدون هوش مصنوعی = سریع‌تر (زیر ۱۰ ثانیه)، توضیح الگوریتمی. Gemini/OpenAI/Claude = روایت غنی‌تر، تا ۳۰ ثانیه تأخیر بیشتر».
   - Selection stored in component state.
5. **User clicks «شروع تحلیل».**
   - CTA enters loading state: spinner + «در حال آپلود...».
   - File uploaded via `POST /uploads` (multipart).
   - On upload progress: `FilePill` shows progress bar.
6. **Upload success → `upload_id` received.**
   - UI transitions to Analysis Progress Flow (§2.4) automatically.
7. **Upload error recovery:**
   - *413 (too large):* shouldn't happen (client-side check), but handle: «حجم فایل بیش از حد مجاز است».
   - *422 (invalid content):* engine message displayed inline, e.g., «ستون سود/زیان در فایل شما پیدا نشد. مطمئن شوید خروجی بروکر شامل ستون Profit است». CTA «مشاهده فرمت‌های پشتیبانی‌شده» opens a help modal.
   - *Network error:* «اتصال به سرور برقرار نشد. دوباره تلاش کنید» + retry button.
   - On any error: file remains selected, user can retry without re-selecting.

**Success state:**
- File uploaded, `upload_id` obtained, automatic transition to Analysis Progress Flow.

**Mobile considerations:**
- Dropzone is full-width, thumb-reachable.
- Drag & drop not available on mobile (touch devices) — click-to-browse is the only path. Dropzone copy on mobile: «برای انتخاب فایل ضربه بزنید» (no "drag" mention).
- FilePill is full-width, single-line truncated filename.
- LLM SegmentedControl is horizontally scrollable on mobile (4 options don't fit comfortably).

**Cognitive load tactics:**
- CTA disabled until valid file — prevents the most common error (clicking before selecting).
- Client-side validation catches size/format errors instantly — no waiting for server round-trip.
- LLM provider defaults to "none" — users who don't care don't have to think about it. Tooltip surfaces the time tradeoff *before* the user commits (consistency with §2.4 smart time estimate).
- FilePill shows everything needed (name, size, remove) in one row — no nested menus.

---

### 2.4 Analysis Progress Flow (Updated in v1.1 — smart time estimation)

**Purpose:** Communicate that analysis is running, set honest expectations about timing, transition to Dashboard on completion.

**Trigger:** Upload Flow successfully obtains `upload_id`, then `POST /analyses` is fired.

**Critical honesty note (unchanged from v1.0):**
V23's `POST /analyses` is **synchronous** — it blocks until the full pipeline completes and returns `201 + AnalysisSummary`. The API does not stream stage-by-stage progress. The UI must be honest about this:

- The 6 stages are shown as a **conceptual list** ("here's what the engine is doing"), not as live-updating steps.
- A single "Analyzing…" indicator conveys the actual state.
- The UI does NOT fake stage transitions it cannot detect.

**Smart time estimation (new in v1.1):**
The time estimate shown to the user is now **LLM-aware**, derived from the `llm_provider` value sent to `POST /analyses`:

| LLM provider | Estimate shown to user | Rationale |
|---|---|---|
| `none` (default) | «معمولاً کمتر از ۱۰ ثانیه طول می‌کشد» / "Usually under 10 seconds" | V23 measured ~1s for 25k trades; padded for upload + serialization. |
| `gemini` / `openai` / `claude` | «ممکن است تا ۲۰–۳۰ ثانیه طول بکشد» / "May take up to 20–30 seconds" | Adds external LLM call latency for the `explainable_ai` paragraph. |

The estimate is shown as a **bounded range** ("up to 20–30 seconds"), not a false-precision single number. If the elapsed counter exceeds the upper bound (e.g., 35s with LLM), the UI shows a soft reassurance: «کمی بیشتر از حد انتظار طول می‌کشد — هنوز در حال تحلیل است» / "Taking a little longer than expected — still analyzing." This is honest (we don't know why it's slow) without alarming the user.

**Future enhancement (flagged, not Phase 1):** A `POST /analyses` returning `202 Accepted` + job ID, with `GET /analyses/{id}/status` for polling, would enable real-time stage updates. This is API-layer, not engine. For Phase 1, we ship the honest synchronous UI with smart time estimation.

**Steps:**

1. **Transition from Upload Flow.**
   - `POST /analyses` fired with `{upload_id, llm_provider}`.
   - Upload page content fades out (150ms).
   - Progress UI fades in (200ms): page title «در حال تحلیل...» + 6-stage list + animated indicator + smart time estimate.
2. **Progress UI (mobile-first):**
   - Page title: «در حال تحلیل معاملات شما».
   - Subtitle: filename + «۱٬۲۴۵ معامله» (trade count from upload response).
   - 6 stages listed vertically (mobile) / horizontally (desktop) with connector line:
     1. خواندن و نرمال‌سازی فایل (Reading & normalizing)
     2. اعتبارسنجی داده (Validating data)
     3. تحلیل رفتار (Analyzing behavior)
     4. محاسبه‌ی امتیازها و Impact دلاری (Computing scores & $ impact)
     5. تشخیص مشکل اصلی (Diagnosing primary issue)
     6. ساخت برنامه‌ی اقدام (Building action plan)
   - Each stage shows: stage number, stage name, conceptual icon (Phosphor).
   - All stages show a subtle pulsing dot (not checkmarks — we can't confirm individual completion).
   - Below stages: large indeterminate progress bar (animated stripe, frozen if reduced-motion).
   - Below bar: **smart time estimate** (LLM-aware, per table above) + elapsed counter «۰:۰۳».
   - Cancel button (X, top-right): «انصراف» — confirms, then returns to Upload with file still selected.
3. **Success — `201` response received:**
   - All stage dots flip to green checkmarks (✓) in a quick staggered animation (60ms per stage, 360ms total).
   - Progress bar fills to 100%.
   - Toast: «تحلیل کامل شد» (success, 1.5s).
   - 800ms delay (let the user see the success state).
   - Navigate to `/dashboard/{analysis_id}`.
4. **Error recovery:**
   - *422 (invalid data — e.g., no recognizable trading columns):* stay on progress page, show error card with engine message + «بازگشت به آپلود» CTA. File is preserved on Upload page for retry.
   - *500 (server error):* «خطای داخلی سرور. لطفاً دوباره تلاش کنید» + retry button (re-fires `POST /analyses` with same upload_id).
   - *Network timeout (60s, or 90s if LLM was selected — extended bound):* «تحلیل بیش از حد طول کشید. لطفاً دوباره تلاش کنید» + retry.
   - *Rate limited (429):* «تعداد درخواست‌ها بیش از حد مجاز است. یک دقیقه دیگر تلاش کنید» + countdown timer + auto-retry.

**Mobile considerations:**
- Stages stack vertically (mobile) — horizontal would cramp text.
- Elapsed counter uses mono font for scannability.
- Cancel button is in top bar (not inline) to avoid accidental taps.

**Cognitive load tactics:**
- 6 named stages tell the user *what* is happening — reduces "is it broken?" anxiety.
- Smart time estimate (LLM-aware) sets honest expectations — no false precision.
- Soft reassurance if elapsed exceeds estimate — acknowledges without alarming.
- Elapsed counter provides a sense of progress without faking stage transitions.
- Cancel option gives the user control — they're never trapped.
- Extended timeout (60s → 90s) when LLM is selected — matches the longer estimate; avoids premature timeout errors.

---

### 2.5 Dashboard Flow (Emotional Center)

**Purpose:** The post-analysis home. Deliver the 4 emotional answers in 5 seconds. Provide drill-down paths.

**Trigger:** Auto-navigate from Analysis Progress Flow, OR user clicks a History item, OR user clicks "Dashboard" in nav.

**Steps:**

1. **Land on Dashboard.**
   - Top bar: logo + current analysis badge (filename + trade count + date, clickable to open History in a drawer) + theme toggle + language toggle + account menu (future).
   - 4 emotional-center cards rendered above fold (Phase 2 Visual Design §12.5):
     - Overall Health (ScoreGauge 0–100 + severity word)
     - Biggest Leak (top evidence: label + $ impact + severity)
     - Biggest Strength (first strength: label + supporting metric)
     - Immediate Next Action (top recommendation: verb-led sentence + CTA)
   - Cards animate in with a staggered fade-up (100ms per card, 400ms total — frozen if reduced-motion).
   - ScoreGauge fills from 0 to value (600ms Expo.out).
2. **User absorbs the 4 answers (5 seconds).**
3. **Decision point: which card to drill into?**
   - *Click Overall Health* → `/behavioral/{id}` (Behavioral Analysis)
   - *Click Biggest Leak* → `/diagnosis/{id}` (Diagnosis, scrolled to that evidence)
   - *Click Biggest Strength* → `/edge-map/{id}` (Edge Map)
   - *Click Immediate Next Action CTA* → `/coaching/{id}` (Coaching)
4. **Below-fold exploration (user scrolls):**
   - Performance strip: 6 stat cards (Win Rate, Profit Factor, Max Drawdown, Total Trades, Avg Win, Avg Loss).
   - "Biggest leak" drill-down callout: top evidence with full description + «شواهد کامل را ببین» CTA → Diagnosis.
   - "What you'd save if you fixed it" callout: what-if simulation (e.g., «اگر معامله‌ی انتقامی را اصلاح می‌کردید، ۱٬۸۴۰ دلار بیشتر سود می‌کردید») + «جزئیات بیشتر» CTA → Behavioral.
   - Quick-jump tiles (2×2 on mobile, 1×4 on desktop): Behavioral · Diagnosis · Coaching · Edge Map. Each tile shows a one-line preview (e.g., «۳ رفتار نیاز به توجه دارد»).
   - Data quality warnings (collapsible, only if warnings exist): «۳ هشدار کیفیت داده» — expand to see each warning with explanation.
5. **Top-bar actions:**
   - Click analysis badge → drawer opens with History list (recent 5) + «مشاهده‌ی همه» → full History page.
   - Click «دانلود گزارش» (always visible in top bar on Desktop; in mobile overflow menu) → `/report/{id}`.
   - Click theme toggle → instant theme switch (no reload).
   - Click language toggle → instant language switch (no reload).
6. **Mobile bottom tab bar:**
   - 5 items: Dashboard (active) · Behavioral · Diagnosis · Coaching · Report.
   - "More" sheet (swipe up or tap) reveals: Trader DNA · Edge Map · Charts · **Trade Explorer** · Trends · History · Settings.

**Success state:**
- User understands their situation and clicks a drill-down card within 10 seconds.

**Empty state (shouldn't happen — Dashboard requires analysis context):**
- If user navigates to `/dashboard` without an analysis ID, redirect to `/upload` with toast «ابتدا یک فایل آپلود کنید».

**Error state:**
- If `GET /analyses/{id}/report` fails: error card replaces the 4 cards, with «تحلیل بارگذاری نشد» + retry button + «بازگشت به تاریخچه» link.

**Mobile considerations (375px layout — verified math, see §10.1):**
- 4 emotional-center cards stack vertically: 140 + 120 + 120 + 110px + 3×16px gaps = 538px content.
- With 56px top bar = 594px total above-fold height.
- iPhone SE viewport: 375 × 667px (CSS pixels, standard reference).
- Buffer: 667 − 594 = **73px** (accommodates iOS Safari's dynamic URL bar).
- Bottom tab bar (64px + safe-area-inset) is **below** the fold — correct, the 4 cards are the above-fold priority.
- **Confirmation (v1.2):** The 4 emotional-center cards fit comfortably on 375 × 667 with a 73px buffer — no scrolling required to see Overall Health, Biggest Leak, Biggest Strength, or Immediate Next Action. ✓

**Cognitive load tactics:**
- 4 cards = 4 questions = 4 answers. No more, no less.
- Each card is one tap away from its detail — no nested menus.
- Below-fold content is bonus, not required. User can leave after the 4 cards and still have value.
- Data quality warnings collapsed — transparent but not intrusive.

---

### 2.6 Report Exploration Flow

**Purpose:** Let the user browse the full structured report in-app, and download it as HTML or PDF.

**Trigger:** User clicks "Report" in nav, OR clicks «دانلود گزارش» in top bar, OR clicks «گزارش کامل را دانلود کن» CTA on Coaching page.

**Steps:**

1. **Land on Report page (`/report/{id}`).**
   - Top card: «گزارش شما آماده است» + 2 download buttons:
     - «دانلود PDF» (primary, amber, full-width on mobile) — triggers `GET /analyses/{id}/report.pdf`.
     - «دانلود HTML» (secondary, full-width on mobile) — triggers `GET /analyses/{id}/report.html`.
   - Section navigator (desktop: sticky left rail; mobile: horizontal scrollable pills): Executive Summary · Performance · Behavioral · Diagnosis · Coaching · Evidence · Appendix.
2. **Browse sections (in-app preview):**
   - Default: Executive Summary expanded; others collapsed.
   - Each section card: title + 2-line excerpt + chevron icon.
   - Tap/click section → expands with full content (rendered from `GET /analyses/{id}/report` JSON).
   - Only one section expanded at a time on mobile (accordion behavior); multiple allowed on desktop.
3. **Download PDF:**
   - Click «دانلود PDF» → button enters loading state (spinner + «در حال آماده‌سازی...»).
   - Browser handles download (filename: `trading_doctor_report_{date}.pdf`).
   - On completion: toast «گزارش PDF دانلود شد» (success, 3s).
4. **Download HTML:**
   - Same pattern. HTML opens in new tab OR downloads (browser-dependent; we set `Content-Disposition` appropriately via the API).
5. **Print alternative:**
   - «چاپ» button (secondary) → opens browser print dialog. User can save as PDF from there if they prefer.
6. **Navigate sections:**
   - Click section pill (mobile) or section in left rail (desktop) → smooth-scroll to that section + auto-expand it.

**Success state:**
- User downloads PDF or HTML. Toast confirms.
- OR user browses sections in-app and finds what they need.

**Empty state:**
- If report not yet generated (analysis still running — shouldn't happen on this page): skeleton of section cards.

**Error state:**
- PDF generation fails (500): «تولید PDF ناموفق بود. لطفاً دوباره تلاش کنید» + retry. HTML fallback offered: «یا گزارش HTML را امتحان کنید».
- HTML generation fails: same pattern with PDF fallback.
- Analysis not found (404): «تحلیل یافت نشد» + «بازگشت به تاریخچه».

**Mobile considerations:**
- Download buttons stack vertically (full-width).
- Section pills horizontally scrollable (no wrap — saves vertical space).
- Section content in narrow container (640px max) for readability.

**Cognitive load tactics:**
- Two clear download options (PDF for printing/sharing, HTML for archiving) — not five.
- Section accordion prevents information overload — user sees one section at a time on mobile.
- Print button is secondary — most users want PDF, not print dialog confusion.

---

### 2.7 AI Coach Flow

**Purpose:** Deliver the prioritized action plan + AI-generated coaching narrative + reality check. Turn insight into action.

**Trigger:** User clicks "Coaching" in nav, OR clicks Immediate Next Action CTA on Dashboard, OR clicks «برنامه‌ی اقدام را ببین» on Diagnosis.

**Steps:**

1. **Land on Coaching page (`/coaching/{id}`).**
   - Page title: «برنامه‌ی اقدام».
   - Subtitle: «۳ گام برای این هفته» (or whatever the top-3 count is).
   - Top-3 `RecommendationCard`s visible:
     - Each card: priority chip (P1/P2/P3) + issue label + action text (verb-led, e.g., «بعد از هر باخت، ۳۰ دقیقه استراحت کن») + chevron.
     - P1 card has severity-colored left border (RTL: right) matching the underlying evidence severity.
   - Below cards: «نمایش گام‌های بیشتر» button (if >3 recommendations exist).
2. **Expand a recommendation:**
   - Tap card → expands with rationale (2–3 sentences explaining *why* this action, tied to the evidence) + «انجام شد» toggle (visual only in Phase 1).
   - Only one expanded at a time on mobile; multiple on desktop.
3. **Mark as done (Phase 1: visual only):**
   - Toggle «انجام شد» → card gets a subtle strikethrough + green check icon.
   - State stored in `localStorage` (per analysis ID + recommendation index). Phase 1: visual feedback only. Future: persists to user profile.
   - If user returns to the page later (same session), state is preserved.
4. **Show more recommendations:**
   - Click «نمایش گام‌های بیشتر» → remaining recommendations (up to 5 more, total 8) slide in with staggered animation.
   - Button text changes to «نمایش کمتر».
5. **AI Coaching narrative section (below recommendations):**
   - Card with `Lightbulb` icon + header «روانشناسی این برنامه».
   - Body: `ai_coaching.explainable_ai` text (long-form, narrow container 640px for readability, 1.6 line-height).
   - Badge above text:
     - If LLM provider was "none": «توضیح الگوریتمی» (grey badge) + tooltip: «این توضیح توسط الگوریتم تولید شده است. برای روایت غنی‌تر، تحلیل را با هوش مصنوعی اجرا کنید».
     - If LLM provider was set: «توضیح هوش مصنوعی» (accent badge).
6. **Reality check section:**
   - Card with `Info` icon + header «واقعیت‌بینی».
   - Body: `ai_coaching.reality_check` text.
   - Tone: grounded, non-judgmental. Visually distinct from AI Coaching (different background tint).
7. **Bottom CTA:**
   - «گزارش کامل را دانلود کن» (secondary) → `/report/{id}`.

**Success state:**
- User reads the top-3 recommendations, marks one as done, and leaves with a clear next step.

**Empty state:**
- If `recommendations[]` is empty (rare — engine always produces action plan if there's evidence): «برنامه‌ی اقدام در دسترس نیست. ابتدا تحلیل را کامل کنید» + CTA to Dashboard.
- If `ai_coaching.explainable_ai` is empty: hide the AI Coaching card entirely (don't show empty card).

**Error state:**
- Fetch error: standard error card + retry.

**Mobile considerations:**
- Cards stack vertically, full-width.
- Long-form text in narrow container (640px) even on wider screens — aids readability.
- «انجام شد» toggle is a large touch target (44pt) on the right side of each expanded card.

**Cognitive load tactics:**
- Top-3 only by default — working memory limit (~5 items, leave room for 2 in context).
- Each action is verb-led — «do this», not «consider this».
- Rationale is collapsed — available if curious, not forced.
- AI Coaching and Reality Check are visually distinct — user knows which is which.
- "Mark as done" gives a sense of progress and agency.

---

### 2.8 Trade Explorer Flow (clarified in v1.1 — Tier 3 Deep Dive)

**Purpose:** Let the user browse the normalized trade-level data, filter and sort, and inspect individual trades. This is the "raw data" explorer for users who want to verify the engine's findings against their own trade history.

> **API flag (clarified in v1.1):** This flow requires a single new endpoint `GET /api/v1/analyses/{id}/trades` that returns `record.doctor.df` (the normalized DataFrame) as JSON. The data already exists in memory (`api/services/store.py` preserves `record.doctor`). This endpoint serializes the DataFrame using pandas' `.to_dict(orient='records')` with ISO date formatting — **no engine logic, no recomputation, no scoring**. It is API-layer only, consistent with the existing `/report` endpoint pattern (which also reads from `record.*` without recomputing). The endpoint supports query params for pagination (`?page=1&page_size=50`) and basic presentational filtering (`?side=long&outcome=win`) to avoid sending huge payloads for large datasets. Full implementation sketch in §5.1. Test enforcement in §5.1.4.
>
> **This is the ONLY API-layer addition flagged by Phase 2.** It does not touch the analytical engine. The engine's `BehaviorEngine`, `ScoreEngine`, `CoachingEngine`, and all other analytical code remain byte-for-byte unchanged.

**Nav placement (Phase 1 §8 update — see §10.2 of this document):** Tier 3 (Deep Dive), positioned between Charts and Trends. Phosphor icon: `Table` or `ListBullets`. Sidebar position 8 (Charts moves to 7, Trends to 9, etc. — see updated table in §10.2).

**Trigger:** User clicks "Trade Explorer" in nav (new nav item), OR clicks «مشاهده‌ی معاملات خام» on the Charts page, OR clicks «مشاهده‌ی معاملات مرتبط» on an Evidence card (Diagnosis page).

**Steps:**

1. **Land on Trade Explorer page (`/trades/{id}`).**
   - Page title: «کاوش معاملات».
   - Subtitle: «۱٬۲۴۵ معامله · نمایش به‌صورت جدول».
   - Filter bar (top, collapsible on mobile):
     - Date range picker (from/to — Shamsi calendar in Persian UI).
     - Side filter: «همه» / «خرید (Long)» / «فروش (Short)» — SegmentedControl.
     - Outcome filter: «همه» / «سودده» / «زیان‌ده» — SegmentedControl.
     - Size range (min/max) — two number inputs.
   - Sort dropdown: «تاریخ (قدیمی→جدید)» (default) | «تاریخ (جدید→قدیمی)» | «سود (بیشترین)» | «سود (کمترین)» | «حجم (بیشترین)».
   - «اعمال فیلترها» button (applies filters) + «پاک کردن فیلترها» ghost button.
2. **Trade table (`DataTable`):**
   - Columns: # | Open Time | Side | Size | Profit | Hour | Weekday.
   - Mobile: table becomes card list — each card shows: date + side icon + size + profit (large, colored).
   - Desktop: full table with sortable column headers (click to sort).
   - Pagination: «مورد ۱–۵۰ از ۱٬۲۴۵» + «قبلی» / «بعدی» buttons + page-size selector (50/100/200).
3. **Aggregate stats bar (above table, updates with filters):**
   - «نمایش: ۸۷ معامله» (filtered count).
   - 4 mini-stats: Total P&L · Win Rate · Avg Size · Largest Win/Loss.
   - These are **client-computed** from the filtered set — they are presentational, not analytical (the engine's authoritative scores remain unchanged).
4. **Click a trade (row on desktop, card on mobile):**
   - Drawer slides in from the side (desktop) / bottom sheet slides up (mobile).
   - Shows all columns for that trade: Open Time (full timestamp), Side, Size, Profit, Profit (formatted $), Hour, Weekday, Date, plus any other normalized columns present.
   - «بستن» button or swipe-down to dismiss.
5. **Export filtered trades:**
   - «خروجی CSV» button — downloads the current filtered set as CSV (client-side generation from in-memory data).
   - Useful for users who want to take a subset to Excel.

**Success state:**
- User filters to a specific time range or side, sees the relevant trades, and confirms (or refutes) the engine's findings.

**Empty state:**
- No trades match filters: «هیچ معامله‌ای با این فیلترها یافت نشد» + «پاک کردن فیلترها» CTA.
- No trades at all (analysis somehow has empty df — shouldn't happen): «داده‌ی معامله‌ای موجود نیست» + CTA to Dashboard.

**Error state:**
- Fetch error: standard error card + retry.
- 404 (analysis not found): «تحلیل یافت نشد» + CTA to History.

**Mobile considerations:**
- Filter bar collapses into a «فیلترها» button that opens a bottom sheet.
- Table is replaced by card list on mobile (each card = one trade).
- Drawer becomes full-screen bottom sheet on mobile.
- Pagination becomes «بعدی» / «قبلی» + page indicator.

**Cognitive load tactics:**
- Default view is unfiltered, sorted by date — familiar to anyone who's seen a broker statement.
- Filters are optional — users who don't need them never see them (collapsed on mobile).
- Aggregate stats update live with filters — instant feedback.
- One trade per drawer — focus, not split attention.
- CSV export for power users — doesn't clutter the main view.

**Why this flow respects the engine constraint:**
The new endpoint serializes `record.doctor.df` — data the engine already produced. It does not recompute scores, thresholds, or diagnoses. It does not call any engine method beyond accessing the preserved DataFrame. The analytical engine is untouched.

---

### 2.9 Evidence Explorer Flow

**Purpose:** Let the user explore the prioritized evidence behind their diagnosis. Understand *why* the engine concluded what it concluded.

**Trigger:** User clicks "Diagnosis" in nav, OR clicks Biggest Leak card on Dashboard, OR clicks «شواهد این رفتار» on Behavioral Analysis.

**Steps:**

1. **Land on Diagnosis page (`/diagnosis/{id}`).**
   - Page title: «تشخیص».
   - Primary diagnosis card (full-width, severity-colored border):
     - Label: «مشکل اصلی».
     - Diagnosis text (large, bold): e.g., «معامله‌ی انتقامی پس از باخت‌های پیاپی».
     - Severity badge.
     - Detail text: `diagnosis.primary_detail` (3–4 lines).
   - Secondary diagnosis card (if exists, below primary):
     - Label: «مشکل ثانویه».
     - Diagnosis text + brief detail.
2. **Evidence section:**
   - Section title: «شواهد» + count badge (e.g., «۸ شاهد»).
   - Filter/sort bar (collapsible on mobile):
     - Filter by severity: «همه» / «بحرانی» / «بالا» / «متوسط» / «پایین» — pill toggle.
     - Filter by type: dropdown of unique evidence types present (e.g., Revenge, Overtrading, Risk, Patience, Emotional).
     - Sort by: «اولویت (بیشترین)» (default) | «تأثیر دلاری (بیشترین)» | «فرکانس (بیشترین)».
   - Top-3 evidence `EvidenceCard`s visible by default:
     - Each card: type icon + label + severity badge + frequency («۱۲ بار») + $ impact («۱٬۸۴۰ دلار») + chevron.
     - Severity-colored left border (RTL: right).
   - «نمایش همه‌ی شواهد» button → reveals remaining 5 evidence cards with staggered animation.
3. **Expand an evidence card:**
   - Tap card → expands with:
     - Full description (`evidence.description`).
     - Confidence score: «اطمینان: ۸۵٪» with a mini progress bar.
     - Priority score: «اولویت: ۹۲/۱۰۰».
     - «مشاهده‌ی معاملات مرتبط» CTA → `/trades/{id}?evidence={type}` (Trade Explorer, pre-filtered — requires the trades endpoint from §2.8/§5.1).
   - Only one expanded at a time on mobile; multiple on desktop.
4. **Bottom CTA:**
   - «برنامه‌ی اقدام را ببین» → `/coaching/{id}`.

**Success state:**
- User reads primary diagnosis, scans top-3 evidence, and understands the *why* behind the diagnosis.

**Empty state:**
- If `evidence[]` is empty (engine found no notable patterns): hide evidence section, show only diagnosis card with «الگوی رفتاری برجسته‌ای شناسایی نشد» + CTA to Dashboard.
- If no secondary diagnosis: hide secondary card (no empty state).

**Error state:**
- Fetch error: standard error card + retry.

**Mobile considerations:**
- Cards stack vertically, full-width.
- Filter bar collapses into «فیلترها» bottom sheet.
- Expanded card content in narrow container for readability.

**Cognitive load tactics:**
- Primary diagnosis first, evidence second — answer before explanation.
- Top-3 evidence by default — most users don't need all 8.
- Severity colors + icons — scannable without reading every card.
- Confidence and priority scores — build trust through transparency.
- Filters are collapsed — power users can drill, casual users aren't overwhelmed.

---

### 2.10 Settings Flow (Phase 1 Stub)

**Purpose:** Let the user customize appearance and language. Future-ready for account, billing, API keys.

**Trigger:** User clicks "Settings" in nav (bottom of sidebar, or in mobile "More" sheet).

**Steps:**

1. **Land on Settings page (`/settings`).**
   - Page title: «تنظیمات».
   - Single column, max-width 640px, centered.
2. **Appearance section (functional in Phase 1):**
   - Theme toggle: «روشن» / «تیره» / «سیستم» — SegmentedControl. Instant switch, persisted in `localStorage`.
   - Density toggle: «راحت» / «فشرده» — SegmentedControl. Visual only in Phase 1 (affects spacing tokens — future: full implementation).
3. **Language section (functional in Phase 1):**
   - Language toggle: «فارسی» / «English» — SegmentedControl. Instant switch, persisted in `localStorage`.
4. **About section (informational):**
   - App version: «Trading Doctor Web 1.0.0».
   - Engine version: «Trading Doctor V23 — Phase 4» (from `GET /config` or hardcoded).
   - Link to documentation (future).
   - «پاک کردن همه‌ی داده‌ها» button (destructive) — clears `localStorage` (theme, language, onboarding state, "mark as done" states, cached analysis). Confirmation modal: «همه‌ی تنظیمات و داده‌ی محلی پاک می‌شود. ادامه می‌دهید؟» → «پاک کن» / «انصراف».
5. **Future sections (visible but disabled, with «به‌زودی» badge):**
   - Account (sign-in, profile, email).
   - API Keys (for power users who want to use their own LLM keys).
   - Notifications (future alerts).
   - Subscription (future billing).
   - Mentor Workspace (future tier).
6. **Offline cache section (future-ready, visible but informational in Phase 1):**
   - Toggle: «ذخیره‌ی تحلیل آخر به‌صورت محلی (آفلاین)» — disabled with «به‌زودی» badge.
   - Tooltip: «با این گزینه، آخرین تحلیل شما در مرورگر ذخیره می‌شود تا در صورت قطع اینترنت همچنان قابل مشاهده باشد.»
   - See §8 (Offline Handling) for the future design.

**Success state:**
- User changes theme or language, sees instant result, leaves.

**Empty state:** N/A (Settings always has content).

**Error state:** N/A (Settings is client-side in Phase 1).

**Mobile considerations:**
- Single column, full-width.
- SegmentedControls are full-width.
- Destructive button («پاک کردن») is at the bottom, requires confirmation.

**Cognitive load tactics:**
- Only 3 functional sections in Phase 1 — no overwhelm.
- Future sections are visible but clearly marked «به‌زودی» — no anxiety about "missing" features.
- Theme/language switches are instant — no "save" button needed.
- Destructive action requires confirmation — error prevention.

---

### 2.11 Subscription Flow (Future-Ready — Phase 1 ships without billing)

**Purpose:** Designed for the future Pro/Mentor/Enterprise tiers. Phase 1 has no billing; this flow is documented so future implementation is additive.

**Phase 1 behavior:** No subscription UI visible. Settings shows "Subscription (coming soon)" disabled section.

**Future flow (when enabled):**

1. **View current plan** (`/settings/subscription` or accessible from Settings):
   - Current plan badge: «رایگان» / «Pro» / «Mentor» / «Enterprise».
   - Current usage: «۳ از ۵ تحلیل استفاده شده» (for free tier with cap).
   - Renewal date (for paid tiers).
2. **Compare plans** (`/pricing` — public page):
   - 4-tier comparison table: Free / Pro / Mentor / Enterprise.
   - Feature matrix: max analyses, history retention, PDF watermark, Trends access, mentor seats, SSO, etc.
   - «ارتقا به Pro» CTA on each tier (except current).
3. **Upgrade flow:**
   - Select plan → `/checkout?plan=pro`.
   - Payment method: credit card (Stripe Elements) or regional gateway (future).
   - Billing cycle: monthly / annual (annual gets ~20% discount).
   - Review order → «پرداخت».
   - On success: session updated with new role, redirect to Dashboard with toast «ارتقا به Pro انجام شد».
   - On failure: inline error from payment provider, no partial state.
4. **Manage subscription:**
   - Change billing cycle (monthly ↔ annual).
   - Update payment method.
   - Cancel subscription (downgrade to Free at end of billing period — not immediate).
   - Download invoices.
5. **Downgrade flow:**
   - Cancel → confirmation: «اشتراک شما تا پایان دوره فعال می‌ماند. پس از آن به طرح رایگان باز می‌گردید.» → «تأیید» / «انصراف».
   - No guilt-trip modals. No "are you sure you want to lose these features?" dark patterns.

**Error recovery:**
- Payment failure: inline error, retry without leaving checkout.
- Webhook delay (payment succeeded but role not updated): «پرداخت شما دریافت شد. ممکن است چند دقیقه طول بکشد تا اشتراک شما فعال شود.» + refresh button.

**Mobile considerations:**
- Pricing table becomes stacked cards on mobile (one per tier).
- Checkout is single-column, large inputs.
- Payment keyboard shows numeric keypad for card number.

**Cognitive load tactics:**
- 4 tiers only — not 7.
- Feature matrix uses checkmarks/X, not paragraphs.
- No hidden fees — billing cycle and total clearly stated.
- Cancellation is straightforward — no dark patterns (Phase 1 §16 SaaS principle).

---

### 2.12 History & Return Flow (Cross-cutting)

**Purpose:** Let users return to past analyses and re-open them. This is the retention mechanism.

**Trigger:** User clicks "History" in nav, OR clicks the analysis badge in top bar, OR navigates to `/history`.

**Steps:**

1. **Land on History page (`/history`).**
   - Page title: «تاریخچه‌ی تحلیل‌ها» + count badge.
   - Filter/sort bar:
     - Time filter: «همه» / «این ماه» / «۳ ماه اخیر» — SegmentedControl.
     - Sort: «جدیدترین» (default) | «قدیمی‌ترین» | «بالاترین امتیاز» | «پایین‌ترین امتیاز».
2. **List of past analyses:**
   - Each `HistoryItemCard`: filename (truncated), date (Shamsi), trade count, discipline score (mini gauge), primary diagnosis (one line, truncated), ⋯ menu.
   - Mobile: vertical stack. Desktop: `DataTable` with columns.
   - Pagination: «مورد ۱–۲۰ از ۴۷» + page numbers (desktop) / «بیشتر» button (mobile).
3. **Re-open an analysis:**
   - Click row/card → navigate to `/dashboard/{analysis_id}`.
4. **Quick actions (per item):**
   - Click ⋯ → menu: «باز کردن» / «دانلود PDF» / «دانلود HTML» / «حذف».
   - «دانلود PDF» → triggers `GET /analyses/{id}/report.pdf` directly.
   - «حذف» → confirmation modal: «این تحلیل برای همیشه حذف می‌شود. ادامه می‌دهید؟» → «حذف کن» / «انصراف».
   - On delete: toast «تحلیل حذف شد» + list updates.
5. **Long-press (mobile) / right-click (desktop):**
   - Opens the same ⋯ menu — shortcut for power users.

**Success state:**
- User finds the analysis they were looking for and re-opens it.

**Empty state:**
- No analyses: illustration + «هنوز تحلیلی انجام نداده‌اید» + «شروع تحلیل» CTA → `/upload`.

**Error state:**
- Fetch error: standard error card + retry.
- Delete error: toast «حذف ناموفق بود. دوباره تلاش کنید».

**Mobile considerations:**
- Cards stack vertically.
- Long-press activates haptic feedback (light impact).
- ⋯ menu opens as bottom sheet.

**Cognitive load tactics:**
- Each card shows the 4 most important things: filename, date, score, diagnosis.
- Filter defaults to «همه» — no forced choice.
- Delete requires confirmation — error prevention.
- Quick PDF download from the list — no need to open the analysis first.

---

## 3. Per-Page UX Specifications

Every page specified against 12 attributes: Purpose · Primary Action · Secondary Actions · Required Components · Expected User Behavior · Navigation · Interaction Logic · Loading State · Empty State · Error State · Success State · Accessibility.

---

### 3.1 Home / Landing

| Attribute | Specification |
|---|---|
| **Purpose** | Communicate value proposition in 5 seconds. Convert visitor → uploader. |
| **Primary Action** | Click «تحلیل معاملاتم را شروع کن» → `/upload`. |
| **Secondary Actions** | Click «گزارش نمونه ببین» → `/sample`. Scroll to learn more. |
| **Required Components** | HeroSection, TrustStrip, HowItWorks (3 steps), SamplePreview, FinalCTA, TopBar (transparent in hero, solid on scroll). |
| **Expected User Behavior** | Read headline (3s) → scan trust strip (2s) → click primary CTA OR scroll to learn more → click CTA. |
| **Navigation** | Top bar: logo + «شروع» CTA + theme toggle + language toggle. No sidebar (public layout). |
| **Interaction Logic** | Sticky top bar appears after scrolling past hero (scroll listener, 80ms throttle). Smooth scroll between sections (respecting reduced-motion). CTA hover: amber darkens, slight scale (1.02). |
| **Loading State** | N/A (static page). Skeleton of hero text on initial JS hydration (prevents blank flash). |
| **Empty State** | N/A. |
| **Error State** | If sample report preview image fails to load: hide preview, show text-only description. No error UI. |
| **Success State** | User clicks CTA → navigates to `/upload`. |
| **Accessibility** | H1 is the hero headline (one per page). All CTAs are `<button>` or `<a>` with descriptive aria-labels. Color contrast ≥4.5:1. Skip-to-content link at top. Reduced-motion: smooth scroll becomes instant jump. |

---

### 3.2 Sample Report

| Attribute | Specification |
|---|---|
| **Purpose** | Show visitors exactly what they'll get before uploading. Reduce uncertainty. |
| **Primary Action** | Click «این تحلیل را روی داده‌ی خودم انجام بدهم» → `/upload`. |
| **Secondary Actions** | Scroll through report sections. Click section anchors (desktop) to jump. |
| **Required Components** | PageTitle, SampleBadge («این یک تحلیل نمونه است»), ReportRenderer (iframe or in-place HTML), SectionNavigator (desktop: sticky left rail; mobile: horizontal pills), StickyBottomCTA. |
| **Expected User Behavior** | Browse 2–3 sections (Executive Summary, Diagnosis, Coaching) → click CTA. |
| **Navigation** | Top bar: back to Home. Section navigator for in-page jump. |
| **Interaction Logic** | Section anchor click → smooth scroll + URL hash update (for shareable links). Sticky CTA always visible. |
| **Loading State** | Skeleton of report structure (heading bars + content blocks) while HTML loads. |
| **Empty State** | N/A (sample is pre-generated). |
| **Error State** | If sample report asset fails: «گزارش نمونه در دسترس نیست. می‌توانید مستقیماً تحلیل خود را شروع کنید.» + CTA to `/upload`. |
| **Success State** | User clicks CTA → `/upload`. |
| **Accessibility** | Iframe has `title` attribute. Section navigator is `<nav>` with `aria-label="بخش‌های گزارش"`. Keyboard navigable. Skip-to-content link. |

---

### 3.3 Upload

| Attribute | Specification |
|---|---|
| **Purpose** | Ingest trade file, validate, prepare for analysis. |
| **Primary Action** | Click «شروع تحلیل» (disabled until valid file selected). |
| **Secondary Actions** | Select file (click dropzone). Remove selected file (X on FilePill). Change LLM provider (SegmentedControl). View supported formats (help modal). |
| **Required Components** | UploadDropzone, FilePill, LLMProviderSelector (SegmentedControl), SupportedFormatsModal, PrimaryCTA (Button), TopBar, MobileBackButton. |
| **Expected User Behavior** | Tap dropzone → file picker → select file → (optional) change LLM → click «شروع تحلیل». |
| **Navigation** | Top bar: back to Home. No sidebar on mobile (focused flow). Desktop: sidebar visible but Upload is the active page. |
| **Interaction Logic** | Dropzone: drag-over → border solid amber + bg tint (150ms). File selected → client-side validation (size ≤25MB, extension in allow-list) → if valid, show FilePill + enable CTA; if invalid, inline error. CTA click → upload via `POST /uploads` → on success, transition to Analysis Progress Flow. LLM SegmentedControl change → update component state, tooltip on each option explains time/depth tradeoff (consistent with §2.4 smart estimate). |
| **Loading State** | Upload in progress: FilePill shows progress bar (0–100%). CTA shows spinner + «در حال آپلود...». Dropzone disabled. |
| **Empty State** | Initial state: dropzone + format hint + disabled CTA. First-time tooltip: «فایل خروجی بروکر خود را اینجا بکشید» (one-time, dismissable). |
| **Error State** | File too large: inline «حجم فایل ۳۲ مگابایت است؛ حداکثر مجاز ۲۵ مگابایت». Wrong format: inline «فرمت .zip پشتیبانی نمی‌شود». Upload 422: engine message inline + «فرمت‌های پشتیبانی‌شده» link. Upload network error: «اتصال برقرار نشد» + retry. |
| **Success State** | File uploaded → automatic transition to Analysis Progress (no success toast — the transition itself is the feedback). |
| **Accessibility** | Dropzone is keyboard-accessible (`tabindex=0`, `role="button"`, `aria-label="آپلود فایل معاملات"`). Enter/Space triggers file picker. LLM SegmentedControl uses `radiogroup` semantics. Error messages are `aria-live="polite"` and associated with the dropzone via `aria-describedby`. FilePill remove button has `aria-label="حذف فایل"`. |

---

### 3.4 Analysis Progress (updated v1.1 — smart time estimate)

| Attribute | Specification |
|---|---|
| **Purpose** | Communicate analysis is running. Set honest, LLM-aware expectations. Transition to Dashboard. |
| **Primary Action** | Wait for completion. (No user action needed — automatic transition.) |
| **Secondary Actions** | Click «انصراف» to cancel and return to Upload. |
| **Required Components** | PageTitle, Subtitle (filename + trade count), StageList (6 stages), IndeterminateProgressBar, ElapsedCounter, SmartTimeEstimate (LLM-aware), CancelButton, SoftReassuranceMessage (shown if elapsed exceeds estimate). |
| **Expected User Behavior** | Watch the progress UI for 5–30 seconds. Read the stage names to understand what's happening. Optionally cancel. |
| **Navigation** | Top bar: logo only (no nav — user is in a flow). Cancel returns to `/upload`. |
| **Interaction Logic** | On mount: fire `POST /analyses` with `{upload_id, llm_provider}`. Determine smart time estimate from `llm_provider` (none → «زیر ۱۰ ثانیه»; gemini/openai/claude → «تا ۲۰–۳۰ ثانیه»). Start elapsed counter (updates every second). Stages show pulsing dots (not checkmarks — honest about not knowing individual stage completion). If elapsed > estimate upper bound (15s for none; 35s for LLM), show soft reassurance: «کمی بیشتر از حد انتظار طول می‌کشد — هنوز در حال تحلیل است». On `201` response: staggered checkmark animation (60ms per stage) → progress bar fills → toast → 800ms delay → navigate to `/dashboard/{id}`. On error: show error card with retry. |
| **Loading State** | This page IS the loading state. |
| **Empty State** | N/A. |
| **Error State** | 422 (invalid data): «داده‌ی فایل معتبر نیست: {engine message}» + «بازگشت به آپلود». 500: «خطای داخلی سرور» + retry button. Timeout (60s for none, 90s for LLM — extended bound): «تحلیل بیش از حد طول کشید» + retry. 429: «تعداد درخواست‌ها بیش از حد» + countdown + auto-retry. |
| **Success State** | All stages show ✓ → toast «تحلیل کامل شد» → navigate to Dashboard. |
| **Accessibility** | Stage list uses `<ol>` with `aria-label="مراحل تحلیل"`. Progress bar has `role="progressbar"` with `aria-valuetext="در حال تحلیل"`. Elapsed counter is `aria-live="off"` (don't announce every second). Smart time estimate is `aria-live="polite"` (announced once on mount). Soft reassurance is `aria-live="polite"` (announced when it appears). Error card is `aria-live="assertive"`. Cancel button has descriptive `aria-label="انصراف از تحلیل"`. |

---

### 3.5 Dashboard (Emotional Center)

| Attribute | Specification |
|---|---|
| **Purpose** | Deliver the 4 emotional answers in 5 seconds. Provide drill-down paths. |
| **Primary Action** | Click one of the 4 emotional-center cards → drill to detail page. |
| **Secondary Actions** | Scroll to below-fold content. Click quick-jump tiles. Click analysis badge (top bar) to switch analysis. Click «دانلود گزارش» to download. Toggle theme/language. |
| **Required Components** | TopBar (with AnalysisBadge, DownloadReport button, ThemeToggle, LanguageToggle), OverallHealthCard (ScoreGauge), BiggestLeakCard (EvidenceCard variant), BiggestStrengthCard, ImmediateNextActionCard (RecommendationCard variant), PerformanceStrip (6 StatCards), BiggestLeakCallout, WhatIfCallout, QuickJumpTiles (4), DataQualityWarnings (Accordion), MobileBottomTabBar, MobileNavDrawer. |
| **Expected User Behavior** | Land → absorb 4 cards (5s) → click a card to drill down. OR scroll for more context. |
| **Navigation** | Top bar: logo + AnalysisBadge (click → History drawer) + DownloadReport + ThemeToggle + LanguageToggle + AccountMenu (future). Sidebar (desktop): all nav items, Dashboard active. Bottom tab bar (mobile): Dashboard, Behavioral, Diagnosis, Coaching, Report + More sheet (includes Trade Explorer). |
| **Interaction Logic** | 4 cards: staggered fade-in on mount (100ms per card). ScoreGauge: animates 0→value (600ms Expo.out, frozen if reduced-motion). Click card → navigate to drill-down. Click AnalysisBadge → drawer with recent 5 analyses + «مشاهده‌ی همه». Click DownloadReport → `/report/{id}`. Quick-jump tiles → navigate. DataQualityWarnings: collapsed by default, expand on click. |
| **Loading State** | 4 skeleton cards in the same layout (matching heights). Skeleton PerformanceStrip. Skeleton quick-jump tiles. Pulse animation (frozen if reduced-motion). |
| **Empty State** | If navigated to `/dashboard` without ID → redirect to `/upload` with toast «ابتدا یک فایل آپلود کنید». |
| **Error State** | If `GET /analyses/{id}/report` fails: error card replaces 4 cards: «تحلیل بارگذاری نشد» + retry + «بازگشت به تاریخچه». |
| **Success State** | User clicks a card → navigates to detail page (the navigation is the success). |
| **Accessibility** | Each card is a `<button>` or `<a>` with descriptive `aria-label` (e.g., «وضعیت کلی: ۶۷ از ۱۰۰، متوسط. کلیک برای جزئیات رفتاری»). ScoreGauge has `role="img"` and `aria-label` with the value + severity. Severity badges have text labels (not color alone). DataQualityWarnings accordion uses `aria-expanded`. Skip-to-content link. |

---

### 3.6 Behavioral Analysis

| Attribute | Specification |
|---|---|
| **Purpose** | Per-score breakdown of 5 behavioral scores with severity, $ impact, what-if. |
| **Primary Action** | Expand a ContextBlockCard to read insight + what-if. |
| **Secondary Actions** | Click «شواهد این رفتار» → Diagnosis (filtered). Click score (desktop) → tooltip with severity thresholds. |
| **Required Components** | PageTitle, SummaryLine («۳ رفتار نیاز به توجه دارد»), ContextBlockCard ×5, WhatIfCallout (per card, collapsible), CTAButton («شواهد این رفتار»), RadarChart (desktop right rail), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Scan 5 cards by severity color → expand Critical/High cards → read insights → click through to evidence. |
| **Navigation** | Standard app nav. Behavioral is active. Breadcrumb: Dashboard › Behavioral. |
| **Interaction Logic** | Cards ordered by severity (Critical→Low), then by $ impact. Default state: Critical/High expanded, Medium/Low collapsed. Tap card → toggle expand (accordion on mobile, independent on desktop). WhatIfCallout collapsed by default — expand on click. CTA → `/diagnosis/{id}`. |
| **Loading State** | 5 skeleton cards with pulse. |
| **Empty State** | If no behavioral data (shouldn't happen post-analysis): «داده‌ی رفتاری موجود نیست» + CTA to Dashboard. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User expands a card, reads the insight, and either clicks through to evidence or moves on. |
| **Accessibility** | Cards use `role="button"` with `aria-expanded`. Severity badge has text label. ScoreGauge has `role="img"` + `aria-label`. What-if section is `aria-live="polite"` when expanded. RadarChart has `aria-label` + visually-hidden data table. Keyboard: Tab to card, Enter/Space to expand. |

---

### 3.7 Diagnosis

| Attribute | Specification |
|---|---|
| **Purpose** | Primary + secondary diagnosis with prioritized evidence. |
| **Primary Action** | Scan primary diagnosis + top-3 evidence. |
| **Secondary Actions** | Expand evidence card for detail. «نمایش همه‌ی شواهد». Filter/sort evidence. Click «برنامه‌ی اقدام را ببین» → Coaching. Click «مشاهده‌ی معاملات مرتبط» on expanded evidence → Trade Explorer (pre-filtered). |
| **Required Components** | PageTitle, PrimaryDiagnosisCard, SecondaryDiagnosisCard (conditional), EvidenceSectionHeader, EvidenceFilterBar (collapsible on mobile), EvidenceCard ×3 (default) + ×5 (show more), ShowMoreButton, CTAButton («برنامه‌ی اقدام را ببین»), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Read primary diagnosis (5s) → scan top-3 evidence → expand one for detail → click CTA to action plan. |
| **Navigation** | Standard app nav. Diagnosis active. Breadcrumb: Dashboard › Diagnosis. |
| **Interaction Logic** | Primary card severity-colored border. Evidence cards ordered by priority_score (default). Filter change → re-filter + re-render. Sort change → re-sort. «نمایش همه» → staggered reveal of remaining cards. Expanded evidence shows «مشاهده‌ی معاملات مرتبط» CTA → `/trades/{id}?evidence={type}` (requires trades endpoint §5.1). CTA → `/coaching/{id}`. |
| **Loading State** | Skeleton of diagnosis cards + 3 evidence skeletons. |
| **Empty State** | If evidence empty: hide evidence section, diagnosis card shows «الگوی رفتاری برجسته‌ای شناسایی نشد» + CTA to Dashboard. If no secondary diagnosis: hide secondary card. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User reads diagnosis + scans evidence → clicks CTA to Coaching. |
| **Accessibility** | Diagnosis cards use `role="region"` with `aria-labelledby`. Evidence cards use `role="button"` + `aria-expanded`. Filter bar uses `role="toolbar"`. Severity badges have text. Confidence/priority scores are `aria-label` on their progress bars. |

---

### 3.8 Coaching

| Attribute | Specification |
|---|---|
| **Purpose** | Action plan + AI coaching narrative + reality check. |
| **Primary Action** | Read top-3 recommendations, mark one as done. |
| **Secondary Actions** | Expand recommendation for rationale. «نمایش گام‌های بیشتر». Read AI coaching narrative. Read reality check. Download report. |
| **Required Components** | PageTitle, Subtitle («۳ گام برای این هفته»), RecommendationCard ×3 (default) + ×5 (show more), ShowMoreButton, AICoachingCard (with badge + narrative), RealityCheckCard, CTAButton («گزارش کامل را دانلود کن»), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Scan 3 recommendations (10s) → expand one for rationale → mark as done → read AI coaching → leave or download report. |
| **Navigation** | Standard app nav. Coaching active. Breadcrumb: Dashboard › Coaching. |
| **Interaction Logic** | Cards ordered by priority (P1, P2, P3). P1 card has severity-colored border. Tap card → expand rationale + «انجام شد» toggle. Toggle → strikethrough + green check + `localStorage` update. «نمایش بیشتر» → staggered reveal. AI coaching badge: «توضیح الگوریتمی» (grey) or «توضیح هوش مصنوعی» (accent). CTA → `/report/{id}`. |
| **Loading State** | 3 skeleton recommendation cards + skeleton text block. |
| **Empty State** | If recommendations empty: «برنامه‌ی اقدام در دسترس نیست» + CTA to Dashboard. If AI coaching empty: hide AI card. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User marks a recommendation as done → green check + toast «انجام شد» (optional, subtle). |
| **Accessibility** | Recommendation cards use `role="button"` + `aria-expanded`. Priority chip has `aria-label="اولویت ۱"`. «انجام شد» toggle uses `role="switch"` + `aria-checked`. AI badge has `aria-label`. Long-form text uses semantic `<p>` tags with appropriate heading levels. |

---

### 3.9 Trader DNA

| Attribute | Specification |
|---|---|
| **Purpose** | Psychological archetype profile with narrative and supporting evidence. |
| **Primary Action** | Read archetype + narrative. |
| **Secondary Actions** | Expand supporting evidence. Click «تشخیص کامل را ببین» → Diagnosis. |
| **Required Components** | PageTitle, ArchetypeHeroCard (large archetype label + icon), NarrativeCard (long-form text), SupportingEvidenceSection (3 compact EvidenceCards), CTAButton, TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Read archetype label (3s) → read narrative (30s) → scan supporting evidence → click CTA or leave. |
| **Navigation** | Standard app nav. Trader DNA active. Breadcrumb: Dashboard › Trader DNA. |
| **Interaction Logic** | Hero card: archetype in `--text-data-xl` mono font, centered. Narrative in narrow container (640px) for readability. Supporting evidence below. CTA → `/diagnosis/{id}`. |
| **Loading State** | Skeleton hero (large text placeholder) + skeleton paragraphs. |
| **Empty State** | If archetype is "N/A": «پروفایل هنوز تعیین نشده» + CTA to re-analyze with more data. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User reads narrative and clicks CTA to Diagnosis. |
| **Accessibility** | Hero card uses `<h2>` for archetype. Narrative uses `<p>` tags. Evidence cards accessible as above. Icon has `aria-hidden="true"` (decorative). |

---

### 3.10 Edge Map

| Attribute | Specification |
|---|---|
| **Purpose** | Best/worst trading hour, weekday, strategy, long-vs-short. |
| **Primary Action** | Scan 4 best/worst cards. |
| **Secondary Actions** | Click any card → Charts (pre-selected dimension). View side comparison table. Tap heatmap cell for detail. |
| **Required Components** | PageTitle, BestWorstCard ×4 (best hour, worst hour, best weekday, worst weekday), StrategyCard ×2 (best, worst), SideComparisonTable (or card list on mobile), HeatmapChart (hour × weekday), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Scan 4 cards (5s) → glance at heatmap → check side comparison → click through to Charts. |
| **Navigation** | Standard app nav. Edge Map active. Breadcrumb: Dashboard › Edge Map. |
| **Interaction Logic** | 4 cards in 2×2 grid (mobile) or 1×4 row (desktop). Best cards: green border. Worst cards: red border. Heatmap: tap cell → tooltip with hour, weekday, P&L. Side comparison: tap row (mobile) → drill to Behavioral filtered. Click any best/worst card → `/charts/{id}?dim=hour` (or weekday/strategy). |
| **Loading State** | 4 skeleton cards + skeleton heatmap. |
| **Empty State** | If edge_map empty (insufficient data): «داده‌ی کافی برای این تحلیل نیست (حداقل ۵ معامله در هر دسته لازم است)» + CTA to Upload. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User identifies their best/worst times and clicks through to Charts. |
| **Accessibility** | Best/worst cards have `aria-label` with full info (e.g., «بهترین ساعت: ۱۴:۰۰، میانگین سود ۱۲ دلار»). Heatmap cells are `<button>` with `aria-label` (hour, weekday, P&L). Side comparison table has proper `<th>` scope. Color + text + border convey best/worst (not color alone). |

---

### 3.11 Charts

| Attribute | Specification |
|---|---|
| **Purpose** | Visual deep-dive — 6 charts, each answering a specific question. |
| **Primary Action** | Select a chart from the selector. View it. |
| **Secondary Actions** | Hover/tap data point for tooltip. Pinch to zoom (equity, drawdown). Double-tap to reset. Click key insight callout. Click «مشاهده‌ی معاملات خام» → Trade Explorer. |
| **Required Components** | PageTitle, ChartSelector (SegmentedControl or horizontal pills), ChartContainer (Recharts), ChartCaption, KeyInsightCallout, RawTradesLink, TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Select chart → view → read caption → check key insight → switch chart. |
| **Navigation** | Standard app nav. Charts active. Breadcrumb: Dashboard › Charts. |
| **Interaction Logic** | Selector: horizontal scroll on mobile, full pills on desktop. Chart: 280px tall (mobile), 400px (desktop). Cross-fade on switch (300ms). Hover/tap → tooltip. Pinch → zoom (equity, drawdown only). Double-tap → reset. KeyInsight click → highlight data point. «مشاهده‌ی معاملات خام» → `/trades/{id}`. |
| **Loading State** | Chart skeleton (axes + pulsing placeholder area). |
| **Empty State** | If insufficient data for specific chart: «داده‌ی کافی برای این نمودار نیست» + suggest another chart. |
| **Error State** | If chart render fails: «نمودار قابل رسم نیست» + «مشاهده‌ی داده‌ی خام» fallback link (to Trade Explorer). |
| **Success State** | User views chart and gains insight. |
| **Accessibility** | Chart has `aria-label` summarizing data. Visually-hidden `<table>` with raw data as alternative. Tooltip content available to screen readers (`aria-live` on tooltip container). Color + line style differentiate series (not color alone). Selector uses `radiogroup` semantics. |

---

### 3.12 Trade Explorer (clarified in v1.1 — Tier 3 Deep Dive, requires API addition)

| Attribute | Specification |
|---|---|
| **Purpose** | Browse normalized trade-level data. Filter, sort, inspect individual trades. Verify engine findings. |
| **Primary Action** | Browse/filter/sort the trade table. |
| **Secondary Actions** | Click a trade → detail drawer. Export filtered set as CSV. Adjust pagination. |
| **Required Components** | PageTitle, Subtitle (trade count), FilterBar (date range, side, outcome, size — collapsible on mobile), SortDropdown, AggregateStatsBar (4 mini-stats), DataTable (or CardList on mobile), Pagination, TradeDetailDrawer (or BottomSheet on mobile), ExportCSVButton, TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Browse default view → apply a filter (e.g., «زیان‌ده») → scan results → click a trade to inspect → maybe export. |
| **Navigation** | Standard app nav. Trade Explorer active (sidebar position 8, between Charts and Trends). Breadcrumb: Dashboard › Trade Explorer. |
| **Interaction Logic** | Default: all trades, sorted by date ascending. Filter change → server-side filter via query params (`?side=long&outcome=win`) + AggregateStatsBar update (client-computed from returned page). Sort change → server-side sort. Page change → fetch next page (server-side pagination). Click row/card → drawer/bottom sheet with full trade detail. Export CSV → client-side generation from current filtered in-memory data (limited to current page; future: server-side export endpoint). |
| **Loading State** | Table skeleton (10 row placeholders). AggregateStatsBar skeleton. |
| **Empty State** | No trades match filter: «هیچ معامله‌ای با این فیلترها یافت نشد» + «پاک کردن فیلترها» CTA. No trades at all: «داده‌ی معامله‌ای موجود نیست» + CTA to Dashboard. |
| **Error State** | Fetch error: standard error card + retry. 404: «تحلیل یافت نشد» + CTA to History. |
| **Success State** | User finds a trade they were looking for and inspects it. |
| **Accessibility** | Table uses proper `<table>` semantics with `<th scope>`. Sortable headers are `<button>` with `aria-sort`. Filter bar uses `role="toolbar"`. Drawer/sheet has `role="dialog"` + `aria-modal="true"` + focus trap. Pagination has `aria-label="صفحه‌بندی"`. Export button has descriptive `aria-label`. |

---

### 3.13 Trends

| Attribute | Specification |
|---|---|
| **Purpose** | Longitudinal score evolution across past analyses. Requires 2+ analyses. |
| **Primary Action** | Select a metric. View trend chart. |
| **Secondary Actions** | Hover/tap data point for detail. Click table row → that analysis's Dashboard. «تحلیل دوباره» CTA → Upload. |
| **Required Components** | PageTitle, MetricSelector (SegmentedControl), TrendChart (LineChart), TrendSummaryCallout, ComparisonTable (or card list on mobile), RadarChart (5-axis, desktop), CTAButton («تحلیل دوباره»), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Select metric → view trend → read summary → check comparison table → click a past analysis or re-analyze. |
| **Navigation** | Standard app nav. Trends active (sidebar position 9). Breadcrumb: Dashboard › Trends. |
| **Interaction Logic** | Metric selector: 7 options (5 scores + Net Profit + Win Rate). Chart: line chart, x-axis = analysis dates, y-axis = metric value. Summary callout: auto-generated based on trend direction (improving/declining/flat). Comparison table: date, value, delta vs previous, delta vs first. Click row → `/dashboard/{id}`. |
| **Loading State** | Chart skeleton + table skeleton. |
| **Empty State** | <2 analyses: illustration + «برای دیدن روند، حداقل ۲ تحلیل لازم است» + CTA to Upload. 0 analyses: same, stronger CTA. |
| **Error State** | Fetch error: standard error card + retry. |
| **Success State** | User sees their trend and understands if they're improving. |
| **Accessibility** | Chart has `aria-label` + visually-hidden data table. Summary callout is `aria-live="polite"`. Table rows are `<button>` or have `onclick` with keyboard support. Metric selector uses `radiogroup` semantics. |

---

### 3.14 Report

| Attribute | Specification |
|---|---|
| **Purpose** | Generate, preview, download HTML/PDF reports. |
| **Primary Action** | Click «دانلود PDF». |
| **Secondary Actions** | Click «دانلود HTML». Click «چاپ». Browse section previews. Expand/collapse sections. |
| **Required Components** | PageTitle, ReadyCard («گزارش شما آماده است»), DownloadPDFButton (primary), DownloadHTMLButton (secondary), PrintButton, SectionNavigator (desktop: sticky rail; mobile: horizontal pills), SectionPreviewCard ×7 (Executive Summary, Performance, Behavioral, Diagnosis, Coaching, Evidence, Appendix), DataQualityWarnings (if any), ReportMetadata, TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Click «دانلود PDF» → wait for download → leave. OR browse a section or two first. |
| **Navigation** | Standard app nav. Report active (sidebar position 10). Breadcrumb: Dashboard › Report. |
| **Interaction Logic** | Download buttons: click → loading state (spinner + «در حال آماده‌سازی...») → browser download → toast «گزارش دانلود شد». Section navigator: click → smooth scroll + auto-expand. Section cards: accordion (one open on mobile, multiple on desktop). Print: opens browser print dialog. |
| **Loading State** | Skeleton of section cards. Download buttons in loading state during download. |
| **Empty State** | N/A (Report always has content if analysis exists). |
| **Error State** | PDF fail: «تولید PDF ناموفق بود» + retry + «گزارش HTML را امتحان کنید». HTML fail: same with PDF fallback. 404: «تحلیل یافت نشد» + CTA to History. |
| **Success State** | Toast «گزارش PDF دانلود شد» (3s). |
| **Accessibility** | Download buttons have descriptive `aria-label` (e.g., «دانلود گزارش PDF»). Section navigator is `<nav>` with `aria-label`. Accordion cards use `role="button"` + `aria-expanded`. Print button has `aria-label`. Download success toast is `aria-live="polite"`. |

---

### 3.15 Settings (Phase 1 Stub — updated v1.1 with offline cache section)

| Attribute | Specification |
|---|---|
| **Purpose** | Customize appearance, language. Future-ready for account, billing, API keys, offline cache. |
| **Primary Action** | Toggle theme or language. |
| **Secondary Actions** | Toggle density. Reset all data. View About info. View future sections (disabled). View offline cache section (disabled, informational). |
| **Required Components** | PageTitle, AppearanceSection (ThemeToggle, DensityToggle), LanguageSection (LanguageToggle), AboutSection (version info, docs link, ResetDataButton), OfflineCacheSection (disabled toggle + tooltip), FutureSections (disabled, with «به‌زودی» badges), TopBar, Sidebar/BottomTabBar. |
| **Expected User Behavior** | Toggle theme → see instant result → leave. OR toggle language → see instant result → leave. |
| **Navigation** | Standard app nav. Settings active (sidebar position 11). Breadcrumb: Settings. |
| **Interaction Logic** | Theme toggle: instant switch, persisted in `localStorage('td_theme')`. Language toggle: instant switch, persisted in `localStorage('td_lang')`. Density toggle: visual only Phase 1. ResetData: confirmation modal → clears `localStorage` → toast «داده‌ها پاک شدند» → page reloads with defaults. Offline cache toggle: disabled, tooltip explains future behavior. Future sections: disabled, show tooltip «این بخش به‌زودی فعال می‌شود». |
| **Loading State** | N/A (Settings is client-side, instant). |
| **Empty State** | N/A. |
| **Error State** | N/A (Phase 1). |
| **Success State** | Theme/language change is instant — the change itself is the success feedback. |
| **Accessibility** | Toggles use `role="radiogroup"` + `role="radio"` + `aria-checked`. Reset button has `aria-label` + confirmation modal has `role="alertdialog"`. Future sections are `aria-disabled="true"` with explanatory `aria-label`. Offline cache tooltip is `aria-describedby` linked to the toggle. |

---

## 4. Cross-Cutting UX Patterns

### 4.1 Cognitive Load Reduction Tactics (Applied Throughout)

| Tactic | Where applied |
|---|---|
| One question per page | Every page has a single named question (Phase 1 §13). No page tries to do two things. |
| Numbers always paired with meaning | "67" never appears alone. Always "67/100 — Medium severity." |
| Consistent severity colors | Low=green, Medium=amber, High=orange, Critical=red. Never reused for non-severity. |
| No jargon without explanation | First use of "Revenge Trading," "Profit Factor," etc. has inline tooltip. |
| Comparison anchors where engine supports | PF≥1 is a real industry anchor → shown. "Average trader discipline" is not → never invented. |
| Charts only when they add info | 6 specific charts on Charts page, each answering a named question. No decorative charts. |
| Long content collapsible | Evidence lists, action plans, what-if, data warnings — all collapse by default. |
| Top-3 / Top-5 visible by default | Evidence: top-3. Recommendations: top-3. Beyond that, "show more." |
| Empty states actionable | Every empty state has illustration + headline + CTA. Never just "no data." |
| Loading states honest | Skeletons for async content. Stage names for analysis (without faking transitions). Elapsed counter. Smart time estimate. |
| Errors actionable | Every error has: what went wrong (1 line) + why (1 line) + what to do (CTA). |
| Repeated patterns | Every score card, evidence card, recommendation card uses the same layout. Learn once, apply everywhere. |
| Default to the common case | LLM provider defaults to "none." Evidence defaults to top-3. Filters default to "all." |
| Verb-led actions | "بعد از هر باخت، ۳۰ دقیقه استراحت کن" not "مدیریت استرس پس از باخت." |
| One primary CTA per page | Every page has one amber CTA. Secondary actions are ghost or text. |
| Smart, honest time estimates | Analysis Progress shows LLM-aware estimate («زیر ۱۰ ثانیه» vs «تا ۲۰–۳۰ ثانیه»). No false precision. |

### 4.2 Progressive Disclosure Tiers (Recap — updated v1.1 with Trade Explorer)

| Layer | Question | Where | Who reaches it |
|---|---|---|---|
| L1 — Composite | "How am I doing overall?" | Dashboard | Every user, every visit |
| L2 — Per-dimension | "Which behaviors are costing me?" | Behavioral, Diagnosis, Coaching | Engaged users (most) |
| L3 — Cross-cut | "When/where/who am I? Show me the raw data." | Edge Map, Trader DNA, Charts, **Trade Explorer** | Curious users |
| L4 — Longitudinal & raw | "Am I improving? Show me everything." | Trends, Report | Power users, mentors |

### 4.3 Error Prevention Patterns

| Pattern | Where |
|---|---|
| CTA disabled until prerequisites met | Upload: CTA disabled until valid file selected. |
| Client-side validation before server | Upload: file size + extension checked before `POST /uploads`. |
| Confirmation on destructive actions | History delete: confirmation modal. Settings reset: confirmation modal. |
| Optimistic UI only for safe actions | Coaching "mark as done" is optimistic (visual only, no server call). |
| No silent failures | Every error surfaces to the user with a recovery path. |
| Idempotent retries | Retry buttons re-fire the same request safely. |
| Extended timeouts matching estimates | Analysis Progress timeout: 60s (none) / 90s (LLM) — matches smart estimate, avoids premature timeout. |

### 4.4 Mobile-First Universal Patterns (Recap)

| Pattern | Mobile behavior |
|---|---|
| Sidebar | Off-canvas drawer (hamburger toggle). |
| Top bar | Logo + hamburger + theme toggle. Analysis badge in drawer. |
| Bottom tab bar | 5 items (Dashboard, Behavioral, Diagnosis, Coaching, Report) + More sheet (includes Trade Explorer, Trader DNA, Edge Map, Charts, Trends, History, Settings). |
| Tables | Card list (one card per row). |
| Modals | Bottom sheets (slide-up, swipe-down to dismiss). |
| Filters | Collapsed into «فیلترها» button → bottom sheet. |
| Forms | Single column, full-width inputs. |
| Long-form text | Narrow container (640px) even on wider screens. |
| Touch targets | ≥44×44pt with 8pt separation. |
| Gestures | Swipe edge → nav drawer. Swipe down → refresh. Long-press → context menu. All have tap equivalents. |

### 4.5 Primary Navigation & Page Hierarchy (Explicit — NEW in v1.2)

This subsection makes the navigation structure and page hierarchy explicit in the main body of this document (previously referenced from Phase 1 §8–§9 and documented for update in §10.2–§10.3). **Trade Explorer is included as a Tier 3 Deep Dive page, position 8, between Charts and Trends, icon: `Table` (Phosphor).**

#### Primary Navigation Table (sidebar, RTL-aware, collapsible)

Organized by user intent (Understand → Improve → Explore → Act), not by engine module name. Each item labeled with the user's question.

| Position | Nav item | User question it answers | Icon (Phosphor) | Tier |
|---|---|---|---|---|
| Top | Upload (CTA, always visible) | «تحلیل معاملات جدید» / "Analyze new trades" | `UploadSimple` (Bold) | Entry |
| 1 | Dashboard | «وضعیت کلی من چطور است؟» / "How am I doing overall?" | `Gauge` | Primary |
| 2 | Behavioral Analysis | «کدام رفتارها به من ضرر می‌زنند؟» / "Which behaviors are costing me?" | `ChartBar` | Primary |
| 3 | Diagnosis | «بزرگ‌ترین مشکل من چیست؟» / "What's my main leak?" | `Stethoscope` | Primary |
| 4 | Coaching | «چه کار باید بکنم؟» / "What do I do about it?" | `Lightbulb` | Primary |
| 5 | Trader DNA | «من چه نوع معامله‌گری هستم؟» / "What kind of trader am I?" | `Dna` | Deep dive |
| 6 | Edge Map | «کِی و کجا بهترین/بدترین هستم؟» / "When/where am I best and worst?" | `MapPin` | Deep dive |
| 7 | Charts | «نمودارها را نشانم بده» / "Show me the visuals" | `ChartLineUp` | Deep dive |
| **8** | **Trade Explorer** | **«معاملات خام را نشانم بده» / "Show me the raw trades"** | **`Table`** | **Deep dive** |
| 9 | Trends | «آیا در حال بهبود هستم؟» / "Am I improving over time?" | `TrendUp` | Deep dive |
| 10 | Report | «گزارش قابل‌دانلود بده» / "Give me a downloadable report" | `FileText` | Action |
| 11 | History | «قبلاً چه تحلیل کرده‌ام؟» / "What have I analyzed before?" | `ClockCounterClockwise` | Entry |
| Bottom | Settings (future) | «حسابم را پیکربندی کن» / "Configure my account" | `Gear` | Future |

**Mobile bottom tab bar** (visible on `< md`): 5 items — Dashboard · Behavioral · Diagnosis · Coaching · Report. "More" sheet reveals: Trader DNA · Edge Map · Charts · **Trade Explorer** · Trends · History · Settings.

#### Page Hierarchy (updated with Trade Explorer)

```
Tier 0 — Public (no analysis required)
  Home / Landing
  Sample Report

Tier 1 — Entry (produce or consume analyses)
  Upload          → produces Analysis
  History         → consumes past Analyses

Tier 2 — Primary consumption (require an Analysis in context)
  Dashboard           → entry view; the 5-second emotional answer (4 cards)
  Behavioral Analysis → drill from Dashboard (Overall Health card)
  Diagnosis           → drill from Dashboard (Biggest Leak card)
  Coaching            → drill from Dashboard (Immediate Next Action card)

Tier 3 — Deep dive (require an Analysis in context, used by engaged users)
  Trader DNA      → drill from Diagnosis
  Edge Map        → drill from Dashboard (Biggest Strength card) or Behavioral
  Charts          → drill from Dashboard or Behavioral
  Trade Explorer  → drill from Charts or Diagnosis (NEW — requires /trades API)
  Trends          → requires 2+ Analyses; drill from Dashboard or History

Tier 4 — Action
  Report          → produces downloadable HTML/PDF

Tier 5 — Future-ready (Phase 1 stub or hidden)
  Settings        → Phase 1 stub (theme, language, offline cache toggle)
  Mentor Workspace → reserved
  Team Dashboard   → reserved
```

**Hierarchy rules:**
- Tier 2 pages never link upward to Tier 1 except via the sidebar.
- Tier 3 pages always offer a "back to Dashboard" or "back to related Tier 2" CTA.
- Tier 4 (Report) is reachable from any Tier 2/3 page via the persistent top-bar «دانلود گزارش» action.
- Trade Explorer (Tier 3) is reachable from Charts («مشاهده‌ی معاملات خام») and Diagnosis («مشاهده‌ی معاملات مرتبط» on expanded evidence cards).

### 4.6 Phase 3 Nice-to-Have (NEW in v1.2)

The following enhancements are **not Phase 1 requirements** but are designed and documented so Phase 3 implementation can include them as low-risk additions. They reduce cognitive load for power users without cluttering the experience for casual users.

| Enhancement | Summary | Full spec |
|---|---|---|
| **Keyboard shortcuts & Command Palette** | `Cmd/Ctrl+K` opens a Spotlight-style palette for fuzzy search across pages, recent analyses, and actions. Plus page-specific shortcuts (`g`+letter for navigation, `u` for Upload, `?` for help, `t`/`l` for theme/language toggle, `d` for PDF download). Disabled in text inputs. Discoverable via `?` overlay. Casual users never need to learn them — the UI is fully usable with mouse/touch. | §6 (full specification) |
| **Offline caching** | IndexedDB caching of the last 3 analyses' JSON reports + last 1 analysis' first trades page. On network failure, fall back to cached data with an honest «شما آفلاین هستید» banner. Read-only cached data; auto-refresh when network returns. Settings toggle (disabled in Phase 1 with «به‌زودی» badge). Designed for flaky networks (mobile, travel, Iranian network conditions). | §7 (full specification) |

**Rationale for documenting now:** Both enhancements touch cross-cutting concerns (navigation, state management, Settings page) that are expensive to retrofit. Documenting them in Phase 2 ensures the Phase 3 component interfaces (e.g., Settings page layout, app shell state) reserve space for them from day one, even if implementation ships later.

---

## 5. Phase 3 Implementation Preview

### 5.1 API Addition Required (Trade Explorer only — clarified in v1.1)

**New endpoint:** `GET /api/v1/analyses/{analysis_id}/trades`

**Purpose:** Return the normalized trade-level DataFrame for the Trade Explorer UI. Serialization only — no engine logic, no recomputation, no scoring.

**Why this is API-layer only and respects the engine constraint:**

The V23 `AnalysisRecord` (in `api/services/store.py`) already preserves `record.doctor.df` — the normalized DataFrame produced by `BehaviorEngine.__init__()` via `ColumnMapper.normalize()`. This data is **already in memory** after analysis completes. The new endpoint simply serializes this existing DataFrame to JSON. It does not:

- Call any `BehaviorEngine`, `ScoreEngine`, `CoachingEngine`, or other analytical method.
- Recompute any score, threshold, or diagnosis.
- Modify the DataFrame or any engine state.
- Introduce any new analytical logic.

This is the same pattern as the existing `GET /analyses/{id}/report` endpoint, which reads from `record.result` and `record.coach` (also already in memory) without recomputing.

#### 5.1.1 Implementation sketch

```python
# api/routers/trades.py (new file)
from fastapi import APIRouter, Depends, Query, Optional
from api.dependencies import enforce_rate_limit, get_store, verify_api_key
from api.models.analysis import TradesResponse  # new Pydantic model
from api.services.store import AnalysisStore
from utils.logger import get_logger

log = get_logger("api.routers.trades")

router = APIRouter(
    tags=["Trades"],
    dependencies=[Depends(enforce_rate_limit), Depends(verify_api_key)],
)

@router.get(
    "/analyses/{analysis_id}/trades",
    response_model=TradesResponse,
    summary="دریافت معاملات خام نرمال‌شده (JSON)",
    description="داده‌ی معامله‌ای نرمال‌شده را برمی‌گرداند — بدون هیچ محاسبه‌ی تحلیلی. "
                "فیلترها نمایشی هستند (pandas boolean indexing روی ستون‌های از قبل نرمال‌شده).",
)
async def get_trades(
    analysis_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    side: Optional[str] = Query(None, regex="^(long|short)$"),
    outcome: Optional[str] = Query(None, regex="^(win|loss)$"),
    store: AnalysisStore = Depends(get_store),
) -> TradesResponse:
    record = store.get_analysis(analysis_id)
    df = record.doctor.df.copy()

    # Presentational filtering only — no analytical logic
    if side == "long":
        df = df[df.get("Side", "long") == "long"]  # column name per ColumnMapper
    elif side == "short":
        df = df[df.get("Side", "long") == "short"]
    if outcome == "win":
        df = df[df["Profit"] > 0]
    elif outcome == "loss":
        df = df[df["Profit"] < 0]

    total = len(df)
    start = (page - 1) * page_size
    end = start + page_size
    page_df = df.iloc[start:end]

    # Serialize: ISO dates, plain dicts — no engine objects
    trades = page_df.to_dict(orient="records")
    # Convert any numpy/pandas types to JSON-native
    for t in trades:
        for k, v in t.items():
            if hasattr(v, "isoformat"):
                t[k] = v.isoformat()
            elif hasattr(v, "item"):
                t[k] = v.item()

    return TradesResponse(
        trades=trades,
        total=total,
        page=page,
        page_size=page_size,
    )
```

#### 5.1.2 Pydantic model

```python
# api/models/analysis.py (add to existing file)
class TradesResponse(BaseModel):
    trades: List[Dict[str, Any]]
    total: int
    page: int
    page_size: int
```

#### 5.1.3 Router registration

```python
# api/main.py (add one line)
from api.routers import analyses, config as config_router, health, history, reports, trades, uploads
app.include_router(trades.router, prefix=API_PREFIX)
```

#### 5.1.4 Test enforcement

Add to `tests/test_api.py`:

```python
def test_no_business_logic_duplicated_in_api_layer():
    """No file under api/ may import an engine class directly.
    Trades router is no exception — it serializes record.doctor.df,
    it does NOT call BehaviorEngine/ScoreEngine/etc."""
    # ... existing check ...
    # This test already exists; the new trades.py file must pass it.
    # Verify by ensuring api/routers/trades.py does not import from engines/.
```

Add a new test:

```python
def test_trades_endpoint_returns_serialized_df():
    """GET /analyses/{id}/trades returns the normalized DataFrame as JSON,
    without recomputing any score or diagnosis."""
    # ... upload + analyze ...
    response = client.get(f"/api/v1/analyses/{analysis_id}/trades?page=1&page_size=10")
    assert response.status_code == 200
    data = response.json()
    assert "trades" in data
    assert "total" in data
    assert data["page"] == 1
    assert len(data["trades"]) <= 10
    # Each trade should have standard columns (Open Time, Profit, Size, etc.)
    if data["trades"]:
        assert "Profit" in data["trades"][0]
```

#### 5.1.5 What this does NOT change

- ❌ `engines/` — untouched.
- ❌ `core/service.py` — untouched.
- ❌ `utils/` — untouched.
- ❌ `llm/` — untouched.
- ❌ `reporting/` — untouched.
- ❌ Existing API endpoints — untouched.
- ✅ `api/routers/trades.py` — new file.
- ✅ `api/models/analysis.py` — add `TradesResponse` class.
- ✅ `api/main.py` — add one import + one `include_router` line.
- ✅ `tests/test_api.py` — add one test + verify existing test passes.

**This is the ONLY API-layer addition flagged by Phase 2.** Total diff: ~80 lines of new code, all in `api/`, none touching the engine.

---

### 5.2 Routing Structure (App Router — updated v1.1 with Trade Explorer)

```
app/
├── (public)/
│   ├── page.tsx                    # Home
│   ├── sample/page.tsx             # Sample Report
│   └── layout.tsx                  # Public layout (no sidebar)
├── (app)/
│   ├── layout.tsx                  # App layout (sidebar + top bar + bottom tab bar)
│   ├── upload/page.tsx
│   ├── history/page.tsx
│   ├── dashboard/[analysisId]/page.tsx
│   ├── behavioral/[analysisId]/page.tsx
│   ├── diagnosis/[analysisId]/page.tsx
│   ├── coaching/[analysisId]/page.tsx
│   ├── trader-dna/[analysisId]/page.tsx
│   ├── edge-map/[analysisId]/page.tsx
│   ├── charts/[analysisId]/page.tsx
│   ├── trades/[analysisId]/page.tsx    # NEW — Trade Explorer (Tier 3, between Charts and Trends)
│   ├── trends/page.tsx
│   ├── report/[analysisId]/page.tsx
│   └── settings/page.tsx
├── api/                            # BFF Route Handlers
│   ├── uploads/route.ts
│   ├── analyses/route.ts
│   ├── analyses/[id]/route.ts
│   ├── analyses/[id]/report/route.ts
│   ├── analyses/[id]/report.html/route.ts
│   ├── analyses/[id]/report.pdf/route.ts
│   ├── analyses/[id]/trades/route.ts   # NEW — proxies to V23 trades endpoint
│   └── history/route.ts
└── layout.tsx                      # Root layout
```

---

### 5.3 Page Count Update (updated v1.1)

Phase 1 listed 13 build pages + 3 future-ready. Phase 2 v1.0 added Trade Explorer as a 14th build page. **v1.1 confirms: 14 build pages + Settings stub + 2 future-ready (Mentor Workspace, Team Dashboard).**

| # | Page | Tier | Phase 1 status | v1.1 status |
|---|---|---|---|---|
| 1 | Home / Landing | Public | Build | Build (unchanged) |
| 2 | Sample Report | Public | Build | Build (unchanged) |
| 3 | Upload | Entry | Build | Build (unchanged) |
| 4 | History | Entry | Build | Build (unchanged) |
| 5 | Dashboard | Primary | Build | Build (unchanged — emotional center) |
| 6 | Behavioral Analysis | Primary | Build | Build (unchanged) |
| 7 | Diagnosis | Primary | Build | Build (unchanged) |
| 8 | Coaching | Primary | Build | Build (unchanged) |
| 9 | Trader DNA | Deep dive | Build | Build (unchanged) |
| 10 | Edge Map | Deep dive | Build | Build (unchanged) |
| 11 | Charts | Deep dive | Build | Build (unchanged) |
| 12 | **Trade Explorer** | **Deep dive** | **Not in Phase 1** | **Build (NEW — requires API addition §5.1)** |
| 13 | Trends | Deep dive | Build | Build (unchanged) |
| 14 | Report | Action | Build | Build (unchanged) |
| 15 | Settings | Future | Stub | Stub (updated v1.1 — added offline cache section) |
| 16 | Mentor Workspace | Future | Reserved | Reserved (unchanged) |
| 17 | Team Dashboard | Future | Reserved | Reserved (unchanged) |

---

## 6. Keyboard Shortcuts & Command Palette (NEW in v1.1)

**Purpose:** Power-user acceleration without cluttering the UI for casual users. Reduces cognitive load by providing a single discovery surface for all navigation and actions.

### 6.1 Command Palette (Cmd/Ctrl + K)

A Spotlight/Linear-style command palette, opened with `Cmd+K` (macOS) / `Ctrl+K` (Windows/Linux). Visible to all users (no auth required). Discoverable via a small «⌘K» hint in the top bar (desktop) and in the mobile "More" sheet.

**Behavior:**
- Opens as a centered modal (desktop) / full-screen sheet (mobile).
- Single search input, autofocus on open.
- Fuzzy search across: pages, recent analyses, actions.
- Keyboard navigation: ↑↓ to move, Enter to select, Esc to close.
- Results grouped: «صفحات» (Pages) · «تحلیل‌های اخیر» (Recent Analyses) · «اقدامات» (Actions).
- Mouse/touch also supported — not keyboard-only.

**Indexed items:**

| Group | Items |
|---|---|
| Pages | All 14 build pages + Settings (with their icons). |
| Recent Analyses | Last 5 from History (filename + date). Selecting navigates to that analysis's Dashboard. |
| Actions | «آپلود فایل جدید» · «دانلود PDF آخرین تحلیل» · «دانلود HTML آخرین تحلیل» · «تغییر تم» · «تغییر زبان» · «پاک کردن داده‌ی محلی» |

### 6.2 Page-Specific Shortcuts

| Shortcut | Action | Where |
|---|---|---|
| `g` then `d` | Go to Dashboard | Anywhere in app |
| `g` then `b` | Go to Behavioral | Anywhere in app |
| `g` then `i` | Go to Diagnosis (i for "issue") | Anywhere in app |
| `g` then `c` | Go to Coaching | Anywhere in app |
| `g` then `r` | Go to Report | Anywhere in app |
| `g` then `h` | Go to History | Anywhere in app |
| `g` then `t` | Go to Trade Explorer | Anywhere in app |
| `g` then `n` | Go to Trends (n for "trend") | Anywhere in app |
| `u` | Go to Upload | Anywhere in app |
| `?` | Show keyboard shortcuts help | Anywhere in app |
| `Esc` | Close modal/drawer/palette | Anywhere |
| `/` | Focus search (on pages with search: History, Trade Explorer) | History, Trade Explorer |
| `n` | New analysis (alias for `u`) | History |
| `d` | Download PDF (current analysis) | Any analysis page |
| `t` | Toggle theme | Anywhere |
| `l` | Toggle language | Anywhere |

**Implementation notes:**
- Use a library like `react-hotkeys-hook` or `cmdk` (for the palette).
- Shortcuts are disabled when focus is in a text input or textarea (except `Esc`).
- All shortcuts respect `prefers-reduced-motion` (palette opens instantly, no animation).
- Shortcuts are discoverable via the `?` help overlay and the command palette itself.
- Mobile: no keyboard shortcuts (touch devices). Command palette accessible via a button in the "More" sheet.

### 6.3 Cognitive load rationale

- **Casual users** never need to learn shortcuts — the UI is fully usable with mouse/touch.
- **Power users** (mentors, frequent re-analyzers) get Linear-style speed without UI clutter.
- **Command palette** is a single discovery surface — type what you want, find it. No need to memorize.
- **Shortcuts help** (`?`) is always one key away — no hidden features.

---

## 7. Offline Handling (Future Suggestion — NEW in v1.1)

**Purpose:** Let users view their last analysis even when offline. Not Phase 1, but designed so Phase 3+ implementation is additive.

### 7.1 Why this matters

Trading Doctor's users may be on flaky connections (mobile, travel, Iranian network conditions). Losing access to a just-computed analysis because the network dropped is a trust-killer. Caching the last analysis locally preserves the emotional-center moment.

### 7.2 Future design (when implemented)

**Storage:** IndexedDB (larger capacity than `localStorage`, structured data).

**What to cache:**
- The full `AnalysisReport` JSON (from `GET /analyses/{id}/report`) for the last 3 analyses.
- The normalized trades (from `GET /analyses/{id}/trades` first page) for the last 1 analysis.
- **Not cached:** HTML/PDF report bytes (too large; user can re-download when online).

**Behavior:**
- On every successful analysis fetch, write to IndexedDB with a TTL of 7 days.
- On app load, if network fails, fall back to cached data with a banner: «شما آفلاین هستید — آخرین تحلیل ذخیره‌شده نمایش داده می‌شود».
- Cached data is read-only — no edits, no re-analysis offline.
- When network returns, silently refresh in the background; toast if data changed.

**Settings toggle:** «ذخیره‌ی تحلیل آخر به‌صورت محلی (آفلاین)» — disabled in Phase 1 with «به‌زودی» badge (see §2.10/§3.15).

**Mobile considerations:**
- IndexedDB works on mobile browsers (iOS Safari 14+, Chrome Android).
- Storage quota is limited (~50MB typical) — only cache last 3 reports, not all history.
- Service Worker (future) could enable full offline app shell.

### 7.3 Why this is future, not Phase 1

- Adds complexity (IndexedDB schema, TTL logic, conflict resolution).
- Requires careful invalidation (what if the user re-analyzes and the new result differs?).
- Phase 1 priority is the core flow (upload → analyze → understand); offline is a refinement.
- Documented now so the IA and Settings page reserve space for it.

### 7.4 Cognitive load rationale

- Offline state is **surfaced honestly** (banner), not hidden.
- Cached data is **clearly marked** as potentially stale.
- User can always retry when online — no dead ends.

---

## 8. Master Phase 2 UX Specification (Cross-Reference System — NEW in v1.1)

**Purpose:** Three Phase 2 documents exist (`phase1_product_strategy.md`, `phase2_ux_visual_design.md`, `phase2_ux_architecture.md`). This section provides a cross-reference map so Phase 3 implementation can navigate between them without ambiguity.

### 8.1 Document roles

| Document | Role | Primary audience |
|---|---|---|
| `phase1_product_strategy.md` | **What** we're building and **why**. IA, personas, goals, feature inventory, page list. | Product, engineering leadership |
| `phase2_ux_visual_design.md` | **How it looks**. Design system, color tokens, typography, components, motion, accessibility specs. | Designers, frontend engineers |
| `phase2_ux_architecture.md` (this document) | **How it behaves**. User flows, per-page UX specs, interaction logic, states, API additions. | UX architects, frontend engineers |

### 8.2 Topic cross-reference map

| Topic | Phase 1 ref | Visual Design ref | Architecture ref (this doc) |
|---|---|---|---|
| Product vision & goals | §1–2 | — | — |
| User personas | §3 | — | — (drives all flows) |
| Feature inventory (V23 mapping) | §6 | — | §2.8 (Trade Explorer API), §5.1 |
| Information Architecture | §7 | — | §4.2 (progressive disclosure tiers) |
| Navigation Structure | §8 | §11 (responsive) | §10.2 (updated nav table v1.1) |
| Page Hierarchy | §9 | — | §4.2, §5.3 |
| Dashboard structure | §10 | §12.5 (emotional center) | §2.5, §3.5, §10.1 (375px math) |
| User Permissions (future) | §11 | — | §2.2 (auth flow), §2.11 (subscription) |
| Module Relationships | §12 | — | §2.x (each flow's drill-down links) |
| Cognitive Load Strategy | §15 | — | §1.1, §4.1 |
| SaaS UX Principles | §16 | §2.2 (checklist) | §1 (principles) |
| Page List | §17 | §12 (page specs) | §3 (per-page UX), §5.3 (count) |
| Design System | — | §2–§8 | — (consumes) |
| Color Tokens | — | §3 | — (consumes) |
| Typography | — | §4 | — (consumes) |
| Spacing & Layout | — | §5 | §11 (responsive verification) |
| Iconography | — | §6 | §10.2 (nav icon mapping) |
| Component System | — | §7 | §3 (components referenced per page) |
| Motion | — | §8 | §2.x (interaction patterns per flow) |
| RTL & Persian | — | §9 | §10.3 (RTL flow verification) |
| Accessibility | — | §10 | §3 (per-page accessibility), §10 (validation) |
| Responsive Strategy | — | §11 | §4.4, §10.1 (Dashboard 375px) |
| User Flows | — | — | §2 (12 flows) |
| Per-Page UX Specs | — | §12 (visual specs) | §3 (12-attribute UX specs) |
| States (Empty/Loading/Error/Success) | — | §7 (component states) | §3 (per-page states), §4.3 |
| Keyboard Shortcuts | — | — | §6 (NEW v1.1) |
| Offline Handling | — | — | §7 (NEW v1.1) |
| API Additions | — | — | §5.1 (Trade Explorer endpoint) |
| Phase 3 Implementation | — | §15 | §5 (routing, stack) |
| Pre-Phase-3 Validation | — | §16 (checklist) | §10 (comprehensive validation — NEW v1.1) |

### 8.3 Conflict resolution rule

If any two documents conflict, the **priority order** is:

1. **Phase 1 hard constraints** (Dashboard as emotional center, mobile-first, Persian-first RTL, engine untouched) — these are non-negotiable and override everything.
2. **This document (Phase 2 UX Architecture v1.1)** — for interaction behavior, flows, states, API additions.
3. **Phase 2 Visual Design** — for visual appearance, tokens, components, motion.
4. **Phase 1 Product Strategy** — for IA, personas, feature inventory (reference, not implementation detail).

If a conflict is found during Phase 3, the implementer should flag it and the UX Architect resolves it by updating the appropriate document (with a version bump and changes summary).

### 8.4 Versioning

All three documents carry a version in their header. Changes require:
- Version bump (v1.0 → v1.1).
- Entry in Changes Summary (this document §11; equivalent in others if they're updated).
- Worklog entry in `/home/z/my-project/worklog.md`.

---

## 9. Pre-Phase-3 Validation Checklist (NEW in v1.1 — comprehensive)

**Purpose:** A single, testable checklist that must pass before Phase 3 implementation is considered complete. Covers responsive, RTL, accessibility, keyboard, error scenarios, and the Phase 1 hard constraints.

### 9.1 Responsive Validation (especially Dashboard at 375px)

| # | Test | Pass criteria |
|---|---|---|
| R1 | Dashboard at 375 × 667 (iPhone SE) | All 4 emotional-center cards (Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action) visible without scrolling. Verified math: 140+120+120+110px + 3×16px gaps + 56px top bar = 594px; viewport 667px; buffer 73px. |
| R2 | Dashboard at 375 × 667 with iOS Safari URL bar visible | Buffer reduces to ~23px — still fits, but tight. Verify no clipping. |
| R3 | Dashboard at 414 × 896 (iPhone 11) | All 4 cards visible with comfortable buffer. |
| R4 | Dashboard at 768 × 1024 (iPad portrait) | 2-column layout: Health+Leak left, Strength+Action right. |
| R5 | Dashboard at 1024 × 768 (iPad landscape) | 4-column equal-width grid. |
| R6 | Dashboard at 1280 × 800 (laptop) | 4-column grid with sidebar visible. |
| R7 | Dashboard at 1536 × 960 (desktop) | 4-column grid, max-width container, centered. |
| R8 | Every page at 375 / 768 / 1024 / 1280 / 1536px | No horizontal scroll. No clipped content. Touch targets ≥44pt on mobile. |
| R9 | Upload page mobile | Dropzone copy says «برای انتخاب فایل ضربه بزنید» (no "drag" mention). |
| R10 | Tables on mobile | Render as card list, not horizontal scroll. |
| R11 | Modals on mobile | Render as bottom sheets, swipe-down to dismiss. |
| R12 | Bottom tab bar | Visible only on `< md` (mobile). Hidden on tablet/desktop. |
| R13 | Sidebar | Off-canvas drawer on mobile. Icon-rail on tablet. Full on desktop. |

### 9.2 RTL Flow Validation

| # | Test | Pass criteria |
|---|---|---|
| RTL1 | Default direction | `dir="rtl"` on `<html>`. Default language `fa`. |
| RTL2 | Sidebar position | On right side in RTL, left side in LTR. |
| RTL3 | Text alignment | All body text right-aligned in RTL. |
| RTL4 | Icons | Directional icons (arrows, chevrons) flipped in RTL. |
| RTL5 | Charts | Time-series x-axis reversed in RTL (earliest right, latest left). |
| RTL6 | Numbers in prose | Persian numerals (۰۱۲۳۴۵۶۷۸۹) in prose. |
| RTL7 | Numbers in data fields | Latin numerals in `--font-mono` data fields. |
| RTL8 | Severity badges | Severity color + text label + icon — not color alone. Works in both directions. |
| RTL9 | Modal/drawer | Slides in from correct side (left in RTL for right-anchored drawer). |
| RTL10 | Language toggle | Instant switch (no reload). Both `fa` and `en` fully translated. |
| RTL11 | Logical CSS properties | All margins/paddings/borders use `inline-start`/`inline-end`, not `left`/`right`. |
| RTL12 | Date format | Shamsi calendar in `fa`, Gregorian in `en`. |

### 9.3 WCAG AA Accessibility Validation

| # | Test | Pass criteria |
|---|---|---|
| A1 | Body text contrast (dark theme) | ≥4.5:1 against `--bg-base` and `--bg-elevated`. |
| A2 | Body text contrast (light theme) | ≥4.5:1 against `--bg-base` and `--bg-elevated`. |
| A3 | Secondary text contrast (both themes) | ≥3:1. |
| A4 | Non-text UI contrast (icons, borders) | ≥3:1. |
| A5 | Severity colors (both themes) | All 4 severity colors distinguishable by brightness/shape, not hue alone. Verified with colorblind simulator (protanopia, deuteranopia, tritanopia). |
| A6 | Focus rings | 3px solid `--ring-focus`, 2px offset, on every focusable element. Never removed without replacement. |
| A7 | Keyboard navigation | Every interactive element reachable via Tab in logical order. |
| A8 | Screen reader (NVDA on Windows) | All 12 flows completable. No unlabeled controls. No confusing focus traversal. |
| A9 | Screen reader (VoiceOver on macOS/iOS) | Same as A8. |
| A10 | `prefers-reduced-motion` | All animation/transition durations set to 0.01ms. Skeletons switch to static (no pulse). Page still fully functional. |
| A11 | Touch targets | ≥44×44pt on mobile. Adjacent targets ≥8pt apart. |
| A12 | ARIA labels | Every interactive element has `aria-label` or visible text label. Decorative icons `aria-hidden`. |
| A13 | Charts | Each chart has `aria-label` summarizing data + visually-hidden `<table>` alternative. |
| A14 | Forms | Labels associated with inputs. Error messages `aria-live="polite"` and `aria-describedby`. |
| A15 | Skip-to-content link | Present on every page. Visually hidden until focused. |
| A16 | Color not sole signal | Every color-coded indicator (severity, profit/loss) has text + icon. |
| A17 | Document structure | One `<h1>` per page. Logical heading hierarchy (`<h2>` → `<h3>` → ...). |
| A18 | Live regions | Toasts `aria-live="polite"`. Errors `aria-live="assertive"`. |

### 9.4 Keyboard Navigation Validation

| # | Test | Pass criteria |
|---|---|---|
| K1 | Command palette | `Cmd/Ctrl+K` opens. ↑↓ navigate, Enter select, Esc close. |
| K2 | Page shortcuts | `g` then `d`/`b`/`i`/`c`/`r`/`h`/`t`/`n` navigate to pages. |
| K3 | `u` shortcut | Opens Upload page. |
| K4 | `?` shortcut | Opens keyboard shortcuts help. |
| K5 | `Esc` | Closes any open modal/drawer/palette. |
| K6 | `t` / `l` shortcuts | Toggle theme / language. |
| K7 | `d` shortcut (on analysis pages) | Triggers PDF download. |
| K8 | Shortcuts in text inputs | All shortcuts (except `Esc`) disabled when focus is in input/textarea. |
| K9 | Tab order | Matches visual order on every page. |
| K10 | Focus trap | Modals/drawers trap focus inside while open. Returns focus to trigger on close. |

### 9.5 Error Scenario Validation

| # | Test | Pass criteria |
|---|---|---|
| E1 | Upload: file too large (client-side) | Inline error before upload. CTA stays disabled. |
| E2 | Upload: wrong format (client-side) | Inline error before upload. CTA stays disabled. |
| E3 | Upload: 422 invalid content (server) | Engine message displayed inline + «فرمت‌های پشتیبانی‌شده» link. |
| E4 | Upload: network error | «اتصال برقرار نشد» + retry. File preserved. |
| E5 | Analysis: 422 invalid data | Error card with engine message + «بازگشت به آپلود». |
| E6 | Analysis: 500 server error | «خطای داخلی سرور» + retry. |
| E7 | Analysis: timeout (60s none / 90s LLM) | «تحلیل بیش از حد طول کشید» + retry. |
| E8 | Analysis: 429 rate limited | «تعداد درخواست‌ها بیش از حد» + countdown + auto-retry. |
| E9 | Analysis: elapsed exceeds estimate | Soft reassurance shown: «کمی بیشتر از حد انتظار طول می‌کشد — هنوز در حال تحلیل است». |
| E10 | Dashboard: report fetch fails | Error card replaces 4 cards + retry + «بازگشت به تاریخچه». |
| E11 | Any page: 404 analysis not found | «تحلیل یافت نشد» + CTA to History. |
| E12 | Any page: network error | Error card + retry. |
| E13 | Report: PDF generation fails | «تولید PDF ناموفق بود» + retry + HTML fallback offered. |
| E14 | Report: HTML generation fails | Same with PDF fallback. |
| E15 | Charts: render fails | «نمودار قابل رسم نیست» + «مشاهده‌ی داده‌ی خام» fallback. |
| E16 | Trade Explorer: no trades match filter | «هیچ معامله‌ای با این فیلترها یافت نشد» + «پاک کردن فیلترها». |
| E17 | History: delete fails | Toast «حذف ناموفق بود. دوباره تلاش کنید». |
| E18 | Settings: reset data | Confirmation modal → clears localStorage → toast → reload. |

### 9.6 Phase 1 Hard Constraints Validation

| # | Test | Pass criteria |
|---|---|---|
| H1 | Dashboard emotional center | 4 cards (Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action) visible without scrolling on 375 × 667. (Same as R1 — duplicated here for emphasis.) |
| H2 | Mobile-first | Base styles target 375px. Breakpoints enhance upward. No `max-width` queries. |
| H3 | Persian-first RTL | Default `dir="rtl"`, `lang="fa"`. LTR/English is full alternative. (Same as RTL1 — duplicated for emphasis.) |
| H4 | Engine untouched | No frontend code imports from `engines/`. No client-side score/threshold/diagnosis computation. Only API addition is `GET /analyses/{id}/trades` (§5.1), which is serialization-only and test-enforced. |
| H5 | Clarity > Complexity | Every page has one primary CTA. Top-3 default for lists. No page tries to do two things. |
| H6 | Actionability > Information Density | Every screen has a clear next action. No decorative-only content. |
| H7 | Premium SaaS quality | No emojis as icons (Phosphor SVGs only). Token-driven theming. 4/8dp spacing. Smooth 150–300ms transitions. Both themes polished. |

### 9.7 Engine Integration Validation

| # | Test | Pass criteria |
|---|---|---|
| EN1 | No engine imports in frontend | `grep -r "from engines" app/` returns nothing. |
| EN2 | No client-side scoring | No `revenge_score`, `overtrading_score`, etc. computed in JS. All values come from API responses. |
| EN3 | HTML/PDF downloads use existing endpoints | `/report.html` and `/report.pdf` hit `GET /api/v1/analyses/{id}/report.html` and `/report.pdf` directly. No client-side rendering. |
| EN4 | Trade Explorer endpoint is serialization-only | `api/routers/trades.py` does not import any engine class. Test `test_no_business_logic_duplicated_in_api_layer` passes with the new file. |
| EN5 | Error envelope handled uniformly | All API errors (4xx, 5xx) handled via the standard `{"error":{code,message,details}}` envelope. No raw tracebacks shown to user. |

---

## 10. Phase 1 Cross-Document Updates (NEW in v1.1)

This section documents the updates that **Phase 1** (`phase1_product_strategy.md`) needs to stay aligned with Phase 2 v1.1. These are documented here so a future edit pass can apply them in one shot.

### 10.1 Dashboard 375px mobile layout (verification — no change needed)

Phase 1 §10 described a 5-card header row. Phase 2 Visual Design §12.5 and this document §2.5/§3.5 refined this to the 4-card emotional-center layout (per the user's Phase 1 approval refinement #2).

**Math verification (final):**
- Card 1 (Overall Health): 140px (ScoreGauge 96px numeral + severity word + label)
- Card 2 (Biggest Leak): 120px (icon + label + $ impact + severity badge)
- Card 3 (Biggest Strength): 120px (icon + label + supporting metric)
- Card 4 (Immediate Next Action): 110px (verb-led sentence + CTA)
- Gaps: 3 × 16px = 48px
- Total content: 140 + 120 + 120 + 110 + 48 = **538px**
- Top bar (mobile): 56px
- Total above-fold: 56 + 538 = **594px**
- iPhone SE viewport: 375 × 667px
- Buffer: 667 − 594 = **73px** (accommodates iOS Safari's dynamic URL bar, which can consume ~50px)
- Bottom tab bar (64px + safe-area-inset): **below** the fold — correct, the 4 cards are the above-fold priority.

**Conclusion:** All 4 emotional-center cards visible without scrolling on 375 × 667. ✓ No change needed to Phase 1 or Phase 2 Visual Design.

### 10.2 Phase 1 §8 Navigation Structure (UPDATE NEEDED)

Phase 1 §8 listed 10 nav items. Phase 2 v1.1 adds Trade Explorer as the 8th item (between Charts and Trends). The updated nav table:

| Position | Nav item | User question it answers | Icon (Phosphor) |
|---|---|---|---|
| Top | Upload (CTA, always visible) | "Analyze new trades" | `UploadSimple` |
| 1 | Dashboard | "How am I doing overall?" | `Gauge` |
| 2 | Behavioral Analysis | "Which behaviors are costing me?" | `ChartBar` |
| 3 | Diagnosis | "What's my main leak?" | `Stethoscope` |
| 4 | Coaching | "What do I do about it?" | `Lightbulb` |
| 5 | Trader DNA | "What kind of trader am I?" | `Dna` |
| 6 | Edge Map | "When/where am I best and worst?" | `MapPin` |
| 7 | Charts | "Show me the visuals" | `ChartLineUp` |
| **8** | **Trade Explorer (NEW)** | **"Show me the raw trades"** | **`Table`** |
| 9 | Trends | "Am I improving over time?" | `TrendUp` |
| 10 | Report | "Give me a downloadable report" | `FileText` |
| 11 | History | "What have I analyzed before?" | `ClockCounterClockwise` |
| Bottom | Settings (future) | "Configure my account" | `Gear` |

**Action:** Update Phase 1 §8 with this table on next edit pass.

### 10.3 Phase 1 §9 Page Hierarchy (UPDATE NEEDED)

Phase 1 §9 Tier 3 list needs Trade Explorer added:

```
Tier 3 — Deep dive (require an Analysis in context, used by engaged users)
  Trader DNA      → drill from Diagnosis
  Edge Map        → drill from Behavioral or Dashboard
  Charts          → drill from Dashboard or Behavioral
  Trade Explorer  → drill from Charts or Diagnosis (NEW)
  Trends          → requires 2+ Analyses; drill from Dashboard or History
```

**Action:** Update Phase 1 §9 Tier 3 with Trade Explorer on next edit pass.

### 10.4 Phase 1 §17 Page List (UPDATE NEEDED)

Phase 1 §17 listed 13 build pages + 3 future-ready. Add Trade Explorer as #12 (between Charts and Trends):

```
#### 12. Trade Explorer (Deep Dive — NEW in Phase 2)
- **Purpose:** Browse normalized trade-level data. Filter, sort, inspect individual trades. Verify engine findings.
- **Engine dependency:** `GET /api/v1/analyses/{id}/trades` (NEW endpoint — serialization only, no engine changes. See Phase 2 Architecture §5.1.)
- **Phase 1 status:** Build (Phase 2 addition; requires the flagged API endpoint).
```

**Action:** Update Phase 1 §17 with this entry on next edit pass.

### 10.5 Phase 1 §6 Feature Inventory (UPDATE NEEDED)

Phase 1 §6.11 (Operational) should add the new endpoint:

```
### 6.11 Operational (updated v1.1)

| Feature | Backend source |
|---|---|
| Liveness/readiness probe | `GET /api/v1/health` |
| Pre-flight config | `GET /api/v1/config` |
| Trade-level data access (NEW) | `GET /api/v1/analyses/{id}/trades` (serializes `record.doctor.df` — no engine changes) |
```

And Phase 1 §6.12 (Explicitly NOT supported) should clarify that Trade Explorer's CSV export is **client-side from in-memory data** (presentational), not a new server capability.

**Action:** Update Phase 1 §6.11 and §6.12 on next edit pass.

---

## 11. Changes Summary (v1.0 → v1.1)

### 11.1 What changed

| # | Change | Section(s) affected | Rationale |
|---|---|---|---|
| 1 | **Trade Explorer clarified** as Tier 3 Deep Dive page (position 8, between Charts and Trends). API endpoint `GET /api/v1/analyses/{id}/trades` documented as the ONLY API-layer addition (serialization only, no engine changes). Full implementation sketch, Pydantic model, router registration, and test enforcement added. | §2.8, §3.7, §3.11, §3.12, §5.1, §10.2, §10.3, §10.4, §10.5 | User request #1 — proper placement and clear API documentation. |
| 2 | **Analysis Progress Flow: smart time estimation.** LLM-aware: «زیر ۱۰ ثانیه» when `llm_provider=none`, «تا ۲۰–۳۰ ثانیه» when LLM selected. Soft reassurance message if elapsed exceeds estimate. Extended timeout (60s → 90s) when LLM is selected. | §2.4, §3.4, §4.1, §4.3, §9.5 (E7, E9) | User request #2 — smart, honest time estimation. |
| 3 | **Cross-reference consistency.** Verified Dashboard 375px mobile layout math (73px buffer — fits). Updated all cross-references between Phase 1, Visual Design, and Architecture documents. Documented Phase 1 sections needing update (§8, §9, §17, §6) for next edit pass. | §10.1, §10.2, §10.3, §10.4, §10.5, §8 (cross-ref map) | User request #3 — full alignment. |
| 4 | **Keyboard shortcuts & command palette** added. `Cmd/Ctrl+K` palette + page-specific shortcuts (`g`+letter, `u`, `?`, `t`, `l`, `d`, `Esc`). | §6 (NEW), §9.4 (K1–K10) | User request #4 — power-user acceleration without UI clutter. |
| 5 | **Offline handling** documented as future suggestion. IndexedDB caching of last 3 analyses, honest "offline" banner, read-only cached data, Settings toggle (disabled in Phase 1 with «به‌زودی» badge). | §7 (NEW), §2.10, §3.15 | User request #4 — future resilience for flaky networks. |
| 6 | **Master Phase 2 UX Specification cross-reference system** added. Document roles, topic cross-reference map, conflict resolution rule, versioning protocol. | §8 (NEW) | User request #5 — stronger cross-reference system. |
| 7 | **Pre-Phase-3 Validation Checklist** — comprehensive, testable. 7 categories: Responsive (R1–R13), RTL (RTL1–RTL12), WCAG AA (A1–A18), Keyboard (K1–K10), Error scenarios (E1–E18), Phase 1 hard constraints (H1–H7), Engine integration (EN1–EN5). | §9 (NEW, replaces old §6 checklist) | User request #6 — comprehensive validation gate. |
| 8 | Upload Flow tooltip updated to surface LLM time tradeoff *before* commit (consistency with §2.4 smart estimate). | §2.3, §3.3 | Consistency with #2. |
| 9 | Diagnosis and Charts pages updated to link to Trade Explorer. | §2.9, §3.7, §3.11 | Trade Explorer integration. |
| 10 | Settings page updated with Offline Cache section (disabled, future-ready). | §2.10, §3.15 | Consistency with #5. |
| 11 | Bottom tab bar "More" sheet updated to include Trade Explorer. | §2.5, §4.4 | Trade Explorer nav placement. |
| 12 | Cognitive load tactics table updated with "Smart, honest time estimates" row. | §4.1 | Consistency with #2. |
| 13 | Progressive disclosure tiers updated to include Trade Explorer in L3. | §4.2 | Trade Explorer placement. |
| 14 | Page count table updated (14 build + Settings stub + 2 future-ready). | §5.3 | Trade Explorer addition. |
| 15 | Old §6 Pre-Phase-3 Checklist replaced with comprehensive §9 Validation Checklist. | §9 (replaces old §6) | User request #6. |

### 11.2 What did NOT change

- **Phase 1 hard constraints** — Dashboard as emotional center, mobile-first, Persian-first RTL, engine untouched. All preserved.
- **V23 analytical engine** — completely untouched. The only API addition is `GET /analyses/{id}/trades`, which is serialization-only and test-enforced.
- **12 user flows** — all 12 preserved (Onboarding, Auth, Upload, Analysis Progress, Dashboard, Report Exploration, AI Coach, Trade Explorer, Evidence Explorer, Settings, Subscription, History & Return).
- **14 build pages** — all preserved. Trade Explorer was already in v1.0; v1.1 clarifies its placement and API dependency.
- **Phase 2 Visual Design** — no changes required. The Visual Design document already accommodates Trade Explorer (§12.11 Charts page mentions "raw trades" link; component system already includes `DataTable`, `Drawer`, `BottomSheet`). The only Visual Design section worth a minor note: §12 should add a Trade Explorer page spec on next edit pass (see §11.3 below).

### 11.3 Phase 2 Visual Design — recommended updates (for next edit pass)

The Visual Design document (`phase2_ux_visual_design.md`) does not need structural changes, but the following minor additions would improve alignment:

1. **§12 Page-by-Page UX Specs:** Add a `§12.12 Trade Explorer` entry (between Charts and Trends), matching the per-page spec in this document's §3.12. Currently Visual Design §12 jumps from Charts (§12.11) to Trends (§12.12) — Trends should be renumbered to §12.13, Report to §12.14, etc.
2. **§7 Component System:** The component inventory already includes `DataTable`, `Drawer`, `Pagination`, `SegmentedControl`, `Select`, `TextField` — all used by Trade Explorer. No new components needed. Confirm `FilterBar` (composite of SegmentedControl + Select + TextField) is documented as a pattern.
3. **§16 Pre-Delivery Checklist:** Add a line item: "Trade Explorer: filter/sort/pagination work; CSV export functional; drawer/bottom sheet accessible."

These are minor documentation additions, not design changes. The Visual Design system as approved fully supports the Trade Explorer page.

### 11.4 Compatibility statement

This v1.1 document is **fully compatible** with:
- Phase 1 Product Strategy (approved) — with the documented updates in §10.2–§10.5 to be applied on next edit pass.
- Phase 2 Visual Design (approved) — with the minor additions in §11.3 to be applied on next edit pass.
- Phase 1 hard constraints (Dashboard emotional center, mobile-first, Persian-first RTL, engine untouched) — all preserved, all validated in §9.6.
- V23 analytical engine — completely untouched. Only API-layer addition is serialization-only `GET /analyses/{id}/trades`, test-enforced.

---

## 12. Final Changes Summary (v1.1 → v1.2)

This section documents the final polish changes applied in v1.2. All Phase 1 hard constraints are preserved: Dashboard as emotional center, mobile-first, Persian-first RTL, engine untouched.

### 12.1 What changed (v1.1 → v1.2)

| # | Change | Section | Rationale |
|---|---|---|---|
| 1 | **Phase 2 Master Specification Note added.** Recommends merging Visual Design + Architecture into a single Master UX Spec (or heavily cross-linking them) before Phase 3. Includes suggested merged structure. | §0 (NEW) | User request #2 — consolidation recommendation. |
| 2 | **Primary Navigation table made explicit in main body.** Full 12-row table with Trade Explorer at position 8 (Tier 3, icon `Table`), between Charts (7) and Trends (9). Mobile bottom tab bar "More" sheet list updated. | §4.5 (NEW) | User request #1 — explicit nav table with Trade Explorer. |
| 3 | **Page Hierarchy made explicit in main body.** Full tier tree with Trade Explorer in Tier 3 (between Charts and Trends). Hierarchy rules updated to include Trade Explorer's drill-down entry points. | §4.5 (NEW) | User request #1 — explicit page hierarchy with Trade Explorer. |
| 4 | **Phase 3 Nice-to-Have subsection added.** Brief summary of keyboard shortcuts (Cmd/Ctrl+K) and offline caching, with pointers to full specs in §6 and §7. | §4.6 (NEW) | User request #3 — concise pointer under Cross-Cutting Patterns. |
| 5 | **Dashboard 375px confirmation sentence strengthened.** Added explicit "fits comfortably" sentence with 73px buffer callout. | §2.5 | User request #4 — clear confirmation. |
| 6 | **Version bumped to v1.2.** Header and footer updated. | Header, footer | Versioning protocol. |

### 12.2 What did NOT change (v1.1 → v1.2)

- **All 12 user flows** — preserved (Onboarding, Auth, Upload, Analysis Progress, Dashboard, Report Exploration, AI Coach, Trade Explorer, Evidence Explorer, Settings, Subscription, History & Return).
- **All 14 build pages + Settings stub** — preserved.
- **Analysis Progress smart time estimation** — preserved (LLM-aware: «زیر ۱۰ ثانیه» vs «تا ۲۰–۳۰ ثانیه»).
- **Trade Explorer API specification** — preserved (`GET /api/v1/analyses/{id}/trades`, serialization-only, ~80 lines, no engine changes, test-enforced).
- **Pre-Phase-3 Validation Checklist** — preserved (83 testable items across 7 categories in §9).
- **Cross-reference system** — preserved (§8, with §9 reference corrected from v1.1's stale "§9" to "§8" in the header note).
- **Phase 1 hard constraints** — all preserved: Dashboard emotional center (4 cards above fold on 375px), mobile-first, Persian-first RTL, engine untouched.

### 12.3 Terminology consistency (v1.2 polish)

- **"emotional-center cards"** — standardized as the compound-adjective form throughout (refers to the 4 Dashboard cards: Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action).
- **Component references** — all flows reference components from Phase 2 Visual Design §7 inventory (ScoreGauge, EvidenceCard, RecommendationCard, ContextBlockCard, StatCard, DataTable, Drawer, Modal, SegmentedControl, UploadDropzone, FilePill, ProgressStepper, Skeleton, EmptyState, etc.). No fabricated component names.
- **Nav item names** — consistent across §4.5 nav table, §3 per-page specs, §2 flows, and §4.4 mobile patterns.

### 12.4 Phase 2 Visual Design — still recommended updates

As noted in v1.1 §11.3, the Visual Design document needs three minor additions on next edit pass:
1. Add `§12.12 Trade Explorer` page spec (between Charts and Trends).
2. Confirm `FilterBar` composite pattern in §7.
3. Add Trade Explorer line to §16 pre-delivery checklist.

These are unchanged in v1.2. The Master Specification Note (§0 of this document) recommends merging the two documents before Phase 3, which would make these additions moot.

### 12.5 Compatibility statement

This v1.2 document is **fully compatible** with:
- Phase 1 Product Strategy (approved) — with the documented updates in §10.2–§10.5 to be applied on next edit pass (or via the merge in §0).
- Phase 2 Visual Design (approved) — with the minor additions in §11.3 / §12.4 to be applied on next edit pass (or via the merge in §0).
- Phase 1 hard constraints — all preserved, all validated in §9.6.
- V23 analytical engine — completely untouched.

---

**Document version:** v1.2 (Final Polish)
**Status:** For approval — gate for Phase 3 (Implementation)
**Awaiting approval before Phase 3.**
