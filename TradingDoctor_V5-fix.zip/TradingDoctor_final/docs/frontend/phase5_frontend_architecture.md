# Trading Doctor — Phase 5 Frontend Architecture

**Author:** Senior Frontend Architect
**Status:** For approval — gate for Phase 6 (Implementation)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Builds on:** Phase 1 IA (approved) · Phase 2 Visual Design + UX Architecture v1.2 (approved) · Phase 3 Design System v1.1 (approved) · Phase 4 Screen Design Parts 1 & 2 (approved)
**Document version:** v1.0

> **Hard constraint:** Everything in this document integrates with the existing V23 backend **without modifying the backend**. The only API-layer addition is the already-flagged `GET /api/v1/analyses/{id}/trades` endpoint (Phase 2 §5.1, serialization-only, no engine changes). No other backend work is required or assumed.

> **Phase 1 hard constraints (carried — non-negotiable):**
> 1. Mobile-first & responsive by design.
> 2. Dashboard = emotional center (4 cards above fold on 375 × 667).
> 3. Clarity > Complexity · Actionability > Information Density · Premium SaaS > Feature Quantity.
> 4. Persian-first RTL · dark-default + light-supported · engine untouched.

---

## Table of Contents

1. Recommended Framework
2. Project Structure
3. Folder Structure
4. Component Hierarchy
5. Reusable Components
6. State Management
7. API Layer
8. Authentication Layer
9. Routing
10. Theme System
11. Dark Mode Strategy
12. Responsive Strategy
13. Performance Strategy
14. Caching Strategy
15. Lazy Loading
16. Error Handling
17. Accessibility
18. Future Scalability
19. Backend Integration Contract
20. Changes Summary

---

## 1. Recommended Framework

### Primary: Next.js 16 (App Router)

**Why Next.js 16:**

| Requirement | Next.js 16 solution |
|---|---|
| Server-side rendering for fast first paint | RSC (React Server Components) by default |
| Mobile-first performance | Streaming + Suspense + `next/image` + `next/font` |
| File-based routing with layouts | App Router (`app/` directory) |
| API proxy / BFF layer | Route Handlers (`app/api/`) |
| SEO + social sharing | Metadata API, `generateMetadata`, OpenGraph |
| Persian-first RTL | Full `dir="rtl"` support, logical CSS properties |
| Design system integration | Tailwind CSS 4 + shadcn/ui compatibility |
| Auth-ready | Middleware + NextAuth.js v4 (when enabled) |
| Production deployment | Vercel / self-hosted (`output: 'standalone'`) |

**Why NOT alternatives:**
- **Plain Vite + React:** No SSR, no image optimization, no built-in API routes, manual routing. Trading Doctor needs SSR for the landing page and API proxying for the V23 backend.
- **Remix:** Excellent, but smaller ecosystem and less alignment with the shadcn/ui + Tailwind stack already in place.
- **Gatsby:** Overkill for an app that's mostly dynamic (not a content site). Build times would be painful.

**Version pin:** Next.js 16.1+ with Turbopack (stable in 16).

**Language:** TypeScript 5 (strict mode, `noUncheckedIndexedAccess: true`).

### Supporting Libraries

| Library | Purpose | Version | Why |
|---|---|---|---|
| **Tailwind CSS 4** | Styling | 4.x | Token-driven, mobile-first breakpoints, RTL support |
| **shadcn/ui** | Component primitives | Latest | Accessible, token-driven, copy-into-project (not a dependency) |
| **Recharts** | Charts | 2.x | React-native, declarative, accessible (SVG), RTL support |
| **Phosphor Icons** | Iconography | 2.x | 1,334+ icons, 6 weights, RTL-aware, tree-shakeable |
| **cmdk** | Command Palette | 1.x | The library behind Linear/Stripe command palettes |
| **react-hook-form** + **Zod** | Forms + validation | 7.x / 4.x | Performant, schema-first, type-safe |
| **TanStack Query** | Server state | 5.x | Caching, dedup, optimistic updates, background refetch |
| **Zustand** | Client state | 5.x | Lightweight, no boilerplate, perfect for UI state |
| **next-themes** | Theme management | 0.4.x | No FOUC, system preference, SSR-safe |
| **date-fns** + **Intl API** | Date formatting | 4.x | Shamsi calendar via `Intl.DateTimeFormat('fa-IR-u-ca-persian')` |
| **sonner** | Toasts | 2.x | Accessible, performant, stacked |

**Libraries deliberately NOT used:**
- **Redux / Redux Toolkit:** Overkill for this app's state complexity. Zustand + TanStack Query covers everything.
- **Formik:** react-hook-form is more performant and pairs better with Zod.
- **styled-components / emotion:** Tailwind 4 + CSS variables cover all styling needs. CSS-in-JS adds runtime overhead.
- **axios:** `fetch` is sufficient; TanStack Query handles caching/retries.
- **moment.js:** Deprecated; date-fns + Intl is lighter and locale-aware.

---

## 2. Project Structure

### High-level architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Browser (Client)                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Next.js 16 App (RSC + Client Components)                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │   │
│  │  │  App Shell   │  │  Views (14) │  │  Components │      │   │
│  │  │  (Sidebar,   │  │  (Page-level│  │  (18 core + │      │   │
│  │  │  TopBar,     │  │   screens)  │  │  13 composite)│     │   │
│  │  │  BottomTab)  │  │             │  │             │      │   │
│  │  └──────┬───────┘  └──────┬──────┘  └──────┬──────┘      │   │
│  │         │                 │                │              │   │
│  │  ┌──────▼─────────────────▼────────────────▼──────┐       │   │
│  │  │           State Layer                            │       │   │
│  │  │  ┌──────────────┐  ┌──────────────┐            │       │   │
│  │  │  │ TanStack     │  │ Zustand      │            │       │   │
│  │  │  │ Query        │  │ (UI state)   │            │       │   │
│  │  │  │ (server)     │  │              │            │       │   │
│  │  │  └──────┬───────┘  └──────────────┘            │       │   │
│  │  └─────────┼──────────────────────────────────────┘       │   │
│  │            │                                                │   │
│  │  ┌─────────▼──────────────────────────────────────┐       │   │
│  │  │           API Layer (BFF)                       │       │   │
│  │  │  Route Handlers → fetch → V23 FastAPI           │       │   │
│  │  └─────────┬──────────────────────────────────────┘       │   │
│  └────────────┼──────────────────────────────────────────────┘   │
└───────────────┼─────────────────────────────────────────────────┘
                │  HTTPS (internal network)
                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    V23 Backend (Unchanged)                       │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  FastAPI /api/v1/*                                         │   │
│  │  ├── /health, /config (public)                             │   │
│  │  ├── /uploads (multipart)                                  │   │
│  │  ├── /analyses (POST + GET)                                │   │
│  │  ├── /analyses/{id}/report (JSON)                          │   │
│  │  ├── /analyses/{id}/report.html                            │   │
│  │  ├── /analyses/{id}/report.pdf                             │   │
│  │  ├── /analyses/{id}/trades (NEW — Phase 2 §5.1)           │   │
│  │  └── /history                                              │   │
│  └──────────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Analytical Engine (engines/, core/, utils/, llm/)        │   │
│  │  UNTOUCHED                                                  │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Key architectural principles

1. **BFF (Backend-for-Frontend) pattern.** The Next.js app never calls the V23 API directly from the browser. All API calls go through Next.js Route Handlers (`app/api/`), which proxy to the V23 FastAPI backend. This:
   - Hides the V23 API URL from the client.
   - Enables request/response transformation if needed.
   - Provides a single place for auth, rate limiting, and caching headers.
   - Keeps the V23 backend untouched.

2. **Server Components by default.** Pages are RSC; only interactive leaf components are `'use client'`. This minimizes client JS bundle.

3. **Token-driven everything.** No hardcoded values in components. All visual properties come from CSS variables defined in `globals.css`.

4. **Type-safe end-to-end.** TypeScript types in `src/lib/types.ts` mirror the V23 `data_context.py` output exactly. Zod schemas validate API responses at runtime.

5. **Progressive enhancement.** Core content (Dashboard, Report) is server-rendered and readable without JavaScript. Interactions layer on top.

---

## 3. Folder Structure

```
trading-doctor-web/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── (public)/                 # Route group: public (no auth, no sidebar)
│   │   │   ├── page.tsx              # Landing page
│   │   │   ├── sample/
│   │   │   │   └── page.tsx          # Sample report
│   │   │   └── layout.tsx            # Public layout
│   │   │
│   │   ├── (app)/                    # Route group: app (sidebar, analysis-aware)
│   │   │   ├── layout.tsx            # App layout (sidebar + top bar + bottom tab)
│   │   │   ├── upload/
│   │   │   │   └── page.tsx
│   │   │   ├── history/
│   │   │   │   └── page.tsx
│   │   │   ├── dashboard/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── behavioral/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── diagnosis/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── coaching/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── trader-dna/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── edge-map/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── charts/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   ├── trades/
│   │   │   │   └── [analysisId]/
│   │   │   │       ├── page.tsx      # Trade Explorer
│   │   │   │       └── [tradeId]/
│   │   │   │           └── page.tsx  # Trade Detail
│   │   │   ├── trends/
│   │   │   │   └── page.tsx
│   │   │   ├── report/
│   │   │   │   └── [analysisId]/
│   │   │   │       └── page.tsx
│   │   │   └── settings/
│   │   │       └── page.tsx
│   │   │
│   │   ├── (auth)/                   # Route group: auth (future-ready)
│   │   │   ├── signin/
│   │   │   │   └── page.tsx
│   │   │   ├── signup/
│   │   │   │   └── page.tsx
│   │   │   ├── forgot-password/
│   │   │   │   └── page.tsx
│   │   │   └── layout.tsx
│   │   │
│   │   ├── api/                      # BFF Route Handlers
│   │   │   ├── uploads/
│   │   │   │   └── route.ts
│   │   │   ├── analyses/
│   │   │   │   ├── route.ts          # POST /analyses
│   │   │   │   └── [id]/
│   │   │   │       ├── route.ts      # GET /analyses/{id}
│   │   │   │       ├── report/
│   │   │   │       │   └── route.ts  # GET /analyses/{id}/report
│   │   │   │       ├── report.html/
│   │   │   │       │   └── route.ts
│   │   │   │       ├── report.pdf/
│   │   │   │       │   └── route.ts
│   │   │   │       └── trades/
│   │   │   │           └── route.ts  # GET /analyses/{id}/trades (NEW)
│   │   │   └── history/
│   │   │       └── route.ts
│   │   │
│   │   ├── globals.css               # Design tokens + base styles
│   │   ├── layout.tsx                # Root layout (fonts, theme, dir)
│   │   ├── error.tsx                 # Global error boundary
│   │   ├── not-found.tsx             # 404 page
│   │   └── loading.tsx               # Global loading skeleton
│   │
│   ├── components/
│   │   ├── ui/                       # shadcn/ui primitives (50+ components)
│   │   │   ├── button.tsx
│   │   │   ├── card.tsx
│   │   │   ├── input.tsx
│   │   │   ├── dialog.tsx
│   │   │   ├── table.tsx
│   │   │   └── ... (existing shadcn set)
│   │   │
│   │   ├── td/                       # Trading Doctor custom components
│   │   │   ├── score-gauge.tsx       # ScoreGauge + SeverityBadge + StatCard
│   │   │   ├── app-shell.tsx         # Sidebar + TopBar + BottomTabBar
│   │   │   ├── empty-states.tsx      # EmptyState + ErrorState + SkeletonCard
│   │   │   ├── evidence-card.tsx     # Composite: severity-bordered evidence card
│   │   │   ├── recommendation-card.tsx
│   │   │   ├── context-block-card.tsx
│   │   │   ├── history-item-card.tsx
│   │   │   ├── upload-dropzone.tsx
│   │   │   ├── file-pill.tsx
│   │   │   ├── progress-stepper.tsx
│   │   │   ├── filter-bar.tsx
│   │   │   ├── trade-detail-drawer.tsx
│   │   │   ├── quick-jump-tile.tsx
│   │   │   └── command-palette.tsx
│   │   │
│   │   ├── charts/                   # Chart components (Recharts wrappers)
│   │   │   ├── equity-curve.tsx
│   │   │   ├── drawdown-chart.tsx
│   │   │   ├── pnl-distribution.tsx
│   │   │   ├── hourly-heatmap.tsx
│   │   │   ├── weekday-bar.tsx
│   │   │   ├── streaks-bar.tsx
│   │   │   ├── score-radar.tsx
│   │   │   └── trend-line.tsx
│   │   │
│   │   └── providers/                # Context providers
│   │       ├── theme-provider.tsx    # next-themes wrapper
│   │       ├── query-provider.tsx    # TanStack Query wrapper
│   │       └── app-state-provider.tsx # Zustand store provider
│   │
│   ├── views/                        # Page-level view components
│   │   ├── landing.tsx
│   │   ├── upload.tsx
│   │   ├── dashboard.tsx
│   │   ├── behavioral.tsx
│   │   ├── diagnosis.tsx
│   │   ├── coaching.tsx
│   │   ├── trader-dna.tsx
│   │   ├── edge-map.tsx
│   │   ├── charts.tsx
│   │   ├── trade-explorer.tsx
│   │   ├── trade-detail.tsx
│   │   ├── trends.tsx
│   │   ├── report.tsx
│   │   ├── history.tsx
│   │   └── settings.tsx
│   │
│   ├── lib/
│   │   ├── api/                      # API client layer
│   │   │   ├── client.ts             # Base fetch client with interceptors
│   │   │   ├── uploads.ts            # uploadFile()
│   │   │   ├── analyses.ts           # runAnalysis(), getAnalysis(), getReport()
│   │   │   ├── trades.ts             # getTrades() (new endpoint)
│   │   │   ├── history.ts            # getHistory()
│   │   │   └── types.ts              # API request/response types
│   │   │
│   │   ├── hooks/                    # Custom React hooks
│   │   │   ├── use-analysis.ts       # useAnalysis(id), useReport(id)
│   │   │   ├── use-trades.ts         # useTrades(id, filters)
│   │   │   ├── use-history.ts        # useHistory(page)
│   │   │   ├── use-upload.ts         # useUpload()
│   │   │   ├── use-theme.ts          # useTheme() (wraps next-themes)
│   │   │   ├── use-keyboard.ts       # useKeyboardShortcuts()
│   │   │   └── use-media-query.ts    # useMediaQuery()
│   │   │
│   │   ├── store/                    # Zustand stores
│   │   │   ├── app-store.ts          # Current view, analysis ID, sidebar open
│   │   │   ├── theme-store.ts        # Theme + language preferences
│   │   │   └── onboarding-store.ts   # Onboarding tooltip dismissals
│   │   │
│   │   ├── utils/
│   │   │   ├── format.ts             # formatCurrency, formatNumber, formatDate
│   │   │   ├── severity.ts           # severityColor(), severityLabel()
│   │   │   ├── persian.ts            # toPersianNumerals(), toShamsi()
│   │   │   ├── cn.ts                 # className merge (clsx + tailwind-merge)
│   │   │   └── constants.ts          # Nav items, breakpoints, API paths
│   │   │
│   │   ├── validations/              # Zod schemas
│   │   │   ├── upload.ts             # File validation schema
│   │   │   ├── analysis.ts           # AnalysisReport response schema
│   │   │   └── settings.ts           # Settings form schema
│   │   │
│   │   ├── types.ts                  # Shared TypeScript types (V23 mirror)
│   │   └── utils.ts                   # cn() helper (existing)
│   │
│   ├── styles/
│   │   ├── tokens.css                # Design tokens (imported by globals.css)
│   │   └── animations.css            # Keyframe animations
│   │
│   └── middleware.ts                 # Auth middleware (future-ready)
│
├── public/
│   ├── illustrations/                # SVG illustrations (9 files)
│   │   ├── empty-analysis.svg
│   │   ├── empty-history.svg
│   │   ├── empty-trends.svg
│   │   ├── empty-trades.svg
│   │   ├── empty-edge-map.svg
│   │   ├── error-generic.svg
│   │   ├── error-network.svg
│   │   ├── success-analysis.svg
│   │   └── hero-landing.svg
│   ├── fonts/                        # Self-hosted fonts (if not using next/font)
│   └── favicon.ico
│
├── prisma/                           # Database (future: user accounts, history)
│   └── schema.prisma
│
├── next.config.ts                    # Next.js config (images, redirects, headers)
├── tailwind.config.ts                # Tailwind config (extends tokens)
├── tsconfig.json                     # TypeScript config (strict)
├── package.json
└── .env.local                        # Environment variables
```

### Folder structure rules

1. **`app/` = routing only.** Page files are thin — they fetch data and render a view component from `views/`. No business logic in `app/`.
2. **`views/` = page-level compositions.** Each view composes components to build a full screen. Views are `'use client'` (they need interactivity) but receive data as props from the server page.
3. **`components/ui/` = shadcn/ui primitives.** Untouched generated components. Never modify these directly — extend via composition.
4. **`components/td/` = Trading Doctor custom components.** Domain-specific composites (ScoreGauge, EvidenceCard, etc.).
5. **`lib/api/` = API client.** All backend communication lives here. Components never call `fetch` directly.
6. **`lib/hooks/` = custom hooks.** Reusable stateful logic (data fetching, media queries, keyboard).
7. **`lib/store/` = Zustand stores.** Client-only UI state. Server state lives in TanStack Query.
8. **`lib/utils/` = pure functions.** Formatting, constants, helpers. No side effects.

---

## 4. Component Hierarchy

### App-level hierarchy

```
<RootLayout>
  <ThemeProvider>
    <QueryProvider>
      <AppStateProvider>
        <AppShell>                        ← layout wrapper
          <TopBar>
            <Logo />
            <AnalysisBadge />
            <CommandPaletteTrigger />
            <ThemeToggle />
            <LanguageToggle />
            <AccountMenu />               ← future-ready
          </TopBar>
          <Sidebar>                       ← desktop (≥md)
            <NavItems />
            <UploadCTA />
          </Sidebar>
          <MobileNavDrawer />             ← mobile (<md)
          <BottomTabBar />                ← mobile (<md)
          <main>
            {children}                    ← view content
          </main>
        </AppShell>
        <CommandPalette />                ← global, mounted at root
        <Toaster />                       ← global toasts
      </AppStateProvider>
    </QueryProvider>
  </ThemeProvider>
</RootLayout>
```

### Page-level hierarchy (Dashboard example)

```
<DashboardPage>                          ← Server Component (RSC)
  │  fetches: GET /api/v1/analyses/{id}/report
  │
  └── <DashboardView report={data}>      ← Client Component
        ├── <PageHeader title="داشبورد" />
        │
        ├── <EmotionalCenterCards>       ← 4 cards above fold
        │   ├── <OverallHealthCard>      ← clickable → /behavioral
        │   │   └── <ScoreGauge value={67} />
        │   ├── <BiggestLeakCard>        ← clickable → /diagnosis
        │   │   ├── <SeverityBadge />
        │   │   └── <StatCard />
        │   ├── <BiggestStrengthCard>    ← clickable → /edge-map
        │   │   └── <StatCard />
        │   └── <ImmediateNextActionCard>← clickable → /coaching
        │       └── <Button />
        │
        ├── <PerformanceStrip>           ← 6 StatCards
        │   └── <StatCard /> ×6
        │
        ├── <Callouts>
        │   ├── <BiggestLeakCallout />
        │   └── <WhatIfCallout />
        │
        ├── <QuickJumpTiles>             ← 4 tiles
        │   └── <QuickJumpTile /> ×4
        │
        └── <DataQualityWarnings>         ← collapsible
            └── <Accordion />
```

### Component ownership rules

| Layer | Owns | Does NOT own |
|---|---|---|
| Page (RSC) | Data fetching, metadata | UI state, interactivity |
| View (Client) | Page composition, local UI state | Data fetching (receives as props) |
| Composite Component | Domain logic (e.g., ScoreGauge rendering) | Data fetching, routing |
| Primitive (shadcn/ui) | Base styling, accessibility | Domain logic, business rules |

---

## 5. Reusable Components

### Core reusable components (18 from Phase 3 §39.1)

| Component | Location | Reused on | Props |
|---|---|---|---|
| Button | `components/ui/button.tsx` | Every interactive surface | `variant`, `size`, `loading`, `disabled` |
| Card | `components/ui/card.tsx` | Every screen | `variant` (default/elevated/interactive/severity-bordered/stat) |
| Input | `components/ui/input.tsx` | Upload, Settings, Auth | `type`, `error`, `icon`, `suffix` |
| Table | `components/ui/table.tsx` | Trade Explorer, History, Subscription | `columns`, `data`, `sortable`, `mobileCardLayout` |
| Select | `components/ui/select.tsx` | Upload (LLM), Trade Explorer (sort), Settings | `options`, `searchable` |
| Tabs | `components/ui/tabs.tsx` | Report sections, Settings | `items`, `variant` (underline/pill/segmented) |
| Chart | `components/charts/*.tsx` | Charts, Trends, Behavioral, Edge Map | `data`, `type`, `color`, `onPointClick` |
| Dialog | `components/ui/dialog.tsx` | History delete, Settings reset, Trade Detail | `open`, `onClose`, `variant` (default/sheet/drawer) |
| Badge | `components/ui/badge.tsx` | Every screen with severity/status | `variant` (severity/status/count/priority) |
| Toast | `components/ui/sonner.tsx` | Global | `message`, `type`, `duration` |
| Tooltip | `components/ui/tooltip.tsx` | Dashboard, Behavioral, Evidence | `content`, `position` |
| CommandPalette | `components/td/command-palette.tsx` | Global (Cmd+K) | — |
| Pagination | `components/ui/pagination.tsx` | Trade Explorer, History | `page`, `totalPages`, `onPageChange` |
| Breadcrumb | `components/ui/breadcrumb.tsx` | Every app page | `items` |
| Progress | `components/ui/progress.tsx` | Analysis Progress, Upload, Confidence bars | `value`, `variant` (linear/circular/stepper) |
| Skeleton | `components/ui/skeleton.tsx` | Every async page | `shape`, `size` |
| EmptyState | `components/td/empty-states.tsx` | History, Trends, Trade Explorer | `illustration`, `title`, `description`, `cta` |
| ErrorState | `components/td/empty-states.tsx` | Every page error | `title`, `description`, `onRetry` |

### Composite components (13 from Phase 3 §39.2)

| Composite | Built from | Reused on |
|---|---|---|
| ScoreGauge | Progress (circular) + Typography | Dashboard, Behavioral, Overview, Risk, History |
| SeverityBadge | Badge (severity variant) | Dashboard, Behavioral, Diagnosis, Evidence, Risk |
| EvidenceCard | Card (severity-bordered) + Badge + Tooltip | Diagnosis, Dashboard, Trader DNA, Risk |
| RecommendationCard | Card (severity-bordered) + Badge (priority) + Button (toggle) | Coaching, Dashboard, Risk |
| ContextBlockCard | Card + ScoreGauge + Badge + Tooltip | Behavioral, Risk |
| StatCard | Card (stat variant) + Typography (mono) | Dashboard, Overview, Performance, Risk, Edge Map |
| HistoryItemCard | Card (interactive) + ScoreGauge + Badge + Menu | History |
| UploadDropzone | Input (file) + Icons + Typography | Upload |
| FilePill | Badge + IconButton | Upload |
| ProgressStepper | Progress (stepper) + Typography | Analysis Progress |
| FilterBar | Input + Select + SegmentedControl + Button | Trade Explorer, Diagnosis, History |
| TradeDetailDrawer | Dialog (drawer) + Typography + Table | Trade Explorer, Trade Detail |
| QuickJumpTile | Card (interactive) + Icons + Typography | Dashboard |

### Reusability principles

1. **Composition over inheritance.** Components are composed, not extended. `EvidenceCard` is built from `Card` + `Badge`, not a subclass of `Card`.
2. **Props are typed and minimal.** Every component has a TypeScript interface. Props are named clearly. No `any`.
3. **Components are dumb.** They receive data via props and emit events via callbacks. No data fetching inside components (hooks do that).
4. **Tokens, not values.** Components consume CSS variables, never hardcoded colors/sizes.
5. **Accessible by default.** Every interactive component has ARIA roles, keyboard support, focus management built in.

---

## 6. State Management

### Two-tier state strategy

| State type | Tool | Examples | Persistence |
|---|---|---|---|
| **Server state** (data from API) | TanStack Query | Analysis report, trades, history | Query cache (in-memory, configurable TTL) |
| **Client state** (UI only) | Zustand | Current view, sidebar open, theme, language, onboarding dismissals | `localStorage` for preferences |

### Why two tools (not one)?

- **TanStack Query** handles everything that comes from the backend: caching, dedup, background refetch, optimistic updates, pagination. It's purpose-built for server state.
- **Zustand** handles everything that's UI-only: which sidebar item is active, is the mobile drawer open, what theme did the user pick. It's lightweight (1KB) and has no boilerplate.
- **We do NOT use Redux.** The app's state complexity doesn't warrant it. Two focused tools are simpler than one bloated one.

### TanStack Query configuration

```typescript
// src/components/providers/query-provider.tsx
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,      // 5 minutes — analysis data doesn't change
      gcTime: 30 * 60 * 1000,        // 30 minutes garbage collection
      retry: 2,                       // retry failed requests twice
      refetchOnWindowFocus: false,    // don't refetch on tab focus (data is stable)
      refetchOnMount: true,           // refetch on mount if stale
    },
    mutations: {
      retry: 1,
    },
  },
});
```

### Query key conventions

```typescript
// Analysis report
['analysis', analysisId, 'report']

// Trades (with filters)
['analysis', analysisId, 'trades', { page, pageSize, side, outcome }]

// History (with pagination)
['history', { page, pageSize }]

// Config
['config']
```

### Zustand stores

```typescript
// src/lib/store/app-store.ts
interface AppStore {
  currentAnalysisId: string | null;
  sidebarOpen: boolean;
  mobileNavOpen: boolean;
  commandPaletteOpen: boolean;
  setCurrentAnalysis: (id: string) => void;
  toggleSidebar: () => void;
  toggleMobileNav: () => void;
  toggleCommandPalette: () => void;
}

// src/lib/store/theme-store.ts (persists to localStorage)
interface ThemeStore {
  theme: 'dark' | 'light' | 'system';
  language: 'fa' | 'en';
  density: 'comfortable' | 'compact';
  setTheme: (t: ThemeStore['theme']) => void;
  setLanguage: (l: ThemeStore['language']) => void;
  setDensity: (d: ThemeStore['density']) => void;
}

// src/lib/store/onboarding-store.ts (persists to localStorage)
interface OnboardingStore {
  tooltipsDismissed: Record<string, boolean>;
  dismissTooltip: (id: string) => void;
}
```

### State flow diagram

```
User clicks "Dashboard" in sidebar
         │
         ▼
┌─────────────────────┐
│ Zustand: appStore   │  sets currentAnalysisId
│ .setCurrentAnalysis │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Next.js Router      │  navigates to /dashboard/{id}
│ push('/dashboard/') │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Server Component    │  fetches via Route Handler
│ (RSC page)          │  → GET /api/v1/analyses/{id}/report
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ TanStack Query      │  caches response, serves from cache
│ useReport(id)       │  on subsequent visits
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ DashboardView       │  renders with data
│ (Client Component)  │
└─────────────────────┘
```

---

## 7. API Layer

### Architecture: BFF (Backend-for-Frontend)

```
Browser → Next.js Route Handler (/app/api/*) → V23 FastAPI (/api/v1/*)
```

**The browser never calls the V23 API directly.** All requests go through Next.js Route Handlers, which:
1. Proxy to the V23 backend at `TRADING_DOCTOR_API_URL` (server-side env var).
2. Add auth headers (future).
3. Transform responses if needed.
4. Set cache headers.
5. Handle errors uniformly.

### API client structure

```typescript
// src/lib/api/client.ts — base fetch client
const API_BASE = '/api/v1';  // relative path to BFF Route Handlers

async function apiClient<T>(
  path: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new ApiError(response.status, error.error?.code || 'unknown', error.error?.message || 'خطای نامشخص');
  }

  return response.json();
}

// src/lib/api/analyses.ts
export async function getReport(analysisId: string): Promise<AnalysisReport> {
  return apiClient<AnalysisReport>(`/analyses/${analysisId}/report`);
}

export async function runAnalysis(uploadId: string, llmProvider: string): Promise<AnalysisSummary> {
  return apiClient<AnalysisSummary>('/analyses', {
    method: 'POST',
    body: JSON.stringify({ upload_id: uploadId, llm_provider: llmProvider }),
  });
}

// src/lib/api/trades.ts (NEW endpoint)
export async function getTrades(
  analysisId: string,
  params: { page: number; pageSize: number; side?: string; outcome?: string }
): Promise<TradesResponse> {
  const query = new URLSearchParams(params as Record<string, string>);
  return apiClient<TradesResponse>(`/analyses/${analysisId}/trades?${query}`);
}
```

### Route Handler (BFF) example

```typescript
// src/app/api/analyses/[id]/report/route.ts
import { NextRequest, NextResponse } from 'next/server';

const V23_API = process.env.TRADING_DOCTOR_API_URL || 'http://localhost:8000/api/v1';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const response = await fetch(`${V23_API}/analyses/${params.id}/report`, {
      headers: {
        // Forward auth if enabled (future)
        // 'X-API-Key': request.headers.get('X-API-Key') || '',
      },
      next: { revalidate: 300 }, // cache for 5 minutes
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      return NextResponse.json(error, { status: response.status });
    }

    const data = await response.json();
    return NextResponse.json(data, {
      headers: {
        'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600',
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: { code: 'internal_error', message: 'خطای داخلی سرور' } },
      { status: 500 }
    );
  }
}
```

### API endpoint mapping

| BFF Route Handler | V23 Backend Endpoint | Method | Cached? |
|---|---|---|---|
| `/api/v1/health` | `/api/v1/health` | GET | No (liveness) |
| `/api/v1/config` | `/api/v1/config` | GET | 1 hour |
| `/api/v1/uploads` | `/api/v1/uploads` | POST | No |
| `/api/v1/analyses` | `/api/v1/analyses` | POST | No |
| `/api/v1/analyses/{id}` | `/api/v1/analyses/{id}` | GET | 5 minutes |
| `/api/v1/analyses/{id}/report` | `/api/v1/analyses/{id}/report` | GET | 5 minutes |
| `/api/v1/analyses/{id}/report.html` | `/api/v1/analyses/{id}/report.html` | GET | 1 hour |
| `/api/v1/analyses/{id}/report.pdf` | `/api/v1/analyses/{id}/report.pdf` | GET | 1 hour |
| `/api/v1/analyses/{id}/trades` | `/api/v1/analyses/{id}/trades` | GET | 5 minutes |
| `/api/v1/history` | `/api/v1/history` | GET | 1 minute |

### Error handling in API layer

The V23 backend returns errors in a standard envelope:
```json
{ "error": { "code": "not_found", "message": "تحالیلی با شناسه «...» یافت نشد.", "details": {} } }
```

The BFF Route Handlers pass this through unchanged. The API client throws an `ApiError` with the code and message. TanStack Query catches it and exposes it via `error` in the hook. Views render an `ErrorState` component with the message.

---

## 8. Authentication Layer

### Phase 1: No auth (Anonymous tier)

Phase 1 ships without authentication. The V23 backend runs with `AUTH_ENABLED=false`. All API calls are unauthenticated. The frontend has no login UI.

### Future-ready: NextAuth.js v4

When auth is enabled (Registered/Pro/Mentor/Enterprise tiers), the architecture supports it without restructuring:

```typescript
// src/lib/auth.ts
import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { PrismaAdapter } from '@auth/prisma-adapter';
import { db } from '@/lib/db';

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PrismaAdapter(db),
  providers: [
    CredentialsProvider({
      credentials: { email: {}, password: {} },
      async authorize(credentials) {
        // Verify against V23 API (future endpoint)
        // or against local Prisma DB
      },
    }),
    // GoogleProvider({ ... }),  // future OAuth
  ],
  session: { strategy: 'jwt', maxAge: 30 * 24 * 60 * 60 }, // 30 days
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.role = user.role;
      return token;
    },
    async session({ session, token }) {
      session.user.role = token.role;
      return session;
    },
  },
});
```

### Middleware (future-ready)

```typescript
// src/middleware.ts
import { auth } from '@/lib/auth';

export default auth((req) => {
  const { pathname } = req.nextUrl;
  const isPublic = pathname === '/' || pathname.startsWith('/sample') || pathname.startsWith('/api/v1/health');
  const isAuth = pathname.startsWith('/signin') || pathname.startsWith('/signup');

  if (isPublic || isAuth) return NextResponse.next();

  if (!req.auth) {
    return NextResponse.redirect(new URL('/signin', req.url));
  }

  // Role-based access (future)
  const role = req.auth.user.role;
  if (pathname.startsWith('/settings/subscription') && role === 'anonymous') {
    return NextResponse.redirect(new URL('/pricing', req.url));
  }
});
```

### Auth flow (future)

1. User visits any `/app/*` route.
2. Middleware checks `req.auth` (JWT in cookie).
3. If no auth → redirect to `/signin`.
4. User signs in → NextAuth calls V23 `/api/v1/auth/signin` (future endpoint).
5. JWT cookie set → redirect to original URL.
6. BFF Route Handlers forward JWT to V23 API as `Authorization: Bearer {token}`.

**Backend impact: NONE.** The V23 API already has `verify_api_key` dependency (Phase 2 §2.2). When `AUTH_ENABLED=true`, it expects `X-API-Key` headers. The BFF layer adds these headers from the JWT. No V23 code changes.

---

## 9. Routing

### App Router structure

Next.js 16 App Router with route groups:

| Route group | Purpose | Layout |
|---|---|---|
| `(public)/` | Landing, Sample Report | No sidebar, no auth |
| `(app)/` | All analysis screens | Sidebar + top bar + bottom tab |
| `(auth)/` | Sign in, sign up (future) | Centered card, no sidebar |

### Route map

| Route | View | Tier | Phase |
|---|---|---|---|
| `/` | Landing | Public | Phase 1 |
| `/sample` | Sample Report | Public | Phase 1 |
| `/upload` | Upload | Entry | Phase 1 |
| `/history` | History | Entry | Phase 1 |
| `/dashboard/[analysisId]` | Dashboard | Primary | Phase 1 |
| `/behavioral/[analysisId]` | Behavioral Analysis | Primary | Phase 1 |
| `/diagnosis/[analysisId]` | Diagnosis | Primary | Phase 1 |
| `/coaching/[analysisId]` | Coaching | Primary | Phase 1 |
| `/trader-dna/[analysisId]` | Trader DNA | Deep dive | Phase 1 |
| `/edge-map/[analysisId]` | Edge Map | Deep dive | Phase 1 |
| `/charts/[analysisId]` | Charts | Deep dive | Phase 1 |
| `/trades/[analysisId]` | Trade Explorer | Deep dive | Phase 1 |
| `/trades/[analysisId]/[tradeId]` | Trade Detail | Deep dive | Phase 1 |
| `/trends` | Trends | Deep dive | Phase 1 |
| `/report/[analysisId]` | Report | Action | Phase 1 |
| `/settings` | Settings | Future | Phase 1 stub |
| `/signin` | Sign In | Auth | Future |
| `/signup` | Sign Up | Auth | Future |

### Dynamic routes

Analysis-dependent routes use `[analysisId]` dynamic segment. This:
- Makes analyses deep-linkable (`/dashboard/abc123`).
- Enables browser back/forward navigation.
- Allows sharing analysis links.
- Works with SSR (server fetches data for the ID).

### Navigation patterns

| Pattern | Implementation |
|---|---|
| Sidebar click | `<Link href="/behavioral/{id}">` (client-side navigation) |
| Dashboard card click | `<Link>` wrapping the card |
| History item click | `<Link href="/dashboard/{analysisId}">` |
| Browser back | Next.js handles automatically |
| Programmatic navigation | `useRouter().push('/dashboard/{id}')` |
| Command Palette | `cmdk` with `<Link>` items |

### Loading states

Each route has a `loading.tsx` that shows a skeleton matching the page layout:

```
app/
├── dashboard/[analysisId]/
│   ├── page.tsx        ← Server Component (fetches data)
│   ├── loading.tsx     ← Skeleton (instant, no fetch)
│   └── error.tsx       ← Error boundary (if fetch fails)
```

### Not-found handling

- `app/not-found.tsx` — global 404 page (illustration + CTA to Home).
- `app/dashboard/[analysisId]/not-found.tsx` — analysis-specific 404 («تحلیل یافت نشد» + CTA to History).

---

## 10. Theme System

### Architecture: CSS variables + next-themes

```
next-themes (manages .dark / .light class on <html>)
         │
         ▼
globals.css (defines CSS variables per theme)
         │
         ▼
Tailwind config (maps CSS variables to utility classes)
         │
         ▼
Components (consume utility classes / var() directly)
```

### Token structure

```css
/* globals.css */
:root {
  /* Dark theme — DEFAULT */
  --background: #0a0e1a;
  --foreground: #f1f5f9;
  --card: #121829;
  --primary: #3b82f6;
  --cta: #f59e0b;
  --cta-foreground: #0a0e1a;  /* dark-on-amber for WCAG AA */
  --severity-low: #22c55e;
  --severity-medium: #f59e0b;
  --severity-high: #f97316;
  --severity-critical: #ef4444;
  --profit-positive: #22c55e;
  --profit-negative: #ef4444;
  /* ... ~50 more tokens */
}

.light {
  --background: #f8fafc;
  --foreground: #0f172a;
  --primary: #1e40af;
  --cta: #d97706;
  --cta-foreground: #ffffff;
  --severity-low: #16a34a;
  /* ... light theme overrides */
}
```

### Theme switching

```typescript
// src/components/providers/theme-provider.tsx
'use client';
import { ThemeProvider as NextThemesProvider } from 'next-themes';

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="dark"
      enableSystem={false}  // dark is the default; user can switch
      disableTransitionOnChange  // prevent flash on switch
    >
      {children}
    </NextThemesProvider>
  );
}
```

### Theme toggle component

```typescript
// src/components/td/theme-toggle.tsx
'use client';
import { useTheme } from 'next-themes';
import { Sun, Moon } from '@phosphor-icons/react';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  return (
    <button
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label="تغییر تم"
      className="p-2 rounded-lg hover:bg-accent transition-colors"
    >
      {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
```

### No FOUC (Flash of Unstyled Content)

`next-themes` injects an inline script in `<head>` that sets the theme class before first paint. Combined with `suppressHydrationWarning` on `<html>`, this prevents any flash.

---

## 11. Dark Mode Strategy

### Dark is the default

Trading Doctor is **dark-mode-first**. Rationale:
- Trading dashboards are used in dim environments (home offices, late-night analysis).
- Dark mode reduces eye strain for prolonged data analysis.
- The design system (Phase 3) is built dark-first; light is the override.

### Light mode is fully supported

Light mode is a first-class alternative, not an afterthought. Every token has a light value. Every component is tested in both themes.

### Color contrast verification

| Token | Dark ratio (on --bg-base) | Light ratio (on --bg-base) | Pass |
|---|---|---|---|
| `--fg-primary` | 14.8:1 | 16.3:1 | ✓ AAA |
| `--fg-secondary` | 7.4:1 | 8.9:1 | ✓ AAA |
| `--fg-muted` | 4.8:1 | 5.9:1 | ✓ AA |
| `--severity-critical` | 4.9:1 | 4.6:1 | ✓ AA |
| `--cta-foreground` on `--cta` | 8.9:1 | 4.8:1 | ✓ AA |

### Amber CTA contrast rule (critical)

On dark theme, amber `#F59E0B` with white text is 2.8:1 (FAILS AA). The fix:
- **Dark theme:** `--cta-foreground: #0A0E1A` (deep navy text on amber) → 8.9:1 ✓
- **Light theme:** `--cta-foreground: #FFFFFF` (white text on amber) → 4.8:1 ✓

This is the Stripe pattern (dark text on bright CTA).

### Theme persistence

`next-themes` persists theme choice in `localStorage('theme')`. On next visit, the stored theme is applied before first paint (via inline script).

### System preference

`enableSystem={false}` — we do NOT follow `prefers-color-scheme` automatically. Trading Doctor is dark-first; the user must explicitly opt into light. This prevents jarring theme switches when moving between apps.

---

## 12. Responsive Strategy

### Mobile-first breakpoint system

```css
/* Tailwind 4 breakpoints (default, mobile-first) */
--breakpoint-xs: 0;       /* Base: mobile portrait (375px+) */
--breakpoint-sm: 640px;   /* Mobile landscape, small tablet */
--breakpoint-md: 768px;   /* Tablet portrait (iPad) */
--breakpoint-lg: 1024px;  /* Tablet landscape, small laptop */
--breakpoint-xl: 1280px;  /* Desktop */
--breakpoint-2xl: 1536px; /* Large desktop */
```

### Layout per breakpoint

| Breakpoint | Sidebar | Top bar | Bottom bar | Content max-width | Grid |
|---|---|---|---|---|---|
| `< sm` (375px) | Off-canvas drawer | Logo + hamburger + theme | 5-item tab bar | 100% − 32px | 1 col |
| `sm`–`md` (640–767px) | Off-canvas drawer | + analysis badge | 5-item tab bar | 100% − 48px | 2 col |
| `md`–`lg` (768–1023px) | Icon-rail (72px) | + language toggle | hidden | 100% − 72px − 48px | 2–8 col |
| `lg`–`xl` (1024–1279px) | Full sidebar (240px) | Full | hidden | 1024px | 8–12 col |
| `≥ xl` (1280px+) | Full sidebar (240px) | Full | hidden | 1280px | 12 col |

### Mobile-first rules

1. **Base styles target 375px.** Breakpoints enhance upward via `min-width` media queries. Never use `max-width`.
2. **Touch targets ≥ 44×44pt** on mobile. `padding` extends hit area without changing visual size.
3. **Tables become card lists** on `< md`. Each row renders as a card.
4. **Modals become bottom sheets** on `< md`. Slide-up, swipe-down to dismiss.
5. **Sidebar → off-canvas drawer** on `< md`. Hamburger toggle.
6. **Bottom tab bar** on `< md` only. Hidden at `md+`.

### Dashboard 375px verification (critical constraint)

The Dashboard's 4 emotional-center cards must fit above the fold on 375 × 667 (iPhone SE):

| Card | Height |
|---|---|
| Overall Health (ScoreGauge 80px) | 140px |
| Biggest Leak (icon + label + $ + severity) | 120px |
| Biggest Strength (icon + label + metric) | 120px |
| Immediate Next Action (verb + CTA) | 110px |
| 3 × 16px gaps | 48px |
| **Content total** | **538px** |
| Top bar (mobile) | 56px |
| **Above-fold total** | **594px** |
| iPhone SE viewport | 667px |
| **Buffer** | **73px** ✓ |

**Implementation:** Cards use `min-h-[140px]` / `min-h-[120px]` / `min-h-[110px]` on mobile, removing the minimum at `md:` where they expand to equal-height grid.

### Responsive testing matrix

Every page is verified at: **375 × 667** (iPhone SE), **375 × 812** (iPhone 11), **768 × 1024** (iPad portrait), **1024 × 768** (iPad landscape), **1280 × 800** (laptop), **1536 × 960** (desktop).

---

## 13. Performance Strategy

### Performance budget

| Metric | Target | Measurement |
|---|---|---|
| First Contentful Paint (FCP) | < 1.5s on 4G mobile | Lighthouse |
| Largest Contentful Paint (LCP) | < 2.5s on 4G mobile | Lighthouse |
| Cumulative Layout Shift (CLS) | < 0.1 | Lighthouse |
| Time to Interactive (TTI) | < 3.5s on 4G mobile | Lighthouse |
| Initial JS bundle (gzip) | < 200KB | `@next/bundle-analyzer` |
| Total page weight (first load) | < 500KB | Lighthouse |

### Strategies to hit the budget

**1. Server Components by default.**
Pages are RSC. Only interactive leaf components are `'use client'`. This minimizes client JS.

**2. Code splitting with `next/dynamic`.**
Heavy components (Recharts, Command Palette) are lazy-loaded:
```typescript
const Chart = dynamic(() => import('@/components/charts/equity-curve'), {
  loading: () => <Skeleton className="h-[280px]" />,
  ssr: false,  // charts are client-only
});
```

**3. Image optimization with `next/image`.**
All images use `<Image>` with automatic WebP/AVIF conversion, lazy loading, and blur placeholders.

**4. Font optimization with `next/font`.**
Vazirmatn + Fira Code are self-hosted via `next/font/google` with `display: swap` and automatic subset injection. Zero layout shift.

**5. Streaming with Suspense.**
Pages stream HTML as data arrives:
```tsx
<Suspense fallback={<DashboardSkeleton />}>
  <AsyncDashboardContent analysisId={id} />
</Suspense>
```

**6. Prefetching.**
`<Link>` prefetches linked routes on hover/viewport-entry. Navigation is instant.

**7. Minimal client JS.**
Zustand (1KB) + TanStack Query (12KB) + React (45KB) = ~58KB core. Recharts (95KB) is lazy-loaded only on chart pages.

### Bundle analysis

```bash
ANALYZE=true bun run build  # generates bundle report
```

Verify no single chunk exceeds 50KB (gzip) except the main app chunk (target < 100KB).

---

## 14. Caching Strategy

### Three caching layers

| Layer | Tool | TTL | Invalidation |
|---|---|---|---|
| **Browser HTTP cache** | `Cache-Control` headers | Per resource | URL-based |
| **Next.js Data Cache** | `fetch()` with `next: { revalidate }` | 5 min (reports), 1 hour (config, HTML/PDF) | Tag-based revalidation |
| **TanStack Query cache** | In-memory | 5 min (stale), 30 min (GC) | Query invalidation on mutations |

### Cache headers per resource

| Resource | `Cache-Control` | Rationale |
|---|---|---|
| `/api/v1/config` | `public, s-maxage=3600` | Rarely changes |
| `/api/v1/analyses/{id}/report` | `public, s-maxage=300, stale-while-revalidate=600` | Analysis is immutable; 5 min cache + 10 min stale |
| `/api/v1/analyses/{id}/report.html` | `public, s-maxage=3600` | HTML is fully static post-analysis |
| `/api/v1/analyses/{id}/report.pdf` | `public, s-maxage=3600` | PDF is fully static |
| `/api/v1/analyses/{id}/trades` | `public, s-maxage=300` | Trades don't change; cache 5 min |
| `/api/v1/history` | `public, s-maxage=60` | Changes when new analysis runs; 1 min cache |
| `/api/v1/health` | `no-cache` | Liveness probe; always fresh |

### TanStack Query stale times

| Query | `staleTime` | Rationale |
|---|---|---|
| `['config']` | 1 hour | Config rarely changes |
| `['analysis', id, 'report']` | 5 minutes | Analysis is immutable, but user might re-analyze |
| `['analysis', id, 'trades']` | 5 minutes | Trades don't change |
| `['history']` | 1 minute | New analyses appear at the top |

### Cache invalidation on mutations

When user runs a new analysis:
```typescript
const mutation = useMutation({
  mutationFn: runAnalysis,
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['history'] });
  },
});
```

### Offline caching (future, Phase 2 §7)

IndexedDB caching of last 3 analyses' reports for offline access. Not Phase 1, but the architecture supports it:
- TanStack Query `persister` extension can persist cache to IndexedDB.
- Service Worker (future) can cache the app shell for offline use.

---

## 15. Lazy Loading

### Route-level lazy loading

Next.js App Router automatically code-splits per route. Each page's JS is loaded only when navigated to. No manual configuration needed.

### Component-level lazy loading

Heavy components are lazy-loaded with `next/dynamic`:

| Component | When to load | Reason |
|---|---|---|
| Recharts charts | On chart page visit | 95KB; only needed on Charts/Trends pages |
| Command Palette | On first Cmd+K press | 20KB; not needed by most users |
| Trade Detail Drawer | On row click | Only needed when inspecting a trade |
| PDF/HTML download logic | On download button click | Avoid loading blob logic upfront |

```typescript
// Example: lazy-load charts
const EquityCurve = dynamic(() => import('@/components/charts/equity-curve'), {
  loading: () => <Skeleton className="h-[280px] w-full" />,
  ssr: false,
});
```

### Image lazy loading

`next/image` lazy-loads by default. Above-fold images get `priority`:
```tsx
<Image src="/hero.svg" priority alt="Trading Doctor" />
```

### Conditional loading

Components that depend on analysis data are conditionally rendered:
```tsx
{hasAnalysis && <DashboardView report={data} />}
{!hasAnalysis && <UploadView />}
```

This prevents loading Dashboard JS bundle when no analysis exists.

---

## 16. Error Handling

### Three error layers

| Layer | What it catches | Recovery |
|---|---|---|
| **Route Error Boundary** (`error.tsx`) | Unhandled errors in a route | Reset button + link to Home |
| **TanStack Query error** | API fetch failures | Retry button in ErrorState component |
| **Global Error Boundary** (`app/error.tsx`) | Errors that escape route boundaries | Full-page error with reload |

### Error display pattern

Every async view renders an `ErrorState` component on failure:

```tsx
function DashboardView({ analysisId }: { analysisId: string }) {
  const { data, error, isLoading } = useReport(analysisId);

  if (isLoading) return <DashboardSkeleton />;
  if (error) return <ErrorState title="تحلیل بارگذاری نشد" onRetry={() => refetch()} />;
  if (!data) return <EmptyState title="تحلیلی یافت نشد" />;

  return <DashboardContent report={data} />;
}
```

### API error mapping

The V23 backend returns errors in a standard envelope. The frontend maps them to user-friendly messages:

| HTTP status | Error code | User message (fa) | Action |
|---|---|---|---|
| 400 | `invalid_file` | «فرمت فایل قابل‌پردازش نیست» | Return to Upload |
| 404 | `not_found` | «تحلیل یافت نشد» | Return to History |
| 413 | `file_too_large` | «حجم فایل بیش از ۲۵ مگابایت است» | Inline error |
| 422 | `invalid_data` | (engine message, e.g., «ستون سود/زیان پیدا نشد») | Inline error + help link |
| 429 | `rate_limited` | «تعداد درخواست‌ها بیش از حد. X ثانیه دیگر.» | Countdown + auto-retry |
| 500 | `internal_error` | «خطای داخلی سرور. لطفاً بعداً تلاش کنید.» | Retry button |
| Network | — | «اتصال به سرور برقرار نشد» | Retry button |

### Error boundary implementation

```tsx
// app/dashboard/[analysisId]/error.tsx
'use client';
import { ErrorState } from '@/components/td/empty-states';

export default function DashboardError({ reset }: { reset: () => void }) {
  return (
    <ErrorState
      title="تحلیل بارگذاری نشد"
      description="لطفاً دوباره تلاش کنید."
      onRetry={reset}
    />
  );
}
```

### Global error page

```tsx
// app/error.tsx
'use client';
export default function GlobalError({ reset }: { reset: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <ErrorState
        title="خطای غیرمنتظره"
        description="خطایی رخ داد. لطفاً صفحه را بازخوانی کنید."
        onRetry={() => window.location.reload()}
      />
    </div>
  );
}
```

### Toast notifications for action errors

Non-fatal errors (e.g., "delete failed") show a toast:
```typescript
toast.error('حذف ناموفق بود. دوباره تلاش کنید.');
```

---

## 17. Accessibility

### WCAG 2.1 AA compliance (minimum)

| Category | Implementation |
|---|---|
| **Contrast** | Body text ≥ 4.5:1, secondary ≥ 3:1, non-text ≥ 3:1 (verified in Phase 3 §5.5) |
| **Keyboard navigation** | Every interactive element reachable via Tab. Visible focus ring (3px `--ring-focus`). Enter/Space activates. |
| **Screen reader** | ARIA roles, labels, descriptions on every interactive element. `aria-live` for dynamic content. |
| **Color independence** | Color is never the only signal. Every severity indicator has text + icon. |
| **Reduced motion** | `@media (prefers-reduced-motion: reduce)` freezes all animations to ≤1ms. |
| **Touch targets** | ≥ 44×44pt on mobile. 8pt separation between adjacent targets. |

### Semantic HTML

```tsx
// Every page uses semantic landmarks
<html>
  <body>
    <header role="banner">          ← TopBar
    <nav role="navigation">         ← Sidebar
    <main role="main">              ← Page content
    <footer role="contentinfo">     ← (if present)
  </body>
</html>
```

### ARIA patterns

| Component | ARIA pattern |
|---|---|
| Sidebar nav | `<nav aria-label="اصلی">` with `<ul>` of `<li><a>` |
| Tabs | `role="tablist"` + `role="tab"` + `aria-selected` + `aria-controls` |
| Modal | `role="dialog"` + `aria-modal="true"` + focus trap |
| Toast | `role="status"` (polite) or `role="alert"` (assertive) |
| Chart | `role="img"` + `aria-label` summarizing data + visually-hidden `<table>` |
| ScoreGauge | `role="img"` + `aria-label="امتیاز: ۶۷ از ۱۰۰"` |
| SeverityBadge | Text label + icon (not color alone) |

### Skip-to-content link

```tsx
// In every layout
<a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 z-50">
  پرش به محتوا
</a>
<main id="main">
```

### Keyboard shortcuts (Phase 3 §6)

| Shortcut | Action |
|---|---|
| `Cmd/Ctrl+K` | Open Command Palette |
| `g` then `d` | Go to Dashboard |
| `g` then `b` | Go to Behavioral |
| `g` then `i` | Go to Diagnosis |
| `g` then `c` | Go to Coaching |
| `g` then `r` | Go to Report |
| `g` then `h` | Go to History |
| `g` then `t` | Go to Trade Explorer |
| `u` | Go to Upload |
| `?` | Show keyboard help |
| `Esc` | Close modal/drawer/palette |
| `/` | Focus search (on list pages) |
| `d` | Download PDF (on analysis pages) |
| `t` | Toggle theme |
| `l` | Toggle language |

### RTL accessibility

- `dir="rtl"` on `<html>` (default).
- Logical CSS properties (`margin-inline-start`, not `margin-left`).
- Directional icons mirror in RTL.
- Charts reverse x-axis in RTL.
- Screen reader announces in Persian.

### Accessibility testing

- **Automated:** axe-core in development (browser extension + CI).
- **Manual:** NVDA (Windows) + VoiceOver (macOS/iOS) on all 12 flows.
- **Keyboard-only:** Complete all flows without mouse.
- **Colorblind:** Test with protanopia, deuteranopia, tritanopia simulators.

---

## 18. Future Scalability

### Horizontal scaling (multi-instance)

The frontend is stateless. TanStack Query cache is in-memory per request. Deploy multiple instances behind a load balancer — no session affinity needed.

The V23 backend's in-memory store (`api/services/store.py`) is per-process. For multi-instance, swap for Redis (documented in V23 `API_DOCUMENTATION.md` as a known limitation). This is a backend concern, not frontend.

### Feature flags

```typescript
// src/lib/config/features.ts
export const features = {
  auth: process.env.NEXT_PUBLIC_FEATURE_AUTH === 'true',
  subscription: process.env.NEXT_PUBLIC_FEATURE_SUBSCRIPTION === 'true',
  offlineCache: process.env.NEXT_PUBLIC_FEATURE_OFFLINE === 'true',
  mentorWorkspace: process.env.NEXT_PUBLIC_FEATURE_MENTOR === 'true',
};
```

Features are gated at the component level:
```tsx
{features.auth && <AccountMenu />}
{features.subscription && <SubscriptionLink />}
```

### Internationalization (i18n)

Phase 1: Persian + English via `next-intl` (already in dependencies). Messages in `src/messages/fa.json` and `src/messages/en.json`.

Future: Add Arabic, Turkish, Russian (other trading communities). The architecture supports it — just add message files and locale detection.

### Adding new analysis types

If V24 adds new behavioral scores or evidence types:
1. Update `src/lib/types.ts` with new fields.
2. Update Zod validation schemas.
3. Add UI components for the new type.
4. No backend changes (V23 engine untouched).

### Adding new pages

1. Create route in `app/`.
2. Create view in `views/`.
3. Add nav item in `lib/utils/constants.ts`.
4. Add keyboard shortcut if needed.

The architecture is additive — new pages don't require touching existing ones.

### Performance scaling

- **CDN:** Static assets (`/_next/static/`, fonts, illustrations) served via CDN.
- **Edge:** Next.js Edge Runtime for middleware (auth checks at the edge).
- **Image optimization:** `next/image` with remote patterns for any future user-uploaded images.
- **Database (future):** Prisma + PostgreSQL for user accounts, persistent history. SQLite for development.

### Team scaling

The folder structure separates concerns:
- **Design system team** owns `components/ui/` and `lib/styles/`.
- **Feature team** owns `views/` and `components/td/`.
- **Backend integration team** owns `lib/api/` and `app/api/`.
- **Infrastructure team** owns `next.config.ts`, `middleware.ts`, deployment.

Multiple teams can work in parallel without merge conflicts.

---

## 19. Backend Integration Contract

### What the frontend expects from V23 (unchanged)

| Endpoint | Method | Request | Response | Frontend usage |
|---|---|---|---|---|
| `/api/v1/health` | GET | — | `{ status, version, engine_ready, timestamp }` | Health check on app load |
| `/api/v1/config` | GET | — | `{ max_upload_size, allowed_types, llm_providers, auth_enabled, rate_limit_enabled }` | Pre-flight before upload |
| `/api/v1/uploads` | POST | multipart `file` | `{ upload_id, filename, size_bytes, uploaded_at }` | Upload flow |
| `/api/v1/analyses` | POST | `{ upload_id, llm_provider }` | `{ analysis_id, overall_score, primary_diagnosis, ... }` | Run analysis |
| `/api/v1/analyses/{id}` | GET | — | `AnalysisSummary` | Poll for status |
| `/api/v1/analyses/{id}/report` | GET | — | `AnalysisReport` (full JSON) | All analysis views |
| `/api/v1/analyses/{id}/report.html` | GET | — | HTML string | Report download |
| `/api/v1/analyses/{id}/report.pdf` | GET | — | PDF bytes | Report download |
| `/api/v1/analyses/{id}/trades` | GET | `?page=&page_size=&side=&outcome=` | `{ trades, total, page, page_size }` | Trade Explorer (NEW) |
| `/api/v1/history` | GET | `?page=&page_size=` | `{ items, total, page, page_size }` | History page |

### What the frontend adds (BFF layer only)

| BFF Route Handler | V23 Endpoint | Transformation |
|---|---|---|
| `/app/api/v1/*` | `/api/v1/*` | None (pass-through proxy) |

The BFF layer:
1. **Proxies** requests to V23 at `TRADING_DOCTOR_API_URL`.
2. **Adds cache headers** (`Cache-Control`, `next: { revalidate }`).
3. **Handles errors** uniformly (wraps in NextResponse).
4. **Future: adds auth** (forwards `X-API-Key` from JWT).

### What the frontend does NOT do

- ❌ Does NOT modify the V23 engine.
- ❌ Does NOT add new analysis logic.
- ❌ Does NOT recompute scores, thresholds, or diagnoses.
- ❌ Does NOT call engine classes directly (only via API).
- ❌ Does NOT modify the V23 API (except the already-flagged `/trades` endpoint, which is serialization-only).

### Environment variables

```bash
# .env.local (frontend)
TRADING_DOCTOR_API_URL=http://localhost:8000/api/v1  # V23 FastAPI base URL
NEXT_PUBLIC_FEATURE_AUTH=false                        # Enable auth (future)
NEXT_PUBLIC_FEATURE_SUBSCRIPTION=false                # Enable billing (future)
NEXT_PUBLIC_FEATURE_OFFLINE=false                     # Enable offline cache (future)
```

The V23 backend's environment variables (`GEMINI_API_KEY`, `TRADING_DOCTOR_LLM_PROVIDER`, `TRADING_DOCTOR_API_KEYS`, etc.) are unchanged.

---

## 20. Changes Summary

### What this document delivers

| # | Section | Deliverable |
|---|---|---|
| 1 | Recommended Framework | Next.js 16 + TypeScript 5 + Tailwind 4 + shadcn/ui + Recharts + Phosphor + TanStack Query + Zustand |
| 2 | Project Structure | BFF pattern: Browser → Next.js Route Handlers → V23 FastAPI |
| 3 | Folder Structure | Full file tree with `app/`, `components/`, `views/`, `lib/`, `public/` |
| 4 | Component Hierarchy | App-level + page-level hierarchy with ownership rules |
| 5 | Reusable Components | 18 core + 13 composite, all with props and reuse mapping |
| 6 | State Management | Two-tier: TanStack Query (server) + Zustand (client), no Redux |
| 7 | API Layer | BFF Route Handlers proxying to V23, with caching + error handling |
| 8 | Authentication Layer | Phase 1: no auth. Future: NextAuth.js v4 + middleware (no backend changes) |
| 9 | Routing | App Router with 3 route groups: (public), (app), (auth) |
| 10 | Theme System | CSS variables + next-themes, ~50 tokens per theme |
| 11 | Dark Mode Strategy | Dark-first, light fully supported, amber CTA contrast rule |
| 12 | Responsive Strategy | Mobile-first, 6 breakpoints, Dashboard 375px verification |
| 13 | Performance Strategy | RSC + code splitting + image/font optimization, <200KB JS budget |
| 14 | Caching Strategy | 3 layers: HTTP cache + Next.js Data Cache + TanStack Query |
| 15 | Lazy Loading | Route-level (automatic) + component-level (next/dynamic) + images |
| 16 | Error Handling | 3 layers: route boundary + query error + global boundary |
| 17 | Accessibility | WCAG AA, 16 keyboard shortcuts, ARIA patterns, RTL, reduced-motion |
| 18 | Future Scalability | Feature flags, i18n, horizontal scaling, team scaling |
| 19 | Backend Integration Contract | 10 endpoints, BFF proxy pattern, zero backend modifications |

### Backend impact: ZERO

- **V23 analytical engine:** Untouched.
- **V23 API:** Untouched (except already-flagged `/trades` endpoint, Phase 2 §5.1, serialization-only).
- **V23 config:** Untouched.
- **V23 tests:** Untouched.

The frontend is a **pure consumer** of the V23 API. It adds a BFF proxy layer (Next.js Route Handlers) for caching, auth forwarding, and error normalization — but this layer does not modify the backend.

### Hard constraints preserved

- ✅ Dashboard emotional center (4 cards above fold on 375 × 667, verified math: 594px + 73px buffer).
- ✅ Mobile-first responsive (every flow designed for 375px first).
- ✅ Persian-first RTL (`dir="rtl"`, Vazirmatn, logical CSS properties).
- ✅ Engine untouched (BFF proxy only, no engine imports or recomputation).
- ✅ Clarity > Complexity · Actionability > Information Density · Premium SaaS quality.

### Compatibility

This Phase 5 architecture is **fully compatible** with:
- Phase 1 Product Strategy (approved).
- Phase 2 Visual Design + UX Architecture v1.2 (approved).
- Phase 3 Design System v1.1 (approved).
- Phase 4 Screen Design Parts 1 & 2 (approved).
- V23 analytical engine (untouched).

---

**Document version:** v1.0
**Status:** For approval — gate for Phase 6 (Implementation)
**Awaiting approval before Phase 6.**
