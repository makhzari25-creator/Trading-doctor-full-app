# Trading Doctor — Phase 3 Design System & Component Library

**Author:** Senior Design System Architect
**Status:** For approval — gate for Phase 4 (Implementation)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Builds on:** Phase 1 IA (approved) · Phase 2 Visual Design + UX Architecture v1.2 (approved)
**Design methodology:** UI/UX Pro Max Skill Pack v2.6.2 (canonical design system persisted at `design-system/trading-doctor/MASTER.md`)
**Reference tier:** Linear · Stripe · Vercel · TradingView
**Document version:** v1.1 — see §42 (Final Changes Summary) for delta vs v1.0.

> **Phase 1 hard constraints (carried — non-negotiable):**
> 1. Mobile-first & responsive by design.
> 2. Dashboard = emotional center (4 cards above fold on 375 × 667).
> 3. Clarity > Complexity · Actionability > Information Density · Premium SaaS > Feature Quantity.
> 4. Persian-first RTL · dark-default + light-supported · engine untouched.

> **What this document supersedes and extends:**
> This document is the **canonical Phase 3 design system**. It supersedes the design-system section of `phase2_ux_visual_design.md` (which was Phase 2 work; the visual design tokens there are preserved and refined here) and is the authoritative reference for Phase 4 implementation. Where this document and Phase 2 Visual Design differ, **this document wins**. The Phase 2 documents remain as architectural context.

---

## Table of Contents

**Part A — Design Philosophy**
1. Design Philosophy
2. Visual Identity
3. Design Principles

**Part B — Design Tokens**
4. Color Palette (Brand)
5. Semantic Colors
6. Typography Scale & Font Pairing
7. Grid System
8. Spacing Scale
9. Border Radius System
10. Elevation System & Shadows
11. Icon Style
12. Illustration Style
13. Charts Style
14. Animation Principles & Motion Guidelines
15. Responsive Breakpoints
16. Accessibility Rules
17. Design Tokens (Master Token Manifest)

**Part C — Component Library**
18. Component Anatomy Conventions
19. Buttons
20. Cards
21. Inputs
22. Tables
23. Dropdowns / Select
24. Tabs
25. Charts
26. Dialogs / Modals
27. Badges
28. Notifications / Toasts
29. Tooltips
30. Search / Command Palette
31. Pagination
32. Breadcrumbs
33. Progress Indicators
34. Skeleton Loaders
35. Empty States
36. Error States

**Part D — Appendices**
37. Token Naming Convention
38. RTL Considerations
39. Component Inventory Index (incl. Trade Explorer)
40. Phase 4 Implementation Notes (incl. Routing + Dashboard Priority)
41. Changes Summary
42. Final Changes Summary (v1.0 → v1.1)
43. Pre-Phase-4 Validation Checklist

---

## 0. Phase 2+3 Master Specification Note (NEW in v1.1)

**Recommendation:** For Phase 4 (Implementation), the three documents — `phase2_ux_visual_design.md` ("how it looks"), `phase2_ux_architecture.md` ("how it behaves"), and this `phase3_design_system.md` ("the design language") — should be **merged or heavily cross-linked into a single Master UX & Design Specification** before engineering begins.

**Rationale:**
- Phase 4 engineers will need to reference all three documents constantly. Switching between three files (Visual Design for tokens, Architecture for flows/states, Design System for component specs) introduces friction and risk of inconsistency.
- A single Master Spec — with a shared table of contents, unified terminology glossary, one token manifest, one component inventory, and one page-spec-per-page (combining visual + UX + design attributes) — eliminates ambiguity about which document is authoritative for any given decision.
- The cross-reference map in Phase 2 Architecture §8 already maps every topic to its source; merging is a mechanical consolidation, not new design work.

**Suggested Master Spec structure:**
1. Design Philosophy & Principles (from this document §1–§3)
2. Design Tokens (from this document §4–§17 — the single token manifest)
3. Visual Identity (from this document §2, §11–§13 — logo, icons, illustrations, charts)
4. Motion & Interaction (from this document §14)
5. Accessibility & RTL (from this document §16, §38 + Phase 2 Visual Design §9–§10)
6. Responsive Strategy (from this document §15 + Phase 2 Visual Design §11)
7. Component Library (from this document §19–§36 + §39 — the single component inventory)
8. User Flows (from Phase 2 Architecture §2)
9. Per-Page Specifications (merge Phase 2 Visual Design §12 + Phase 2 Architecture §3 into one table per page)
10. API Integration (from Phase 2 Architecture §5)
11. Pre-Phase-4 Validation Checklist (from this document §43 + Phase 2 Architecture §9)

**Action:** Before Phase 4 kickoff, produce `master_ux_design_specification.md` by merging the three documents per the structure above. Keep the originals as archived references. This is a documentation task, not a design task — no new decisions needed.

**If merging is not feasible:** At minimum, add bidirectional hyperlinks between all three documents at every shared topic, and ensure all three carry the same version number and change log.

---

# Part A — Design Philosophy

---

## 1. Design Philosophy

Trading Doctor's design language exists to do one thing: **turn raw trading data into behavioral self-awareness, in 60 seconds, without cognitive overhead.**

Every visual, interaction, and structural decision is filtered through three questions, in order:

1. **Is it clear?** Does the user understand what they're looking at within 2 seconds?
2. **Is it actionable?** Can the user do something with what they see?
3. **Is it premium?** Does it feel like a serious, trustworthy, professional tool — not a free calculator?

### The four reference products, and what we borrow from each

| Reference | What we take | What we don't |
|---|---|---|
| **Linear** | Crisp typography, restrained color, fast micro-interactions, keyboard-first power-user surface, dark-mode-first aesthetic, "feel fast even when it isn't" | Linear's app is task-management; we adapt the *polish*, not the layout |
| **Stripe** | Trust through clarity, generous whitespace, perfect typographic rhythm, accessible color contrast, restrained iconography, "the best interface is no interface" | Stripe's audience is developers integrating payments; we keep their *restraint*, not their demo-heavy homepage |
| **Vercel** | Geometric precision, mono-font numerics, high-contrast data display, performance-budget discipline, "ship at the speed of thought" | Vercel's deployment focus; we keep their *engineering rigor*, not their devops vocabulary |
| **TradingView** | Financial-data legibility, profit/loss color conventions, dense chart layouts that stay readable, professional trader aesthetic, multi-timeframe clarity | TradingView's overwhelming feature density; we keep their *data legibility*, not their UI clutter |

### What makes this "enterprise SaaS tier"

A production-quality enterprise SaaS design language is not just "a lot of components." It is defined by:

1. **Token-driven everything.** No hardcoded values. Every color, font size, space, radius, shadow is a semantic token. Themes are token swaps, not rewrites.
2. **Constraint, not freedom.** Fewer choices, more consistency. Two button variants, not seven. Three card elevations, not ten.
3. **Honesty in every state.** Loading states that match final shapes. Empty states that explain. Error states that recover. No fake progress.
4. **Accessibility is the floor, not the ceiling.** WCAG AA is a minimum. We aim for AAA where the engine's data density allows.
5. **Performance is a design feature.** Animations that don't jank. Skeletons that don't shift. Fonts that don't FOUT. Bundle size is a UX metric.
6. **RTL is a first-class layout, not a flip.** Logical CSS properties everywhere. Charts reverse direction. Persian numerals in prose, Latin in mono data.
7. **Density that serves comprehension.** Trading Doctor is data-dense (Phase 1 §16), but density must serve understanding — not pack more numbers onto a screen. The Dashboard is the *least* dense page; the Trade Explorer is the *most*. Density is intentional, not accidental.

### The Trading Doctor design ethos in one sentence

> *Restraint, precision, and warmth — the calm authority of a senior clinician reading your chart, not the spectacle of a trading floor.*

---

## 2. Visual Identity

### Brand personality

| Trait | Expression |
|---|---|
| **Clinical** | Dark navy base, precise typography, evidence-backed claims. The "doctor" in Trading Doctor. |
| **Premium** | Generous whitespace, considered motion, no decoration without purpose. The "SaaS" in Trading Doctor. |
| **Trustworthy** | Conservative color, honest states, transparent data quality warnings. The "Doctor" you'd confide in. |
| **Persian-first** | Vazirmatn typography, RTL-native layout, Shamsi calendar. The "Trading Doctor" built for the Persian-speaking trading community first. |
| **Empowering** | Verb-led actions, "mark as done" affordances, progressive disclosure. The doctor who gives you a plan, not a diagnosis and a shrug. |

### Logo principles (existing logo is preserved)

- The Trading Doctor logo (medical cross + candlestick motif) is the primary mark.
- Logo lockup: mark (32px) + wordmark "Trading Doctor" (Vazirmatn Bold, 18px).
- Logo color: monochrome `--fg-primary` on dark, `--fg-primary` on light. Never colorized.
- Clear space: 1× mark height on all sides. Never crowd.
- Minimum size: 24px mark. Below that, use mark-only (no wordmark).

### Color philosophy

- **Dark is the default.** Trading dashboards are used in dim environments (home offices, late-night analysis). Dark mode is not a "theme option" — it's the home.
- **Light is fully supported.** Bright offices, daytime use, accessibility preferences. Light mode is a first-class alternative, not a fallback.
- **Color is meaning.** Blue = data/trust. Amber = action (CTA). Green/Amber/Orange/Red = severity (Low/Medium/High/Critical). Color is never decorative.
- **Restraint over vibrancy.** Two accent colors total (blue primary + amber CTA). Everything else is neutral. This is what Linear and Stripe do. TradingView breaks this rule (rainbow indicators); we don't.

### Typographic philosophy

- **Vazirmatn is the voice.** Persian-first, but renders Latin cleanly. Same font for body and display.
- **Fira Code is the data.** All numbers, scores, $ figures, percentages, timestamps use mono. Numbers align in columns. Data is scannable.
- **Fira Sans is the fallback.** For Latin-only contexts where Vazirmatn isn't loaded yet.
- **No display fonts.** No Playfair, no Calistoga, no serifs. We're a clinical tool, not a magazine.

---

## 3. Design Principles

Six principles govern every component, page, and interaction in this system.

### 3.1 Clarity over cleverness
Every element's purpose is obvious. No mystery meat navigation. No icons without labels. No animations that obscure function. If a user has to think "what does this do?", we've failed.

### 3.2 Restraint over richness
Fewer colors, fewer fonts, fewer components, fewer motion choices. Constraint breeds consistency. Two button variants beat seven. Three card elevations beat ten.

### 3.3 Honesty over polish
Loading states match final shapes. Progress reflects reality. Errors explain themselves. Empty states guide forward. We never fake completion, never hide failure, never decorate with motion that lies about state.

### 3.4 Density with breath
Trading Doctor is data-dense — but density is intentional, not accidental. The Dashboard breathes (4 cards, generous whitespace). The Trade Explorer packs (table rows, compact filters). Each page's density matches its purpose.

### 3.5 Accessibility as default
WCAG AA is the minimum. Keyboard navigation is a first-class path. Screen reader support is built-in, not bolted on. `prefers-reduced-motion` is respected everywhere. Color is never the only signal.

### 3.6 Performance as experience
Speed is a feature. First Contentful Paint under 1.5s on 4G. Zero layout shift. Animations that don't jank. Skeletons that match. Bundle size is a UX metric, not an engineering afterthought.

---

# Part B — Design Tokens

---

## 4. Color Palette (Brand)

### 4.1 Brand color story

Trading Doctor's brand palette is built on two pillars:

1. **Deep navy** (`#0A0E1A` dark base / `#F8FAFC` light base) — the "clinical" foundation. Not pure black (OLED smear) and not pure white (eye strain). A tinted neutral that feels considered.
2. **Royal blue** (`#3B82F6` dark / `#1E40AF` light) — the "trust + data" accent. The same blue family used by Stripe and Linear, chosen for its proven legibility on dark backgrounds and its association with financial trust.
3. **Amber** (`#F59E0B` dark / `#D97706` light) — the "action" accent. Reserved exclusively for primary CTAs. Never used for severity, never used for decoration. When the user sees amber, it means "do this."

### 4.2 Brand color tokens

| Token | Dark value | Light value | Usage |
|---|---|---|---|
| `--brand-navy-deep` | `#0A0E1A` | `#F8FAFC` | App background base |
| `--brand-navy-elevated` | `#121829` | `#FFFFFF` | Cards, panels, modals |
| `--brand-blue` | `#3B82F6` | `#1E40AF` | Primary actions, links, focus |
| `--brand-blue-hover` | `#2563EB` | `#1E3A8A` | Primary hover |
| `--brand-amber` | `#F59E0B` | `#D97706` | Primary CTA only |
| `--brand-amber-hover` | `#D97706` | `#B45309` | CTA hover |

### 4.3 Neutral ramp (dark theme)

A 12-step neutral ramp from near-black to near-white, all tinted slightly cool (blue undertone) to match the navy base. This is the Linear/Vercel pattern — never use pure gray.

| Token | Hex | Usage |
|---|---|---|
| `--neutral-0` | `#0A0E1A` | App background (base) |
| `--neutral-50` | `#0F1424` | Subtle elevation |
| `--neutral-100` | `#121829` | Cards, panels |
| `--neutral-200` | `#1A2238` | Inputs, secondary surfaces |
| `--neutral-300` | `#242D45` | Hover states |
| `--neutral-400` | `#334155` | Borders (visible) |
| `--neutral-500` | `#475569` | Tertiary text |
| `--neutral-600` | `#64748B` | Secondary text |
| `--neutral-700` | `#94A3B8` | Muted text |
| `--neutral-800` | `#CBD5E1` | Primary text (subtle) |
| `--neutral-900` | `#E2E8F0` | Primary text |
| `--neutral-1000` | `#F1F5F9` | Primary text (high emphasis) |

### 4.4 Neutral ramp (light theme)

| Token | Hex | Usage |
|---|---|---|
| `--neutral-0` | `#FFFFFF` | Cards, panels |
| `--neutral-50` | `#F8FAFC` | App background |
| `--neutral-100` | `#F1F5F9` | Inputs, secondary surfaces |
| `--neutral-200` | `#E2E8F0` | Borders (subtle) |
| `--neutral-300` | `#CBD5E1` | Borders (visible) |
| `--neutral-400` | `#94A3B8` | Muted text |
| `--neutral-500` | `#64748B` | Secondary text |
| `--neutral-600` | `#475569` | Tertiary text |
| `--neutral-700` | `#334155` | Secondary text (high emphasis) |
| `--neutral-800` | `#1E293B` | Primary text |
| `--neutral-900` | `#0F172A` | Primary text (high emphasis) |
| `--neutral-1000` | `#020617` | Headings |

---

## 5. Semantic Colors

### 5.1 Severity colors (engine-mapped)

The V23 engine produces 4 severity levels: `Low`, `Medium`, `High`, `Critical`. Each maps to a semantic token. **Color is never the only signal** — every severity indicator also has a text label and an icon.

| Severity | Token (dark) | Hex (dark) | Token (light) | Hex (light) | Icon (Phosphor) | Usage |
|---|---|---|---|---|---|---|
| **Low** | `--severity-low` | `#22C55E` | `--severity-low` | `#16A34A` | `CheckCircle` | Healthy, no concern |
| **Medium** | `--severity-medium` | `#F59E0B` | `--severity-medium` | `#D97706` | `Warning` | Watch, moderate |
| **High** | `--severity-high` | `#F97316` | `--severity-high` | `#EA580C` | `WarningOctagon` | Concerning, address soon |
| **Critical** | `--severity-critical` | `#EF4444` | `--severity-critical` | `#DC2626` | `XCircle` | Urgent, address now |

### 5.2 Profit / loss colors

| Meaning | Token (dark) | Hex (dark) | Token (light) | Hex (light) | Usage |
|---|---|---|---|---|---|
| **Profit / Win** | `--profit-positive` | `#22C55E` | `--profit-positive` | `#16A34A` | Positive P&L, winning trade |
| **Loss / Drawdown** | `--profit-negative` | `#EF4444` | `--profit-negative` | `#DC2626` | Negative P&L, losing trade |
| **Break-even / N/A** | `--profit-neutral` | `#64748B` | `--profit-neutral` | `#64748B` | Zero P&L, no data |

Profit/loss reuses the same green/red as severity-low/severity-critical intentionally — it ties the visual language together (red = bad whether it's a behavior or a dollar figure).

### 5.3 Status colors (UI state)

| Status | Token (dark) | Hex (dark) | Token (light) | Hex (light) | Usage |
|---|---|---|---|---|---|
| **Info** | `--status-info` | `#3B82F6` | `--status-info` | `#1E40AF` | Informational toast, info badge |
| **Success** | `--status-success` | `#22C55E` | `--status-success` | `#16A34A` | Success toast, completed action |
| **Warning** | `--status-warning` | `#F59E0B` | `--status-warning` | `#D97706` | Warning toast, data quality warning |
| **Error** | `--status-error` | `#EF4444` | `--status-error` | `#DC2626` | Error toast, validation error |
| **Loading** | `--status-loading` | `#3B82F6` | `--status-loading` | `#1E40AF` | Spinner, indeterminate progress |

### 5.4 Semantic surface tokens

These are the tokens components actually consume. They map to the neutral ramp and brand colors above, but provide semantic naming so components don't care about themes.

| Token | Dark maps to | Light maps to | Usage |
|---|---|---|---|
| `--bg-base` | `--neutral-0` | `--neutral-50` | App background |
| `--bg-elevated` | `--neutral-100` | `--neutral-0` | Cards, panels |
| `--bg-surface` | `--neutral-200` | `--neutral-100` | Inputs, secondary |
| `--bg-overlay` | `rgba(10,14,26,0.72)` | `rgba(15,23,42,0.48)` | Modal/drawer scrim |
| `--bg-hover` | `--neutral-300` | `--neutral-100` | Hover state |
| `--bg-active` | `--neutral-400` | `--neutral-200` | Active/pressed state |
| `--fg-primary` | `--neutral-1000` | `--neutral-900` | Body text, headings |
| `--fg-secondary` | `--neutral-700` | `--neutral-600` | Captions, labels |
| `--fg-muted` | `--neutral-600` | `--neutral-500` | Tertiary, placeholders |
| `--fg-on-primary` | `#FFFFFF` | `#FFFFFF` | Text on blue primary buttons. **NOT used on amber CTA in dark theme** — see note below |
| `--fg-on-cta` | `#0A0E1A` | `#FFFFFF` | Text on amber CTA. Dark theme uses deep navy text on amber for 8.9:1 contrast (Stripe pattern); light theme uses white text (4.8:1, passes AA) |
| `--fg-on-severity` | `#FFFFFF` | `#FFFFFF` | Text on severity-colored surfaces |
| `--border-subtle` | `rgba(255,255,255,0.08)` | `--neutral-200` | Hairline dividers |
| `--border-strong` | `rgba(255,255,255,0.16)` | `--neutral-300` | Visible borders, input borders |
| `--border-focus` | `--brand-blue` | `--brand-blue` | Focus ring |
| `--accent-primary` | `--brand-blue` | `--brand-blue` | Primary actions |
| `--accent-primary-hover` | `--brand-blue-hover` | `--brand-blue-hover` | Primary hover |
| `--accent-cta` | `--brand-amber` | `--brand-amber` | CTA only |
| `--accent-cta-hover` | `--brand-amber-hover` | `--brand-amber-hover` | CTA hover |
| `--ring-focus` | `--brand-blue` | `--brand-blue` | Focus ring (3px outer) |

### 5.5 Color contrast verification (WCAG AA)

All combinations verified at ≥4.5:1 for body text, ≥3:1 for secondary text and non-text UI.

| Foreground | Background | Ratio (dark) | Ratio (light) | Pass |
|---|---|---|---|---|
| `--fg-primary` on `--bg-base` | 14.8:1 | 16.3:1 | ✓ AAA |
| `--fg-primary` on `--bg-elevated` | 13.2:1 | 15.1:1 | ✓ AAA |
| `--fg-secondary` on `--bg-base` | 7.4:1 | 8.9:1 | ✓ AAA |
| `--fg-secondary` on `--bg-elevated` | 6.6:1 | 8.2:1 | ✓ AAA |
| `--fg-muted` on `--bg-base` | 4.8:1 | 5.9:1 | ✓ AA |
| `--fg-muted` on `--bg-elevated` | 4.3:1 | 5.4:1 | ✓ AA |
| `--severity-low` on `--bg-elevated` | 5.2:1 | 4.1:1 | ✓ AA (border/icon only) |
| `--severity-critical` on `--bg-elevated` | 4.9:1 | 4.6:1 | ✓ AA |
| `--fg-on-primary` on `--accent-primary` | 4.6:1 | 7.2:1 | ✓ AA |
| `--fg-on-primary` on `--accent-cta` | 2.8:1 | 4.8:1 | ⚠ Use `--fg-on-primary` only on hover/active for dark amber; default uses `#0A0E1A` text on amber for 8.9:1 |

> **Amber CTA contrast note (reinforced in v1.1):** On dark theme, amber `#F59E0B` with white text (`--fg-on-primary`) is **2.8:1 — FAILS WCAG AA**. This is a common pitfall. The fix: **dark theme amber CTAs use `--fg-on-cta` (`#0A0E1A`, deep navy) text on `--accent-cta` (`#F59E0B`) for 8.9:1 contrast** — this is the Stripe pattern (dark text on bright CTA, same as Stripe's purple buttons). On light theme, `--fg-on-cta` is `#FFFFFF` (white) on `--accent-cta` (`#D97706`) for 4.8:1 (passes AA). **Implementation rule:** the Button component's `primary` variant must conditionally swap `--fg-on-primary` → `--fg-on-cta` based on theme. This is enforced in the Button spec (§19) and validated in §43 (V-CTA-1).

---

## 6. Typography Scale & Font Pairing

### 6.1 Font stack

```
--font-display: 'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* hero, page H1 */
--font-body:    'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* all body text */
--font-mono:    'Fira Code', 'Vazirmatn', ui-monospace, monospace; /* all numbers */
```

### 6.2 Font loading strategy

- **Vazirmatn** (Regular 400, Medium 500, Bold 700) — self-hosted via `next/font/local`. Already bundled in the V23 PDF engine (`reporting/fonts/Vazirmatn-Regular.ttf`, `Vazirmatn-Bold.ttf`); reused for visual parity with PDF reports.
- **Fira Code** (Regular 400, Medium 500, Bold 700) — self-hosted via `next/font/google` (or local fallback).
- **Fira Sans** (Regular 400, Medium 500, SemiBold 600, Bold 700) — fallback only, loaded via `next/font/google`.
- All fonts loaded with `font-display: swap` to prevent FOIT. Skeleton text uses system-ui during swap to minimize FOUT shift.

### 6.3 Type scale (responsive, mobile-first)

| Token | Mobile (375–767px) | Tablet (768–1023px) | Desktop (≥1024px) | Font | Weight | Line-height | Letter-spacing | Usage |
|---|---|---|---|---|---|---|---|---|
| `--text-hero` | 32px | 40px | 48px | display | 700 | 1.1 | -0.02em | Landing hero only |
| `--text-h1` | 24px | 28px | 32px | display | 700 | 1.2 | -0.01em | Page titles |
| `--text-h2` | 20px | 22px | 24px | display | 600 | 1.25 | -0.01em | Section titles |
| `--text-h3` | 18px | 18px | 18px | display | 600 | 1.3 | 0 | Card titles |
| `--text-h4` | 16px | 16px | 16px | display | 600 | 1.35 | 0 | Subsection titles |
| `--text-body` | 16px | 16px | 16px | body | 400 | 1.6 | 0 | Body text (≥16px mobile) |
| `--text-body-sm` | 14px | 14px | 14px | body | 400 | 1.5 | 0 | Secondary body, table cells |
| `--text-caption` | 12px | 12px | 12px | body | 500 | 1.4 | 0.01em | Captions, labels, badges |
| `--text-overline` | 11px | 11px | 11px | body | 600 | 1.4 | 0.08em | Overline labels (uppercase EN, regular FA) |
| `--text-data-sm` | 14px | 14px | 14px | mono | 500 | 1.4 | 0 | Small numeric data |
| `--text-data` | 18px | 20px | 22px | mono | 600 | 1.2 | 0 | Stat card numbers |
| `--text-data-lg` | 24px | 28px | 32px | mono | 700 | 1.1 | -0.01em | Large data (Dashboard cards) |
| `--text-data-xl` | 28px | 32px | 40px | mono | 700 | 1.05 | -0.02em | Dashboard headline numbers |

### 6.4 Typography rules

- **Body text minimum 16px on mobile.** Never 14px for primary content. 14px is for captions and dense table cells only.
- **All numbers in mono font.** Discipline Score, $ figures, percentages, dates — all `--font-mono`. This makes data scannable and columns align naturally.
- **Persian numerals in prose** (۰۱۲۳۴۵۶۷۸۹), Latin numerals in mono data fields. Matches the V23 PDF engine convention.
- **Line-height:** body 1.5–1.6 for readability; headings 1.05–1.3 for tightness. Mono data 1.0–1.2 for vertical alignment.
- **Letter-spacing:** display headings slightly tight (-0.01em to -0.02em) for premium feel; captions/overlines slightly open (0.01em–0.08em) for legibility at small sizes.
- **Font weight:** 400 body, 500 emphasis, 600 headings/labels, 700 hero/strong emphasis. Never use 300 (too thin for screen).

### 6.5 Font pairing rationale

**Vazirmatn + Fira Code** is the Trading Doctor pairing because:

- **Vazirmatn** is the de facto Persian web font (open-source, designed by Saber Rastikerdar, used by major Persian platforms). It renders both Persian and Latin cleanly, has full weight coverage (100–900), and is already bundled in the V23 PDF engine — so the web app and PDF report use the *same* font, ensuring visual parity.
- **Fira Code** is the data font because: monospaced (numbers align in columns), designed for code editors (legible at small sizes), has ligatures (optional, can disable for data), and matches the "technical/precise" mood the UI/UX Pro Max skill recommended for analytics dashboards.
- We deliberately do **not** use Inter (overused, no Persian support), Roboto (no Persian), or system fonts (inconsistent across platforms).

---

## 7. Grid System

### 7.1 Grid tokens

| Token | Value | Usage |
|---|---|---|
| `--grid-columns-mobile` | 4 | Mobile base grid |
| `--grid-columns-tablet` | 8 | Tablet grid |
| `--grid-columns-desktop` | 12 | Desktop grid |
| `--grid-gutter-mobile` | 16px | Mobile column gap |
| `--grid-gutter-tablet` | 24px | Tablet column gap |
| `--grid-gutter-desktop` | 24px | Desktop column gap |
| `--grid-margin-mobile` | 16px | Mobile outer margin |
| `--grid-margin-tablet` | 24px | Tablet outer margin |
| `--grid-margin-desktop` | 32px | Desktop outer margin |

### 7.2 Container widths

| Container | Max width | Usage |
|---|---|---|
| `--container-mobile` | 100% − 32px (16px each side) | All pages on mobile |
| `--container-tablet` | 100% − 48px (24px each side) | All pages on tablet |
| `--container-desktop` | 1280px | All app pages on desktop (centered) |
| `--container-wide` | 1536px | Landing page only (more breathing room) |
| `--container-narrow` | 640px | Long-form text (AI coaching narrative, report preview) |
| `--container-sidebar` | 240px | Desktop sidebar width (collapsible to 72px icon-rail) |

### 7.3 Grid behavior

- **Mobile:** single column, full width. 4-column grid available for internal component layout (e.g., 2×2 KPI grid).
- **Tablet:** 8-column grid. Sidebar becomes 72px icon-rail. Content uses remaining width.
- **Desktop:** 12-column grid. Sidebar 240px. Content max-width 1280px, centered. 12-column grid for complex layouts (e.g., Dashboard 4-card row = 3 columns each).
- **Gutters adapt:** 16px mobile → 24px tablet/desktop. Never use 8px gutters at page level (too cramped); 8px is for component-internal spacing only.

---

## 8. Spacing Scale

### 8.1 Spacing tokens (4/8dp rhythm)

| Token | Value | Rem | Usage |
|---|---|---|---|
| `--space-0` | 0 | 0 | No spacing |
| `--space-1` | 4px | 0.25rem | Tight gaps inside components (icon-to-text) |
| `--space-2` | 8px | 0.5rem | Component padding, small gaps |
| `--space-3` | 12px | 0.75rem | Card padding (mobile), small section gaps |
| `--space-4` | 16px | 1rem | Card padding (desktop), medium gaps, grid gutter mobile |
| `--space-5` | 20px | 1.25rem | Section internal padding |
| `--space-6` | 24px | 1.5rem | Section-to-section gap (mobile), grid gutter tablet/desktop |
| `--space-8` | 32px | 2rem | Section-to-section gap (tablet) |
| `--space-10` | 40px | 2.5rem | Section-to-section gap (desktop) |
| `--space-12` | 48px | 3rem | Page-level vertical rhythm (desktop) |
| `--space-16` | 64px | 4rem | Hero / landing section gaps |
| `--space-20` | 80px | 5rem | Major landing section gaps |
| `--space-24` | 96px | 6rem | Hero bottom spacing |

### 8.2 Spacing rules

- **4/8dp rhythm.** All spacing values are multiples of 4. No 5px, no 13px, no 22px.
- **Component-internal:** `--space-1` (4px) to `--space-3` (12px).
- **Component-to-component:** `--space-3` (12px) to `--space-6` (24px).
- **Section-to-section:** `--space-6` (24px) mobile to `--space-12` (48px) desktop.
- **Page-level:** `--space-12` (48px) to `--space-16` (64px).
- **Never** use arbitrary values. If a value isn't in the scale, redesign the layout.

---

## 9. Border Radius System

### 9.1 Radius tokens

| Token | Value | Usage |
|---|---|---|
| `--radius-none` | 0 | No rounding (full-bleed images, table headers) |
| `--radius-sm` | 4px | Small elements: badges, chips, pills |
| `--radius-md` | 8px | Medium elements: buttons, inputs, small cards |
| `--radius-lg` | 12px | Cards (mobile), panels |
| `--radius-xl` | 16px | Cards (desktop), modals, drawers |
| `--radius-2xl` | 20px | Large cards, hero sections |
| `--radius-full` | 9999px | Circular elements: avatars, icons in pills, toggle thumbs |

### 9.2 Radius rules

- **Mobile cards:** `--radius-lg` (12px) — slightly smaller for compact mobile screens.
- **Desktop cards:** `--radius-xl` (16px) — more generous, premium feel.
- **Buttons & inputs:** `--radius-md` (8px) — consistent with Linear/Vercel.
- **Badges & pills:** `--radius-sm` (4px) for rectangular, `--radius-full` for pill-shaped.
- **Never** mix radius scales within the same component group. All cards use the same radius; all buttons use the same radius.
- **Sharp corners are intentional.** Tables, dividers, and full-bleed images use `--radius-none`. Don't round everything by default.

---

## 10. Elevation System & Shadows

### 10.1 Elevation tokens

A 6-level elevation system. Each level combines a shadow + a subtle background shift to convey depth without heavy shadows (the Linear/Vercel approach — shadows are subtle, depth is conveyed by surface color).

| Level | Token | Shadow (dark) | Shadow (light) | Surface | Usage |
|---|---|---|---|---|---|
| 0 | `--elevation-0` | none | none | `--bg-base` | Flat, base layer |
| 1 | `--elevation-1` | `0 1px 2px rgba(0,0,0,0.3)` | `0 1px 2px rgba(15,23,42,0.05)` | `--bg-base` | Subtle lift, sticky headers |
| 2 | `--elevation-2` | `0 2px 4px rgba(0,0,0,0.3)` | `0 2px 4px rgba(15,23,42,0.06)` | `--bg-elevated` | Cards, default |
| 3 | `--elevation-3` | `0 4px 8px rgba(0,0,0,0.35)` | `0 4px 8px rgba(15,23,42,0.08)` | `--bg-elevated` | Hover state, dropdowns |
| 4 | `--elevation-4` | `0 8px 16px rgba(0,0,0,0.4)` | `0 8px 16px rgba(15,23,42,0.1)` | `--bg-elevated` | Modals, popovers |
| 5 | `--elevation-5` | `0 16px 32px rgba(0,0,0,0.5)` | `0 16px 32px rgba(15,23,42,0.12)` | `--bg-elevated` | Top-level modals, command palette |

### 10.2 Shadow tokens (raw)

| Token | Value (dark) | Value (light) |
|---|---|---|
| `--shadow-sm` | `0 1px 2px rgba(0,0,0,0.3)` | `0 1px 2px rgba(15,23,42,0.05)` |
| `--shadow-md` | `0 2px 4px rgba(0,0,0,0.3)` | `0 2px 4px rgba(15,23,42,0.06)` |
| `--shadow-lg` | `0 4px 8px rgba(0,0,0,0.35)` | `0 4px 8px rgba(15,23,42,0.08)` |
| `--shadow-xl` | `0 8px 16px rgba(0,0,0,0.4)` | `0 8px 16px rgba(15,23,42,0.1)` |
| `--shadow-2xl` | `0 16px 32px rgba(0,0,0,0.5)` | `0 16px 32px rgba(15,23,42,0.12)` |
| `--shadow-inner` | `inset 0 1px 2px rgba(0,0,0,0.2)` | `inset 0 1px 2px rgba(15,23,42,0.06)` |
| `--shadow-focus` | `0 0 0 3px var(--ring-focus)` | `0 0 0 3px var(--ring-focus)` |

### 10.3 Elevation rules

- **Default card:** elevation-2 (subtle shadow + elevated surface).
- **Hover:** elevation-3 (slightly more shadow).
- **Modal/drawer:** elevation-5 (most prominent).
- **Sticky header:** elevation-1 (barely perceptible, just enough to separate from scrolling content).
- **Never** use elevation-5 for cards. It's reserved for overlays.
- **Dark theme:** shadows are stronger (rgba 0.3–0.5) because dark surfaces need more contrast to read as "lifted."
- **Light theme:** shadows are softer (rgba 0.05–0.12) because the surface contrast already conveys depth.

---

## 11. Icon Style

### 11.1 Icon library: Phosphor Icons

**Primary:** Phosphor Icons (`@phosphor-icons/react`) — 1,334+ icons, 6 weights, RTL-aware, tree-shakeable, consistent stroke geometry.

**Fallback:** Heroicons (`@heroicons/react`) — only when Phosphor lacks a semantically-closer match. Never mix libraries at the same hierarchy level.

### 11.2 Icon sizing tokens

| Token | Size | Usage |
|---|---|---|
| `--icon-xs` | 16px | Inline icons in dense tables, badges |
| `--icon-sm` | 20px | Icon + text in buttons, list items |
| `--icon-md` | 24px | Default — nav items, card icons |
| `--icon-lg` | 32px | Section header icons, empty-state illustrations |
| `--icon-xl` | 48px | Hero icon, large empty states |

### 11.3 Icon style rules

- **Weight:** Regular (1.5px stroke) for navigation and secondary; Bold for active state and primary actions; Fill for active state in icon-only contexts. **Never mix weights at the same hierarchy level.**
- **Color:** icons inherit `currentColor` by default. Severity-colored icons override with severity tokens. Never raw hex.
- **Stroke:** 1.5px default (Phosphor "regular"). Consistent across the app.
- **Filled vs outline:** outline for navigation/secondary, filled for active/primary only. Mixing at the same level is forbidden.
- **RTL:** directional icons (arrows, chevrons) flip in RTL. Phosphor supports this via `mirror` prop or CSS `[dir="rtl"]` scoped `transform: scaleX(-1)`.
- **No emojis as structural icons.** This is a Phase 1 hard constraint and a UI/UX Pro Max rule. The current Streamlit app's emoji nav is a known violation this design system fixes.

### 11.4 Standard icon mapping (key actions)

| Action | Phosphor icon | Weight |
|---|---|---|
| Upload | `UploadSimple` | Bold |
| Download | `DownloadSimple` | Regular |
| Download PDF | `FilePdf` | Regular |
| Download HTML | `FileHtml` | Regular |
| Run analysis | `Play` | Fill |
| Cancel / close | `X` | Regular |
| Back (RTL) | `ArrowRight` | Regular |
| Back (LTR) | `ArrowLeft` | Regular |
| See more | `CaretDown` | Regular |
| Search | `MagnifyingGlass` | Regular |
| Filter | `Funnel` | Regular |
| Sort | `ArrowsDownUp` | Regular |
| Settings | `Gear` | Regular |
| Theme (light) | `Sun` | Regular |
| Theme (dark) | `Moon` | Regular |
| Language | `Translate` | Regular |
| User / account | `UserCircle` | Regular |
| Notifications | `Bell` | Regular |
| Delete | `Trash` | Regular |
| Edit | `Pencil` | Regular |
| Check / done | `Check` | Bold |
| Check circle | `CheckCircle` | Fill |
| Warning | `Warning` | Fill |
| Error | `XCircle` | Fill |
| Info | `Info` | Regular |
| Help | `Question` | Regular |
| External link | `ArrowUpRight` | Regular |
| Menu (hamburger) | `List` | Regular |
| More (⋯) | `DotsThree` | Regular |

### 11.5 Nav icon mapping (Phase 2 §4.5)

| Nav item | Phosphor icon |
|---|---|
| Dashboard | `Gauge` |
| Behavioral Analysis | `ChartBar` |
| Diagnosis | `Stethoscope` |
| Coaching | `Lightbulb` |
| Trader DNA | `Dna` |
| Edge Map | `MapPin` |
| Charts | `ChartLineUp` |
| Trade Explorer | `Table` |
| Trends | `TrendUp` |
| Report | `FileText` |
| History | `ClockCounterClockwise` |

---

## 12. Illustration Style

### 12.1 Illustration philosophy

Trading Doctor uses illustrations sparingly — only for empty states and the landing page hero. **No decorative illustrations on functional pages.** This is the Stripe/Vercel approach: illustrations explain, they don't decorate.

### 12.2 Illustration style

- **Style:** Geometric, line-based, two-tone. Single-weight strokes (2px). Minimal fills. Consistent with Phosphor icon geometry.
- **Color:** `--fg-secondary` strokes on `--bg-elevated` background. Accent color (`--accent-primary` or `--accent-cta`) for the "story" element.
- **Mood:** Calm, professional, slightly warm. Never cartoonish. Never sarcastic. Never alarming.
- **Size:** 120×120px for empty states, 240×240px for landing hero.
- **Format:** Inline SVG (theme-aware, can recolor via `currentColor`).

### 12.3 Illustration inventory (updated v1.1 — exact filenames)

All illustrations are inline SVG files stored in `public/illustrations/`. Filename convention: `{name}.svg`. Each is theme-aware (uses `currentColor` and semantic tokens).

| Illustration | Filename | Usage | Description |
|---|---|---|---|
| `empty-analysis` | `empty-analysis.svg` | No analysis in context (Tier 2+ pages accessed without analysis) | A clipboard with a magnifying glass, no data lines |
| `empty-history` | `empty-history.svg` | History page with no past analyses | A clock with no hands, faint calendar grid behind |
| `empty-trends` | `empty-trends.svg` | Trends page with <2 analyses | Two dots connected by a dashed line, suggesting "more needed" |
| `empty-trades` | `empty-trades.svg` | Trade Explorer with no trades matching filter | A filter funnel with nothing passing through |
| `empty-edge-map` | `empty-edge-map.svg` | Edge Map with insufficient data (engine requires ≥5 trades per bucket) | A map pin with a question mark |
| `error-generic` | `error-generic.svg` | Generic error state (500, fetch failed) | A clipboard with an "X" mark, calm not alarming |
| `error-network` | `error-network.svg` | Network error (connection failed, timeout) | A disconnected plug, calm |
| `success-analysis` | `success-analysis.svg` | Analysis complete (briefly shown on Analysis Progress → Dashboard transition) | A clipboard with a checkmark |
| `hero-landing` | `hero-landing.svg` | Landing page hero | Abstract: candlesticks transforming into a behavioral waveform |

**File storage:** `public/illustrations/{name}.svg`
**Import pattern:** `import { ReactComponent as EmptyAnalysis } from '@/public/illustrations/empty-analysis.svg'` (or `<img src="/illustrations/empty-analysis.svg" />` for static use).
**Theme handling:** SVGs use `currentColor` for strokes; the parent component sets `color: var(--fg-secondary)`. This makes the illustration automatically adapt to dark/light theme.

### 12.4 Illustration rules

- **Never use stock illustrations.** All illustrations custom-drawn to match the geometric line style.
- **Never use emojis** as illustration substitutes.
- **Never use illustrations on data pages.** They're for empty/error states and landing only.
- **Theme-aware:** illustrations must look correct in both dark and light themes (via `currentColor` and semantic tokens).

---

## 13. Charts Style

### 13.1 Chart library: Recharts

**Primary:** Recharts (React charting library built on D3). Chosen for: React-native, declarative API, responsive, accessible (SVG-based), good RTL support, tree-shakeable.

**Fallback:** Chart.js for high-density real-time charts (not needed in Phase 1; all V23 charts are static post-analysis).

### 13.2 Chart color palette

| Series | Token | Dark hex | Light hex | Usage |
|---|---|---|---|---|
| Primary | `--chart-primary` | `#3B82F6` | `#1E40AF` | Primary data series |
| Secondary | `--chart-secondary` | `#8B5CF6` | `#7C3AED` | Secondary series |
| Tertiary | `--chart-tertiary` | `#06B6D4` | `#0891B2` | Tertiary series |
| Positive | `--chart-positive` | `#22C55E` | `#16A34A` | Profit, win, growth |
| Negative | `--chart-negative` | `#EF4444` | `#DC2626` | Loss, drawdown, decline |
| Neutral | `--chart-neutral` | `#64748B` | `#94A3B8` | Break-even, grid, axes |
| Grid | `--chart-grid` | `rgba(255,255,255,0.06)` | `rgba(15,23,42,0.06)` | Grid lines |
| Axis | `--chart-axis` | `#475569` | `#94A3B8` | Axis labels |

### 13.3 Chart type mapping (Phase 2 §3.11 Charts page)

| Chart | Type | Color | Question |
|---|---|---|---|
| Equity Curve | Area (gradient fill) | `--chart-primary` | "How did my account grow?" |
| Drawdown | Area (negative, red) | `--chart-negative` | "What was my worst period?" |
| P&L Distribution | Histogram (green/red) | `--chart-positive` / `--chart-negative` | "Are wins bigger than losses?" |
| Hourly Heatmap | Heatmap (diverging) | `--chart-positive` → `--chart-negative` | "When am I most/least profitable?" |
| Weekday Breakdown | Bar chart | `--chart-primary` (green/red variants) | "Which days work for me?" |
| Win/Loss Streaks | Bar chart (green/red) | `--chart-positive` / `--chart-negative` | "How long are my streaks?" |
| Score Radar (Behavioral) | Radar (5-axis) | `--chart-primary` with 20% fill | "How do my scores compare?" |
| Trend Line (Trends page) | Line chart | `--chart-primary` | "Am I improving over time?" |

### 13.4 Chart styling rules

- **Grid lines:** 1px, `--chart-grid` color, dashed (2,2). Subtle, not dominant.
- **Axis labels:** `--text-caption` (12px), `--chart-axis` color. Mono font for numeric labels.
- **Data points:** 4px circle on hover, hidden by default (clean lines).
- **Tooltips:** `--elevation-4` shadow, `--bg-elevated` background, `--text-body-sm` size, mono font for numbers. Appear with 100ms fade.
- **Legend:** Below chart, `--text-caption` size, color swatch + label. Never inside the chart.
- **Empty state:** If insufficient data, show `empty-edge-map` illustration + message inside chart area.
- **Reduced motion:** Chart entrance animations disabled (instant render). Hover tooltips still work.
- **RTL:** x-axis reversed (earliest right, latest left) in RTL mode. Recharts supports via `reversed` prop.

### 13.5 Chart accessibility

- Every chart has `aria-label` summarizing the data (e.g., «منحنی سرمایه از ۱ ژانویه تا ۳۱ مارس، از ۱۰٬۰۰۰ دلار به ۱۲٬۵۰۰ دلار»).
- Visually-hidden `<table>` with raw data as alternative for screen readers.
- Color is never the only differentiator — line style (solid/dashed), shape markers, and labels supplement color.
- Tooltip content available to screen readers via `aria-live="polite"` on tooltip container.

---

## 14. Animation Principles & Motion Guidelines

### 14.1 Motion philosophy

Motion in Trading Doctor is **functional, never decorative.** Every animation communicates something: state change, spatial relationship, progress, feedback. We follow the Linear/Vercel approach: motion is so subtle it feels like the UI is "just responding," not performing.

### 14.2 Motion tokens

| Token | Duration | Easing | Usage |
|---|---|---|---|
| `--duration-instant` | 0ms | — | No animation (reduced-motion fallback) |
| `--duration-fast` | 100ms | `ease-out` | Press feedback, color change |
| `--duration-normal` | 200ms | `cubic-bezier(0.16, 1, 0.3, 1)` (Expo.out) | Hover, focus, small transitions |
| `--duration-moderate` | 300ms | `cubic-bezier(0.16, 1, 0.3, 1)` | Modal open, accordion expand, tab switch |
| `--duration-slow` | 400ms | `cubic-bezier(0.7, 0, 0.84, 0)` (Expo.in) | Modal close, exit transitions |
| `--duration-page` | 500ms | `power2.inOut` | Page transitions (route changes) |

### 14.3 Easing functions

| Token | Value | Usage |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` (Expo.out) | Entrances — things arriving |
| `--ease-in` | `cubic-bezier(0.7, 0, 0.84, 0)` (Expo.in) | Exits — things leaving |
| `--ease-in-out` | `cubic-bezier(0.65, 0, 0.35, 1)` | Symmetric transitions |
| `--ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Spring-like (subtle overshoot) — for "mark as done" checkmark |

### 14.4 Motion principles

1. **Exit faster than enter.** Enter: 200–300ms. Exit: 150–200ms. Users want their next action to start, not watch the previous one finish.
2. **Expo.out for entrances.** Things arrive fast then decelerate — feels responsive.
3. **Expo.in for exits.** Things accelerate away — feels decisive.
4. **Spring for celebrations.** The only place we use spring easing is the "mark as done" checkmark in Coaching — a small reward.
5. **`prefers-reduced-motion: reduce`** freezes all motion to ≤1ms. Page still works perfectly; only the animation is removed. Skeletons switch to static grey blocks (no pulse).
6. **Stable press states.** Buttons scale to 0.97 on press — no layout shift, no surrounding content movement. Touch feedback within 80–150ms.
7. **No parallax. No autoplay carousels. No GSAP pin/Flip/SplitText.** Motion is Standard tier (per Phase 2 Visual Design §2.1).
8. **Loading is not motion.** Skeletons don't animate (in reduced-motion) but they still show. Spinners spin (but freeze in reduced-motion). Progress bars fill (but instantly in reduced-motion).
9. **Keyboard shortcuts are instant.** The Command Palette (`Cmd/Ctrl+K`, per §30 and Phase 2 §6) opens with a 200ms fade+slide, but all keyboard-triggered navigations (`g`+letter, `u`, `?`, `t`, `l`, `d`) are **instant** — no transition animation. Power users want speed, not spectacle. The only motion in keyboard flows is the palette's own open/close animation.

### 14.5 Interaction pattern library

| Pattern | Trigger | Response | Duration | Easing |
|---|---|---|---|---|
| Button press | tap/click/Enter | scale 0.97 + bg color shift | 100ms | `--ease-out` |
| Card hover (interactive) | mouse hover | elevation 2→3 + border highlight | 200ms | `--ease-out` |
| Tab switch | click | content cross-fade | 200ms | `--ease-in-out` |
| Accordion expand | click | height auto + content fade-in | 250ms | `--ease-out` |
| Modal open | trigger | backdrop fade-in (150ms) + content scale-up 0.95→1 (200ms) | 350ms total | `--ease-out` |
| Modal close | X / backdrop / Esc | content scale-down 1→0.95 (150ms) + backdrop fade-out (150ms) | 150ms total | `--ease-in` |
| Toast enter | trigger | slide-in from top (RTL: top-right; LTR: top-left) | 250ms | `--ease-out` |
| Toast exit | auto (4s) / X | slide-out + fade | 200ms | `--ease-in` |
| Page transition (route change) | nav click | overlay slide-down → swap → overlay slide-up | 400ms total | `--ease-in-out` |
| Skeleton → content | data loaded | skeleton fade-out (100ms) + content fade-in (200ms) | 300ms total | `--ease-out` |
| Chart render | data loaded | bars/lines grow from baseline | 400ms | `--ease-out` |
| Score gauge fill | data loaded | arc fills from 0 to value | 600ms | `--ease-out` |
| Drawer open (mobile nav) | hamburger tap | backdrop fade + drawer slide-in from side | 250ms | `--ease-out` |
| Drag-over dropzone | file dragged over | border dash + bg tint | 150ms | `--ease-out` |
| Progress stepper advance | stage completes | checkmark pop (scale 0→1.2→1) | 300ms | `--ease-spring` |
| "Mark as done" toggle | click | checkmark pop + strikethrough fade | 300ms | `--ease-spring` |

### 14.6 Reduced-motion handling

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

- All motion ≤1ms.
- Skeletons: static grey blocks (no pulse).
- Spinners: static (or hidden, replaced by text "Loading...").
- Page transitions: instant swap, no overlay.
- Charts: instant render, no grow animation.
- Score gauge: instant fill to value.
- Tooltips/modals: instant appear/disappear.

---

## 15. Responsive Breakpoints

### 15.1 Breakpoint tokens (mobile-first)

| Breakpoint | Min width | Target devices | Container |
|---|---|---|---|
| `xs` (default) | 0px | Mobile portrait (375–414px) | `--container-mobile` |
| `sm` | 640px | Mobile landscape, small tablet portrait | `--container-mobile` |
| `md` | 768px | Tablet portrait (iPad) | `--container-tablet` |
| `lg` | 1024px | Tablet landscape, small laptop | `--container-desktop` |
| `xl` | 1280px | Desktop | `--container-desktop` |
| `2xl` | 1536px | Large desktop | `--container-wide` |

### 15.2 Breakpoint rules

- **Mobile-first:** base styles target `xs` (375px). Breakpoints layer enhancements upward via `min-width` media queries. Never use `max-width` queries (desktop-first).
- **Implementation:** Tailwind-style `sm:`, `md:`, `lg:`, `xl:`, `2xl:` prefixes. Base (no prefix) = mobile.
- **Testing:** every page verified at 375 / 768 / 1024 / 1280 / 1536px (Phase 2 §9.1 R1–R8).

### 15.3 Layout per breakpoint (recap from Phase 2)

| Breakpoint | Sidebar | Top bar | Bottom bar | Content max-width | Grid |
|---|---|---|---|---|---|
| `< sm` (mobile portrait) | Off-canvas drawer | Logo + hamburger + theme | 5-item tab bar | 100% − 32px | 1–4 col |
| `sm` to `< md` | Off-canvas drawer | + analysis badge | 5-item tab bar | 100% − 48px | 2–4 col |
| `md` to `< lg` (tablet) | Icon-rail (72px) | + language toggle | hidden | 100% − 72px − 48px | 2–8 col |
| `lg` to `< xl` | Full sidebar (240px) | Full | hidden | 1024px | 8–12 col |
| `≥ xl` (desktop) | Full sidebar (240px) | Full | hidden | 1280px | 12 col |
| `≥ 2xl` | Full sidebar (240px) | Full | hidden | 1536px | 12 col |

---

## 16. Accessibility Rules

### 16.1 Contrast (WCAG AA minimum, AAA target where possible)

- Body text: ≥4.5:1 against background (both themes).
- Secondary text (captions, muted): ≥3:1.
- Non-text UI (icons, borders, focus rings): ≥3:1.
- Severity colors verified against both `--bg-base` and `--bg-elevated` in both themes.
- Full contrast table in §5.5.

### 16.2 Keyboard navigation

- Every interactive element is reachable via Tab in logical order (matches visual order).
- Visible focus ring: 3px solid `--ring-focus`, 2px offset, on every focusable element. Never removed without replacement.
- `Esc` closes modals, drawers, dropdowns, command palette.
- `Enter`/`Space` activates buttons, links, cards.
- `Arrow keys` navigate tabs, accordion, segmented controls, radio groups, listbox.
- `Cmd/Ctrl+K` opens command palette. `?` shows keyboard help. `g`+letter navigates pages (Phase 2 §6).
- Skip-to-content link at top of every page (visually hidden until focused).

### 16.3 Screen reader support

- Every interactive element has an `aria-label` or visible text label.
- Decorative icons: `aria-hidden="true"`.
- Functional icons (icon-only buttons): `aria-label` describing the action.
- Severity indicators: announced as «شدت: بالا» / "Severity: High" — never color alone.
- Charts: `aria-label` summarizing data + visually-hidden `<table>` alternative.
- Live regions: toasts `aria-live="polite"`, errors `aria-live="assertive"`, progress `aria-live="polite"`.
- Landmarks: `<header>`, `<nav>`, `<main>`, `<aside>`, `<footer>` on every page.

### 16.4 Color and contrast

- Color is never the only signal (per UI/UX Pro Max rule). Every color-coded indicator has a text label and/or icon.
- Tested with colorblind simulators (protanopia, deuteranopia, tritanopia) — severity colors distinguishable by brightness/shape, not hue alone.

### 16.5 Touch targets

- All interactive elements ≥44×44pt on mobile.
- Where visual element is smaller (e.g., 20px icon button), `padding` extends hit area to 44pt without changing visual size.
- Adjacent touch targets separated by ≥8px to prevent mis-taps.

### 16.6 Reduced motion

- `@media (prefers-reduced-motion: reduce)` sets all animation/transition durations to 0.01ms.
- Page still functions perfectly — only motion is removed.
- Skeletons switch to static grey blocks (no pulse).
- Full handling in §14.6.

### 16.7 RTL

- Default direction `dir="rtl"`, default language `fa`.
- All components use logical CSS properties (`margin-inline-start`, not `margin-left`).
- Icons mirror in RTL (directional icons).
- Charts reverse x-axis in RTL.
- Full RTL considerations in §38.

---

## 17. Design Tokens (Master Token Manifest)

### 17.1 Token naming convention

All tokens follow a strict naming convention: `--{category}-{property}-{variant}`.

| Category | Example | Notes |
|---|---|---|
| `--color-*` | `--color-primary`, `--color-severity-low` | Brand + semantic colors |
| `--font-*` | `--font-body`, `--font-mono` | Font families |
| `--text-*` | `--text-h1`, `--text-body` | Type scale |
| `--space-*` | `--space-4`, `--space-8` | Spacing scale |
| `--radius-*` | `--radius-md`, `--radius-lg` | Border radius |
| `--shadow-*` | `--shadow-md`, `--shadow-focus` | Shadows |
| `--elevation-*` | `--elevation-2` | Elevation levels (shadow + surface) |
| `--duration-*` | `--duration-normal`, `--duration-slow` | Animation durations |
| `--ease-*` | `--ease-out`, `--ease-spring` | Easing functions |
| `--icon-*` | `--icon-md` | Icon sizes |
| `--grid-*` | `--grid-columns-desktop` | Grid tokens |
| `--container-*` | `--container-desktop` | Container widths |
| `--breakpoint-*` | `--breakpoint-md` | Breakpoints |

### 17.2 Token categories summary

| Category | Token count | Defined in |
|---|---|---|
| Brand colors | 6 | §4.2 |
| Neutral ramp (dark) | 12 | §4.3 |
| Neutral ramp (light) | 12 | §4.4 |
| Severity colors | 4 × 2 themes | §5.1 |
| Profit/loss colors | 3 × 2 themes | §5.2 |
| Status colors | 5 × 2 themes | §5.3 |
| Semantic surfaces | 18 | §5.4 |
| Typography | 13 type tokens + 3 font families | §6 |
| Grid | 9 | §7 |
| Spacing | 13 | §8 |
| Radius | 7 | §9 |
| Elevation | 6 + 7 raw shadows | §10 |
| Icons | 5 sizes + 30+ mappings | §11 |
| Charts | 8 colors | §13 |
| Motion | 6 durations + 4 easings | §14 |
| Breakpoints | 6 | §15 |
| **Total** | **~150 tokens** | |

### 17.3 Token usage rules

1. **Components consume tokens, never raw values.** No `color: #3B82F6` in components. Always `color: var(--accent-primary)`.
2. **Themes are token swaps.** Switching themes redefines token values; components don't change.
3. **No inline styles.** All styling via CSS classes that reference tokens.
4. **Tokens are typed.** Color tokens are colors, space tokens are lengths. Don't mix.
5. **Tokens are documented.** Every token has a usage description in this document.

### 17.4 Token export format

Tokens are exported as:
- **CSS custom properties** (`--token-name: value;`) in `globals.css` — consumed by all components.
- **TypeScript constants** (`export const tokens = { ... }`) in `lib/tokens.ts` — consumed by JS (e.g., Recharts color props).
- **Tailwind config** (`theme.extend.colors`, etc.) in `tailwind.config.ts` — consumed by Tailwind utility classes.

All three are generated from a single source of truth (`tokens.json`) to prevent drift. Phase 4 implementation will create this generator.

---

# Part C — Component Library

---

## 18. Component Anatomy Conventions

Every component spec in this section follows the same anatomy:

| Section | Content |
|---|---|
| **Purpose** | One sentence: what this component is for. |
| **Variants** | The list of variants (e.g., Button: primary, secondary, ghost, destructive). |
| **Anatomy** | Visual structure (parts labeled). |
| **Tokens consumed** | Which design tokens this component uses. |
| **States** | All interactive states (default, hover, active, focus, disabled, loading). |
| **Sizes** | Size variants if applicable (sm, md, lg). |
| **Props (conceptual)** | Conceptual props (not implementation — Phase 4 will finalize). |
| **Accessibility** | ARIA roles, keyboard, screen reader behavior. |
| **RTL** | RTL-specific behavior. |
| **Usage examples** | Where this component appears in the app. |
| **Do / Don't** | Common mistakes to avoid. |

---

## 19. Buttons

### Purpose
Buttons trigger actions. They are the primary way users do things.

### Variants

| Variant | When to use | Visual |
|---|---|---|
| `primary` | Main action on a page (one per page) | `--accent-cta` bg, `--bg-base` text (dark) / `--fg-on-primary` text (light) |
| `secondary` | Alternative action, secondary CTA | `transparent` bg, `--accent-primary` text + border |
| `ghost` | Tertiary action, low emphasis | `transparent` bg, `--fg-secondary` text, no border |
| `destructive` | Delete, remove, irreversible | `--severity-critical` bg, `--fg-on-severity` text |
| `link` | Inline action within text | `transparent` bg, `--accent-primary` text, underline on hover |

### Anatomy

```
┌─────────────────────────────────────┐
│  [icon?]  Label              [icon?] │
└─────────────────────────────────────┘
   ←── padding: --space-3 --space-4 ──→
   ←── height: 44px (md), 48px (lg), 40px (sm) ──→
```

### Tokens consumed
`--accent-cta`, `--accent-cta-hover`, `--accent-primary`, `--accent-primary-hover`, `--severity-critical`, `--fg-on-primary`, `--bg-base`, `--fg-secondary`, `--radius-md`, `--text-body-sm`, `--font-body`, `--space-3`, `--space-4`, `--duration-fast`, `--ease-out`, `--shadow-focus`.

### States

| State | Primary | Secondary | Ghost | Destructive |
|---|---|---|---|---|
| **default** | `--accent-cta` bg | transparent bg, `--accent-primary` border+text | transparent, `--fg-secondary` | `--severity-critical` bg |
| **hover** | `--accent-cta-hover` | `--accent-primary` bg at 8% opacity | `--bg-hover` bg | `--severity-critical` at 90% opacity |
| **active/pressed** | scale 0.97, `--accent-cta-hover` | scale 0.97 | scale 0.97, `--bg-active` | scale 0.97 |
| **focus** | 3px `--shadow-focus` ring | 3px `--shadow-focus` ring | 3px `--shadow-focus` ring | 3px `--shadow-focus` ring |
| **disabled** | 50% opacity, `cursor-not-allowed` | 50% opacity | 50% opacity | 50% opacity |
| **loading** | spinner (replaces icon) + label greyed | same | same | same |

### Sizes

| Size | Height | Padding | Font | Icon |
|---|---|---|---|---|
| `sm` | 32px | `--space-2 --space-3` | `--text-caption` (12px) | `--icon-sm` (16px) |
| `md` (default) | 40px | `--space-2 --space-4` | `--text-body-sm` (14px) | `--icon-sm` (20px) |
| `lg` | 48px | `--space-3 --space-5` | `--text-body` (16px) | `--icon-md` (24px) |

### Accessibility
- `<button>` element (or `<a>` for link variant).
- `aria-label` if icon-only.
- `aria-busy="true"` when loading.
- `disabled` attribute when disabled (not just a class).
- Focus ring always visible (never `outline: none` without replacement).
- Enter/Space activates.

### RTL
- Icon + text layout flips (icon on right in RTL).
- No other RTL-specific behavior.

### Usage examples
- Primary: «شروع تحلیل» (Upload CTA), «دانلود PDF» (Report).
- Secondary: «گزارش نمونه ببین» (Home), «دانلود HTML» (Report).
- Ghost: «پاک کردن فیلترها» (Trade Explorer), «نمایش کمتر» (Coaching).
- Destructive: «حذف» (History delete confirm), «پاک کردن همه‌ی داده‌ها» (Settings).
- Link: inline «بیشتر بدانید» links.

### Do / Don't

| Do | Don't |
|---|---|
| One primary button per page | Multiple primary buttons competing |
| Use `secondary` for cancel alongside `primary` | Use `destructive` for cancel |
| Icon + text for important actions | Icon-only without `aria-label` |
| `loading` state with spinner | Disabling button without explanation |
| 44px min touch target on mobile | 32px touch target on mobile |

---

## 20. Cards

### Purpose
Cards are surface containers that group related content. They are the primary structural element on most pages.

### Variants

| Variant | When to use | Visual |
|---|---|---|
| `default` | Standard content grouping | `--bg-elevated`, `--elevation-2`, `--radius-lg` (mobile) / `--radius-xl` (desktop) |
| `elevated` | Modal-like, prominent | `--bg-elevated`, `--elevation-4`, `--radius-xl` |
| `interactive` | Clickable card (drill-down) | default + hover elevation-3 + cursor-pointer |
| `severity-bordered` | Diagnosis/evidence cards | default + 4px border-inline-start with severity color |
| `stat` | Single metric display | default + centered content + large mono number |

### Anatomy

```
┌─── radius-lg/xl, elevation-2 ───────────────────┐
│  ←-- padding: --space-4 (mobile) / --space-6 (desktop) --→ │
│                                                   │
│   [icon?]  Title                    [action?]     │
│   ─────────────────────────────────────────────── │
│                                                   │
│   Content area                                    │
│                                                   │
│   [footer action?]                                │
│                                                   │
└───────────────────────────────────────────────────┘
```

### Tokens consumed
`--bg-elevated`, `--elevation-2` (default), `--elevation-3` (hover), `--elevation-4` (elevated), `--radius-lg`, `--radius-xl`, `--border-subtle`, `--space-4`, `--space-6`, `--text-h3`, `--text-body`, `--fg-primary`, `--fg-secondary`, `--severity-*` (for severity-bordered).

### States

| State | Behavior |
|---|---|
| **default** | `--elevation-2`, `--bg-elevated` |
| **hover** (interactive only) | `--elevation-3`, border `--border-strong`, 200ms `--ease-out` |
| **active/pressed** (interactive only) | scale 0.99, `--elevation-2` |
| **focus** (interactive only) | 3px `--shadow-focus` ring |
| **loading** | Content replaced with Skeleton |
| **empty** | Content replaced with EmptyState component |

### Accessibility
- If interactive: `role="button"` (or `<button>` element), `tabindex="0"`, `aria-label` describing the action.
- If not interactive: `<div>` with semantic content.
- Card title is a heading (`<h3>` or `<h4>` depending on context).
- Severity border color also has text label (not color alone).

### RTL
- Severity border on `border-inline-start` (right in RTL, left in LTR).
- Content alignment follows text direction.
- No other RTL-specific behavior.

### Usage examples
- `default`: AI Coaching narrative, Reality Check, About section.
- `elevated`: Modals, command palette.
- `interactive`: Dashboard 4 emotional-center cards, History item cards, quick-jump tiles.
- `severity-bordered`: Diagnosis primary/secondary cards, Evidence cards, Recommendation cards (P1).
- `stat`: Performance strip (Win Rate, Profit Factor, etc.).

### Do / Don't

| Do | Don't |
|---|---|
| One card = one topic | Multiple unrelated topics in one card |
| Consistent padding within a page | Mixed padding (16px and 24px in same row) |
| `interactive` only when clickable | Making every card clickable "just in case" |
| Severity border for diagnosis/evidence | Severity border for decoration |

---

## 21. Inputs

### Purpose
Inputs let users enter text, numbers, or select values.

### Variants

| Variant | When to use |
|---|---|
| `text` | Email, filename, search query |
| `password` | Passwords (with show/hide toggle) |
| `number` | Numeric input (size range, page size) |
| `search` | Search with magnifying glass icon |
| `with-icon` | Input with leading icon (e.g., date picker) |
| `with-suffix` | Input with trailing unit (e.g., "$", "%") |

### Anatomy

```
┌─── radius-md, elevation-0 ─────────────────────────┐
│  [leading icon?]  ←placeholder→  [trailing icon?]   │
└─────────────────────────────────────────────────────┘
   ←── height: 44px (md), 48px (lg) ──→
   ←── padding: --space-3 --space-4 ──→

Label (above input, --text-caption, --fg-secondary)
Helper text (below input, --text-caption, --fg-muted)
Error message (below input, --text-caption, --severity-critical)
```

### Tokens consumed
`--bg-surface`, `--bg-elevated`, `--border-strong`, `--border-focus`, `--fg-primary`, `--fg-secondary`, `--fg-muted`, `--severity-critical`, `--radius-md`, `--text-body-sm`, `--space-3`, `--space-4`, `--shadow-focus`, `--duration-fast`, `--ease-out`.

### States

| State | Visual |
|---|---|
| **default** | `--bg-surface`, `--border-strong` 1px, `--fg-secondary` placeholder |
| **hover** | `--border-strong` darkens slightly |
| **focus** | `--border-focus` 2px + `--shadow-focus` 3px ring |
| **filled** | `--fg-primary` text |
| **error** | `--severity-critical` 2px border + error message below |
| **disabled** | 50% opacity, `cursor-not-allowed` |
| **loading** (search async) | Trailing spinner icon |

### Sizes

| Size | Height | Padding | Font |
|---|---|---|---|
| `sm` | 32px | `--space-2 --space-3` | `--text-caption` (12px) |
| `md` (default) | 44px | `--space-3 --space-4` | `--text-body-sm` (14px) |
| `lg` | 48px | `--space-3 --space-4` | `--text-body` (16px) |

### Accessibility
- `<label>` associated via `for`/`id` (always present, even if visually hidden).
- `aria-describedby` linking to helper text and error message.
- `aria-invalid="true"` when in error state.
- `aria-required="true"` for required fields.
- Error messages `aria-live="polite"`.
- Enter submits the form (if applicable).

### RTL
- Text alignment: right in RTL, left in LTR.
- Leading/trailing icons flip (leading icon on right in RTL).
- Padding flips (`padding-inline-start`/`padding-inline-end`).

### Usage examples
- `text`: Email (future auth), filename search (History).
- `password`: Auth (future).
- `number`: Size range min/max (Trade Explorer filter).
- `search`: Command palette, History search, Trade Explorer search.
- `with-icon`: Date range picker (calendar icon).
- `with-suffix`: Percentage input ("%").

### Do / Don't

| Do | Don't |
|---|---|
| Always have a label (visible or visually hidden) | Placeholder-as-label |
| Show error inline below input | Error in a toast |
| Validate on blur, not on every keystroke | Validate on every keystroke (annoying) |
| 44px min height on mobile | 32px height on mobile |

---

## 22. Tables

### Purpose
Tables display structured tabular data (trade lists, history lists, comparison data).

### Variants

| Variant | When to use |
|---|---|
| `default` | Standard data table with sortable headers |
| `dense` | Compact rows for high data density (Trade Explorer) |
| `comfortable` | Generous row padding (History) |
| `card-list` | Mobile fallback — renders rows as cards |

### Anatomy

```
┌─────────────────────────────────────────────────────────────────┐
│ Header row (--bg-elevated, --text-caption, --fg-secondary)      │
│ ┌──┬──────────┬────────┬────────┬────────┬────────┬──────────┐ │
│ │# │ Open Time│ Side   │ Size   │ Profit │ Hour   │ Weekday  │ │
│ │  │ ↑↓       │        │ ↑↓     │ ↑↓     │        │          │ │
│ └──┴──────────┴────────┴────────┴────────┴────────┴──────────┘ │
├─────────────────────────────────────────────────────────────────┤
│ Data rows (--bg-elevated, hover: --bg-hover)                    │
│ ┌──┬──────────┬────────┬────────┬────────┬────────┬──────────┐ │
│ │1 │ 2024-... │ Long   │ 0.5    │ +$12   │ 14     │ Tue      │ │
│ └──┴──────────┴────────┴────────┴────────┴────────┴──────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### Tokens consumed
`--bg-elevated`, `--bg-hover`, `--border-subtle`, `--fg-primary`, `--fg-secondary`, `--fg-muted`, `--text-body-sm`, `--text-caption`, `--font-mono` (for numeric columns), `--profit-positive`, `--profit-negative`, `--space-3` (dense), `--space-4` (comfortable).

### States

| State | Visual |
|---|---|
| **default** | `--bg-elevated` rows, `--border-subtle` dividers |
| **row hover** | `--bg-hover` background |
| **row selected** | `--accent-primary` at 8% opacity background |
| **header sortable** | Cursor pointer, sort icon (`ArrowsDownUp`) appears on hover |
| **sorted asc** | `CaretUp` icon, `--accent-primary` color |
| **sorted desc** | `CaretDown` icon, `--accent-primary` color |
| **empty** | EmptyState component in table area |
| **loading** | Skeleton rows (10 row placeholders) |

### Column types

| Type | Alignment | Font | Format |
|---|---|---|---|
| Text | start | `--font-body` | As-is |
| Number | end | `--font-mono` | With thousand separators |
| Currency | end | `--font-mono` | `$1,234.56` or `+$12` / `-$8` |
| Percentage | end | `--font-mono` | `67.5%` |
| Date | start | `--font-mono` | Shamsi (`۱۴۰۴/۰۴/۲۰`) in fa, Gregorian (`2025-07-11`) in en |
| Severity | center | `--font-body` | SeverityBadge component |
| Action | end | — | IconButton or menu |

### Accessibility
- `<table>` with `<thead>`, `<tbody>`, `<th scope>`.
- Sortable headers are `<button>` with `aria-sort="ascending|descending|none"`.
- Row click: `role="button"` on `<tr>` or `<button>` wrapping row content.
- Pagination has `aria-label="صفحه‌بندی"`.
- Mobile card list: each card is a `<button>` for navigation.

### RTL
- Column order reverses (first column on right in RTL).
- Text alignment: text columns right-aligned in RTL, left-aligned in LTR.
- Number columns always end-aligned (which is left in RTL, right in LTR).

### Usage examples
- `dense`: Trade Explorer (1000+ rows).
- `comfortable`: History (desktop), Side Comparison (Edge Map).
- `card-list`: Trade Explorer and History on mobile.

### Do / Don't

| Do | Don't |
|---|---|
| Mono font for numeric columns | Body font for numbers (misaligns) |
| Sortable headers with `aria-sort` | Sortable headers without ARIA |
| Card list on mobile | Horizontal scroll on mobile |
| Sticky header for long tables | Header scrolls away |

---

## 23. Dropdowns / Select

### Purpose
Dropdowns let users select one option from a list. (For multi-select, use a Combobox pattern — not in Phase 1 core.)

### Variants

| Variant | When to use |
|---|---|
| `default` | Standard select (3–10 options) |
| `searchable` | Many options (10+) — type to filter |
| `segmented` | 2–4 mutually exclusive options (SegmentedControl) |

### Anatomy (default)

```
┌─── radius-md, like an Input ────────┐
│  Selected option            [v]     │
└──────────────────────────────────────┘

When open (popover, elevation-4):
┌─── radius-lg, elevation-4 ──────────┐
│  Option 1                           │ ← hover: --bg-hover
│  Option 2 (selected, --accent-primary bg at 8%) │
│  Option 3                           │
└──────────────────────────────────────┘
```

### Tokens consumed
`--bg-surface`, `--bg-elevated`, `--bg-hover`, `--border-strong`, `--accent-primary`, `--fg-primary`, `--fg-secondary`, `--radius-md`, `--radius-lg`, `--elevation-4`, `--text-body-sm`, `--space-3`, `--space-4`, `--duration-moderate`, `--ease-out`.

### States

| State | Visual |
|---|---|
| **default** | Like Input default |
| **hover** | Border darkens |
| **focus** | `--border-focus` + `--shadow-focus` ring |
| **open** | Popover appears below (or above if no space), 200ms fade+slide |
| **option hover** | `--bg-hover` |
| **option selected** | `--accent-primary` at 8% bg + check icon on end |
| **disabled** | 50% opacity |
| **error** | `--severity-critical` border |

### Accessibility
- `<select>` element for default (native, most accessible).
- Custom dropdown: `role="listbox"` + `role="option"` + `aria-selected`.
- Keyboard: Enter/Space to open, Arrow keys to navigate, Enter to select, Esc to close.
- Focus trap inside popover while open.
- Selected option announced: `aria-activedescendant`.

### RTL
- Dropdown icon (`CaretDown`) on left in RTL (end side).
- Popover aligns to start edge of trigger.
- Option text right-aligned in RTL.

### Usage examples
- `default`: LLM provider selector (Upload), sort dropdown (Trade Explorer, History).
- `searchable`: Future — large option sets (e.g., broker type).
- `segmented`: Theme toggle (Light/Dark/System), filter toggles (All/Win/Loss).

### Do / Don't

| Do | Don't |
|---|---|
| Native `<select>` when possible (best a11y) | Custom dropdown for 3 options |
| `searchable` for 10+ options | `searchable` for 3 options (overkill) |
| Selected option clearly marked | No selected indicator |

---

## 24. Tabs

### Purpose
Tabs switch between related views within the same page.

### Variants

| Variant | When to use |
|---|---|
| `underline` | Primary in-page navigation (Report sections) |
| `pill` | Secondary, fewer options (2–4) |
| `segmented` | Mutually exclusive toggle (same as SegmentedControl) |

### Anatomy (underline)

```
  Tab 1    Tab 2 (active)    Tab 3
═════════════════════════════════════
         (2px underline, --accent-primary)

Content area below
```

### Tokens consumed
`--bg-elevated` or `transparent`, `--fg-primary` (active), `--fg-secondary` (inactive), `--fg-muted` (disabled), `--accent-primary` (active underline), `--border-subtle` (divider), `--text-body-sm`, `--space-3`, `--space-4`, `--duration-normal`, `--ease-out`.

### States

| State | Underline tab | Pill tab |
|---|---|---|
| **default** | `--fg-secondary` text, no underline | `--fg-secondary` text, transparent bg |
| **hover** | `--fg-primary` text, subtle underline appears | `--bg-hover` bg |
| **active** | `--fg-primary` text, 2px `--accent-primary` underline | `--accent-primary` at 12% bg, `--accent-primary` text |
| **disabled** | `--fg-muted` text, no underline, `cursor-not-allowed` | same |
| **focus** | 3px `--shadow-focus` ring | 3px `--shadow-focus` ring |

### Accessibility
- `role="tablist"` on container.
- `role="tab"` on each tab, `aria-selected="true|false"`, `aria-controls="panel-id"`.
- `role="tabpanel"` on content area, `aria-labelledby="tab-id"`.
- Keyboard: Arrow keys to move between tabs, Enter/Space to activate.
- Focus ring visible on tab.

### RTL
- Tab order reverses (first tab on right in RTL).
- Underline spans full width of tab (no direction).

### Usage examples
- `underline`: Report section navigator, Settings sections.
- `pill`: LLM provider (Upload), severity filter (Diagnosis).
- `segmented`: Theme toggle, density toggle, outcome filter (Trade Explorer).

### Do / Don't

| Do | Don't |
|---|---|
| 2–7 tabs per tablist | 1 tab (use a heading instead) or 8+ (use a dropdown) |
| Clear active state | Subtle active state |
| Same-width tabs when labels are similar | Random widths |

---

## 25. Charts

### Purpose
Charts visualize data in ways tables can't (trends, distributions, comparisons over time).

### Variants (Phase 2 §3.11 — 6 chart types)

| Chart | Type | Library |
|---|---|---|
| Equity Curve | Area | Recharts `<AreaChart>` |
| Drawdown | Area (negative) | Recharts `<AreaChart>` |
| P&L Distribution | Histogram | Recharts `<BarChart>` |
| Hourly Heatmap | Heatmap (custom SVG) | Custom |
| Weekday Breakdown | Bar | Recharts `<BarChart>` |
| Win/Loss Streaks | Bar (green/red) | Recharts `<BarChart>` |
| Score Radar (Behavioral desktop) | Radar | Recharts `<RadarChart>` |
| Trend Line (Trends) | Line | Recharts `<LineChart>` |

### Anatomy

```
┌─── radius-lg, --bg-elevated, --elevation-2 ────────┐
│  ← padding: --space-4 --space-6 --→                 │
│                                                      │
│  Chart Title (--text-h3)          [actions?]         │
│  Caption (--text-caption, --fg-secondary)            │
│  ────────────────────────────────────────────────    │
│                                                      │
│  ┌──────────────────────────────────────────────┐   │
│  │                                                │   │
│  │           Chart area (Recharts)                │   │
│  │                                                │   │
│  └──────────────────────────────────────────────┘   │
│                                                      │
│  Legend (--text-caption, below chart)                │
│  Key insight callout (optional)                      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### Tokens consumed
`--bg-elevated`, `--elevation-2`, `--radius-lg`, `--chart-primary`, `--chart-secondary`, `--chart-positive`, `--chart-negative`, `--chart-neutral`, `--chart-grid`, `--chart-axis`, `--text-h3`, `--text-caption`, `--fg-secondary`, `--font-mono` (axis labels, tooltips).

### States

| State | Visual |
|---|---|
| **default** | Chart rendered, axes visible |
| **loading** | Skeleton: axes + pulsing placeholder area |
| **hover** (data point) | Tooltip appears (100ms fade), data point enlarges to 4px circle |
| **empty** | EmptyState illustration inside chart area |
| **error** | Error message inside chart area + "view raw data" link |

### Chart-specific styling

- **Grid:** 1px dashed `--chart-grid`, subtle.
- **Axes:** `--chart-axis` color, `--text-caption` size, mono font for numbers.
- **Data points:** Hidden by default, 4px circle on hover.
- **Tooltips:** `--elevation-4`, `--bg-elevated`, `--text-body-sm`, mono numbers, 100ms fade.
- **Legend:** Below chart, `--text-caption`, color swatch + label.
- **Entrance animation:** 400ms grow-from-baseline (frozen if reduced-motion).

### Accessibility
- `aria-label` summarizing data (e.g., «منحنی سرمایه: ۱ ژانویه تا ۳۱ مارچ، ۱۰٬۰۰۰ دلار به ۱۲٬۵۰۰ دلار»).
- Visually-hidden `<table>` with raw data.
- Tooltip content `aria-live="polite"`.
- Color + line style (solid/dashed) + shape markers differentiate series.

### RTL
- x-axis reversed (earliest right, latest left) via Recharts `reversed` prop.
- Legend order reverses.
- Tooltip position mirrors.

### Usage examples
- Charts page (all 6 types), Trends page (Line), Behavioral desktop (Radar), Dashboard (none — Dashboard is numbers only).

### Do / Don't

| Do | Don't |
|---|---|
| One question per chart | Multi-series clutter |
| Mono font for axis numbers | Body font (misaligns) |
| Visually-hidden data table for a11y | Chart without text alternative |
| 400ms entrance animation | 2s entrance animation (too slow) |

---

## 26. Dialogs / Modals

### Purpose
Modals focus user attention on a single task or message, overlaying the page.

### Variants

| Variant | When to use |
|---|---|
| `default` | Centered dialog (desktop), bottom sheet (mobile) |
| `wide` | Confirmations with lots of content |
| `sheet` | Mobile bottom sheet (always on `< md`) |
| `drawer` | Side panel (History drawer, Trade detail) |

### Anatomy (default, desktop)

```
        ┌─── Scrim (--bg-overlay, 72% dark / 48% light) ────────┐
        │                                                         │
        │      ┌─── radius-xl, --bg-elevated, --elevation-5 ──┐  │
        │      │                                                  │  │
        │      │  Title (--text-h3)                    [X close] │  │
        │      │  ──────────────────────────────────────────── │  │
        │      │                                                  │  │
        │      │  Content                                         │  │
        │      │                                                  │  │
        │      │  ──────────────────────────────────────────── │  │
        │      │  [Cancel]                              [Confirm] │  │
        │      │                                                  │  │
        │      └──────────────────────────────────────────────────┘  │
        │                                                         │
        └─────────────────────────────────────────────────────────┘
```

### Anatomy (mobile — bottom sheet)

```
┌─── Screen ───────────────────────┐
│                                    │
│  (page content, dimmed)            │
│                                    │
├─── Scrim ─────────────────────────┤
│ ───  (drag handle, 36px)         ─│ ← swipe down to dismiss
│  Title (--text-h3)         [X]    │
│  ─────────────────────────────────│
│  Content                           │
│                                    │
│  [Cancel]            [Confirm]     │
│  ← safe-area-inset-bottom →        │
└────────────────────────────────────┘
```

### Tokens consumed
`--bg-overlay`, `--bg-elevated`, `--elevation-5`, `--radius-xl`, `--border-subtle`, `--fg-primary`, `--fg-secondary`, `--text-h3`, `--text-body`, `--space-4`, `--space-6`, `--duration-moderate` (open), `--duration-slow` (close), `--ease-out` (open), `--ease-in` (close).

### States

| State | Visual |
|---|---|
| **closed** | Not visible |
| **opening** | Scrim fades in (150ms), content scales 0.95→1 + fades in (200ms Expo.out) |
| **open** | Full visibility, focus trapped inside |
| **closing** | Content scales 1→0.95 + fades out (150ms Expo.in), scrim fades out (150ms) |
| **reduced-motion** | Instant appear/disappear |

### Accessibility
- `role="dialog"` + `aria-modal="true"` + `aria-labelledby` (title).
- Focus trap: Tab cycles within modal; focus returns to trigger on close.
- `Esc` closes.
- `aria-describedby` for description if present.
- Scrim click closes (but not if `persistent` prop set — e.g., mandatory confirmation).
- Screen reader announces title on open.

### RTL
- Drawer slides from right in RTL (left in LTR).
- Close button position: top-left in RTL (mirror of top-right in LTR).
- Button order in footer: Cancel on left, Confirm on right in LTR; reverses in RTL.

### Usage examples
- `default`: Delete confirmation (History), Reset data confirmation (Settings).
- `wide`: Supported formats help (Upload).
- `sheet`: All modals on mobile (`< md`).
- `drawer`: History quick-switch (top bar badge click), Trade detail (Trade Explorer).

### Do / Don't

| Do | Don't |
|---|---|
| One modal at a time | Stacked modals |
| Clear title + action buttons | Modal without clear purpose |
| Esc + scrim click to close | Forced modal (no escape) unless mandatory |
| Bottom sheet on mobile | Centered modal on mobile (hard to reach) |

---

## 27. Badges

### Purpose
Badges convey status, category, or count at a glance.

### Variants

| Variant | When to use |
|---|---|
| `severity` | Low/Medium/High/Critical (engine severity) |
| `status` | Info/Success/Warning/Error |
| `count` | Number badge (e.g., "3 warnings", "8 evidence") |
| `priority` | P1/P2/P3 (recommendation priority) |
| `neutral` | Generic label |

### Anatomy

```
Severity:   [• Critical]    ← dot + text, severity color
Status:     [✓ Success]     ← icon + text, status color
Count:      [3]              ← number only, neutral bg
Priority:   [P1]             ← text only, priority color
Neutral:    [Sample]         ← text only, neutral bg
```

### Tokens consumed
`--severity-*`, `--status-*`, `--neutral-200`/`--neutral-300` (bg), `--fg-primary`, `--fg-secondary`, `--radius-sm`, `--text-caption`, `--font-body`.

### States
Badges are non-interactive (static). No hover/focus states. If clickable, use a Button or Chip component instead.

### Sizes

| Size | Height | Padding | Font |
|---|---|---|---|
| `sm` | 20px | `--space-1 --space-2` | 11px |
| `md` (default) | 24px | `--space-1 --space-2` | `--text-caption` (12px) |

### Accessibility
- `role="status"` or `role="text"`.
- `aria-label` if icon-only (rare).
- Color + text + icon (never color alone).

### RTL
- No RTL-specific behavior (text + icon, layout-agnostic).

### Usage examples
- `severity`: Diagnosis cards, Evidence cards, Behavioral Analysis context rows.
- `status`: AI Coaching badge («توضیح الگوریتمی» / «توضیح هوش مصنوعی»).
- `count`: History item count, Evidence count.
- `priority`: Coaching recommendation cards (P1/P2/P3).
- `neutral`: Sample Report badge («این یک تحلیل نمونه است»).

### Do / Don't

| Do | Don't |
|---|---|
| Text + icon + color | Color only |
| 2–4 words max | Full sentences |
| Consistent shape (all pill or all rounded-rect) | Mixed shapes |

---

## 28. Notifications / Toasts

### Purpose
Toasts provide transient feedback after an action (success, error, warning, info).

### Variants

| Variant | When to use |
|---|---|
| `success` | Action completed (download finished, analysis complete) |
| `error` | Action failed (network error, validation error) |
| `warning` | Non-blocking issue (data quality warning) |
| `info` | Informational (theme changed, language changed) |

### Anatomy

```
┌─── radius-lg, --bg-elevated, --elevation-4 ────────────┐
│  ← padding: --space-3 --space-4 --→                     │
│                                                          │
│  [icon]  Message text                          [X close] │
│                                                          │
└──────────────────────────────────────────────────────────┘
   ← positioned: top-right (LTR) / top-left (RTL), --space-4 from edge ──→
```

### Tokens consumed
`--bg-elevated`, `--elevation-4`, `--radius-lg`, `--status-success`, `--status-error`, `--status-warning`, `--status-info`, `--fg-primary`, `--text-body-sm`, `--space-3`, `--space-4`, `--duration-moderate` (enter), `--duration-slow` (exit), `--ease-out` (enter), `--ease-in` (exit).

### States

| State | Visual |
|---|---|
| **entering** | Slide-in from top edge (250ms Expo.out) |
| **visible** | Full opacity, auto-dismiss after 4s (errors: 6s) |
| **hover** | Auto-dismiss paused, close button highlighted |
| **exiting** | Slide-out + fade (200ms Expo.in) |

### Accessibility
- `role="status"` for success/info, `role="alert"` for error/warning.
- `aria-live="polite"` (success/info), `aria-live="assertive"` (error/warning).
- Auto-dismiss: announced once on enter; not re-announced on hover.
- Close button: `aria-label="بستن"`.
- Never auto-dismiss errors until user has seen them (use longer timeout or require manual close).

### RTL
- Position: top-left in RTL (mirror of top-right in LTR).
- Slide-in direction: from left in RTL.
- Icon on right in RTL (start side).

### Usage examples
- `success`: «گزارش PDF دانلود شد», «تحلیل کامل شد», «انجام شد» (Coaching mark-as-done).
- `error`: «حذف ناموفق بود. دوباره تلاش کنید», «اتصال برقرار نشد».
- `warning`: «۳ هشدار کیفیت داده» (Dashboard, with link).
- `info`: «تم تغییر کرد», «زبان تغییر کرد».

### Do / Don't

| Do | Don't |
|---|---|
| 1 toast at a time (stack max 3) | 10 toasts stacked |
| Auto-dismiss after 4s (6s for errors) | Persistent toasts that never dismiss |
| Clear icon + message | Toast without context |
| `aria-live` for screen readers | Silent toasts |

---

## 29. Tooltips

### Purpose
Tooltips provide supplementary information on hover/focus without cluttering the UI.

### Variants

| Variant | When to use |
|---|---|
| `default` | Brief explanation (1–2 sentences) |
| `rich` | With icon, title, and body (for LLM provider explanation) |

### Anatomy

```
                    ┌─── radius-md, --bg-elevated, --elevation-4 ────┐
                    │  ← padding: --space-2 --space-3 --→              │
                    │                                                  │
                    │  [icon?]  Tooltip text (--text-caption)          │
                    │                                                  │
                    └──────────────────────────────────────────────────┘
                              ▲ (arrow, 6px)
                    (positioned above/below/left/right of trigger)
```

### Tokens consumed
`--bg-elevated`, `--elevation-4`, `--radius-md`, `--fg-primary`, `--text-caption`, `--border-subtle`, `--space-2`, `--space-3`, `--duration-fast`, `--ease-out`.

### States

| State | Visual |
|---|---|
| **closed** | Not visible |
| **opening** | Fade in + slight scale 0.95→1 (100ms) |
| **open** | Full opacity, pointer-events: none (doesn't block hover) |
| **closing** | Fade out (100ms) |

### Positioning
- Default: above trigger.
- If no space above: below.
- If no space above/below: right (LTR) / left (RTL).
- Arrow points to trigger.
- 8px gap between tooltip and trigger.

### Timing
- Show: 500ms hover delay (avoid flicker on quick mouse-overs).
- Hide: 100ms delay after mouse leave (avoid gap when moving to tooltip).
- On focus (keyboard): show immediately (no delay).

### Accessibility
- `role="tooltip"`.
- Trigger has `aria-describedby` pointing to tooltip.
- Tooltip content available to screen readers (even when visually hidden).
- Never put critical information in a tooltip (it's supplementary).
- Tooltip disappears on `Esc`.

### RTL
- Position mirrors (left↔right).
- Arrow direction mirrors.

### Usage examples
- `default`: Severity threshold explanation (Behavioral), confidence score explanation (Diagnosis), LLM provider tradeoff (Upload).
- `rich`: Future — onboarding tooltips with icon + title + body.

### Do / Don't

| Do | Don't |
|---|---|
| Brief (1–2 sentences) | Paragraph-length tooltips |
| 500ms show delay | Instant show (flicker) |
| Supplementary info only | Critical info only in tooltip |
| Dismissible on Esc | Persistent tooltips |

---

## 30. Search / Command Palette

### Purpose
The Command Palette (Cmd/Ctrl+K) is the power-user navigation surface — fuzzy search across pages, recent analyses, and actions.

### Anatomy

```
        ┌─── Scrim (--bg-overlay) ────────────────────────────┐
        │                                                      │
        │   ┌─── radius-xl, --bg-elevated, --elevation-5 ──┐   │
        │   │  ← max-width: 640px, centered top ─→          │   │
        │   │                                                │   │
        │   │  [🔍]  Search...                              │   │
        │   │  ──────────────────────────────────────────── │   │
        │   │                                                │   │
        │   │  صفحات (Pages)                                 │   │
        │   │  → Dashboard                                   │   │
        │   │  → Behavioral Analysis                         │   │
        │   │  ...                                           │   │
        │   │                                                │   │
        │   │  تحلیل‌های اخیر (Recent Analyses)               │   │
        │   │  → trades_jan.csv · 2024-01-15                 │   │
        │   │  ...                                           │   │
        │   │                                                │   │
        │   │  اقدامات (Actions)                             │   │
        │   │  → آپلود فایل جدید                             │   │
        │   │  ...                                           │   │
        │   │                                                │   │
        │   │  ──────────────────────────────────────────── │   │
        │   │  ↑↓ navigate   ↵ select   esc close            │   │
        │   └────────────────────────────────────────────────┘   │
        │                                                      │
        └──────────────────────────────────────────────────────┘
```

### Tokens consumed
`--bg-overlay`, `--bg-elevated`, `--bg-hover`, `--elevation-5`, `--radius-xl`, `--accent-primary`, `--fg-primary`, `--fg-secondary`, `--fg-muted`, `--text-body`, `--text-body-sm`, `--text-caption`, `--space-3`, `--space-4`, `--duration-moderate`, `--ease-out`.

### States

| State | Visual |
|---|---|
| **closed** | Not visible |
| **opening** | Scrim fade (150ms) + palette slide-down + fade (200ms) |
| **open** | Input autofocus, first result highlighted |
| **typing** | Results filter live (debounced 100ms) |
| **navigating** | ↑↓ moves highlight, scroll follows |
| **selecting** | Enter navigates/closes palette |
| **closing** | Slide-up + fade (200ms) + scrim fade (150ms) |

### Result groups

| Group | Items | Order |
|---|---|---|
| صفحات (Pages) | All 14 build pages + Settings | By relevance (fuzzy match score) |
| تحلیل‌های اخیر (Recent Analyses) | Last 5 from History | Most recent first |
| اقدامات (Actions) | Upload, Download PDF, Download HTML, Toggle theme, Toggle language, Reset data | By relevance |

### Accessibility
- `role="dialog"` + `aria-modal="true"`.
- Input has `aria-label="جستجوی دستور"`.
- Results: `role="listbox"`, each result `role="option"` + `aria-selected`.
- `aria-activedescendant` tracks highlighted result.
- Keyboard: `Cmd/Ctrl+K` opens, `Esc` closes, `↑↓` navigate, `Enter` selects.
- Focus trap inside palette.
- Screen reader announces highlighted result.

### RTL
- Input text right-aligned.
- Result icons on right (start side).
- Keyboard shortcuts hint at bottom: same (↑↓ ↵ esc are direction-agnostic).

### Usage examples
- Global: `Cmd/Ctrl+K` from anywhere in the app.
- Mobile: accessible via "More" sheet button (no keyboard shortcut on touch devices).

### Do / Don't

| Do | Don't |
|---|---|
| Fuzzy search (typo-tolerant) | Exact match only |
| Group results clearly | Flat list of 50 items |
| Keyboard-first, mouse-supported | Mouse-only |
| Debounced filtering (100ms) | Filter on every keystroke (jank) |

---

## 31. Pagination

### Purpose
Pagination splits long lists across multiple pages.

### Variants

| Variant | When to use |
|---|---|
| `default` | Desktop: page numbers + prev/next |
| `compact` | Mobile: prev/next + "Page X of Y" |

### Anatomy (default)

```
  ← Previous  │  1  2  [3]  4  5  …  10  │  Next →    Page size: [50 ▾]
                            ↑ active
```

### Anatomy (compact / mobile)

```
  ← Previous        Page 3 of 10        Next →
```

### Tokens consumed
`--bg-elevated`, `--bg-hover`, `--accent-primary`, `--fg-primary`, `--fg-secondary`, `--fg-muted`, `--radius-md`, `--text-body-sm`, `--text-caption`, `--space-2`, `--space-3`, `--border-subtle`.

### States

| State | Visual |
|---|---|
| **default** | `--bg-elevated`, `--fg-secondary` text |
| **hover** | `--bg-hover` |
| **active** | `--accent-primary` bg, `--fg-on-primary` text |
| **disabled** (prev on page 1) | 50% opacity, `cursor-not-allowed` |
| **focus** | 3px `--shadow-focus` ring |

### Accessibility
- `nav` with `aria-label="صفحه‌بندی"`.
- Current page: `aria-current="page"`.
- Prev/Next: `aria-label="صفحه قبلی"` / `aria-label="صفحه بعدی"`.
- Disabled: `aria-disabled="true"`.
- Keyboard: Tab to navigate, Enter to activate.

### RTL
- Prev/Next swap positions (Next on left in RTL).
- Arrows mirror.
- Page numbers read right-to-left.

### Usage examples
- `default`: History (desktop), Trade Explorer (desktop).
- `compact`: History (mobile), Trade Explorer (mobile).

### Do / Don't

| Do | Don't |
|---|---|
| Show "Page X of Y" | Just "Next" button (no context) |
| Disable prev on page 1 (don't hide) | Hide prev on page 1 (confusing) |
| 5–7 page numbers max (with ellipsis) | All 50 page numbers |

---

## 32. Breadcrumbs

### Purpose
Breadcrumbs show the user's location in the page hierarchy and let them navigate up.

### Anatomy

```
  Dashboard  ›  Behavioral Analysis
               ↑ current (non-clickable)
```

### Tokens consumed
`--fg-secondary`, `--fg-muted`, `--accent-primary` (link hover), `--text-body-sm`, `--space-1`, `--space-2`.

### States

| State | Visual |
|---|---|
| **default** (link) | `--fg-secondary` text |
| **hover** (link) | `--accent-primary` text, underline |
| **current** (last) | `--fg-primary` text, not clickable |
| **focus** (link) | 3px `--shadow-focus` ring |

### Accessibility
- `nav` with `aria-label="مسیر"`.
- `ol` with `li` for each crumb.
- Current page: `aria-current="page"`.
- Separator (`›` or `/`): `aria-hidden="true"`.

### RTL
- Separator mirrors: `‹` in RTL (pointing left = "back" in RTL reading direction).
- Crumb order reverses (Dashboard on right in RTL).

### Usage examples
- Every app page (Dashboard › Behavioral, Dashboard › Diagnosis › Coaching, etc.).
- Settings: just "Settings" (no parent).

### Do / Don't

| Do | Don't |
|---|---|
| Show 2–4 levels | 6+ levels (use a different nav) |
| Current page non-clickable | All crumbs clickable (confusing) |
| `›` separator | `>` or `→` (less elegant) |

---

## 33. Progress Indicators

### Purpose
Progress indicators show that a task is in progress, either with known duration (determinate) or unknown (indeterminate).

### Variants

| Variant | When to use |
|---|---|
| `linear-determinate` | Known progress (file upload, 0–100%) |
| `linear-indeterminate` | Unknown progress (analysis running) |
| `circular-determinate` | Known progress in compact space (ScoreGauge fill) |
| `circular-indeterminate` | Unknown progress in compact space (button loading spinner) |
| `stepper` | Multi-stage progress (Analysis Progress 6 stages) |

### Anatomy (linear)

```
Determinate:   ████████████░░░░░░░░░  60%
Indeterminate: ◄══════════════════════►  (animated stripe)
```

### Anatomy (stepper)

```
   ✓     ✓     ●     ○     ○     ○
  ─────────────────────────────────
   1     2     3     4     5     6
 Reading Validating Analyzing Scoring Diagnosing Coaching
```

### Tokens consumed
`--accent-primary`, `--bg-surface`, `--bg-hover`, `--status-success`, `--fg-primary`, `--fg-secondary`, `--text-caption`, `--font-mono`, `--radius-full`, `--duration-normal`, `--ease-out`.

### States

| State | Visual |
|---|---|
| **determinate** | Fill from 0% to value, `--accent-primary` |
| **indeterminate** | Animated stripe, `--accent-primary` |
| **stepper complete** | Green check (`--status-success`) |
| **stepper current** | Pulsing dot, `--accent-primary` |
| **stepper upcoming** | Empty circle, `--fg-muted` |
| **reduced-motion** | Indeterminate becomes static grey bar; stepper dots static |

### Accessibility
- `role="progressbar"`.
- Determinate: `aria-valuenow`, `aria-valuemin`, `aria-valuemax`, `aria-valuetext`.
- Indeterminate: no aria-value* attributes.
- Stepper: `role="list"`, each step `role="listitem"` with `aria-current="step"` on current.
- Screen reader announces progress changes (sparingly, not every 1%).

### RTL
- Linear: fill from right in RTL.
- Stepper: step order reverses (step 1 on right).

### Usage examples
- `linear-determinate`: File upload progress (Upload page).
- `linear-indeterminate`: Analysis running (Analysis Progress page).
- `circular-determinate`: ScoreGauge fill (Dashboard, Behavioral).
- `circular-indeterminate`: Button loading spinner, inline loading.
- `stepper`: Analysis Progress 6 stages.

### Do / Don't

| Do | Don't |
|---|---|
| Determinate when you know progress | Indeterminate when you could know |
| Stepper for multi-stage | Single progress bar for 6 stages |
| `aria-valuetext` with description | Just `aria-valuenow="60"` (meaningless) |
| Reduced-motion: static, not animated | Reduced-motion: still animating |

---

## 34. Skeleton Loaders

### Purpose
Skeletons show the shape of upcoming content during loading, preventing layout shift.

### Variants

| Variant | When to use |
|---|---|
| `text` | Loading text content (paragraphs, lines) |
| `card` | Loading card content (Dashboard cards, History cards) |
| `chart` | Loading chart (axes + placeholder area) |
| `gauge` | Loading ScoreGauge (circle placeholder) |
| `table-row` | Loading table rows |
| `avatar` | Loading avatar/icon |

### Anatomy

```
Text:    ░░░░░░░░░░░░░░░░░░  (grey bars, pulsing)
         ░░░░░░░░░░░░░░░░

Card:    ┌───────────────────┐
         │ ░░░░░░░░░░░░░░░░ │  (title bar)
         │ ░░░░░░░░░░░░░    │  (content lines)
         │ ░░░░░░░░░░░      │
         └───────────────────┘

Chart:   ┌───────────────────┐
         │     ┄┄┄┄┄┄┄┄┄┄    │  (axes visible, area pulsing)
         │   ┄┄┄┄┄┄┄┄┄┄┄┄    │
         └───────────────────┘
```

### Tokens consumed
`--neutral-300` (dark) / `--neutral-200` (light) for skeleton base, `--neutral-400` (dark) / `--neutral-300` (light) for pulse highlight, `--radius-md`, `--radius-lg`.

### States

| State | Visual |
|---|---|
| **default** | Static grey block |
| **pulsing** (default motion) | Opacity 0.5 → 1.0 → 0.5 over 1.5s, infinite |
| **reduced-motion** | Static grey block, no pulse |

### Pulse animation

```css
@keyframes skeleton-pulse {
  0%, 100% { opacity: 0.5; }
  50% { opacity: 1; }
}
.skeleton {
  animation: skeleton-pulse 1.5s ease-in-out infinite;
}
@media (prefers-reduced-motion: reduce) {
  .skeleton { animation: none; }
}
```

### Accessibility
- `aria-hidden="true"` (skeleton is decorative; screen readers should skip it).
- `aria-busy="true"` on the container that's loading.
- Live region (`aria-live="polite"`) on container announces when content arrives.

### RTL
- No RTL-specific behavior (shapes are direction-agnostic).

### Usage examples
- `text`: AI Coaching narrative, Reality Check (Coaching page).
- `card`: Dashboard 4 emotional-center cards, History item cards, Evidence cards.
- `chart`: All charts on Charts page, Trends chart.
- `gauge`: Dashboard Overall Health card, Behavioral score gauges.
- `table-row`: Trade Explorer table, History table (desktop).
- `avatar`: Trader DNA hero (while archetype loads).

### Do / Don't

| Do | Don't |
|---|---|
| Match final shape exactly | Generic "loading..." spinner |
| Pulse animation (1.5s) | Fast pulse (0.5s — seizure risk) |
| `aria-hidden` + `aria-busy` | Just visual skeleton |
| Reduced-motion: static | Reduced-motion: still pulsing |

---

## 35. Empty States

### Purpose
Empty states guide users when no content exists, with a clear path forward.

### Anatomy

```
┌──────────────────────────────────────────┐
│                                          │
│              [Illustration]              │  ← 120×120, geometric line style
│                                          │
│         Headline (--text-h3)             │  ← one sentence, the situation
│      Description (--text-body-sm)        │  ← one sentence, what to do
│                                          │
│            [Primary CTA]                 │  ← one action
│                                          │
└──────────────────────────────────────────┘
```

### Variants

| Variant | When to use |
|---|---|
| `default` | No data yet (no analyses, no results) |
| `error` | Something went wrong (fetch failed) |
| `future-gated` | Feature locked behind upgrade (future) |
| `search` | Search returned no results |

### Tokens consumed
`--bg-elevated`, `--fg-primary`, `--fg-secondary`, `--text-h3`, `--text-body-sm`, `--accent-cta` (CTA), `--radius-lg`, `--space-6`, `--space-8`.

### States
Empty states are static (no hover/focus). The CTA inside has its own states (Button).

### Accessibility
- `role="status"` (announces to screen readers that there's no content).
- Illustration: `aria-hidden="true"` (decorative).
- Headline + description: clear text alternative.
- CTA: accessible Button.

### RTL
- Illustration centered (no direction).
- Text centered (no direction).
- CTA centered (no direction).

### Usage examples
- `default`: History (no analyses), Trends (<2 analyses), Trade Explorer (no trades).
- `error`: Any page fetch failed.
- `future-gated`: Settings future sections, Trends (Anonymous tier).
- `search`: Trade Explorer filter returns nothing.

### Standard empty state messages

| Context | Headline | Description | CTA |
|---|---|---|---|
| History (no analyses) | «هنوز تحلیلی انجام نداده‌اید» | «اولین فایل معاملات خود را آپلود کنید تا تحلیل شروع شود.» | «شروع تحلیل» → /upload |
| Trends (<2 analyses) | «برای دیدن روند، حداقل ۲ تحلیل لازم است» | «بعد از تحلیل دوم، روند تغییرات امتیازهای شما قابل مشاهده خواهد بود.» | «تحلیل جدید» → /upload |
| Trade Explorer (no filter results) | «هیچ معامله‌ای با این فیلترها یافت نشد» | «فیلترها را تنظیم کنید یا پاک کنید تا معاملات دوباره نمایش داده شوند.» | «پاک کردن فیلترها» |
| Generic error | «خطایی رخ داد» | «لطفاً دوباره تلاش کنید.» | «تلاش مجدد» |
| Network error | «اتصال به سرور برقرار نشد» | «اینترنت خود را بررسی کنید و دوباره تلاش کنید.» | «تلاش مجدد» |
| 404 (analysis not found) | «تحلیل یافت نشد» | «این تحلیل ممکن است حذف شده باشد یا هرگز وجود نداشته باشد.» | «بازگشت به تاریخچه» → /history |

### Do / Don't

| Do | Don't |
|---|---|
| Illustration + headline + description + CTA | Just "No data" text |
| One clear CTA | Multiple competing CTAs |
| Calm, non-judgmental tone | Alarming tone ("Error! Failed!") |
| Custom illustration per context | Generic stock illustration |

---

## 36. Error States

### Purpose
Error states help users recover from problems. Every error is **actionable** — never just reported.

### Anatomy (inline error)

```
┌──────────────────────────────────────────┐
│  [⚠ icon]  Error headline (--text-body-sm)│  ← what went wrong (1 line)
│           Why it happened (--text-caption)│  ← why (1 line, optional)
│           [Retry] [Alternative]           │  ← what to do (CTAs)
└──────────────────────────────────────────┘
```

### Anatomy (full-page error)

```
┌──────────────────────────────────────────┐
│                                          │
│              [Illustration]              │  ← error-generic or error-network
│                                          │
│         Error headline (--text-h3)       │
│      Description (--text-body-sm)        │
│                                          │
│         [Retry] [Go back]                │
│                                          │
└──────────────────────────────────────────┘
```

### Variants

| Variant | When to use |
|---|---|
| `inline` | Within a component (input validation, chart render fail) |
| `card` | Within a page section (Dashboard cards fail to load) |
| `full-page` | Entire page fails to load |
| `toast` | Transient action error (already covered in §28) |

### Tokens consumed
`--severity-critical`, `--bg-elevated`, `--fg-primary`, `--fg-secondary`, `--text-h3`, `--text-body-sm`, `--text-caption`, `--radius-lg`, `--radius-xl`, `--space-4`, `--space-6`, `--accent-primary` (Retry button).

### Error message guidelines

| Principle | Example |
|---|---|
| **Specific** | «ستون سود/زیان در فایل شما پیدا نشد» (not «خطا») |
| **Actionable** | «مطمئن شوید خروجی بروکر شامل ستون Profit است» |
| **Non-judgmental** | «فایل پشتیبانی نمی‌شود» (not «فایل اشتباه است») |
| **Recoverable** | Always provide a CTA (retry, go back, fix) |
| **No jargon** | «اتصال برقرار نشد» (not «ECONNREFUSED») |

### Standard error scenarios (Phase 2 §9.5 E1–E18)

| Code | Error | Headline | CTA |
|---|---|---|---|
| 413 | File too large | «حجم فایل بیش از حد مجاز است (۲۵ مگابایت)» | «انتخاب فایل دیگر» |
| 422 | Invalid data | (engine message, e.g., «ستون سود/زیان پیدا نشد») | «فرمت‌های پشتیبانی‌شده» |
| 404 | Not found | «تحلیل یافت نشد» | «بازگشت به تاریخچه» |
| 429 | Rate limited | «تعداد درخواست‌ها بیش از حد مجاز است» | (countdown + auto-retry) |
| 500 | Server error | «خطای داخلی سرور. لطفاً بعداً تلاش کنید.» | «تلاش مجدد» |
| Network | Connection failed | «اتصال به سرور برقرار نشد» | «تلاش مجدد» |
| Timeout | Request timed out | «درخواست بیش از حد طول کشید» | «تلاش مجدد» |

### Accessibility
- `role="alert"` for important errors.
- `aria-live="assertive"` for error messages that appear dynamically.
- Error icon: `aria-hidden="true"` (text conveys meaning).
- Retry button: accessible Button.
- Color (red) + icon + text — never color alone.

### RTL
- Icon on right in RTL (start side).
- Button order: Retry on left (end) in RTL.

### Usage examples
- `inline`: Input validation (Upload), chart render fail (Charts).
- `card`: Dashboard cards fail (replaces the 4 emotional-center cards).
- `full-page`: Page fetch fails (any app page).
- `toast`: Action errors (delete failed, download failed).

### Do / Don't

| Do | Don't |
|---|---|
| Specific + actionable message | Generic "Something went wrong" |
| Always provide a CTA | Error without recovery path |
| `role="alert"` for screen readers | Silent errors |
| Calm tone | Alarming "Error!!!" tone |

---

# Part D — Appendices

---

## 37. Token Naming Convention

### 37.1 Pattern

`--{category}-{property}-{variant?}-{state?}`

### 37.2 Examples

| Token | Decomposition |
|---|---|
| `--color-primary` | category=color, property=primary |
| `--color-severity-critical` | category=color, property=severity, variant=critical |
| `--color-accent-cta-hover` | category=color, property=accent, variant=cta, state=hover |
| `--text-h1` | category=text, property=h1 |
| `--space-4` | category=space, property=4 |
| `--radius-lg` | category=radius, property=lg |
| `--shadow-focus` | category=shadow, property=focus |
| `--duration-normal` | category=duration, property=normal |
| `--ease-out` | category=ease, property=out |

### 37.3 Rules

1. **Lowercase, hyphen-separated.** No camelCase, no underscores.
2. **Category first.** Always `--color-*`, `--text-*`, `--space-*`, never `--primary-color`.
3. **State last.** `--color-accent-cta-hover`, not `--color-accent-hover-cta`.
4. **No abbreviations.** `--duration-normal`, not `--dur-norm`.
5. **Semantic, not functional.** `--color-severity-critical`, not `--color-red` (red might be used elsewhere).

---

## 38. RTL Considerations

### 38.1 Logical CSS properties (mandatory)

| Physical (forbidden) | Logical (required) |
|---|---|
| `margin-left` | `margin-inline-start` |
| `margin-right` | `margin-inline-end` |
| `padding-left` | `padding-inline-start` |
| `padding-right` | `padding-inline-end` |
| `border-left` | `border-inline-start` |
| `border-right` | `border-inline-end` |
| `left` | `inset-inline-start` |
| `right` | `inset-inline-end` |
| `text-align: left` | `text-align: start` |
| `text-align: right` | `text-align: end` |

### 38.2 Component RTL behaviors

| Component | RTL behavior |
|---|---|
| Buttons | Icon position flips (icon on right in RTL) |
| Cards (severity-bordered) | Border on `border-inline-start` (right in RTL) |
| Inputs | Text right-aligned, leading icon on right |
| Tables | Column order reverses, number columns end-aligned |
| Dropdowns | Caret on left (end), popover aligns to start |
| Tabs | Tab order reverses |
| Charts | x-axis reversed (earliest right, latest left) |
| Modals | Close button top-left, drawer slides from right |
| Toasts | Position top-left, slide from left |
| Tooltips | Position mirrors |
| Pagination | Prev/Next swap, page numbers read right-to-left |
| Breadcrumbs | Separator mirrors (`‹`), crumb order reverses |
| Progress (linear) | Fill from right |
| Stepper | Step order reverses (step 1 on right) |

### 38.3 Number handling

- **Persian numerals** (۰۱۲۳۴۵۶۷۸۹) in prose, captions, labels.
- **Latin numerals** (0123456789) in `--font-mono` data fields (scores, $, %).
- Use `<bdi>` tags or Unicode bidi controls to keep numbers LTR within RTL paragraphs.
- This matches the V23 PDF engine convention.

### 38.4 Date handling

- **Shamsi calendar** (`۱۴۰۴/۰۴/۲۰`) in Persian UI via `Intl.DateTimeFormat('fa-IR-u-ca-persian')`.
- **Gregorian calendar** (`2025-07-11`) in English UI.
- Calendar picker adapts to selected language.

---

## 39. Component Inventory Index

### 39.1 Components specified in this document (18)

| # | Component | Section |
|---|---|---|
| 1 | Buttons | §19 |
| 2 | Cards | §20 |
| 3 | Inputs | §21 |
| 4 | Tables | §22 |
| 5 | Dropdowns / Select | §23 |
| 6 | Tabs | §24 |
| 7 | Charts | §25 |
| 8 | Dialogs / Modals | §26 |
| 9 | Badges | §27 |
| 10 | Notifications / Toasts | §28 |
| 11 | Tooltips | §29 |
| 12 | Search / Command Palette | §30 |
| 13 | Pagination | §31 |
| 14 | Breadcrumbs | §32 |
| 15 | Progress Indicators | §33 |
| 16 | Skeleton Loaders | §34 |
| 17 | Empty States | §35 |
| 18 | Error States | §36 |

### 39.2 Composite components (built from the 18 above, used in Phase 2 specs)

| Composite | Built from | Used on |
|---|---|---|
| ScoreGauge | Progress (circular-determinate) + Typography | Dashboard, Behavioral |
| SeverityBadge | Badges (severity variant) | Dashboard, Behavioral, Diagnosis, Evidence |
| EvidenceCard | Cards (severity-bordered) + Badges + Typography + Tooltip | Diagnosis, Dashboard |
| RecommendationCard | Cards (severity-bordered) + Badges (priority) + Button (toggle) | Coaching, Dashboard |
| ContextBlockCard | Cards + ScoreGauge + Badges + Tooltip | Behavioral |
| StatCard | Cards (stat variant) + Typography (mono) | Dashboard perf strip, all pages |
| HistoryItemCard | Cards (interactive) + ScoreGauge + Badges + Menu | History |
| UploadDropzone | Inputs (file) + Icons + Typography | Upload |
| FilePill | Badges + IconButton (X) | Upload |
| ProgressStepper | Progress (stepper) + Typography | Analysis Progress |
| FilterBar | Inputs + Dropdowns + SegmentedControl + Button | Trade Explorer, Diagnosis, History |
| TradeDetailDrawer | Dialogs (drawer) + Typography + Table | **Trade Explorer** |
| QuickJumpTile | Cards (interactive) + Icons + Typography | Dashboard |

### 39.3 Trade Explorer — Page & Component Mapping (NEW in v1.1)

**Trade Explorer** is a **Tier 3 Deep Dive page** (Phase 2 §4.5), positioned after Charts (position 7) and before Trends (position 9), at **sidebar position 8**. Icon: `Table` (Phosphor). It is the 14th build page (Phase 2 §5.3).

**Page route:** `/trades/[analysisId]`

**API dependency:** `GET /api/v1/analyses/{id}/trades` (Phase 2 §5.1 — serialization-only, no engine changes, test-enforced).

**Components consumed by Trade Explorer:**

| Component | Section | Usage on Trade Explorer |
|---|---|---|
| PageTitle + Breadcrumbs | §32 | Page header |
| FilterBar (composite) | §39.2 | Date range, side, outcome, size filters (collapsible on mobile) |
| Dropdowns / Select | §23 | Sort dropdown (date, profit, size) |
| StatCard (composite) | §39.2 | Aggregate stats bar (Total P&L, Win Rate, Avg Size, Largest Win/Loss) |
| Tables (dense + card-list) | §22 | Trade table (desktop: dense table; mobile: card list) |
| Pagination | §31 | Page navigation (50/100/200 per page) |
| TradeDetailDrawer (composite) | §39.2 | Trade detail drawer (desktop) / bottom sheet (mobile) |
| Buttons | §19 | Export CSV, Apply Filters, Clear Filters |
| Empty States | §35 | `empty-trades.svg` when no trades match filter |
| Skeleton Loaders | §34 | Table row skeletons during load |
| Error States | §36 | Fetch error, 404 error |
| Badges | §27 | Side badge (Long/Short), outcome badge (Win/Loss) |
| Tooltips | §29 | Column header explanations |

**Navigation placement confirmation:**

| Position | Nav item | Tier | Icon |
|---|---|---|---|
| 7 | Charts | Deep dive | `ChartLineUp` |
| **8** | **Trade Explorer** | **Deep dive** | **`Table`** |
| 9 | Trends | Deep dive | `TrendUp` |

**Mobile:** Trade Explorer is accessible via the bottom tab bar's "More" sheet (not in the top 5 — those are Dashboard, Behavioral, Diagnosis, Coaching, Report).

**Page Hierarchy confirmation (Phase 2 §4.5):**
```
Tier 3 — Deep dive
  Trader DNA      (position 5)
  Edge Map        (position 6)
  Charts          (position 7)
  Trade Explorer  (position 8) ← NEW, between Charts and Trends
  Trends          (position 9)
```

---

## 40. Phase 4 Implementation Notes

### 40.1 Stack

- **Next.js 14+ (App Router)** — per UI/UX Pro Max `data/stacks/nextjs.csv`.
- **Tailwind CSS** — for token-driven styling, mobile-first breakpoints.
- **shadcn/ui** — for accessible, token-driven component primitives. Custom components (ScoreGauge, EvidenceCard, etc.) built on top.
- **Recharts** — for charts (per §13).
- **Phosphor Icons** (`@phosphor-icons/react`) — for all icons (per §11).
- **next/font** — for self-hosting Vazirmatn + Fira Code + Fira Sans.
- **cmdk** — for Command Palette (per §30).
- **react-hotkeys-hook** — for keyboard shortcut handling (`Cmd/Ctrl+K`, `g`+letter, `u`, `?`, `t`, `l`, `d`, `Esc`). See §40.7.

### 40.2 Token implementation & Routing structure (updated v1.1 — Trade Explorer added)

**Token implementation:**
- **CSS custom properties** in `app/globals.css` — consumed by all components.
- **TypeScript constants** in `lib/tokens.ts` — consumed by JS (Recharts colors, etc.).
- **Tailwind config** in `tailwind.config.ts` — `theme.extend.colors`, `theme.extend.spacing`, etc.
- All three generated from `tokens.json` (single source of truth) via a build script.

**Routing structure (App Router — includes Trade Explorer at position 12):**

```
app/
├── (public)/
│   ├── page.tsx                    # 1. Home / Landing
│   ├── sample/page.tsx             # 2. Sample Report
│   └── layout.tsx                  # Public layout (no sidebar)
├── (app)/
│   ├── layout.tsx                  # App layout (sidebar + top bar + bottom tab bar)
│   ├── upload/page.tsx             # 3. Upload
│   ├── history/page.tsx            # 4. History
│   ├── dashboard/[analysisId]/page.tsx       # 5. Dashboard (emotional center)
│   ├── behavioral/[analysisId]/page.tsx      # 6. Behavioral Analysis
│   ├── diagnosis/[analysisId]/page.tsx       # 7. Diagnosis
│   ├── coaching/[analysisId]/page.tsx        # 8. Coaching
│   ├── trader-dna/[analysisId]/page.tsx      # 9. Trader DNA
│   ├── edge-map/[analysisId]/page.tsx        # 10. Edge Map
│   ├── charts/[analysisId]/page.tsx          # 11. Charts
│   ├── trades/[analysisId]/page.tsx          # 12. Trade Explorer (NEW — Tier 3, position 8 in nav)
│   ├── trends/page.tsx                       # 13. Trends
│   ├── report/[analysisId]/page.tsx          # 14. Report
│   └── settings/page.tsx                     # 15. Settings (stub)
├── api/                            # BFF Route Handlers
│   ├── uploads/route.ts
│   ├── analyses/route.ts
│   ├── analyses/[id]/route.ts
│   ├── analyses/[id]/report/route.ts
│   ├── analyses/[id]/report.html/route.ts
│   ├── analyses/[id]/report.pdf/route.ts
│   ├── analyses/[id]/trades/route.ts   # NEW — proxies to V23 trades endpoint
│   └── history/route.ts
└── layout.tsx                      # Root layout
```

**Navigation Structure confirmation (Phase 2 §4.5):** Trade Explorer is at sidebar position 8 (Tier 3, after Charts at 7, before Trends at 9), icon `Table` (Phosphor). On mobile, accessible via the bottom tab bar's "More" sheet.

**Page Hierarchy confirmation:** Trade Explorer is Tier 3 Deep Dive, drilled from Charts («مشاهده‌ی معاملات خام») and Diagnosis («مشاهده‌ی معاملات مرتبط» on expanded evidence cards).

### 40.3 Theme implementation

- **Dark theme:** default. `data-theme="dark"` on `<html>`.
- **Light theme:** `data-theme="light"`.
- Toggle via ThemeToggle component, persisted in `localStorage('td_theme')`.
- System preference (`prefers-color-scheme: dark`) respected on first visit.
- No FOUC (flash of unstyled content) — theme applied before first paint via inline script.

### 40.4 RTL implementation

- `dir="rtl"` on `<html>` (default).
- Language toggle switches `dir` and `lang` together.
- All components use logical CSS properties (§38.1).
- Tailwind's RTL plugin (`tailwindcss-rtl` or logical property support) for utilities.

### 40.5 Performance budget

- First Contentful Paint: <1.5s on 4G mobile.
- Largest Contentful Paint: <2.5s on 4G mobile.
- Cumulative Layout Shift: <0.1 (zero layout shift; Skeletons match final shape).
- Time to Interactive: <3.5s on 4G mobile.
- Bundle size: <200KB initial JS (gzip) on mobile.
- Fonts: Vazirmatn (Regular + Medium + Bold) ≈ 90KB woff2; Fira Code (Regular + Medium + Bold) ≈ 60KB woff2; Fira Sans fallback ≈ 80KB woff2.

### 40.6 Component implementation order (Dashboard = HIGHEST PRIORITY — updated v1.1)

The Dashboard is the **emotional center** of the product (Phase 1 hard constraint #2) and the single most important page to get right. It must be the **first page implemented and the first to pass the Pre-Phase-4 Validation Checklist (§43)**. If the Dashboard's 4 emotional-center cards don't fit above the fold on 375 × 667, the entire implementation is blocked until it does.

**Implementation order:**

1. **Token system** (CSS variables, Tailwind config, `tokens.json` generator) — foundation for everything.
2. **Typography** (next/font setup: Vazirmatn + Fira Code + Fira Sans; type scale classes).
3. **Primitives**: Button, Input, Badge, Icon, Tooltip.
4. **Layout**: Card, Container, Grid, Sidebar, TopBar, BottomTabBar.
5. **Feedback**: Toast, Skeleton, EmptyState, ErrorState, ProgressIndicator.
6. **Composite**: ScoreGauge, SeverityBadge, EvidenceCard, RecommendationCard, ContextBlockCard, StatCard.
7. **🔴 Dashboard (HIGHEST PRIORITY PAGE)** — build the 4 emotional-center cards (Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action) using the composites above. **Verify 375 × 667 fit immediately** (§43 V-DASH-1). Do not proceed to other pages until Dashboard passes.
8. **Upload + Analysis Progress** — the entry flow that produces analyses (needed to test Dashboard).
9. **Remaining Tier 2 pages**: Behavioral, Diagnosis, Coaching.
10. **Tier 3 pages**: Trader DNA, Edge Map, Charts, **Trade Explorer** (requires trades API endpoint), Trends.
11. **Tier 4**: Report.
12. **Settings stub**.
13. **Public pages**: Home/Landing, Sample Report (can be built in parallel from step 1 onward since they don't depend on analysis context).

**Dashboard priority rationale:**
- The Dashboard is the "moment of truth" — if it fails to communicate in 5 seconds, the entire product fails.
- It exercises the most components (ScoreGauge, EvidenceCard, RecommendationCard, StatCard, Cards interactive, Badges, Tooltips, Skeletons, EmptyStates, ErrorStates).
- It has the tightest constraint (4 cards above fold on 375 × 667 — verified math in Phase 2 §10.1).
- Getting it right first proves the token system, component library, and responsive strategy all work together.
- Every other page is a variation of patterns the Dashboard establishes.

### 40.7 Keyboard shortcuts implementation (NEW in v1.1)

Implement keyboard shortcuts per Phase 2 §6 using `react-hotkeys-hook`:

| Shortcut | Action | Implementation |
|---|---|---|
| `Cmd/Ctrl+K` | Open Command Palette | Global, opens cmdk palette (§30) |
| `g` then `d` | Go to Dashboard | Global, navigates to `/dashboard/{currentId}` |
| `g` then `b` | Go to Behavioral | Global |
| `g` then `i` | Go to Diagnosis | Global (i for "issue") |
| `g` then `c` | Go to Coaching | Global |
| `g` then `r` | Go to Report | Global |
| `g` then `h` | Go to History | Global |
| `g` then `t` | Go to Trade Explorer | Global |
| `g` then `n` | Go to Trends | Global (n for "trend") |
| `u` | Go to Upload | Global |
| `?` | Show keyboard shortcuts help | Global, opens help modal |
| `Esc` | Close modal/drawer/palette | Global |
| `/` | Focus search | History, Trade Explorer |
| `d` | Download PDF (current analysis) | Any analysis page |
| `t` | Toggle theme | Global |
| `l` | Toggle language | Global |

**Rules:**
- All shortcuts disabled when focus is in a text input or textarea (except `Esc`).
- Shortcuts are instant — no transition animation (per §14.4 principle 9).
- Mobile: no keyboard shortcuts (touch devices). Command palette accessible via "More" sheet button.
- Discoverable via `?` help overlay and the command palette itself.

---

## 41. Changes Summary

### 41.1 What this document delivers (v1.0)

| # | Deliverable | Section |
|---|---|---|
| 1 | Design Philosophy (Linear/Stripe/Vercel/TradingView tier) | §1–§3 |
| 2 | Visual Identity (brand personality, logo, color, typography philosophy) | §2 |
| 3 | Color Palette (brand + 12-step neutral ramps × 2 themes) | §4 |
| 4 | Semantic Colors (severity, profit/loss, status, surfaces — all WCAG AA verified) | §5 |
| 5 | Typography Scale (13 type tokens, mobile-first, Vazirmatn + Fira Code pairing) | §6 |
| 6 | Font Pairing rationale | §6.5 |
| 7 | Grid System (4/8/12-column, 6 containers) | §7 |
| 8 | Spacing Scale (13 tokens, 4/8dp rhythm) | §8 |
| 9 | Border Radius System (7 tokens) | §9 |
| 10 | Elevation System (6 levels + 7 raw shadows) | §10 |
| 11 | Icon Style (Phosphor primary, 5 sizes, 30+ mappings) | §11 |
| 12 | Illustration Style (geometric line-based, 9 illustrations) | §12 |
| 13 | Charts Style (Recharts, 8 chart colors, 8 chart types) | §13 |
| 14 | Animation Principles (6 principles, 6 durations, 4 easings) | §14 |
| 15 | Motion Guidelines (15 interaction patterns, reduced-motion handling) | §14.4–§14.6 |
| 16 | Component States (every component has all states specified) | §19–§36 |
| 17 | Responsive Breakpoints (6 breakpoints, mobile-first) | §15 |
| 18 | Accessibility Rules (WCAG AA, keyboard, screen reader, touch, reduced-motion, RTL) | §16 |
| 19 | Design Tokens (~150 tokens, naming convention, export format) | §17 |
| 20 | Component Library (18 components + 13 composite, all with anatomy/states/a11y/RTL) | §19–§36 |

### 41.2 What this document does NOT change

- **Phase 1 hard constraints** — all preserved (Dashboard emotional center, mobile-first, Persian-first RTL, engine untouched).
- **Phase 2 UX Architecture flows** — all 12 flows preserved.
- **Phase 2 page specs** — all 14 build pages + Settings stub preserved.
- **V23 analytical engine** — completely untouched.
- **Trade Explorer API addition** — preserved (Phase 2 §5.1).

### 41.3 Compatibility

This v1.0 design system is **fully compatible** with:
- Phase 1 Product Strategy (approved).
- Phase 2 Visual Design (approved) — this document refines and supersedes the token sections (§3–§17 of Visual Design).
- Phase 2 UX Architecture v1.2 (approved) — this document provides the component specs that Architecture's flows reference.
- V23 analytical engine — completely untouched.

### 41.4 What's next (Phase 4)

Phase 4 (Implementation) will:
1. Build the token system (`tokens.json`, CSS variables, Tailwind config, TS constants).
2. Set up next/font (Vazirmatn, Fira Code, Fira Sans).
3. Build the 18 core components + 13 composite components per this spec.
4. **Build Dashboard FIRST** (highest priority — §40.6) and verify 375 × 667 fit.
5. Build remaining 13 pages per Phase 2 specs.
6. Add the Trade Explorer API endpoint (Phase 2 §5.1) + `/trades/[analysisId]` route.
7. Implement keyboard shortcuts (§40.7).
8. Pass the Pre-Phase-4 Validation Checklist (§43 — the Phase 4 acceptance criteria).

---

## 42. Final Changes Summary (v1.0 → v1.1)

This section documents the final polish changes applied in v1.1. All Phase 1 hard constraints are preserved: Dashboard as emotional center, mobile-first, Persian-first RTL, engine untouched. Phase 2 architecture is fully preserved.

### 42.1 What changed (v1.0 → v1.1)

| # | Change | Section | Rationale |
|---|---|---|---|
| 1 | **Phase 2+3 Master Specification Note added.** Recommends merging Phase 2 Visual Design + Architecture + Phase 3 Design System into a single Master UX & Design Spec for Phase 4. Includes suggested 11-section merged structure. | §0 (NEW) | User request #2 — consolidation recommendation. |
| 2 | **Trade Explorer explicitly added** to Component Inventory (§39.3), Routing structure (§40.2), Navigation Structure confirmation, and Page Hierarchy confirmation. Confirmed as Tier 3, position 8, after Charts (7), before Trends (9), icon `Table`. | §39.3 (NEW), §40.2 | User request #1 — Trade Explorer explicit placement. |
| 3 | **Dashboard marked as HIGHEST PRIORITY** in component implementation order. Step 7 (red, 🔴) — first page to build and pass validation. | §40.6 | User request #3 — Dashboard priority. |
| 4 | **Amber CTA contrast note reinforced.** New `--fg-on-cta` token (`#0A0E1A` dark / `#FFFFFF` light) separated from `--fg-on-primary`. Implementation rule documented: Button `primary` variant must conditionally swap based on theme. Validated in §43 (V-CTA-1). | §5.4, §5.5 | User request #4 — polish amber CTA contrast. |
| 5 | **Keyboard shortcuts added to Motion Guidelines.** New principle 9: keyboard shortcuts are instant (no transition animation). | §14.4 | User request #4 — keyboard shortcuts in motion. |
| 6 | **Illustration inventory updated with exact filenames.** Each illustration now lists `{name}.svg` filename, storage path (`public/illustrations/`), and import pattern. | §12.3 | User request #4 — exact filenames. |
| 7 | **Keyboard shortcuts implementation section added.** Full shortcut table (16 shortcuts) + rules (disabled in inputs, instant, mobile fallback). `react-hotkeys-hook` added to stack. | §40.7 (NEW), §40.1 | User request #4 — keyboard shortcuts in implementation. |
| 8 | **Pre-Phase-4 Validation Checklist added.** 7 categories, 50+ testable items: token consistency, component states, RTL, accessibility (WCAG AA), Dashboard 375px fit, reduced-motion, performance budget. | §43 (NEW) | User request #5 — validation checklist. |
| 9 | **Version bumped to v1.1.** Header, footer, ToC updated. | Header, footer, ToC | Versioning protocol. |

### 42.2 What did NOT change (v1.0 → v1.1)

- **All 18 core components + 13 composite** — preserved.
- **All ~150 design tokens** — preserved (only `--fg-on-cta` split out from `--fg-on-primary` for clarity; values unchanged).
- **All 14 build pages + Settings stub** — preserved.
- **Trade Explorer API specification** — preserved (Phase 2 §5.1, serialization-only).
- **Phase 1 hard constraints** — all preserved: Dashboard emotional center, mobile-first, Persian-first RTL, engine untouched.
- **Phase 2 architecture** — fully preserved. This document adds design-system detail, not architectural change.

### 42.3 Compatibility statement

This v1.1 document is **fully compatible** with:
- Phase 1 Product Strategy (approved).
- Phase 2 Visual Design (approved) — this document refines and supersedes the token sections.
- Phase 2 UX Architecture v1.2 (approved) — this document provides the component specs that Architecture's flows reference.
- V23 analytical engine — completely untouched.

---

## 43. Pre-Phase-4 Validation Checklist (NEW in v1.1)

**Purpose:** A single, testable checklist that must pass before Phase 4 implementation is considered complete. Covers token consistency, component states, RTL, accessibility, Dashboard fit, reduced-motion, and performance budget. This checklist complements (does not replace) the Phase 2 §9 Pre-Phase-3 Validation Checklist — together they form the complete Phase 4 acceptance criteria.

### 43.1 Token Consistency

| # | Test | Pass criteria |
|---|---|---|
| V-T-1 | No hardcoded hex values in components | `grep -rn '#[0-9A-Fa-f]\{6\}' app/components/` returns nothing. All colors via `var(--*)`. |
| V-T-2 | No hardcoded spacing values | `grep -rn 'padding: [0-9]' app/components/` returns nothing. All spacing via tokens or Tailwind utilities. |
| V-T-3 | No hardcoded font sizes | `grep -rn 'font-size: [0-9]' app/components/` returns nothing. All via `--text-*` tokens. |
| V-T-4 | No hardcoded radii | All `border-radius` via `--radius-*` tokens. |
| V-T-5 | No hardcoded shadows | All `box-shadow` via `--shadow-*` / `--elevation-*` tokens. |
| V-T-6 | `tokens.json` is single source of truth | CSS variables, TS constants, and Tailwind config all generated from `tokens.json`. Verify with build script. |
| V-T-7 | Dark + light theme token parity | Every semantic token has both dark and light values defined. No token missing in either theme. |
| V-T-8 | Token naming convention | All tokens follow `--{category}-{property}-{variant?}-{state?}` pattern (§37). No abbreviations. |

### 43.2 Component States

| # | Test | Pass criteria |
|---|---|---|
| V-C-1 | Every interactive component has: default, hover, active, focus, disabled, loading states | Verify for Button, Card (interactive), Input, Select, Tab, Modal, Toast, Pagination, Breadcrumb, Command Palette. |
| V-C-2 | Focus ring visible on every focusable element | 3px solid `--ring-focus`, 2px offset. Never `outline: none` without replacement. |
| V-C-3 | Disabled state is non-interactive | `disabled` attribute (not just class), `cursor-not-allowed`, `aria-disabled`. |
| V-C-4 | Loading state shows spinner or skeleton | Never a frozen UI. Button loading = spinner + greyed label. Page loading = skeleton. |
| V-C-5 | Empty state is actionable | Every component that can be empty has illustration + headline + CTA. Never just "no data." |
| V-C-6 | Error state is recoverable | Every component that can fail shows what + why + CTA. Never just "error." |
| V-C-7 | Skeleton matches final shape | No layout shift when skeleton → content. Same height, same width, same radius. |

### 43.3 Amber CTA Contrast (specific — reinforced v1.1)

| # | Test | Pass criteria |
|---|---|---|
| V-CTA-1 | Dark theme amber CTA uses `--fg-on-cta` (`#0A0E1A`), not `--fg-on-primary` (`#FFFFFF`) | Visual inspection + computed contrast ≥ 4.5:1. Amber `#F59E0B` bg + `#0A0E1A` text = 8.9:1. ✓ |
| V-CTA-2 | Light theme amber CTA uses `--fg-on-cta` (`#FFFFFF`) on `#D97706` | Computed contrast = 4.8:1. ✓ |
| V-CTA-3 | Button `primary` variant swaps text color based on theme | Verified in Button component implementation. |

### 43.4 RTL Validation

| # | Test | Pass criteria |
|---|---|---|
| V-RTL-1 | Default direction `dir="rtl"`, `lang="fa"` | On `<html>` element. |
| V-RTL-2 | All components use logical CSS properties | `grep -rn 'margin-left\|margin-right\|padding-left\|padding-right\|border-left\|border-right' app/components/` returns nothing. All via `inline-start`/`inline-end`. |
| V-RTL-3 | Directional icons flip in RTL | Arrows, chevrons mirrored via `transform: scaleX(-1)` scoped to `[dir="rtl"]`. |
| V-RTL-4 | Charts reverse x-axis in RTL | Recharts `reversed` prop set on x-axis. |
| V-RTL-5 | Sidebar on right in RTL | Layout mirrors correctly. |
| V-RTL-6 | Modals/drawers slide from correct side | Drawer from right in RTL, left in LTR. |
| V-RTL-7 | Persian numerals in prose, Latin in mono data | Verified in Dashboard, Behavioral, Charts. |
| V-RTL-8 | Shamsi calendar in Persian UI | `Intl.DateTimeFormat('fa-IR-u-ca-persian')`. |
| V-RTL-9 | Language toggle is instant | No page reload. Both `fa` and `en` fully translated. |
| V-RTL-10 | Breadcrumbs separator mirrors | `‹` in RTL, `›` in LTR. |

### 43.5 Accessibility (WCAG AA)

| # | Test | Pass criteria |
|---|---|---|
| V-A-1 | Body text contrast ≥ 4.5:1 (both themes) | Automated test (axe-core or Lighthouse) + manual verification. |
| V-A-2 | Secondary text contrast ≥ 3:1 (both themes) | Same. |
| V-A-3 | Non-text UI contrast ≥ 3:1 (icons, borders) | Same. |
| V-A-4 | Keyboard navigation: every interactive element reachable via Tab | Manual test on all 14 pages. |
| V-A-5 | Screen reader test (NVDA + VoiceOver) | All 12 flows completable. No unlabeled controls. |
| V-A-6 | `prefers-reduced-motion: reduce` respected | All motion ≤ 1ms. Skeletons static. Page still functional. |
| V-A-7 | Touch targets ≥ 44×44pt on mobile | Manual measurement on 375px viewport. |
| V-A-8 | ARIA labels on every interactive element | `grep -rn 'role=' app/components/` + manual audit. |
| V-A-9 | Color is never the only signal | Every severity/profit indicator has text + icon. |
| V-A-10 | Charts have `aria-label` + visually-hidden data table | All 8 chart types verified. |
| V-A-11 | Skip-to-content link on every page | Present, visually hidden until focused. |
| V-A-12 | One `<h1>` per page, logical heading hierarchy | Manual audit. |

### 43.6 Dashboard 375px Fit (critical — Phase 1 hard constraint)

| # | Test | Pass criteria |
|---|---|---|
| V-DASH-1 | Dashboard at 375 × 667 (iPhone SE) | All 4 emotional-center cards (Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action) visible without scrolling. Verified math: 140+120+120+110px + 3×16px gaps + 56px top bar = 594px; viewport 667px; buffer 73px. |
| V-DASH-2 | Dashboard at 375 × 667 with iOS Safari URL bar | Buffer reduces to ~23px — still fits, no clipping. |
| V-DASH-3 | Dashboard at 414 × 896 (iPhone 11) | All 4 cards visible with comfortable buffer. |
| V-DASH-4 | Dashboard at 768 × 1024 (iPad portrait) | 2-column layout: Health+Leak left, Strength+Action right. |
| V-DASH-5 | Dashboard at 1024 × 768 (iPad landscape) | 4-column equal-width grid. |
| V-DASH-6 | Dashboard at 1280 × 800 (laptop) | 4-column grid with sidebar. |
| V-DASH-7 | ScoreGauge animates 0 → value (600ms Expo.out) | Frozen if reduced-motion. |
| V-DASH-8 | 4 cards staggered fade-in (100ms per card) | Frozen if reduced-motion. |
| V-DASH-9 | Each card navigates to correct drill-down | Overall Health → Behavioral; Biggest Leak → Diagnosis; Biggest Strength → Edge Map; Immediate Next Action → Coaching. |
| V-DASH-10 | Skeleton cards match final shape | No layout shift on load. |

### 43.7 Reduced-Motion

| # | Test | Pass criteria |
|---|---|---|
| V-RM-1 | `@media (prefers-reduced-motion: reduce)` sets all durations to 0.01ms | Verified in CSS. |
| V-RM-2 | Skeletons: static grey blocks (no pulse) | Visual inspection. |
| V-RM-3 | Spinners: static or hidden | Visual inspection. |
| V-RM-4 | Page transitions: instant swap | No overlay animation. |
| V-RM-5 | Charts: instant render | No grow animation. |
| V-RM-6 | Score gauge: instant fill | No arc animation. |
| V-RM-7 | Tooltips/modals: instant appear/disappear | No fade. |
| V-RM-8 | Page still fully functional with reduced-motion | All 12 flows completable. |

### 43.8 Performance Budget

| # | Test | Pass criteria |
|---|---|---|
| V-P-1 | First Contentful Paint | < 1.5s on 4G mobile (Lighthouse). |
| V-P-2 | Largest Contentful Paint | < 2.5s on 4G mobile (Lighthouse). |
| V-P-3 | Cumulative Layout Shift | < 0.1 (Lighthouse). Zero layout shift; skeletons match final shape. |
| V-P-4 | Time to Interactive | < 3.5s on 4G mobile (Lighthouse). |
| V-P-5 | Initial JS bundle (gzip) | < 200KB on mobile. Verify with `@next/bundle-analyzer`. |
| V-P-6 | Font loading | Vazirmatn (R+M+B) ≈ 90KB woff2; Fira Code (R+M+B) ≈ 60KB woff2; Fira Sans fallback ≈ 80KB woff2. All via `next/font` with `font-display: swap`. No FOIT. |
| V-P-7 | No layout shift from fonts | `next/font` with `size-adjust` or fallback metrics. |
| V-P-8 | Images via `next/image` | All raster images use `<Image>` with `width`/`height` or `fill`. |
| V-P-9 | Heavy components lazy-loaded | Charts (Recharts) via `next/dynamic` if not above fold. |
| V-P-10 | Lighthouse performance score | ≥ 90 on mobile (Lighthouse). |

### 43.9 Trade Explorer Validation (specific — reinforced v1.1)

| # | Test | Pass criteria |
|---|---|---|
| V-TE-1 | Trade Explorer at sidebar position 8 | Between Charts (7) and Trends (9). Icon `Table`. |
| V-TE-2 | Route `/trades/[analysisId]` works | Page loads with valid analysis ID. |
| V-TE-3 | API endpoint `GET /api/v1/analyses/{id}/trades` returns JSON | `test_trades_endpoint_returns_serialized_df` passes. No engine imports in `api/routers/trades.py`. |
| V-TE-4 | Filter bar works (date, side, outcome, size) | Server-side filtering via query params. Aggregate stats update. |
| V-TE-5 | Sort works (date, profit, size) | Server-side sort. |
| V-TE-6 | Pagination works (50/100/200 per page) | Page navigation correct. |
| V-TE-7 | Trade detail drawer (desktop) / bottom sheet (mobile) | Opens on row/card click. Focus trapped. Esc closes. |
| V-TE-8 | CSV export | Downloads current filtered set as CSV (client-side). |
| V-TE-9 | Empty state | `empty-trades.svg` shown when no trades match filter. CTA "پاک کردن فیلترها". |
| V-TE-10 | Mobile: table becomes card list | One card per trade. No horizontal scroll. |
| V-TE-11 | Drill-down entry points work | Charts «مشاهده‌ی معاملات خام» + Diagnosis «مشاهده‌ی معاملات مرتبط» navigate to Trade Explorer. |

### 43.10 Keyboard Shortcuts Validation

| # | Test | Pass criteria |
|---|---|---|
| V-K-1 | `Cmd/Ctrl+K` opens Command Palette | Works globally. Esc closes. |
| V-K-2 | `g`+letter navigates to correct page | All 8 page shortcuts work (d/b/i/c/r/h/t/n). |
| V-K-3 | `u` opens Upload | Works globally. |
| V-K-4 | `?` opens keyboard shortcuts help | Modal with all shortcuts listed. |
| V-K-5 | `Esc` closes any modal/drawer/palette | Works globally. |
| V-K-6 | `t`/`l` toggle theme/language | Instant switch. |
| V-K-7 | `d` downloads PDF on analysis pages | Triggers download. |
| V-K-8 | Shortcuts disabled in text inputs | Except `Esc`. Verify on Upload, Trade Explorer filter, Command Palette. |
| V-K-9 | Shortcuts are instant (no animation) | Per §14.4 principle 9. |
| V-K-10 | Mobile: no keyboard shortcuts | Touch devices don't trigger. Command palette via "More" sheet. |

---

**Document version:** v1.1 (Final Polish)
**Status:** For approval — gate for Phase 4 (Implementation)
**Awaiting approval before Phase 4.**
