# Trading Doctor — Phase 2 UX & Visual Design Specification

**Author:** Senior Product Designer / UX Architect
**Status:** For approval — gate for Phase 3 (Implementation)
**Engine baseline:** Trading Doctor V23 Phase 4 (untouched)
**Design methodology:** UI/UX Pro Max Skill Pack v2.6.2 (canonical design system persisted at `design-system/trading-doctor/MASTER.md`)
**Phase 1 baseline:** Approved with three refinements (see §1)

> **Phase 1 refinements carried as hard constraints (non-negotiable):**
> 1. **Mobile-first & responsive by design.** Every UX flow is designed simultaneously for Desktop, Tablet, Mobile — mobile is never an adaptation.
> 2. **Dashboard = emotional center.** First screen after analysis shows, without scrolling: **Overall Health · Biggest Leak · Biggest Strength · Immediate Next Action**.
> 3. **Always prioritize:** Clarity over complexity · Actionability over information density · Premium SaaS quality over feature quantity.

---

## 1. Design Philosophy

The three refinements from Phase 1 are not just preferences — they are the **decision filter** for every design tradeoff in this document and all subsequent phases.

### 1.1 Mobile-first means design order, not afterthought

Mobile is designed **first**, then enhanced upward. This forces two things: ruthless prioritization (a 375px viewport cannot lie about importance), and component-level responsive thinking (every component is born responsive). The desktop layout is the **enhanced** view, never the default that gets "made to work" on mobile.

Concretely: for every page in this document, the mobile layout is specified first, then the tablet enhancement, then the desktop expansion. Implementation must follow the same order — base mobile styles + breakpoint enhancements, never desktop-default + max-width queries.

### 1.2 Dashboard as emotional center

The post-analysis Dashboard is the single most important screen in the product. It is not a summary of metrics — it is the **emotional payoff** for the user's effort (uploading data, waiting for analysis). If the Dashboard fails to make the user feel understood in 5 seconds, the entire product fails.

The Dashboard's job is to answer four questions in one screen, without scrolling, on a 375px viewport:

1. **Overall Health** — "Am I OK?" (one number, one severity color, one word)
2. **Biggest Leak** — "What's hurting me most?" (one label, one $ figure, one severity)
3. **Biggest Strength** — "What should I keep doing?" (one label, one supporting metric)
4. **Immediate Next Action** — "What do I do right now?" (one verb-led sentence, one CTA)

Everything else on the Dashboard is **secondary and lives below the fold**. This is a hard rule.

### 1.3 Three priorities, applied as a decision filter

Every design choice in this document was filtered through these questions, in order:

1. **Is it clear?** If a user has to think twice to understand a UI element, redesign it.
2. **Is it actionable?** If a user can't do something with the information, why is it on screen?
3. **Is it premium?** If it looks like a free tool, we've failed. Polish > breadth.

Where these conflict, the earlier one wins. Example: a chart that is information-dense but not actionable gets cut; a single clear callout that drives action wins.

---

## 2. Design System (canonical, persisted)

The UI/UX Pro Max skill was invoked with a Trading Doctor-shaped query and persisted to `design-system/trading-doctor/MASTER.md`. The skill selected:

- **Pattern:** Real-Time / Operations Landing — dark/neutral, status colors, data-dense but scannable, demo/sandbox link, trust signals.
- **Style:** Modern Dark (Cinema Mobile) — dark mode primary, ambient light, glassmorphism, premium, layered, Bezier(0.16,1,0.3,1) easing. Best-fit per skill: "fintech/trading dashboards."
- **Typography base:** Fira Sans (body) + Fira Code (data/mono) — dashboard, analytics, technical, precise.
- **Color base:** Analytics Dashboard palette — blue primary `#1E40AF`, amber accent `#D97706`, with full token set.
- **Motion:** Standard tier — 400–600ms page transitions, 150–300ms micro-interactions, `power2.inOut` easing.
- **Density:** 7/10 (Standard-to-dense) — appropriate for analytics dashboard without crowding.

### 2.1 Adjustments to the canonical system (Persian-first RTL premium SaaS)

The skill's defaults are excellent for a generic analytics dashboard. Three adjustments are made for Trading Doctor's specific context:

**Adjustment 1 — Typography: add Vazirmatn for Persian.**
The skill recommended Fira Sans + Fira Code (Latin-only). Trading Doctor is Persian-first. The existing PDF engine already bundles **Vazirmatn** (Regular + Bold) for correct Persian rendering. The web app uses the same font stack for visual parity with the PDF report. Final stack:

```
--font-body:    'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* Persian + Latin */
--font-mono:    'Fira Code', 'Vazirmatn', ui-monospace, monospace; /* data, scores, $ figures */
--font-display: 'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* hero, page titles */
```

Vazirmatn covers both Persian and Latin glyphs cleanly; Fira Sans/Fira Code are fallbacks for any Latin-only context. This stack renders identically in-app and in the PDF — a Phase 2 requirement (visual consistency between UI and exported report).

**Adjustment 2 — Color: dual surface system (dark primary, light secondary).**
The skill recommended "Modern Dark (Cinema Mobile)" as dark-primary. Trading Doctor adopts **dark as the default theme** but ships a **fully-supported light theme** as a first-class option (not an exception). Reason: trading dashboards are used in both dim home offices and bright office environments; forcing dark-only would hurt daytime usability.

Final dual-surface color token system (see §3 for full token table). Both themes pass WCAG AA contrast (≥4.5:1 body, ≥3:1 secondary, ≥3:1 non-text UI).

**Adjustment 3 — Motion: capped at "Standard" tier, never "Complex."**
The skill's motion dial was set to 5/10 (Standard). This is the ceiling. No GSAP pin/Flip/SplitText choreography. Reason: Trading Doctor's users want **answers, not spectacle**. Motion is functional (transitions, feedback, progressive disclosure) — never decorative. `prefers-reduced-motion` freezes all motion to ≤1ms.

### 2.2 Pre-delivery checklist (from skill, mandatory before Phase 3 ship)

- [ ] No emojis as structural icons (SVG via Phosphor preferred, Heroicons fallback)
- [ ] `cursor-pointer` on every clickable element
- [ ] Hover states with smooth 150–300ms transitions
- [ ] Light + dark themes both pass 4.5:1 body / 3:1 secondary contrast
- [ ] Visible focus rings for keyboard navigation
- [ ] `prefers-reduced-motion` respected (all motion ≤1ms when set)
- [ ] Responsive verified at 375 / 768 / 1024 / 1440px
- [ ] RTL layout verified independently (not just LTR flipped)
- [ ] All touch targets ≥ 44×44pt
- [ ] All interactive elements have accessible names

---

## 3. Color Token System (dual-theme, semantic, token-driven)

Tokens are semantic (role-based), not raw. Components consume tokens; themes redefine token values. No component ever hardcodes a hex value.

### 3.1 Dark theme (default)

| Token | Hex | Usage |
|---|---|---|
| `--bg-base` | `#0A0E1A` | App background (deep navy-black, not pure #000 to avoid OLED smear) |
| `--bg-elevated` | `#121829` | Cards, panels, modals |
| `--bg-surface` | `#1A2238` | Inputs, secondary surfaces |
| `--bg-overlay` | `rgba(10,14,26,0.72)` | Modal/drawer scrim (72% — strong enough for legibility per skill rule) |
| `--fg-primary` | `#F1F5F9` | Body text, headings |
| `--fg-secondary` | `#94A3B8` | Captions, labels, secondary text |
| `--fg-muted` | `#64748B` | Tertiary text, placeholders |
| `--fg-on-primary` | `#FFFFFF` | Text on primary-colored surfaces |
| `--accent-primary` | `#3B82F6` | Primary actions, links, focus rings |
| `--accent-primary-hover` | `#2563EB` | Hover state of primary |
| `--accent-cta` | `#F59E0B` | Primary CTA buttons (amber, contrasts navy) |
| `--accent-cta-hover` | `#D97706` | Hover state of CTA |
| `--border-subtle` | `rgba(255,255,255,0.08)` | Hairline borders, dividers |
| `--border-strong` | `rgba(255,255,255,0.16)` | Visible borders, inputs focus |
| `--severity-low` | `#22C55E` | Green — healthy, no concern |
| `--severity-medium` | `#F59E0B` | Amber — watch, moderate |
| `--severity-high` | `#F97316` | Orange — concerning, address soon |
| `--severity-critical` | `#EF4444` | Red — urgent, address now |
| `--profit-positive` | `#22C55E` | Green — profit, win |
| `--profit-negative` | `#EF4444` | Red — loss, drawdown |
| `--profit-neutral` | `#64748B` | Grey — break-even, N/A |
| `--ring-focus` | `#3B82F6` | Focus ring (3px outer) |

### 3.2 Light theme (fully supported, toggle in top bar)

| Token | Hex | Usage |
|---|---|---|
| `--bg-base` | `#F8FAFC` | App background |
| `--bg-elevated` | `#FFFFFF` | Cards, panels, modals |
| `--bg-surface` | `#F1F5F9` | Inputs, secondary surfaces |
| `--bg-overlay` | `rgba(15,23,42,0.48)` | Modal/drawer scrim |
| `--fg-primary` | `#0F172A` | Body text, headings |
| `--fg-secondary` | `#475569` | Captions, labels, secondary text |
| `--fg-muted` | `#94A3B8` | Tertiary text, placeholders |
| `--fg-on-primary` | `#FFFFFF` | Text on primary-colored surfaces |
| `--accent-primary` | `#1E40AF` | Primary actions, links, focus rings |
| `--accent-primary-hover` | `#1E3A8A` | Hover state of primary |
| `--accent-cta` | `#D97706` | Primary CTA buttons |
| `--accent-cta-hover` | `#B45309` | Hover state of CTA |
| `--border-subtle` | `#E2E8F0` | Hairline borders, dividers |
| `--border-strong` | `#CBD5E1` | Visible borders, inputs focus |
| `--severity-low` | `#16A34A` | Green — slightly darker for AA on white |
| `--severity-medium` | `#D97706` | Amber |
| `--severity-high` | `#EA580C` | Orange |
| `--severity-critical` | `#DC2626` | Red |
| `--profit-positive` | `#16A34A` | Green |
| `--profit-negative` | `#DC2626` | Red |
| `--profit-neutral` | `#64748B` | Grey |
| `--ring-focus` | `#1E40AF` | Focus ring |

### 3.3 Severity color rules (apply across entire app, no exceptions)

- The 4 severity colors (`low/medium/high/critical`) map to the engine's 4 severity levels (`Low/Medium/High/Critical`).
- **Color is never the only signal.** Every severity indicator also has a text label and (on Dashboard) an icon. This satisfies the UX skill's "Color Only" anti-pattern rule.
- Profit/loss uses the same green/red as severity-low/severity-critical intentionally — it ties the visual language together (red = bad whether it's a behavior or a dollar figure).
- The CTA amber (`#F59E0B` dark / `#D97706` light) is reserved for **primary actions only** — never used for severity, never used for decoration. This keeps the eye trained: amber = "do this."

---

## 4. Typography System

### 4.1 Font stack

```
--font-display: 'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* hero, page H1 */
--font-body:    'Vazirmatn', 'Fira Sans', system-ui, sans-serif;  /* all body text */
--font-mono:    'Fira Code', 'Vazirmatn', ui-monospace, monospace; /* numbers, $, scores, code-like data */
```

### 4.2 Type scale (responsive, mobile-first)

| Token | Mobile (375–767px) | Tablet (768–1023px) | Desktop (≥1024px) | Usage |
|---|---|---|---|---|
| `--text-hero` | 32px / 1.15 / 700 | 40px / 1.1 / 700 | 48px / 1.05 / 700 | Landing hero only |
| `--text-h1` | 24px / 1.25 / 700 | 28px / 1.2 / 700 | 32px / 1.15 / 700 | Page titles |
| `--text-h2` | 20px / 1.3 / 600 | 22px / 1.25 / 600 | 24px / 1.2 / 600 | Section titles |
| `--text-h3` | 18px / 1.35 / 600 | 18px / 1.3 / 600 | 18px / 1.3 / 600 | Card titles |
| `--text-body` | 16px / 1.5 / 400 | 16px / 1.55 / 400 | 16px / 1.6 / 400 | Body text (≥16px for readability) |
| `--text-body-sm` | 14px / 1.45 / 400 | 14px / 1.5 / 400 | 14px / 1.5 / 400 | Secondary body, table cells |
| `--text-caption` | 12px / 1.4 / 500 | 12px / 1.4 / 500 | 12px / 1.4 / 500 | Captions, labels, badges |
| `--text-data-sm` | 14px / 1.4 / 500 mono | 14px / 1.4 / 500 mono | 14px / 1.4 / 500 mono | Small numeric data |
| `--text-data` | 18px / 1.2 / 600 mono | 20px / 1.2 / 600 mono | 22px / 1.2 / 600 mono | Stat card numbers |
| `--text-data-xl` | 28px / 1.1 / 700 mono | 32px / 1.05 / 700 mono | 40px / 1.0 / 700 mono | Dashboard headline numbers |

### 4.3 Typography rules

- **Body text minimum 16px on mobile.** Never 14px for primary content. 14px is reserved for captions and dense table cells only.
- **All numbers in mono font.** Discipline Score, $ figures, percentages, scores, dates — all `--font-mono`. This makes data scannable and aligns columns naturally.
- **Persian numerals:** use Persian digits (۰۱۲۳۴۵۶۷۸۹) in Persian UI text, Latin digits (0123456789) in mono-font data fields. The mono font handles Latin digits; Persian digits use Vazirmatn. This is the convention used in the existing PDF engine — preserved for consistency.
- **Line-height:** body 1.5–1.6 for readability; headings 1.05–1.3 for tightness. Mono data 1.0–1.2 for vertical alignment.

---

## 5. Spacing & Layout System

### 5.1 Spacing scale (4/8dp rhythm)

| Token | Value | Usage |
|---|---|---|
| `--space-1` | 4px | Tight gaps inside components (icon-to-text) |
| `--space-2` | 8px | Component padding, small gaps |
| `--space-3` | 12px | Card padding (mobile), small section gaps |
| `--space-4` | 16px | Card padding (desktop), medium gaps |
| `--space-5` | 20px | Section internal padding |
| `--space-6` | 24px | Section-to-section gap (mobile) |
| `--space-8` | 32px | Section-to-section gap (tablet) |
| `--space-10` | 40px | Section-to-section gap (desktop) |
| `--space-12` | 48px | Page-level vertical rhythm (desktop) |
| `--space-16` | 64px | Hero / landing section gaps |

### 5.2 Breakpoint system (mobile-first)

| Breakpoint | Min width | Target devices |
|---|---|---|
| `xs` (default) | 0px | Mobile portrait (375–414px) |
| `sm` | 640px | Mobile landscape, small tablet portrait |
| `md` | 768px | Tablet portrait (iPad) |
| `lg` | 1024px | Tablet landscape, small laptop |
| `xl` | 1280px | Desktop |
| `2xl` | 1536px | Large desktop |

Implementation: Tailwind-style `sm:`, `md:`, `lg:`, `xl:` prefixes. Base styles (no prefix) target mobile. Enhancements layer upward. Never the reverse.

### 5.3 Layout containers

| Container | Max width | Usage |
|---|---|---|
| `--container-mobile` | 100% – 32px (16px each side) | All pages on mobile |
| `--container-tablet` | 100% – 48px (24px each side) | All pages on tablet |
| `--container-desktop` | 1280px | All app pages on desktop (centered) |
| `--container-wide` | 1536px | Landing page only (more breathing room) |
| `--container-narrow` | 640px | Long-form text (e.g., AI coaching narrative, report preview) |

### 5.4 Grid system

- Mobile: single column, full width.
- Tablet: 2-column or 8-column grid (context-dependent).
- Desktop: 12-column grid with sidebar (240px) + content (rest).
- Grid gap: 16px mobile, 24px tablet/desktop.

### 5.5 Component sizing

| Element | Mobile | Desktop |
|---|---|---|
| Touch target min | 44×44pt | 44×44pt (kept for accessibility consistency) |
| Card border radius | 12px | 16px |
| Button height (primary) | 48px | 44px |
| Button height (secondary) | 44px | 40px |
| Input height | 48px | 44px |
| Sidebar width | n/a (off-canvas) | 240px (collapsible to 72px icon-rail) |
| Top bar height | 56px | 64px |
| Bottom tab bar height | 64px + safe-area-inset-bottom | n/a |

---

## 6. Iconography System

### 6.1 Library: Phosphor Icons (primary)

Per UI/UX Pro Max skill rule: **no emojis as structural icons**. Phosphor (`@phosphor-icons/react`) is the primary library because:
- 1,334+ icons in 6 weights (Thin / Light / Regular / Bold / Fill / Duotone)
- Excellent Persian/RTL support (icons are direction-agnostic, can be flipped with `dir` aware utilities)
- Tree-shakeable (only used icons ship)
- Consistent stroke geometry (1.5px default)

**Fallback:** Heroicons (`@heroicons/react`) only when Phosphor lacks a semantically-closer match. Never mix Phosphor and Heroicons in the same hierarchy level.

### 6.2 Icon sizing tokens

| Token | Size | Usage |
|---|---|---|
| `--icon-xs` | 16px | Inline icons in dense tables, badges |
| `--icon-sm` | 20px | Icon + text in buttons, list items |
| `--icon-md` | 24px | Default — nav items, card icons |
| `--icon-lg` | 32px | Section header icons, empty-state illustrations |
| `--icon-xl` | 48px | Hero icon, large empty states |

### 6.3 Stroke and style discipline

- **Single weight per hierarchy level.** Nav uses Regular (24px). Card headers use Bold (24px). Body uses Regular (20px). Never mix weights at the same level.
- **Filled vs outline:** outline for navigation/secondary actions, filled for active state and primary actions only. Mixing at the same level is forbidden.
- **Stroke width:** 1.5px default. Phosphor's `weight="regular"` provides this.
- **Color:** icons inherit `currentColor` by default. Severity-colored icons override with the severity token. Never use raw hex.
- **RTL:** directional icons (arrow-left, arrow-right) flip automatically via `dir="rtl"` aware CSS. Phosphor provides `mirror` utility, or use `transform: scaleX(-1)` in RTL.

### 6.4 Icon mapping for navigation and key actions

| Nav item / action | Phosphor icon | Weight |
|---|---|---|
| Upload (CTA) | `UploadSimple` | Bold |
| Dashboard | `Gauge` | Regular/Bold (active) |
| Behavioral Analysis | `Barbell` or `ChartBar` | Regular |
| Diagnosis | `Stethoscope` | Regular |
| Coaching | `Lightbulb` | Regular |
| Trader DNA | `Dna` | Regular |
| Edge Map | `MapPin` | Regular |
| Charts | `ChartLineUp` | Regular |
| Trends | `TrendUp` | Regular |
| Report | `FileText` | Regular |
| History | `ClockCounterClockwise` | Regular |
| Settings | `Gear` | Regular |
| Theme toggle | `Sun` / `Moon` | Regular |
| Language toggle | `Translate` | Regular |
| Account | `UserCircle` | Regular |
| Download PDF | `FilePdf` | Regular |
| Download HTML | `FileHtml` | Regular |
| Run analysis | `Play` | Fill |
| Delete | `Trash` | Regular |
| Close / dismiss | `X` | Regular |
| Back | `ArrowRight` (RTL) / `ArrowLeft` (LTR) | Regular |
| See more | `CaretDown` | Regular |
| External link | `ArrowUpRight` | Regular |
| Warning (data quality) | `Warning` | Fill |
| Error | `XCircle` | Fill |
| Success | `CheckCircle` | Fill |
| Info | `Info` | Regular |

---

## 7. Component System

Components are the atomic units. Every page is composed from this inventory. Components are token-driven, RTL-aware, mobile-first, and accessible by default.

### 7.1 Core component inventory

| Component | Purpose | Variants | States |
|---|---|---|---|
| `Button` | All clickable actions | primary / secondary / ghost / destructive / link | default / hover / active / focus / disabled / loading |
| `IconButton` | Icon-only actions (theme toggle, close) | round / square | (same as Button) |
| `Card` | Surface container | default / elevated / interactive / severity-bordered | default / hover / active |
| `StatCard` | Single metric display | compact / standard / hero | default / loading (skeleton) |
| `ScoreGauge` | 0–100 score with severity color | radial (Dashboard) / linear (lists) | default / loading |
| `SeverityBadge` | Low/Medium/High/Critical label | dot / pill /w text /w icon | 4 severity levels |
| `Badge` | Generic label | neutral / primary / accent / success / warning / danger | default |
| `ProgressBar` | 0–100% progress | linear / segmented | default / indeterminate |
| `EvidenceCard` | Single evidence item | compact / expanded | collapsed / expanded |
| `RecommendationCard` | Single action plan item | compact / expanded | collapsed / expanded |
| `ContextBlockCard` | Per-score breakdown | compact / detailed | default / hover |
| `DataTable` | Sortable, paginated table | dense / comfortable | default / hover-row / sorted-asc / sorted-desc / empty |
| `Chart` | Recharts/Chart.js wrapper | line / area / bar / heatmap / radar / bullet | default / loading / error |
| `Tabs` | In-page navigation | underline / pill | default / active / disabled |
| `Accordion` | Collapsible sections | default / bordered | collapsed / expanding / expanded |
| `Modal` | Centered overlay dialog | default / wide / sheet (mobile) | closed / opening / open / closing |
| `Drawer` | Side overlay (mobile nav, filters) | right (LTR) / left (RTL) / bottom | (same as Modal) |
| `Toast` | Transient notification | success / error / warning / info | entering / visible / exiting |
| `Tooltip` | Hover/focus explanation | top / bottom / left / right | default |
| `EmptyState` | No-data state | default / error / future-gated | default |
| `Skeleton` | Loading placeholder | text / card / chart / gauge | pulsing |
| `UploadDropzone` | File upload area | default / drag-active / uploading / error / success | (same) |
| `ProgressStepper` | Multi-stage progress | horizontal (desktop) / vertical (mobile) | current / complete / upcoming |
| `Breadcrumb` | Hierarchy navigation | default | default |
| `Pagination` | List paging | default / compact (mobile) | default / disabled |
| `SegmentedControl` | Mutually exclusive option picker | default | default / active |
| `Toggle` | Binary switch | default | on / off / disabled |
| `Select` | Dropdown picker | default / searchable | default / open / selected |
| `TextField` | Text input | default / with-icon / with-suffix | default / focus / error / disabled |
| `FilePill` | Uploaded file indicator | default | uploading / ready / error |

### 7.2 Component rules

1. **Token-only consumption.** No component hardcodes a color, font, spacing, or radius. All values come from §3–§5 tokens.
2. **RTL-aware by default.** Every component handles `dir="rtl"` correctly: borders flip, icons mirror, padding mirrors. Tested in both directions.
3. **Mobile-first internal layout.** Components are designed for 375px first, enhanced for wider viewports.
4. **Accessibility built-in.** Every interactive component has: keyboard support, visible focus ring, ARIA roles/labels, ≥44pt touch target on mobile.
5. **Loading states are skeletons, not spinners.** Every async-loaded component has a `loading` variant that shows a `Skeleton` matching its shape. Spinners are reserved for explicit button actions (e.g., "Running analysis…").
6. **Empty states are actionable.** Every component that can be empty has an `EmptyState` variant with: illustration (SVG), one-line headline, one-line explanation, one CTA.
7. **Error states are recoverable.** Every component that can fail shows: what went wrong (one line, no jargon), why (one line), what to do (one CTA).

---

## 8. Motion & Interaction Patterns

### 8.1 Motion principles

1. **Motion is functional, never decorative.** Every animation communicates something: state change, spatial relationship, progress, feedback.
2. **Standard tier only.** 150–300ms micro-interactions, 400–600ms page transitions. No GSAP pin/Flip/SplitText. No parallax. No autoplay carousels.
3. **Easing:** `cubic-bezier(0.16, 1, 0.3, 1)` (Expo.out) for entrances; `cubic-bezier(0.7, 0, 0.84, 0)` (Expo.in) for exits; `power2.inOut` for symmetric transitions.
4. **`prefers-reduced-motion: reduce`** freezes all motion to ≤1ms. Page still works perfectly; only the animation is removed.
5. **Stable press states.** Buttons scale to 0.97 on press (no layout shift, no surrounding content movement). Touch feedback within 80–150ms.
6. **Exit faster than enter.** Enter: 200–300ms. Exit: 150–200ms. Users want their next action to start, not to watch the previous one finish.

### 8.2 Interaction patterns

| Pattern | Trigger | Response | Duration |
|---|---|---|---|
| Button press | tap/click/Enter | scale 0.97 + bg color shift | 100ms |
| Card hover (interactive) | mouse hover | elevation + border highlight | 200ms |
| Tab switch | click | content cross-fade | 200ms |
| Accordion expand | click | height auto + content fade-in | 250ms |
| Modal open | trigger | backdrop fade-in (150ms) + content scale-up (200ms Expo.out) | 350ms total |
| Modal close | X / backdrop / Esc | content scale-down (150ms Expo.in) + backdrop fade-out (150ms) | 150ms total |
| Toast enter | trigger | slide-in from top (RTL: top-right; LTR: top-left) | 250ms |
| Toast exit | auto (4s) / X | slide-out + fade | 200ms |
| Page transition (route change) | nav click | overlay slide-down → swap → overlay slide-up | 400ms total |
| Skeleton → content | data loaded | skeleton fade-out (100ms) + content fade-in (200ms) | 300ms total |
| Chart render | data loaded | bars/lines grow from baseline | 400ms Expo.out |
| Score gauge fill | data loaded | arc fills from 0 to value | 600ms Expo.out |
| Drawer open (mobile nav) | hamburger tap | backdrop fade + drawer slide-in from side | 250ms |
| Drag-over dropzone | file dragged over | border dash + bg tint | 150ms |
| Progress stepper advance | stage completes | checkmark pop + next stage highlight | 300ms |

### 8.3 Haptic feedback (mobile, where supported)

- Button press (primary CTA): light impact
- Analysis complete: medium impact + success sound (optional, user-controllable)
- Error: warning notification (system default)
- All haptics respect device settings; never override user preference.

---

## 9. RTL & Persian-First Design

### 9.1 RTL is a first-class layout, not a flip

The app's default direction is `dir="rtl"` with Persian as the default language. LTR (English) is a full alternative, not the canonical version. Implementation rules:

1. **Layout direction flows from `dir`.** Margins, paddings, borders, icons all use logical properties (`margin-inline-start`, `padding-inline-end`, `border-inline-start`) — never physical (`margin-left`). This way one `dir="rtl"` flip works correctly everywhere.
2. **Icons mirror automatically.** Directional icons (arrows, chevrons) flip in RTL. Phosphor supports this natively via `mirror` prop or CSS `transform: scaleX(-1)` scoped to `[dir="rtl"]`.
3. **Charts respect RTL.** Time-series charts flow right-to-left in RTL mode (earliest time on the right, latest on the left). Recharts/Chart.js support this via `reversed` axis prop. This matches Persian reading direction and the convention used in Iranian financial publications.
4. **Numbers stay LTR even in RTL paragraphs.** Persian text is RTL, but numeric data ($1,840, 67/100, 14:00) is rendered LTR within the RTL flow using Unicode bidi controls or `<bdi>` tags. This is standard Persian publishing convention.
5. **Form fields** are RTL-aligned (label and input text right-aligned), but input content respects its own direction (numbers LTR, text RTL).

### 9.2 Language toggle

- Top-bar button: globe/translate icon + "فا" / "EN" label.
- Toggle is instant (no reload) — language state is client-side.
- Persisted in `localStorage` (Phase 1) and user profile (future auth).
- Default language: Persian (`fa`).
- Both languages are complete — no partial translations. If a string isn't translated, it's not shipped.

### 9.3 Persian typography rules

- **Persian numerals** (۰۱۲۳۴۵۶۷۸۹) in prose, captions, and labels.
- **Latin numerals** (0123456789) in `--font-mono` data fields (scores, $, %), matching the PDF engine convention.
- **Punctuation:** Persian uses «» for quotes, ، for comma, ؛ for semicolon. Avoid Latin punctuation in Persian text.
- **Date format:** Shamsi (Persian solar) calendar in Persian UI (`۱۴۰۴/۰۴/۲۰`), Gregorian in English UI (`2025-07-11`). Conversion via `Intl.DateTimeFormat` with `fa-IR-u-ca-persian` calendar.
- **Currency:** Rial/Toman formatting in Persian UI, USD formatting in English UI — but the engine reports in whatever currency the broker CSV uses, so the UI preserves the source currency unit and only localizes the formatting.

---

## 10. Accessibility Specification (WCAG AA, mandatory)

### 10.1 Contrast

- Body text: ≥4.5:1 against background (both themes verified independently).
- Secondary text (captions, muted): ≥3:1.
- Non-text UI (icons, borders, focus rings): ≥3:1.
- Severity colors verified against both `--bg-base` and `--bg-elevated` in both themes.

### 10.2 Keyboard navigation

- Every interactive element is reachable via Tab in a logical order matching visual order.
- Visible focus ring: 3px solid `--ring-focus`, 2px offset, on every focusable element. Never removed without replacement.
- `Esc` closes modals, drawers, dropdowns.
- `Enter`/`Space` activates buttons, links, cards.
- `Arrow keys` navigate tabs, accordion, segmented controls, radio groups.
- Skip-to-content link at top of every page (visually hidden until focused).

### 10.3 Screen reader support

- Every interactive element has an `aria-label` or visible text label.
- Decorative icons: `aria-hidden="true"`.
- Functional icons (icon-only buttons): `aria-label` describing the action (e.g., "بستن" / "Close").
- Severity indicators: announced as "شدت: بالا" / "Severity: High" — never color alone.
- Charts: every chart has a `aria-label` summarizing the data, plus a visually-hidden data table alternative.
- Live regions: toasts, progress steppers use `aria-live="polite"`. Errors use `aria-live="assertive"`.

### 10.4 Reduced motion

- `@media (prefers-reduced-motion: reduce)` sets all `animation-duration` and `transition-duration` to `0.01ms !important`.
- Page still functions perfectly — only motion is removed.
- Skeleton loaders switch to a static grey block (no pulse).

### 10.5 Touch targets

- All interactive elements ≥44×44pt on mobile. Where the visual element is smaller (e.g., a 20px icon button), `padding` extends the hit area to 44pt without changing visual size.
- Adjacent touch targets separated by ≥8px to prevent mis-taps.

### 10.6 Color and contrast

- Color is never the only signal (per UX skill rule). Every color-coded indicator has a text label and/or icon.
- Tested with colorblind simulators (protanopia, deuteranopia, tritanopia) — severity colors are distinguishable by brightness/shape, not hue alone.

---

## 11. Responsive Strategy (Mobile-First, Per-Page)

This section specifies the responsive behavior pattern that applies to **every page**. Per-page specifics follow in §12.

### 11.1 Universal responsive rules

1. **Base styles target mobile (375px).** Breakpoints (`sm`, `md`, `lg`, `xl`) layer enhancements upward.
2. **Touch targets grow on mobile, shrink on desktop** (but never below 44pt for accessibility).
3. **Sidebar collapses to off-canvas drawer on mobile** (`< md`), persistent on tablet (`md` to `lg`) as icon-rail, full on desktop (`≥ lg`).
4. **Top bar persists on all breakpoints** but adapts: mobile shows logo + hamburger + theme toggle; desktop shows full breadcrumb + analysis badge + theme + language + account.
5. **Bottom tab bar appears on mobile only** (`< md`), showing top 5 nav items. Replaced by sidebar at `md+`.
6. **Tables become cards on mobile.** `DataTable` component has a `mobileCardLayout` prop that renders each row as a card on `< md`.
7. **Multi-column grids collapse to single column on mobile.** Two-column layouts become stacked; four-column KPI rows become 2×2 grids.
8. **Modals become bottom sheets on mobile.** `Modal` component renders as a bottom sheet (slide-up from bottom, full-width, max-height 90vh, swipe-down to dismiss) on `< md`, centered dialog on `md+`.
9. **Forms stack vertically on mobile.** No multi-column forms below `md`.
10. **Long-form text wraps at `--container-narrow` (640px) on all breakpoints** for readability.

### 11.2 Layout per breakpoint

| Breakpoint | Sidebar | Top bar | Bottom bar | Content width | Grid |
|---|---|---|---|---|---|
| `< sm` (mobile portrait) | Off-canvas drawer | Logo + hamburger + theme | 5-item tab bar | 100% – 32px | 1 column |
| `sm` to `< md` (mobile landscape / small tablet) | Off-canvas drawer | + analysis badge | 5-item tab bar | 100% – 48px | 2 columns |
| `md` to `< lg` (tablet portrait) | Icon-rail (72px) | + language toggle | hidden | 100% – 72px – 48px | 2–4 columns |
| `lg` to `< xl` (tablet landscape / small laptop) | Full sidebar (240px) | Full | hidden | Up to 1024px | 8–12 columns |
| `≥ xl` (desktop) | Full sidebar (240px) | Full | hidden | Up to 1280px | 12 columns |
| `≥ 2xl` (large desktop) | Full sidebar (240px) | Full | hidden | Up to 1536px | 12 columns |

### 11.3 Mobile gestures

- **Swipe right (LTR: left)** on screen edge: open nav drawer.
- **Swipe down** on top half of screen: refresh current analysis (re-fetch report).
- **Swipe down** on bottom sheet: dismiss.
- **Long-press** on history item: show context menu (reopen / delete / export).
- **Pinch** on charts: zoom (Charts page only).
- All gestures have button/tap equivalents — no gesture-only actions.

---

## 12. Page-by-Page UX Specifications

For each page: **purpose (from Phase 1) → mobile layout → tablet enhancement → desktop expansion → key interactions → empty/loading/error states**.

Special treatment: **Dashboard (§12.5)** is the emotional center and gets the deepest specification, with the 4 required above-the-fold elements on every breakpoint.

---

### 12.1 Home / Landing (Public)

**Purpose:** Communicate value proposition in 5 seconds. Show sample report. Convert visitor → uploader.

**Mobile layout (375–767px):**
- Hero: full-viewport-height section. Headline (`--text-hero`): «معامله‌گر بهتر شو، نه فقط سود more» / "Become a better trader, not just a profitable one." Subhead (`--text-body`): one sentence explaining behavioral diagnosis. Primary CTA button (amber, full-width): «تحلیل معاملاتم را شروع کن» / "Analyze my trades." Secondary CTA (ghost, full-width): «گزارش نمونه ببین» / "See a sample report."
- Trust strip: 3 inline badges (no logos in Phase 1 — text badges: "۲۲ تست پاس شده" / "22 tests passing", "بدون نیاز به ثبت‌نام" / "No signup required", "خروجی PDF حرفه‌ای" / "Professional PDF").
- How it works: 3 stacked steps (Upload → Analyze → Improve) with Phosphor icons + one-line description each.
- Sample report preview: card with screenshot thumbnail + "مشاهده گزارش کامل" / "View full report" CTA.
- Final CTA: repeat primary CTA.

**Tablet (768–1023px):**
- Hero: 2-column. Left: text + CTAs. Right: floating dashboard preview (SVG mock of the Dashboard's 4-card emotional center).
- How it works: 3 horizontal cards.
- Sample preview: larger card.

**Desktop (≥1024px):**
- Hero: full-viewport with ambient background (subtle gradient + blurred accent blobs per "Modern Dark" style).
- Trust strip: 4 badges inline.
- How it works: 3 large cards with icons.
- Sample preview: 2-column (left: preview image, right: feature bullets with check icons).
- Final CTA: centered, max-width 640px.

**Key interactions:**
- Primary CTA → navigates to `/upload`.
- Sample CTA → navigates to `/sample`.
- Smooth scroll between sections (respecting reduced-motion).
- Sticky top bar appears after scrolling past hero (transparent in hero, solid after).

**States:**
- No loading state (static page).
- No empty state.
- Error: if sample report asset fails to load, fallback to text-only description.

---

### 12.2 Sample Report (Public)

**Purpose:** Read-only, fully-rendered demo analysis so visitors can see exactly what they'll get.

**Mobile:**
- Top: page title + "این یک تحلیل نمونه است" / "This is a sample analysis" badge.
- Content: rendered HTML report (using existing `reporting/html_report.py` output) in an iframe or in-place render.
- Bottom sticky bar: «این تحلیل را روی داده‌ی خودم انجام بدهم» / "Run this on my own data" CTA → `/upload`.

**Tablet/Desktop:**
- Same as mobile but with sidebar showing section anchors (Executive Summary, Performance, Behavioral, Diagnosis, Coaching, Evidence, Appendix) for quick jump.
- Bottom sticky bar persists.

**Key interactions:**
- Section anchor click → smooth scroll to section.
- CTA → `/upload`.

**States:**
- Loading: skeleton of the report structure (heading bars + content blocks).
- Error: if sample report unavailable, show explanation + direct user to upload their own.

---

### 12.3 Upload (Entry)

**Purpose:** Multi-format file ingest, validation feedback, LLM provider selection, run analysis with staged progress.

**Mobile:**
- Full-width upload dropzone (dashed border, 200px tall) with cloud-upload icon and «فایل معاملات را اینجا بکشید یا برای انتخاب کلیک کنید» / "Drag your trades file here or click to select."
- Below: allowed formats text (CSV, XLSX, HTM, JSON, LOG, TXT) + max size (25MB).
- After file selected: `FilePill` appears with filename + size + remove (X) button.
- LLM provider `SegmentedControl`: «بدون هوش مصنوعی» / "No AI" (default) | «Gemini» | «OpenAI» | «Claude». Each with a one-line tooltip explaining the tradeoff (latency/cost vs narrative richness).
- Below: info text explaining "هوش مصنوعی فقط روایت coaching را غنی‌تر می‌کند؛ امتیازها و تشخیص‌ها همیشه توسط موتور تعیین‌شده می‌شوند." / "AI only enriches the coaching narrative; scores and diagnoses are always engine-determined."
- Primary CTA: «شروع تحلیل» / "Start Analysis" (disabled until file selected).
- Once clicked: `ProgressStepper` appears (vertical on mobile) with stages:
  1. ✓ خواندن فایل (Reading file)
  2. ✓ اعتبارسنجی داده (Validating data)
  3. ✓ تحلیل رفتار (Analyzing behavior)
  4. ✓ محاسبه‌ی امتیازها (Computing scores)
  5. ✓ تشخیص مشکل (Generating diagnosis)
  6. ✓ ساخت برنامه‌ی اقدام (Building action plan)
  - Each stage shows: stage name + spinner (or check if complete) + elapsed time.
- On complete: auto-navigate to `/dashboard/{analysis_id}`.

**Tablet/Desktop:**
- 2-column layout: left = dropzone + file pill + provider; right = "What happens next" explainer card + sample CSV format preview.
- `ProgressStepper` horizontal with connector line.

**Key interactions:**
- Drag file over dropzone: border becomes solid amber, bg tint.
- Click dropzone: native file picker opens.
- File selected: auto-detect format (show detected format + trade count if quick to read).
- Click "Start Analysis": button enters loading state (spinner + «در حال اجرا...» / "Running..."), progress stepper appears.
- Click any completed stage in stepper: tooltip shows what was done.
- Cancel button (X) during analysis: confirms, then returns to upload state.

**States:**
- Empty (initial): dropzone + format hint + CTA disabled.
- File selected: file pill + CTA enabled.
- Uploading (POST /uploads): file pill shows progress bar.
- Upload error (413 too large): inline error with size limit + suggestion.
- Upload error (422 invalid file): inline error with the engine's message (e.g., «ستون سود/زیان در فایل شما پیدا نشد» / "No profit/loss column found in your file") + "supported formats" link.
- Running analysis: progress stepper with live stage updates.
- Analysis error: error card with what failed + retry CTA.
- Analysis complete: 800ms success state (green check on all stages + «تحلیل کامل شد» / "Analysis complete") then auto-navigate.

---

### 12.4 History (Entry)

**Purpose:** Paginated list of past analyses. Click to reopen. Delete with confirm.

**Mobile:**
- Top: page title «تاریخچه‌ی تحلیل‌ها» / "Analysis History" + count badge.
- Filter/sort bar: `SegmentedControl` (all / this month / last 3 months) + sort dropdown (newest / oldest / highest score / lowest score).
- List: vertical stack of `HistoryItemCard`s. Each card shows: filename (truncated), date (Shamsi), trade count, discipline score (mini gauge), primary diagnosis (one line, truncated), actions menu (⋯).
- Long-press card: context menu (Open / Download PDF / Delete).
- Pagination: "Load more" button (no traditional page numbers on mobile).
- Empty state: illustration + «هنوز تحلیلی انجام نداده‌اید» / "You haven't run any analyses yet" + CTA to Upload.

**Tablet/Desktop:**
- Same list but in 2-column (tablet) or `DataTable` (desktop) with columns: Date | Filename | Trades | Score | Diagnosis | Actions.
- Pagination: traditional page numbers (1, 2, 3 …) + page-size selector (10/20/50).

**Key interactions:**
- Click row/card → navigate to `/dashboard/{analysis_id}`.
- Click ⋯ → menu: Open / Download HTML / Download PDF / Delete.
- Delete → confirmation modal («این تحلیل برای همیشه حذف می‌شود») → confirm → toast «حذف شد».
- Filter change → re-fetch with query params.
- Sort change → client-side sort (no re-fetch).

**States:**
- Empty (no analyses): illustration + headline + CTA to Upload.
- Loading: 5 skeleton cards.
- Error: error card with retry.
- Single analysis: list shows 1 item; no pagination.

---

### 12.5 Dashboard — Emotional Center (Primary, Special Treatment)

**Purpose:** The post-analysis home. The emotional payoff. Must answer 4 questions without scrolling on **every breakpoint including 375px**.

**The 4 questions (hard requirement):**
1. **Overall Health** — «وضعیت کلی» — one number, one severity color, one word
2. **Biggest Leak** — «بزرگ‌ترین نقطه‌ضعف» — one label, one $ figure, one severity
3. **Biggest Strength** — «بزرگ‌ترین نقطه‌قوت» — one label, one supporting metric
4. **Immediate Next Action** — «گام بعدی» — one verb-led sentence, one CTA

**Mobile layout (375–767px) — the hardest constraint:**

The 4 elements are stacked vertically, each a full-width card, in this exact order:

```
┌─────────────────────────────────┐
│ ۱. وضعیت کلی (Overall Health)    │  ← 140px tall
│  ┌──────────────────────────┐   │
│  │       ۶۷ / ۱۰۰            │   │  ← ScoreGauge radial, 96px numeral
│  │   انضباط: متوسط           │   │  ← severity word (Medium)
│  └──────────────────────────┘   │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ ۲. بزرگ‌ترین نقطه‌ضعف (Biggest Leak)│  ← 120px tall
│  معامله‌ی انتقامی (Revenge)       │  ← label ( Phosphor icon + text )
│  ۱٬۸۴۰ دلار ضرر · شدت: بالا      │  ← $ impact + severity badge
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ ۳. بزرگ‌ترین نقطه‌قوت (Biggest     │  ← 120px tall
│     Strength)                    │
│  بهترین ساعت: ۱۴:۰۰              │  ← label
│  میانگین سود: ۱۲ دلار/معامله     │  ← supporting metric
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ ۴. گام بعدی (Next Action)        │  ← 110px tall
│  بعد از هر باخت، ۳۰ دقیقه استراحت │  ← verb-led sentence
│  کن.                            │
│  [مشاهده برنامه‌ی کامل →]         │  ← CTA → /coaching/{id}
└─────────────────────────────────┘

──── fold (typical 375px viewport shows all 4 cards) ────

Below fold:
- Performance strip (2x3 grid of 6 stats)
- Quick-jump tiles (2x2 grid of 4 nav cards)
- Data quality warnings (collapsible)
```

Total above-fold height: 140 + 120 + 120 + 110 + (3 × 16px gaps) = 538px. Fits comfortably in a 375×667 iPhone SE viewport with top bar (56px) — 538 + 56 = 594px, leaving 73px of fold buffer. **All 4 elements visible without scrolling.** ✓

**Tablet layout (768–1023px):**

2-column grid above fold:
- Left column (60% width): Overall Health card (large, full column height) + Biggest Leak card below it.
- Right column (40% width): Biggest Strength card + Immediate Next Action card.

```
┌────────────────────┬─────────────────┐
│                    │ ۳. Biggest      │
│ ۱. Overall Health  │   Strength      │
│   [gauge 96px]     ├─────────────────┤
│                    │ ۴. Next Action  │
├────────────────────┤   [CTA]         │
│ ۲. Biggest Leak    │                 │
└────────────────────┴─────────────────┘
```

**Desktop layout (≥1024px):**

4-column grid above fold, all 4 cards equal width and equal height (~280px tall):

```
┌──────────┬──────────┬──────────┬──────────┐
│ Overall  │ Biggest  │ Biggest  │ Next     │
│ Health   │ Leak     │ Strength │ Action   │
│ [gauge]  │ [icon+$] │ [icon+$] │ [verb+   │
│          │          │          │  CTA]    │
└──────────┴──────────┴──────────┴──────────┘
```

Below fold (all breakpoints): performance strip, biggest-leak drill-down callout, what-if callout, quick-jump tiles, data quality warnings.

**Content sourcing for the 4 cards (from `GET /analyses/{id}/report`):**

| Card | Source field |
|---|---|
| Overall Health | `overall_score.value` (0–100) + `overall_score.severity` (0–3 → Low/Medium/High/Critical) |
| Biggest Leak | `evidence[0]` (top evidence by priority_score) → `evidence[0].label` + `evidence[0].financial_impact_fmt` + `evidence[0].severity` |
| Biggest Strength | `strengths[0]` (first auto-classified strength) — typically best_hour, best_weekday, or PF≥1 |
| Immediate Next Action | `recommendations[0]` (top-priority action_plan item) → `recommendations[0].action` (truncated to ~80 chars) + CTA to /coaching |

**Fallbacks** (when engine returns sparse data):
- If `evidence[]` is empty → Biggest Leak card shows «الگوی رفتاری برجسته‌ای شناسایی نشد» / "No notable behavioral pattern detected" + CTA to Behavioral.
- If `strengths[]` only has the default fallback string → Biggest Strength card shows «با داده‌ی فعلی، نقطه‌ی قوت برجسته‌ای شناسایی نشد» / "No standout strength identified with current data" + CTA to Edge Map.
- If `recommendations[]` is empty → Next Action card shows «برنامه‌ی اقدام در دسترس نیست» / "No action plan available" + CTA to Coaching.

**Key interactions:**
- Click any of the 4 cards → navigate to the corresponding drill-down page (Overall Health → Behavioral; Biggest Leak → Diagnosis; Biggest Strength → Edge Map; Next Action → Coaching).
- ScoreGauge animates from 0 to value on first render (600ms Expo.out, frozen if reduced-motion).
- Severity badges pulse subtly once on first render to draw the eye (frozen if reduced-motion).
- "Download report" persistent action in top bar (one click to /report/{id}).

**States:**
- Loading (analysis just completed, report fetching): 4 skeleton cards in the same layout.
- Error (report fetch failed): error card with retry CTA.
- Partial data: each card handles its own fallback (above).

---

### 12.6 Behavioral Analysis (Primary)

**Purpose:** Per-score breakdown of 5 behavioral scores with severity, $ impact, % of profit, event count, insight, what-if.

**Mobile:**
- Page title «تحلیل رفتاری» / "Behavioral Analysis" + 1-line summary «۳ رفتار نیاز به توجه دارد» / "3 behaviors need attention" (computed from severity counts).
- 5 `ContextBlockCard`s stacked vertically, ordered by severity (Critical → Low), then by $ impact:
  - Card header: behavior label (e.g., «معامله‌ی انتقامی») + severity badge + score (e.g., ۶۷/۱۰۰).
  - Card body (collapsed by default for Medium/Low; expanded for High/Critical):
    - 4 mini-stats: $ impact | % of profit | event count | avg per event
    - Insight text (2–3 lines)
    - What-if callout (collapsible): «اگر این رفتار را اصلاح می‌کردید، ۱٬۸۴۰ دلار بیشتر سود می‌کردید» / "If you'd fixed this, you'd have made $1,840 more"
    - CTA: «شواهد این رفتار» / "See evidence" → /diagnosis
- Tap card to expand/collapse.

**Tablet:**
- 2-column grid of cards.
- All cards expanded by default (more space).

**Desktop:**
- 5 cards in a 3+2 grid (top row 3, bottom row 2 centered) or single column with detailed expansion.
- Right rail (sticky): summary chart — radar chart of 5 scores (visual comparison), with severity legend.

**Key interactions:**
- Click card → expand/collapse (accordion behavior; only one expanded at a time on mobile).
- Click "See evidence" → /diagnosis (filtered to this behavior).
- Hover score (desktop) → tooltip with severity thresholds (Low <25, Medium 25–49, High 50–74, Critical 75+).
- What-if expand → reveals the simulation logic in one sentence.

**States:**
- Loading: 5 skeleton cards.
- Empty (no behavioral data — shouldn't happen post-analysis, but defensive): empty state with CTA to re-run.

---

### 12.7 Diagnosis (Primary)

**Purpose:** Primary + secondary diagnosis with explanatory detail and top-8 prioritized evidence.

**Mobile:**
- Page title «تشخیص» / "Diagnosis".
- Primary diagnosis card (full-width, severity-colored left border RTL:right):
  - Label: «مشکل اصلی» / "Primary issue"
  - Diagnosis text (large, bold): e.g., «معامله‌ی انتقامی پس از باخت‌های پیاپی» / "Revenge trading after consecutive losses"
  - Severity badge
  - Detail text (3–4 lines from `diagnosis.primary_detail`)
- Secondary diagnosis card (if exists):
  - Label: «مشکل ثانویه» / "Secondary issue"
  - Diagnosis text + brief detail
- Evidence section:
  - Section title: «شواهد» / "Evidence" + count
  - Top 3 evidence cards visible by default; "show all 8" button reveals the rest.
  - Each `EvidenceCard`: type icon + label + severity badge + frequency + $ impact + (collapsed) description + confidence score.
  - Tap card to expand description.
- Bottom CTA: «برنامه‌ی اقدام را ببین» / "See action plan" → /coaching

**Tablet/Desktop:**
- 2-column: left = primary + secondary diagnosis; right = evidence list (scrollable, sticky header).
- Desktop: evidence list shows all 8 with a "priority score" sparkline column.

**Key interactions:**
- Click evidence card → expand description + confidence explanation.
- Click primary diagnosis → smooth-scroll to top evidence for this diagnosis.
- "Show all" toggle on evidence list.
- CTA → /coaching.

**States:**
- Loading: skeleton of diagnosis cards + 3 evidence skeletons.
- No secondary diagnosis: hide the secondary card (no empty state).

---

### 12.8 Coaching (Primary)

**Purpose:** Action plan + AI coaching narrative + reality check.

**Mobile:**
- Page title «برنامه‌ی اقدام» / "Action Plan".
- Top card: «۳ گام برای این هفته» / "3 steps for this week" — top-3 recommendations as `RecommendationCard`s:
  - Each card: priority chip (P1/P2/P3) + issue label + action text (verb-led) + (collapsed) rationale + "Mark as done" toggle (Phase 1: visual only, no persistence).
  - Tap to expand rationale.
- "Show more" button → reveals remaining recommendations (up to 8 total).
- AI Coaching section:
  - Card with `Lightbulb` icon + «روانشناسی این برنامه» / "The psychology behind this plan" header.
  - Body: `ai_coaching.explainable_ai` text (long-form, narrow container for readability).
  - If LLM provider was "none": subtle badge «توضیح الگوریتمی» / "Algorithmic explanation" indicating heuristic text.
  - If LLM was used: badge «توضیح هوش مصنوعی» / "AI-generated explanation".
- Reality check section:
  - Card with `Info` icon + «واقعیت‌بینی» / "Reality check" header.
  - Body: `ai_coaching.reality_check` text.
- Bottom CTA: «گزارش کامل را دانلود کن» / "Download full report" → /report.

**Tablet/Desktop:**
- 2-column: left = action plan (top-3 cards); right = AI coaching + reality check (sticky).
- Desktop: top-3 recommendations in 3-column grid.

**Key interactions:**
- "Mark as done" toggle (visual feedback only in Phase 1; future: persists to user profile).
- "Show more" reveals remaining recommendations with a smooth expand animation.
- CTA → /report.

**States:**
- Loading: 3 skeleton recommendation cards + skeleton text block.
- LLM was "none": show algorithmic badge; explain in tooltip that AI is optional.

---

### 12.9 Trader DNA (Deep Dive)

**Purpose:** Psychological archetype profile with narrative and supporting evidence.

**Mobile:**
- Page title «دی‌ان‌ای معامله‌گر» / "Trader DNA".
- Hero card: full-width, centered:
  - Large archetype label (e.g., «معامله‌گر انتقامی» / "Revenge Trader") in `--text-data-xl`, mono font.
  - Archetype icon (large, 48px) representing the archetype.
  - One-line summary «این پروفایل بر اساس مهم‌ترین شواهد رفتاری شما تعیین شده است» / "This profile is determined by your strongest behavioral evidence."
- Narrative card: full-width, narrow container for readability:
  - `psychology.narrative` text (3–5 paragraphs).
- Supporting evidence card:
  - Section: «شواهد پشتیبان این پروفایل» / "Evidence supporting this profile"
  - Top 3 evidence items (compact `EvidenceCard`s).
- CTA: «تشخیص کامل را ببین» / "See full diagnosis" → /diagnosis.

**Tablet/Desktop:**
- 2-column: left = hero + narrative; right = supporting evidence (sticky).
- Desktop: hero card has a DNA-helix SVG decoration on the side.

**Key interactions:**
- Archetype icon → tooltip explaining the archetype name.
- Evidence card → expandable to show full description.
- CTA → /diagnosis.

**States:**
- Loading: skeleton hero + skeleton paragraphs.
- Archetype is "N/A" or empty: show «پروفایل هنوز تعیین نشده» / "Profile not yet determined" + CTA to re-analyze with more data.

---

### 12.10 Edge Map (Deep Dive)

**Purpose:** Best/worst trading hour, weekday, strategy, long-vs-short.

**Mobile:**
- Page title «نقشه‌ی نقاط قوت و ضعف» / "Edge Map".
- 2-card grid (2×2 layout on mobile):
  - Best Hour card (green-bordered): «بهترین ساعت: ۱۴:۰۰» + avg P&L
  - Worst Hour card (red-bordered): «بدترین ساعت: ۰۳:۰۰» + avg P&L
  - Best Weekday card (green-bordered): «بهترین روز: سه‌شنبه» + total P&L
  - Worst Weekday card (red-bordered): «بدترین روز: یکشنبه» + total P&L
- Best/Worst Strategy cards (if exists):
  - Best strategy: name + avg P&L + win rate
  - Worst strategy: name + avg P&L
- Side comparison section:
  - Long vs Short `DataTable` (mobile: card layout) showing: count, win rate, avg P&L, total P&L for each side.
- Heatmap visualization (Charts page teaser):
  - Hour × Weekday P&L heatmap (compact on mobile, full on desktop).
  - Tap a cell → tooltip with exact value.

**Tablet/Desktop:**
- 4-column grid for best/worst cards (top row).
- Strategy cards in 2-column row.
- Side comparison as proper table.
- Heatmap full-size with hover tooltip.

**Key interactions:**
- Click any best/worst card → drill to /charts with this dimension pre-selected.
- Heatmap hover/tap → tooltip.
- Side comparison row click → drill to /behavioral filtered to that side.

**States:**
- Loading: 4 skeleton cards + skeleton heatmap.
- Empty edge_map (insufficient data — engine requires ≥5 trades per bucket): show «داده‌ی کافی برای این تحلیل نیست» / "Not enough data for this analysis" + CTA to upload more trades.

---

### 12.11 Charts (Deep Dive)

**Purpose:** Visual deep-dive — equity curve, drawdown, P&L distribution, hourly heatmap, weekday breakdown, win/loss streaks. Each chart answers a specific question.

**Mobile:**
- Page title «نمودارها» / "Charts".
- Chart selector (horizontal scrollable `SegmentedControl` or pill list):
  - Equity Curve | Drawdown | P&L Distribution | Hourly Heatmap | Weekday Breakdown | Win/Loss Streaks
- Selected chart fills the screen (full-width, ~280px tall on mobile).
- Below chart: 1-line caption explaining what the chart shows + what to look for.
- Below caption: "key insight" callout (engine-derived where possible, e.g., «بیشترین افت سرمایه در روز ۱۴ رخ داد» / "Largest drawdown occurred on day 14").

**Tablet/Desktop:**
- 2-column grid: chart on left (larger), key insight + raw data table on right.
- Desktop: all 6 charts visible in a 2-column masonry layout, each with its own caption and insight.

**Charts (all consume `behavior_analysis`, `performance`, `statistics`, `appendix`):**

| Chart | Type | Library | Question it answers |
|---|---|---|---|
| Equity Curve | Line/Area | Recharts | "How did my account grow/shrink over time?" |
| Drawdown | Area (negative) | Recharts | "What was my worst period?" |
| P&L Distribution | Histogram | Recharts | "Are my wins bigger than my losses?" |
| Hourly Heatmap | Heatmap (custom SVG) | Custom | "When am I most/least profitable?" |
| Weekday Breakdown | Bar chart | Recharts | "Which days work for me?" |
| Win/Loss Streaks | Bar chart (green/red) | Recharts | "How long are my winning/losing streaks?" |

**Key interactions:**
- Chart selector → swap chart (300ms cross-fade).
- Hover/tap data point → tooltip with exact value + date/time.
- Pinch on mobile → zoom (equity curve, drawdown only).
- Double-tap → reset zoom.
- Click "key insight" callout → highlight the relevant data point on the chart.

**States:**
- Loading: chart skeleton (axes + animated bars placeholder).
- Empty (insufficient data for this specific chart): empty chart card with explanation.
- Error (chart render failed): error card with retry.

---

### 12.12 Trends (Deep Dive)

**Purpose:** Longitudinal view of score evolution across past analyses. Requires 2+ analyses.

**Mobile:**
- Page title «روند تغییرات» / "Trends".
- Metric selector (`SegmentedControl`): Discipline | Revenge | Overtrading | Risk-Taking | Patience | Net Profit | Win Rate.
- Line chart (full-width, 240px tall) showing selected metric across all past analyses (x-axis: analysis date, y-axis: metric value).
- Below chart: trend summary callout:
  - If improving: «انضباط شما در ۳ تحلیل اخیر در حال بهبود است» / "Your discipline is improving across your last 3 analyses" + green up-arrow.
  - If declining: red down-arrow + warning.
  - If flat: «تغییر قابل‌توجهی مشاهده نمی‌شود» / "No significant change observed" + neutral.
- Below callout: comparison table (card layout on mobile):
  - Each row: date | metric value | delta vs previous | delta vs first.

**Tablet/Desktop:**
- 2-column: left = chart + summary; right = comparison table + all-metrics radar chart (5-axis).
- Desktop: chart is larger; radar chart in top-right corner; full comparison table below.

**Key interactions:**
- Metric selector → swap chart + table (300ms cross-fade).
- Hover/tap data point → tooltip with exact value + date + filename.
- Click table row → navigate to that analysis's Dashboard.
- "Re-analyze now" CTA → /upload.

**States:**
- Loading: chart skeleton + table skeleton.
- Empty (only 1 analysis): empty state with illustration + «برای دیدن روند، حداقل ۲ تحلیل لازم است» / "You need at least 2 analyses to see trends" + CTA to Upload.
- Empty (0 analyses): same empty state, stronger CTA.

---

### 12.13 Report (Action)

**Purpose:** Generate, preview, and download HTML and PDF reports.

**Mobile:**
- Page title «گزارش» / "Report".
- Top card: «گزارش شما آماده است» / "Your report is ready" + 2 download buttons (full-width, stacked):
  - «دانلود PDF» (primary, amber) → triggers `GET /analyses/{id}/report.pdf` download.
  - «دانلود HTML» (secondary) → triggers `GET /analyses/{id}/report.html` download.
- Below: section preview (vertically stacked cards, each a collapsible):
  - Executive Summary (expanded by default)
  - Performance
  - Behavioral Analysis
  - Diagnosis
  - Coaching
  - Evidence
  - Appendix
- Each preview card: section title + 2-line excerpt + "expand" to see full section content (rendered from JSON report).
- Bottom: data quality warnings (if any) + report metadata (generated_at, engine_version, total_trades).

**Tablet/Desktop:**
- 2-column: left = section navigator (sticky list of sections, click to jump); right = section previews (full content rendered).
- Download buttons persist in top-right (sticky).

**Key interactions:**
- Download PDF/HTML → triggers browser download with filename `trading_doctor_report_{date}.pdf`.
- Section navigator click → smooth scroll to that section.
- Expand/collapse sections individually.
- "Print" button (alternative to PDF download) → opens browser print dialog.

**States:**
- Loading: skeleton of section cards.
- Download in progress: button enters loading state (spinner + «در حال آماده‌سازی...»).
- Download complete: toast «گزارش دانلود شد» / "Report downloaded".
- Error: error card with retry.

---

### 12.14 Settings (Future-Ready Stub)

**Purpose:** Account, theme, language, LLM provider default, API key.

**Phase 1 stub:**
- Page title «تنظیمات» / "Settings".
- 3 sections only (everything else shows «به‌زودی» / "Coming soon"):
  - Appearance: theme toggle (Light/Dark/System) + density toggle (Comfortable/Compact — visual only in Phase 1).
  - Language: language toggle (فارسی / English).
  - About: app version + engine version + link to docs + "Reset all data" button (clears localStorage).
- Future sections (visible but disabled): Account, API Keys, Notifications, Mentor Workspace.

**Layout:** Single column, full-width on mobile, max-width 640px on desktop, centered.

---

## 13. Empty / Loading / Error States (Universal Patterns)

Every page and component follows these patterns. The patterns are **actionable** — never just "no data."

### 13.1 Empty states

| Trigger | Pattern |
|---|---|
| No analysis in context (Tier 2+ page accessed directly) | Illustration (SVG) + «هنوز تحلیلی انجام نداده‌اید» / "You haven't run an analysis yet" + primary CTA «شروع تحلیل» → /upload |
| History empty | Illustration + «تاریخچه‌ی تحلیلی وجود ندارد» + CTA to Upload |
| Trends with <2 analyses | Illustration + «برای دیدن روند، حداقل ۲ تحلیل لازم است» + CTA to Upload |
| Edge Map with insufficient data | Illustration + «داده‌ی کافی برای این تحلیل نیست (حداقل ۵ معامله در هر دسته لازم است)» + CTA to Upload |
| Search/filter returns nothing | «هیچ موردی با این فیلتر یافت نشد» + "Clear filters" button |

### 13.2 Loading states

| Trigger | Pattern |
|---|---|
| Initial page load (Server Component fetch) | Page-level skeleton matching final layout shape (cards, charts, tables in greyed-out placeholder form). Skeleton pulse animation. |
| Inline data refresh | Inline skeleton (only the refreshing component shows skeleton, rest of page stays interactive). |
| Action in progress (button click) | Button enters loading state: spinner icon + verb-led text («در حال اجرا...»). Button disabled. |
| Analysis running (Upload page) | `ProgressStepper` with 6 named stages, current stage has spinner, completed stages have check, upcoming stages are dimmed. Elapsed time per stage. |
| Chart rendering | Chart skeleton (axes visible, data area shows pulsing placeholder bars). |

### 13.3 Error states

| Trigger | Pattern |
|---|---|
| Network error / API unreachable | Error card: «اتصال به سرور برقرار نشد» / "Couldn't connect to server" + retry button. |
| 404 (analysis not found) | Error card: «تحلیل موردنظر یافت نشد» / "Analysis not found" + CTA to History. |
| 422 (invalid data) | Inline error: engine's Persian message (already user-friendly per Phase 1 audit) + "supported formats" link. |
| 413 (file too large) | Inline error: «حجم فایل بیشتر از حد مجاز (۲۵ مگابایت) است» / "File exceeds 25MB limit" + suggestion to split. |
| 429 (rate limited) | Error card: «تعداد درخواست‌ها بیش از حد مجاز است. لطفاً یک دقیقه دیگر تلاش کنید.» / "Too many requests. Please try again in a minute." + auto-retry countdown. |
| 500 (server error) | Error card: «خطای داخلی سرور. لطفاً بعداً تلاش کنید.» / "Internal server error. Please try again later." + report button (future). |
| Chart render error | Inline error in chart area: «نمودار قابل رسم نیست» / "Couldn't render chart" + "View raw data" fallback link. |

---

## 14. Information Density & Cognitive Load Targets (Per Page)

Per Phase 1's Cognitive Load Reduction strategy, each page has an explicit density target.

| Page | Density target | Above-fold elements | Below-fold elements | Max visible without action |
|---|---|---|---|---|
| Home / Landing | Low | 1 headline, 1 subhead, 1 CTA | trust strip, how-it-works, sample | 3 |
| Sample Report | Medium | title + badge + report | sticky CTA | 3 |
| Upload | Low | dropzone, format hint, CTA | (after file) file pill, provider, CTA | 3 |
| History | Medium | title, filter, list | pagination | 5 (title + filter + 3 cards) |
| **Dashboard** | **Low (emotional center)** | **4 cards only** | perf strip, quick-jumps, warnings | **4** |
| Behavioral Analysis | Medium | 5 cards (collapsed) | expanded details | 5 |
| Diagnosis | Medium | primary card, secondary card, top-3 evidence | "show more", CTA | 5 |
| Coaching | Low | top-3 recommendations | AI coaching, reality check | 4 (title + 3 cards) |
| Trader DNA | Low | archetype hero, narrative start | supporting evidence | 2 |
| Edge Map | Medium | 4 best/worst cards | strategy, side comparison, heatmap | 4 |
| Charts | Low (one chart at a time on mobile) | selector, chart, caption | insight, more charts | 3 |
| Trends | Low | selector, chart, summary | comparison table | 3 |
| Report | Medium | ready card, download buttons | section previews | 3 |
| Settings | Low | 3 sections | future (disabled) | 3 |

The Dashboard's "4 above fold" is the tightest constraint in the entire product. Every other page has more breathing room — intentionally. The Dashboard earns its emotional impact by **saying less**.

---

## 15. Implementation Notes for Phase 3 (preview, not exhaustive)

These notes bridge Phase 2 (design) to Phase 3 (implementation). They are not implementation themselves — they specify constraints the implementation must respect.

### 15.1 Stack (assumed; will be confirmed in Phase 3)

- **Next.js 14+ (App Router)** — per UI/UX Pro Max `data/stacks/nextjs.csv` guidelines.
- **Tailwind CSS** — for token-driven styling, mobile-first breakpoints.
- **shadcn/ui** — for accessible, token-driven component primitives (Button, Card, Dialog, etc.). Custom components (ScoreGauge, EvidenceCard, etc.) built on top.
- **Recharts** — for line/area/bar/radar charts (per skill recommendation for dashboards).
- **Phosphor Icons** — `@phosphor-icons/react` for all icons.
- **next/font** — for self-hosting Vazirmatn + Fira Sans + Fira Code with zero layout shift.
- **next/image** — for any raster images (sample report screenshots, illustrations).
- **Server Components by default** — `'use client'` only at leaf nodes for interactive components.
- **Route Handlers** — for any server-side BFF calls to the Trading Doctor API (avoids exposing API URL to client).
- **Middleware** — for future auth gate (Phase 1: passthrough).

### 15.2 Routing structure (App Router)

```
app/
├── (public)/                    # Route group, no auth
│   ├── page.tsx                 # Home / Landing
│   ├── sample/page.tsx          # Sample Report
│   └── layout.tsx               # Public layout (no sidebar)
├── (app)/                       # Route group, analysis-aware
│   ├── layout.tsx               # App layout (sidebar + top bar + bottom tab bar)
│   ├── upload/page.tsx
│   ├── history/page.tsx
│   ├── dashboard/[analysisId]/page.tsx
│   ├── behavioral/[analysisId]/page.tsx
│   ├── diagnosis/[analysisId]/page.tsx
│   ├── coaching/[analysisId]/page.tsx
│   ├── trader-dna/[analysisId]/page.tsx
│   ├── edge-map/[analysisId]/page.tsx
│   ├── charts/[analysisId]/page.tsx
│   ├── trends/page.tsx          # Multi-analysis, no specific ID
│   ├── report/[analysisId]/page.tsx
│   └── settings/page.tsx
├── api/                         # Route Handlers (BFF)
│   ├── uploads/route.ts
│   ├── analyses/route.ts
│   ├── analyses/[id]/route.ts
│   ├── analyses/[id]/report/route.ts
│   ├── analyses/[id]/report.html/route.ts
│   ├── analyses/[id]/report.pdf/route.ts
│   └── history/route.ts
└── layout.tsx                   # Root layout (font loading, theme provider, dir)
```

### 15.3 Data fetching

- Server Components fetch via internal Route Handlers (BFF pattern), which proxy to the Trading Doctor FastAPI backend at `TRADING_DOCTOR_API_URL`.
- Client-side mutations (upload, run analysis) use Server Actions or fetch to Route Handlers.
- All API responses cached with `revalidate` per Next.js 15 conventions.
- Optimistic UI for toggle actions (e.g., "mark as done" in Coaching).

### 15.4 State management

- Server state: TanStack Query (or Next.js native cache) for analysis data.
- Client state: React Context for theme, language, current analysis ID.
- Form state: React Hook Form + Zod for validation (Upload page, future Settings).

### 15.5 Performance budget

- First Contentful Paint: <1.5s on 4G mobile.
- Largest Contentful Paint: <2.5s on 4G mobile.
- Cumulative Layout Shift: <0.1 (zero layout shift; Skeleton loaders match final shape).
- Time to Interactive: <3.5s on 4G mobile.
- Bundle size: <200KB initial JS (gzip) on mobile.

---

## 16. Pre-Delivery Checklist (Phase 3 gate)

Before Phase 3 implementation is considered complete, every item must pass:

### Visual quality
- [ ] No emojis as structural icons (SVG via Phosphor only)
- [ ] All icons from Phosphor (or Heroicons fallback), consistent weight per level
- [ ] All colors come from semantic tokens; zero hardcoded hex in components
- [ ] All fonts loaded via `next/font` (zero layout shift)
- [ ] Both themes (dark/light) tested independently for contrast

### Responsive
- [ ] Every page tested at 375 / 768 / 1024 / 1280 / 1536px
- [ ] Mobile-first: base styles target mobile, breakpoints enhance upward
- [ ] All touch targets ≥44×44pt on mobile
- [ ] Tables become cards on mobile (`mobileCardLayout`)
- [ ] Modals become bottom sheets on mobile
- [ ] Bottom tab bar appears only on mobile (`< md`)

### Dashboard (emotional center)
- [ ] 4 required elements (Overall Health, Biggest Leak, Biggest Strength, Immediate Next Action) visible without scrolling on 375×667 viewport
- [ ] Each card navigates to its drill-down page
- [ ] ScoreGauge animates from 0 (frozen if reduced-motion)

### RTL & Persian
- [ ] Default direction `dir="rtl"`, default language `fa`
- [ ] All components use logical CSS properties (no `margin-left` etc.)
- [ ] Charts flow right-to-left in RTL
- [ ] Persian numerals in prose, Latin numerals in mono data
- [ ] Shamsi calendar dates in Persian UI
- [ ] Language toggle works without reload

### Accessibility
- [ ] WCAG AA contrast verified (≥4.5:1 body, ≥3:1 secondary, both themes)
- [ ] Keyboard navigation: every interactive element reachable via Tab
- [ ] Visible focus rings (3px, never removed)
- [ ] `prefers-reduced-motion` respected (all motion ≤1ms)
- [ ] ARIA labels on every interactive element
- [ ] Charts have `aria-label` + visually-hidden data table alternative
- [ ] Color is never the only signal (every color-coded indicator has text/icon)
- [ ] Screen reader test (NVDA + VoiceOver) passes on key flows

### Interaction
- [ ] All motion in 150–600ms range, Expo.out easing
- [ ] Press feedback within 80–150ms
- [ ] Skeleton loaders (not spinners) for async content
- [ ] Empty states always actionable (illustration + headline + CTA)
- [ ] Error states always recoverable (what + why + CTA)
- [ ] Toasts auto-dismiss after 4s, manually dismissible

### Engine integration
- [ ] Every page consumes the Trading Doctor REST API (no engine logic in frontend)
- [ ] No score, threshold, or diagnosis computed client-side
- [ ] HTML/PDF download endpoints used as-is (no client-side rendering)
- [ ] Error envelope `{"error":{code,message,details}}` handled uniformly

---

## Summary

Phase 2 produces a complete UX & Visual Design specification grounded in:
- The UI/UX Pro Max skill's canonical design system (persisted as `design-system/trading-doctor/MASTER.md`)
- Three Phase 1 refinements treated as hard constraints
- Trading Doctor V23's actual engine outputs (no invented analytics)

The Dashboard is rebuilt as the **emotional center** with the 4 required elements visible without scrolling on every breakpoint including 375×667. Every page is specified mobile-first with simultaneous tablet and desktop enhancements. The component system is token-driven, RTL-aware, accessible (WCAG AA), and uses Phosphor SVG icons (no emojis). Motion is capped at Standard tier (functional, not decorative). Both dark and light themes are first-class.

**Awaiting approval before Phase 3 (Implementation).**
